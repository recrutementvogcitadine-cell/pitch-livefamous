import React, { useState } from 'react';
import { X, Phone, MessageCircle, Send, User, Mail, MapPin, Star, Shield, Clock } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface SellerInfo {
  name: string;
  phone?: string;
  whatsapp?: string;
  location?: string;
  rating?: number;
  verified?: boolean;
  responseTime?: string;
}

interface ProductInfo {
  name: string;
  price: number;
  image: string;
}

interface ContactSellerModalProps {
  isOpen: boolean;
  onClose: () => void;
  seller: SellerInfo;
  product?: ProductInfo;
}

const formatPrice = (price: number) => {
  return new Intl.NumberFormat('fr-CI', {
    style: 'currency',
    currency: 'XOF',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price);
};

const ContactSellerModal: React.FC<ContactSellerModalProps> = ({ 
  isOpen, 
  onClose, 
  seller, 
  product 
}) => {
  const [message, setMessage] = useState(
    product 
      ? `Bonjour, je suis intéressé(e) par "${product.name}" à ${formatPrice(product.price)}. Est-il toujours disponible ?`
      : 'Bonjour, je suis intéressé(e) par vos produits. Pouvez-vous me donner plus d\'informations ?'
  );
  const [contactMethod, setContactMethod] = useState<'whatsapp' | 'call' | 'message'>('whatsapp');

  if (!isOpen) return null;

  // Default phone number for demo (Côte d'Ivoire format)
  const sellerPhone = seller.phone || seller.whatsapp || '+2250700000000';
  const cleanPhone = sellerPhone.replace(/\s/g, '');

  const handleWhatsApp = () => {
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
    toast({
      title: "Redirection vers WhatsApp",
      description: `Vous allez contacter ${seller.name}`,
    });
    onClose();
  };

  const handleCall = () => {
    window.location.href = `tel:${cleanPhone}`;
    toast({
      title: "Appel en cours",
      description: `Appel vers ${seller.name}`,
    });
  };

  const handleSendMessage = () => {
    // In a real app, this would send a message through the platform
    toast({
      title: "Message envoyé",
      description: `Votre message a été envoyé à ${seller.name}. Vous recevrez une réponse bientôt.`,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      ></div>

      {/* Modal */}
      <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-red-500 to-red-600 p-6">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-white/20 backdrop-blur rounded-full text-white hover:bg-white/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">{seller.name}</h2>
                {seller.verified && (
                  <Shield className="w-5 h-5 text-white" />
                )}
              </div>
              {seller.location && (
                <div className="flex items-center gap-1 text-white/80 text-sm mt-1">
                  <MapPin className="w-4 h-4" />
                  {seller.location}
                </div>
              )}
              <div className="flex items-center gap-3 mt-2">
                {seller.rating && (
                  <div className="flex items-center gap-1 text-white/90 text-sm">
                    <Star className="w-4 h-4" fill="currentColor" />
                    {seller.rating}
                  </div>
                )}
                {seller.responseTime && (
                  <div className="flex items-center gap-1 text-white/80 text-sm">
                    <Clock className="w-4 h-4" />
                    {seller.responseTime}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Product Info (if provided) */}
        {product && (
          <div className="p-4 bg-slate-800/50 border-b border-slate-700">
            <div className="flex items-center gap-4">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-20 h-20 object-cover rounded-xl"
              />
              <div className="flex-1 min-w-0">
                <p className="text-slate-400 text-xs mb-1">Produit sélectionné</p>
                <h3 className="text-white font-medium truncate">{product.name}</h3>
                <p className="text-red-500 font-bold mt-1">{formatPrice(product.price)}</p>
              </div>
            </div>
          </div>
        )}

        {/* Contact Methods */}
        <div className="p-6">
          <h3 className="text-white font-semibold mb-4">Choisissez comment contacter le vendeur</h3>
          
          <div className="grid grid-cols-3 gap-3 mb-6">
            <button
              onClick={() => setContactMethod('whatsapp')}
              className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                contactMethod === 'whatsapp'
                  ? 'border-green-500 bg-green-500/10'
                  : 'border-slate-700 bg-slate-800 hover:border-slate-600'
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                contactMethod === 'whatsapp' ? 'bg-green-500' : 'bg-slate-700'
              }`}>
                <MessageCircle className="w-5 h-5 text-white" />
              </div>
              <span className={`text-sm font-medium ${
                contactMethod === 'whatsapp' ? 'text-green-400' : 'text-slate-400'
              }`}>WhatsApp</span>
            </button>

            <button
              onClick={() => setContactMethod('call')}
              className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                contactMethod === 'call'
                  ? 'border-blue-500 bg-blue-500/10'
                  : 'border-slate-700 bg-slate-800 hover:border-slate-600'
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                contactMethod === 'call' ? 'bg-blue-500' : 'bg-slate-700'
              }`}>
                <Phone className="w-5 h-5 text-white" />
              </div>
              <span className={`text-sm font-medium ${
                contactMethod === 'call' ? 'text-blue-400' : 'text-slate-400'
              }`}>Appeler</span>
            </button>

            <button
              onClick={() => setContactMethod('message')}
              className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                contactMethod === 'message'
                  ? 'border-red-500 bg-red-500/10'
                  : 'border-slate-700 bg-slate-800 hover:border-slate-600'
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                contactMethod === 'message' ? 'bg-red-500' : 'bg-slate-700'
              }`}>
                <Mail className="w-5 h-5 text-white" />
              </div>
              <span className={`text-sm font-medium ${
                contactMethod === 'message' ? 'text-red-400' : 'text-slate-400'
              }`}>Message</span>
            </button>
          </div>

          {/* Message Input (for WhatsApp and Message) */}
          {(contactMethod === 'whatsapp' || contactMethod === 'message') && (
            <div className="mb-6">
              <label className="block text-slate-400 text-sm mb-2">Votre message</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={4}
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 resize-none"
                placeholder="Écrivez votre message..."
              />
            </div>
          )}

          {/* Action Button */}
          {contactMethod === 'whatsapp' && (
            <button
              onClick={handleWhatsApp}
              className="w-full py-4 bg-green-500 text-white font-bold rounded-xl hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              Ouvrir WhatsApp
            </button>
          )}

          {contactMethod === 'call' && (
            <button
              onClick={handleCall}
              className="w-full py-4 bg-blue-500 text-white font-bold rounded-xl hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Appeler maintenant
            </button>
          )}

          {contactMethod === 'message' && (
            <button
              onClick={handleSendMessage}
              className="w-full py-4 bg-gradient-to-r from-red-500 to-red-600 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-5 h-5" />
              Envoyer le message
            </button>
          )}

          {/* Info Text */}
          <p className="text-slate-500 text-xs text-center mt-4">
            Les transactions se font directement entre vous et le vendeur. 
            PITCH n'est pas responsable des transactions.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ContactSellerModal;
