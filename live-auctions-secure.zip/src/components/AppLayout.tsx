import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import Header from './Header';
import HeroSection from './HeroSection';
import LiveStreamsSection from './LiveStreamsSection';
import FeaturedProducts from './FeaturedProducts';
import HowItWorks from './HowItWorks';
import SubscriptionPlans from './SubscriptionPlans';
import Testimonials from './Testimonials';
import TopSellers from './TopSellers';
import CTABanner from './CTABanner';
import Footer from './Footer';
import AuthModal from './AuthModal';
import LiveStreamModal from './LiveStreamModal';
import SellerDashboard from './SellerDashboard';
import AdminPanel from './AdminPanel';
import { MessagingPanel } from './MessagingPanel';
import { GlobalVideoCallHandler } from './GlobalVideoCallHandler';
import { NotificationCenter } from './NotificationCenter';
import { LiveStream } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { CalendarDays, ArrowRight } from 'lucide-react';

const AppLayout: React.FC = () => {
  const location = useLocation();
  const { user, profile } = useAuth();
  
  // State management
  const [searchQuery, setSearchQuery] = useState('');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');
  const [isSellerDashboardOpen, setIsSellerDashboardOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [isMessagingOpen, setIsMessagingOpen] = useState(false);
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState(false);
  const [isSubscriptionPlansOpen, setIsSubscriptionPlansOpen] = useState(false);
  const [selectedStream, setSelectedStream] = useState<LiveStream | null>(null);

  // Check if we should open auth modal from navigation state
  useEffect(() => {
    const state = location.state as { openAuth?: boolean } | null;
    if (state?.openAuth && !user) {
      setIsAuthModalOpen(true);
      // Clear the state
      window.history.replaceState({}, document.title);
    }
  }, [location, user]);

  // Handlers
  const handleJoinStream = (stream: LiveStream) => {
    setSelectedStream(stream);
  };

  const handleSelectPlan = (planId: string) => {
    if (!user) {
      setAuthModalTab('register');
      setIsAuthModalOpen(true);
    } else if (profile?.user_type === 'seller') {
      // Already a seller, show dashboard
      setIsSellerDashboardOpen(true);
    } else {
      // User is logged in but not a seller
      setAuthModalTab('register');
      setIsAuthModalOpen(true);
    }
  };

  const handleOpenAuth = (tab: 'login' | 'register' = 'login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const handleOpenAdminPanel = () => {
    setIsAdminPanelOpen(true);
  };

  const handleOpenNotificationCenter = () => {
    setIsNotificationCenterOpen(true);
  };

  const scrollToLives = () => {
    document.getElementById('lives')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Handler for "Devenir Vendeur" button
  const handleBecomeSeller = () => {
    if (!user) {
      // User not logged in - show auth modal with register tab
      setAuthModalTab('register');
      setIsAuthModalOpen(true);
    } else if (profile?.user_type === 'seller') {
      // Already a seller - open seller dashboard
      setIsSellerDashboardOpen(true);
    } else {
      // User is logged in but not a seller - show subscription plans
      setIsSubscriptionPlansOpen(true);
    }
  };

  // Handler for opening live from notification
  const handleOpenLiveFromNotification = (streamId: string) => {
    // Find the stream from mock data or fetch it
    // For now, we'll just scroll to the lives section
    document.getElementById('lives')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Handler for opening replay from notification
  const handleOpenReplayFromNotification = (streamId: string) => {
    // Scroll to lives section which has replays tab
    document.getElementById('lives')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <Header 
        onAuthClick={() => handleOpenAuth('login')}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenAdminPanel={handleOpenAdminPanel}
        onOpenLive={handleOpenLiveFromNotification}
        onOpenReplay={handleOpenReplayFromNotification}
        onOpenMessaging={() => setIsMessagingOpen(true)}
        onOpenNotificationCenter={handleOpenNotificationCenter}
      />


      {/* Main Content */}
      <main>
        {/* Hero Section */}
        <HeroSection 
          onStartSelling={handleBecomeSeller}
          onDiscoverLives={scrollToLives}
        />

        {/* Live Streams Section */}
        <LiveStreamsSection 
          searchQuery={searchQuery}
          onJoinStream={handleJoinStream}
        />

        {/* Live Schedule Banner */}
        <section className="py-12 bg-gradient-to-r from-purple-900/50 via-slate-900 to-pink-900/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl p-8 border border-purple-500/30 backdrop-blur-sm">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                    <CalendarDays className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">Programme des Lives</h3>
                    <p className="text-slate-300">
                      Découvrez les prochains lives et ne manquez aucun événement de vos vendeurs préférés
                    </p>
                  </div>
                </div>
                <Link 
                  to="/live-schedule"
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-purple-500/30 transition-all whitespace-nowrap"
                >
                  Voir le programme
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <HowItWorks />

        {/* Featured Products */}
        <FeaturedProducts 
          onAuthClick={() => handleOpenAuth('login')}
        />

        {/* Top Sellers */}
        <TopSellers />

        {/* Subscription Plans Section - visible on page */}
        <section id="subscriptions" className="py-20 bg-slate-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                Devenez Vendeur sur PITCH
              </h2>
              <p className="text-slate-400 max-w-2xl mx-auto">
                Choisissez le plan qui correspond à vos besoins et commencez à vendre en live dès aujourd'hui
              </p>
            </div>
            <div className="flex justify-center">
              <button
                onClick={handleBecomeSeller}
                className="px-8 py-4 bg-gradient-to-r from-red-500 to-red-600 text-white font-bold rounded-xl hover:shadow-xl hover:shadow-red-500/30 transition-all"
              >
                {user && profile?.user_type === 'seller' 
                  ? 'Accéder à mon Dashboard' 
                  : user 
                    ? 'Voir les Plans d\'Abonnement'
                    : 'Créer un Compte Vendeur'}
              </button>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <Testimonials />

        {/* CTA Banner */}
        <CTABanner onGetStarted={() => handleOpenAuth('register')} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialTab={authModalTab}
      />

      <LiveStreamModal 
        stream={selectedStream}
        isOpen={selectedStream !== null}
        onClose={() => setSelectedStream(null)}
      />

      <SellerDashboard
        isOpen={isSellerDashboardOpen}
        onClose={() => setIsSellerDashboardOpen(false)}
      />

      <AdminPanel
        isOpen={isAdminPanelOpen}
        onClose={() => setIsAdminPanelOpen(false)}
      />

      <MessagingPanel
        isOpen={isMessagingOpen}
        onClose={() => setIsMessagingOpen(false)}
      />

      <NotificationCenter
        isOpen={isNotificationCenterOpen}
        onClose={() => setIsNotificationCenterOpen(false)}
      />

      {/* Subscription Plans Modal */}
      <SubscriptionPlans
        isOpen={isSubscriptionPlansOpen}
        onClose={() => setIsSubscriptionPlansOpen(false)}
        onSubscriptionChange={() => {
          setIsSubscriptionPlansOpen(false);
          setIsSellerDashboardOpen(true);
        }}
      />

      {/* Global Video Call Handler - handles incoming calls even when messaging is closed */}
      <GlobalVideoCallHandler 
        onOpenMessaging={() => setIsMessagingOpen(true)}
      />
    </div>
  );
};

export default AppLayout;
