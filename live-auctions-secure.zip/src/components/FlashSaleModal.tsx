import React, { useState } from 'react';
import { 
  X, Zap, Clock, Percent, Package, AlertTriangle,
  TrendingDown, Bell, Users
} from 'lucide-react';
import { formatPrice } from '@/data/mockData';

interface Product {
  id: string;
  name: string;
  price: number;
  image?: string;
  originalPrice?: number;
}

interface FlashSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  streamId: string;
  sellerId: string;
  onCreateFlashSale: (params: {
    stream_id: string;
    product_id: string;
    product_name: string;
    product_image?: string;
    original_price: number;
    discount_percent: number;
    duration_minutes: number;
    max_units?: number;
    seller_id: string;
  }) => Promise<any>;
  isLoading?: boolean;
}

const DISCOUNT_OPTIONS = [10, 15, 20, 25, 30, 40, 50];
const DURATION_OPTIONS = [
  { value: 2, label: '2 min' },
  { value: 5, label: '5 min' },
  { value: 10, label: '10 min' },
  { value: 15, label: '15 min' },
  { value: 30, label: '30 min' }
];

const FlashSaleModal: React.FC<FlashSaleModalProps> = ({
  isOpen,
  onClose,
  products,
  streamId,
  sellerId,
  onCreateFlashSale,
  isLoading = false
}) => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [discountPercent, setDiscountPercent] = useState(20);
  const [customDiscount, setCustomDiscount] = useState('');
  const [durationMinutes, setDurationMinutes] = useState(5);
  const [maxUnits, setMaxUnits] = useState<string>('');
  const [step, setStep] = useState<'select' | 'configure' | 'confirm'>('select');

  if (!isOpen) return null;

  const effectiveDiscount = customDiscount ? parseInt(customDiscount) : discountPercent;
  const flashPrice = selectedProduct 
    ? selectedProduct.price * (1 - effectiveDiscount / 100) 
    : 0;

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setStep('configure');
  };

  const handleBack = () => {
    if (step === 'configure') {
      setStep('select');
      setSelectedProduct(null);
    } else if (step === 'confirm') {
      setStep('configure');
    }
  };

  const handleContinue = () => {
    if (step === 'configure') {
      setStep('confirm');
    }
  };

  const handleCreateFlashSale = async () => {
    if (!selectedProduct) return;

    await onCreateFlashSale({
      stream_id: streamId,
      product_id: selectedProduct.id,
      product_name: selectedProduct.name,
      product_image: selectedProduct.image,
      original_price: selectedProduct.price,
      discount_percent: effectiveDiscount,
      duration_minutes: durationMinutes,
      max_units: maxUnits ? parseInt(maxUnits) : undefined,
      seller_id: sellerId
    });

    // Reset and close
    setSelectedProduct(null);
    setDiscountPercent(20);
    setCustomDiscount('');
    setDurationMinutes(5);
    setMaxUnits('');
    setStep('select');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold">Vente Flash</h2>
              <p className="text-slate-400 text-sm">
                {step === 'select' && 'Sélectionnez un produit'}
                {step === 'configure' && 'Configurez la promotion'}
                {step === 'confirm' && 'Confirmez la vente flash'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {/* Step 1: Select Product */}
          {step === 'select' && (
            <div className="space-y-3">
              <p className="text-slate-300 text-sm mb-4">
                Choisissez le produit à mettre en promotion flash :
              </p>
              {products.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-slate-400">Aucun produit disponible</p>
                  <p className="text-slate-500 text-sm">Ajoutez des produits à votre live</p>
                </div>
              ) : (
                products.map((product) => (
                  <button
                    key={product.id}
                    onClick={() => handleSelectProduct(product)}
                    className="w-full flex items-center gap-3 p-3 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 hover:border-orange-500/50 transition-all text-left"
                  >
                    {product.image && (
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-14 h-14 rounded-lg object-cover flex-shrink-0"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-medium truncate">{product.name}</p>
                      <p className="text-orange-400 font-bold">{formatPrice(product.price)}</p>
                    </div>
                    <Zap className="w-5 h-5 text-slate-500" />
                  </button>
                ))
              )}
            </div>
          )}

          {/* Step 2: Configure */}
          {step === 'configure' && selectedProduct && (
            <div className="space-y-6">
              {/* Selected Product */}
              <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-xl">
                {selectedProduct.image && (
                  <img 
                    src={selectedProduct.image} 
                    alt={selectedProduct.name}
                    className="w-14 h-14 rounded-lg object-cover"
                  />
                )}
                <div className="flex-1">
                  <p className="text-white font-medium">{selectedProduct.name}</p>
                  <p className="text-slate-400">{formatPrice(selectedProduct.price)}</p>
                </div>
              </div>

              {/* Discount Selection */}
              <div>
                <label className="flex items-center gap-2 text-white font-medium mb-3">
                  <Percent className="w-4 h-4 text-orange-400" />
                  Réduction
                </label>
                <div className="grid grid-cols-4 gap-2 mb-3">
                  {DISCOUNT_OPTIONS.map((discount) => (
                    <button
                      key={discount}
                      onClick={() => {
                        setDiscountPercent(discount);
                        setCustomDiscount('');
                      }}
                      className={`py-2 px-3 rounded-lg font-bold text-sm transition-all ${
                        discountPercent === discount && !customDiscount
                          ? 'bg-orange-500 text-white'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      -{discount}%
                    </button>
                  ))}
                  <input
                    type="number"
                    placeholder="Autre"
                    value={customDiscount}
                    onChange={(e) => setCustomDiscount(e.target.value)}
                    min="1"
                    max="90"
                    className="py-2 px-3 rounded-lg bg-slate-800 text-white text-sm text-center focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
                
                {/* Price Preview */}
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-orange-500/10 to-red-500/10 rounded-xl border border-orange-500/30">
                  <div>
                    <p className="text-slate-400 text-sm">Prix flash</p>
                    <p className="text-2xl font-bold text-orange-400">{formatPrice(flashPrice)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-slate-500 text-sm line-through">{formatPrice(selectedProduct.price)}</p>
                    <p className="text-green-400 font-bold">-{effectiveDiscount}%</p>
                  </div>
                </div>
              </div>

              {/* Duration Selection */}
              <div>
                <label className="flex items-center gap-2 text-white font-medium mb-3">
                  <Clock className="w-4 h-4 text-blue-400" />
                  Durée de la promotion
                </label>
                <div className="flex gap-2">
                  {DURATION_OPTIONS.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setDurationMinutes(option.value)}
                      className={`flex-1 py-2 px-3 rounded-lg font-medium text-sm transition-all ${
                        durationMinutes === option.value
                          ? 'bg-blue-500 text-white'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Max Units (Optional) */}
              <div>
                <label className="flex items-center gap-2 text-white font-medium mb-3">
                  <Package className="w-4 h-4 text-purple-400" />
                  Quantité limitée (optionnel)
                </label>
                <input
                  type="number"
                  placeholder="Ex: 10 unités"
                  value={maxUnits}
                  onChange={(e) => setMaxUnits(e.target.value)}
                  min="1"
                  className="w-full py-3 px-4 rounded-xl bg-slate-800 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <p className="text-slate-500 text-xs mt-2">
                  Laissez vide pour une quantité illimitée
                </p>
              </div>
            </div>
          )}

          {/* Step 3: Confirm */}
          {step === 'confirm' && selectedProduct && (
            <div className="space-y-6">
              {/* Summary Card */}
              <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 rounded-2xl p-4 border border-orange-500/30">
                <div className="flex items-center gap-3 mb-4">
                  {selectedProduct.image && (
                    <img 
                      src={selectedProduct.image} 
                      alt={selectedProduct.name}
                      className="w-16 h-16 rounded-xl object-cover"
                    />
                  )}
                  <div className="flex-1">
                    <p className="text-white font-bold">{selectedProduct.name}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-2xl font-bold text-orange-400">{formatPrice(flashPrice)}</span>
                      <span className="text-slate-500 line-through text-sm">{formatPrice(selectedProduct.price)}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-black/30 rounded-xl p-3 text-center">
                    <TrendingDown className="w-5 h-5 text-green-400 mx-auto mb-1" />
                    <p className="text-green-400 font-bold text-lg">-{effectiveDiscount}%</p>
                    <p className="text-slate-400 text-xs">Réduction</p>
                  </div>
                  <div className="bg-black/30 rounded-xl p-3 text-center">
                    <Clock className="w-5 h-5 text-blue-400 mx-auto mb-1" />
                    <p className="text-blue-400 font-bold text-lg">{durationMinutes} min</p>
                    <p className="text-slate-400 text-xs">Durée</p>
                  </div>
                </div>

                {maxUnits && (
                  <div className="mt-3 bg-black/30 rounded-xl p-3 text-center">
                    <Package className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                    <p className="text-purple-400 font-bold">{maxUnits} unités max</p>
                  </div>
                )}
              </div>

              {/* Notification Info */}
              <div className="flex items-start gap-3 p-4 bg-blue-500/10 rounded-xl border border-blue-500/30">
                <Bell className="w-5 h-5 text-blue-400 mt-0.5" />
                <div>
                  <p className="text-blue-400 font-medium">Notifications automatiques</p>
                  <p className="text-slate-400 text-sm">
                    Vos abonnés recevront une notification push pour cette vente flash
                  </p>
                </div>
              </div>

              {/* Warning */}
              <div className="flex items-start gap-3 p-4 bg-yellow-500/10 rounded-xl border border-yellow-500/30">
                <AlertTriangle className="w-5 h-5 text-yellow-400 mt-0.5" />
                <div>
                  <p className="text-yellow-400 font-medium">Attention</p>
                  <p className="text-slate-400 text-sm">
                    La vente flash démarrera immédiatement et sera visible par tous les spectateurs
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-700 flex gap-3">
          {step !== 'select' && (
            <button
              onClick={handleBack}
              className="flex-1 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
            >
              Retour
            </button>
          )}
          
          {step === 'select' && (
            <button
              onClick={onClose}
              className="flex-1 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
            >
              Annuler
            </button>
          )}

          {step === 'configure' && (
            <button
              onClick={handleContinue}
              disabled={effectiveDiscount < 1 || effectiveDiscount > 90}
              className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Continuer
            </button>
          )}

          {step === 'confirm' && (
            <button
              onClick={handleCreateFlashSale}
              disabled={isLoading}
              className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Activation...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5" />
                  Lancer la Vente Flash
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default FlashSaleModal;
