import React from 'react';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StarRatingProps {
  rating: number;
  maxRating?: number;
  size?: 'sm' | 'md' | 'lg';
  showValue?: boolean;
  showCount?: boolean;
  count?: number;
  interactive?: boolean;
  onChange?: (rating: number) => void;
  className?: string;
}

export function StarRating({
  rating,
  maxRating = 5,
  size = 'md',
  showValue = false,
  showCount = false,
  count = 0,
  interactive = false,
  onChange,
  className
}: StarRatingProps) {
  const [hoverRating, setHoverRating] = React.useState(0);

  const sizeClasses = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-6 h-6'
  };

  const textSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };

  const handleClick = (index: number) => {
    if (interactive && onChange) {
      onChange(index);
    }
  };

  const handleMouseEnter = (index: number) => {
    if (interactive) {
      setHoverRating(index);
    }
  };

  const handleMouseLeave = () => {
    if (interactive) {
      setHoverRating(0);
    }
  };

  const displayRating = hoverRating || rating;

  return (
    <div className={cn('flex items-center gap-1', className)}>
      <div className="flex items-center">
        {Array.from({ length: maxRating }, (_, i) => {
          const index = i + 1;
          const isFilled = index <= displayRating;
          const isHalfFilled = !isFilled && index - 0.5 <= displayRating;

          return (
            <button
              key={i}
              type="button"
              onClick={() => handleClick(index)}
              onMouseEnter={() => handleMouseEnter(index)}
              onMouseLeave={handleMouseLeave}
              disabled={!interactive}
              className={cn(
                'relative transition-transform',
                interactive && 'cursor-pointer hover:scale-110',
                !interactive && 'cursor-default'
              )}
            >
              {/* Background star (empty) */}
              <Star
                className={cn(
                  sizeClasses[size],
                  'text-gray-300 dark:text-gray-600'
                )}
              />
              {/* Foreground star (filled) */}
              {(isFilled || isHalfFilled) && (
                <Star
                  className={cn(
                    sizeClasses[size],
                    'absolute top-0 left-0 text-yellow-400 fill-yellow-400',
                    isHalfFilled && 'clip-path-half'
                  )}
                  style={isHalfFilled ? { clipPath: 'inset(0 50% 0 0)' } : undefined}
                />
              )}
            </button>
          );
        })}
      </div>
      {showValue && (
        <span className={cn('font-medium text-gray-700 dark:text-gray-300', textSizeClasses[size])}>
          {rating.toFixed(1)}
        </span>
      )}
      {showCount && count > 0 && (
        <span className={cn('text-gray-500 dark:text-gray-400', textSizeClasses[size])}>
          ({count.toLocaleString()})
        </span>
      )}
    </div>
  );
}

// Compact version for product cards
interface CompactRatingProps {
  rating: number;
  count?: number;
  className?: string;
}

export function CompactRating({ rating, count, className }: CompactRatingProps) {
  if (rating === 0 && (!count || count === 0)) {
    return (
      <span className={cn('text-xs text-gray-400 dark:text-gray-500', className)}>
        No reviews yet
      </span>
    );
  }

  return (
    <div className={cn('flex items-center gap-1', className)}>
      <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
        {rating.toFixed(1)}
      </span>
      {count !== undefined && count > 0 && (
        <span className="text-xs text-gray-500 dark:text-gray-400">
          ({count})
        </span>
      )}
    </div>
  );
}

// Rating breakdown for product detail pages
interface RatingBreakdownProps {
  summary: {
    average_rating: number;
    total_reviews: number;
    rating_1_count: number;
    rating_2_count: number;
    rating_3_count: number;
    rating_4_count: number;
    rating_5_count: number;
  };
  onFilterClick?: (rating: number | null) => void;
  activeFilter?: number | null;
}

export function RatingBreakdown({ summary, onFilterClick, activeFilter }: RatingBreakdownProps) {
  const ratings = [
    { stars: 5, count: summary.rating_5_count },
    { stars: 4, count: summary.rating_4_count },
    { stars: 3, count: summary.rating_3_count },
    { stars: 2, count: summary.rating_2_count },
    { stars: 1, count: summary.rating_1_count },
  ];

  const maxCount = Math.max(...ratings.map(r => r.count), 1);

  return (
    <div className="space-y-4">
      {/* Overall rating */}
      <div className="text-center pb-4 border-b border-gray-200 dark:border-gray-700">
        <div className="text-5xl font-bold text-gray-900 dark:text-white">
          {summary.average_rating.toFixed(1)}
        </div>
        <StarRating rating={summary.average_rating} size="lg" className="justify-center mt-2" />
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          Based on {summary.total_reviews.toLocaleString()} review{summary.total_reviews !== 1 ? 's' : ''}
        </p>
      </div>

      {/* Rating bars */}
      <div className="space-y-2">
        {ratings.map(({ stars, count }) => {
          const percentage = summary.total_reviews > 0 ? (count / summary.total_reviews) * 100 : 0;
          const isActive = activeFilter === stars;

          return (
            <button
              key={stars}
              onClick={() => onFilterClick?.(isActive ? null : stars)}
              className={cn(
                'w-full flex items-center gap-2 p-1.5 rounded-lg transition-colors',
                onFilterClick && 'hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer',
                isActive && 'bg-purple-50 dark:bg-purple-900/20'
              )}
            >
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400 w-8">
                {stars}
              </span>
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <div className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div
                  className={cn(
                    'h-full rounded-full transition-all',
                    isActive ? 'bg-purple-500' : 'bg-yellow-400'
                  )}
                  style={{ width: `${percentage}%` }}
                />
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400 w-12 text-right">
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {activeFilter && (
        <button
          onClick={() => onFilterClick?.(null)}
          className="w-full text-sm text-purple-600 dark:text-purple-400 hover:underline"
        >
          Clear filter
        </button>
      )}
    </div>
  );
}
