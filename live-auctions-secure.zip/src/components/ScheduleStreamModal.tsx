import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Image, Tag, X, Upload, Sparkles, AlertCircle } from 'lucide-react';
import { useScheduledStreams, ScheduledStream } from '@/hooks/useScheduledStreams';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface ScheduleStreamModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (stream: ScheduledStream) => void;
  editStream?: ScheduledStream | null;
}

const CATEGORIES = [
  'Mode & Vêtements',
  'Beauté & Cosmétiques',
  'Électronique',
  'Maison & Déco',
  'Sport & Fitness',
  'Bijoux & Accessoires',
  'Art & Artisanat',
  'Alimentation',
  'Autre'
];

const DURATION_OPTIONS = [
  { value: 30, label: '30 minutes' },
  { value: 60, label: '1 heure' },
  { value: 90, label: '1h30' },
  { value: 120, label: '2 heures' },
  { value: 180, label: '3 heures' }
];

export function ScheduleStreamModal({ isOpen, onClose, onSuccess, editStream }: ScheduleStreamModalProps) {
  const { user } = useAuth();
  const { createScheduledStream, updateScheduledStream } = useScheduledStreams();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [title, setTitle] = useState(editStream?.title || '');
  const [description, setDescription] = useState(editStream?.description || '');
  const [scheduledDate, setScheduledDate] = useState(
    editStream ? new Date(editStream.scheduled_at).toISOString().split('T')[0] : ''
  );
  const [scheduledTime, setScheduledTime] = useState(
    editStream ? new Date(editStream.scheduled_at).toTimeString().slice(0, 5) : ''
  );
  const [duration, setDuration] = useState(editStream?.duration_minutes?.toString() || '60');
  const [category, setCategory] = useState(editStream?.category || '');
  const [tags, setTags] = useState<string[]>(editStream?.tags || []);
  const [tagInput, setTagInput] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState(editStream?.thumbnail_url || '');
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState(editStream?.thumbnail_url || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadingThumbnail, setUploadingThumbnail] = useState(false);

  const handleThumbnailSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Fichier trop volumineux",
          description: "La taille maximale est de 5 Mo",
          variant: "destructive"
        });
        return;
      }
      setThumbnailFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setThumbnailPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const uploadThumbnail = async (): Promise<string | null> => {
    if (!thumbnailFile || !user?.id) return thumbnailUrl || null;

    setUploadingThumbnail(true);
    try {
      const fileExt = thumbnailFile.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      
      const { data, error } = await supabase.storage
        .from('stream-recordings')
        .upload(`thumbnails/${fileName}`, thumbnailFile, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('stream-recordings')
        .getPublicUrl(`thumbnails/${fileName}`);

      return publicUrl;
    } catch (error: any) {
      console.error('Error uploading thumbnail:', error);
      toast({
        title: "Erreur d'upload",
        description: "Impossible de télécharger la miniature",
        variant: "destructive"
      });
      return null;
    } finally {
      setUploadingThumbnail(false);
    }
  };

  const handleAddTag = () => {
    const trimmedTag = tagInput.trim().toLowerCase();
    if (trimmedTag && !tags.includes(trimmedTag) && tags.length < 5) {
      setTags([...tags, trimmedTag]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddTag();
    }
  };

  const validateForm = () => {
    if (!title.trim()) {
      toast({ title: "Titre requis", description: "Veuillez entrer un titre pour votre live", variant: "destructive" });
      return false;
    }
    if (!scheduledDate || !scheduledTime) {
      toast({ title: "Date et heure requises", description: "Veuillez sélectionner une date et une heure", variant: "destructive" });
      return false;
    }
    
    const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
    const now = new Date();
    const minTime = new Date(now.getTime() + 30 * 60 * 1000); // 30 minutes from now
    
    if (scheduledDateTime < minTime) {
      toast({ 
        title: "Date invalide", 
        description: "Le live doit être programmé au moins 30 minutes à l'avance", 
        variant: "destructive" 
      });
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !user?.id) return;

    setIsSubmitting(true);
    try {
      // Upload thumbnail if selected
      const uploadedThumbnailUrl = await uploadThumbnail();
      
      const scheduledAt = new Date(`${scheduledDate}T${scheduledTime}`).toISOString();
      
      const streamData = {
        title: title.trim(),
        description: description.trim() || null,
        thumbnail_url: uploadedThumbnailUrl,
        scheduled_at: scheduledAt,
        duration_minutes: parseInt(duration),
        category: category || null,
        tags
      };

      let result;
      if (editStream) {
        result = await updateScheduledStream(editStream.id, user.id, streamData);
      } else {
        result = await createScheduledStream({
          seller_id: user.id,
          ...streamData
        });
      }

      if (result) {
        toast({
          title: editStream ? "Live mis à jour" : "Live programmé",
          description: editStream 
            ? "Votre live a été mis à jour avec succès"
            : "Votre live a été programmé avec succès"
        });
        onSuccess?.(result);
        onClose();
        resetForm();
      }
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setScheduledDate('');
    setScheduledTime('');
    setDuration('60');
    setCategory('');
    setTags([]);
    setTagInput('');
    setThumbnailUrl('');
    setThumbnailFile(null);
    setThumbnailPreview('');
  };

  // Get minimum date (today)
  const today = new Date().toISOString().split('T')[0];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Sparkles className="w-6 h-6 text-purple-500" />
            {editStream ? 'Modifier le live programmé' : 'Programmer un live'}
          </DialogTitle>
          <DialogDescription>
            Planifiez votre prochain live et permettez à vos abonnés de recevoir des rappels
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* Thumbnail Upload */}
          <div className="space-y-2">
            <Label>Miniature personnalisée</Label>
            <div 
              className="relative aspect-video rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-purple-500 transition-colors cursor-pointer overflow-hidden group"
              onClick={() => fileInputRef.current?.click()}
            >
              {thumbnailPreview ? (
                <>
                  <img 
                    src={thumbnailPreview} 
                    alt="Thumbnail preview" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="text-white font-medium">Changer l'image</span>
                  </div>
                </>
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground">
                  <Upload className="w-12 h-12 mb-2" />
                  <span className="font-medium">Cliquez pour ajouter une miniature</span>
                  <span className="text-sm">PNG, JPG jusqu'à 5 Mo</span>
                </div>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleThumbnailSelect}
              className="hidden"
            />
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Titre du live *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Nouvelle collection printemps 2026"
              maxLength={100}
            />
            <p className="text-xs text-muted-foreground text-right">{title.length}/100</p>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Décrivez ce que vous allez présenter pendant ce live..."
              rows={3}
              maxLength={500}
            />
            <p className="text-xs text-muted-foreground text-right">{description.length}/500</p>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date" className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Date *
              </Label>
              <Input
                id="date"
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                min={today}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="time" className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Heure *
              </Label>
              <Input
                id="time"
                type="time"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
              />
            </div>
          </div>

          {/* Duration & Category */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Durée estimée</Label>
              <Select value={duration} onValueChange={setDuration}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner la durée" />
                </SelectTrigger>
                <SelectContent>
                  {DURATION_OPTIONS.map(option => (
                    <SelectItem key={option.value} value={option.value.toString()}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Catégorie</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner une catégorie" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Tag className="w-4 h-4" />
              Tags (max 5)
            </Label>
            <div className="flex gap-2">
              <Input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ajouter un tag..."
                disabled={tags.length >= 5}
              />
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleAddTag}
                disabled={tags.length >= 5 || !tagInput.trim()}
              >
                Ajouter
              </Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {tags.map(tag => (
                  <Badge key={tag} variant="secondary" className="pl-2 pr-1 py-1">
                    #{tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-1 hover:bg-gray-300 dark:hover:bg-gray-600 rounded-full p-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Info Box */}
          <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4 flex gap-3">
            <AlertCircle className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-purple-800 dark:text-purple-200">
              <p className="font-medium mb-1">Conseils pour un live réussi</p>
              <ul className="list-disc list-inside space-y-1 text-purple-700 dark:text-purple-300">
                <li>Choisissez une miniature attrayante qui représente votre contenu</li>
                <li>Programmez votre live aux heures de forte audience (18h-21h)</li>
                <li>Partagez l'annonce sur vos réseaux sociaux</li>
              </ul>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || uploadingThumbnail}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {isSubmitting || uploadingThumbnail ? (
                <>
                  <span className="animate-spin mr-2">⏳</span>
                  {uploadingThumbnail ? 'Upload...' : 'Enregistrement...'}
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  {editStream ? 'Mettre à jour' : 'Programmer le live'}
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
