import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Search, Menu, X, User, Heart, LogOut, Settings, Store, ChevronDown, Shield, CheckCircle, Crown, MessageCircle, Bell, CalendarDays, Grid3X3, Users, ShoppingBag, Package } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useAppContext } from '@/contexts/AppContext';
import { useSubscription } from '@/hooks/useSubscription';
import { useMessaging } from '@/hooks/useMessaging';
import { NotificationBell } from './NotificationBell';

interface HeaderProps {
  onAuthClick: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenAdminPanel?: () => void;
  onOpenLive?: (streamId: string) => void;
  onOpenReplay?: (streamId: string) => void;
  onOpenMessaging?: () => void;
  onOpenNotificationCenter?: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  onAuthClick, 
  searchQuery, 
  onSearchChange,
  onOpenAdminPanel,
  onOpenLive,
  onOpenReplay,
  onOpenMessaging,
  onOpenNotificationCenter
}) => {
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const { wishlist } = useAppContext();
  const { plan, isSubscribed } = useSubscription();
  const { unreadCount: messageUnreadCount } = useMessaging();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    setIsUserMenuOpen(false);
    navigate('/');
  };

  const wishlistCount = wishlist.length;
  const isAdmin = profile?.user_type === 'admin';
  const isVerified = profile?.is_verified || false;
  const isSeller = profile?.user_type === 'seller';

  const getPlanGradient = (slug: string) => {
    switch (slug) {
      case 'starter':
        return 'from-blue-500 to-cyan-500';
      case 'pro':
        return 'from-orange-500 to-yellow-500';
      case 'enterprise':
        return 'from-purple-500 to-pink-500';
      default:
        return 'from-slate-500 to-slate-600';
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <div 
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => navigate('/')}
          >
            <img 
              src="https://d64gsuwffb70l.cloudfront.net/697513d586d0577d49bce648_1769467497622_9f8e043e.png" 
              alt="PITCH Logo" 
              className="h-10 sm:h-12 w-auto"
            />
          </div>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-xl mx-8">
            <div 
              className="relative w-full cursor-pointer"
              onClick={() => navigate('/products')}
            >
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <div className="w-full pl-12 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-slate-400 hover:border-orange-500/50 transition-all">
                Rechercher des produits, vendeurs...
              </div>
            </div>
          </div>



          {/* Right Actions */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Categories Link */}
            <Link 
              to="/categories"
              className="hidden sm:flex items-center gap-2 px-3 py-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              title="Catégories"
            >
              <Grid3X3 className="w-5 h-5" />
              <span className="hidden lg:inline text-sm">Catégories</span>
            </Link>

            {/* Sellers Link */}
            <Link 
              to="/sellers"
              className="hidden sm:flex items-center gap-2 px-3 py-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              title="Vendeurs"
            >
              <Users className="w-5 h-5" />
              <span className="hidden lg:inline text-sm">Vendeurs</span>
            </Link>

            {/* Live Schedule Link */}
            <Link 
              to="/live-schedule"
              className="hidden sm:flex items-center gap-2 px-3 py-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              title="Programme des Lives"
            >
              <CalendarDays className="w-5 h-5" />
              <span className="hidden lg:inline text-sm">Programme</span>
            </Link>

            {/* Admin Panel Button */}
            {isAdmin && onOpenAdminPanel && (
              <button 
                onClick={onOpenAdminPanel}
                className="hidden sm:flex items-center gap-2 px-4 py-2 bg-purple-500/20 text-purple-400 font-medium rounded-xl hover:bg-purple-500/30 transition-colors"
                title="Panneau Admin"
              >
                <Shield className="w-5 h-5" />
                <span className="hidden lg:inline">Admin</span>
              </button>
            )}

            {/* Notifications */}
            {user && (
              <NotificationBell 
                onOpenLive={onOpenLive}
                onOpenReplay={onOpenReplay}
                onOpenNotificationCenter={onOpenNotificationCenter}
              />
            )}

            {/* Messages */}
            {user && onOpenMessaging && (
              <button 
                onClick={onOpenMessaging}
                className="relative p-2.5 text-slate-400 hover:text-white transition-colors"
                title="Messages"
              >
                <MessageCircle className="w-6 h-6" />
                {messageUnreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {messageUnreadCount > 9 ? '9+' : messageUnreadCount}
                  </span>
                )}
              </button>
            )}

            {/* Orders - for logged in users */}
            {user && (
              <button 
                onClick={() => navigate('/orders')}
                className="relative p-2.5 text-slate-400 hover:text-white transition-colors"
                title="Mes Commandes"
              >
                <Package className="w-6 h-6" />
              </button>
            )}

            {/* Wishlist */}
            <button 
              onClick={() => user ? navigate('/wishlist') : onAuthClick()}
              className="relative p-2.5 text-slate-400 hover:text-white transition-colors"
              title="Mes Favoris"
            >
              <Heart className="w-6 h-6" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {wishlistCount > 9 ? '9+' : wishlistCount}
                </span>
              )}
            </button>

            {/* User Menu */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-2 rounded-xl hover:bg-slate-800 transition-colors"
                >
                  <div className="relative">
                    <div className="w-9 h-9 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-semibold text-sm">
                        {profile?.full_name?.charAt(0) || user.email?.charAt(0)?.toUpperCase()}
                      </span>
                    </div>
                    {isVerified && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center border-2 border-slate-900">
                        <CheckCircle className="w-2.5 h-2.5 text-white" />
                      </div>
                    )}
                  </div>
                  <ChevronDown className={`w-4 h-4 text-slate-400 hidden sm:block transition-transform ${isUserMenuOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown Menu */}
                {isUserMenuOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-40"
                      onClick={() => setIsUserMenuOpen(false)}
                    ></div>
                    <div className="absolute right-0 mt-2 w-72 bg-slate-800 border border-slate-700 rounded-2xl shadow-xl z-50 overflow-hidden">
                      {/* User Info */}
                      <div className="p-4 border-b border-slate-700">
                        <div className="flex items-center gap-2">
                          <p className="text-white font-semibold">{profile?.full_name || 'Utilisateur'}</p>
                          {isVerified && (
                            <div className="flex items-center gap-1 px-1.5 py-0.5 bg-blue-500/20 rounded-full">
                              <CheckCircle className="w-3 h-3 text-blue-400" />
                            </div>
                          )}
                        </div>
                        <p className="text-slate-400 text-sm truncate">{user.email}</p>
                        <div className="flex items-center gap-2 mt-2 flex-wrap">
                          {isSeller && (
                            <span className="inline-flex items-center gap-1 px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded-full">
                              <Store className="w-3 h-3" />
                              Vendeur
                            </span>
                          )}
                          {isAdmin && (
                            <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-500/20 text-purple-400 text-xs rounded-full">
                              <Shield className="w-3 h-3" />
                              Admin
                            </span>
                          )}
                          {isSeller && isSubscribed && plan && (
                            <span className={`inline-flex items-center gap-1 px-2 py-1 bg-gradient-to-r ${getPlanGradient(plan.slug)} text-white text-xs rounded-full`}>
                              <Crown className="w-3 h-3" />
                              {plan.name}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Menu Items */}
                      <div className="p-2">
                        <button
                          onClick={() => {
                            navigate('/profile');
                            setIsUserMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-slate-300 hover:bg-slate-700 rounded-xl transition-colors"
                        >
                          <User className="w-5 h-5" />
                          Mon Profil
                        </button>
                        <button
                          onClick={() => {
                            navigate('/orders');
                            setIsUserMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-slate-300 hover:bg-slate-700 rounded-xl transition-colors"
                        >
                          <Package className="w-5 h-5" />
                          Mes Commandes
                        </button>
                        <button
                          onClick={() => {
                            navigate('/wishlist');
                            setIsUserMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-slate-300 hover:bg-slate-700 rounded-xl transition-colors"
                        >
                          <Heart className="w-5 h-5" />
                          Mes Favoris
                          {wishlistCount > 0 && (
                            <span className="ml-auto text-xs bg-red-500 text-white px-2 py-0.5 rounded-full">
                              {wishlistCount}
                            </span>
                          )}
                        </button>
                        {isSeller && (
                          <button
                            onClick={() => {
                              navigate('/seller/orders');
                              setIsUserMenuOpen(false);
                            }}
                            className="w-full flex items-center gap-3 px-3 py-2.5 text-orange-400 hover:bg-orange-500/10 rounded-xl transition-colors"
                          >
                            <ShoppingBag className="w-5 h-5" />
                            Gestion des Commandes
                          </button>
                        )}
                        <button
                          onClick={() => {
                            navigate('/sellers');
                            setIsUserMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-slate-300 hover:bg-slate-700 rounded-xl transition-colors"
                        >
                          <Users className="w-5 h-5" />
                          Découvrir les Vendeurs
                        </button>
                        <button
                          onClick={() => {
                            navigate('/categories');
                            setIsUserMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-slate-300 hover:bg-slate-700 rounded-xl transition-colors"
                        >
                          <Grid3X3 className="w-5 h-5" />
                          Explorer les Catégories
                        </button>
                        <button
                          onClick={() => {
                            navigate('/live-schedule');
                            setIsUserMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-slate-300 hover:bg-slate-700 rounded-xl transition-colors"
                        >
                          <CalendarDays className="w-5 h-5" />
                          Programme des Lives
                        </button>
                        {onOpenNotificationCenter && (
                          <button
                            onClick={() => {
                              onOpenNotificationCenter();
                              setIsUserMenuOpen(false);
                            }}
                            className="w-full flex items-center gap-3 px-3 py-2.5 text-slate-300 hover:bg-slate-700 rounded-xl transition-colors"
                          >
                            <Bell className="w-5 h-5" />
                            Centre de Notifications
                          </button>
                        )}
                        {isAdmin && onOpenAdminPanel && (
                          <button
                            onClick={() => {
                              onOpenAdminPanel();
                              setIsUserMenuOpen(false);
                            }}
                            className="w-full flex items-center gap-3 px-3 py-2.5 text-purple-400 hover:bg-purple-500/10 rounded-xl transition-colors"
                          >
                            <Shield className="w-5 h-5" />
                            Panneau Admin
                          </button>
                        )}
                        <button
                          onClick={() => setIsUserMenuOpen(false)}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-slate-300 hover:bg-slate-700 rounded-xl transition-colors"
                        >
                          <Settings className="w-5 h-5" />
                          Paramètres
                        </button>
                      </div>

                      {/* Sign Out */}
                      <div className="p-2 border-t border-slate-700">
                        <button
                          onClick={handleSignOut}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-red-400 hover:bg-red-500/10 rounded-xl transition-colors"
                        >
                          <LogOut className="w-5 h-5" />
                          Déconnexion
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <button
                onClick={onAuthClick}
                className="hidden sm:flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all"
              >
                <User className="w-5 h-5" />
                Connexion
              </button>
            )}

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-slate-400 hover:text-white transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden pb-4">
          <div 
            className="relative cursor-pointer"
            onClick={() => navigate('/products')}
          >
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <div className="w-full pl-12 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-slate-400">
              Rechercher...
            </div>
          </div>
        </div>

      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 border-t border-slate-800">
          <div className="px-4 py-4 space-y-2">
            <a href="#lives" className="block px-4 py-3 text-slate-300 hover:bg-slate-800 rounded-xl transition-colors">
              Lives en cours
            </a>
            <a href="#products" className="block px-4 py-3 text-slate-300 hover:bg-slate-800 rounded-xl transition-colors">
              Produits
            </a>
            {user && (
              <Link 
                to="/orders" 
                className="flex items-center gap-2 px-4 py-3 text-slate-300 hover:bg-slate-800 rounded-xl transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Package className="w-5 h-5" />
                Mes Commandes
              </Link>
            )}
            {user && isSeller && (
              <Link 
                to="/seller/orders" 
                className="flex items-center gap-2 px-4 py-3 text-orange-400 hover:bg-orange-500/10 rounded-xl transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <ShoppingBag className="w-5 h-5" />
                Gestion des Commandes (Vendeur)
              </Link>
            )}
            <Link 
              to="/sellers" 
              className="flex items-center gap-2 px-4 py-3 text-slate-300 hover:bg-slate-800 rounded-xl transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <Users className="w-5 h-5" />
              Découvrir les Vendeurs
            </Link>
            <Link 
              to="/categories" 
              className="flex items-center gap-2 px-4 py-3 text-slate-300 hover:bg-slate-800 rounded-xl transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <Grid3X3 className="w-5 h-5" />
              Explorer les Catégories
            </Link>
            <Link 
              to="/live-schedule" 
              className="flex items-center gap-2 px-4 py-3 text-slate-300 hover:bg-slate-800 rounded-xl transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <CalendarDays className="w-5 h-5" />
              Programme des Lives
            </Link>
            <a href="#subscriptions" className="block px-4 py-3 text-slate-300 hover:bg-slate-800 rounded-xl transition-colors">
              Devenir Vendeur
            </a>
            {user && onOpenNotificationCenter && (
              <button
                onClick={() => {
                  onOpenNotificationCenter();
                  setIsMobileMenuOpen(false);
                }}
                className="w-full px-4 py-3 text-left text-slate-300 hover:bg-slate-800 rounded-xl transition-colors flex items-center gap-2"
              >
                <Bell className="w-5 h-5" />
                Centre de Notifications
              </button>
            )}
            {isAdmin && onOpenAdminPanel && (
              <button
                onClick={() => {
                  onOpenAdminPanel();
                  setIsMobileMenuOpen(false);
                }}
                className="w-full px-4 py-3 text-left text-purple-400 hover:bg-purple-500/10 rounded-xl transition-colors flex items-center gap-2"
              >
                <Shield className="w-5 h-5" />
                Panneau Admin
              </button>
            )}
            {!user && (
              <button
                onClick={() => {
                  onAuthClick();
                  setIsMobileMenuOpen(false);
                }}
                className="w-full px-4 py-3 bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold rounded-xl"
              >
                Connexion / Inscription
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
