import React, { useState, useEffect, useMemo } from 'react';
import {
  X, Calendar, Clock, Share2, Instagram, Youtube, Twitter, Facebook,
  ChevronLeft, ChevronRight, Check, AlertCircle, Sparkles, Hash,
  Plus, Trash2, Copy, CalendarDays, Timer, Layers, FileText, Send, Zap
} from 'lucide-react';
import { useSocialSharing, SocialAccount, SocialShare } from '@/hooks/useSocialSharing';
import { VideoClip } from '@/hooks/useClips';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/components/ui/use-toast';

interface BulkShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedClips: VideoClip[];
  onShareComplete?: () => void;
}

const STAGGER_OPTIONS = [
  { label: '15 minutes', value: 15 },
  { label: '30 minutes', value: 30 },
  { label: '1 hour', value: 60 },
  { label: '2 hours', value: 120 },
  { label: '4 hours', value: 240 },
  { label: '6 hours', value: 360 },
  { label: '12 hours', value: 720 },
  { label: '1 day', value: 1440 },
  { label: '2 days', value: 2880 },
];

const CAPTION_PLACEHOLDERS = [
  { placeholder: '{clip_title}', description: 'Title of the clip' },
  { placeholder: '{clip_number}', description: 'Position in queue (1, 2, 3...)' },
  { placeholder: '{total_clips}', description: 'Total number of clips' },
  { placeholder: '{date}', description: 'Scheduled date' },
  { placeholder: '{time}', description: 'Scheduled time' },
];

export const BulkShareModal: React.FC<BulkShareModalProps> = ({
  isOpen,
  onClose,
  selectedClips,
  onShareComplete
}) => {
  const {
    accounts,
    fetchAccounts,
    bulkShareClips,
    autoScheduleAtOptimalTimes,
    optimalSlots,
    getOptimalSlots,
    scheduledShares,
    fetchScheduledShares,
    cancelScheduledShare,
    loading,
    getSuggestedHashtags,
    suggestedHashtags
  } = useSocialSharing();

  const [activeTab, setActiveTab] = useState('setup');
  const [selectedPlatforms, setSelectedPlatforms] = useState<{ platform: string; social_account_id: string }[]>([]);
  const [captionTemplate, setCaptionTemplate] = useState('Check out {clip_title}! Part {clip_number} of {total_clips}');
  const [hashtags, setHashtags] = useState<string[]>(['#viral', '#trending']);
  const [hashtagInput, setHashtagInput] = useState('');
  const [staggerMinutes, setStaggerMinutes] = useState(60);
  const [startTime, setStartTime] = useState<string>('');
  const [shareResults, setShareResults] = useState<any>(null);
  const [currentWeekStart, setCurrentWeekStart] = useState<Date>(getWeekStart(new Date()));
  const [useOptimalTimes, setUseOptimalTimes] = useState(false);
  const [loadingOptimalSlots, setLoadingOptimalSlots] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchAccounts();
      fetchScheduledShares();
      const now = new Date();
      now.setHours(now.getHours() + 1, 0, 0, 0);
      setStartTime(now.toISOString().slice(0, 16));
    }
  }, [isOpen, fetchAccounts, fetchScheduledShares]);

  useEffect(() => {
    if (selectedPlatforms.length > 0) {
      getSuggestedHashtags(selectedPlatforms[0].platform);
      if (useOptimalTimes) {
        loadOptimalSlots(selectedPlatforms[0].platform);
      }
    }
  }, [selectedPlatforms, getSuggestedHashtags, useOptimalTimes]);

  const loadOptimalSlots = async (platform: string) => {
    setLoadingOptimalSlots(true);
    await getOptimalSlots(platform, selectedClips.length);
    setLoadingOptimalSlots(false);
  };

  function getWeekStart(date: Date): Date {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff));
  }


  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'instagram': return <Instagram className="w-5 h-5" />;
      case 'tiktok': return (
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
        </svg>
      );
      case 'twitter': return <Twitter className="w-5 h-5" />;
      case 'facebook': return <Facebook className="w-5 h-5" />;
      case 'youtube': return <Youtube className="w-5 h-5" />;
      default: return <Share2 className="w-5 h-5" />;
    }
  };

  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case 'instagram': return 'from-purple-500 via-pink-500 to-orange-500';
      case 'tiktok': return 'from-gray-900 to-gray-800';
      case 'twitter': return 'from-sky-500 to-sky-600';
      case 'facebook': return 'from-blue-600 to-blue-700';
      case 'youtube': return 'from-red-600 to-red-700';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const togglePlatform = (account: SocialAccount) => {
    const existing = selectedPlatforms.find(p => p.social_account_id === account.id);
    if (existing) {
      setSelectedPlatforms(prev => prev.filter(p => p.social_account_id !== account.id));
    } else {
      setSelectedPlatforms(prev => [...prev, { platform: account.platform, social_account_id: account.id }]);
    }
  };

  const addHashtag = () => {
    if (hashtagInput.trim()) {
      const tag = hashtagInput.startsWith('#') ? hashtagInput : `#${hashtagInput}`;
      if (!hashtags.includes(tag)) {
        setHashtags(prev => [...prev, tag]);
      }
      setHashtagInput('');
    }
  };

  const removeHashtag = (tag: string) => {
    setHashtags(prev => prev.filter(t => t !== tag));
  };

  const insertPlaceholder = (placeholder: string) => {
    setCaptionTemplate(prev => prev + ' ' + placeholder);
  };

  const handleBulkShare = async () => {
    if (selectedClips.length === 0) {
      toast({ title: 'No Clips Selected', description: 'Please select at least one clip.', variant: 'destructive' });
      return;
    }
    if (selectedPlatforms.length === 0) {
      toast({ title: 'No Platforms Selected', description: 'Please select at least one platform.', variant: 'destructive' });
      return;
    }

    try {
      const clips = selectedClips.map(c => ({ clip_id: c.id, title: c.title }));
      const result = await bulkShareClips(
        clips,
        selectedPlatforms,
        captionTemplate,
        hashtags,
        staggerMinutes,
        startTime || undefined
      );
      setShareResults(result);
      setActiveTab('results');
      onShareComplete?.();
    } catch (error) {
      console.error('Bulk share error:', error);
    }
  };

  // Generate preview of scheduled posts
  const scheduledPreview = useMemo(() => {
    if (!startTime || selectedClips.length === 0 || selectedPlatforms.length === 0) return [];
    
    const preview: { clip: VideoClip; platform: string; scheduledFor: Date; caption: string }[] = [];
    const start = new Date(startTime);
    
    selectedClips.forEach((clip, i) => {
      const scheduledFor = new Date(start.getTime() + (i * staggerMinutes * 60 * 1000));
      const caption = captionTemplate
        .replace(/{clip_title}/g, clip.title)
        .replace(/{clip_number}/g, String(i + 1))
        .replace(/{total_clips}/g, String(selectedClips.length))
        .replace(/{date}/g, scheduledFor.toLocaleDateString())
        .replace(/{time}/g, scheduledFor.toLocaleTimeString());
      
      selectedPlatforms.forEach(p => {
        preview.push({ clip, platform: p.platform, scheduledFor, caption });
      });
    });
    
    return preview.sort((a, b) => a.scheduledFor.getTime() - b.scheduledFor.getTime());
  }, [startTime, selectedClips, selectedPlatforms, staggerMinutes, captionTemplate]);

  // Calendar view data
  const weekDays = useMemo(() => {
    const days: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const day = new Date(currentWeekStart);
      day.setDate(day.getDate() + i);
      days.push(day);
    }
    return days;
  }, [currentWeekStart]);

  const getSharesForDay = (day: Date) => {
    const dayStart = new Date(day);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(day);
    dayEnd.setHours(23, 59, 59, 999);
    
    // Combine scheduled shares with preview
    const existing = scheduledShares.filter(s => {
      if (!s.scheduled_for) return false;
      const shareDate = new Date(s.scheduled_for);
      return shareDate >= dayStart && shareDate <= dayEnd;
    });
    
    const previewed = scheduledPreview.filter(p => {
      return p.scheduledFor >= dayStart && p.scheduledFor <= dayEnd;
    }).map(p => ({
      id: `preview-${p.clip.id}-${p.platform}-${p.scheduledFor.getTime()}`,
      platform: p.platform,
      scheduled_for: p.scheduledFor.toISOString(),
      caption: p.caption,
      isPreview: true
    }));
    
    return [...existing, ...previewed];
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    const newStart = new Date(currentWeekStart);
    newStart.setDate(newStart.getDate() + (direction === 'next' ? 7 : -7));
    setCurrentWeekStart(newStart);
  };

  const connectedAccounts = accounts.filter(a => a.is_connected);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-700 max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-purple-400" />
            Bulk Share {selectedClips.length} Clip{selectedClips.length !== 1 ? 's' : ''}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="bg-slate-800 border border-slate-700 shrink-0">
            <TabsTrigger value="setup" className="data-[state=active]:bg-purple-500">
              <FileText className="w-4 h-4 mr-2" />
              Setup
            </TabsTrigger>
            <TabsTrigger value="calendar" className="data-[state=active]:bg-purple-500">
              <CalendarDays className="w-4 h-4 mr-2" />
              Calendar
            </TabsTrigger>
            {shareResults && (
              <TabsTrigger value="results" className="data-[state=active]:bg-purple-500">
                <Check className="w-4 h-4 mr-2" />
                Results
              </TabsTrigger>
            )}
          </TabsList>

          <div className="flex-1 overflow-y-auto mt-4">
            <TabsContent value="setup" className="space-y-6 m-0">
              {/* Selected Clips Preview */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-purple-400" />
                  Selected Clips ({selectedClips.length})
                </h4>
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {selectedClips.map((clip, index) => (
                    <div
                      key={clip.id}
                      className="flex-shrink-0 w-24 bg-slate-700 rounded-lg overflow-hidden"
                    >
                      <div className="aspect-video bg-slate-800 relative">
                        {clip.thumbnail_url ? (
                          <img src={clip.thumbnail_url} alt={clip.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-500 text-xs">
                            #{index + 1}
                          </div>
                        )}
                        <div className="absolute top-1 left-1 w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                          {index + 1}
                        </div>
                      </div>
                      <p className="text-xs text-slate-300 p-1 truncate">{clip.title}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Platform Selection */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Share2 className="w-4 h-4 text-purple-400" />
                  Select Platforms
                </h4>
                {connectedAccounts.length === 0 ? (
                  <p className="text-slate-400 text-sm">No connected accounts. Please connect your social media accounts first.</p>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {connectedAccounts.map(account => {
                      const isSelected = selectedPlatforms.some(p => p.social_account_id === account.id);
                      return (
                        <button
                          key={account.id}
                          onClick={() => togglePlatform(account)}
                          className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                            isSelected
                              ? 'bg-purple-500/20 border-purple-500'
                              : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                          }`}
                        >
                          <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${getPlatformColor(account.platform)} flex items-center justify-center text-white`}>
                            {getPlatformIcon(account.platform)}
                          </div>
                          <div className="flex-1 text-left">
                            <p className="text-white text-sm font-medium capitalize">{account.platform}</p>
                            <p className="text-slate-400 text-xs">{account.account_handle || account.account_name}</p>
                          </div>
                          {isSelected && (
                            <Check className="w-5 h-5 text-purple-400" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Caption Template */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-purple-400" />
                  Caption Template
                </h4>
                <textarea
                  value={captionTemplate}
                  onChange={(e) => setCaptionTemplate(e.target.value)}
                  placeholder="Write your caption template..."
                  className="w-full h-24 px-4 py-3 bg-slate-800 border border-slate-600 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-500 resize-none"
                />
                <div className="mt-3">
                  <p className="text-slate-400 text-xs mb-2">Insert placeholders:</p>
                  <div className="flex flex-wrap gap-2">
                    {CAPTION_PLACEHOLDERS.map(({ placeholder, description }) => (
                      <button
                        key={placeholder}
                        onClick={() => insertPlaceholder(placeholder)}
                        className="px-2 py-1 bg-slate-700 hover:bg-slate-600 rounded text-xs text-purple-400 transition-colors"
                        title={description}
                      >
                        {placeholder}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Hashtags */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Hash className="w-4 h-4 text-purple-400" />
                  Hashtags
                </h4>
                <div className="flex gap-2 mb-3">
                  <input
                    type="text"
                    value={hashtagInput}
                    onChange={(e) => setHashtagInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addHashtag()}
                    placeholder="Add hashtag..."
                    className="flex-1 px-4 py-2 bg-slate-800 border border-slate-600 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
                  />
                  <Button onClick={addHashtag} className="bg-purple-500 hover:bg-purple-600">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mb-3">
                  {hashtags.map(tag => (
                    <span
                      key={tag}
                      className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-sm flex items-center gap-1"
                    >
                      {tag}
                      <button onClick={() => removeHashtag(tag)} className="hover:text-purple-300">
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
                {suggestedHashtags.length > 0 && (
                  <div>
                    <p className="text-slate-400 text-xs mb-2 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Suggested:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {suggestedHashtags.filter(t => !hashtags.includes(t)).slice(0, 8).map(tag => (
                        <button
                          key={tag}
                          onClick={() => setHashtags(prev => [...prev, tag])}
                          className="px-2 py-1 bg-slate-700 hover:bg-slate-600 rounded text-xs text-slate-300 transition-colors"
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Scheduling */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Timer className="w-4 h-4 text-purple-400" />
                  Scheduling
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Start Time</label>
                    <input
                      type="datetime-local"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Post Interval</label>
                    <select
                      value={staggerMinutes}
                      onChange={(e) => setStaggerMinutes(Number(e.target.value))}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-purple-500"
                    >
                      {STAGGER_OPTIONS.map(opt => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  </div>
                </div>
                
                {/* Preview Timeline */}
                {scheduledPreview.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-slate-700">
                    <p className="text-slate-400 text-sm mb-3">Preview ({scheduledPreview.length} posts):</p>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {scheduledPreview.slice(0, 6).map((item, index) => (
                        <div key={index} className="flex items-center gap-3 text-sm">
                          <div className={`w-6 h-6 rounded-full bg-gradient-to-r ${getPlatformColor(item.platform)} flex items-center justify-center text-white`}>
                            {getPlatformIcon(item.platform)}
                          </div>
                          <span className="text-slate-300 truncate flex-1">{item.clip.title}</span>
                          <span className="text-slate-500 text-xs">
                            {item.scheduledFor.toLocaleDateString()} {item.scheduledFor.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      ))}
                      {scheduledPreview.length > 6 && (
                        <p className="text-slate-500 text-xs">+{scheduledPreview.length - 6} more posts...</p>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Share Button */}
              <Button
                onClick={handleBulkShare}
                disabled={loading || selectedClips.length === 0 || selectedPlatforms.length === 0}
                className="w-full bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600 py-6 text-lg"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Sharing...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Share {selectedClips.length * selectedPlatforms.length} Posts
                  </>
                )}
              </Button>
            </TabsContent>

            <TabsContent value="calendar" className="m-0">
              {/* Week Navigation */}
              <div className="flex items-center justify-between mb-4">
                <Button
                  variant="ghost"
                  onClick={() => navigateWeek('prev')}
                  className="text-slate-400 hover:text-white"
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <h4 className="text-white font-medium">
                  {currentWeekStart.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </h4>
                <Button
                  variant="ghost"
                  onClick={() => navigateWeek('next')}
                  className="text-slate-400 hover:text-white"
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="text-center text-slate-400 text-xs font-medium py-2">
                    {day}
                  </div>
                ))}
                {weekDays.map(day => {
                  const dayShares = getSharesForDay(day);
                  const isToday = day.toDateString() === new Date().toDateString();
                  
                  return (
                    <div
                      key={day.toISOString()}
                      className={`min-h-[120px] p-2 rounded-xl border ${
                        isToday
                          ? 'bg-purple-500/10 border-purple-500'
                          : 'bg-slate-800/50 border-slate-700'
                      }`}
                    >
                      <div className={`text-sm font-medium mb-2 ${isToday ? 'text-purple-400' : 'text-slate-300'}`}>
                        {day.getDate()}
                      </div>
                      <div className="space-y-1">
                        {dayShares.slice(0, 4).map((share: any, idx) => (
                          <div
                            key={share.id || idx}
                            className={`flex items-center gap-1 p-1 rounded text-xs ${
                              share.isPreview
                                ? 'bg-purple-500/20 border border-purple-500/30'
                                : 'bg-slate-700'
                            }`}
                          >
                            <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${getPlatformColor(share.platform)} flex items-center justify-center text-white`}>
                              {React.cloneElement(getPlatformIcon(share.platform) as React.ReactElement, { className: 'w-2.5 h-2.5' })}
                            </div>
                            <span className="text-slate-300 truncate flex-1">
                              {new Date(share.scheduled_for).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                            {share.isPreview && (
                              <span className="text-purple-400 text-[10px]">NEW</span>
                            )}
                          </div>
                        ))}
                        {dayShares.length > 4 && (
                          <p className="text-slate-500 text-[10px] text-center">+{dayShares.length - 4} more</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Legend */}
              <div className="flex items-center gap-4 mt-4 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-slate-700 rounded" />
                  <span>Existing scheduled</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-purple-500/20 border border-purple-500/30 rounded" />
                  <span>New (preview)</span>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="results" className="m-0">
              {shareResults && (
                <div className="space-y-4">
                  {/* Summary */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700 text-center">
                      <p className="text-3xl font-bold text-white">{shareResults.total_shares}</p>
                      <p className="text-slate-400 text-sm">Total Posts</p>
                    </div>
                    <div className="bg-green-500/10 rounded-xl p-4 border border-green-500/30 text-center">
                      <p className="text-3xl font-bold text-green-400">{shareResults.successful}</p>
                      <p className="text-slate-400 text-sm">Successful</p>
                    </div>
                    <div className="bg-red-500/10 rounded-xl p-4 border border-red-500/30 text-center">
                      <p className="text-3xl font-bold text-red-400">{shareResults.failed}</p>
                      <p className="text-slate-400 text-sm">Failed</p>
                    </div>
                  </div>

                  {/* Results List */}
                  <div className="bg-slate-800/50 rounded-xl border border-slate-700 overflow-hidden">
                    <div className="max-h-64 overflow-y-auto">
                      {shareResults.results.map((result: any, index: number) => (
                        <div
                          key={index}
                          className="flex items-center gap-3 p-3 border-b border-slate-700 last:border-0"
                        >
                          <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${getPlatformColor(result.platform)} flex items-center justify-center text-white`}>
                            {getPlatformIcon(result.platform)}
                          </div>
                          <div className="flex-1">
                            <p className="text-white text-sm">
                              Clip to {result.platform}
                            </p>
                            {result.scheduled_for && (
                              <p className="text-slate-400 text-xs">
                                Scheduled for {new Date(result.scheduled_for).toLocaleString()}
                              </p>
                            )}
                          </div>
                          {result.success ? (
                            <Check className="w-5 h-5 text-green-400" />
                          ) : (
                            <AlertCircle className="w-5 h-5 text-red-400" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    onClick={onClose}
                    className="w-full bg-purple-500 hover:bg-purple-600"
                  >
                    Done
                  </Button>
                </div>
              )}
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default BulkShareModal;
