import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useSocialSharing, AudienceInsights, AIRecommendation } from '@/hooks/useSocialSharing';
import { 
  Users, 
  MapPin, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  BarChart3, 
  Target, 
  Lightbulb, 
  RefreshCw, 
  Sparkles,
  Globe,
  Heart,
  MessageCircle,
  Share2,
  Eye,
  ArrowUpRight,
  ArrowDownRight,
  Hash,
  Clock,
  Video,
  FileText,
  Zap
} from 'lucide-react';

export function AudienceInsightsDashboard() {
  const { audienceInsights, loadingInsights, fetchAudienceInsights, accounts } = useSocialSharing();
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');

  useEffect(() => {
    fetchAudienceInsights(selectedPlatform === 'all' ? undefined : selectedPlatform);
  }, [selectedPlatform]);

  const handleRefresh = () => {
    fetchAudienceInsights(selectedPlatform === 'all' ? undefined : selectedPlatform);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400';
      case 'low': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'down': return <TrendingDown className="h-4 w-4 text-red-500" />;
      default: return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  const getGenderColor = (type: string) => {
    switch (type) {
      case 'Female': return 'bg-pink-500';
      case 'Male': return 'bg-blue-500';
      default: return 'bg-purple-500';
    }
  };

  if (loadingInsights) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Analyzing your audience data...</p>
          <p className="text-sm text-muted-foreground mt-2">This may take a moment</p>
        </div>
      </div>
    );
  }

  if (!audienceInsights) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-center">
        <Users className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">No Audience Data Available</h3>
        <p className="text-muted-foreground mb-4">Connect your social accounts and share content to start gathering audience insights.</p>
        <Button onClick={handleRefresh}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Analyze Audience
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" />
            Audience Insights
          </h2>
          <p className="text-muted-foreground">AI-powered analysis of your followers and engagement patterns</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Platforms" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Platforms</SelectItem>
              {accounts.filter(a => a.is_connected).map(account => (
                <SelectItem key={account.id} value={account.platform}>
                  {account.platform.charAt(0).toUpperCase() + account.platform.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={handleRefresh} disabled={loadingInsights}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loadingInsights ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs defaultValue="demographics" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="demographics" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Demographics</span>
          </TabsTrigger>
          <TabsTrigger value="segments" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            <span className="hidden sm:inline">Segments</span>
          </TabsTrigger>
          <TabsTrigger value="content" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Content</span>
          </TabsTrigger>
          <TabsTrigger value="growth" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            <span className="hidden sm:inline">Growth</span>
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center gap-2">
            <Lightbulb className="h-4 w-4" />
            <span className="hidden sm:inline">AI Tips</span>
          </TabsTrigger>
        </TabsList>

        {/* Demographics Tab */}
        <TabsContent value="demographics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Age Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Age Distribution
                </CardTitle>
                <CardDescription>Breakdown of your audience by age group</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {audienceInsights.demographics.age_groups.map((group, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">{group.range}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">{group.percentage}%</span>
                        <Badge variant="outline" className="text-xs">
                          {group.engagement_index > 1 ? '+' : ''}{((group.engagement_index - 1) * 100).toFixed(0)}% eng
                        </Badge>
                      </div>
                    </div>
                    <Progress value={group.percentage} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Gender Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  Gender Distribution
                </CardTitle>
                <CardDescription>Your audience gender breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center mb-6">
                  <div className="relative w-40 h-40">
                    {/* Pie chart visualization */}
                    <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                      {audienceInsights.demographics.gender.reduce((acc, segment, index) => {
                        const startAngle = acc.offset;
                        const angle = (segment.percentage / 100) * 360;
                        const endAngle = startAngle + angle;
                        
                        const largeArc = angle > 180 ? 1 : 0;
                        const startX = 50 + 40 * Math.cos((startAngle * Math.PI) / 180);
                        const startY = 50 + 40 * Math.sin((startAngle * Math.PI) / 180);
                        const endX = 50 + 40 * Math.cos((endAngle * Math.PI) / 180);
                        const endY = 50 + 40 * Math.sin((endAngle * Math.PI) / 180);
                        
                        const colors = ['#ec4899', '#3b82f6', '#a855f7'];
                        
                        acc.paths.push(
                          <path
                            key={index}
                            d={`M 50 50 L ${startX} ${startY} A 40 40 0 ${largeArc} 1 ${endX} ${endY} Z`}
                            fill={colors[index]}
                            className="transition-all hover:opacity-80"
                          />
                        );
                        acc.offset = endAngle;
                        return acc;
                      }, { paths: [] as React.ReactNode[], offset: 0 }).paths}
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <p className="text-2xl font-bold">{audienceInsights.demographics.gender[0]?.percentage}%</p>
                        <p className="text-xs text-muted-foreground">Female</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  {audienceInsights.demographics.gender.map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${getGenderColor(item.type)}`} />
                        <span className="text-sm">{item.type}</span>
                      </div>
                      <span className="font-medium">{item.percentage}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Top Locations */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Top Locations
                </CardTitle>
                <CardDescription>Where your audience is located</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {audienceInsights.demographics.top_locations.map((location, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium">{location.location}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {location.city}
                        </p>
                      </div>
                    </div>
                    <span className="font-bold text-primary">{location.percentage}%</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Engagement Segments Tab */}
        <TabsContent value="segments" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {audienceInsights.engagement_segments.map((segment, index) => (
              <Card key={index} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{segment.segment_name}</CardTitle>
                    <Badge variant="secondary" className="text-lg font-bold">
                      {segment.percentage}%
                    </Badge>
                  </div>
                  <CardDescription>
                    Avg. engagement rate: <span className="font-semibold text-primary">{segment.avg_engagement_rate}%</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm font-medium mb-2">Characteristics:</p>
                    <div className="flex flex-wrap gap-2">
                      {segment.characteristics.map((char, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {char}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                    <p className="text-sm font-medium flex items-center gap-2 mb-1">
                      <Lightbulb className="h-4 w-4 text-primary" />
                      Recommended Content
                    </p>
                    <p className="text-sm text-muted-foreground">{segment.recommended_content}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Content Preferences Tab */}
        <TabsContent value="content" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Performing Content Types */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Top Performing Content
                </CardTitle>
                <CardDescription>Content types ranked by engagement</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {audienceInsights.content_preferences.top_performing_types.map((type, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        index === 0 ? 'bg-yellow-100 text-yellow-600' :
                        index === 1 ? 'bg-gray-100 text-gray-600' :
                        index === 2 ? 'bg-orange-100 text-orange-600' :
                        'bg-muted text-muted-foreground'
                      }`}>
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium">{type.type}</p>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            {(type.avg_views / 1000).toFixed(1)}K views
                          </span>
                          <span className="flex items-center gap-1">
                            <Heart className="h-3 w-3" />
                            {type.avg_engagement}% eng
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {getTrendIcon(type.trend)}
                      <span className="text-xs capitalize">{type.trend}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Optimal Content Length & Hashtags */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Optimal Content Length
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <Video className="h-6 w-6 mx-auto mb-2 text-primary" />
                    <p className="text-sm font-medium">Video</p>
                    <p className="text-lg font-bold">{audienceInsights.content_preferences.optimal_content_length.video}</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <FileText className="h-6 w-6 mx-auto mb-2 text-primary" />
                    <p className="text-sm font-medium">Caption</p>
                    <p className="text-lg font-bold">{audienceInsights.content_preferences.optimal_content_length.caption}</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <Hash className="h-6 w-6 mx-auto mb-2 text-primary" />
                    <p className="text-sm font-medium">Hashtags</p>
                    <p className="text-lg font-bold">{audienceInsights.content_preferences.optimal_content_length.hashtags}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Hash className="h-5 w-5" />
                    Hashtag Performance
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {audienceInsights.content_preferences.hashtag_performance.map((hashtag, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                      <span className="font-mono text-sm font-medium">{hashtag.hashtag}</span>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <ArrowUpRight className="h-3 w-3" />
                        {hashtag.reach_multiplier}x reach
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Trending Topics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {audienceInsights.content_preferences.trending_topics.map((topic, index) => (
                      <Badge key={index} variant="outline" className="capitalize">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Growth Trends Tab */}
        <TabsContent value="growth" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border-green-200 dark:border-green-800">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Growth Rate</p>
                    <p className="text-3xl font-bold text-green-600">+{audienceInsights.growth_trends.growth_rate_percentage}%</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">Monthly growth rate</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border-blue-200 dark:border-blue-800">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Projected Growth</p>
                    <p className="text-3xl font-bold text-blue-600">+{audienceInsights.growth_trends.projected_monthly_growth.toLocaleString()}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">New followers this month</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-purple-200 dark:border-purple-800">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Current Engagement</p>
                    <p className="text-3xl font-bold text-purple-600">{audienceInsights.growth_trends.engagement_trend[audienceInsights.growth_trends.engagement_trend.length - 1]?.rate}%</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center">
                    <Heart className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">Average engagement rate</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Follower Growth Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Follower Growth</CardTitle>
                <CardDescription>Weekly follower count over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-end justify-between gap-2">
                  {audienceInsights.growth_trends.follower_growth.map((point, index) => {
                    const maxFollowers = Math.max(...audienceInsights.growth_trends.follower_growth.map(p => p.followers));
                    const minFollowers = Math.min(...audienceInsights.growth_trends.follower_growth.map(p => p.followers));
                    const range = maxFollowers - minFollowers || 1;
                    const height = ((point.followers - minFollowers) / range) * 80 + 20;
                    
                    return (
                      <div key={index} className="flex-1 flex flex-col items-center gap-2">
                        <div className="relative w-full flex flex-col items-center">
                          {point.change > 0 && (
                            <span className="text-xs text-green-600 font-medium mb-1">+{point.change}</span>
                          )}
                          <div 
                            className="w-full bg-gradient-to-t from-primary to-primary/60 rounded-t-lg transition-all hover:opacity-80"
                            style={{ height: `${height}%`, minHeight: '40px' }}
                          />
                        </div>
                        <div className="text-center">
                          <p className="text-xs font-medium">{(point.followers / 1000).toFixed(1)}K</p>
                          <p className="text-xs text-muted-foreground">{point.period}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Growth Drivers */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Best Growth Drivers
                </CardTitle>
                <CardDescription>Key factors contributing to your growth</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {audienceInsights.growth_trends.best_growth_drivers.map((driver, index) => (
                  <div key={index} className="flex items-center gap-4 p-4 rounded-lg border bg-muted/30">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                      {index + 1}
                    </div>
                    <p className="font-medium">{driver}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* AI Recommendations Tab */}
        <TabsContent value="recommendations" className="space-y-6">
          <div className="grid grid-cols-1 gap-4">
            {audienceInsights.ai_recommendations.map((rec, index) => (
              <Card key={index} className="overflow-hidden">
                <div className={`h-1 ${
                  rec.priority === 'high' ? 'bg-red-500' :
                  rec.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                }`} />
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <Badge className={getPriorityColor(rec.priority)}>
                          {rec.priority.charAt(0).toUpperCase() + rec.priority.slice(1)} Priority
                        </Badge>
                        <Badge variant="outline">{rec.category}</Badge>
                      </div>
                      <p className="text-base leading-relaxed">{rec.recommendation}</p>
                    </div>
                    <div className="flex-shrink-0 p-4 rounded-lg bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 text-center min-w-[140px]">
                      <p className="text-xs text-muted-foreground mb-1">Expected Impact</p>
                      <p className="text-lg font-bold text-green-600">{rec.expected_impact}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default AudienceInsightsDashboard;
