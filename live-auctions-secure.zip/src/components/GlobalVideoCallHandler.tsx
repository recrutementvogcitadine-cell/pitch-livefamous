import React, { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { IncomingCallNotification } from './VideoCallModal';
import { VideoCallModal } from './VideoCallModal';

interface VideoCall {
  id: string;
  conversation_id: string;
  caller_id: string;
  callee_id: string;
  status: string;
  caller_name?: string;
  caller_avatar?: string;
}

// STUN servers for NAT traversal
const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
];

interface GlobalVideoCallHandlerProps {
  onOpenMessaging?: () => void;
}

export function GlobalVideoCallHandler({ onOpenMessaging }: GlobalVideoCallHandlerProps) {
  const { user } = useAuth();
  const [incomingCall, setIncomingCall] = useState<VideoCall | null>(null);
  const [activeCall, setActiveCall] = useState<VideoCall | null>(null);
  const [callStatus, setCallStatus] = useState<'idle' | 'calling' | 'ringing' | 'connected' | 'ended'>('idle');
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const signalingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const pendingCandidatesRef = useRef<RTCIceCandidate[]>([]);

  // Check for incoming calls
  useEffect(() => {
    if (!user?.id) return;

    const checkIncomingCalls = async () => {
      // Don't check if already in a call
      if (callStatus !== 'idle') return;

      try {
        const { data } = await supabase.functions.invoke('manage-video-calls', {
          body: {
            action: 'get_incoming_calls',
            user_id: user.id
          }
        });

        if (data?.success && data.calls && data.calls.length > 0) {
          setIncomingCall(data.calls[0]);
        }
      } catch (err) {
        console.error('Failed to check incoming calls:', err);
      }
    };

    const interval = setInterval(checkIncomingCalls, 2000);
    checkIncomingCalls(); // Initial check

    return () => clearInterval(interval);
  }, [user?.id, callStatus]);

  // Initialize media stream
  const initializeMedia = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      setLocalStream(stream);
      return stream;
    } catch (err: any) {
      console.error('Failed to get media:', err);
      setError('Impossible d\'accéder à la caméra ou au microphone');
      return null;
    }
  }, []);

  // Send signaling data
  const sendSignal = async (callId: string, signalType: string, signalData: any) => {
    if (!user?.id) return;

    try {
      await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'send_signal',
          call_id: callId,
          sender_id: user.id,
          signal_type: signalType,
          signal_data: signalData
        }
      });
    } catch (err) {
      console.error('Failed to send signal:', err);
    }
  };

  // Create peer connection
  const createPeerConnection = useCallback((stream: MediaStream, call: VideoCall) => {
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    // Add local tracks
    stream.getTracks().forEach(track => {
      pc.addTrack(track, stream);
    });

    // Handle remote stream
    pc.ontrack = (event) => {
      const [remoteStream] = event.streams;
      setRemoteStream(remoteStream);
    };

    // Handle ICE candidates
    pc.onicecandidate = async (event) => {
      if (event.candidate) {
        await sendSignal(call.id, 'ice_candidate', event.candidate.toJSON());
      }
    };

    pc.oniceconnectionstatechange = () => {
      console.log('ICE connection state:', pc.iceConnectionState);
      if (pc.iceConnectionState === 'disconnected' || pc.iceConnectionState === 'failed') {
        setError('Connexion perdue');
      }
    };

    peerConnectionRef.current = pc;
    return pc;
  }, [user?.id]);

  // Poll for signaling data
  const pollSignals = useCallback(async (callId: string) => {
    if (!user?.id) return;

    try {
      const { data } = await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'get_signals',
          call_id: callId,
          user_id: user.id
        }
      });

      if (data?.success && data.signals) {
        for (const signal of data.signals) {
          await handleSignal(signal, callId);
        }
      }
    } catch (err) {
      console.error('Failed to poll signals:', err);
    }
  }, [user?.id]);

  // Handle incoming signal
  const handleSignal = async (signal: any, callId: string) => {
    const pc = peerConnectionRef.current;
    if (!pc) return;

    try {
      if (signal.signal_type === 'offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.signal_data));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await sendSignal(callId, 'answer', answer);
        
        // Process pending candidates
        for (const candidate of pendingCandidatesRef.current) {
          await pc.addIceCandidate(candidate);
        }
        pendingCandidatesRef.current = [];
      } else if (signal.signal_type === 'answer') {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.signal_data));
        
        // Process pending candidates
        for (const candidate of pendingCandidatesRef.current) {
          await pc.addIceCandidate(candidate);
        }
        pendingCandidatesRef.current = [];
      } else if (signal.signal_type === 'ice_candidate') {
        const candidate = new RTCIceCandidate(signal.signal_data);
        if (pc.remoteDescription) {
          await pc.addIceCandidate(candidate);
        } else {
          pendingCandidatesRef.current.push(candidate);
        }
      }
    } catch (err) {
      console.error('Failed to handle signal:', err);
    }
  };

  // Answer incoming call
  const answerCall = useCallback(async () => {
    if (!user?.id || !incomingCall) return;

    setCallStatus('connected');
    setError(null);
    setActiveCall(incomingCall);
    setIncomingCall(null);

    try {
      // Initialize media
      const stream = await initializeMedia();
      if (!stream) return;

      // Accept call
      const { data } = await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'answer_call',
          call_id: incomingCall.id,
          accepted: true
        }
      });

      if (!data?.success) {
        throw new Error('Échec de l\'acceptation de l\'appel');
      }

      // Create peer connection
      createPeerConnection(stream, incomingCall);

      // Start polling for signals
      signalingIntervalRef.current = setInterval(() => {
        pollSignals(incomingCall.id);
      }, 1000);

      // Start duration timer
      durationIntervalRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);

    } catch (err: any) {
      console.error('Failed to answer call:', err);
      setError(err.message);
      setCallStatus('idle');
      cleanup();
    }
  }, [user?.id, incomingCall, initializeMedia, createPeerConnection, pollSignals]);

  // Reject incoming call
  const rejectCall = useCallback(async () => {
    if (!incomingCall) return;

    try {
      await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'answer_call',
          call_id: incomingCall.id,
          accepted: false
        }
      });
      setIncomingCall(null);
    } catch (err) {
      console.error('Failed to reject call:', err);
    }
  }, [incomingCall]);

  // End call
  const endCall = useCallback(async () => {
    if (activeCall) {
      try {
        await supabase.functions.invoke('manage-video-calls', {
          body: {
            action: 'end_call',
            call_id: activeCall.id
          }
        });
      } catch (err) {
        console.error('Failed to end call:', err);
      }
    }

    cleanup();
    setCallStatus('ended');
    setTimeout(() => setCallStatus('idle'), 2000);
  }, [activeCall]);

  // Cleanup resources
  const cleanup = useCallback(() => {
    // Stop intervals
    if (signalingIntervalRef.current) {
      clearInterval(signalingIntervalRef.current);
      signalingIntervalRef.current = null;
    }
    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
      durationIntervalRef.current = null;
    }

    // Close peer connection
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    // Stop local stream
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }

    setLocalStream(null);
    setRemoteStream(null);
    setActiveCall(null);
    setCallDuration(0);
    setIsMuted(false);
    setIsVideoOff(false);
    pendingCandidatesRef.current = [];
  }, [localStream]);

  // Toggle mute
  const toggleMute = useCallback(() => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    }
  }, [localStream]);

  // Toggle video
  const toggleVideo = useCallback(() => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoOff(!videoTrack.enabled);
      }
    }
  }, [localStream]);

  // Format call duration
  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cleanup();
    };
  }, []);

  const isInCall = callStatus !== 'idle' && callStatus !== 'ended';

  return (
    <>
      {/* Incoming Call Notification */}
      {incomingCall && callStatus === 'idle' && (
        <IncomingCallNotification
          callerName={incomingCall.caller_name || 'Utilisateur'}
          callerAvatar={incomingCall.caller_avatar}
          onAccept={answerCall}
          onReject={rejectCall}
        />
      )}

      {/* Video Call Modal */}
      {isInCall && activeCall && (
        <VideoCallModal
          isOpen={true}
          callStatus={callStatus}
          localStream={localStream}
          remoteStream={remoteStream}
          isMuted={isMuted}
          isVideoOff={isVideoOff}
          callDuration={callDuration}
          otherUserName={activeCall.caller_name || 'Utilisateur'}
          otherUserAvatar={activeCall.caller_avatar}
          error={error}
          onToggleMute={toggleMute}
          onToggleVideo={toggleVideo}
          onEndCall={endCall}
          formatDuration={formatDuration}
        />
      )}
    </>
  );
}

export default GlobalVideoCallHandler;
