import React, { useState, useEffect } from 'react';
import {
  Clock, TrendingUp, Sparkles, Calendar, Zap, Info, RefreshCw,
  CheckCircle, AlertCircle, Instagram, Twitter, Facebook, Youtube,
  ChevronDown, ChevronUp, Target, BarChart3, Lightbulb
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useSocialSharing, OptimalTimesAnalysis, OptimalSlot, HeatmapData } from '@/hooks/useSocialSharing';

interface OptimalTimesAnalyzerProps {
  onSelectSlot?: (slot: OptimalSlot) => void;
  selectedPlatform?: string;
}

const OptimalTimesAnalyzer: React.FC<OptimalTimesAnalyzerProps> = ({
  onSelectSlot,
  selectedPlatform
}) => {
  const {
    accounts,
    optimalTimesAnalysis,
    optimalSlots,
    analyzingTimes,
    analyzeOptimalTimes,
    getOptimalSlots
  } = useSocialSharing();

  const [platform, setPlatform] = useState(selectedPlatform || 'instagram');
  const [showInsights, setShowInsights] = useState(true);
  const [showSlots, setShowSlots] = useState(true);

  useEffect(() => {
    if (selectedPlatform) {
      setPlatform(selectedPlatform);
    }
  }, [selectedPlatform]);

  useEffect(() => {
    analyzeOptimalTimes(platform);
    getOptimalSlots(platform, 7);
  }, [platform]);

  const getPlatformIcon = (p: string) => {
    switch (p) {
      case 'instagram': return <Instagram className="w-4 h-4" />;
      case 'tiktok': return (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
        </svg>
      );
      case 'twitter': return <Twitter className="w-4 h-4" />;
      case 'facebook': return <Facebook className="w-4 h-4" />;
      case 'youtube': return <Youtube className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getPlatformColor = (p: string) => {
    switch (p) {
      case 'instagram': return 'from-purple-500 via-pink-500 to-orange-500';
      case 'tiktok': return 'from-gray-900 to-gray-700';
      case 'twitter': return 'from-sky-500 to-sky-600';
      case 'facebook': return 'from-blue-600 to-blue-700';
      case 'youtube': return 'from-red-600 to-red-700';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const fullDayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const getHeatmapColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-green-400';
    if (score >= 40) return 'bg-yellow-400';
    if (score >= 20) return 'bg-orange-400';
    return 'bg-red-400';
  };

  const getHeatmapOpacity = (score: number) => {
    return Math.max(0.2, score / 100);
  };

  const formatHour = (hour: number) => {
    if (hour === 0) return '12am';
    if (hour === 12) return '12pm';
    if (hour < 12) return `${hour}am`;
    return `${hour - 12}pm`;
  };

  const recommendation = optimalTimesAnalysis?.recommendations?.find(r => r.platform === platform);
  const heatmapData = optimalTimesAnalysis?.heatmap_data?.[platform];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-white font-bold text-lg">AI Optimal Posting Times</h3>
            <p className="text-slate-400 text-sm">
              {optimalTimesAnalysis?.data_points || 0} data points analyzed
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Select value={platform} onValueChange={setPlatform}>
            <SelectTrigger className="w-40 bg-slate-800 border-slate-700 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700">
              {['instagram', 'tiktok', 'twitter', 'facebook', 'youtube'].map(p => (
                <SelectItem key={p} value={p} className="text-white hover:bg-slate-700">
                  <div className="flex items-center gap-2">
                    {getPlatformIcon(p)}
                    <span className="capitalize">{p}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            onClick={() => {
              analyzeOptimalTimes(platform);
              getOptimalSlots(platform, 7);
            }}
            disabled={analyzingTimes}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:text-white"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${analyzingTimes ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {analyzingTimes ? (
        <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
          <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-white font-medium">Analyzing your engagement data...</p>
          <p className="text-slate-400 text-sm mt-2">AI is finding the best times to post</p>
        </div>
      ) : (
        <>
          {/* Recommendation Card */}
          {recommendation && (
            <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 border-slate-700 overflow-hidden">
              <div className={`h-1 bg-gradient-to-r ${getPlatformColor(platform)}`} />
              <CardHeader className="pb-2">
                <CardTitle className="text-white flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-r ${getPlatformColor(platform)} flex items-center justify-center text-white`}>
                    {getPlatformIcon(platform)}
                  </div>
                  <span className="capitalize">{platform} Recommendations</span>
                  <span className="ml-auto text-sm font-normal text-slate-400 flex items-center gap-1">
                    <Target className="w-4 h-4" />
                    {recommendation.confidence_score}% confidence
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Best Days */}
                  <div className="bg-slate-900/50 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-slate-400 text-sm mb-2">
                      <Calendar className="w-4 h-4" />
                      Best Days
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {recommendation.best_days.map(day => (
                        <span key={day} className="px-3 py-1 bg-green-500/20 text-green-400 text-sm rounded-full font-medium">
                          {day}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Best Hours */}
                  <div className="bg-slate-900/50 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-slate-400 text-sm mb-2">
                      <Clock className="w-4 h-4" />
                      Best Hours
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {recommendation.best_hours.map(hour => (
                        <span key={hour} className="px-3 py-1 bg-blue-500/20 text-blue-400 text-sm rounded-full font-medium">
                          {formatHour(hour)}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Peak Window */}
                  <div className="bg-slate-900/50 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-slate-400 text-sm mb-2">
                      <Zap className="w-4 h-4" />
                      Peak Engagement
                    </div>
                    <p className="text-white font-semibold text-lg">{recommendation.peak_engagement_window}</p>
                  </div>
                </div>

                <div className="bg-slate-900/50 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-slate-400 text-sm mb-2">
                    <Lightbulb className="w-4 h-4" />
                    AI Analysis
                  </div>
                  <p className="text-slate-300">{recommendation.reasoning}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Heatmap */}
          {heatmapData && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-white flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-purple-400" />
                  Engagement Heatmap
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info className="w-4 h-4 text-slate-500" />
                      </TooltipTrigger>
                      <TooltipContent className="bg-slate-800 border-slate-700 text-white">
                        <p>Darker colors indicate higher engagement potential</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <div className="min-w-[600px]">
                    {/* Hour labels */}
                    <div className="flex mb-1">
                      <div className="w-12 flex-shrink-0" />
                      {[0, 3, 6, 9, 12, 15, 18, 21].map(hour => (
                        <div key={hour} className="flex-1 text-center text-xs text-slate-500">
                          {formatHour(hour)}
                        </div>
                      ))}
                    </div>

                    {/* Heatmap grid */}
                    {dayNames.map((day, dayIndex) => (
                      <div key={day} className="flex items-center mb-1">
                        <div className="w-12 flex-shrink-0 text-xs text-slate-400 font-medium">
                          {day}
                        </div>
                        <div className="flex-1 flex gap-0.5">
                          {Array.from({ length: 24 }, (_, hour) => {
                            const score = heatmapData[dayIndex]?.[hour] || 0;
                            return (
                              <TooltipProvider key={hour}>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <div
                                      className={`flex-1 h-6 rounded-sm cursor-pointer transition-transform hover:scale-110 ${getHeatmapColor(score)}`}
                                      style={{ opacity: getHeatmapOpacity(score) }}
                                    />
                                  </TooltipTrigger>
                                  <TooltipContent className="bg-slate-800 border-slate-700 text-white">
                                    <p className="font-medium">{fullDayNames[dayIndex]} at {formatHour(hour)}</p>
                                    <p className="text-sm text-slate-400">Engagement Score: {score}%</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            );
                          })}
                        </div>
                      </div>
                    ))}

                    {/* Legend */}
                    <div className="flex items-center justify-end gap-4 mt-4">
                      <span className="text-xs text-slate-500">Low</span>
                      <div className="flex gap-1">
                        {[20, 40, 60, 80, 100].map(score => (
                          <div
                            key={score}
                            className={`w-6 h-4 rounded-sm ${getHeatmapColor(score)}`}
                            style={{ opacity: getHeatmapOpacity(score) }}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-slate-500">High</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* AI Insights */}
          {optimalTimesAnalysis?.insights && optimalTimesAnalysis.insights.length > 0 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-2 cursor-pointer" onClick={() => setShowInsights(!showInsights)}>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-400" />
                  AI Insights
                  {showInsights ? <ChevronUp className="w-4 h-4 ml-auto" /> : <ChevronDown className="w-4 h-4 ml-auto" />}
                </CardTitle>
              </CardHeader>
              {showInsights && (
                <CardContent>
                  <div className="space-y-3">
                    {optimalTimesAnalysis.insights.map((insight, index) => (
                      <div key={index} className="flex items-start gap-3 p-3 bg-slate-900/50 rounded-xl">
                        <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-purple-400 text-xs font-bold">{index + 1}</span>
                        </div>
                        <p className="text-slate-300 text-sm">{insight}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              )}
            </Card>
          )}

          {/* Optimal Time Slots */}
          {optimalSlots.length > 0 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-2 cursor-pointer" onClick={() => setShowSlots(!showSlots)}>
                <CardTitle className="text-white flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-green-400" />
                  Recommended Time Slots
                  <span className="text-sm font-normal text-slate-400 ml-2">
                    Next {optimalSlots.length} optimal times
                  </span>
                  {showSlots ? <ChevronUp className="w-4 h-4 ml-auto" /> : <ChevronDown className="w-4 h-4 ml-auto" />}
                </CardTitle>
              </CardHeader>
              {showSlots && (
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {optimalSlots.map((slot, index) => {
                      const slotDate = new Date(slot.datetime);
                      return (
                        <div
                          key={index}
                          className={`p-4 rounded-xl border transition-all cursor-pointer hover:border-purple-500 ${
                            slot.is_optimal
                              ? 'bg-green-500/10 border-green-500/30'
                              : 'bg-slate-900/50 border-slate-700'
                          }`}
                          onClick={() => onSelectSlot?.(slot)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-white font-medium">
                              {slotDate.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                            </span>
                            {slot.is_optimal && (
                              <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded-full flex items-center gap-1">
                                <Zap className="w-3 h-3" />
                                Optimal
                              </span>
                            )}
                          </div>
                          <p className="text-2xl font-bold text-white mb-1">
                            {slotDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                          </p>
                          <div className="flex items-center gap-2 text-sm">
                            <TrendingUp className="w-4 h-4 text-green-400" />
                            <span className="text-slate-400">Expected engagement:</span>
                            <span className="text-green-400 font-medium">{slot.expected_engagement}%</span>
                          </div>
                          <p className="text-xs text-slate-500 mt-2 line-clamp-2">{slot.reasoning}</p>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              )}
            </Card>
          )}

          {/* Last analyzed */}
          {optimalTimesAnalysis?.analyzed_at && (
            <p className="text-center text-slate-500 text-sm">
              Last analyzed: {new Date(optimalTimesAnalysis.analyzed_at).toLocaleString()}
            </p>
          )}
        </>
      )}
    </div>
  );
};

export default OptimalTimesAnalyzer;
