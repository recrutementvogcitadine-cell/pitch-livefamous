import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X, Play, Pause, SkipBack, SkipForward, Scissors, Plus, Trash2,
  Save, Eye, EyeOff, Clock, List, MessageCircle, ChevronRight,
  Check, Edit2, GripVertical, Film, Upload, Image as ImageIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { useRecordings, Recording, Chapter, ChatMessage } from '@/hooks/useRecordings';

interface RecordingEditorProps {
  isOpen: boolean;
  onClose: () => void;
  recordingId: string;
  onSave?: () => void;
}

const RecordingEditor: React.FC<RecordingEditorProps> = ({
  isOpen,
  onClose,
  recordingId,
  onSave
}) => {
  const {
    fetchRecording,
    updateRecording,
    publishRecording,
    unpublishRecording,
    addChapter,
    updateChapter,
    deleteChapter,
    loading
  } = useRecordings();

  const [recording, setRecording] = useState<Recording | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(0);
  const [isTrimming, setIsTrimming] = useState(false);
  
  const [activeTab, setActiveTab] = useState<'chapters' | 'chat' | 'settings'>('chapters');
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [newChapterTitle, setNewChapterTitle] = useState('');
  const [newChapterDescription, setNewChapterDescription] = useState('');
  const [showAddChapter, setShowAddChapter] = useState(false);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [hasChanges, setHasChanges] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && recordingId) {
      loadRecording();
    }
  }, [isOpen, recordingId]);

  const loadRecording = async () => {
    const { recording: rec, chapters: chaps, messages: msgs } = await fetchRecording(recordingId);
    if (rec) {
      setRecording(rec);
      setChapters(chaps);
      setMessages(msgs);
      setTitle(rec.title);
      setDescription(rec.description || '');
      setTrimStart(rec.trim_start_seconds || 0);
      setTrimEnd(rec.trim_end_seconds || rec.duration_seconds);
      setDuration(rec.duration_seconds);
    }
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleTimeUpdate = useCallback(() => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  }, []);

  const handleLoadedMetadata = useCallback(() => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      setTrimEnd(videoRef.current.duration);
    }
  }, []);

  const togglePlayback = () => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const seekTo = (time: number) => {
    if (!videoRef.current) return;
    const clampedTime = Math.max(0, Math.min(time, duration));
    videoRef.current.currentTime = clampedTime;
    setCurrentTime(clampedTime);
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressRef.current) return;
    const rect = progressRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    seekTo(percentage * duration);
  };

  const setTrimStartAtCurrent = () => {
    setTrimStart(currentTime);
    setHasChanges(true);
  };

  const setTrimEndAtCurrent = () => {
    setTrimEnd(currentTime);
    setHasChanges(true);
  };

  const handleAddChapter = async () => {
    if (!newChapterTitle.trim()) {
      toast({
        title: "Erreur",
        description: "Le titre du chapitre est requis",
        variant: "destructive"
      });
      return;
    }

    const chapter = await addChapter(recordingId, {
      title: newChapterTitle,
      description: newChapterDescription,
      timestampSeconds: currentTime
    });

    if (chapter) {
      setChapters([...chapters, chapter].sort((a, b) => a.timestamp_seconds - b.timestamp_seconds));
      setNewChapterTitle('');
      setNewChapterDescription('');
      setShowAddChapter(false);
      toast({
        title: "Chapitre ajouté",
        description: `"${chapter.title}" a été ajouté à ${formatTime(chapter.timestamp_seconds)}`
      });
    }
  };

  const handleUpdateChapter = async () => {
    if (!editingChapter) return;

    const updated = await updateChapter(editingChapter.id, {
      title: editingChapter.title,
      description: editingChapter.description,
      timestampSeconds: editingChapter.timestamp_seconds
    });

    if (updated) {
      setChapters(chapters.map(c => c.id === updated.id ? updated : c));
      setEditingChapter(null);
      toast({
        title: "Chapitre mis à jour",
        description: "Les modifications ont été enregistrées"
      });
    }
  };

  const handleDeleteChapter = async (chapterId: string) => {
    const success = await deleteChapter(chapterId);
    if (success) {
      setChapters(chapters.filter(c => c.id !== chapterId));
      toast({
        title: "Chapitre supprimé",
        description: "Le chapitre a été supprimé"
      });
    }
  };

  const handleSave = async () => {
    const updated = await updateRecording(recordingId, {
      title,
      description,
      trimStart,
      trimEnd
    });

    if (updated) {
      setRecording(updated);
      setHasChanges(false);
      toast({
        title: "Enregistré",
        description: "Les modifications ont été sauvegardées"
      });
      onSave?.();
    }
  };

  const handlePublish = async () => {
    const success = await publishRecording(recordingId);
    if (success) {
      setRecording(prev => prev ? { ...prev, status: 'published', is_published: true } : null);
      toast({
        title: "Publié",
        description: "La rediffusion est maintenant disponible pour les spectateurs"
      });
      onSave?.();
    }
  };

  const handleUnpublish = async () => {
    const success = await unpublishRecording(recordingId);
    if (success) {
      setRecording(prev => prev ? { ...prev, status: 'ready', is_published: false } : null);
      toast({
        title: "Dépublié",
        description: "La rediffusion n'est plus visible par les spectateurs"
      });
      onSave?.();
    }
  };

  const getVisibleMessages = () => {
    return messages.filter(msg => {
      const msgTime = msg.timestamp_offset_ms / 1000;
      return msgTime >= trimStart && msgTime <= trimEnd;
    });
  };

  if (!isOpen) return null;

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
  const trimStartPercent = duration > 0 ? (trimStart / duration) * 100 : 0;
  const trimEndPercent = duration > 0 ? (trimEnd / duration) * 100 : 100;

  return (
    <div className="fixed inset-0 z-[9999] bg-black/95 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-800">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
            <X className="w-5 h-5 text-white" />
          </button>
          <div>
            <h2 className="text-white font-bold text-lg">Éditeur de rediffusion</h2>
            <p className="text-slate-400 text-sm">{recording?.title || 'Chargement...'}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {hasChanges && (
            <span className="text-yellow-400 text-sm">Modifications non sauvegardées</span>
          )}
          <Button
            onClick={handleSave}
            disabled={loading || !hasChanges}
            className="bg-purple-500 hover:bg-purple-600"
          >
            <Save className="w-4 h-4 mr-2" />
            Sauvegarder
          </Button>
          {recording?.is_published ? (
            <Button
              onClick={handleUnpublish}
              disabled={loading}
              variant="outline"
              className="border-orange-500 text-orange-500 hover:bg-orange-500/10"
            >
              <EyeOff className="w-4 h-4 mr-2" />
              Dépublier
            </Button>
          ) : (
            <Button
              onClick={handlePublish}
              disabled={loading || recording?.status === 'processing'}
              className="bg-green-500 hover:bg-green-600"
            >
              <Eye className="w-4 h-4 mr-2" />
              Publier
            </Button>
          )}
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Video Section */}
        <div className="flex-1 flex flex-col p-4">
          {/* Video Player */}
          <div className="flex-1 relative bg-black rounded-xl overflow-hidden mb-4">
            {recording?.processed_url ? (
              <video
                ref={videoRef}
                src={recording.processed_url}
                className="w-full h-full object-contain"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onClick={togglePlayback}
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <Film className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400">Vidéo en cours de traitement...</p>
                </div>
              </div>
            )}

            {/* Play/Pause Overlay */}
            {!isPlaying && recording?.processed_url && (
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={togglePlayback}
                  className="w-20 h-20 bg-purple-500/80 hover:bg-purple-500 rounded-full flex items-center justify-center transition-all"
                >
                  <Play className="w-10 h-10 text-white ml-1" />
                </button>
              </div>
            )}

            {/* Chapter Markers */}
            {chapters.map(chapter => {
              const position = (chapter.timestamp_seconds / duration) * 100;
              return (
                <div
                  key={chapter.id}
                  className="absolute bottom-16 w-1 h-4 bg-yellow-400 cursor-pointer hover:h-6 transition-all"
                  style={{ left: `${position}%` }}
                  onClick={() => seekTo(chapter.timestamp_seconds)}
                  title={chapter.title}
                />
              );
            })}
          </div>

          {/* Timeline & Controls */}
          <div className="bg-slate-900 rounded-xl p-4">
            {/* Progress Bar with Trim Handles */}
            <div className="relative mb-4">
              <div
                ref={progressRef}
                className="h-12 bg-slate-800 rounded-lg cursor-pointer relative overflow-hidden"
                onClick={handleProgressClick}
              >
                {/* Trimmed region (darker) */}
                <div
                  className="absolute inset-y-0 bg-slate-700/50"
                  style={{ left: 0, width: `${trimStartPercent}%` }}
                />
                <div
                  className="absolute inset-y-0 bg-slate-700/50"
                  style={{ left: `${trimEndPercent}%`, right: 0 }}
                />

                {/* Active region */}
                <div
                  className="absolute inset-y-0 bg-gradient-to-r from-purple-500/30 to-pink-500/30"
                  style={{ left: `${trimStartPercent}%`, width: `${trimEndPercent - trimStartPercent}%` }}
                />

                {/* Playhead */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-white z-10"
                  style={{ left: `${progress}%` }}
                >
                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full" />
                </div>

                {/* Trim handles */}
                {isTrimming && (
                  <>
                    <div
                      className="absolute top-0 bottom-0 w-2 bg-green-500 cursor-ew-resize z-20"
                      style={{ left: `${trimStartPercent}%` }}
                    />
                    <div
                      className="absolute top-0 bottom-0 w-2 bg-red-500 cursor-ew-resize z-20"
                      style={{ left: `${trimEndPercent}%` }}
                    />
                  </>
                )}

                {/* Chapter markers on timeline */}
                {chapters.map(chapter => {
                  const position = (chapter.timestamp_seconds / duration) * 100;
                  return (
                    <div
                      key={chapter.id}
                      className="absolute top-0 bottom-0 w-0.5 bg-yellow-400 z-5"
                      style={{ left: `${position}%` }}
                    />
                  );
                })}
              </div>

              {/* Time labels */}
              <div className="flex justify-between text-slate-400 text-sm mt-2">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Playback Controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => seekTo(currentTime - 10)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                >
                  <SkipBack className="w-5 h-5 text-white" />
                </button>
                <button
                  onClick={togglePlayback}
                  className="p-3 bg-purple-500 hover:bg-purple-600 rounded-lg transition-colors"
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-white ml-0.5" />
                  )}
                </button>
                <button
                  onClick={() => seekTo(currentTime + 10)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                >
                  <SkipForward className="w-5 h-5 text-white" />
                </button>
              </div>

              {/* Trim Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsTrimming(!isTrimming)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                    isTrimming ? 'bg-purple-500 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <Scissors className="w-4 h-4" />
                  <span className="text-sm">Découper</span>
                </button>
                
                {isTrimming && (
                  <>
                    <button
                      onClick={setTrimStartAtCurrent}
                      className="flex items-center gap-2 px-3 py-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors"
                    >
                      <span className="text-sm">Début: {formatTime(trimStart)}</span>
                    </button>
                    <button
                      onClick={setTrimEndAtCurrent}
                      className="flex items-center gap-2 px-3 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                    >
                      <span className="text-sm">Fin: {formatTime(trimEnd)}</span>
                    </button>
                  </>
                )}
              </div>

              {/* Add Chapter */}
              <button
                onClick={() => setShowAddChapter(true)}
                className="flex items-center gap-2 px-3 py-2 bg-yellow-500/20 text-yellow-400 rounded-lg hover:bg-yellow-500/30 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span className="text-sm">Chapitre à {formatTime(currentTime)}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-96 bg-slate-900 border-l border-slate-800 flex flex-col">
          {/* Tabs */}
          <div className="flex border-b border-slate-800">
            <button
              onClick={() => setActiveTab('chapters')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'chapters' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
              }`}
            >
              <List className="w-4 h-4 inline mr-2" />
              Chapitres
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'chat' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
              }`}
            >
              <MessageCircle className="w-4 h-4 inline mr-2" />
              Chat
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'settings' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
              }`}
            >
              Détails
            </button>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-4">
            {activeTab === 'chapters' && (
              <div className="space-y-3">
                {/* Add Chapter Form */}
                {showAddChapter && (
                  <div className="bg-slate-800 rounded-xl p-4 mb-4">
                    <h4 className="text-white font-medium mb-3">Nouveau chapitre</h4>
                    <div className="space-y-3">
                      <Input
                        placeholder="Titre du chapitre"
                        value={newChapterTitle}
                        onChange={(e) => setNewChapterTitle(e.target.value)}
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                      <Textarea
                        placeholder="Description (optionnel)"
                        value={newChapterDescription}
                        onChange={(e) => setNewChapterDescription(e.target.value)}
                        className="bg-slate-700 border-slate-600 text-white resize-none"
                        rows={2}
                      />
                      <div className="flex items-center gap-2 text-slate-400 text-sm">
                        <Clock className="w-4 h-4" />
                        <span>Position: {formatTime(currentTime)}</span>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={handleAddChapter}
                          className="flex-1 bg-purple-500 hover:bg-purple-600"
                        >
                          Ajouter
                        </Button>
                        <Button
                          onClick={() => {
                            setShowAddChapter(false);
                            setNewChapterTitle('');
                            setNewChapterDescription('');
                          }}
                          variant="outline"
                          className="border-slate-600"
                        >
                          Annuler
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {chapters.length === 0 ? (
                  <div className="text-center py-8">
                    <List className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-slate-400 text-sm">Aucun chapitre</p>
                    <p className="text-slate-500 text-xs mt-1">
                      Ajoutez des chapitres pour faciliter la navigation
                    </p>
                  </div>
                ) : (
                  chapters.map((chapter) => (
                    <div
                      key={chapter.id}
                      className={`bg-slate-800 rounded-xl p-3 cursor-pointer hover:bg-slate-700 transition-colors ${
                        editingChapter?.id === chapter.id ? 'ring-2 ring-purple-500' : ''
                      }`}
                    >
                      {editingChapter?.id === chapter.id ? (
                        <div className="space-y-2">
                          <Input
                            value={editingChapter.title}
                            onChange={(e) => setEditingChapter({ ...editingChapter, title: e.target.value })}
                            className="bg-slate-700 border-slate-600 text-white text-sm"
                          />
                          <Textarea
                            value={editingChapter.description || ''}
                            onChange={(e) => setEditingChapter({ ...editingChapter, description: e.target.value })}
                            className="bg-slate-700 border-slate-600 text-white text-sm resize-none"
                            rows={2}
                          />
                          <div className="flex gap-2">
                            <Button
                              onClick={handleUpdateChapter}
                              size="sm"
                              className="bg-green-500 hover:bg-green-600"
                            >
                              <Check className="w-4 h-4" />
                            </Button>
                            <Button
                              onClick={() => setEditingChapter(null)}
                              size="sm"
                              variant="outline"
                              className="border-slate-600"
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-start gap-3">
                          <div className="flex items-center gap-1 text-slate-500">
                            <GripVertical className="w-4 h-4" />
                          </div>
                          <div
                            className="flex-1 min-w-0"
                            onClick={() => seekTo(chapter.timestamp_seconds)}
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-purple-400 text-xs font-mono">
                                {formatTime(chapter.timestamp_seconds)}
                              </span>
                              <ChevronRight className="w-3 h-3 text-slate-500" />
                            </div>
                            <h4 className="text-white font-medium text-sm truncate">{chapter.title}</h4>
                            {chapter.description && (
                              <p className="text-slate-400 text-xs line-clamp-1">{chapter.description}</p>
                            )}
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingChapter(chapter);
                              }}
                              className="p-1.5 hover:bg-slate-600 rounded transition-colors"
                            >
                              <Edit2 className="w-3.5 h-3.5 text-slate-400" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteChapter(chapter.id);
                              }}
                              className="p-1.5 hover:bg-red-500/20 rounded transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-red-400" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            )}

            {activeTab === 'chat' && (
              <div className="space-y-2">
                <div className="bg-slate-800/50 rounded-lg p-3 mb-4">
                  <p className="text-slate-400 text-sm">
                    {getVisibleMessages().length} messages dans la zone sélectionnée
                  </p>
                </div>
                
                {getVisibleMessages().length === 0 ? (
                  <div className="text-center py-8">
                    <MessageCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-slate-400 text-sm">Aucun message</p>
                  </div>
                ) : (
                  getVisibleMessages().map((msg) => (
                    <div
                      key={msg.id}
                      className="bg-slate-800/50 rounded-lg p-3 cursor-pointer hover:bg-slate-800 transition-colors"
                      onClick={() => seekTo(msg.timestamp_offset_ms / 1000)}
                    >
                      <div className="flex items-start gap-2">
                        <img
                          src={msg.user_avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50'}
                          alt={msg.user_name}
                          className="w-6 h-6 rounded-full"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-white text-xs font-medium">{msg.user_name}</span>
                            <span className="text-slate-500 text-xs">
                              {formatTime(msg.timestamp_offset_ms / 1000)}
                            </span>
                          </div>
                          <p className="text-slate-300 text-sm">{msg.message}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-slate-400 text-sm mb-2">Titre</label>
                  <Input
                    value={title}
                    onChange={(e) => {
                      setTitle(e.target.value);
                      setHasChanges(true);
                    }}
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                
                <div>
                  <label className="block text-slate-400 text-sm mb-2">Description</label>
                  <Textarea
                    value={description}
                    onChange={(e) => {
                      setDescription(e.target.value);
                      setHasChanges(true);
                    }}
                    className="bg-slate-800 border-slate-700 text-white resize-none"
                    rows={4}
                  />
                </div>

                <div className="bg-slate-800 rounded-xl p-4">
                  <h4 className="text-white font-medium mb-3">Informations</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Durée originale</span>
                      <span className="text-white">{formatTime(recording?.duration_seconds || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Durée après découpe</span>
                      <span className="text-white">{formatTime(trimEnd - trimStart)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Chapitres</span>
                      <span className="text-white">{chapters.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Messages chat</span>
                      <span className="text-white">{getVisibleMessages().length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Vues</span>
                      <span className="text-white">{recording?.view_count || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Statut</span>
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        recording?.is_published 
                          ? 'bg-green-500/20 text-green-400' 
                          : 'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {recording?.is_published ? 'Publié' : 'Brouillon'}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 text-sm mb-2">Miniature</label>
                  <div className="bg-slate-800 rounded-xl p-4 border-2 border-dashed border-slate-700 text-center">
                    {recording?.thumbnail_url ? (
                      <img
                        src={recording.thumbnail_url}
                        alt="Thumbnail"
                        className="w-full h-32 object-cover rounded-lg mb-2"
                      />
                    ) : (
                      <ImageIcon className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                    )}
                    <Button variant="outline" size="sm" className="border-slate-600">
                      <Upload className="w-4 h-4 mr-2" />
                      Changer la miniature
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecordingEditor;
