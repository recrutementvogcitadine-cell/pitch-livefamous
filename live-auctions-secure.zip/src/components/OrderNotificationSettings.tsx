import React, { useState, useEffect } from 'react';
import { 
  Package, 
  CheckCircle, 
  Truck, 
  Home, 
  X, 
  Bell, 
  BellOff,
  Settings,
  ChevronRight,
  Loader2,
  Info
} from 'lucide-react';
import { useNotifications, NotificationPreferences } from '@/hooks/useNotifications';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

interface OrderNotificationSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export function OrderNotificationSettings({ isOpen, onClose }: OrderNotificationSettingsProps) {
  const { user } = useAuth();
  const { preferences, fetchPreferences, updatePreferences, loading } = useNotifications();
  const [localPrefs, setLocalPrefs] = useState<Partial<NotificationPreferences>>({
    order_notifications: true,
    order_confirmed_notifications: true,
    order_shipped_notifications: true,
    order_delivered_notifications: true,
    order_cancelled_notifications: true
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user && isOpen) {
      fetchPreferences(user.id).then(prefs => {
        if (prefs) {
          setLocalPrefs({
            order_notifications: prefs.order_notifications ?? true,
            order_confirmed_notifications: prefs.order_confirmed_notifications ?? true,
            order_shipped_notifications: prefs.order_shipped_notifications ?? true,
            order_delivered_notifications: prefs.order_delivered_notifications ?? true,
            order_cancelled_notifications: prefs.order_cancelled_notifications ?? true
          });
        }
      }).catch(console.error);
    }
  }, [user, isOpen, fetchPreferences]);

  const handleToggle = async (key: keyof NotificationPreferences, value: boolean) => {
    if (!user) return;
    
    setSaving(true);
    const newPrefs = { ...localPrefs, [key]: value };
    setLocalPrefs(newPrefs);
    
    try {
      await updatePreferences(user.id, { [key]: value });
      toast({
        title: "Préférences mises à jour",
        description: "Vos préférences de notification ont été sauvegardées"
      });
    } catch (error) {
      // Revert on error
      setLocalPrefs(prev => ({ ...prev, [key]: !value }));
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour les préférences",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const orderNotificationTypes = [
    {
      key: 'order_confirmed_notifications' as keyof NotificationPreferences,
      icon: CheckCircle,
      color: 'blue',
      title: 'Confirmation de commande',
      description: 'Quand le vendeur confirme votre commande'
    },
    {
      key: 'order_shipped_notifications' as keyof NotificationPreferences,
      icon: Truck,
      color: 'purple',
      title: 'Expédition',
      description: 'Quand votre commande est expédiée'
    },
    {
      key: 'order_delivered_notifications' as keyof NotificationPreferences,
      icon: Home,
      color: 'green',
      title: 'Livraison',
      description: 'Quand votre commande est livrée'
    },
    {
      key: 'order_cancelled_notifications' as keyof NotificationPreferences,
      icon: X,
      color: 'red',
      title: 'Annulation',
      description: 'Quand une commande est annulée'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; text: string; border: string }> = {
      blue: { bg: 'bg-blue-500/20', text: 'text-blue-400', border: 'border-blue-500/30' },
      purple: { bg: 'bg-purple-500/20', text: 'text-purple-400', border: 'border-purple-500/30' },
      green: { bg: 'bg-green-500/20', text: 'text-green-400', border: 'border-green-500/30' },
      red: { bg: 'bg-red-500/20', text: 'text-red-400', border: 'border-red-500/30' }
    };
    return colors[color] || colors.blue;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-slate-800 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-700 bg-gradient-to-r from-orange-500 to-pink-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                <Package className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Notifications de commande</h2>
                <p className="text-white/80 text-sm">Choisissez quand être notifié</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X className="w-6 h-6 text-white" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Master Toggle */}
          <div className={`p-4 rounded-xl border transition-all ${
            localPrefs.order_notifications 
              ? 'bg-orange-500/10 border-orange-500/30' 
              : 'bg-slate-700/50 border-slate-600'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  localPrefs.order_notifications ? 'bg-orange-500/30' : 'bg-slate-600'
                }`}>
                  {localPrefs.order_notifications ? (
                    <Bell className="w-5 h-5 text-orange-400" />
                  ) : (
                    <BellOff className="w-5 h-5 text-slate-400" />
                  )}
                </div>
                <div>
                  <p className="text-white font-semibold">Notifications de commande</p>
                  <p className="text-slate-400 text-sm">Activer toutes les notifications</p>
                </div>
              </div>
              <button
                onClick={() => handleToggle('order_notifications', !localPrefs.order_notifications)}
                disabled={saving}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                  localPrefs.order_notifications ? 'bg-orange-500' : 'bg-slate-600'
                } ${saving ? 'opacity-50' : ''}`}
              >
                <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                  localPrefs.order_notifications ? 'left-8' : 'left-1'
                }`}>
                  {saving && (
                    <Loader2 className="w-5 h-5 animate-spin text-slate-400" />
                  )}
                </div>
              </button>
            </div>
          </div>

          {/* Individual Notification Types */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider px-1">
              Types de notifications
            </h3>
            
            {orderNotificationTypes.map(({ key, icon: Icon, color, title, description }) => {
              const colorClasses = getColorClasses(color);
              const isEnabled = localPrefs[key] && localPrefs.order_notifications;
              const isDisabled = !localPrefs.order_notifications;
              
              return (
                <div 
                  key={key}
                  className={`p-4 rounded-xl border transition-all ${
                    isDisabled 
                      ? 'bg-slate-800/50 border-slate-700 opacity-50' 
                      : isEnabled 
                        ? `${colorClasses.bg} ${colorClasses.border}` 
                        : 'bg-slate-700/50 border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        isEnabled ? colorClasses.bg : 'bg-slate-600'
                      }`}>
                        <Icon className={`w-5 h-5 ${isEnabled ? colorClasses.text : 'text-slate-400'}`} />
                      </div>
                      <div>
                        <p className={`font-medium ${isEnabled ? 'text-white' : 'text-slate-300'}`}>
                          {title}
                        </p>
                        <p className="text-slate-400 text-sm">{description}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleToggle(key, !localPrefs[key])}
                      disabled={saving || isDisabled}
                      className={`relative w-12 h-6 rounded-full transition-colors ${
                        isEnabled ? 'bg-orange-500' : 'bg-slate-600'
                      } ${(saving || isDisabled) ? 'cursor-not-allowed' : ''}`}
                    >
                      <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                        isEnabled ? 'left-6' : 'left-0.5'
                      }`} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Info Box */}
          <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl">
            <div className="flex gap-3">
              <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-blue-300 text-sm font-medium">Comment ça marche?</p>
                <p className="text-blue-300/80 text-sm mt-1">
                  Vous recevrez une notification instantanée à chaque étape de votre commande. 
                  Les notifications apparaissent dans le centre de notifications et peuvent 
                  également être envoyées par push si vous avez activé cette option.
                </p>
              </div>
            </div>
          </div>

          {/* Preview Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider px-1">
              Aperçu des notifications
            </h3>
            
            <div className="space-y-2">
              {localPrefs.order_confirmed_notifications && localPrefs.order_notifications && (
                <div className="p-3 bg-slate-700/50 rounded-lg border border-slate-600">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-4 h-4 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">Commande confirmée</p>
                      <p className="text-slate-400 text-xs">Votre commande #ORD-001 a été confirmée par TechStore.</p>
                    </div>
                  </div>
                </div>
              )}
              
              {localPrefs.order_shipped_notifications && localPrefs.order_notifications && (
                <div className="p-3 bg-slate-700/50 rounded-lg border border-slate-600">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                      <Truck className="w-4 h-4 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">Commande expédiée</p>
                      <p className="text-slate-400 text-xs">Votre colis est en route! N° de suivi: CP123456789</p>
                    </div>
                  </div>
                </div>
              )}
              
              {localPrefs.order_delivered_notifications && localPrefs.order_notifications && (
                <div className="p-3 bg-slate-700/50 rounded-lg border border-slate-600">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                      <Home className="w-4 h-4 text-green-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">Commande livrée</p>
                      <p className="text-slate-400 text-xs">Votre commande a été livrée. Merci pour votre achat!</p>
                    </div>
                  </div>
                </div>
              )}

              {(!localPrefs.order_notifications || 
                (!localPrefs.order_confirmed_notifications && 
                 !localPrefs.order_shipped_notifications && 
                 !localPrefs.order_delivered_notifications)) && (
                <div className="p-4 text-center">
                  <BellOff className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                  <p className="text-slate-400 text-sm">Aucune notification activée</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-700">
          <button
            onClick={onClose}
            className="w-full py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg transition-all"
          >
            Terminé
          </button>
        </div>
      </div>
    </div>
  );
}

export default OrderNotificationSettings;
