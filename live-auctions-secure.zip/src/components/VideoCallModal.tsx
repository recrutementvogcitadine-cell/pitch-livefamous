import React, { useEffect, useRef } from 'react';
import { 
  Phone, 
  PhoneOff, 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  X,
  User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface VideoCallModalProps {
  isOpen: boolean;
  callStatus: 'idle' | 'calling' | 'ringing' | 'connected' | 'ended';
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isMuted: boolean;
  isVideoOff: boolean;
  callDuration: number;
  otherUserName?: string;
  otherUserAvatar?: string;
  error: string | null;
  onToggleMute: () => void;
  onToggleVideo: () => void;
  onEndCall: () => void;
  formatDuration: (seconds: number) => string;
}

export function VideoCallModal({
  isOpen,
  callStatus,
  localStream,
  remoteStream,
  isMuted,
  isVideoOff,
  callDuration,
  otherUserName = 'Utilisateur',
  otherUserAvatar,
  error,
  onToggleMute,
  onToggleVideo,
  onEndCall,
  formatDuration
}: VideoCallModalProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  // Attach local stream to video element
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Attach remote stream to video element
  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  if (!isOpen) return null;

  const isConnected = callStatus === 'connected';
  const isCalling = callStatus === 'calling' || callStatus === 'ringing';
  const isEnded = callStatus === 'ended';

  return (
    <div className="fixed inset-0 z-[100] bg-gray-900 flex flex-col">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 p-4 bg-gradient-to-b from-black/70 to-transparent">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center overflow-hidden">
              {otherUserAvatar ? (
                <img src={otherUserAvatar} alt={otherUserName} className="w-full h-full object-cover" />
              ) : (
                <User className="h-6 w-6 text-gray-400" />
              )}
            </div>
            <div>
              <h3 className="text-white font-semibold">{otherUserName}</h3>
              <p className="text-sm text-gray-300">
                {isCalling && 'Appel en cours...'}
                {isConnected && formatDuration(callDuration)}
                {isEnded && 'Appel terminé'}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            onClick={onEndCall}
          >
            <X className="h-6 w-6" />
          </Button>
        </div>
      </div>

      {/* Main video area */}
      <div className="flex-1 relative">
        {/* Remote video (full screen) */}
        {remoteStream ? (
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-800 to-gray-900">
            <div className="text-center">
              {/* Avatar placeholder */}
              <div className="w-32 h-32 rounded-full bg-gray-700 flex items-center justify-center mx-auto mb-6 overflow-hidden">
                {otherUserAvatar ? (
                  <img src={otherUserAvatar} alt={otherUserName} className="w-full h-full object-cover" />
                ) : (
                  <User className="h-16 w-16 text-gray-500" />
                )}
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">{otherUserName}</h2>
              
              {isCalling && (
                <div className="flex items-center justify-center gap-2">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <span className="text-gray-300 ml-2">
                    {callStatus === 'calling' ? 'Appel en cours' : 'Sonnerie'}
                  </span>
                </div>
              )}
              
              {isEnded && (
                <p className="text-gray-400">Appel terminé</p>
              )}
              
              {error && (
                <p className="text-red-400 mt-4">{error}</p>
              )}
            </div>
          </div>
        )}

        {/* Local video (picture-in-picture) */}
        {localStream && (
          <div className="absolute bottom-24 right-4 w-32 h-44 md:w-48 md:h-64 rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20">
            {isVideoOff ? (
              <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                <VideoOff className="h-8 w-8 text-gray-500" />
              </div>
            ) : (
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover transform scale-x-[-1]"
              />
            )}
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/70 to-transparent">
        <div className="flex items-center justify-center gap-4">
          {/* Mute button */}
          <Button
            onClick={onToggleMute}
            className={cn(
              'w-14 h-14 rounded-full transition-all',
              isMuted 
                ? 'bg-red-500 hover:bg-red-600 text-white' 
                : 'bg-white/20 hover:bg-white/30 text-white'
            )}
          >
            {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
          </Button>

          {/* Video toggle button */}
          <Button
            onClick={onToggleVideo}
            className={cn(
              'w-14 h-14 rounded-full transition-all',
              isVideoOff 
                ? 'bg-red-500 hover:bg-red-600 text-white' 
                : 'bg-white/20 hover:bg-white/30 text-white'
            )}
          >
            {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
          </Button>

          {/* End call button */}
          <Button
            onClick={onEndCall}
            className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 text-white"
          >
            <PhoneOff className="h-7 w-7" />
          </Button>
        </div>
      </div>
    </div>
  );
}

// Incoming call notification component
interface IncomingCallNotificationProps {
  callerName: string;
  callerAvatar?: string;
  onAccept: () => void;
  onReject: () => void;
}

export function IncomingCallNotification({
  callerName,
  callerAvatar,
  onAccept,
  onReject
}: IncomingCallNotificationProps) {
  // Play ringtone effect
  useEffect(() => {
    // Create audio context for ringtone
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    let oscillator: OscillatorNode | null = null;
    let gainNode: GainNode | null = null;
    let intervalId: NodeJS.Timeout | null = null;

    const playRing = () => {
      oscillator = audioContext.createOscillator();
      gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 440;
      oscillator.type = 'sine';
      gainNode.gain.value = 0.1;
      
      oscillator.start();
      
      setTimeout(() => {
        if (oscillator) {
          oscillator.stop();
        }
      }, 200);
    };

    // Ring every second
    playRing();
    intervalId = setInterval(playRing, 1500);

    return () => {
      if (intervalId) clearInterval(intervalId);
      if (oscillator) {
        try { oscillator.stop(); } catch (e) {}
      }
      audioContext.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl p-8 shadow-2xl max-w-sm w-full mx-4 animate-pulse-slow">
        <div className="text-center">
          {/* Caller avatar with animation */}
          <div className="relative mx-auto w-28 h-28 mb-6">
            <div className="absolute inset-0 rounded-full bg-green-500/30 animate-ping" />
            <div className="absolute inset-2 rounded-full bg-green-500/20 animate-ping" style={{ animationDelay: '0.5s' }} />
            <div className="relative w-28 h-28 rounded-full bg-gray-700 flex items-center justify-center overflow-hidden border-4 border-green-500">
              {callerAvatar ? (
                <img src={callerAvatar} alt={callerName} className="w-full h-full object-cover" />
              ) : (
                <User className="h-14 w-14 text-gray-400" />
              )}
            </div>
          </div>

          <h2 className="text-2xl font-bold text-white mb-2">{callerName}</h2>
          <p className="text-gray-400 mb-8">Appel vidéo entrant...</p>

          {/* Action buttons */}
          <div className="flex items-center justify-center gap-6">
            {/* Reject button */}
            <button
              onClick={onReject}
              className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center transition-transform hover:scale-110 shadow-lg shadow-red-600/30"
            >
              <PhoneOff className="h-7 w-7" />
            </button>

            {/* Accept button */}
            <button
              onClick={onAccept}
              className="w-16 h-16 rounded-full bg-green-600 hover:bg-green-700 text-white flex items-center justify-center transition-transform hover:scale-110 shadow-lg shadow-green-600/30"
            >
              <Phone className="h-7 w-7" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default VideoCallModal;
