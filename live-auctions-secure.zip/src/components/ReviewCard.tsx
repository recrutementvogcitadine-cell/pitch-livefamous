import React, { useState } from 'react';
import { ThumbsUp, MessageSquare, Flag, ChevronDown, ChevronUp, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { StarRating } from '@/components/StarRating';
import { Review, useReviews } from '@/hooks/useReviews';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface ReviewCardProps {
  review: Review;
  currentUserId?: string;
  isSeller?: boolean;
  sellerId?: string;
  onReviewUpdated?: (review: Review) => void;
  showProductInfo?: boolean;
}

export function ReviewCard({
  review,
  currentUserId,
  isSeller = false,
  sellerId,
  onReviewUpdated,
  showProductInfo = false
}: ReviewCardProps) {
  const [showFullReview, setShowFullReview] = useState(false);
  const [showResponseForm, setShowResponseForm] = useState(false);
  const [responseText, setResponseText] = useState('');
  const [isHelpful, setIsHelpful] = useState(false);
  const [helpfulCount, setHelpfulCount] = useState(review.helpful_count);
  const [showPhotos, setShowPhotos] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  const { addSellerResponse, markHelpful, loading } = useReviews();
  const { toast } = useToast();

  const isLongReview = review.review_text && review.review_text.length > 300;
  const displayText = isLongReview && !showFullReview
    ? review.review_text?.slice(0, 300) + '...'
    : review.review_text;

  const handleHelpful = async () => {
    if (!currentUserId) {
      toast({
        title: 'Sign in required',
        description: 'Please sign in to mark reviews as helpful.',
        variant: 'destructive'
      });
      return;
    }

    try {
      const action = await markHelpful(review.id, currentUserId);
      if (action === 'added') {
        setIsHelpful(true);
        setHelpfulCount(prev => prev + 1);
      } else {
        setIsHelpful(false);
        setHelpfulCount(prev => Math.max(0, prev - 1));
      }
    } catch (err: any) {
      toast({
        title: 'Error',
        description: err.message,
        variant: 'destructive'
      });
    }
  };

  const handleSubmitResponse = async () => {
    if (!responseText.trim() || !sellerId) return;

    try {
      const updatedReview = await addSellerResponse(review.id, sellerId, responseText.trim());
      setShowResponseForm(false);
      setResponseText('');
      onReviewUpdated?.(updatedReview);
      toast({
        title: 'Response posted',
        description: 'Your response has been added to the review.'
      });
    } catch (err: any) {
      toast({
        title: 'Error',
        description: err.message,
        variant: 'destructive'
      });
    }
  };

  const timeAgo = formatDistanceToNow(new Date(review.created_at), { addSuffix: true });

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <Avatar className="w-10 h-10">
            <AvatarImage src={review.buyer_avatar} />
            <AvatarFallback className="bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-300">
              {review.buyer_name?.charAt(0) || 'U'}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-medium text-gray-900 dark:text-white">
                {review.buyer_name || 'Anonymous'}
              </span>
              {review.verified_purchase && (
                <span className="inline-flex items-center text-xs text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/30 px-2 py-0.5 rounded-full">
                  <Check className="w-3 h-3 mr-1" />
                  Verified Purchase
                </span>
              )}
            </div>
            <span className="text-sm text-gray-500 dark:text-gray-400">{timeAgo}</span>
          </div>
        </div>
        <StarRating rating={review.rating} size="sm" />
      </div>

      {/* Product info (for seller view) */}
      {showProductInfo && (review.product_name || review.product_image) && (
        <div className="flex items-center gap-3 mb-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
          {review.product_image && (
            <img
              src={review.product_image}
              alt={review.product_name}
              className="w-12 h-12 object-cover rounded"
            />
          )}
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
            {review.product_name}
          </span>
        </div>
      )}

      {/* Review title */}
      {review.title && (
        <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
          {review.title}
        </h4>
      )}

      {/* Review text */}
      {review.review_text && (
        <div className="mb-4">
          <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
            {displayText}
          </p>
          {isLongReview && (
            <button
              onClick={() => setShowFullReview(!showFullReview)}
              className="text-purple-600 dark:text-purple-400 text-sm font-medium hover:underline mt-1 flex items-center gap-1"
            >
              {showFullReview ? (
                <>Show less <ChevronUp className="w-4 h-4" /></>
              ) : (
                <>Read more <ChevronDown className="w-4 h-4" /></>
              )}
            </button>
          )}
        </div>
      )}

      {/* Photos */}
      {review.photos && review.photos.length > 0 && (
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {review.photos.slice(0, showPhotos ? undefined : 3).map((photo, index) => (
              <button
                key={index}
                onClick={() => setSelectedPhoto(photo)}
                className="relative group"
              >
                <img
                  src={photo}
                  alt={`Review photo ${index + 1}`}
                  className="w-20 h-20 object-cover rounded-lg border border-gray-200 dark:border-gray-700 transition-transform group-hover:scale-105"
                />
              </button>
            ))}
            {!showPhotos && review.photos.length > 3 && (
              <button
                onClick={() => setShowPhotos(true)}
                className="w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center text-sm font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                +{review.photos.length - 3}
              </button>
            )}
          </div>
        </div>
      )}

      {/* Seller response */}
      {review.seller_response && (
        <div className="mt-4 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border-l-4 border-purple-500">
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span className="font-medium text-purple-700 dark:text-purple-300 text-sm">
              Seller Response
            </span>
            {review.seller_response_at && (
              <span className="text-xs text-purple-500 dark:text-purple-400">
                {formatDistanceToNow(new Date(review.seller_response_at), { addSuffix: true })}
              </span>
            )}
          </div>
          <p className="text-gray-700 dark:text-gray-300 text-sm whitespace-pre-wrap">
            {review.seller_response}
          </p>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
        <div className="flex items-center gap-4">
          <button
            onClick={handleHelpful}
            disabled={loading}
            className={cn(
              'flex items-center gap-1.5 text-sm transition-colors',
              isHelpful
                ? 'text-purple-600 dark:text-purple-400'
                : 'text-gray-500 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400'
            )}
          >
            <ThumbsUp className={cn('w-4 h-4', isHelpful && 'fill-current')} />
            <span>Helpful ({helpfulCount})</span>
          </button>
        </div>

        {/* Seller response button */}
        {isSeller && sellerId === review.seller_id && !review.seller_response && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowResponseForm(!showResponseForm)}
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Respond
          </Button>
        )}
      </div>

      {/* Response form for sellers */}
      {showResponseForm && (
        <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700 space-y-3">
          <Textarea
            placeholder="Write your response to this review..."
            value={responseText}
            onChange={(e) => setResponseText(e.target.value)}
            rows={3}
            maxLength={1000}
          />
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">{responseText.length}/1000</span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setShowResponseForm(false);
                  setResponseText('');
                }}
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={handleSubmitResponse}
                disabled={!responseText.trim() || loading}
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  'Post Response'
                )}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Photo modal */}
      {selectedPhoto && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={() => setSelectedPhoto(null)}
        >
          <img
            src={selectedPhoto}
            alt="Review photo"
            className="max-w-full max-h-full object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
