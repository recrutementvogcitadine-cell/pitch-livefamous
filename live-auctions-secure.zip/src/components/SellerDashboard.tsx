import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  X, Play, Package, DollarSign, Users, TrendingUp, 
  Plus, Video, Settings, BarChart3, ShoppingBag, Clock,
  ChevronRight, Eye, Store, Shield, CheckCircle, AlertCircle,
  LineChart, Crown, Zap, Building2, Calendar, RefreshCw, ArrowRight,
  Trash2, Edit2, Radio, StopCircle, ExternalLink, Truck, Home,
  MapPin, Phone, Search, Filter, ChevronDown, ChevronUp, Copy,
  MessageSquare, RotateCcw, ToggleLeft, ToggleRight, AlertTriangle,
  Star, Target, CalendarDays, Sparkles, Bell, Film, Scissors, Percent
} from 'lucide-react';

import { formatPrice, products as mockProducts } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import SellerVerificationForm from './SellerVerificationForm';
import { VerificationBadgeFull } from './VerificationBadge';
import SellerAnalytics from './SellerAnalytics';
import SubscriptionPlans from './SubscriptionPlans';
import GoLiveModal from './GoLiveModal';
import { ScheduleStreamModal } from './ScheduleStreamModal';
import { useSubscription } from '@/hooks/useSubscription';
import { useLiveStream, LiveStreamData, ScheduleLiveParams } from '@/hooks/useLiveStream';
import { useOrders, Order, OrderStats } from '@/hooks/useOrders';
import { useProducts, StockAlert, SalesGoal } from '@/hooks/useProducts';
import { useScheduledStreams } from '@/hooks/useScheduledStreams';
import SellerOrdersTab from './SellerOrdersTab';
import SellerProductsTab from './SellerProductsTab';
import { SellerNotificationSettings } from './SellerNotificationSettings';
import { SellerReviewsTab } from './SellerReviewsTab';
import RecordingsTab from './RecordingsTab';
import ClipsTab from './ClipsTab';
import PromoCodesTab from './PromoCodesTab';
import { toast } from '@/components/ui/use-toast';









interface SellerDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

interface VerificationStatus {
  status: 'none' | 'pending' | 'approved' | 'rejected';
  submittedAt?: string;
}

// Mock stock alerts for overview
const mockStockAlerts: StockAlert[] = [
  { id: '1', seller_id: '1', product_id: '6', product_name: 'iPad Pro 12.9"', current_stock: 0, threshold: 10, alert_type: 'out_of_stock', is_read: false, created_at: new Date().toISOString() },
  { id: '2', seller_id: '1', product_id: '7', product_name: 'Sony WH-1000XM5', current_stock: 3, threshold: 10, alert_type: 'low_stock', is_read: false, created_at: new Date().toISOString() },
];

// Mock sales goals for overview
const mockSalesGoals: SalesGoal[] = [
  { id: '1', seller_id: '1', goal_type: 'revenue', target_value: 5000000, current_value: 3750000, period: 'monthly', start_date: new Date().toISOString(), end_date: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString(), is_active: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
];

const SellerDashboard: React.FC<SellerDashboardProps> = ({ isOpen, onClose }) => {
  const { user, profile, refreshProfile } = useAuth();
  const { subscription, plan, limits, isSubscribed, getDaysRemaining, isExpiringSoon, refreshSubscription } = useSubscription();
  const { 
    lives, limits: liveLimits, loading: liveLoading, 
    checkLimits, scheduleLive, startLive, endLive, cancelLive, fetchSellerLives, toggleReplay, fetchSellerReplays
  } = useLiveStream();
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'lives' | 'orders' | 'reviews' | 'analytics' | 'verification' | 'subscription' | 'promotions'>('overview');


  const [showVerificationForm, setShowVerificationForm] = useState(false);
  const [showSubscriptionPlans, setShowSubscriptionPlans] = useState(false);
  const [showGoLiveModal, setShowGoLiveModal] = useState(false);
  const [showNotificationSettings, setShowNotificationSettings] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>({ status: 'none' });
  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [livesSubTab, setLivesSubTab] = useState<'upcoming' | 'replays' | 'recordings' | 'clips'>('upcoming');

  const [showEndLiveModal, setShowEndLiveModal] = useState(false);
  const [endingLiveId, setEndingLiveId] = useState<string | null>(null);
  const [enableReplayOnEnd, setEnableReplayOnEnd] = useState(true);
  const [stockAlerts] = useState<StockAlert[]>(mockStockAlerts);
  const [salesGoals] = useState<SalesGoal[]>(mockSalesGoals);
  const [scheduleForm, setScheduleForm] = useState({
    title: '',
    description: '',
    scheduledAt: '',
    category: 'Électronique',
    selectedProducts: [] as string[]
  });




  useEffect(() => {
    if (isOpen && user) {
      fetchVerificationStatus();
      fetchSellerLives();
      checkLimits();
    }
  }, [isOpen, user]);

  const handleScheduleLive = async () => {
    if (!scheduleForm.title || !scheduleForm.scheduledAt) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir le titre et la date du live",
        variant: "destructive"
      });
      return;
    }

    const selectedProductsData = mockProducts
      .filter(p => scheduleForm.selectedProducts.includes(p.id))
      .map(p => ({
        id: p.id,
        name: p.name,
        price: p.price,
        image: p.image,
        originalPrice: p.originalPrice
      }));

    const result = await scheduleLive({
      title: scheduleForm.title,
      description: scheduleForm.description,
      scheduledAt: scheduleForm.scheduledAt,
      category: scheduleForm.category,
      products: selectedProductsData
    });

    if (result) {
      setShowScheduleForm(false);
      setScheduleForm({
        title: '',
        description: '',
        scheduledAt: '',
        category: 'Électronique',
        selectedProducts: []
      });
    }
  };

  const handleStartLive = async (liveId: string) => {
    await startLive(liveId);
  };

  const handleEndLive = async (liveId: string) => {
    await endLive(liveId);
  };

  const handleCancelLive = async (liveId: string) => {
    if (confirm('Êtes-vous sûr de vouloir annuler ce live?')) {
      await cancelLive(liveId);
    }
  };

  const getLiveStatusBadge = (status: string) => {
    switch (status) {
      case 'scheduled':
        return <span className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded-full">Programmé</span>;
      case 'live':
        return <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded-full flex items-center gap-1"><span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></span>En direct</span>;
      case 'ended':
        return <span className="px-2 py-1 bg-slate-500/20 text-slate-400 text-xs rounded-full">Terminé</span>;
      case 'cancelled':
        return <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded-full">Annulé</span>;
      default:
        return null;
    }
  };

  const categories = ['Électronique', 'Mode', 'Beauté', 'Maison', 'Bijoux', 'Chaussures', 'Auto', 'Accessoires'];



  const fetchVerificationStatus = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('seller_verification_requests')
        .select('status, submitted_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (data && !error) {
        setVerificationStatus({
          status: data.status as 'pending' | 'approved' | 'rejected',
          submittedAt: data.submitted_at
        });
      }
    } catch (err) {
      setVerificationStatus({ status: 'none' });
    }
  };

  if (!isOpen) return null;

  const storeName = profile?.store_name || 'Ma Boutique';
  const sellerName = profile?.full_name || 'Vendeur';
  const isVerified = profile?.is_verified || false;

  const stats = [
    { label: 'Revenus ce mois', value: formatPrice(2450000), change: '+12%', icon: <DollarSign className="w-5 h-5" />, color: 'from-green-500 to-emerald-500' },
    { label: 'Commandes', value: '156', change: '+8%', icon: <ShoppingBag className="w-5 h-5" />, color: 'from-blue-500 to-cyan-500' },
    { label: 'Vues Lives', value: '12.4K', change: '+23%', icon: <Eye className="w-5 h-5" />, color: 'from-purple-500 to-pink-500' },
    { label: 'Produits actifs', value: '48', change: '+5', icon: <Package className="w-5 h-5" />, color: 'from-orange-500 to-yellow-500' }
  ];

  const recentOrders = [
    { id: 'ORD-001', customer: 'Aminata K.', product: 'iPhone 15 Pro', amount: 850000, status: 'delivered' },
    { id: 'ORD-002', customer: 'Kouadio M.', product: 'Samsung Galaxy S24', amount: 650000, status: 'in_transit' },
    { id: 'ORD-003', customer: 'Fatou S.', product: 'MacBook Air M3', amount: 1200000, status: 'confirmed' },
    { id: 'ORD-004', customer: 'Ibrahim T.', product: 'AirPods Pro', amount: 180000, status: 'pending' }
  ];

  const upcomingLives = [
    { title: 'Vente Flash Smartphones', scheduled: '14:00', viewers: 0 },
    { title: 'Nouveautés Apple 2026', scheduled: '18:00', viewers: 0 },
    { title: 'Accessoires Gaming', scheduled: 'Demain 10:00', viewers: 0 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-green-500/20 text-green-400';
      case 'in_transit': return 'bg-blue-500/20 text-blue-400';
      case 'confirmed': return 'bg-purple-500/20 text-purple-400';
      case 'pending': return 'bg-yellow-500/20 text-yellow-400';
      default: return 'bg-slate-500/20 text-slate-400';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'delivered': return 'Livré';
      case 'in_transit': return 'En transit';
      case 'confirmed': return 'Confirmé';
      case 'pending': return 'En attente';
      default: return status;
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getPlanIcon = (slug: string) => {
    switch (slug) {
      case 'starter':
        return <Zap className="w-5 h-5" />;
      case 'pro':
        return <Crown className="w-5 h-5" />;
      case 'enterprise':
        return <Building2 className="w-5 h-5" />;
      default:
        return <Crown className="w-5 h-5" />;
    }
  };

  const getPlanGradient = (slug: string) => {
    switch (slug) {
      case 'starter':
        return 'from-blue-500 to-cyan-500';
      case 'pro':
        return 'from-orange-500 to-yellow-500';
      case 'enterprise':
        return 'from-purple-500 to-pink-500';
      default:
        return 'from-slate-500 to-slate-600';
    }
  };

  const daysRemaining = getDaysRemaining();

  return (
    <div className="fixed inset-0 z-50 bg-slate-900">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center">
              <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/>
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-white font-bold text-lg">Tableau de Bord Vendeur</h1>
                {isVerified && (
                  <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-500/20 rounded-full">
                    <CheckCircle className="w-3.5 h-3.5 text-blue-400" />
                    <span className="text-blue-400 text-xs font-medium">Vérifié</span>
                  </div>
                )}
                {plan && (
                  <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full bg-gradient-to-r ${getPlanGradient(plan.slug)}`}>
                    {getPlanIcon(plan.slug)}
                    <span className="text-white text-xs font-medium">{plan.name}</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Store className="w-3 h-3 text-purple-400" />
                <p className="text-purple-400 text-sm font-medium">{storeName}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-3 px-4 py-2 bg-slate-900/50 rounded-xl">
              {profile?.avatar_url ? (
                <img 
                  src={profile.avatar_url} 
                  alt={sellerName}
                  className="w-8 h-8 rounded-lg object-cover"
                />
              ) : (
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-sm font-bold">
                  {getInitials(sellerName)}
                </div>
              )}
              <div className="text-left">
                <p className="text-white text-sm font-medium">{sellerName}</p>
                <p className="text-slate-400 text-xs">{user?.email}</p>
              </div>
            </div>

            {/* Notification Settings Button */}
            <button
              onClick={() => setShowNotificationSettings(true)}
              className="p-2 text-slate-400 hover:text-white transition-colors relative"
              title="Paramètres de notifications"
            >
              <Bell className="w-5 h-5" />
            </button>

            <button 
              onClick={() => setShowGoLiveModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white font-semibold rounded-xl hover:shadow-lg transition-all"
            >
              <Video className="w-4 h-4" />
              <span className="hidden sm:inline">Démarrer un Live</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

        </div>


        {/* Tabs */}
        {/* Tabs */}
        <div className="flex gap-1 mt-4 bg-slate-900/50 p-1 rounded-xl w-fit overflow-x-auto">
          {[
            { id: 'overview', label: 'Aperçu', icon: <BarChart3 className="w-4 h-4" /> },
            { id: 'subscription', label: 'Abonnement', icon: <Crown className="w-4 h-4" />, highlight: !isSubscribed || isExpiringSoon },
            { id: 'analytics', label: 'Analytics', icon: <LineChart className="w-4 h-4" /> },
            { id: 'products', label: 'Produits', icon: <Package className="w-4 h-4" /> },
            { id: 'lives', label: 'Lives', icon: <Video className="w-4 h-4" /> },
            { id: 'orders', label: 'Commandes', icon: <ShoppingBag className="w-4 h-4" /> },
            { id: 'promotions', label: 'Promotions', icon: <Percent className="w-4 h-4" /> },
            { id: 'reviews', label: 'Avis', icon: <Star className="w-4 h-4" /> },
            { id: 'verification', label: 'Vérification', icon: <Shield className="w-4 h-4" />, badge: !isVerified }
          ].map((tab) => (


            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap relative ${
                activeTab === tab.id
                  ? 'bg-orange-500 text-white'
                  : tab.highlight
                  ? 'text-orange-400 hover:text-orange-300'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.icon}
              {tab.label}
              {tab.badge && (
                <span className="w-2 h-2 bg-red-500 rounded-full absolute top-1 right-1"></span>
              )}
              {tab.highlight && !tab.badge && (
                <span className="w-2 h-2 bg-orange-500 rounded-full absolute top-1 right-1 animate-pulse"></span>
              )}
            </button>
          ))}
        </div>
      </header>

      {/* Content */}
      <div className="p-6 overflow-y-auto h-[calc(100vh-160px)]">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Subscription Expiring Banner */}
            {isSubscribed && isExpiringSoon && (
              <div className="rounded-2xl p-6 border bg-orange-500/10 border-orange-500/30">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-orange-500/20 flex items-center justify-center">
                    <Clock className="w-6 h-6 text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-orange-400 font-semibold mb-1">Abonnement expire bientôt</h3>
                    <p className="text-slate-300 text-sm mb-3">
                      Votre abonnement {plan?.name} expire dans {daysRemaining} jour{daysRemaining > 1 ? 's' : ''}. Renouvelez maintenant pour continuer à profiter de toutes les fonctionnalités.
                    </p>
                    <button 
                      onClick={() => setActiveTab('subscription')}
                      className="px-4 py-2 bg-orange-500 text-white font-semibold rounded-xl hover:bg-orange-600 transition-all text-sm"
                    >
                      Renouveler maintenant
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Upgrade Banner for Free Users */}
            {!isSubscribed && (
              <div className="rounded-2xl p-6 border bg-gradient-to-r from-orange-500/20 to-yellow-500/20 border-orange-500/30">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center">
                    <Crown className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-orange-400 font-semibold mb-1">Passez au niveau supérieur!</h3>
                    <p className="text-slate-300 text-sm mb-3">
                      Débloquez plus de produits, lives illimités, et des outils avancés pour développer votre boutique.
                    </p>
                    <button 
                      onClick={() => setShowSubscriptionPlans(true)}
                      className="px-4 py-2 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all text-sm flex items-center gap-2"
                    >
                      <Crown className="w-4 h-4" />
                      Voir les plans
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Verification Banner */}
            {!isVerified && (
              <div className={`rounded-2xl p-6 border ${
                verificationStatus.status === 'pending' 
                  ? 'bg-yellow-500/10 border-yellow-500/30' 
                  : verificationStatus.status === 'rejected'
                  ? 'bg-red-500/10 border-red-500/30'
                  : 'bg-blue-500/10 border-blue-500/30'
              }`}>
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    verificationStatus.status === 'pending' 
                      ? 'bg-yellow-500/20' 
                      : verificationStatus.status === 'rejected'
                      ? 'bg-red-500/20'
                      : 'bg-blue-500/20'
                  }`}>
                    {verificationStatus.status === 'pending' ? (
                      <Clock className="w-6 h-6 text-yellow-400" />
                    ) : verificationStatus.status === 'rejected' ? (
                      <AlertCircle className="w-6 h-6 text-red-400" />
                    ) : (
                      <Shield className="w-6 h-6 text-blue-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className={`font-semibold mb-1 ${
                      verificationStatus.status === 'pending' 
                        ? 'text-yellow-400' 
                        : verificationStatus.status === 'rejected'
                        ? 'text-red-400'
                        : 'text-blue-400'
                    }`}>
                      {verificationStatus.status === 'pending' 
                        ? 'Vérification en cours' 
                        : verificationStatus.status === 'rejected'
                        ? 'Vérification refusée'
                        : 'Faites vérifier votre boutique'}
                    </h3>
                    <p className="text-slate-300 text-sm mb-3">
                      {verificationStatus.status === 'pending' 
                        ? 'Votre demande est en cours d\'examen. Vous recevrez une notification sous 48h.' 
                        : verificationStatus.status === 'rejected'
                        ? 'Votre demande a été refusée. Veuillez soumettre une nouvelle demande avec des documents valides.'
                        : 'Obtenez le badge vérifié pour gagner la confiance des acheteurs et augmenter vos ventes.'}
                    </p>
                    {verificationStatus.status !== 'pending' && (
                      <button 
                        onClick={() => setShowVerificationForm(true)}
                        className={`px-4 py-2 font-semibold rounded-xl transition-all text-sm ${
                          verificationStatus.status === 'rejected'
                            ? 'bg-red-500 text-white hover:bg-red-600'
                            : 'bg-blue-500 text-white hover:bg-blue-600'
                        }`}
                      >
                        {verificationStatus.status === 'rejected' ? 'Soumettre à nouveau' : 'Demander la vérification'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Welcome Banner */}
            <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-2xl p-6 border border-purple-500/30">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h2 className="text-white text-xl font-bold">Bienvenue, {sellerName.split(' ')[0]}!</h2>
                    {isVerified && (
                      <VerificationBadgeFull status="verified" />
                    )}
                  </div>
                  <p className="text-slate-300">
                    Voici un aperçu de votre activité sur PITCH. Continuez à développer votre boutique!
                  </p>

                </div>
                <button 
                  onClick={() => setActiveTab('analytics')}
                  className="hidden md:flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all"
                >
                  <LineChart className="w-4 h-4" />
                  Voir Analytics
                </button>
              </div>
            </div>

            {/* Subscription Status Card */}
            {isSubscribed && plan && (
              <div className={`rounded-2xl p-6 border bg-gradient-to-r ${getPlanGradient(plan.slug)}/10 border-white/10`}>
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-4">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${getPlanGradient(plan.slug)} flex items-center justify-center text-white`}>
                      {getPlanIcon(plan.slug)}
                    </div>
                    <div>
                      <p className="text-white font-bold text-lg">{plan.name}</p>
                      <p className="text-slate-400 text-sm flex items-center gap-2">
                        <Calendar className="w-3 h-3" />
                        {subscription?.auto_renew ? 'Renouvellement auto' : 'Expire'} le {subscription?.ends_at && new Date(subscription.ends_at).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'long'
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-slate-400 text-xs">Limites</p>
                      <p className="text-white text-sm">
                        {limits.maxProducts === -1 ? '∞' : limits.maxProducts} produits • {limits.maxLivesPerMonth === -1 ? '∞' : limits.maxLivesPerMonth} lives/mois
                      </p>
                    </div>
                    <button
                      onClick={() => setActiveTab('subscription')}
                      className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all text-sm font-medium"
                    >
                      Gérer
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Stock Alerts Banner */}
            {stockAlerts.filter(a => !a.is_read).length > 0 && (
              <div className="rounded-2xl p-4 border bg-red-500/10 border-red-500/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                      <AlertTriangle className="w-5 h-5 text-red-400" />
                    </div>
                    <div>
                      <h4 className="text-red-400 font-semibold">Alertes de Stock</h4>
                      <p className="text-slate-400 text-sm">
                        {stockAlerts.filter(a => a.alert_type === 'out_of_stock').length} produit(s) en rupture, {stockAlerts.filter(a => a.alert_type === 'low_stock').length} stock bas
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setActiveTab('analytics')}
                    className="px-4 py-2 bg-red-500/20 text-red-400 font-medium rounded-xl hover:bg-red-500/30 transition-all text-sm"
                  >
                    Voir les alertes
                  </button>
                </div>
              </div>
            )}

            {/* Sales Goals Progress */}
            {salesGoals.length > 0 && (
              <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-semibold flex items-center gap-2">
                    <Target className="w-5 h-5 text-orange-400" />
                    Objectifs du Mois
                  </h3>
                  <button 
                    onClick={() => setActiveTab('analytics')}
                    className="text-orange-500 text-sm font-medium flex items-center gap-1 hover:underline"
                  >
                    Gérer <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
                <div className="grid md:grid-cols-3 gap-4">
                  {salesGoals.map((goal) => {
                    const progress = (goal.current_value / goal.target_value) * 100;
                    return (
                      <div key={goal.id} className="p-4 bg-slate-900/50 rounded-xl">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-slate-400 text-sm">
                            {goal.goal_type === 'revenue' ? 'Chiffre d\'affaires' : 
                             goal.goal_type === 'orders' ? 'Commandes' : 
                             goal.goal_type === 'products_sold' ? 'Produits vendus' : 'Nouveaux clients'}
                          </span>
                          <span className={`text-sm font-medium ${progress >= 100 ? 'text-green-400' : 'text-orange-400'}`}>
                            {progress.toFixed(0)}%
                          </span>
                        </div>
                        <div className="h-2 bg-slate-700 rounded-full overflow-hidden mb-2">
                          <div 
                            className={`h-full rounded-full transition-all ${progress >= 100 ? 'bg-green-500' : 'bg-gradient-to-r from-orange-500 to-yellow-500'}`}
                            style={{ width: `${Math.min(100, progress)}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-white font-medium">
                            {goal.goal_type === 'revenue' ? formatPrice(goal.current_value) : goal.current_value}
                          </span>
                          <span className="text-slate-500">
                            / {goal.goal_type === 'revenue' ? formatPrice(goal.target_value) : goal.target_value}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {stats.map((stat, index) => (
                <div
                  key={index}
                  onClick={() => setActiveTab('analytics')}
                  className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700 cursor-pointer hover:border-slate-600 transition-all"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center text-white`}>
                      {stat.icon}
                    </div>
                    <span className="text-green-400 text-sm font-medium">{stat.change}</span>
                  </div>
                  <p className="text-2xl font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-slate-400 text-sm">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              {/* Recent Orders */}
              <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-white font-semibold">Commandes Récentes</h3>
                  <button 
                    onClick={() => setActiveTab('orders')}
                    className="text-orange-500 text-sm font-medium flex items-center gap-1 hover:underline"
                  >
                    Voir tout <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-4">
                  {recentOrders.map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                      <div>
                        <p className="text-white font-medium text-sm">{order.product}</p>
                        <p className="text-slate-400 text-xs">{order.customer} • {order.id}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-orange-500 font-bold text-sm">{formatPrice(order.amount)}</p>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusColor(order.status)}`}>
                          {getStatusLabel(order.status)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Upcoming Lives */}
              <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-white font-semibold">Lives Programmés</h3>
                  <button className="flex items-center gap-2 px-3 py-1.5 bg-slate-700 text-white text-sm rounded-lg hover:bg-slate-600 transition-colors">
                    <Plus className="w-4 h-4" />
                    Nouveau
                  </button>
                </div>
                <div className="space-y-4">
                  {upcomingLives.map((live, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center">
                          <Video className="w-5 h-5 text-red-400" />
                        </div>
                        <div>
                          <p className="text-white font-medium text-sm">{live.title}</p>
                          <p className="text-slate-400 text-xs flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {live.scheduled}
                          </p>
                        </div>
                      </div>
                      <button className="px-3 py-1.5 bg-orange-500 text-white text-sm font-medium rounded-lg hover:bg-orange-600 transition-colors">
                        Modifier
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
              <h3 className="text-white font-semibold mb-4">Actions Rapides</h3>
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                {[
                  { label: 'Ajouter un produit', icon: <Plus className="w-5 h-5" />, color: 'from-green-500 to-emerald-500', action: () => setActiveTab('products') },
                  { label: 'Programmer un live', icon: <Video className="w-5 h-5" />, color: 'from-red-500 to-pink-500', action: () => setActiveTab('lives') },
                  { label: 'Voir Analytics', icon: <LineChart className="w-5 h-5" />, color: 'from-blue-500 to-cyan-500', action: () => setActiveTab('analytics') },
                  { label: 'Abonnement', icon: <Crown className="w-5 h-5" />, color: 'from-orange-500 to-yellow-500', action: () => setActiveTab('subscription') },
                  { label: 'Commandes', icon: <ShoppingBag className="w-5 h-5" />, color: 'from-purple-500 to-pink-500', action: () => setActiveTab('orders') },
                  { label: 'Paramètres', icon: <Settings className="w-5 h-5" />, color: 'from-slate-500 to-slate-600', action: () => {} }
                ].map((action, index) => (
                  <button
                    key={index}
                    onClick={action.action}
                    className="flex flex-col items-center gap-3 p-4 bg-slate-900/50 rounded-xl border border-slate-700 hover:border-slate-600 transition-all group"
                  >
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center text-white group-hover:scale-110 transition-transform`}>
                      {action.icon}
                    </div>
                    <span className="text-slate-300 text-sm font-medium text-center">{action.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'subscription' && (
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Current Subscription */}
            <div className="text-center mb-8">
              <div className={`w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${plan ? getPlanGradient(plan.slug) : 'from-slate-500 to-slate-600'} flex items-center justify-center text-white`}>
                {plan ? getPlanIcon(plan.slug) : <Crown className="w-10 h-10" />}
              </div>
              <h2 className="text-white text-2xl font-bold mb-2">
                {isSubscribed ? `Plan ${plan?.name}` : 'Aucun abonnement actif'}
              </h2>
              <p className="text-slate-400">
                {isSubscribed 
                  ? `Votre abonnement est actif jusqu'au ${subscription?.ends_at && new Date(subscription.ends_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}`
                  : 'Choisissez un plan pour débloquer toutes les fonctionnalités'
                }
              </p>
            </div>

            {/* Current Plan Details */}
            {isSubscribed && plan && (
              <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                <h3 className="text-white font-semibold mb-4">Détails de votre abonnement</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                      <span className="text-slate-400">Plan</span>
                      <span className="text-white font-medium">{plan.name}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                      <span className="text-slate-400">Prix</span>
                      <span className="text-white font-medium">{formatPrice(plan.price)}/mois</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                      <span className="text-slate-400">Statut</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        subscription?.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {subscription?.status === 'active' ? 'Actif' : 'En cours d\'annulation'}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                      <span className="text-slate-400">Date de début</span>
                      <span className="text-white font-medium">
                        {subscription?.starts_at && new Date(subscription.starts_at).toLocaleDateString('fr-FR')}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                      <span className="text-slate-400">Prochaine facturation</span>
                      <span className="text-white font-medium">
                        {subscription?.ends_at && new Date(subscription.ends_at).toLocaleDateString('fr-FR')}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                      <span className="text-slate-400">Renouvellement auto</span>
                      <span className={`flex items-center gap-1 ${subscription?.auto_renew ? 'text-green-400' : 'text-slate-400'}`}>
                        {subscription?.auto_renew ? (
                          <>
                            <RefreshCw className="w-4 h-4" />
                            Activé
                          </>
                        ) : 'Désactivé'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Plan Limits */}
            <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
              <h3 className="text-white font-semibold mb-4">Vos limites actuelles</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 bg-slate-900/50 rounded-xl text-center">
                  <Package className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{limits.maxProducts === -1 ? '∞' : limits.maxProducts}</p>
                  <p className="text-slate-400 text-sm">Produits max</p>
                </div>
                <div className="p-4 bg-slate-900/50 rounded-xl text-center">
                  <Video className="w-8 h-8 text-red-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{limits.maxLivesPerMonth === -1 ? '∞' : limits.maxLivesPerMonth}</p>
                  <p className="text-slate-400 text-sm">Lives/mois</p>
                </div>
                <div className="p-4 bg-slate-900/50 rounded-xl text-center">
                  <Shield className={`w-8 h-8 mx-auto mb-2 ${limits.hasVerificationBadge ? 'text-green-400' : 'text-slate-600'}`} />
                  <p className="text-2xl font-bold text-white">{limits.hasVerificationBadge ? 'Oui' : 'Non'}</p>
                  <p className="text-slate-400 text-sm">Badge vérifié</p>
                </div>
                <div className="p-4 bg-slate-900/50 rounded-xl text-center">
                  <BarChart3 className={`w-8 h-8 mx-auto mb-2 ${limits.hasAdvancedAnalytics ? 'text-purple-400' : 'text-slate-600'}`} />
                  <p className="text-2xl font-bold text-white">{limits.hasAdvancedAnalytics ? 'Avancé' : 'Basic'}</p>
                  <p className="text-slate-400 text-sm">Analytics</p>
                </div>
              </div>
            </div>

            {/* Upgrade/Change Plan Button */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => setShowSubscriptionPlans(true)}
                className="px-8 py-4 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all flex items-center justify-center gap-2"
              >
                <Crown className="w-5 h-5" />
                {isSubscribed ? 'Changer de plan' : 'Choisir un plan'}
              </button>
              {isSubscribed && (
                <button
                  onClick={() => setShowSubscriptionPlans(true)}
                  className="px-8 py-4 bg-slate-700 text-white font-bold rounded-xl hover:bg-slate-600 transition-all"
                >
                  Voir tous les plans
                </button>
              )}
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <SellerAnalytics />
        )}

        {activeTab === 'products' && (
          <SellerProductsTab />
        )}


        {activeTab === 'lives' && (
          <div className="space-y-6">
            {/* Live Limits Banner */}
            <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-red-500 to-pink-500 flex items-center justify-center text-white">
                    <Video className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg">Gestion des Lives</h3>
                    <p className="text-slate-400 text-sm">
                      {liveLimits ? (
                        liveLimits.maxLives === -1 
                          ? 'Lives illimités ce mois' 
                          : `${liveLimits.livesUsed}/${liveLimits.maxLives} lives utilisés ce mois`
                      ) : (
                        `${limits.maxLivesPerMonth === -1 ? 'Illimité' : limits.maxLivesPerMonth} lives/mois`
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {liveLimits && liveLimits.maxLives !== -1 && liveLimits.livesUsed >= liveLimits.maxLives && (
                    <button
                      onClick={() => setShowSubscriptionPlans(true)}
                      className="px-4 py-2 bg-orange-500/20 text-orange-400 font-medium rounded-xl hover:bg-orange-500/30 transition-all text-sm flex items-center gap-2"
                    >
                      <Crown className="w-4 h-4" />
                      Upgrade
                    </button>
                  )}
                  <button
                    onClick={() => setShowScheduleForm(true)}
                    disabled={liveLimits && liveLimits.maxLives !== -1 && liveLimits.livesUsed >= liveLimits.maxLives}
                    className="px-4 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Plus className="w-4 h-4" />
                    Programmer un Live
                  </button>
                </div>
              </div>
              
              {/* Progress Bar */}
              {liveLimits && liveLimits.maxLives !== -1 && (
                <div className="mt-4">
                  <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        liveLimits.livesUsed >= liveLimits.maxLives 
                          ? 'bg-red-500' 
                          : liveLimits.livesUsed >= liveLimits.maxLives * 0.8 
                          ? 'bg-yellow-500' 
                          : 'bg-gradient-to-r from-red-500 to-pink-500'
                      }`}
                      style={{ width: `${Math.min(100, (liveLimits.livesUsed / liveLimits.maxLives) * 100)}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>

            {/* Sub-tabs for Lives */}
            {/* Sub-tabs for Lives */}
            <div className="flex gap-2 flex-wrap">
              <button
                onClick={() => setLivesSubTab('upcoming')}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium transition-all ${
                  livesSubTab === 'upcoming'
                    ? 'bg-gradient-to-r from-red-500 to-pink-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Video className="w-4 h-4" />
                Lives Actifs
                <span className={`px-2 py-0.5 rounded-full text-xs ${
                  livesSubTab === 'upcoming' ? 'bg-white/20' : 'bg-slate-700'
                }`}>
                  {lives.filter(l => l.status !== 'ended' && l.status !== 'cancelled').length}
                </span>
              </button>
              <button
                onClick={() => setLivesSubTab('replays')}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium transition-all ${
                  livesSubTab === 'replays'
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <RotateCcw className="w-4 h-4" />
                Rediffusions
                <span className={`px-2 py-0.5 rounded-full text-xs ${
                  livesSubTab === 'replays' ? 'bg-white/20' : 'bg-slate-700'
                }`}>
                  {lives.filter(l => l.status === 'ended').length}
                </span>
              </button>
              <button
                onClick={() => setLivesSubTab('recordings')}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium transition-all ${
                  livesSubTab === 'recordings'
                    ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Film className="w-4 h-4" />
                Enregistrements
              </button>
              {/* Clips tab hidden - secondary feature for MVP */}
            </div>


            {/* Upcoming/Active Lives */}
            {livesSubTab === 'upcoming' && (

              <div className="grid gap-4">
                {lives.filter(l => l.status !== 'ended' && l.status !== 'cancelled').length === 0 ? (
                  <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
                    <Video className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                    <h3 className="text-white text-xl font-semibold mb-2">Aucun live programmé</h3>
                    <p className="text-slate-400 mb-6">Programmez votre premier live pour commencer à vendre en direct</p>
                    <button
                      onClick={() => setShowScheduleForm(true)}
                      className="px-6 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all"
                    >
                      Programmer mon premier live
                    </button>
                  </div>
                ) : (
                  lives.filter(l => l.status !== 'ended' && l.status !== 'cancelled').map((live) => (
                    <div key={live.id} className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex items-start gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                            live.status === 'live' 
                              ? 'bg-red-500/20' 
                              : 'bg-blue-500/20'
                          }`}>
                            {live.status === 'live' ? (
                              <Radio className="w-6 h-6 text-red-400" />
                            ) : (
                              <Video className="w-6 h-6 text-blue-400" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="text-white font-semibold">{live.title}</h4>
                              {getLiveStatusBadge(live.status)}
                            </div>
                            <p className="text-slate-400 text-sm mb-2">{live.description || 'Pas de description'}</p>
                            <div className="flex items-center gap-4 text-sm">
                              <span className="text-slate-500 flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5" />
                                {live.scheduled_at 
                                  ? new Date(live.scheduled_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
                                  : 'Non programmé'
                                }
                              </span>
                              {live.status === 'live' && (
                                <>
                                  <span className="text-slate-500 flex items-center gap-1">
                                    <Users className="w-3.5 h-3.5" />
                                    {live.viewer_count} spectateurs
                                  </span>
                                  <span className="text-slate-500 flex items-center gap-1">
                                    <TrendingUp className="w-3.5 h-3.5" />
                                    {live.peak_viewers} pic
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {live.status === 'scheduled' && (
                            <>
                              <button
                                onClick={() => handleStartLive(live.id)}
                                disabled={liveLoading}
                                className="px-4 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white font-semibold rounded-xl hover:shadow-lg transition-all flex items-center gap-2 disabled:opacity-50"
                              >
                                <Play className="w-4 h-4" />
                                Démarrer
                              </button>
                              <button
                                onClick={() => handleCancelLive(live.id)}
                                disabled={liveLoading}
                                className="p-2 text-slate-400 hover:text-red-400 transition-colors"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </>
                          )}
                          {live.status === 'live' && (
                            <button
                              onClick={() => {
                                setEndingLiveId(live.id);
                                setShowEndLiveModal(true);
                              }}
                              disabled={liveLoading}
                              className="px-4 py-2 bg-red-500 text-white font-semibold rounded-xl hover:bg-red-600 transition-all flex items-center gap-2 disabled:opacity-50"
                            >
                              <StopCircle className="w-4 h-4" />
                              Terminer
                            </button>
                          )}
                        </div>
                      </div>
                      
                      {/* Products in this live */}
                      {live.live_stream_products && live.live_stream_products.length > 0 && (
                        <div className="mt-4 pt-4 border-t border-slate-700">
                          <p className="text-slate-400 text-sm mb-2">Produits ({live.live_stream_products.length})</p>
                          <div className="flex gap-2 overflow-x-auto pb-2">
                            {live.live_stream_products.map((product) => (
                              <div key={product.id} className="flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden bg-slate-700">
                                {product.product_image ? (
                                  <img src={product.product_image} alt={product.product_name} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center">
                                    <Package className="w-6 h-6 text-slate-500" />
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Replays Tab */}
            {livesSubTab === 'replays' && (
              <div className="space-y-6">
                {/* Replay Info Banner */}
                <div className="bg-purple-500/10 rounded-2xl p-4 border border-purple-500/30">
                  <div className="flex items-start gap-3">
                    <RotateCcw className="w-5 h-5 text-purple-400 mt-0.5" />
                    <div>
                      <p className="text-purple-300 font-medium">Rediffusions</p>
                      <p className="text-slate-400 text-sm">
                        Activez la rediffusion pour permettre aux acheteurs de revoir vos lives et acheter les produits présentés.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Replays List */}
                <div className="grid gap-4">
                  {lives.filter(l => l.status === 'ended').length === 0 ? (
                    <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
                      <RotateCcw className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                      <h3 className="text-white text-xl font-semibold mb-2">Aucune rediffusion</h3>
                      <p className="text-slate-400">Vos lives terminés apparaîtront ici avec l'option de rediffusion</p>
                    </div>
                  ) : (
                    lives.filter(l => l.status === 'ended').map((live) => (
                      <div key={live.id} className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                              <RotateCcw className="w-6 h-6 text-purple-400" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1 flex-wrap">
                                <h4 className="text-white font-semibold">{live.title}</h4>
                                {live.replay_enabled ? (
                                  <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full flex items-center gap-1">
                                    <CheckCircle className="w-3 h-3" />
                                    Rediffusion active
                                  </span>
                                ) : (
                                  <span className="px-2 py-1 bg-slate-500/20 text-slate-400 text-xs rounded-full">
                                    Rediffusion désactivée
                                  </span>
                                )}
                              </div>
                              <p className="text-slate-400 text-sm mb-3">{live.description || 'Pas de description'}</p>
                              
                              {/* Stats Grid */}
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                <div className="bg-slate-900/50 rounded-lg p-3 text-center">
                                  <p className="text-slate-500 text-xs mb-1">Durée</p>
                                  <p className="text-white font-medium text-sm">
                                    {live.duration_seconds 
                                      ? `${Math.floor(live.duration_seconds / 60)} min`
                                      : '-'
                                    }
                                  </p>
                                </div>
                                <div className="bg-slate-900/50 rounded-lg p-3 text-center">
                                  <p className="text-slate-500 text-xs mb-1">Pic spectateurs</p>
                                  <p className="text-white font-medium text-sm">{live.peak_viewers || 0}</p>
                                </div>
                                <div className="bg-slate-900/50 rounded-lg p-3 text-center">
                                  <p className="text-slate-500 text-xs mb-1">Vues replay</p>
                                  <p className="text-purple-400 font-medium text-sm">{live.replay_views || 0}</p>
                                </div>
                                <div className="bg-slate-900/50 rounded-lg p-3 text-center">
                                  <p className="text-slate-500 text-xs mb-1">Revenus</p>
                                  <p className="text-green-400 font-medium text-sm">{formatPrice(live.total_revenue || 0)}</p>
                                </div>
                              </div>

                              <div className="flex items-center gap-4 mt-3 text-sm text-slate-500">
                                <span className="flex items-center gap-1">
                                  <Calendar className="w-3.5 h-3.5" />
                                  Terminé le {live.ended_at && new Date(live.ended_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}
                                </span>
                                <span className="flex items-center gap-1">
                                  <ShoppingBag className="w-3.5 h-3.5" />
                                  {live.total_sales || 0} ventes
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          {/* Replay Toggle */}
                          <div className="flex flex-col items-end gap-3">
                            <button
                              onClick={async () => {
                                await toggleReplay(live.id, !live.replay_enabled);
                              }}
                              disabled={liveLoading}
                              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
                                live.replay_enabled
                                  ? 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                              }`}
                            >
                              {live.replay_enabled ? (
                                <>
                                  <ToggleRight className="w-5 h-5" />
                                  Désactiver
                                </>
                              ) : (
                                <>
                                  <ToggleLeft className="w-5 h-5" />
                                  Activer
                                </>
                              )}
                            </button>
                            
                            {live.replay_enabled && (
                              <button
                                onClick={() => {
                                  const url = `${window.location.origin}?replay=${live.id}`;
                                  navigator.clipboard.writeText(url);
                                  toast({
                                    title: "Lien copié!",
                                    description: "Le lien de la rediffusion a été copié"
                                  });
                                }}
                                className="flex items-center gap-2 px-3 py-1.5 text-slate-400 hover:text-white text-sm transition-colors"
                              >
                                <Copy className="w-4 h-4" />
                                Copier le lien
                              </button>
                            )}
                          </div>
                        </div>
                        
                        {/* Products in this live */}
                        {live.live_stream_products && live.live_stream_products.length > 0 && (
                          <div className="mt-4 pt-4 border-t border-slate-700">
                            <p className="text-slate-400 text-sm mb-2">Produits présentés ({live.live_stream_products.length})</p>
                            <div className="flex gap-2 overflow-x-auto pb-2">
                              {live.live_stream_products.map((product) => (
                                <div key={product.id} className="flex-shrink-0">
                                  <div className="w-16 h-16 rounded-lg overflow-hidden bg-slate-700 mb-1">
                                    {product.product_image ? (
                                      <img src={product.product_image} alt={product.product_name} className="w-full h-full object-cover" />
                                    ) : (
                                      <div className="w-full h-full flex items-center justify-center">
                                        <Package className="w-6 h-6 text-slate-500" />
                                      </div>
                                    )}
                                  </div>
                                  <p className="text-xs text-slate-500 text-center">{product.units_sold || 0} vendus</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}



            {/* Recordings Tab */}
            {livesSubTab === 'recordings' && (
              <RecordingsTab />
            )}

            {/* Clips Tab */}
            {livesSubTab === 'clips' && (
              <ClipsTab />
            )}

            {/* End Live Modal with Replay Option */}

            {/* End Live Modal with Replay Option */}
            {showEndLiveModal && endingLiveId && (
              <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
                <div className="bg-slate-800 rounded-2xl w-full max-w-md">
                  <div className="p-6 border-b border-slate-700">
                    <div className="flex items-center justify-between">
                      <h3 className="text-white text-xl font-bold">Terminer le Live</h3>
                      <button onClick={() => setShowEndLiveModal(false)} className="text-slate-400 hover:text-white">
                        <X className="w-6 h-6" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="p-6 space-y-6">
                    <p className="text-slate-300">
                      Voulez-vous terminer ce live? Vous pouvez choisir d'activer la rediffusion pour permettre aux acheteurs de revoir le live.
                    </p>
                    
                    {/* Replay Toggle */}
                    <div 
                      onClick={() => setEnableReplayOnEnd(!enableReplayOnEnd)}
                      className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                        enableReplayOnEnd 
                          ? 'bg-purple-500/10 border-purple-500' 
                          : 'bg-slate-900/50 border-slate-700 hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                            enableReplayOnEnd ? 'bg-purple-500/20' : 'bg-slate-700'
                          }`}>
                            <RotateCcw className={`w-5 h-5 ${enableReplayOnEnd ? 'text-purple-400' : 'text-slate-400'}`} />
                          </div>
                          <div>
                            <p className={`font-medium ${enableReplayOnEnd ? 'text-purple-300' : 'text-slate-300'}`}>
                              Activer la rediffusion
                            </p>
                            <p className="text-slate-500 text-sm">
                              Les acheteurs pourront revoir ce live
                            </p>
                          </div>
                        </div>
                        <div className={`w-12 h-7 rounded-full relative transition-colors ${
                          enableReplayOnEnd ? 'bg-purple-500' : 'bg-slate-600'
                        }`}>
                          <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                            enableReplayOnEnd ? 'right-1' : 'left-1'
                          }`}></div>
                        </div>
                      </div>
                    </div>
                    
                    {enableReplayOnEnd && (
                      <div className="bg-purple-500/10 rounded-xl p-4 border border-purple-500/30">
                        <div className="flex items-start gap-2">
                          <CheckCircle className="w-5 h-5 text-purple-400 mt-0.5" />
                          <div>
                            <p className="text-purple-300 font-medium text-sm">Avantages de la rediffusion</p>
                            <ul className="text-slate-400 text-sm mt-1 space-y-1">
                              <li>• Les acheteurs peuvent revoir les produits</li>
                              <li>• Le chat sera synchronisé avec la vidéo</li>
                              <li>• Continuez à générer des ventes</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="p-6 border-t border-slate-700 flex justify-end gap-3">
                    <button
                      onClick={() => setShowEndLiveModal(false)}
                      className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
                    >
                      Annuler
                    </button>
                    <button
                      onClick={async () => {
                        await endLive(endingLiveId, enableReplayOnEnd);
                        setShowEndLiveModal(false);
                        setEndingLiveId(null);
                      }}
                      disabled={liveLoading}
                      className="px-6 py-3 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      {liveLoading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      ) : (
                        <>
                          <StopCircle className="w-5 h-5" />
                          Terminer le Live
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Schedule Form Modal */}
            {showScheduleForm && (
              <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
                <div className="bg-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                  <div className="p-6 border-b border-slate-700">
                    <div className="flex items-center justify-between">
                      <h3 className="text-white text-xl font-bold">Programmer un Live</h3>
                      <button onClick={() => setShowScheduleForm(false)} className="text-slate-400 hover:text-white">
                        <X className="w-6 h-6" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="p-6 space-y-6">
                    <div>
                      <label className="block text-white font-medium mb-2">Titre du Live *</label>
                      <input
                        type="text"
                        value={scheduleForm.title}
                        onChange={(e) => setScheduleForm(prev => ({ ...prev, title: e.target.value }))}
                        placeholder="Ex: Vente Flash Smartphones"
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-white font-medium mb-2">Description</label>
                      <textarea
                        value={scheduleForm.description}
                        onChange={(e) => setScheduleForm(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Décrivez votre live..."
                        rows={3}
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 resize-none"
                      />
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-white font-medium mb-2">Date et Heure *</label>
                        <input
                          type="datetime-local"
                          value={scheduleForm.scheduledAt}
                          onChange={(e) => setScheduleForm(prev => ({ ...prev, scheduledAt: e.target.value }))}
                          className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                        />
                      </div>
                      <div>
                        <label className="block text-white font-medium mb-2">Catégorie</label>
                        <select
                          value={scheduleForm.category}
                          onChange={(e) => setScheduleForm(prev => ({ ...prev, category: e.target.value }))}
                          className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                        >
                          {categories.map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-white font-medium mb-2">Produits à présenter</label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-h-48 overflow-y-auto p-2 bg-slate-900 rounded-xl">
                        {mockProducts.map(product => (
                          <label
                            key={product.id}
                            className={`relative cursor-pointer rounded-xl overflow-hidden border-2 transition-all ${
                              scheduleForm.selectedProducts.includes(product.id)
                                ? 'border-orange-500'
                                : 'border-transparent hover:border-slate-600'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={scheduleForm.selectedProducts.includes(product.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setScheduleForm(prev => ({ ...prev, selectedProducts: [...prev.selectedProducts, product.id] }));
                                } else {
                                  setScheduleForm(prev => ({ ...prev, selectedProducts: prev.selectedProducts.filter(id => id !== product.id) }));
                                }
                              }}
                              className="sr-only"
                            />
                            <img src={product.image} alt={product.name} className="w-full aspect-square object-cover" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-2">
                              <p className="text-white text-xs font-medium line-clamp-2">{product.name}</p>
                            </div>
                            {scheduleForm.selectedProducts.includes(product.id) && (
                              <div className="absolute top-2 right-2 w-5 h-5 bg-orange-500 rounded-full flex items-center justify-center">
                                <CheckCircle className="w-3 h-3 text-white" />
                              </div>
                            )}
                          </label>
                        ))}
                      </div>
                      <p className="text-slate-500 text-sm mt-2">{scheduleForm.selectedProducts.length} produit(s) sélectionné(s)</p>
                    </div>
                  </div>
                  
                  <div className="p-6 border-t border-slate-700 flex justify-end gap-3">
                    <button
                      onClick={() => setShowScheduleForm(false)}
                      className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
                    >
                      Annuler
                    </button>
                    <button
                      onClick={handleScheduleLive}
                      disabled={liveLoading}
                      className="px-6 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      {liveLoading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      ) : (
                        <>
                          <Calendar className="w-5 h-5" />
                          Programmer
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}




        {activeTab === 'orders' && (
          <div className="space-y-6">
            {/* Link to full order management */}
            <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-2xl p-6 border border-purple-500/30">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white">
                    <ShoppingBag className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg">Gestion Avancée des Commandes</h3>
                    <p className="text-slate-400 text-sm">Accédez au tableau de bord complet pour gérer vos commandes</p>
                  </div>
                </div>
                <Link
                  to="/seller/orders"
                  onClick={onClose}
                  className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-purple-500/30 transition-all flex items-center gap-2"
                >
                  <ExternalLink className="w-5 h-5" />
                  Ouvrir
                </Link>
              </div>
            </div>
            
            <SellerOrdersTab />
          </div>
        )}
        {activeTab === 'promotions' && (
          <PromoCodesTab />
        )}

        {activeTab === 'reviews' && (
          <SellerReviewsTab />
        )}


        {activeTab === 'verification' && (
          <div className="max-w-2xl mx-auto">

            {isVerified ? (
              <div className="text-center py-12">
                <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center">
                  <CheckCircle className="w-12 h-12 text-blue-500" />
                </div>
                <VerificationBadgeFull status="verified" className="mb-4" />
                <h3 className="text-white text-2xl font-bold mb-2">Vous êtes vérifié!</h3>
                <p className="text-slate-400 mb-6">
                  Votre compte vendeur a été vérifié. Le badge de vérification est visible sur votre profil et vos produits.
                </p>
                <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700 text-left">
                  <h4 className="text-white font-semibold mb-4">Avantages de la vérification</h4>
                  <ul className="space-y-3">
                    {[
                      'Badge vérifié visible sur votre profil',
                      'Confiance accrue des acheteurs',
                      'Meilleur classement dans les recherches',
                      'Accès aux fonctionnalités premium',
                      'Support prioritaire'
                    ].map((benefit, index) => (
                      <li key={index} className="flex items-center gap-3 text-slate-300">
                        <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center">
                    <Shield className="w-10 h-10 text-blue-500" />
                  </div>
                  <h3 className="text-white text-2xl font-bold mb-2">Vérification Vendeur</h3>
                  <p className="text-slate-400">
                    Faites vérifier votre boutique pour gagner la confiance des acheteurs
                  </p>
                </div>

                {verificationStatus.status === 'pending' ? (
                  <div className="bg-yellow-500/10 rounded-2xl p-6 border border-yellow-500/30 text-center">
                    <Clock className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                    <h4 className="text-yellow-400 font-semibold text-lg mb-2">Demande en cours</h4>
                    <p className="text-slate-300 mb-4">
                      Votre demande de vérification est en cours d'examen. Notre équipe vous contactera sous 48h.
                    </p>
                    {verificationStatus.submittedAt && (
                      <p className="text-slate-500 text-sm">
                        Soumise le {new Date(verificationStatus.submittedAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric'
                        })}
                      </p>
                    )}
                  </div>
                ) : (
                  <>
                    <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                      <h4 className="text-white font-semibold mb-4">Pourquoi se faire vérifier?</h4>
                      <ul className="space-y-3">
                        {[
                          'Badge vérifié visible sur votre profil et produits',
                          'Confiance accrue des acheteurs (+40% de conversions)',
                          'Meilleur classement dans les résultats de recherche',
                          'Accès aux fonctionnalités premium',
                          'Support client prioritaire'
                        ].map((benefit, index) => (
                          <li key={index} className="flex items-center gap-3 text-slate-300">
                            <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
                            {benefit}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                      <h4 className="text-white font-semibold mb-4">Documents requis</h4>
                      <ul className="space-y-3">
                        {[
                          'Pièce d\'identité valide (CNI, Passeport)',
                          'Registre de commerce (pour les entreprises)',
                          'Attestation fiscale (optionnel)'
                        ].map((doc, index) => (
                          <li key={index} className="flex items-center gap-3 text-slate-300">
                            <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-xs font-bold">
                              {index + 1}
                            </div>
                            {doc}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <button
                      onClick={() => setShowVerificationForm(true)}
                      className="w-full py-4 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-blue-500/30 transition-all flex items-center justify-center gap-2"
                    >
                      <Shield className="w-5 h-5" />
                      Commencer la vérification
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Verification Form Modal */}
      <SellerVerificationForm
        isOpen={showVerificationForm}
        onClose={() => setShowVerificationForm(false)}
        onSuccess={() => {
          fetchVerificationStatus();
          refreshProfile();
        }}
      />

      {/* Subscription Plans Modal */}
      <SubscriptionPlans
        isOpen={showSubscriptionPlans}
        onClose={() => setShowSubscriptionPlans(false)}
        onSubscriptionChange={() => {
          refreshSubscription();
        }}
      />

      {/* Go Live Modal */}
      <GoLiveModal
        isOpen={showGoLiveModal}
        onClose={() => setShowGoLiveModal(false)}
        onLiveStarted={(liveId) => {
          console.log('Live started:', liveId);
          fetchSellerLives();
        }}
        onLiveEnded={() => {
          fetchSellerLives();
        }}
      />

      {/* Seller Notification Settings Modal */}
      <SellerNotificationSettings
        open={showNotificationSettings}
        onOpenChange={setShowNotificationSettings}
      />
    </div>
  );
};


export default SellerDashboard;
