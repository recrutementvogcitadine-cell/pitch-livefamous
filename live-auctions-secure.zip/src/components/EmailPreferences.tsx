import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Mail, 
  MailCheck, 
  MailX, 
  Package, 
  Truck, 
  CheckCircle2, 
  XCircle, 
  MessageSquare, 
  Video, 
  Tag, 
  Newspaper,
  ShoppingBag,
  Star,
  AlertTriangle,
  Users,
  Loader2,
  Save
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';

interface EmailPreferences {
  email_enabled: boolean;
  // Buyer preferences
  order_confirmation_email: boolean;
  shipping_update_email: boolean;
  delivery_confirmation_email: boolean;
  order_cancelled_email: boolean;
  new_message_email: boolean;
  live_reminder_email: boolean;
  promo_email: boolean;
  weekly_digest_email: boolean;
  marketing_emails: boolean;
  // Seller preferences
  seller_new_order_email: boolean;
  seller_order_cancelled_email: boolean;
  seller_buyer_message_email: boolean;
  seller_low_stock_email: boolean;
  seller_new_review_email: boolean;
  seller_new_follower_email: boolean;
}

const defaultPreferences: EmailPreferences = {
  email_enabled: true,
  order_confirmation_email: true,
  shipping_update_email: true,
  delivery_confirmation_email: true,
  order_cancelled_email: true,
  new_message_email: true,
  live_reminder_email: true,
  promo_email: true,
  weekly_digest_email: false,
  marketing_emails: true,
  seller_new_order_email: true,
  seller_order_cancelled_email: true,
  seller_buyer_message_email: false,
  seller_low_stock_email: true,
  seller_new_review_email: true,
  seller_new_follower_email: false,
};

export function EmailPreferences() {
  const { user, profile } = useAuth();
  const [preferences, setPreferences] = useState<EmailPreferences>(defaultPreferences);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [originalPreferences, setOriginalPreferences] = useState<EmailPreferences>(defaultPreferences);

  const isSeller = profile?.is_seller || profile?.role === 'seller';

  useEffect(() => {
    if (user) {
      fetchPreferences();
    }
  }, [user]);

  const fetchPreferences = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'get_preferences', user_id: user.id }
      });

      if (error) throw error;

      if (data?.preferences) {
        const prefs = {
          email_enabled: data.preferences.email_enabled ?? true,
          order_confirmation_email: data.preferences.order_confirmation_email ?? true,
          shipping_update_email: data.preferences.shipping_update_email ?? true,
          delivery_confirmation_email: data.preferences.delivery_confirmation_email ?? true,
          order_cancelled_email: data.preferences.order_cancelled_email ?? true,
          new_message_email: data.preferences.new_message_email ?? true,
          live_reminder_email: data.preferences.live_reminder_email ?? true,
          promo_email: data.preferences.promo_email ?? true,
          weekly_digest_email: data.preferences.weekly_digest_email ?? false,
          marketing_emails: data.preferences.marketing_emails ?? true,
          seller_new_order_email: data.preferences.seller_new_order_email ?? true,
          seller_order_cancelled_email: data.preferences.seller_order_cancelled_email ?? true,
          seller_buyer_message_email: data.preferences.seller_buyer_message_email ?? false,
          seller_low_stock_email: data.preferences.seller_low_stock_email ?? true,
          seller_new_review_email: data.preferences.seller_new_review_email ?? true,
          seller_new_follower_email: data.preferences.seller_new_follower_email ?? false,
        };
        setPreferences(prefs);
        setOriginalPreferences(prefs);
      }
    } catch (error) {
      console.error('Error fetching email preferences:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger vos préférences email",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePreferenceChange = (key: keyof EmailPreferences, value: boolean) => {
    setPreferences(prev => {
      const newPrefs = { ...prev, [key]: value };
      setHasChanges(JSON.stringify(newPrefs) !== JSON.stringify(originalPreferences));
      return newPrefs;
    });
  };

  const handleMasterToggle = (enabled: boolean) => {
    setPreferences(prev => {
      const newPrefs = { ...prev, email_enabled: enabled };
      setHasChanges(JSON.stringify(newPrefs) !== JSON.stringify(originalPreferences));
      return newPrefs;
    });
  };

  const savePreferences = async () => {
    if (!user) return;

    setSaving(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { 
          action: 'update_preferences', 
          user_id: user.id, 
          preferences 
        }
      });

      if (error) throw error;

      setOriginalPreferences(preferences);
      setHasChanges(false);
      
      toast({
        title: "Préférences sauvegardées",
        description: "Vos préférences email ont été mises à jour"
      });
    } catch (error) {
      console.error('Error saving email preferences:', error);
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder vos préférences",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const PreferenceItem = ({ 
    icon: Icon, 
    label, 
    description, 
    preferenceKey,
    disabled = false
  }: { 
    icon: React.ElementType; 
    label: string; 
    description: string; 
    preferenceKey: keyof EmailPreferences;
    disabled?: boolean;
  }) => (
    <div className={`flex items-center justify-between py-3 ${disabled ? 'opacity-50' : ''}`}>
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/30">
          <Icon className="w-4 h-4 text-purple-600 dark:text-purple-400" />
        </div>
        <div>
          <Label className="font-medium">{label}</Label>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      <Switch
        checked={preferences[preferenceKey]}
        onCheckedChange={(checked) => handlePreferenceChange(preferenceKey, checked)}
        disabled={disabled || !preferences.email_enabled}
      />
    </div>
  );

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Master Email Toggle */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Notifications par Email
          </CardTitle>
          <CardDescription>
            Gérez les emails que vous recevez de LiveSell
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950/30 dark:to-pink-950/30 rounded-lg border">
            <div className="flex items-center gap-3">
              {preferences.email_enabled ? (
                <div className="p-2 rounded-full bg-green-100 dark:bg-green-900/30">
                  <MailCheck className="w-5 h-5 text-green-600" />
                </div>
              ) : (
                <div className="p-2 rounded-full bg-red-100 dark:bg-red-900/30">
                  <MailX className="w-5 h-5 text-red-600" />
                </div>
              )}
              <div>
                <p className="font-medium">
                  {preferences.email_enabled ? 'Emails activés' : 'Emails désactivés'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {preferences.email_enabled 
                    ? 'Vous recevez des emails pour les événements importants'
                    : 'Vous ne recevrez aucun email de notification'}
                </p>
              </div>
            </div>
            <Switch
              checked={preferences.email_enabled}
              onCheckedChange={handleMasterToggle}
            />
          </div>

          {!preferences.email_enabled && (
            <Alert className="mt-4" variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Tous les emails de notification sont désactivés. Vous ne recevrez pas d'emails 
                pour vos commandes, messages ou alertes importantes.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Order Notifications */}
      <Card className={!preferences.email_enabled ? 'opacity-60' : ''}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Package className="w-5 h-5 text-blue-600" />
            Commandes
          </CardTitle>
          <CardDescription>
            Emails concernant vos achats et commandes
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-1">
          <PreferenceItem
            icon={CheckCircle2}
            label="Confirmation de commande"
            description="Email de confirmation après chaque achat"
            preferenceKey="order_confirmation_email"
          />
          <Separator />
          <PreferenceItem
            icon={Truck}
            label="Mises à jour d'expédition"
            description="Notifications quand votre commande est expédiée"
            preferenceKey="shipping_update_email"
          />
          <Separator />
          <PreferenceItem
            icon={CheckCircle2}
            label="Confirmation de livraison"
            description="Email quand votre commande est livrée"
            preferenceKey="delivery_confirmation_email"
          />
          <Separator />
          <PreferenceItem
            icon={XCircle}
            label="Annulation de commande"
            description="Notification si une commande est annulée"
            preferenceKey="order_cancelled_email"
          />
        </CardContent>
      </Card>

      {/* Communication Notifications */}
      <Card className={!preferences.email_enabled ? 'opacity-60' : ''}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <MessageSquare className="w-5 h-5 text-green-600" />
            Communication
          </CardTitle>
          <CardDescription>
            Emails pour les messages et interactions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-1">
          <PreferenceItem
            icon={MessageSquare}
            label="Nouveaux messages"
            description="Email quand vous recevez un message d'un vendeur"
            preferenceKey="new_message_email"
          />
          <Separator />
          <PreferenceItem
            icon={Video}
            label="Rappels de lives"
            description="Email avant le début d'un live que vous suivez"
            preferenceKey="live_reminder_email"
          />
        </CardContent>
      </Card>

      {/* Marketing Notifications */}
      <Card className={!preferences.email_enabled ? 'opacity-60' : ''}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Tag className="w-5 h-5 text-orange-600" />
            Marketing & Promotions
          </CardTitle>
          <CardDescription>
            Offres spéciales et actualités
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-1">
          <PreferenceItem
            icon={Tag}
            label="Codes promo"
            description="Recevez les codes promo et offres exclusives"
            preferenceKey="promo_email"
          />
          <Separator />
          <PreferenceItem
            icon={Newspaper}
            label="Newsletter hebdomadaire"
            description="Résumé des nouveautés et tendances"
            preferenceKey="weekly_digest_email"
          />
          <Separator />
          <PreferenceItem
            icon={Mail}
            label="Emails marketing"
            description="Actualités et recommandations personnalisées"
            preferenceKey="marketing_emails"
          />
        </CardContent>
      </Card>

      {/* Seller Notifications */}
      {isSeller && (
        <Card className={!preferences.email_enabled ? 'opacity-60' : ''}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ShoppingBag className="w-5 h-5 text-purple-600" />
              Notifications Vendeur
              <Badge variant="secondary" className="ml-2">Vendeur</Badge>
            </CardTitle>
            <CardDescription>
              Emails pour gérer votre activité de vendeur
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-1">
            <PreferenceItem
              icon={ShoppingBag}
              label="Nouvelles commandes"
              description="Email immédiat pour chaque nouvelle commande"
              preferenceKey="seller_new_order_email"
            />
            <Separator />
            <PreferenceItem
              icon={XCircle}
              label="Commandes annulées"
              description="Notification quand un client annule une commande"
              preferenceKey="seller_order_cancelled_email"
            />
            <Separator />
            <PreferenceItem
              icon={MessageSquare}
              label="Messages des clients"
              description="Email quand un client vous envoie un message"
              preferenceKey="seller_buyer_message_email"
            />
            <Separator />
            <PreferenceItem
              icon={AlertTriangle}
              label="Alertes de stock"
              description="Notification quand un produit est en rupture ou stock faible"
              preferenceKey="seller_low_stock_email"
            />
            <Separator />
            <PreferenceItem
              icon={Star}
              label="Nouveaux avis"
              description="Email quand un client laisse un avis sur vos produits"
              preferenceKey="seller_new_review_email"
            />
            <Separator />
            <PreferenceItem
              icon={Users}
              label="Nouveaux followers"
              description="Notification quand quelqu'un suit votre boutique"
              preferenceKey="seller_new_follower_email"
            />
          </CardContent>
        </Card>
      )}

      {/* Save Button */}
      {hasChanges && (
        <div className="sticky bottom-4 flex justify-end">
          <Button
            onClick={savePreferences}
            disabled={saving}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg"
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Sauvegarde...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Sauvegarder les préférences
              </>
            )}
          </Button>
        </div>
      )}

      {/* Email Info */}
      {/* Email Info */}
      <Card className="bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Mail className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <p className="font-medium text-blue-900 dark:text-blue-100">
                À propos de vos emails
              </p>
              <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                Les emails transactionnels importants (comme les confirmations de commande) 
                seront toujours envoyés même si vous désactivez certaines catégories. 
                Vous pouvez vous désabonner complètement en désactivant le toggle principal.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Automatic Email Info */}
      <Card className="bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
            <div>
              <p className="font-medium text-green-900 dark:text-green-100">
                Emails automatiques activés
              </p>
              <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                Les emails sont envoyés automatiquement lors des événements suivants:
              </p>
              <ul className="text-sm text-green-700 dark:text-green-300 mt-2 space-y-1 list-disc list-inside">
                <li>Nouvelle commande passée (confirmation acheteur + notification vendeur)</li>
                <li>Changement de statut de commande (expédition, livraison, annulation)</li>
                <li>Nouveau message reçu (après 5 minutes si vous êtes hors ligne)</li>
                <li>Nouvel avis posté sur un produit (notification vendeur)</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

