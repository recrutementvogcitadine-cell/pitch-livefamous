import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Check, 
  CheckCheck, 
  Trash2, 
  X, 
  Video, 
  Play, 
  Package, 
  Tag, 
  Info,
  MessageCircle,
  Star,
  TrendingDown,
  Filter,
  Search,
  ChevronLeft,
  Settings,
  Volume2,
  VolumeX,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { useNotifications, Notification, NotificationPreferences } from '@/hooks/useNotifications';
import { useAuth } from '@/contexts/AuthContext';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
}

type NotificationFilter = 'all' | 'unread' | 'live_start' | 'order_update' | 'promo' | 'message' | 'system';

export function NotificationCenter({ isOpen, onClose }: NotificationCenterProps) {
  const { user } = useAuth();
  const {
    notifications,
    unreadCount,
    countsByType,
    preferences,
    loading,
    fetchNotifications,
    fetchPreferences,
    updatePreferences,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAllNotifications
  } = useNotifications();
  
  const [filter, setFilter] = useState<NotificationFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [localPrefs, setLocalPrefs] = useState<Partial<NotificationPreferences>>({});

  useEffect(() => {
    if (user && isOpen) {
      fetchNotifications(user.id);
      fetchPreferences(user.id).then(prefs => {
        if (prefs) setLocalPrefs(prefs);
      });
    }
  }, [user, isOpen, fetchNotifications, fetchPreferences]);

  useEffect(() => {
    if (preferences) {
      setLocalPrefs(preferences);
    }
  }, [preferences]);

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'live_start':
        return <Video className="w-5 h-5 text-red-500" />;
      case 'replay_available':
        return <Play className="w-5 h-5 text-purple-500" />;
      case 'order_update':
        return <Package className="w-5 h-5 text-blue-500" />;
      case 'promo':
        return <Tag className="w-5 h-5 text-green-500" />;
      case 'message':
        return <MessageCircle className="w-5 h-5 text-cyan-500" />;
      case 'review':
        return <Star className="w-5 h-5 text-yellow-500" />;
      case 'price_drop':
        return <TrendingDown className="w-5 h-5 text-orange-500" />;
      default:
        return <Info className="w-5 h-5 text-gray-500" />;
    }
  };

  const getNotificationColor = (type: Notification['type']) => {
    switch (type) {
      case 'live_start':
        return 'bg-red-500/10 border-red-500/30';
      case 'replay_available':
        return 'bg-purple-500/10 border-purple-500/30';
      case 'order_update':
        return 'bg-blue-500/10 border-blue-500/30';
      case 'promo':
        return 'bg-green-500/10 border-green-500/30';
      case 'message':
        return 'bg-cyan-500/10 border-cyan-500/30';
      case 'review':
        return 'bg-yellow-500/10 border-yellow-500/30';
      case 'price_drop':
        return 'bg-orange-500/10 border-orange-500/30';
      default:
        return 'bg-gray-500/10 border-gray-500/30';
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;
    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  };

  const handleNotificationClick = (notification: Notification) => {
    if (user && !notification.is_read) {
      markAsRead(notification.id, user.id);
    }
    // Handle navigation based on notification type
    if (notification.action_url) {
      window.location.href = notification.action_url;
    }
  };

  const handleMarkAllRead = () => {
    if (user) {
      if (filter !== 'all' && filter !== 'unread') {
        markAllAsRead(user.id, filter);
      } else {
        markAllAsRead(user.id);
      }
    }
  };

  const handleClearAll = () => {
    if (user) {
      if (filter !== 'all' && filter !== 'unread') {
        clearAllNotifications(user.id, filter);
      } else {
        clearAllNotifications(user.id);
      }
    }
  };

  const handleDelete = (e: React.MouseEvent, notificationId: string) => {
    e.stopPropagation();
    if (user) {
      deleteNotification(notificationId, user.id);
    }
  };

  const handleRefresh = () => {
    if (user) {
      fetchNotifications(user.id);
    }
  };

  const handlePreferenceChange = (key: keyof NotificationPreferences, value: boolean) => {
    setLocalPrefs(prev => ({ ...prev, [key]: value }));
    if (user) {
      updatePreferences(user.id, { [key]: value });
    }
  };

  const filteredNotifications = notifications.filter(n => {
    // Filter by type
    if (filter === 'unread' && n.is_read) return false;
    if (filter !== 'all' && filter !== 'unread' && n.type !== filter) return false;
    
    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return n.title.toLowerCase().includes(query) || 
             n.message.toLowerCase().includes(query) ||
             (n.sender_name && n.sender_name.toLowerCase().includes(query));
    }
    
    return true;
  });

  const filterTabs: { key: NotificationFilter; label: string; icon: React.ReactNode; count?: number }[] = [
    { key: 'all', label: 'Tout', icon: <Bell className="w-4 h-4" /> },
    { key: 'unread', label: 'Non lus', icon: <Badge className="w-4 h-4" />, count: unreadCount },
    { key: 'order_update', label: 'Commandes', icon: <Package className="w-4 h-4" />, count: countsByType['order_update'] },
    { key: 'message', label: 'Messages', icon: <MessageCircle className="w-4 h-4" />, count: countsByType['message'] },
    { key: 'promo', label: 'Promos', icon: <Tag className="w-4 h-4" />, count: countsByType['promo'] },
    { key: 'live_start', label: 'Lives', icon: <Video className="w-4 h-4" />, count: countsByType['live_start'] },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
      <div className="absolute right-0 top-0 bottom-0 w-full max-w-lg bg-slate-900 border-l border-slate-700 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-700 bg-gradient-to-r from-orange-500 to-pink-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={onClose}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-white" />
              </button>
              <div>
                <h2 className="text-xl font-bold text-white">Centre de Notifications</h2>
                <p className="text-white/80 text-sm">
                  {unreadCount > 0 ? `${unreadCount} non lue${unreadCount > 1 ? 's' : ''}` : 'Tout est lu'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleRefresh}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
                disabled={loading}
              >
                <RefreshCw className={`w-5 h-5 text-white ${loading ? 'animate-spin' : ''}`} />
              </button>
              <button
                onClick={() => setShowSettings(!showSettings)}
                className={`p-2 rounded-lg transition-colors ${showSettings ? 'bg-white/30' : 'hover:bg-white/20'}`}
              >
                <Settings className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>

        {showSettings ? (
          /* Settings Panel */
          <div className="flex-1 overflow-y-auto p-4">
            <h3 className="text-lg font-semibold text-white mb-4">Préférences de Notifications</h3>
            
            <div className="space-y-4">
              {/* Master Toggle */}
              <div className="p-4 bg-slate-800 rounded-xl border border-slate-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                      <Bell className="w-5 h-5 text-orange-500" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Notifications push</p>
                      <p className="text-slate-400 text-sm">Activer toutes les notifications</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handlePreferenceChange('push_notifications', !localPrefs.push_notifications)}
                    className={`w-12 h-6 rounded-full transition-colors ${localPrefs.push_notifications ? 'bg-orange-500' : 'bg-slate-600'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${localPrefs.push_notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
                  </button>
                </div>
              </div>

              {/* Notification Types */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Types de notifications</h4>
                
                {[
                  { key: 'order_notifications', icon: Package, color: 'blue', label: 'Commandes', desc: 'Mises à jour de vos commandes' },
                  { key: 'message_notifications', icon: MessageCircle, color: 'cyan', label: 'Messages', desc: 'Nouveaux messages des vendeurs' },
                  { key: 'promo_notifications', icon: Tag, color: 'green', label: 'Promotions', desc: 'Codes promo et offres spéciales' },
                  { key: 'live_start_notifications', icon: Video, color: 'red', label: 'Lives', desc: 'Démarrage de lives' },
                  { key: 'replay_notifications', icon: Play, color: 'purple', label: 'Rediffusions', desc: 'Nouvelles rediffusions disponibles' },
                  { key: 'price_drop_notifications', icon: TrendingDown, color: 'orange', label: 'Baisses de prix', desc: 'Produits en promotion' },
                  { key: 'review_notifications', icon: Star, color: 'yellow', label: 'Avis', desc: 'Réponses à vos avis' },
                ].map(({ key, icon: Icon, color, label, desc }) => (
                  <div key={key} className="flex items-center justify-between py-3 border-b border-slate-800">
                    <div className="flex items-center gap-3">
                      <Icon className={`w-5 h-5 text-${color}-500`} />
                      <div>
                        <p className="text-white font-medium">{label}</p>
                        <p className="text-slate-400 text-sm">{desc}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handlePreferenceChange(key as keyof NotificationPreferences, !localPrefs[key as keyof NotificationPreferences])}
                      disabled={!localPrefs.push_notifications}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        localPrefs[key as keyof NotificationPreferences] && localPrefs.push_notifications 
                          ? 'bg-orange-500' 
                          : 'bg-slate-600'
                      } ${!localPrefs.push_notifications ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                        localPrefs[key as keyof NotificationPreferences] && localPrefs.push_notifications 
                          ? 'translate-x-6' 
                          : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                ))}
              </div>

              {/* Sound Toggle */}
              <div className="p-4 bg-slate-800 rounded-xl border border-slate-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {localPrefs.sound_enabled ? (
                      <Volume2 className="w-5 h-5 text-cyan-500" />
                    ) : (
                      <VolumeX className="w-5 h-5 text-slate-500" />
                    )}
                    <div>
                      <p className="text-white font-medium">Son des notifications</p>
                      <p className="text-slate-400 text-sm">Jouer un son à chaque notification</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handlePreferenceChange('sound_enabled', !localPrefs.sound_enabled)}
                    disabled={!localPrefs.push_notifications}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      localPrefs.sound_enabled && localPrefs.push_notifications 
                        ? 'bg-orange-500' 
                        : 'bg-slate-600'
                    } ${!localPrefs.push_notifications ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                      localPrefs.sound_enabled && localPrefs.push_notifications 
                        ? 'translate-x-6' 
                        : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
              </div>

              {/* Email Preferences */}
              <div className="space-y-3 mt-6">
                <h4 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Emails</h4>
                
                {[
                  { key: 'email_notifications', label: 'Notifications par email', desc: 'Recevoir les notifications importantes par email' },
                  { key: 'weekly_digest', label: 'Résumé hebdomadaire', desc: 'Récapitulatif de la semaine' },
                  { key: 'marketing_emails', label: 'Emails marketing', desc: 'Nouveautés et offres exclusives' },
                ].map(({ key, label, desc }) => (
                  <div key={key} className="flex items-center justify-between py-3 border-b border-slate-800">
                    <div>
                      <p className="text-white font-medium">{label}</p>
                      <p className="text-slate-400 text-sm">{desc}</p>
                    </div>
                    <button
                      onClick={() => handlePreferenceChange(key as keyof NotificationPreferences, !localPrefs[key as keyof NotificationPreferences])}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        localPrefs[key as keyof NotificationPreferences] 
                          ? 'bg-orange-500' 
                          : 'bg-slate-600'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                        localPrefs[key as keyof NotificationPreferences] 
                          ? 'translate-x-6' 
                          : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Search & Filters */}
            <div className="p-4 border-b border-slate-700 space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Rechercher..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                {filterTabs.map(tab => (
                  <button
                    key={tab.key}
                    onClick={() => setFilter(tab.key)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                      filter === tab.key
                        ? 'bg-orange-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {tab.icon}
                    {tab.label}
                    {tab.count !== undefined && tab.count > 0 && (
                      <span className={`px-1.5 py-0.5 rounded-full text-xs ${
                        filter === tab.key ? 'bg-white/20' : 'bg-slate-700'
                      }`}>
                        {tab.count}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions Bar */}
            {filteredNotifications.length > 0 && (
              <div className="px-4 py-2 border-b border-slate-700 flex items-center justify-between">
                <span className="text-sm text-slate-400">
                  {filteredNotifications.length} notification{filteredNotifications.length > 1 ? 's' : ''}
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={handleMarkAllRead}
                    className="text-sm text-orange-500 hover:text-orange-400 flex items-center gap-1"
                  >
                    <CheckCheck className="w-4 h-4" />
                    Tout marquer lu
                  </button>
                  <span className="text-slate-600">|</span>
                  <button
                    onClick={handleClearAll}
                    className="text-sm text-red-500 hover:text-red-400 flex items-center gap-1"
                  >
                    <Trash2 className="w-4 h-4" />
                    Tout effacer
                  </button>
                </div>
              </div>
            )}

            {/* Notifications List */}
            <ScrollArea className="flex-1">
              {filteredNotifications.length === 0 ? (
                <div className="p-8 text-center">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-slate-800 flex items-center justify-center">
                    <Bell className="w-8 h-8 text-slate-600" />
                  </div>
                  <p className="text-white font-medium">Aucune notification</p>
                  <p className="text-slate-400 text-sm mt-1">
                    {filter === 'unread' 
                      ? 'Toutes vos notifications ont été lues'
                      : 'Vous n\'avez pas encore de notifications'}
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-slate-800">
                  {filteredNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-slate-800/50 cursor-pointer transition-colors ${
                        !notification.is_read ? 'bg-orange-500/5' : ''
                      }`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <div className="flex gap-3">
                        {/* Icon or Avatar */}
                        <div className="flex-shrink-0">
                          {notification.sender_avatar ? (
                            <img
                              src={notification.sender_avatar}
                              alt={notification.sender_name || ''}
                              className="w-12 h-12 rounded-full object-cover"
                            />
                          ) : notification.image_url ? (
                            <img
                              src={notification.image_url}
                              alt=""
                              className="w-12 h-12 rounded-lg object-cover"
                            />
                          ) : (
                            <div className={`w-12 h-12 rounded-full flex items-center justify-center border ${getNotificationColor(notification.type)}`}>
                              {getNotificationIcon(notification.type)}
                            </div>
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              {notification.sender_name && (
                                <p className="text-sm text-orange-500 font-medium">
                                  {notification.sender_name}
                                </p>
                              )}
                              <p className={`text-sm ${!notification.is_read ? 'font-semibold text-white' : 'text-slate-300'}`}>
                                {notification.title}
                              </p>
                            </div>
                            <button
                              onClick={(e) => handleDelete(e, notification.id)}
                              className="text-slate-500 hover:text-red-500 transition-colors p-1"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                          <p className="text-sm text-slate-400 mt-1 line-clamp-2">
                            {notification.message}
                          </p>
                          <div className="flex items-center gap-3 mt-2">
                            <span className="text-xs text-slate-500">
                              {formatTime(notification.created_at)}
                            </span>
                            {!notification.is_read && (
                              <span className="w-2 h-2 rounded-full bg-orange-500" />
                            )}
                            {notification.priority === 'high' && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/20 text-red-400">
                                Important
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </>
        )}
      </div>
    </div>
  );
}
