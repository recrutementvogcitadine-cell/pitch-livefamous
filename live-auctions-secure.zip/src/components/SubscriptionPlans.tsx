import React, { useState, useEffect } from 'react';
import { 
  X, Check, Crown, Zap, Building2, Star, ArrowRight, 
  Shield, Clock, CreditCard, Phone, Loader2, AlertCircle,
  ChevronDown, Sparkles, Users, Package, Video, BarChart3,
  Headphones, Megaphone, Code, GraduationCap, RefreshCw, Calendar
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';

interface SubscriptionPlan {
  id: string;
  name: string;
  slug: string;
  price: number;
  period: string;
  features: string[];
  max_products: number;
  max_lives_per_month: number;
  is_popular: boolean;
  is_active: boolean;
}

interface SellerSubscription {
  id: string;
  seller_id: string;
  plan_id: string;
  status: string;
  starts_at: string;
  ends_at: string;
  auto_renew: boolean;
  payment_method: string;
  payment_reference: string;
}

interface SubscriptionPlansProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscriptionChange?: () => void;
}

// Default plans as fallback when database is unavailable
const DEFAULT_PLANS: SubscriptionPlan[] = [
  {
    id: 'starter-default',
    name: 'Starter',
    slug: 'starter',
    price: 15000,
    period: 'month',
    features: [
      '5 Lives par mois',
      '20 produits max',
      'Support email',
      'Statistiques basiques'
    ],
    max_products: 20,
    max_lives_per_month: 5,
    is_popular: false,
    is_active: true
  },
  {
    id: 'pro-default',
    name: 'Professionnel',
    slug: 'pro',
    price: 35000,
    period: 'month',
    features: [
      'Lives illimités',
      '100 produits max',
      'Support prioritaire',
      'Statistiques avancées',
      'Badge vérifié',
      'Promotion en page d\'accueil'
    ],
    max_products: 100,
    max_lives_per_month: -1,
    is_popular: true,
    is_active: true
  },
  {
    id: 'enterprise-default',
    name: 'Entreprise',
    slug: 'enterprise',
    price: 75000,
    period: 'month',
    features: [
      'Tout du Pro',
      'Produits illimités',
      'Manager dédié',
      'API personnalisée',
      'Multi-utilisateurs',
      'Formation incluse',
      'Publicité gratuite'
    ],
    max_products: -1,
    max_lives_per_month: -1,
    is_popular: false,
    is_active: true
  }
];

const formatPrice = (price: number) => {
  return new Intl.NumberFormat('fr-CI', {
    style: 'decimal',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(price) + ' FCFA';
};

const SubscriptionPlans: React.FC<SubscriptionPlansProps> = ({ isOpen, onClose, onSubscriptionChange }) => {
  const { user } = useAuth();
  const [plans, setPlans] = useState<SubscriptionPlan[]>(DEFAULT_PLANS);
  const [currentSubscription, setCurrentSubscription] = useState<SellerSubscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'orange' | 'mtn' | 'wave' | 'moov'>('orange');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [processing, setProcessing] = useState(false);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  useEffect(() => {
    if (isOpen) {
      fetchPlans();
      fetchCurrentSubscription();
    }
  }, [isOpen, user]);

  const fetchPlans = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true)
        .order('price', { ascending: true });

      if (error) {
        console.warn('Error fetching plans from database, using defaults:', error);
        setPlans(DEFAULT_PLANS);
        return;
      }
      
      if (data && data.length > 0) {
        setPlans(data);
      } else {
        setPlans(DEFAULT_PLANS);
      }
    } catch (err) {
      console.warn('Error fetching plans, using defaults:', err);
      setPlans(DEFAULT_PLANS);
    }
  };

  const fetchCurrentSubscription = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('seller_subscriptions')
        .select('*')
        .eq('seller_id', user.id)
        .eq('status', 'active')
        .single();

      if (data && !error) {
        setCurrentSubscription(data);
      }
    } catch (err) {
      console.warn('Error fetching subscription:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectPlan = (plan: SubscriptionPlan) => {
    if (currentSubscription?.plan_id === plan.id) {
      toast({
        title: "Plan actuel",
        description: "Vous êtes déjà abonné à ce plan",
      });
      return;
    }
    setSelectedPlan(plan);
    setShowPaymentModal(true);
  };

  const handleSubscribe = async () => {
    if (!selectedPlan || !user || !phoneNumber) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs",
        variant: "destructive",
      });
      return;
    }

    setProcessing(true);

    try {
      // Call the edge function to process subscription
      const { data, error } = await supabase.functions.invoke('process-subscription', {
        body: {
          action: currentSubscription ? 'upgrade' : 'subscribe',
          planId: selectedPlan.id,
          sellerId: user.id,
          paymentMethod,
          phoneNumber,
          currentSubscriptionId: currentSubscription?.id
        }
      });

      if (error) throw error;

      if (data.success) {
        // Calculate subscription dates
        const startsAt = new Date();
        const endsAt = new Date();
        endsAt.setMonth(endsAt.getMonth() + (billingCycle === 'yearly' ? 12 : 1));

        // Create or update subscription in database
        if (currentSubscription) {
          await supabase
            .from('seller_subscriptions')
            .update({
              plan_id: selectedPlan.id,
              status: 'active',
              starts_at: startsAt.toISOString(),
              ends_at: endsAt.toISOString(),
              payment_method: paymentMethod,
              payment_reference: data.transactionId,
              auto_renew: true
            })
            .eq('id', currentSubscription.id);
        } else {
          await supabase
            .from('seller_subscriptions')
            .insert({
              seller_id: user.id,
              plan_id: selectedPlan.id,
              status: 'active',
              starts_at: startsAt.toISOString(),
              ends_at: endsAt.toISOString(),
              payment_method: paymentMethod,
              payment_reference: data.transactionId,
              auto_renew: true
            });
        }

        toast({
          title: "Abonnement réussi!",
          description: data.message,
        });

        setShowPaymentModal(false);
        setSelectedPlan(null);
        setPhoneNumber('');
        fetchCurrentSubscription();
        onSubscriptionChange?.();
      } else {
        throw new Error(data.message);
      }
    } catch (err) {
      console.error('Subscription error:', err);
      toast({
        title: "Erreur",
        description: err instanceof Error ? err.message : "Erreur lors de l'abonnement",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleCancelSubscription = async () => {
    if (!currentSubscription || !user) return;

    setProcessing(true);

    try {
      const { data, error } = await supabase.functions.invoke('process-subscription', {
        body: {
          action: 'cancel',
          planId: currentSubscription.plan_id,
          sellerId: user.id,
          currentSubscriptionId: currentSubscription.id
        }
      });

      if (error) throw error;

      if (data.success) {
        await supabase
          .from('seller_subscriptions')
          .update({
            auto_renew: false,
            status: 'canceling'
          })
          .eq('id', currentSubscription.id);

        toast({
          title: "Annulation programmée",
          description: "Votre abonnement sera annulé à la fin de la période en cours",
        });

        fetchCurrentSubscription();
        onSubscriptionChange?.();
      }
    } catch (err) {
      console.error('Cancel error:', err);
      toast({
        title: "Erreur",
        description: "Impossible d'annuler l'abonnement",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const getPlanIcon = (slug: string) => {
    switch (slug) {
      case 'starter':
        return <Zap className="w-8 h-8" />;
      case 'pro':
        return <Crown className="w-8 h-8" />;
      case 'enterprise':
        return <Building2 className="w-8 h-8" />;
      default:
        return <Star className="w-8 h-8" />;
    }
  };

  const getPlanGradient = (slug: string) => {
    switch (slug) {
      case 'starter':
        return 'from-blue-500 to-cyan-500';
      case 'pro':
        return 'from-orange-500 to-yellow-500';
      case 'enterprise':
        return 'from-purple-500 to-pink-500';
      default:
        return 'from-slate-500 to-slate-600';
    }
  };

  const getPlanBorder = (slug: string, isPopular: boolean) => {
    if (isPopular) return 'border-orange-500 ring-2 ring-orange-500/20';
    switch (slug) {
      case 'starter':
        return 'border-blue-500/30';
      case 'enterprise':
        return 'border-purple-500/30';
      default:
        return 'border-slate-700';
    }
  };

  const getFeatureIcon = (feature: string) => {
    if (feature.toLowerCase().includes('live')) return <Video className="w-4 h-4" />;
    if (feature.toLowerCase().includes('produit')) return <Package className="w-4 h-4" />;
    if (feature.toLowerCase().includes('support')) return <Headphones className="w-4 h-4" />;
    if (feature.toLowerCase().includes('statistique') || feature.toLowerCase().includes('analytics')) return <BarChart3 className="w-4 h-4" />;
    if (feature.toLowerCase().includes('badge') || feature.toLowerCase().includes('vérifié')) return <Shield className="w-4 h-4" />;
    if (feature.toLowerCase().includes('promotion') || feature.toLowerCase().includes('publicité')) return <Megaphone className="w-4 h-4" />;
    if (feature.toLowerCase().includes('api')) return <Code className="w-4 h-4" />;
    if (feature.toLowerCase().includes('formation')) return <GraduationCap className="w-4 h-4" />;
    if (feature.toLowerCase().includes('utilisateur') || feature.toLowerCase().includes('manager')) return <Users className="w-4 h-4" />;
    return <Check className="w-4 h-4" />;
  };

  const getCurrentPlan = () => {
    if (!currentSubscription) return null;
    return plans.find(p => p.id === currentSubscription.plan_id);
  };

  const currentPlan = getCurrentPlan();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-6xl bg-slate-900 rounded-3xl shadow-2xl border border-slate-700 my-8">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900 rounded-t-3xl border-b border-slate-700 p-6 z-10">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center">
                  <Crown className="w-5 h-5 text-white" />
                </div>
                Plans d'Abonnement
              </h2>
              <p className="text-slate-400 mt-1">Choisissez le plan qui correspond à vos besoins</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-800"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mt-6">
            <span className={`text-sm font-medium ${billingCycle === 'monthly' ? 'text-white' : 'text-slate-400'}`}>
              Mensuel
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
              className={`relative w-14 h-7 rounded-full transition-colors ${
                billingCycle === 'yearly' ? 'bg-orange-500' : 'bg-slate-700'
              }`}
            >
              <div className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-transform ${
                billingCycle === 'yearly' ? 'translate-x-8' : 'translate-x-1'
              }`} />
            </button>
            <span className={`text-sm font-medium ${billingCycle === 'yearly' ? 'text-white' : 'text-slate-400'}`}>
              Annuel
              <span className="ml-2 px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded-full">
                -20%
              </span>
            </span>
          </div>
        </div>

        {/* Current Subscription Banner */}
        {currentSubscription && currentPlan && (
          <div className="mx-6 mt-6 p-4 rounded-xl bg-gradient-to-r from-orange-500/20 to-yellow-500/20 border border-orange-500/30">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${getPlanGradient(currentPlan.slug)} flex items-center justify-center text-white`}>
                  {getPlanIcon(currentPlan.slug)}
                </div>
                <div>
                  <p className="text-white font-semibold">Plan actuel: {currentPlan.name}</p>
                  <p className="text-slate-400 text-sm flex items-center gap-2">
                    <Calendar className="w-3 h-3" />
                    Expire le {new Date(currentSubscription.ends_at).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                    {currentSubscription.auto_renew && (
                      <span className="flex items-center gap-1 text-green-400">
                        <RefreshCw className="w-3 h-3" />
                        Renouvellement auto
                      </span>
                    )}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {currentSubscription.auto_renew && (
                  <button
                    onClick={handleCancelSubscription}
                    disabled={processing}
                    className="px-4 py-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors text-sm font-medium"
                  >
                    Annuler le renouvellement
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Plans Grid */}
        <div className="p-6">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              {plans.map((plan) => {
                const isCurrentPlan = currentSubscription?.plan_id === plan.id;
                const yearlyPrice = Math.round(plan.price * 12 * 0.8);
                const displayPrice = billingCycle === 'yearly' ? yearlyPrice : plan.price;

                return (
                  <div
                    key={plan.id}
                    className={`relative rounded-2xl border bg-slate-800/50 overflow-hidden transition-all hover:scale-[1.02] ${
                      getPlanBorder(plan.slug, plan.is_popular)
                    } ${isCurrentPlan ? 'ring-2 ring-green-500/50' : ''}`}
                  >
                    {/* Popular Badge */}
                    {plan.is_popular && (
                      <div className="absolute top-0 right-0 px-4 py-1 bg-gradient-to-r from-orange-500 to-yellow-500 text-white text-xs font-bold rounded-bl-xl">
                        <Sparkles className="w-3 h-3 inline mr-1" />
                        POPULAIRE
                      </div>
                    )}

                    {/* Current Plan Badge */}
                    {isCurrentPlan && (
                      <div className="absolute top-0 left-0 px-4 py-1 bg-green-500 text-white text-xs font-bold rounded-br-xl">
                        PLAN ACTUEL
                      </div>
                    )}

                    <div className="p-6">
                      {/* Plan Header */}
                      <div className="flex items-center gap-4 mb-6">
                        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${getPlanGradient(plan.slug)} flex items-center justify-center text-white`}>
                          {getPlanIcon(plan.slug)}
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white">{plan.name}</h3>
                          <p className="text-slate-400 text-sm">
                            {plan.max_products === -1 ? 'Illimité' : `${plan.max_products} produits`}
                          </p>
                        </div>
                      </div>

                      {/* Price */}
                      <div className="mb-6">
                        <div className="flex items-baseline gap-2">
                          <span className="text-4xl font-bold text-white">
                            {formatPrice(displayPrice)}
                          </span>
                        </div>
                        <p className="text-slate-400 text-sm">
                          /{billingCycle === 'yearly' ? 'an' : 'mois'}
                          {billingCycle === 'yearly' && (
                            <span className="ml-2 text-green-400">
                              (économisez {formatPrice(plan.price * 12 - yearlyPrice)})
                            </span>
                          )}
                        </p>
                      </div>

                      {/* Features */}
                      <div className="space-y-3 mb-6">
                        {plan.features.map((feature, index) => (
                          <div key={index} className="flex items-center gap-3 text-slate-300">
                            <div className={`w-5 h-5 rounded-full bg-gradient-to-br ${getPlanGradient(plan.slug)} flex items-center justify-center text-white`}>
                              {getFeatureIcon(feature)}
                            </div>
                            <span className="text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>

                      {/* Limits */}
                      <div className="p-4 bg-slate-900/50 rounded-xl mb-6">
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div>
                            <p className="text-2xl font-bold text-white">
                              {plan.max_products === -1 ? '∞' : plan.max_products}
                            </p>
                            <p className="text-slate-400 text-xs">Produits</p>
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-white">
                              {plan.max_lives_per_month === -1 ? '∞' : plan.max_lives_per_month}
                            </p>
                            <p className="text-slate-400 text-xs">Lives/mois</p>
                          </div>
                        </div>
                      </div>

                      {/* CTA Button */}
                      <button
                        onClick={() => handleSelectPlan(plan)}
                        disabled={isCurrentPlan}
                        className={`w-full py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 ${
                          isCurrentPlan
                            ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                            : plan.is_popular
                            ? 'bg-gradient-to-r from-orange-500 to-yellow-500 text-white hover:shadow-lg hover:shadow-orange-500/30'
                            : `bg-gradient-to-r ${getPlanGradient(plan.slug)} text-white hover:shadow-lg`
                        }`}
                      >
                        {isCurrentPlan ? (
                          <>
                            <Check className="w-5 h-5" />
                            Plan actuel
                          </>
                        ) : currentSubscription ? (
                          <>
                            {plans.findIndex(p => p.id === currentSubscription.plan_id) < plans.findIndex(p => p.id === plan.id) ? 'Passer au' : 'Rétrograder vers'} {plan.name}
                            <ArrowRight className="w-5 h-5" />
                          </>
                        ) : (
                          <>
                            Choisir {plan.name}
                            <ArrowRight className="w-5 h-5" />
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Features Comparison */}
          <div className="mt-12 bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-6 border-b border-slate-700">
              <h3 className="text-xl font-bold text-white">Comparaison des fonctionnalités</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left p-4 text-slate-400 font-medium">Fonctionnalité</th>
                    {plans.map(plan => (
                      <th key={plan.id} className="text-center p-4 text-white font-semibold">
                        {plan.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    { name: 'Nombre de produits', values: plans.map(p => p.max_products === -1 ? 'Illimité' : p.max_products.toString()) },
                    { name: 'Lives par mois', values: plans.map(p => p.max_lives_per_month === -1 ? 'Illimité' : p.max_lives_per_month.toString()) },
                    { name: 'Support client', values: ['Email', 'Prioritaire', 'Dédié'] },
                    { name: 'Statistiques', values: ['Basiques', 'Avancées', 'Premium'] },
                    { name: 'Badge vérifié', values: [false, true, true] },
                    { name: 'Promotion en page d\'accueil', values: [false, true, true] },
                    { name: 'API personnalisée', values: [false, false, true] },
                    { name: 'Multi-utilisateurs', values: [false, false, true] },
                    { name: 'Formation incluse', values: [false, false, true] }
                  ].map((row, index) => (
                    <tr key={index} className="border-b border-slate-700/50">
                      <td className="p-4 text-slate-300">{row.name}</td>
                      {row.values.map((value, i) => (
                        <td key={i} className="text-center p-4">
                          {typeof value === 'boolean' ? (
                            value ? (
                              <Check className="w-5 h-5 text-green-500 mx-auto" />
                            ) : (
                              <X className="w-5 h-5 text-slate-600 mx-auto" />
                            )
                          ) : (
                            <span className="text-white">{value}</span>
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* FAQ */}
          <div className="mt-8 text-center">
            <p className="text-slate-400">
              Des questions? <button className="text-orange-500 hover:underline">Contactez notre équipe</button>
            </p>
          </div>
        </div>

        {/* Payment Modal */}
        {showPaymentModal && selectedPlan && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="w-full max-w-md bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden">
              <div className="p-6 border-b border-slate-700">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-white">Confirmer l'abonnement</h3>
                  <button
                    onClick={() => {
                      setShowPaymentModal(false);
                      setSelectedPlan(null);
                    }}
                    className="p-2 text-slate-400 hover:text-white transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Plan Summary */}
                <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${getPlanGradient(selectedPlan.slug)} flex items-center justify-center text-white`}>
                      {getPlanIcon(selectedPlan.slug)}
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-semibold">{selectedPlan.name}</p>
                      <p className="text-slate-400 text-sm">
                        {billingCycle === 'yearly' ? 'Abonnement annuel' : 'Abonnement mensuel'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-bold">
                        {formatPrice(billingCycle === 'yearly' ? Math.round(selectedPlan.price * 12 * 0.8) : selectedPlan.price)}
                      </p>
                      <p className="text-slate-400 text-xs">/{billingCycle === 'yearly' ? 'an' : 'mois'}</p>
                    </div>
                  </div>
                </div>

                {/* Payment Method */}
                <div>
                  <label className="block text-slate-300 text-sm font-medium mb-3">
                    Méthode de paiement
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { id: 'orange', name: 'Orange Money', color: 'from-orange-500 to-orange-600' },
                      { id: 'mtn', name: 'MTN MoMo', color: 'from-yellow-500 to-yellow-600' },
                      { id: 'wave', name: 'Wave', color: 'from-blue-500 to-blue-600' },
                      { id: 'moov', name: 'Moov Money', color: 'from-cyan-500 to-cyan-600' }
                    ].map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id as any)}
                        className={`p-3 rounded-xl border transition-all flex items-center gap-3 ${
                          paymentMethod === method.id
                            ? 'border-orange-500 bg-orange-500/10'
                            : 'border-slate-700 hover:border-slate-600'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${method.color} flex items-center justify-center`}>
                          <CreditCard className="w-4 h-4 text-white" />
                        </div>
                        <span className="text-white text-sm font-medium">{method.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Phone Number */}
                <div>
                  <label className="block text-slate-300 text-sm font-medium mb-2">
                    Numéro de téléphone
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="+225 07 XX XX XX XX"
                      className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                {/* Terms */}
                <div className="flex items-start gap-3 p-4 bg-blue-500/10 rounded-xl border border-blue-500/30">
                  <AlertCircle className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                  <p className="text-blue-300 text-sm">
                    En vous abonnant, vous acceptez nos conditions d'utilisation et autorisez le prélèvement automatique mensuel.
                  </p>
                </div>

                {/* Submit Button */}
                <button
                  onClick={handleSubscribe}
                  disabled={processing || !phoneNumber}
                  className="w-full py-4 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {processing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Traitement en cours...
                    </>
                  ) : (
                    <>
                      <Shield className="w-5 h-5" />
                      Confirmer et payer {formatPrice(billingCycle === 'yearly' ? Math.round(selectedPlan.price * 12 * 0.8) : selectedPlan.price)}
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubscriptionPlans;
