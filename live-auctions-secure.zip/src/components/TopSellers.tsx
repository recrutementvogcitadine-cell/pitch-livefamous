import React, { useState } from 'react';
import { Star, Users, ShoppingBag, Play, CheckCircle } from 'lucide-react';
import FollowButton from './FollowButton';
import AuthModal from './AuthModal';

interface TopSellersProps {
  onJoinLive?: (sellerId: string) => void;
}

const TopSellers: React.FC<TopSellersProps> = ({ onJoinLive }) => {
  const [showAuthModal, setShowAuthModal] = useState(false);

  const sellers = [
    {
      id: '1',
      name: 'TechStore CI',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100',
      banner: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400',
      category: 'Électronique',
      rating: 4.9,
      reviews: 234,
      followers: 12500,
      products: 156,
      isLive: true,
      verified: true
    },
    {
      id: '2',
      name: 'Awa Fashion',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
      banner: 'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=400',
      category: 'Mode Africaine',
      rating: 4.8,
      reviews: 189,
      followers: 8900,
      products: 89,
      isLive: true,
      verified: true
    },
    {
      id: '3',
      name: 'Bijoux d\'Or',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100',
      banner: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400',
      category: 'Bijoux',
      rating: 4.7,
      reviews: 67,
      followers: 4500,
      products: 45,
      isLive: false,
      verified: false
    },
    {
      id: '4',
      name: 'Maison Plus',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100',
      banner: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400',
      category: 'Électroménager',
      rating: 4.6,
      reviews: 156,
      followers: 6700,
      products: 78,
      isLive: true,
      verified: true
    },
    {
      id: '5',
      name: 'SneakerHead ABJ',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100',
      banner: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400',
      category: 'Chaussures',
      rating: 4.9,
      reviews: 312,
      followers: 15600,
      products: 234,
      isLive: true,
      verified: true
    },
    {
      id: '6',
      name: 'Beauty Queen',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100',
      banner: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400',
      category: 'Beauté',
      rating: 4.5,
      reviews: 98,
      followers: 5400,
      products: 67,
      isLive: false,
      verified: true
    }
  ];

  const handleJoinLive = (sellerId: string) => {
    if (onJoinLive) {
      onJoinLive(sellerId);
    }
  };

  return (
    <>
      <section className="py-16 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">
                Vendeurs{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                  Populaires
                </span>
              </h2>
              <p className="text-slate-400">Découvrez nos meilleurs vendeurs vérifiés</p>
            </div>
            <button className="px-6 py-3 bg-slate-800 border border-slate-700 text-white font-medium rounded-xl hover:border-purple-500 transition-colors">
              Voir tous les vendeurs
            </button>
          </div>

          {/* Sellers Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {sellers.map((seller) => (
              <div
                key={seller.id}
                className="group bg-slate-800/50 rounded-2xl overflow-hidden border border-slate-700 hover:border-purple-500/50 transition-all duration-300 hover:-translate-y-1"
              >
                {/* Banner */}
                <div className="relative h-32 overflow-hidden">
                  <img 
                    src={seller.banner} 
                    alt={seller.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent"></div>
                  
                  {/* Live Badge */}
                  {seller.isLive && (
                    <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 bg-red-500 text-white text-xs font-bold rounded-full">
                      <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
                      LIVE
                    </div>
                  )}

                  {/* Verified Badge on Banner */}
                  {seller.verified && (
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 bg-blue-500/90 backdrop-blur text-white text-xs font-bold rounded-full">
                      <CheckCircle className="w-3.5 h-3.5" />
                      Vérifié
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-5 -mt-10 relative">
                  {/* Avatar */}
                  <div className="flex items-end gap-3 mb-4">
                    <div className="relative">
                      <img 
                        src={seller.avatar} 
                        alt={seller.name}
                        className="w-16 h-16 rounded-xl border-4 border-slate-800 object-cover"
                      />
                      {seller.verified && (
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center border-2 border-slate-800">
                          <CheckCircle className="w-3.5 h-3.5 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 pb-1">
                      <div className="flex items-center gap-2">
                        <h3 className="text-white font-semibold">{seller.name}</h3>
                      </div>
                      <p className="text-slate-400 text-sm">{seller.category}</p>
                    </div>
                  </div>

                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span className="text-white font-medium">{seller.rating}</span>
                    </div>
                    <span className="text-slate-500 text-sm">({seller.reviews} avis)</span>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="text-center p-2 bg-slate-900/50 rounded-lg">
                      <Users className="w-4 h-4 text-purple-500 mx-auto mb-1" />
                      <p className="text-white text-sm font-semibold">{(seller.followers / 1000).toFixed(1)}K</p>
                      <p className="text-slate-500 text-xs">Abonnés</p>
                    </div>
                    <div className="text-center p-2 bg-slate-900/50 rounded-lg">
                      <ShoppingBag className="w-4 h-4 text-orange-500 mx-auto mb-1" />
                      <p className="text-white text-sm font-semibold">{seller.products}</p>
                      <p className="text-slate-500 text-xs">Produits</p>
                    </div>
                    <div className="text-center p-2 bg-slate-900/50 rounded-lg">
                      <Play className="w-4 h-4 text-red-500 mx-auto mb-1" />
                      <p className="text-white text-sm font-semibold">{seller.isLive ? 'En ligne' : 'Hors ligne'}</p>
                      <p className="text-slate-500 text-xs">Statut</p>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <FollowButton
                      sellerId={seller.id}
                      sellerName={seller.name}
                      variant="default"
                      className="flex-1 text-sm"
                      onAuthRequired={() => setShowAuthModal(true)}
                    />
                    {seller.isLive ? (
                      <button 
                        onClick={() => handleJoinLive(seller.id)}
                        className="flex-1 py-2.5 bg-gradient-to-r from-red-500 to-pink-500 text-white font-medium rounded-xl hover:shadow-lg transition-all text-sm flex items-center justify-center gap-1"
                      >
                        <Play className="w-4 h-4" />
                        Rejoindre
                      </button>
                    ) : (
                      <button className="flex-1 py-2.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-medium rounded-xl hover:shadow-lg transition-all text-sm">
                        Voir boutique
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />
    </>
  );
};

export default TopSellers;
