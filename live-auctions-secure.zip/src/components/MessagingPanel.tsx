import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Image, DollarSign, ArrowLeft, MoreVertical, Check, XIcon, RefreshCw, Loader2, ZoomIn, Camera, Video, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import { useMessaging, Conversation, Message } from '@/hooks/useMessaging';
import { useVideoCall } from '@/hooks/useVideoCall';
import { VideoCallModal, IncomingCallNotification } from '@/components/VideoCallModal';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

interface MessagingPanelProps {
  isOpen: boolean;
  onClose: () => void;
  initialSellerId?: string;
  initialProduct?: {
    id: string;
    name: string;
    image: string;
    price: number;
  };
}

export function MessagingPanel({ isOpen, onClose, initialSellerId, initialProduct }: MessagingPanelProps) {
  const { user, profile } = useAuth();
  const {
    conversations,
    currentConversation,
    messages,
    loading,
    uploading,
    createConversation,
    openConversation,
    closeConversation,
    sendMessage,
    sendImageMessage,
    respondToPrice,
    archiveConversation,
    formatLastSeen,
    formatMessageTime
  } = useMessaging();

  // Video call hook
  const otherUserId = currentConversation 
    ? (currentConversation.buyer_id === user?.id ? currentConversation.seller_id : currentConversation.buyer_id)
    : undefined;
  
  const {
    incomingCall,
    callStatus,
    localStream,
    remoteStream,
    isMuted,
    isVideoOff,
    callDuration,
    error: callError,
    initiateCall,
    answerCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleVideo,
    formatDuration,
    setIncomingCall
  } = useVideoCall({
    conversationId: currentConversation?.id,
    otherUserId,
    otherUserName: currentConversation?.other_user_name
  });

  const [messageInput, setMessageInput] = useState('');
  const [showPriceOffer, setShowPriceOffer] = useState(false);
  const [priceOffer, setPriceOffer] = useState('');
  const [counterPrice, setCounterPrice] = useState('');
  const [respondingToMessage, setRespondingToMessage] = useState<string | null>(null);
  
  // Image upload states
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageCaption, setImageCaption] = useState('');
  const [showImagePreview, setShowImagePreview] = useState(false);
  const [viewingImage, setViewingImage] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle initial conversation creation
  useEffect(() => {
    if (isOpen && initialSellerId && initialProduct) {
      createConversation(
        initialSellerId,
        initialProduct.id,
        initialProduct.name,
        initialProduct.image,
        initialProduct.price
      ).then(conv => {
        if (conv) {
          openConversation(conv);
        }
      });
    }
  }, [isOpen, initialSellerId, initialProduct]);

  // Handle image selection
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        alert('Veuillez sélectionner une image');
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('L\'image ne doit pas dépasser 5 Mo');
        return;
      }

      setSelectedImage(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
        setShowImagePreview(true);
      };
      reader.readAsDataURL(file);
    }
    
    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Cancel image selection
  const cancelImageSelection = () => {
    setSelectedImage(null);
    setImagePreview(null);
    setImageCaption('');
    setShowImagePreview(false);
  };

  // Send image message
  const handleSendImage = async () => {
    if (!currentConversation || !selectedImage) return;

    await sendImageMessage(currentConversation.id, selectedImage, imageCaption || undefined);
    cancelImageSelection();
  };

  const handleSendMessage = async () => {
    if (!currentConversation || !messageInput.trim()) return;

    await sendMessage(currentConversation.id, messageInput.trim());
    setMessageInput('');
  };

  const handleSendPriceOffer = async () => {
    if (!currentConversation || !priceOffer) return;

    const price = parseFloat(priceOffer);
    if (isNaN(price) || price <= 0) return;

    await sendMessage(
      currentConversation.id,
      `Je propose ${price.toLocaleString()} FCFA`,
      'price_offer',
      undefined,
      price,
      currentConversation.product_price || undefined
    );
    setPriceOffer('');
    setShowPriceOffer(false);
  };

  const handleRespondToPrice = async (messageId: string, response: 'accepted' | 'rejected' | 'countered') => {
    if (response === 'countered' && counterPrice) {
      await respondToPrice(messageId, response, parseFloat(counterPrice));
      setCounterPrice('');
    } else {
      await respondToPrice(messageId, response);
    }
    setRespondingToMessage(null);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleBack = () => {
    closeConversation();
  };

  // Handle video call
  const handleStartVideoCall = () => {
    if (currentConversation && otherUserId) {
      initiateCall();
    }
  };

  const handleAnswerCall = () => {
    if (incomingCall) {
      answerCall(incomingCall);
    }
  };

  const handleRejectCall = () => {
    if (incomingCall) {
      rejectCall(incomingCall);
    }
  };

  if (!isOpen) return null;

  const isSeller = profile?.role === 'seller';
  const isInCall = callStatus !== 'idle' && callStatus !== 'ended';

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl h-[600px] flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-red-600 to-red-700 text-white p-4 flex items-center justify-between">
            {currentConversation ? (
              <>
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-white hover:bg-white/20"
                    onClick={handleBack}
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                  <div className="relative">
                    <img
                      src={currentConversation.other_user_avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentConversation.id}`}
                      alt="Avatar"
                      className="w-10 h-10 rounded-full border-2 border-white"
                    />
                    {currentConversation.other_user_presence?.is_online && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold">
                      {currentConversation.other_user_name || 'Utilisateur'}
                    </h3>
                    <p className="text-xs text-white/80">
                      {currentConversation.other_user_presence?.is_online
                        ? 'En ligne'
                        : currentConversation.other_user_presence?.last_seen
                          ? formatLastSeen(currentConversation.other_user_presence.last_seen)
                          : 'Hors ligne'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {/* Video call button */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-white hover:bg-white/20"
                    onClick={handleStartVideoCall}
                    disabled={isInCall}
                    title="Appel vidéo"
                  >
                    <Video className="h-5 w-5" />
                  </Button>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                        <MoreVertical className="h-5 w-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => archiveConversation(currentConversation.id)}>
                        Archiver la conversation
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </>
            ) : (
              <>
                <h2 className="text-xl font-bold">Messages</h2>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white hover:bg-white/20"
                  onClick={onClose}
                >
                  <X className="h-5 w-5" />
                </Button>
              </>
            )}
          </div>

          {/* Content */}
          {currentConversation ? (
            <>
              {/* Product info if applicable */}
              {currentConversation.product_name && (
                <div className="bg-gray-50 p-3 border-b flex items-center gap-3">
                  {currentConversation.product_image && (
                    <img
                      src={currentConversation.product_image}
                      alt={currentConversation.product_name}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                  )}
                  <div className="flex-1">
                    <p className="font-medium text-sm">{currentConversation.product_name}</p>
                    {currentConversation.product_price && (
                      <p className="text-red-600 font-bold">
                        {currentConversation.product_price.toLocaleString()} FCFA
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Image Preview Modal */}
              {showImagePreview && imagePreview && (
                <div className="p-4 bg-gray-100 border-b">
                  <div className="flex items-start gap-4">
                    <div className="relative">
                      <img
                        src={imagePreview}
                        alt="Prévisualisation"
                        className="w-32 h-32 object-cover rounded-lg shadow-md"
                      />
                      <button
                        onClick={cancelImageSelection}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-md hover:bg-red-600"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="flex-1 space-y-3">
                      <p className="text-sm font-medium text-gray-700">Envoyer cette image</p>
                      <Input
                        placeholder="Ajouter une légende (optionnel)..."
                        value={imageCaption}
                        onChange={(e) => setImageCaption(e.target.value)}
                        className="text-sm"
                      />
                      <div className="flex gap-2">
                        <Button
                          onClick={handleSendImage}
                          disabled={uploading}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          {uploading ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Envoi...
                            </>
                          ) : (
                            <>
                              <Send className="h-4 w-4 mr-2" />
                              Envoyer
                            </>
                          )}
                        </Button>
                        <Button variant="outline" onClick={cancelImageSelection}>
                          Annuler
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <MessageBubble
                      key={message.id}
                      message={message}
                      isOwn={message.sender_id === user?.id}
                      isSeller={isSeller}
                      formatTime={formatMessageTime}
                      onRespondToPrice={(response) => {
                        if (response === 'countered') {
                          setRespondingToMessage(message.id);
                        } else {
                          handleRespondToPrice(message.id, response);
                        }
                      }}
                      respondingToMessage={respondingToMessage}
                      counterPrice={counterPrice}
                      setCounterPrice={setCounterPrice}
                      onSubmitCounter={() => handleRespondToPrice(message.id, 'countered')}
                      onCancelCounter={() => setRespondingToMessage(null)}
                      onImageClick={(url) => setViewingImage(url)}
                    />
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              {/* Price offer input */}
              {showPriceOffer && (
                <div className="p-3 bg-yellow-50 border-t border-yellow-200">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-yellow-600" />
                    <Input
                      type="number"
                      placeholder="Votre offre en FCFA"
                      value={priceOffer}
                      onChange={(e) => setPriceOffer(e.target.value)}
                      className="flex-1"
                    />
                    <Button onClick={handleSendPriceOffer} className="bg-yellow-600 hover:bg-yellow-700">
                      Envoyer
                    </Button>
                    <Button variant="ghost" onClick={() => setShowPriceOffer(false)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}

              {/* Message input */}
              <div className="p-4 border-t bg-white">
                <div className="flex items-center gap-2">
                  {/* Hidden file input */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageSelect}
                    accept="image/*"
                    className="hidden"
                  />
                  
                  {/* Image button */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-gray-500 hover:text-red-600"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    title="Envoyer une image"
                  >
                    {uploading ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <Camera className="h-5 w-5" />
                    )}
                  </Button>
                  
                  {/* Price offer button */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-gray-500 hover:text-red-600"
                    onClick={() => setShowPriceOffer(!showPriceOffer)}
                    title="Faire une offre de prix"
                  >
                    <DollarSign className="h-5 w-5" />
                  </Button>
                  
                  <Input
                    placeholder="Écrivez votre message..."
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="flex-1"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!messageInput.trim()}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    <Send className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            /* Conversation list */
            <ScrollArea className="flex-1">
              {loading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600" />
                </div>
              ) : conversations.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-500 p-8">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <Send className="h-10 w-10 text-gray-400" />
                  </div>
                  <p className="text-lg font-medium">Aucune conversation</p>
                  <p className="text-sm text-center mt-2">
                    Commencez une conversation en contactant un vendeur depuis un produit
                  </p>
                </div>
              ) : (
                <div className="divide-y">
                  {conversations.map((conversation) => (
                    <ConversationItem
                      key={conversation.id}
                      conversation={conversation}
                      onClick={() => openConversation(conversation)}
                      isCurrentUser={(id) => id === user?.id}
                      formatLastSeen={formatLastSeen}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          )}
        </div>
      </div>

      {/* Image Viewer Dialog */}
      <Dialog open={!!viewingImage} onOpenChange={() => setViewingImage(null)}>
        <DialogContent className="max-w-4xl p-0 bg-black/90 border-none">
          <div className="relative flex items-center justify-center min-h-[400px]">
            <button
              onClick={() => setViewingImage(null)}
              className="absolute top-4 right-4 text-white hover:text-gray-300 z-10"
            >
              <X className="h-8 w-8" />
            </button>
            {viewingImage && (
              <img
                src={viewingImage}
                alt="Image agrandie"
                className="max-w-full max-h-[80vh] object-contain"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Video Call Modal */}
      <VideoCallModal
        isOpen={isInCall}
        callStatus={callStatus}
        localStream={localStream}
        remoteStream={remoteStream}
        isMuted={isMuted}
        isVideoOff={isVideoOff}
        callDuration={callDuration}
        otherUserName={currentConversation?.other_user_name}
        otherUserAvatar={currentConversation?.other_user_avatar}
        error={callError}
        onToggleMute={toggleMute}
        onToggleVideo={toggleVideo}
        onEndCall={endCall}
        formatDuration={formatDuration}
      />

      {/* Incoming Call Notification */}
      {incomingCall && callStatus === 'idle' && (
        <IncomingCallNotification
          callerName={incomingCall.caller_id === user?.id ? 'Vous' : 'Appelant'}
          onAccept={handleAnswerCall}
          onReject={handleRejectCall}
        />
      )}
    </>
  );
}

// Conversation list item
function ConversationItem({
  conversation,
  onClick,
  isCurrentUser,
  formatLastSeen
}: {
  conversation: Conversation;
  onClick: () => void;
  isCurrentUser: (id: string) => boolean;
  formatLastSeen: (date: string) => string;
}) {
  const unreadCount = isCurrentUser(conversation.buyer_id)
    ? conversation.buyer_unread_count
    : conversation.seller_unread_count;

  return (
    <button
      onClick={onClick}
      className="w-full p-4 hover:bg-gray-50 transition-colors flex items-center gap-3 text-left"
    >
      <div className="relative">
        <img
          src={conversation.other_user_avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${conversation.id}`}
          alt="Avatar"
          className="w-12 h-12 rounded-full"
        />
        {conversation.other_user_presence?.is_online && (
          <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <h4 className="font-semibold truncate">
            {conversation.other_user_name || 'Utilisateur'}
          </h4>
          <span className="text-xs text-gray-500">
            {formatLastSeen(conversation.last_message_at)}
          </span>
        </div>
        {conversation.product_name && (
          <p className="text-xs text-red-600 truncate">{conversation.product_name}</p>
        )}
        <p className="text-sm text-gray-600 truncate">{conversation.last_message || 'Nouvelle conversation'}</p>
      </div>
      {unreadCount > 0 && (
        <Badge className="bg-red-600 text-white">{unreadCount}</Badge>
      )}
    </button>
  );
}

// Message bubble component
function MessageBubble({
  message,
  isOwn,
  isSeller,
  formatTime,
  onRespondToPrice,
  respondingToMessage,
  counterPrice,
  setCounterPrice,
  onSubmitCounter,
  onCancelCounter,
  onImageClick
}: {
  message: Message;
  isOwn: boolean;
  isSeller: boolean;
  formatTime: (date: string) => string;
  onRespondToPrice: (response: 'accepted' | 'rejected' | 'countered') => void;
  respondingToMessage: string | null;
  counterPrice: string;
  setCounterPrice: (value: string) => void;
  onSubmitCounter: () => void;
  onCancelCounter: () => void;
  onImageClick: (url: string) => void;
}) {
  const isPriceOffer = message.message_type === 'price_offer';
  const isPriceResponse = message.message_type === 'price_response';
  const isImage = message.message_type === 'image';
  const isVideoCall = message.message_type === 'system' && message.content?.includes('appel');
  const canRespond = isPriceOffer && !isOwn && message.price_status === 'pending';

  return (
    <div className={cn('flex', isOwn ? 'justify-end' : 'justify-start')}>
      <div
        className={cn(
          'max-w-[75%] rounded-2xl',
          isImage ? 'p-1' : 'px-4 py-2',
          isOwn
            ? 'bg-red-600 text-white rounded-br-md'
            : 'bg-gray-100 text-gray-900 rounded-bl-md',
          (isPriceOffer || isPriceResponse) && 'border-2 px-4 py-2',
          isPriceOffer && message.price_status === 'pending' && 'border-yellow-400 bg-yellow-50',
          isPriceOffer && message.price_status === 'accepted' && 'border-green-400 bg-green-50',
          isPriceOffer && message.price_status === 'rejected' && 'border-red-400 bg-red-50',
          isVideoCall && 'bg-blue-50 border border-blue-200 text-blue-800'
        )}
      >
        {/* Video call system message */}
        {isVideoCall && (
          <div className="flex items-center gap-2 text-sm">
            <Video className="h-4 w-4" />
            <span>{message.content}</span>
          </div>
        )}

        {/* Price offer display */}
        {isPriceOffer && (
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-1">
              <DollarSign className="h-4 w-4 text-yellow-600" />
              <span className="font-medium text-gray-700">Offre de prix</span>
            </div>
            <p className="text-2xl font-bold text-gray-900">
              {message.offered_price?.toLocaleString()} FCFA
            </p>
            {message.original_price && (
              <p className="text-sm text-gray-500 line-through">
                Prix original: {message.original_price.toLocaleString()} FCFA
              </p>
            )}
            {message.price_status && message.price_status !== 'pending' && (
              <Badge
                className={cn(
                  'mt-2',
                  message.price_status === 'accepted' && 'bg-green-500',
                  message.price_status === 'rejected' && 'bg-red-500',
                  message.price_status === 'countered' && 'bg-yellow-500'
                )}
              >
                {message.price_status === 'accepted' && 'Acceptée'}
                {message.price_status === 'rejected' && 'Refusée'}
                {message.price_status === 'countered' && 'Contre-offre'}
              </Badge>
            )}
          </div>
        )}

        {/* Price response display */}
        {isPriceResponse && (
          <div className={cn('text-center', isOwn ? 'text-white' : 'text-gray-900')}>
            <p className="font-medium">{message.content}</p>
          </div>
        )}

        {/* Regular text message */}
        {message.message_type === 'text' && (
          <p>{message.content}</p>
        )}

        {/* Image message */}
        {isImage && message.image_url && (
          <div className="relative group cursor-pointer" onClick={() => onImageClick(message.image_url!)}>
            <img
              src={message.image_url}
              alt="Image partagée"
              className="rounded-xl max-w-full max-h-64 object-cover"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors rounded-xl flex items-center justify-center">
              <ZoomIn className="h-8 w-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            {message.content && message.content !== 'Image' && (
              <p className={cn(
                'mt-2 px-3 pb-2 text-sm',
                isOwn ? 'text-white' : 'text-gray-700'
              )}>
                {message.content}
              </p>
            )}
          </div>
        )}

        {/* Timestamp */}
        {!isVideoCall && (
          <p
            className={cn(
              'text-xs mt-1',
              isOwn ? 'text-white/70' : 'text-gray-500',
              (isPriceOffer || isPriceResponse) && 'text-gray-500',
              isImage && 'px-2'
            )}
          >
            {formatTime(message.created_at)}
            {isOwn && message.is_read && (
              <Check className="inline h-3 w-3 ml-1" />
            )}
          </p>
        )}

        {/* Response buttons for price offers */}
        {canRespond && (
          <div className="mt-3 space-y-2">
            {respondingToMessage === message.id ? (
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  placeholder="Contre-offre"
                  value={counterPrice}
                  onChange={(e) => setCounterPrice(e.target.value)}
                  className="flex-1 h-8 text-sm"
                />
                <Button size="sm" onClick={onSubmitCounter} className="h-8 bg-yellow-600 hover:bg-yellow-700">
                  <Check className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="ghost" onClick={onCancelCounter} className="h-8">
                  <XIcon className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => onRespondToPrice('accepted')}
                >
                  <Check className="h-4 w-4 mr-1" />
                  Accepter
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                  onClick={() => onRespondToPrice('countered')}
                >
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Contre-offre
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 border-red-500 text-red-600 hover:bg-red-50"
                  onClick={() => onRespondToPrice('rejected')}
                >
                  <XIcon className="h-4 w-4 mr-1" />
                  Refuser
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default MessagingPanel;
