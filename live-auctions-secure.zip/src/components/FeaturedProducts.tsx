import React, { useState, useEffect } from 'react';
import { Star, MessageCircle, Heart, Phone, ShoppingBag, Eye, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { products, formatPrice, Product } from '@/data/mockData';
import { useAppContext } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import ContactSellerModal from './ContactSellerModal';
import OrderFormModal from './OrderFormModal';
import { ProductReviewsSection } from './ProductReviewsSection';
import { CompactRating } from './StarRating';
import { useReviews, RatingSummary } from '@/hooks/useReviews';
import { toast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface FeaturedProductsProps {
  onAuthClick?: () => void;
}

const FeaturedProducts: React.FC<FeaturedProductsProps> = ({ onAuthClick }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useAppContext();
  const { getRatingSummary } = useReviews();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showProductDetail, setShowProductDetail] = useState(false);
  const [productForOrder, setProductForOrder] = useState<any>(null);
  const [productRatings, setProductRatings] = useState<Record<string, RatingSummary>>({});

  // Load ratings for all products
  useEffect(() => {
    const loadRatings = async () => {
      const ratings: Record<string, RatingSummary> = {};
      for (const product of products) {
        try {
          const summary = await getRatingSummary(product.id);
          ratings[product.id] = summary;
        } catch (err) {
          // Use mock data if no reviews exist
          ratings[product.id] = {
            product_id: product.id,
            average_rating: product.rating,
            total_reviews: product.reviews,
            rating_1_count: 0,
            rating_2_count: 0,
            rating_3_count: Math.floor(product.reviews * 0.1),
            rating_4_count: Math.floor(product.reviews * 0.3),
            rating_5_count: Math.floor(product.reviews * 0.6)
          };
        }
      }
      setProductRatings(ratings);
    };
    loadRatings();
  }, []);

  const handleWishlistToggle = async (product: Product) => {
    if (!user) {
      onAuthClick?.();
      return;
    }

    if (isInWishlist(product.id)) {
      await removeFromWishlist(product.id);
    } else {
      await addToWishlist(product);
    }
  };

  const handleContactSeller = (product: Product) => {
    setSelectedProduct(product);
    setShowContactModal(true);
  };

  const handleOrder = (product: Product) => {
    if (!user) {
      onAuthClick?.();
      return;
    }

    setProductForOrder({
      id: product.id,
      name: product.name,
      price: product.price,
      originalPrice: product.originalPrice,
      image: product.image,
      seller: product.seller,
      sellerPhone: '+2250700000000'
    });
    setShowOrderModal(true);
  };
  const handleViewProduct = (product: Product) => {
    // Navigate to the product detail page
    navigate(`/products/${product.id}`);
  };


  const getProductRating = (productId: string) => {
    const rating = productRatings[productId];
    if (rating) {
      return { rating: rating.average_rating, count: rating.total_reviews };
    }
    const product = products.find(p => p.id === productId);
    return { rating: product?.rating || 0, count: product?.reviews || 0 };
  };

  return (
    <section id="products" className="py-16 bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">
              Produits{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
                Populaires
              </span>
            </h2>
            <p className="text-slate-400">Les meilleures affaires de nos vendeurs vérifiés</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => navigate('/products')}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-medium rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all"
            >
              <Search className="w-5 h-5" />
              Rechercher
            </button>
            <button 
              onClick={() => navigate('/products')}
              className="px-6 py-3 bg-slate-700 border border-slate-600 text-white font-medium rounded-xl hover:border-orange-500 transition-colors"
            >
              Voir tout
            </button>
          </div>
        </div>



        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {products.map((product) => {
            const inWishlist = isInWishlist(product.id);
            const { rating, count } = getProductRating(product.id);
            
            return (
              <div
                key={product.id}
                className="group bg-slate-900/50 rounded-2xl overflow-hidden border border-slate-700 hover:border-orange-500/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-orange-500/10"
              >
                {/* Image */}
                <div className="relative aspect-square overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 cursor-pointer"
                    onClick={() => handleViewProduct(product)}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                  
                  {/* Discount Badge */}
                  {product.originalPrice && (
                    <div className="absolute top-3 left-3">
                      <span className="px-2 py-1 bg-red-500 text-white text-xs font-bold rounded-full">
                        -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                      </span>
                    </div>
                  )}

                  {/* Wishlist Button */}
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleWishlistToggle(product);
                    }}
                    className={`absolute top-3 right-3 w-9 h-9 backdrop-blur rounded-full flex items-center justify-center transition-all ${
                      inWishlist 
                        ? 'bg-red-500 text-white' 
                        : 'bg-white/10 text-white opacity-0 group-hover:opacity-100 hover:bg-red-500'
                    }`}
                  >
                    <Heart className="w-4 h-4" fill={inWishlist ? 'currentColor' : 'none'} />
                  </button>

                  {/* View Details Button */}
                  <button
                    onClick={() => handleViewProduct(product)}
                    className="absolute top-12 right-3 w-9 h-9 backdrop-blur bg-white/10 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all hover:bg-white/20"
                  >
                    <Eye className="w-4 h-4" />
                  </button>

                  {/* Order Button on Hover */}
                  <button
                    onClick={() => handleOrder(product)}
                    className="absolute bottom-3 left-3 right-3 py-2.5 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center gap-2 text-sm"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    Commander
                  </button>
                </div>

                {/* Content */}
                <div className="p-4">
                  <p className="text-slate-400 text-xs mb-1">{product.seller}</p>
                  <h3 
                    className="text-white font-medium text-sm mb-2 line-clamp-2 group-hover:text-orange-400 transition-colors cursor-pointer"
                    onClick={() => handleViewProduct(product)}
                  >
                    {product.name}
                  </h3>
                  
                  {/* Rating - Using CompactRating component */}
                  <div className="mb-2">
                    <CompactRating 
                      rating={rating} 
                      count={count}
                      className="text-white"
                    />
                  </div>

                  {/* Price */}
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-orange-500 font-bold">{formatPrice(product.price)}</span>
                    {product.originalPrice && (
                      <span className="text-slate-500 text-sm line-through">{formatPrice(product.originalPrice)}</span>
                    )}
                  </div>

                  {/* Quick Action Buttons */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleContactSeller(product)}
                      className="flex-1 py-2 bg-green-500/20 text-green-400 rounded-lg text-xs font-medium hover:bg-green-500/30 transition-colors flex items-center justify-center gap-1"
                    >
                      <MessageCircle className="w-3 h-3" />
                      WhatsApp
                    </button>
                    <button
                      onClick={() => handleOrder(product)}
                      className="flex-1 py-2 bg-orange-500/20 text-orange-400 rounded-lg text-xs font-medium hover:bg-orange-500/30 transition-colors flex items-center justify-center gap-1"
                    >
                      <ShoppingBag className="w-3 h-3" />
                      Commander
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Info Banner */}
        <div className="mt-10 p-6 bg-slate-900/50 rounded-2xl border border-slate-700">
          <div className="flex flex-col md:flex-row items-center gap-4 text-center md:text-left">
            <div className="w-16 h-16 bg-orange-500/20 rounded-2xl flex items-center justify-center flex-shrink-0">
              <ShoppingBag className="w-8 h-8 text-orange-500" />
            </div>
            <div className="flex-1">
              <h3 className="text-white font-semibold text-lg mb-1">Passez commande directement sur la plateforme</h3>
              <p className="text-slate-400 text-sm">
                Contactez d'abord les vendeurs via WhatsApp ou téléphone pour confirmer la disponibilité, 
                puis passez votre commande sur la plateforme pour un suivi complet de votre achat.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Product Detail Modal with Reviews */}
      <Dialog open={showProductDetail} onOpenChange={setShowProductDetail}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-700">
          {selectedProduct && (
            <>
              <DialogHeader>
                <DialogTitle className="text-white text-xl">{selectedProduct.name}</DialogTitle>
              </DialogHeader>
              
              <div className="grid md:grid-cols-2 gap-6 mt-4">
                {/* Product Image */}
                <div className="relative aspect-square rounded-xl overflow-hidden">
                  <img 
                    src={selectedProduct.image} 
                    alt={selectedProduct.name}
                    className="w-full h-full object-cover"
                  />
                  {selectedProduct.originalPrice && (
                    <div className="absolute top-3 left-3">
                      <span className="px-3 py-1 bg-red-500 text-white text-sm font-bold rounded-full">
                        -{Math.round((1 - selectedProduct.price / selectedProduct.originalPrice) * 100)}%
                      </span>
                    </div>
                  )}
                </div>

                {/* Product Info */}
                <div className="space-y-4">
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Vendu par</p>
                    <p className="text-white font-medium">{selectedProduct.seller}</p>
                  </div>

                  {/* Rating */}
                  <div>
                    <CompactRating 
                      rating={getProductRating(selectedProduct.id).rating} 
                      count={getProductRating(selectedProduct.id).count}
                      className="text-white"
                    />
                  </div>

                  {/* Price */}
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-3xl font-bold text-orange-500">{formatPrice(selectedProduct.price)}</span>
                      {selectedProduct.originalPrice && (
                        <span className="text-slate-500 text-lg line-through">{formatPrice(selectedProduct.originalPrice)}</span>
                      )}
                    </div>
                  </div>

                  {/* Category */}
                  <div>
                    <span className="px-3 py-1 bg-slate-800 text-slate-300 text-sm rounded-full">
                      {selectedProduct.category}
                    </span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-col gap-3 pt-4">
                    <button
                      onClick={() => {
                        setShowProductDetail(false);
                        handleOrder(selectedProduct);
                      }}
                      className="w-full py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl flex items-center justify-center gap-2"
                    >
                      <ShoppingBag className="w-5 h-5" />
                      Commander maintenant
                    </button>
                    <button
                      onClick={() => {
                        setShowProductDetail(false);
                        handleContactSeller(selectedProduct);
                      }}
                      className="w-full py-3 bg-green-500/20 text-green-400 font-semibold rounded-xl flex items-center justify-center gap-2 hover:bg-green-500/30 transition-colors"
                    >
                      <MessageCircle className="w-5 h-5" />
                      Contacter via WhatsApp
                    </button>
                    <button
                      onClick={() => handleWishlistToggle(selectedProduct)}
                      className={`w-full py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors ${
                        isInWishlist(selectedProduct.id)
                          ? 'bg-red-500/20 text-red-400'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <Heart className="w-5 h-5" fill={isInWishlist(selectedProduct.id) ? 'currentColor' : 'none'} />
                      {isInWishlist(selectedProduct.id) ? 'Retirer des favoris' : 'Ajouter aux favoris'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Reviews Section */}
              <div className="mt-8 pt-6 border-t border-slate-700">
                <ProductReviewsSection
                  productId={selectedProduct.id}
                  productName={selectedProduct.name}
                  productImage={selectedProduct.image}
                  sellerId="seller-1" // This would come from the product data in a real app
                />
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Contact Seller Modal */}
      {selectedProduct && (
        <ContactSellerModal
          isOpen={showContactModal}
          onClose={() => {
            setShowContactModal(false);
            setSelectedProduct(null);
          }}
          seller={{
            name: selectedProduct.seller,
            phone: '+2250700000000',
            whatsapp: '+2250700000000',
            location: 'Abidjan, Côte d\'Ivoire',
            rating: 4.8,
            verified: true,
            responseTime: 'Répond en ~15 min'
          }}
          product={{
            name: selectedProduct.name,
            price: selectedProduct.price,
            image: selectedProduct.image
          }}
        />
      )}

      {/* Order Form Modal */}
      <OrderFormModal
        isOpen={showOrderModal}
        onClose={() => {
          setShowOrderModal(false);
          setProductForOrder(null);
        }}
        product={productForOrder}
        onOrderSuccess={(orderId) => {
          toast({
            title: "Commande passée!",
            description: `Votre commande ${orderId.slice(0, 8).toUpperCase()} a été enregistrée`
          });
        }}
      />
    </section>
  );
};

export default FeaturedProducts;
