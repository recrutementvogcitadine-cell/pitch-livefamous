import React, { useState, useEffect, useRef } from 'react';
import { Bell, Check, CheckCheck, Trash2, X, Video, Play, Package, Tag, Info, MessageCircle, Star, TrendingDown, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useNotifications, Notification } from '@/hooks/useNotifications';
import { useAuth } from '@/contexts/AuthContext';

interface NotificationBellProps {
  onOpenLive?: (streamId: string) => void;
  onOpenReplay?: (streamId: string) => void;
  onOpenNotificationCenter?: () => void;
}

export function NotificationBell({ onOpenLive, onOpenReplay, onOpenNotificationCenter }: NotificationBellProps) {
  const { user } = useAuth();
  const {
    notifications,
    unreadCount,
    fetchNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAllNotifications
  } = useNotifications();
  
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      fetchNotifications(user.id);
      // Poll for new notifications every 30 seconds
      const interval = setInterval(() => {
        fetchNotifications(user.id);
      }, 30000);
      return () => clearInterval(interval);
    }
  }, [user, fetchNotifications]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'live_start':
        return <Video className="w-4 h-4 text-red-500" />;
      case 'replay_available':
        return <Play className="w-4 h-4 text-purple-500" />;
      case 'order_update':
        return <Package className="w-4 h-4 text-blue-500" />;
      case 'promo':
        return <Tag className="w-4 h-4 text-green-500" />;
      case 'message':
        return <MessageCircle className="w-4 h-4 text-cyan-500" />;
      case 'review':
        return <Star className="w-4 h-4 text-yellow-500" />;
      case 'price_drop':
        return <TrendingDown className="w-4 h-4 text-orange-500" />;
      default:
        return <Info className="w-4 h-4 text-gray-500" />;
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;
    return date.toLocaleDateString('fr-FR');
  };

  const handleNotificationClick = (notification: Notification) => {
    if (user && !notification.is_read) {
      markAsRead(notification.id, user.id);
    }

    if (notification.type === 'live_start' && notification.action_data?.stream_id && onOpenLive) {
      onOpenLive(notification.action_data.stream_id);
      setIsOpen(false);
    } else if (notification.type === 'replay_available' && notification.action_data?.stream_id && onOpenReplay) {
      onOpenReplay(notification.action_data.stream_id);
      setIsOpen(false);
    } else if (notification.action_url) {
      window.location.href = notification.action_url;
      setIsOpen(false);
    }
  };

  const handleMarkAllRead = () => {
    if (user) {
      markAllAsRead(user.id);
    }
  };

  const handleClearAll = () => {
    if (user) {
      clearAllNotifications(user.id);
    }
  };

  const handleDelete = (e: React.MouseEvent, notificationId: string) => {
    e.stopPropagation();
    if (user) {
      deleteNotification(notificationId, user.id);
    }
  };

  const handleOpenFullCenter = () => {
    setIsOpen(false);
    if (onOpenNotificationCenter) {
      onOpenNotificationCenter();
    }
  };

  if (!user) return null;

  // Show only the 5 most recent notifications in the dropdown
  const recentNotifications = notifications.slice(0, 5);

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        variant="ghost"
        size="icon"
        className="relative"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-red-500 hover:bg-red-500">
            {unreadCount > 99 ? '99+' : unreadCount}
          </Badge>
        )}
      </Button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-96 bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 overflow-hidden">
          {/* Header */}
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-orange-500 to-pink-500">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-white">Notifications</h3>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-white hover:bg-white/20 h-8 px-2"
                    onClick={handleMarkAllRead}
                  >
                    <CheckCheck className="w-4 h-4 mr-1" />
                    Tout lire
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white hover:bg-white/20 h-8 w-8"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
            {unreadCount > 0 && (
              <p className="text-sm text-white/80 mt-1">
                {unreadCount} notification{unreadCount > 1 ? 's' : ''} non lue{unreadCount > 1 ? 's' : ''}
              </p>
            )}
          </div>

          {/* Notifications List */}
          <ScrollArea className="h-80">
            {recentNotifications.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <Bell className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="font-medium">Aucune notification</p>
                <p className="text-sm mt-1">Vous recevrez des alertes ici</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100 dark:divide-gray-700">
                {recentNotifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors ${
                      !notification.is_read ? 'bg-orange-50/50 dark:bg-orange-900/10' : ''
                    }`}
                    onClick={() => handleNotificationClick(notification)}
                  >
                    <div className="flex gap-3">
                      {/* Icon or Image */}
                      <div className="flex-shrink-0">
                        {notification.sender_avatar ? (
                          <img
                            src={notification.sender_avatar}
                            alt={notification.sender_name || ''}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                        ) : notification.image_url ? (
                          <img
                            src={notification.image_url}
                            alt=""
                            className="w-10 h-10 rounded-lg object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                            {getNotificationIcon(notification.type)}
                          </div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            {notification.sender_name && (
                              <p className="text-xs text-orange-500 font-medium">
                                {notification.sender_name}
                              </p>
                            )}
                            <p className={`text-sm ${!notification.is_read ? 'font-semibold' : 'font-medium'} text-gray-900 dark:text-white`}>
                              {notification.title}
                            </p>
                          </div>
                          <button
                            onClick={(e) => handleDelete(e, notification.id)}
                            className="text-gray-400 hover:text-red-500 transition-colors p-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-0.5 line-clamp-2">
                          {notification.message}
                        </p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-xs text-gray-400">
                            {formatTime(notification.created_at)}
                          </span>
                          {!notification.is_read && (
                            <span className="w-2 h-2 rounded-full bg-orange-500" />
                          )}
                          {notification.priority === 'high' && (
                            <span className="text-xs px-1.5 py-0.5 rounded bg-red-500/20 text-red-500">
                              Important
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Footer */}
          <div className="p-3 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 flex items-center justify-between">
            {notifications.length > 5 && (
              <Button
                variant="ghost"
                size="sm"
                className="text-orange-500 hover:text-orange-600 hover:bg-orange-50"
                onClick={handleOpenFullCenter}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Voir tout ({notifications.length})
              </Button>
            )}
            {notifications.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-500 hover:text-red-500 ml-auto"
                onClick={handleClearAll}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Effacer
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
