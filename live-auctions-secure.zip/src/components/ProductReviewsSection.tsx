import React, { useState, useEffect } from 'react';
import { MessageSquare, Filter, ChevronDown, Loader2, PenLine } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { StarRating, RatingBreakdown } from '@/components/StarRating';
import { ReviewCard } from '@/components/ReviewCard';
import { ReviewForm } from '@/components/ReviewForm';
import { useReviews, Review, RatingSummary } from '@/hooks/useReviews';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

interface ProductReviewsSectionProps {
  productId: string;
  productName: string;
  productImage?: string;
  sellerId: string;
  className?: string;
}

export function ProductReviewsSection({
  productId,
  productName,
  productImage,
  sellerId,
  className
}: ProductReviewsSectionProps) {
  const { user } = useAuth();
  const { getProductReviews, checkCanReview, loading } = useReviews();

  const [reviews, setReviews] = useState<Review[]>([]);
  const [summary, setSummary] = useState<RatingSummary | null>(null);
  const [totalReviews, setTotalReviews] = useState(0);
  const [page, setPage] = useState(1);
  const [sortBy, setSortBy] = useState<'recent' | 'oldest' | 'highest' | 'lowest' | 'helpful'>('recent');
  const [filterRating, setFilterRating] = useState<number | null>(null);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [canReview, setCanReview] = useState(false);
  const [verifiedPurchase, setVerifiedPurchase] = useState(false);
  const [orderId, setOrderId] = useState<string | undefined>();
  const [loadingMore, setLoadingMore] = useState(false);

  const REVIEWS_PER_PAGE = 5;

  // Load reviews
  const loadReviews = async (resetPage = false) => {
    try {
      const currentPage = resetPage ? 1 : page;
      const result = await getProductReviews(productId, {
        page: currentPage,
        limit: REVIEWS_PER_PAGE,
        sortBy,
        filterRating: filterRating || undefined
      });

      if (resetPage) {
        setReviews(result.reviews);
        setPage(1);
      } else {
        setReviews(prev => currentPage === 1 ? result.reviews : [...prev, ...result.reviews]);
      }
      setSummary(result.summary);
      setTotalReviews(result.total);
    } catch (err) {
      console.error('Failed to load reviews:', err);
    }
  };

  // Check if user can review
  const checkUserCanReview = async () => {
    if (!user) {
      setCanReview(false);
      return;
    }

    try {
      const result = await checkCanReview(productId, user.id);
      setCanReview(result.canReview);
      setVerifiedPurchase(result.verifiedPurchase);
      setOrderId(result.orderId);
    } catch (err) {
      console.error('Failed to check review eligibility:', err);
    }
  };

  useEffect(() => {
    loadReviews(true);
  }, [productId, sortBy, filterRating]);

  useEffect(() => {
    checkUserCanReview();
  }, [user, productId]);

  const handleLoadMore = async () => {
    setLoadingMore(true);
    setPage(prev => prev + 1);
    await loadReviews();
    setLoadingMore(false);
  };

  const handleReviewUpdated = (updatedReview: Review) => {
    setReviews(prev => prev.map(r => r.id === updatedReview.id ? updatedReview : r));
  };

  const handleReviewSuccess = () => {
    setShowReviewForm(false);
    loadReviews(true);
    checkUserCanReview();
  };

  const hasMoreReviews = reviews.length < totalReviews;

  return (
    <div className={cn('space-y-6', className)}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            Customer Reviews
          </h2>
          {summary && summary.total_reviews > 0 && (
            <div className="flex items-center gap-2 mt-1">
              <StarRating rating={summary.average_rating} showValue />
              <span className="text-gray-500 dark:text-gray-400">
                ({summary.total_reviews} review{summary.total_reviews !== 1 ? 's' : ''})
              </span>
            </div>
          )}
        </div>

        {canReview && (
          <Button onClick={() => setShowReviewForm(true)}>
            <PenLine className="w-4 h-4 mr-2" />
            Write a Review
          </Button>
        )}
      </div>

      {/* Rating breakdown and filters */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Rating breakdown */}
        {summary && summary.total_reviews > 0 && (
          <div className="lg:col-span-1 p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
            <RatingBreakdown
              summary={summary}
              onFilterClick={setFilterRating}
              activeFilter={filterRating}
            />
          </div>
        )}

        {/* Reviews list */}
        <div className={cn(
          'space-y-4',
          summary && summary.total_reviews > 0 ? 'lg:col-span-2' : 'lg:col-span-3'
        )}>
          {/* Sort controls */}
          {reviews.length > 0 && (
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500 dark:text-gray-400">
                Showing {reviews.length} of {totalReviews} reviews
              </span>
              <Select value={sortBy} onValueChange={(v: any) => setSortBy(v)}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Most Recent</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="highest">Highest Rated</SelectItem>
                  <SelectItem value="lowest">Lowest Rated</SelectItem>
                  <SelectItem value="helpful">Most Helpful</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Loading state */}
          {loading && reviews.length === 0 && (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            </div>
          )}

          {/* Empty state */}
          {!loading && reviews.length === 0 && (
            <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-xl">
              <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                No reviews yet
              </h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                Be the first to review this product!
              </p>
              {canReview && (
                <Button onClick={() => setShowReviewForm(true)}>
                  Write a Review
                </Button>
              )}
            </div>
          )}

          {/* Reviews list */}
          {reviews.map(review => (
            <ReviewCard
              key={review.id}
              review={review}
              currentUserId={user?.id}
              onReviewUpdated={handleReviewUpdated}
            />
          ))}

          {/* Load more button */}
          {hasMoreReviews && (
            <div className="text-center pt-4">
              <Button
                variant="outline"
                onClick={handleLoadMore}
                disabled={loadingMore}
              >
                {loadingMore ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-4 h-4 mr-2" />
                    Load More Reviews
                  </>
                )}
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Review form modal */}
      <Dialog open={showReviewForm} onOpenChange={setShowReviewForm}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Write a Review</DialogTitle>
          </DialogHeader>
          {user && (
            <ReviewForm
              productId={productId}
              productName={productName}
              productImage={productImage}
              sellerId={sellerId}
              buyerId={user.id}
              orderId={orderId}
              verifiedPurchase={verifiedPurchase}
              onSuccess={handleReviewSuccess}
              onCancel={() => setShowReviewForm(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
