import React, { useState } from 'react';
import { 
  SlidersHorizontal, 
  X, 
  ChevronDown, 
  ChevronUp, 
  Star,
  Check,
  RotateCcw
} from 'lucide-react';
import { SearchFilters } from '@/hooks/useProductSearch';
import { formatPrice } from '@/data/mockData';
import { Slider } from '@/components/ui/slider';

interface ProductFiltersProps {
  filters: SearchFilters;
  onUpdateFilters: (filters: Partial<SearchFilters>) => void;
  onResetFilters: () => void;
  onToggleCategory: (category: string) => void;
  allCategories: string[];
  priceRange: { min: number; max: number };
  hasActiveFilters: boolean;
  totalResults: number;
  className?: string;
}

export const ProductFilters: React.FC<ProductFiltersProps> = ({
  filters,
  onUpdateFilters,
  onResetFilters,
  onToggleCategory,
  allCategories,
  priceRange,
  hasActiveFilters,
  totalResults,
  className = "",
}) => {
  const [expandedSections, setExpandedSections] = useState({
    price: true,
    categories: true,
    rating: true,
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const ratingOptions = [4.5, 4, 3.5, 3, 0];

  const handlePriceChange = (values: number[]) => {
    onUpdateFilters({
      minPrice: values[0] === priceRange.min ? null : values[0],
      maxPrice: values[1] === priceRange.max ? null : values[1],
    });
  };

  const currentMinPrice = filters.minPrice ?? priceRange.min;
  const currentMaxPrice = filters.maxPrice ?? priceRange.max;

  return (
    <div className={`bg-slate-800/50 rounded-2xl border border-slate-700 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-5 h-5 text-orange-500" />
          <span className="font-semibold text-white">Filtres</span>
          {hasActiveFilters && (
            <span className="px-2 py-0.5 bg-orange-500/20 text-orange-400 text-xs rounded-full">
              Actifs
            </span>
          )}
        </div>
        {hasActiveFilters && (
          <button
            onClick={onResetFilters}
            className="flex items-center gap-1 text-sm text-slate-400 hover:text-white transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            Réinitialiser
          </button>
        )}
      </div>

      {/* Results Count */}
      <div className="px-4 py-3 border-b border-slate-700">
        <p className="text-sm text-slate-400">
          <span className="text-white font-semibold">{totalResults}</span> produit{totalResults !== 1 ? 's' : ''} trouvé{totalResults !== 1 ? 's' : ''}
        </p>
      </div>

      {/* Sort By */}
      <div className="p-4 border-b border-slate-700">
        <label className="block text-sm font-medium text-slate-300 mb-2">
          Trier par
        </label>
        <select
          value={filters.sortBy}
          onChange={(e) => onUpdateFilters({ sortBy: e.target.value as SearchFilters['sortBy'] })}
          className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
        >
          <option value="relevance">Pertinence</option>
          <option value="price_asc">Prix croissant</option>
          <option value="price_desc">Prix décroissant</option>
          <option value="rating">Meilleures notes</option>
          <option value="newest">Plus récents</option>
        </select>
      </div>

      {/* Price Range */}
      <div className="border-b border-slate-700">
        <button
          onClick={() => toggleSection('price')}
          className="w-full flex items-center justify-between p-4 text-left"
        >
          <span className="font-medium text-white">Prix</span>
          {expandedSections.price ? (
            <ChevronUp className="w-5 h-5 text-slate-400" />
          ) : (
            <ChevronDown className="w-5 h-5 text-slate-400" />
          )}
        </button>
        {expandedSections.price && (
          <div className="px-4 pb-4">
            <div className="mb-4">
              <Slider
                value={[currentMinPrice, currentMaxPrice]}
                min={priceRange.min}
                max={priceRange.max}
                step={1000}
                onValueChange={handlePriceChange}
                className="w-full"
              />
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1">
                <label className="block text-xs text-slate-400 mb-1">Min</label>
                <input
                  type="number"
                  value={currentMinPrice}
                  onChange={(e) => onUpdateFilters({ minPrice: Number(e.target.value) || null })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="0"
                />
              </div>
              <span className="text-slate-500 mt-5">-</span>
              <div className="flex-1">
                <label className="block text-xs text-slate-400 mb-1">Max</label>
                <input
                  type="number"
                  value={currentMaxPrice}
                  onChange={(e) => onUpdateFilters({ maxPrice: Number(e.target.value) || null })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="Max"
                />
              </div>
            </div>
            <p className="text-xs text-slate-400 mt-2 text-center">
              {formatPrice(currentMinPrice)} - {formatPrice(currentMaxPrice)}
            </p>
          </div>
        )}
      </div>

      {/* Categories */}
      <div className="border-b border-slate-700">
        <button
          onClick={() => toggleSection('categories')}
          className="w-full flex items-center justify-between p-4 text-left"
        >
          <div className="flex items-center gap-2">
            <span className="font-medium text-white">Catégories</span>
            {filters.categories.length > 0 && (
              <span className="px-2 py-0.5 bg-orange-500/20 text-orange-400 text-xs rounded-full">
                {filters.categories.length}
              </span>
            )}
          </div>
          {expandedSections.categories ? (
            <ChevronUp className="w-5 h-5 text-slate-400" />
          ) : (
            <ChevronDown className="w-5 h-5 text-slate-400" />
          )}
        </button>
        {expandedSections.categories && (
          <div className="px-4 pb-4 space-y-2">
            {allCategories.map((category) => (
              <button
                key={category}
                onClick={() => onToggleCategory(category)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl transition-colors ${
                  filters.categories.includes(category)
                    ? 'bg-orange-500/20 text-orange-400'
                    : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>{category}</span>
                {filters.categories.includes(category) && (
                  <Check className="w-4 h-4" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Rating */}
      <div>
        <button
          onClick={() => toggleSection('rating')}
          className="w-full flex items-center justify-between p-4 text-left"
        >
          <span className="font-medium text-white">Note minimum</span>
          {expandedSections.rating ? (
            <ChevronUp className="w-5 h-5 text-slate-400" />
          ) : (
            <ChevronDown className="w-5 h-5 text-slate-400" />
          )}
        </button>
        {expandedSections.rating && (
          <div className="px-4 pb-4 space-y-2">
            {ratingOptions.map((rating) => (
              <button
                key={rating}
                onClick={() => onUpdateFilters({ minRating: rating === 0 ? null : rating })}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl transition-colors ${
                  (filters.minRating === rating) || (rating === 0 && filters.minRating === null)
                    ? 'bg-orange-500/20 text-orange-400'
                    : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  {rating > 0 ? (
                    <>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(rating)
                                ? 'text-yellow-400 fill-yellow-400'
                                : i < rating
                                ? 'text-yellow-400 fill-yellow-400/50'
                                : 'text-slate-600'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm">{rating}+ et plus</span>
                    </>
                  ) : (
                    <span className="text-sm">Toutes les notes</span>
                  )}
                </div>
                {((filters.minRating === rating) || (rating === 0 && filters.minRating === null)) && (
                  <Check className="w-4 h-4" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Mobile Filter Modal
interface MobileFiltersModalProps extends ProductFiltersProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileFiltersModal: React.FC<MobileFiltersModalProps> = ({
  isOpen,
  onClose,
  ...filterProps
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="absolute inset-x-0 bottom-0 max-h-[85vh] bg-slate-900 rounded-t-3xl overflow-hidden animate-slide-up">
        {/* Handle */}
        <div className="flex justify-center py-3">
          <div className="w-12 h-1.5 bg-slate-700 rounded-full" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-4 pb-4 border-b border-slate-700">
          <h2 className="text-lg font-semibold text-white">Filtres</h2>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Filters */}
        <div className="overflow-y-auto max-h-[60vh]">
          <ProductFilters {...filterProps} className="border-0 rounded-none" />
        </div>

        {/* Apply Button */}
        <div className="p-4 border-t border-slate-700">
          <button
            onClick={onClose}
            className="w-full py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl"
          >
            Voir {filterProps.totalResults} résultat{filterProps.totalResults !== 1 ? 's' : ''}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductFilters;
