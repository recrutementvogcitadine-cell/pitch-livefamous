import React, { useState, useEffect } from 'react';
import {
  Film, Play, Eye, EyeOff, Edit2, Trash2, Clock, Share2,
  Calendar, BarChart3, CheckCircle, AlertCircle, Search,
  Filter, MoreVertical, ExternalLink, Copy, Scissors, Plus,
  Instagram, Youtube, Square, RectangleVertical, RectangleHorizontal,
  Download, Sparkles, TrendingUp, Twitter, Facebook, Settings, Link2,
  Layers, CheckSquare, X, Zap, Users
} from 'lucide-react';
import { useClips, VideoClip } from '@/hooks/useClips';
import { useRecordings, Recording } from '@/hooks/useRecordings';
import { useSocialSharing } from '@/hooks/useSocialSharing';
import ClipEditor from './ClipEditor';
import { SocialShareModal } from './SocialShareModal';
import { SocialAccountsManager } from './SocialAccountsManager';
import { BulkShareModal } from './BulkShareModal';
import OptimalTimesAnalyzer from './OptimalTimesAnalyzer';
import AudienceInsightsDashboard from './AudienceInsightsDashboard';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';




const ClipsTab: React.FC = () => {
  const {
    fetchClips,
    publishClip,
    unpublishClip,
    deleteClip,
    loading
  } = useClips();

  const { fetchRecordings } = useRecordings();
  const { shares, fetchShares, analytics, fetchAnalytics } = useSocialSharing();

  const [clips, setClips] = useState<VideoClip[]>([]);
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [filteredClips, setFilteredClips] = useState<VideoClip[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [aspectFilter, setAspectFilter] = useState<string>('all');
  
  const [editingClip, setEditingClip] = useState<{ clip?: VideoClip; recording: Recording } | null>(null);
  const [showRecordingPicker, setShowRecordingPicker] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [shareModalClip, setShareModalClip] = useState<VideoClip | null>(null);
  const [activeTab, setActiveTab] = useState('clips');
  const [showAccountsManager, setShowAccountsManager] = useState(false);
  
  // Multi-select state
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedClipIds, setSelectedClipIds] = useState<Set<string>>(new Set());
  const [showBulkShareModal, setShowBulkShareModal] = useState(false);


  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterClips();
  }, [clips, searchQuery, statusFilter, aspectFilter]);

  useEffect(() => {
    if (activeTab === 'analytics') {
      fetchAnalytics();
      fetchShares();
    }
  }, [activeTab]);

  const loadData = async () => {
    setIsLoading(true);
    const [clipsData, recordingsData] = await Promise.all([
      fetchClips(),
      fetchRecordings()
    ]);
    setClips(clipsData);
    setRecordings(recordingsData);
    setIsLoading(false);
  };

  const filterClips = () => {
    let filtered = [...clips];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(c => 
        c.title.toLowerCase().includes(query) ||
        c.description?.toLowerCase().includes(query) ||
        c.tags?.some(t => t.toLowerCase().includes(query))
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(c => c.status === statusFilter);
    }

    if (aspectFilter !== 'all') {
      filtered = filtered.filter(c => c.aspect_ratio === aspectFilter);
    }

    setFilteredClips(filtered);
  };

  const handlePublish = async (clipId: string) => {
    const success = await publishClip(clipId);
    if (success) {
      setClips(clips.map(c => 
        c.id === clipId ? { ...c, status: 'published' as const, is_published: true } : c
      ));
      toast({
        title: "Published",
        description: "The clip is now visible"
      });
    }
  };

  const handleUnpublish = async (clipId: string) => {
    const success = await unpublishClip(clipId);
    if (success) {
      setClips(clips.map(c => 
        c.id === clipId ? { ...c, status: 'ready' as const, is_published: false } : c
      ));
      toast({
        title: "Unpublished",
        description: "The clip is no longer visible"
      });
    }
  };

  const handleDelete = async (clipId: string) => {
    if (!confirm('Are you sure you want to delete this clip?')) return;
    
    const success = await deleteClip(clipId);
    if (success) {
      setClips(clips.filter(c => c.id !== clipId));
      setSelectedClipIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(clipId);
        return newSet;
      });
      toast({
        title: "Deleted",
        description: "The clip has been deleted"
      });
    }
  };

  const copyLink = (clipId: string) => {
    const url = `${window.location.origin}?clip=${clipId}`;
    navigator.clipboard.writeText(url);
    toast({
      title: "Link Copied",
      description: "The clip link has been copied"
    });
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusBadge = (status: string, isPublished: boolean) => {
    if (status === 'processing') {
      return (
        <span className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded-full flex items-center gap-1">
          <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse" />
          Processing
        </span>
      );
    }
    if (status === 'failed') {
      return (
        <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded-full flex items-center gap-1">
          <AlertCircle className="w-3 h-3" />
          Failed
        </span>
      );
    }
    if (isPublished) {
      return (
        <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full flex items-center gap-1">
          <CheckCircle className="w-3 h-3" />
          Published
        </span>
      );
    }
    if (status === 'ready') {
      return (
        <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded-full">
          Ready
        </span>
      );
    }
    return (
      <span className="px-2 py-1 bg-slate-500/20 text-slate-400 text-xs rounded-full">
        Draft
      </span>
    );
  };

  const getAspectIcon = (ratio: string) => {
    switch (ratio) {
      case '9:16': return RectangleVertical;
      case '1:1': return Square;
      case '4:5': return RectangleVertical;
      default: return RectangleHorizontal;
    }
  };

  const handleCreateClip = (recording: Recording) => {
    setShowRecordingPicker(false);
    setEditingClip({ recording });
  };

  const handleEditClip = (clip: VideoClip) => {
    const recording = recordings.find(r => r.id === clip.recording_id);
    if (recording) {
      setEditingClip({ clip, recording });
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'instagram': return <Instagram className="w-4 h-4" />;
      case 'tiktok': return (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
        </svg>
      );
      case 'twitter': return <Twitter className="w-4 h-4" />;
      case 'facebook': return <Facebook className="w-4 h-4" />;
      case 'youtube': return <Youtube className="w-4 h-4" />;
      default: return <Share2 className="w-4 h-4" />;
    }
  };

  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case 'instagram': return 'from-purple-500 via-pink-500 to-orange-500';
      case 'tiktok': return 'from-gray-900 to-gray-800';
      case 'twitter': return 'from-sky-500 to-sky-600';
      case 'facebook': return 'from-blue-600 to-blue-700';
      case 'youtube': return 'from-red-600 to-red-700';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  // Multi-select functions
  const toggleSelectMode = () => {
    setIsSelectMode(!isSelectMode);
    if (isSelectMode) {
      setSelectedClipIds(new Set());
    }
  };

  const toggleClipSelection = (clipId: string) => {
    setSelectedClipIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(clipId)) {
        newSet.delete(clipId);
      } else {
        newSet.add(clipId);
      }
      return newSet;
    });
  };

  const selectAllClips = () => {
    const publishedClipIds = filteredClips.filter(c => c.is_published).map(c => c.id);
    setSelectedClipIds(new Set(publishedClipIds));
  };

  const deselectAllClips = () => {
    setSelectedClipIds(new Set());
  };

  const selectedClips = clips.filter(c => selectedClipIds.has(c.id));

  const handleBulkShareComplete = () => {
    setIsSelectMode(false);
    setSelectedClipIds(new Set());
    loadData();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white">
              <Scissors className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg">Video Clips</h3>
              <p className="text-slate-400 text-sm">
                {clips.length} clip{clips.length !== 1 ? 's' : ''} • {clips.filter(c => c.is_published).length} published
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 flex-wrap">
            {isSelectMode ? (
              <>
                <span className="text-slate-400 text-sm mr-2">
                  {selectedClipIds.size} selected
                </span>
                <Button
                  onClick={selectAllClips}
                  variant="outline"
                  size="sm"
                  className="border-slate-600 text-slate-300 hover:text-white"
                >
                  Select All Published
                </Button>
                <Button
                  onClick={deselectAllClips}
                  variant="outline"
                  size="sm"
                  className="border-slate-600 text-slate-300 hover:text-white"
                >
                  Deselect All
                </Button>
                <Button
                  onClick={() => setShowBulkShareModal(true)}
                  disabled={selectedClipIds.size === 0}
                  className="bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600"
                >
                  <Layers className="w-4 h-4 mr-2" />
                  Bulk Share ({selectedClipIds.size})
                </Button>
                <Button
                  onClick={toggleSelectMode}
                  variant="ghost"
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </Button>
              </>
            ) : (
              <>
                <Button
                  onClick={toggleSelectMode}
                  variant="outline"
                  className="border-slate-600 text-slate-300 hover:text-white"
                >
                  <CheckSquare className="w-4 h-4 mr-2" />
                  Select Multiple
                </Button>
                <Button
                  onClick={() => setShowAccountsManager(true)}
                  variant="outline"
                  className="border-slate-600 text-slate-300 hover:text-white"
                >
                  <Link2 className="w-4 h-4 mr-2" />
                  Social Accounts
                </Button>
                <Button
                  onClick={() => setShowRecordingPicker(true)}
                  className="bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Clip
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-slate-800 border border-slate-700">
          <TabsTrigger value="clips" className="data-[state=active]:bg-purple-500">
            <Scissors className="w-4 h-4 mr-2" />
            Clips
          </TabsTrigger>
          <TabsTrigger value="optimal-times" className="data-[state=active]:bg-purple-500">
            <Zap className="w-4 h-4 mr-2" />
            Optimal Times
          </TabsTrigger>
          <TabsTrigger value="audience" className="data-[state=active]:bg-purple-500">
            <Users className="w-4 h-4 mr-2" />
            Audience
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-purple-500">
            <BarChart3 className="w-4 h-4 mr-2" />
            Social Analytics
          </TabsTrigger>
        </TabsList>




        <TabsContent value="clips" className="space-y-4 mt-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search clips..."
                className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
            >
              <option value="all">All Status</option>
              <option value="published">Published</option>
              <option value="ready">Ready</option>
              <option value="draft">Draft</option>
              <option value="processing">Processing</option>
            </select>
            <select
              value={aspectFilter}
              onChange={(e) => setAspectFilter(e.target.value)}
              className="px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
            >
              <option value="all">All Formats</option>
              <option value="16:9">Landscape (16:9)</option>
              <option value="9:16">Portrait (9:16)</option>
              <option value="1:1">Square (1:1)</option>
              <option value="4:5">Portrait (4:5)</option>
            </select>
          </div>

          {filteredClips.length === 0 ? (
            <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
              <Scissors className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              <h3 className="text-white text-xl font-semibold mb-2">
                {searchQuery || statusFilter !== 'all' || aspectFilter !== 'all' ? 'No Results' : 'No Clips'}
              </h3>
              <p className="text-slate-400 mb-6">
                {searchQuery || statusFilter !== 'all' || aspectFilter !== 'all'
                  ? 'Try adjusting your filters'
                  : 'Create short clips from your recordings for social media'}
              </p>
              {!searchQuery && statusFilter === 'all' && aspectFilter === 'all' && (
                <Button onClick={() => setShowRecordingPicker(true)} className="bg-gradient-to-r from-pink-500 to-orange-500">
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Clip
                </Button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredClips.map((clip) => {
                const AspectIcon = getAspectIcon(clip.aspect_ratio);
                const isSelected = selectedClipIds.has(clip.id);
                return (
                  <div
                    key={clip.id}
                    className={`bg-slate-800/50 rounded-2xl border overflow-hidden transition-all group ${
                      isSelectMode && isSelected ? 'border-purple-500 ring-2 ring-purple-500/30' : isSelectMode ? 'border-slate-600 hover:border-slate-500 cursor-pointer' : 'border-slate-700 hover:border-slate-600'
                    }`}
                    onClick={isSelectMode ? () => toggleClipSelection(clip.id) : undefined}
                  >
                    <div className="relative aspect-video bg-slate-900">
                      {clip.thumbnail_url ? (
                        <img src={clip.thumbnail_url} alt={clip.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Scissors className="w-12 h-12 text-slate-700" />
                        </div>
                      )}
                      {isSelectMode && (
                        <div className={`absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center transition-colors ${isSelected ? 'bg-purple-500' : 'bg-slate-800/80 border border-slate-600'}`}>
                          {isSelected && <CheckCircle className="w-4 h-4 text-white" />}
                        </div>
                      )}
                      {!isSelectMode && (
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <button onClick={() => handleEditClip(clip)} className="p-3 bg-purple-500 hover:bg-purple-600 rounded-full transition-colors">
                            <Edit2 className="w-5 h-5 text-white" />
                          </button>
                          {clip.is_published && (
                            <button onClick={() => setShareModalClip(clip)} className="p-3 bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600 rounded-full transition-colors">
                              <Share2 className="w-5 h-5 text-white" />
                            </button>
                          )}
                        </div>
                      )}
                      <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/80 rounded text-white text-xs font-medium">{formatDuration(clip.duration_seconds)}</div>
                      <div className="absolute top-2 left-2 px-2 py-1 bg-black/80 rounded text-white text-xs font-medium flex items-center gap-1">
                        <AspectIcon className="w-3 h-3" />
                        {clip.aspect_ratio}
                      </div>
                      {clip.status === 'processing' && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                          <div className="text-center">
                            <div className="w-8 h-8 border-3 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                            <p className="text-white text-sm">Processing...</p>
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h4 className="text-white font-semibold text-sm line-clamp-1 flex-1">{clip.title}</h4>
                        {getStatusBadge(clip.status, clip.is_published)}
                      </div>
                      {clip.description && <p className="text-slate-400 text-xs line-clamp-2 mb-3">{clip.description}</p>}
                      {clip.tags && clip.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-3">
                          {clip.tags.slice(0, 3).map(tag => (
                            <span key={tag} className="px-2 py-0.5 bg-purple-500/20 text-purple-400 text-xs rounded-full">#{tag}</span>
                          ))}
                          {clip.tags.length > 3 && <span className="text-slate-500 text-xs">+{clip.tags.length - 3}</span>}
                        </div>
                      )}
                      <div className="flex items-center gap-4 text-xs text-slate-500 mb-3">
                        <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" />{clip.view_count}</span>
                        <span className="flex items-center gap-1"><Share2 className="w-3.5 h-3.5" />{clip.share_count}</span>
                        <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{new Date(clip.created_at).toLocaleDateString('en-US', { day: 'numeric', month: 'short' })}</span>
                      </div>
                      {!isSelectMode && (
                        <div className="flex items-center gap-2">
                          <Button onClick={() => handleEditClip(clip)} size="sm" variant="outline" className="flex-1 border-slate-600 text-slate-300 hover:text-white">
                            <Edit2 className="w-3.5 h-3.5 mr-1" />Edit
                          </Button>
                          {clip.is_published && (
                            <Button onClick={() => setShareModalClip(clip)} size="sm" className="bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600">
                              <Share2 className="w-3.5 h-3.5" />
                            </Button>
                          )}
                          {(clip.status === 'ready' || clip.status === 'published') && !clip.is_published && (
                            <Button onClick={() => handlePublish(clip.id)} size="sm" className="bg-green-500 hover:bg-green-600">
                              <Eye className="w-3.5 h-3.5" />
                            </Button>
                          )}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="sm" variant="ghost" className="text-slate-400 hover:text-white"><MoreVertical className="w-4 h-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                              {clip.is_published && (
                                <>
                                  <DropdownMenuItem onClick={() => copyLink(clip.id)} className="text-slate-300 hover:text-white hover:bg-slate-700 cursor-pointer"><Copy className="w-4 h-4 mr-2" />Copy Link</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleUnpublish(clip.id)} className="text-slate-300 hover:text-white hover:bg-slate-700 cursor-pointer"><EyeOff className="w-4 h-4 mr-2" />Unpublish</DropdownMenuItem>
                                  <DropdownMenuSeparator className="bg-slate-700" />
                                </>
                              )}
                              {clip.processed_url && (
                                <DropdownMenuItem onClick={() => toast({ title: "Download", description: "The clip will be downloaded..." })} className="text-slate-300 hover:text-white hover:bg-slate-700 cursor-pointer"><Download className="w-4 h-4 mr-2" />Download</DropdownMenuItem>
                              )}
                              <DropdownMenuItem onClick={() => handleDelete(clip.id)} className="text-red-400 hover:text-red-300 hover:bg-red-500/10 cursor-pointer"><Trash2 className="w-4 h-4 mr-2" />Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="optimal-times" className="space-y-6 mt-4">
          <OptimalTimesAnalyzer />
        </TabsContent>

        <TabsContent value="audience" className="space-y-6 mt-4">
          <AudienceInsightsDashboard />
        </TabsContent>


        <TabsContent value="analytics" className="space-y-6 mt-4">
          {analytics && (
            <>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <Card className="bg-slate-800/50 border-slate-700"><CardContent className="p-4 text-center"><p className="text-slate-400 text-sm">Total Posts</p><p className="text-2xl font-bold text-white">{analytics.totals.posts}</p></CardContent></Card>
                <Card className="bg-slate-800/50 border-slate-700"><CardContent className="p-4 text-center"><p className="text-slate-400 text-sm">Total Views</p><p className="text-2xl font-bold text-white">{analytics.totals.views.toLocaleString()}</p></CardContent></Card>
                <Card className="bg-slate-800/50 border-slate-700"><CardContent className="p-4 text-center"><p className="text-slate-400 text-sm">Total Likes</p><p className="text-2xl font-bold text-white">{analytics.totals.likes.toLocaleString()}</p></CardContent></Card>
                <Card className="bg-slate-800/50 border-slate-700"><CardContent className="p-4 text-center"><p className="text-slate-400 text-sm">Total Comments</p><p className="text-2xl font-bold text-white">{analytics.totals.comments.toLocaleString()}</p></CardContent></Card>
                <Card className="bg-slate-800/50 border-slate-700"><CardContent className="p-4 text-center"><p className="text-slate-400 text-sm">Avg Engagement</p><p className="text-2xl font-bold text-green-400">{analytics.totals.avgEngagement}%</p></CardContent></Card>
              </div>
              <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                <h4 className="text-white font-semibold mb-4 flex items-center gap-2"><TrendingUp className="w-5 h-5 text-purple-400" />Performance by Platform</h4>
                <div className="space-y-4">
                  {analytics.platforms.map(platform => (
                    <div key={platform.platform} className="flex items-center gap-4 p-4 bg-slate-900/50 rounded-xl">
                      <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${getPlatformColor(platform.platform)} flex items-center justify-center text-white`}>{getPlatformIcon(platform.platform)}</div>
                      <div className="flex-1"><p className="text-white font-medium capitalize">{platform.platform}</p><p className="text-slate-400 text-sm">{platform.posts} posts</p></div>
                      <div className="grid grid-cols-4 gap-6 text-center">
                        <div><p className="text-slate-400 text-xs">Views</p><p className="text-white font-semibold">{platform.views.toLocaleString()}</p></div>
                        <div><p className="text-slate-400 text-xs">Likes</p><p className="text-white font-semibold">{platform.likes.toLocaleString()}</p></div>
                        <div><p className="text-slate-400 text-xs">Comments</p><p className="text-white font-semibold">{platform.comments.toLocaleString()}</p></div>
                        <div><p className="text-slate-400 text-xs">Engagement</p><p className="text-green-400 font-semibold">{platform.avgEngagement}%</p></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
          <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2"><Share2 className="w-5 h-5 text-purple-400" />Recent Shares</h4>
            {shares.length === 0 ? (
              <div className="text-center py-8"><Share2 className="w-12 h-12 text-slate-600 mx-auto mb-3" /><p className="text-slate-400">No shares yet</p><p className="text-slate-500 text-sm">Share your clips to social media to see analytics</p></div>
            ) : (
              <div className="space-y-3">
                {shares.slice(0, 10).map(share => (
                  <div key={share.id} className="flex items-center gap-4 p-3 bg-slate-900/50 rounded-xl">
                    <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${getPlatformColor(share.platform)} flex items-center justify-center text-white`}>{getPlatformIcon(share.platform)}</div>
                    <div className="flex-1 min-w-0"><p className="text-white text-sm truncate">{share.caption || 'No caption'}</p><p className="text-slate-500 text-xs">{new Date(share.created_at).toLocaleDateString('en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p></div>
                    <div className="flex items-center gap-4 text-xs text-slate-400"><span className="flex items-center gap-1"><Eye className="w-3 h-3" />{share.views.toLocaleString()}</span><span className="flex items-center gap-1"><TrendingUp className="w-3 h-3" />{share.engagement_rate}%</span></div>
                    <span className={`px-2 py-1 text-xs rounded-full ${share.status === 'published' ? 'bg-green-500/20 text-green-400' : share.status === 'scheduled' ? 'bg-blue-500/20 text-blue-400' : share.status === 'failed' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}`}>{share.status}</span>
                    {share.post_url && <Button variant="ghost" size="sm" onClick={() => window.open(share.post_url, '_blank')} className="text-slate-400 hover:text-white"><ExternalLink className="w-4 h-4" /></Button>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={showRecordingPicker} onOpenChange={setShowRecordingPicker}>
        <DialogContent className="bg-slate-900 border-slate-700 max-w-2xl">
          <DialogHeader><DialogTitle className="text-white">Choose a Recording</DialogTitle></DialogHeader>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {recordings.length === 0 ? (
              <div className="text-center py-8"><Film className="w-12 h-12 text-slate-600 mx-auto mb-3" /><p className="text-slate-400">No recordings available</p><p className="text-slate-500 text-sm">Create a recording first to make clips</p></div>
            ) : (
              recordings.filter(r => r.status === 'ready' || r.status === 'published').map(recording => (
                <button key={recording.id} onClick={() => handleCreateClip(recording)} className="w-full flex items-center gap-4 p-4 bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors text-left">
                  <div className="w-24 h-16 bg-slate-700 rounded-lg overflow-hidden flex-shrink-0">
                    {recording.thumbnail_url ? <img src={recording.thumbnail_url} alt={recording.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Film className="w-6 h-6 text-slate-500" /></div>}
                  </div>
                  <div className="flex-1 min-w-0"><h4 className="text-white font-medium truncate">{recording.title}</h4><p className="text-slate-400 text-sm">Duration: {Math.floor(recording.duration_seconds / 60)}:{(recording.duration_seconds % 60).toString().padStart(2, '0')}</p></div>
                  <Scissors className="w-5 h-5 text-purple-400" />
                </button>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {editingClip && (
        <ClipEditor isOpen={!!editingClip} onClose={() => setEditingClip(null)} recording={editingClip.recording} existingClipId={editingClip.clip?.id} initialStartTime={editingClip.clip?.start_time_seconds} initialEndTime={editingClip.clip?.end_time_seconds} onSave={() => loadData()} />
      )}

      {shareModalClip && (
        <SocialShareModal isOpen={!!shareModalClip} onClose={() => setShareModalClip(null)} clip={{ id: shareModalClip.id, title: shareModalClip.title, thumbnail_url: shareModalClip.thumbnail_url }} />
      )}

      <BulkShareModal isOpen={showBulkShareModal} onClose={() => setShowBulkShareModal(false)} selectedClips={selectedClips} onShareComplete={handleBulkShareComplete} />

      <SocialAccountsManager isOpen={showAccountsManager} onClose={() => setShowAccountsManager(false)} />
    </div>
  );
};

export default ClipsTab;
