import React from 'react';
import { ArrowRight, Users, Shield, MessageCircle } from 'lucide-react';

interface CTABannerProps {
  onGetStarted: () => void;
}

const CTABanner: React.FC<CTABannerProps> = ({ onGetStarted }) => {
  return (
    <section className="py-20 bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-red-500 to-red-600 p-8 md:p-12 lg:p-16">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4zIj48Y2lyY2xlIGN4PSIzMCIgY3k9IjMwIiByPSIyIi8+PC9nPjwvZz48L3N2Zz4=')]"></div>
          </div>

          <div className="relative flex flex-col lg:flex-row items-center justify-between gap-8">
            {/* Content */}
            <div className="text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur rounded-full text-white text-sm font-medium mb-6">
                <MessageCircle className="w-4 h-4" />
                Transactions directes entre acheteurs et vendeurs
              </div>
              
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
                Prêt à rejoindre la communauté ?
              </h2>
              
              <p className="text-white/90 text-lg max-w-xl mb-8">
                Que vous soyez acheteur ou vendeur, PITCH vous connecte directement. 
                Pas d'intermédiaire, pas de commission sur vos ventes.
              </p>

              {/* Features */}
              <div className="flex flex-wrap justify-center lg:justify-start gap-6 mb-8">
                <div className="flex items-center gap-2 text-white">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                    <Shield className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-medium">Vendeurs vérifiés</span>
                </div>
                <div className="flex items-center gap-2 text-white">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-medium">Contact direct</span>
                </div>
                <div className="flex items-center gap-2 text-white">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                    <Users className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-medium">Communauté active</span>
                </div>
              </div>

              {/* CTA Button */}
              <button
                onClick={onGetStarted}
                className="group px-8 py-4 bg-white text-red-500 font-bold rounded-xl hover:bg-slate-100 transition-all flex items-center gap-2 mx-auto lg:mx-0"
              >
                Commencer maintenant
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Stats Card */}
            <div className="bg-white/10 backdrop-blur rounded-2xl p-8 border border-white/20">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-white mb-1">500+</div>
                  <div className="text-white/80 text-sm">Vendeurs</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-white mb-1">10K+</div>
                  <div className="text-white/80 text-sm">Acheteurs</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-white mb-1">0%</div>
                  <div className="text-white/80 text-sm">Commission</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-white mb-1">24/7</div>
                  <div className="text-white/80 text-sm">Support</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTABanner;
