import React, { useEffect, useRef } from 'react';
import { Loader2, VideoOff, Wifi, WifiOff } from 'lucide-react';

interface AgoraVideoPlayerProps {
  videoTrack: any;
  isLocal?: boolean;
  className?: string;
  showStats?: boolean;
  stats?: {
    bitrate: number;
    frameRate: number;
    resolution: string;
  } | null;
}

export const AgoraVideoPlayer: React.FC<AgoraVideoPlayerProps> = ({
  videoTrack,
  isLocal = false,
  className = '',
  showStats = false,
  stats
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (videoTrack && containerRef.current) {
      videoTrack.play(containerRef.current);
      return () => {
        videoTrack.stop();
      };
    }
  }, [videoTrack]);

  if (!videoTrack) {
    return (
      <div className={`flex items-center justify-center bg-slate-900 ${className}`}>
        <div className="text-center">
          <VideoOff className="w-12 h-12 text-slate-600 mx-auto mb-2" />
          <p className="text-slate-500 text-sm">No video</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      <div ref={containerRef} className="w-full h-full" />
      {showStats && stats && (
        <div className="absolute top-2 left-2 bg-black/70 backdrop-blur px-2 py-1 rounded text-xs text-white flex items-center gap-2">
          <Wifi className="w-3 h-3 text-green-400" />
          <span>{stats.resolution}</span>
          <span>{stats.frameRate}fps</span>
          <span>{Math.round(stats.bitrate / 1000)}kbps</span>
        </div>
      )}
      {isLocal && (
        <div className="absolute bottom-2 right-2 bg-orange-500 px-2 py-0.5 rounded text-xs text-white font-medium">
          You
        </div>
      )}
    </div>
  );
};

interface LiveStreamViewerProps {
  channelName: string;
  isHost?: boolean;
  onConnectionChange?: (connected: boolean) => void;
  onError?: (error: string) => void;
  fallbackThumbnail?: string;
}

export const LiveStreamViewer: React.FC<LiveStreamViewerProps> = ({
  channelName,
  isHost = false,
  onConnectionChange,
  onError,
  fallbackThumbnail
}) => {
  const [isConnecting, setIsConnecting] = React.useState(true);
  const [isConnected, setIsConnected] = React.useState(false);
  const [hasError, setHasError] = React.useState(false);
  const [remoteUser, setRemoteUser] = React.useState<any>(null);

  // Simulated connection for demo - in production this would use useAgoraStream
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsConnecting(false);
      // For demo, show fallback after "connection attempt"
      if (!isHost) {
        setHasError(true);
        onError?.('Stream not available - showing preview');
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [channelName, isHost, onError]);

  if (isConnecting) {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-orange-500 animate-spin mx-auto mb-3" />
          <p className="text-white text-sm">Connecting to live stream...</p>
          <p className="text-slate-400 text-xs mt-1">Channel: {channelName}</p>
        </div>
      </div>
    );
  }

  if (hasError || !remoteUser) {
    return (
      <div className="absolute inset-0">
        {fallbackThumbnail ? (
          <>
            <img 
              src={fallbackThumbnail}
              alt="Stream preview"
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="w-16 h-16 md:w-24 md:h-24 bg-orange-500/20 rounded-full flex items-center justify-center mb-3 md:mb-4 animate-pulse">
                  <div className="w-10 h-10 md:w-16 md:h-16 bg-orange-500/40 rounded-full flex items-center justify-center">
                    <div className="w-5 h-5 md:w-8 md:h-8 bg-orange-500 rounded-full"></div>
                  </div>
                </div>
                <p className="text-white/80 text-sm font-medium">Live en cours</p>
                <p className="text-white/60 text-xs mt-1">Agora Video Streaming</p>
              </div>
            </div>
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
            <div className="text-center">
              <WifiOff className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">Stream unavailable</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <AgoraVideoPlayer 
      videoTrack={remoteUser.videoTrack}
      className="absolute inset-0"
      showStats
    />
  );
};

export default AgoraVideoPlayer;
