import React, { useState, useEffect } from 'react';
import { Star, MessageSquare, Filter, ChevronDown, Loader2, AlertCircle, CheckCircle, TrendingUp, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { StarRating } from '@/components/StarRating';
import { ReviewCard } from '@/components/ReviewCard';
import { useReviews, Review } from '@/hooks/useReviews';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { formatPrice } from '@/data/mockData';

export function SellerReviewsTab() {
  const { user } = useAuth();
  const { getSellerReviews, addSellerResponse, loading } = useReviews();
  const { toast } = useToast();

  const [reviews, setReviews] = useState<Review[]>([]);
  const [totalReviews, setTotalReviews] = useState(0);
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState<'all' | 'needs_response' | 'responded'>('all');
  const [loadingMore, setLoadingMore] = useState(false);
  const [stats, setStats] = useState({
    averageRating: 0,
    totalReviews: 0,
    needsResponse: 0,
    positiveReviews: 0,
    negativeReviews: 0
  });

  const REVIEWS_PER_PAGE = 10;

  const loadReviews = async (resetPage = false) => {
    if (!user) return;

    try {
      const currentPage = resetPage ? 1 : page;
      const needsResponse = filter === 'needs_response';
      
      const result = await getSellerReviews(user.id, {
        page: currentPage,
        limit: REVIEWS_PER_PAGE,
        needsResponse
      });

      let filteredReviews = result.reviews;
      if (filter === 'responded') {
        filteredReviews = result.reviews.filter(r => r.seller_response);
      }

      if (resetPage) {
        setReviews(filteredReviews);
        setPage(1);
      } else {
        setReviews(prev => currentPage === 1 ? filteredReviews : [...prev, ...filteredReviews]);
      }
      setTotalReviews(result.total);

      // Calculate stats
      const allReviews = result.reviews;
      const avgRating = allReviews.length > 0 
        ? allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length 
        : 0;
      
      setStats({
        averageRating: avgRating,
        totalReviews: result.total,
        needsResponse: allReviews.filter(r => !r.seller_response).length,
        positiveReviews: allReviews.filter(r => r.rating >= 4).length,
        negativeReviews: allReviews.filter(r => r.rating <= 2).length
      });
    } catch (err) {
      console.error('Failed to load reviews:', err);
    }
  };

  useEffect(() => {
    loadReviews(true);
  }, [user, filter]);

  const handleLoadMore = async () => {
    setLoadingMore(true);
    setPage(prev => prev + 1);
    await loadReviews();
    setLoadingMore(false);
  };

  const handleReviewUpdated = (updatedReview: Review) => {
    setReviews(prev => prev.map(r => r.id === updatedReview.id ? updatedReview : r));
    // Update stats
    setStats(prev => ({
      ...prev,
      needsResponse: prev.needsResponse - 1
    }));
  };

  const hasMoreReviews = reviews.length < totalReviews;

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
            <span className="text-slate-400 text-sm">Note moyenne</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats.averageRating.toFixed(1)}</p>
        </div>
        
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare className="w-5 h-5 text-blue-400" />
            <span className="text-slate-400 text-sm">Total avis</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats.totalReviews}</p>
        </div>
        
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-5 h-5 text-orange-400" />
            <span className="text-slate-400 text-sm">Sans réponse</span>
          </div>
          <p className="text-2xl font-bold text-orange-400">{stats.needsResponse}</p>
        </div>
        
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
            <span className="text-slate-400 text-sm">Positifs (4-5)</span>
          </div>
          <p className="text-2xl font-bold text-green-400">{stats.positiveReviews}</p>
        </div>
        
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="w-5 h-5 text-red-400" />
            <span className="text-slate-400 text-sm">Négatifs (1-2)</span>
          </div>
          <p className="text-2xl font-bold text-red-400">{stats.negativeReviews}</p>
        </div>
      </div>

      {/* Tips Banner */}
      {stats.needsResponse > 0 && (
        <div className="bg-orange-500/10 rounded-xl p-4 border border-orange-500/30">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-orange-400 mt-0.5" />
            <div>
              <p className="text-orange-300 font-medium">
                Vous avez {stats.needsResponse} avis sans réponse
              </p>
              <p className="text-slate-400 text-sm mt-1">
                Répondre aux avis montre que vous vous souciez de vos clients et peut améliorer votre réputation.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Filter */}
      <div className="flex items-center justify-between">
        <h3 className="text-white font-semibold">Avis clients</h3>
        <div className="flex items-center gap-3">
          <Select value={filter} onValueChange={(v: any) => setFilter(v)}>
            <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="Filtrer" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les avis</SelectItem>
              <SelectItem value="needs_response">Sans réponse</SelectItem>
              <SelectItem value="responded">Avec réponse</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Loading state */}
      {loading && reviews.length === 0 && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
        </div>
      )}

      {/* Empty state */}
      {!loading && reviews.length === 0 && (
        <div className="text-center py-12 bg-slate-800/50 rounded-xl border border-slate-700">
          <MessageSquare className="w-12 h-12 text-slate-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-white mb-2">
            {filter === 'needs_response' 
              ? 'Tous les avis ont une réponse!'
              : filter === 'responded'
              ? 'Aucun avis avec réponse'
              : 'Aucun avis pour le moment'
            }
          </h3>
          <p className="text-slate-400">
            {filter === 'all' && 'Les avis de vos clients apparaîtront ici.'}
          </p>
        </div>
      )}

      {/* Reviews list */}
      <div className="space-y-4">
        {reviews.map(review => (
          <ReviewCard
            key={review.id}
            review={review}
            currentUserId={user?.id}
            isSeller={true}
            sellerId={user?.id}
            onReviewUpdated={handleReviewUpdated}
            showProductInfo={true}
          />
        ))}
      </div>

      {/* Load more button */}
      {hasMoreReviews && (
        <div className="text-center pt-4">
          <Button
            variant="outline"
            onClick={handleLoadMore}
            disabled={loadingMore}
            className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700"
          >
            {loadingMore ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Chargement...
              </>
            ) : (
              <>
                <ChevronDown className="w-4 h-4 mr-2" />
                Charger plus d'avis
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
