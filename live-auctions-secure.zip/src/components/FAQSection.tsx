import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "Comment fonctionne PITCH ?",
      answer: "PITCH est une plateforme qui connecte acheteurs et vendeurs via des diffusions en direct. Vous pouvez regarder les lives, découvrir des produits, puis contacter directement les vendeurs via WhatsApp ou téléphone pour finaliser vos achats."
    },
    {
      question: "Comment contacter un vendeur ?",
      answer: "Cliquez sur le bouton 'Contacter le vendeur' sur n'importe quel produit. Vous pourrez alors choisir de contacter le vendeur via WhatsApp, par téléphone, ou par message sur la plateforme. Le vendeur vous répondra directement."
    },
    {
      question: "Comment se passe le paiement ?",
      answer: "Les paiements se font directement entre vous et le vendeur. Vous pouvez convenir du mode de paiement qui vous convient : espèces à la livraison, mobile money (Orange Money, MTN MoMo, Wave), ou virement bancaire."
    },
    {
      question: "Comment fonctionne la livraison ?",
      answer: "La livraison est organisée directement avec le vendeur. Vous convenez ensemble du lieu, de la date et des frais de livraison. Certains vendeurs proposent la livraison gratuite à Abidjan."
    },
    {
      question: "Les vendeurs sont-ils vérifiés ?",
      answer: "Oui, tous nos vendeurs passent par un processus de vérification. Nous vérifions leur identité et leurs coordonnées. Les vendeurs avec le badge vérifié ont fourni des documents officiels."
    },
    {
      question: "Que faire en cas de problème avec un vendeur ?",
      answer: "Si vous rencontrez un problème, contactez notre service client. Nous pouvons intervenir comme médiateur et, si nécessaire, suspendre les vendeurs qui ne respectent pas nos règles de confiance."
    },
    {
      question: "Comment devenir vendeur sur PITCH ?",
      answer: "Inscrivez-vous en tant que vendeur, choisissez votre abonnement, et complétez la vérification de votre profil. Une fois approuvé, vous pourrez créer des lives et publier vos produits."
    },
    {
      question: "Puis-je négocier les prix ?",
      answer: "Absolument ! L'un des avantages de PITCH est la possibilité de négocier directement avec les vendeurs. Contactez-les et discutez du prix, surtout pour les achats en quantité."
    }
  ];

  return (
    <section className="py-20 bg-slate-800">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-500 rounded-full text-sm font-semibold mb-4">
            <HelpCircle className="w-4 h-4" />
            FAQ
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Questions{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">
              Fréquentes
            </span>
          </h2>
          <p className="text-slate-400">
            Tout ce que vous devez savoir sur PITCH
          </p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-slate-900/50 rounded-2xl border border-slate-700 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-slate-800/50 transition-colors"
              >
                <span className="text-white font-medium pr-4">{faq.question}</span>
                <ChevronDown 
                  className={`w-5 h-5 text-red-500 flex-shrink-0 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-6 pb-5 text-slate-400 leading-relaxed">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact Support */}
        <div className="mt-12 text-center">
          <p className="text-slate-400 mb-4">
            Vous avez d'autres questions ?
          </p>
          <a
            href="mailto:support@livepitch.ci"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all"
          >
            Contactez-nous
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
