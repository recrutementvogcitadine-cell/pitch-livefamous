import React, { useState, useEffect } from 'react';
import { 
  X, Package, MapPin, Phone, User, 
  Truck, CheckCircle, Loader2, Banknote,
  ChevronRight, MessageCircle, Tag, Percent
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders } from '@/hooks/useOrders';
import { usePromoCodes, PromoValidationResult } from '@/hooks/usePromoCodes';
import { toast } from '@/components/ui/use-toast';
import { formatPrice } from '@/data/mockData';

interface OrderProduct {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  seller: string;
  sellerId?: string;
  sellerPhone?: string;
  quantity?: number;
}

interface OrderFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: OrderProduct | null;
  quantity?: number;
  onOrderSuccess?: (orderId: string) => void;
}


const OrderFormModal: React.FC<OrderFormModalProps> = ({ 
  isOpen, 
  onClose, 
  product,
  quantity: initialQuantity,
  onOrderSuccess 
}) => {

  const { user } = useAuth();
  const { loading, createOrder } = useOrders();
  const { validatePromoCode, applyPromoCode, loading: promoLoading } = usePromoCodes();

  // 3 steps: name, contact, location + confirm + success
  const [step, setStep] = useState<'name' | 'contact' | 'location' | 'confirm' | 'success'>('name');
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [createdOrderId, setCreatedOrderId] = useState<string | null>(null);

  // Form fields - 3 simple fields
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryLocation, setDeliveryLocation] = useState('');

  // Promo code fields
  const [promoCode, setPromoCode] = useState('');
  const [promoValidation, setPromoValidation] = useState<PromoValidationResult | null>(null);
  const [promoApplied, setPromoApplied] = useState(false);

  // Shipping fee
  const shippingFee = 2000;

  useEffect(() => {
    if (isOpen) {
      setStep('name');
      setQuantity(initialQuantity || product?.quantity || 1);
      // Reset form
      setCustomerName('');
      setCustomerPhone('');
      setDeliveryLocation('');
      setNotes('');
      setCreatedOrderId(null);
      // Reset promo code
      setPromoCode('');
      setPromoValidation(null);
      setPromoApplied(false);
    }
  }, [isOpen, initialQuantity, product?.quantity]);

  const handleValidatePromoCode = async () => {
    if (!promoCode.trim() || !product?.sellerId) {
      toast({
        title: "Erreur",
        description: "Veuillez entrer un code promo",
        variant: "destructive"
      });
      return;
    }

    const subtotal = product.price * quantity;
    const result = await validatePromoCode({
      code: promoCode,
      seller_id: product.sellerId,
      order_amount: subtotal,
      product_id: product.id,
      user_email: user?.email
    });

    setPromoValidation(result);
    
    if (result.valid) {
      setPromoApplied(true);
      toast({
        title: "Code promo appliqué!",
        description: `Réduction de ${formatPrice(result.discount || 0)} appliquée`,
      });
    } else {
      setPromoApplied(false);
      toast({
        title: "Code promo invalide",
        description: result.error || "Ce code promo ne peut pas être appliqué",
        variant: "destructive"
      });
    }
  };

  const handleRemovePromoCode = () => {
    setPromoCode('');
    setPromoValidation(null);
    setPromoApplied(false);
  };

  const handleSubmitOrder = async () => {
    if (!product) {
      toast({
        title: "Erreur",
        description: "Aucun produit sélectionné",
        variant: "destructive"
      });
      return;
    }

    if (!customerName.trim() || !customerPhone.trim() || !deliveryLocation.trim()) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir toutes les informations",
        variant: "destructive"
      });
      return;
    }

    setSubmitting(true);
    try {
      const order = await createOrder(
        user?.id || 'guest',
        product.sellerId || 'seller-1',
        [{
          product_id: product.id,
          product_name: product.name,
          product_image: product.image,
          quantity: quantity,
          unit_price: product.price
        }],
        `${customerName}|${customerPhone}|${deliveryLocation}`, // Combined address info
        'cod', // Cash on delivery - only payment method
        notes + (promoApplied && promoValidation?.promo ? ` | Code promo: ${promoValidation.promo.code} (-${formatPrice(promoValidation.discount || 0)})` : ''),
        shippingFee - (promoValidation?.discount || 0) // Adjust shipping with discount
      );

      if (order) {
        // Apply promo code usage if one was used
        if (promoApplied && promoValidation?.promo) {
          try {
            await applyPromoCode({
              promo_code_id: promoValidation.promo.id,
              order_id: order.id,
              user_id: user?.id,
              user_email: user?.email || customerPhone,
              discount_applied: promoValidation.discount || 0
            });
          } catch (e) {
            console.error('Failed to record promo code usage:', e);
          }
        }

        setCreatedOrderId(order.id);
        setStep('success');
        onOrderSuccess?.(order.id);
      } else {
        toast({
          title: "Erreur",
          description: "Impossible de créer la commande. Veuillez réessayer.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la création de la commande",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    setStep('name');
    setCustomerName('');
    setCustomerPhone('');
    setDeliveryLocation('');
    setQuantity(1);
    setNotes('');
    setCreatedOrderId(null);
    setPromoCode('');
    setPromoValidation(null);
    setPromoApplied(false);
    onClose();
  };

  const canProceedFromName = customerName.trim().length >= 2;
  const canProceedFromContact = customerPhone.trim().length >= 8;
  const canProceedFromLocation = deliveryLocation.trim().length >= 5;

  const subtotal = product ? product.price * quantity : 0;
  const discount = promoApplied && promoValidation?.discount ? promoValidation.discount : 0;
  const total = subtotal + shippingFee - discount;

  const getStepNumber = () => {
    switch (step) {
      case 'name': return 1;
      case 'contact': return 2;
      case 'location': return 3;
      case 'confirm': return 3;
      default: return 1;
    }
  };

  if (!isOpen || !product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
              <Package className="w-5 h-5 text-orange-500" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                {step === 'success' ? 'Commande confirmée' : 'Passer commande'}
              </h3>
              {step !== 'success' && step !== 'confirm' && (
                <p className="text-slate-400 text-sm">
                  Étape {getStepNumber()}/3 - {step === 'name' && 'Votre nom'}
                  {step === 'contact' && 'Votre contact'}
                  {step === 'location' && 'Lieu de livraison'}
                </p>
              )}
              {step === 'confirm' && (
                <p className="text-slate-400 text-sm">Confirmation de commande</p>
              )}
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        {step !== 'success' && (
          <div className="px-4 sm:px-6 pt-4">
            <div className="flex items-center gap-2">
              {[1, 2, 3].map((num) => (
                <React.Fragment key={num}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                    getStepNumber() >= num 
                      ? 'bg-orange-500 text-white' 
                      : 'bg-slate-700 text-slate-400'
                  }`}>
                    {getStepNumber() > num ? <CheckCircle className="w-5 h-5" /> : num}
                  </div>
                  {num < 3 && (
                    <div className={`flex-1 h-1 rounded-full transition-all ${
                      getStepNumber() > num ? 'bg-orange-500' : 'bg-slate-700'
                    }`} />
                  )}
                </React.Fragment>
              ))}
            </div>
            <div className="flex justify-between mt-2 text-xs text-slate-400">
              <span>Nom</span>
              <span>Contact</span>
              <span>Livraison</span>
            </div>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {/* Product Summary */}
          {step !== 'success' && (
            <div className="flex gap-4 p-4 bg-slate-800/50 rounded-xl border border-slate-700 mb-6">
              <img 
                src={product.image}
                alt={product.name}
                className="w-20 h-20 rounded-lg object-cover"
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-semibold line-clamp-2">{product.name}</h4>
                <p className="text-slate-400 text-sm mt-1">{product.seller}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-orange-500 font-bold">{formatPrice(product.price)}</span>
                  {product.originalPrice && (
                    <span className="text-slate-500 text-sm line-through">{formatPrice(product.originalPrice)}</span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Step 1: Name */}
          {step === 'name' && (
            <div className="space-y-6">
              <div>
                <label className="flex items-center gap-2 text-white font-semibold mb-3">
                  <User className="w-5 h-5 text-orange-500" />
                  Votre nom complet
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Entrez votre nom complet"
                  autoFocus
                  className="w-full px-4 py-4 bg-slate-800 border border-slate-700 rounded-xl text-white text-lg placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
                <p className="text-slate-500 text-sm mt-2">
                  Ce nom sera utilisé pour la livraison
                </p>
              </div>

              {/* Quantity */}
              <div className="pt-4 border-t border-slate-800">
                <label className="block text-white font-semibold mb-3">Quantité</label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 text-white font-bold text-xl hover:border-orange-500 transition-colors"
                  >
                    -
                  </button>
                  <span className="text-white font-bold text-2xl w-16 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 text-white font-bold text-xl hover:border-orange-500 transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Contact */}
          {step === 'contact' && (
            <div className="space-y-6">
              <div>
                <label className="flex items-center gap-2 text-white font-semibold mb-3">
                  <Phone className="w-5 h-5 text-orange-500" />
                  Votre numéro de téléphone
                </label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="+225 XX XX XX XX XX"
                  autoFocus
                  className="w-full px-4 py-4 bg-slate-800 border border-slate-700 rounded-xl text-white text-lg placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
                <p className="text-slate-500 text-sm mt-2">
                  Le vendeur vous contactera sur ce numéro pour confirmer la commande
                </p>
              </div>
            </div>
          )}

          {/* Step 3: Location */}
          {step === 'location' && (
            <div className="space-y-6">
              <div>
                <label className="flex items-center gap-2 text-white font-semibold mb-3">
                  <MapPin className="w-5 h-5 text-orange-500" />
                  Lieu de livraison
                </label>
                <textarea
                  value={deliveryLocation}
                  onChange={(e) => setDeliveryLocation(e.target.value)}
                  placeholder="Quartier, rue, repère proche, commune..."
                  rows={4}
                  autoFocus
                  className="w-full px-4 py-4 bg-slate-800 border border-slate-700 rounded-xl text-white text-lg placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                />
                <p className="text-slate-500 text-sm mt-2">
                  Soyez précis pour faciliter la livraison (ex: Cocody Angré, près de la pharmacie...)
                </p>
              </div>

              {/* Notes */}
              <div>
                <label className="flex items-center gap-2 text-white font-semibold mb-3">
                  <MessageCircle className="w-5 h-5 text-slate-400" />
                  Notes supplémentaires (optionnel)
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Instructions spéciales pour le vendeur ou le livreur..."
                  rows={2}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                />
              </div>
            </div>
          )}

          {/* Confirm Step */}
          {step === 'confirm' && (
            <div className="space-y-4">
              <h4 className="text-white font-semibold flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-orange-500" />
                Récapitulatif de la commande
              </h4>

              {/* Customer Info */}
              <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 space-y-3">
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-orange-500 mt-0.5" />
                  <div>
                    <p className="text-slate-400 text-sm">Nom</p>
                    <p className="text-white font-medium">{customerName}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-orange-500 mt-0.5" />
                  <div>
                    <p className="text-slate-400 text-sm">Contact</p>
                    <p className="text-white font-medium">{customerPhone}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-orange-500 mt-0.5" />
                  <div>
                    <p className="text-slate-400 text-sm">Lieu de livraison</p>
                    <p className="text-white font-medium">{deliveryLocation}</p>
                  </div>
                </div>
              </div>

              {/* Promo Code Section */}
              <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                <label className="flex items-center gap-2 text-white font-semibold mb-3">
                  <Tag className="w-5 h-5 text-purple-400" />
                  Code promo
                </label>
                
                {promoApplied && promoValidation?.promo ? (
                  <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Percent className="w-5 h-5 text-green-400" />
                      <div>
                        <p className="text-green-400 font-semibold">{promoValidation.promo.code}</p>
                        <p className="text-slate-400 text-sm">
                          {promoValidation.promo.discount_type === 'percentage' 
                            ? `${promoValidation.promo.discount_value}% de réduction`
                            : `${formatPrice(promoValidation.promo.discount_value)} de réduction`
                          }
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={handleRemovePromoCode}
                      className="text-slate-400 hover:text-red-400 transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                      placeholder="Entrez votre code"
                      className="flex-1 px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent uppercase"
                    />
                    <button
                      onClick={handleValidatePromoCode}
                      disabled={promoLoading || !promoCode.trim()}
                      className="px-4 py-3 bg-purple-500 text-white font-semibold rounded-lg hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      {promoLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        'Appliquer'
                      )}
                    </button>
                  </div>
                )}
                
                {promoValidation && !promoValidation.valid && (
                  <p className="text-red-400 text-sm mt-2">{promoValidation.error}</p>
                )}
              </div>

              {/* Payment Method - Cash on Delivery Only */}
              <div className="p-4 bg-green-500/10 rounded-xl border border-green-500/30">
                <div className="flex items-start gap-3">
                  <Banknote className="w-6 h-6 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-green-400 font-semibold">Paiement à la livraison</p>
                    <p className="text-slate-400 text-sm mt-1">
                      Vous paierez directement au vendeur ou au livreur lors de la réception de votre commande.
                    </p>
                  </div>
                </div>
              </div>

              {/* Order Summary */}
              <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 space-y-3">
                <div className="flex justify-between text-slate-400">
                  <span>Sous-total ({quantity} article{quantity > 1 ? 's' : ''})</span>
                  <span className="text-white">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span className="flex items-center gap-1">
                    <Truck className="w-4 h-4" />
                    Frais de livraison
                  </span>
                  <span className="text-white">{formatPrice(shippingFee)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-400">
                    <span className="flex items-center gap-1">
                      <Tag className="w-4 h-4" />
                      Réduction ({promoValidation?.promo?.code})
                    </span>
                    <span>-{formatPrice(discount)}</span>
                  </div>
                )}
                <div className="pt-3 border-t border-slate-700 flex justify-between">
                  <span className="text-white font-semibold">Total à payer</span>
                  <span className="text-orange-500 font-bold text-xl">{formatPrice(total)}</span>
                </div>
              </div>

              {notes && (
                <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-2 text-slate-400 text-sm mb-2">
                    <MessageCircle className="w-4 h-4" />
                    Notes
                  </div>
                  <p className="text-white text-sm">{notes}</p>
                </div>
              )}
            </div>
          )}

          {/* Success Step */}
          {step === 'success' && (
            <div className="text-center py-8">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-green-500/20 flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-green-500" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Commande confirmée!</h3>
              <p className="text-slate-400 mb-6">
                Votre commande a été enregistrée avec succès. Le vendeur va vous contacter au <span className="text-orange-400 font-medium">{customerPhone}</span> pour confirmer les détails.
              </p>
              
              {createdOrderId && (
                <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 mb-6">
                  <p className="text-slate-400 text-sm">Numéro de commande</p>
                  <p className="text-orange-500 font-bold text-lg">{createdOrderId.slice(0, 8).toUpperCase()}</p>
                </div>
              )}

              {/* Discount Applied */}
              {discount > 0 && (
                <div className="p-4 bg-purple-500/10 rounded-xl border border-purple-500/30 mb-6 text-left">
                  <div className="flex items-start gap-3">
                    <Tag className="w-6 h-6 text-purple-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-purple-400 font-semibold">Code promo appliqué</p>
                      <p className="text-slate-400 text-sm mt-1">
                        Vous avez économisé <span className="text-white font-bold">{formatPrice(discount)}</span> avec le code {promoValidation?.promo?.code}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Payment Reminder */}
              <div className="p-4 bg-green-500/10 rounded-xl border border-green-500/30 mb-6 text-left">
                <div className="flex items-start gap-3">
                  <Banknote className="w-6 h-6 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-green-400 font-semibold">Rappel: Paiement à la livraison</p>
                    <p className="text-slate-400 text-sm mt-1">
                      Préparez <span className="text-white font-bold">{formatPrice(total)}</span> pour le paiement lors de la livraison.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <button
                  onClick={handleClose}
                  className="w-full py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all"
                >
                  Continuer mes achats
                </button>
                <button
                  onClick={() => {
                    handleClose();
                    window.location.href = '/profile';
                  }}
                  className="w-full py-3 bg-slate-800 text-white font-semibold rounded-xl border border-slate-700 hover:border-orange-500/50 transition-all"
                >
                  Voir mes commandes
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {step !== 'success' && (
          <div className="p-4 sm:p-6 border-t border-slate-800 shrink-0">
            {/* Price Summary */}
            {step !== 'confirm' && (
              <div className="flex justify-between items-center mb-4">
                <span className="text-slate-400">Total estimé</span>
                <span className="text-orange-500 font-bold text-xl">{formatPrice(total)}</span>
              </div>
            )}

            <div className="flex gap-3">
              {step !== 'name' && (
                <button
                  onClick={() => {
                    if (step === 'contact') setStep('name');
                    if (step === 'location') setStep('contact');
                    if (step === 'confirm') setStep('location');
                  }}
                  className="px-6 py-3 bg-slate-800 text-slate-300 font-semibold rounded-xl border border-slate-700 hover:border-slate-600 transition-all"
                >
                  Retour
                </button>
              )}
              
              {step === 'name' && (
                <button
                  onClick={() => setStep('contact')}
                  disabled={!canProceedFromName}
                  className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  Continuer
                  <ChevronRight className="w-5 h-5" />
                </button>
              )}

              {step === 'contact' && (
                <button
                  onClick={() => setStep('location')}
                  disabled={!canProceedFromContact}
                  className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  Continuer
                  <ChevronRight className="w-5 h-5" />
                </button>
              )}

              {step === 'location' && (
                <button
                  onClick={() => setStep('confirm')}
                  disabled={!canProceedFromLocation}
                  className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  Vérifier la commande
                  <ChevronRight className="w-5 h-5" />
                </button>
              )}

              {step === 'confirm' && (
                <button
                  onClick={handleSubmitOrder}
                  disabled={submitting}
                  className="flex-1 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-green-500/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Traitement...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      Confirmer la commande
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrderFormModal;
