import React, { useState, useEffect } from 'react';
import {
  Package, Plus, Search, Filter, Edit2, Trash2, Eye, EyeOff,
  ChevronDown, ChevronUp, X, Image, Tag, DollarSign, Box,
  BarChart3, TrendingUp, AlertCircle, CheckCircle, Star, Loader2
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useProducts, SellerProduct, ProductStats, CreateProductData } from '@/hooks/useProducts';
import { formatPrice } from '@/data/mockData';
import { toast } from '@/components/ui/use-toast';

const categories = [
  'Électronique', 'Mode', 'Beauté', 'Maison', 'Bijoux', 
  'Chaussures', 'Auto', 'Accessoires', 'Sport', 'Alimentation'
];

const SellerProductsTab: React.FC = () => {
  const { user } = useAuth();
  const {
    loading,
    getSellerProducts,
    createProduct,
    updateProduct,
    deleteProduct,
    toggleProductStatus,
    getProductStats,
    bulkDelete,
    bulkUpdateStatus
  } = useProducts();

  const [products, setProducts] = useState<SellerProduct[]>([]);
  const [stats, setStats] = useState<ProductStats | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<SellerProduct | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  
  const [productForm, setProductForm] = useState<CreateProductData>({
    name: '',
    description: '',
    price: 0,
    originalPrice: undefined,
    category: 'Électronique',
    imageUrl: '',
    stockQuantity: 0,
    sku: '',
    isActive: true,
    isFeatured: false,
    tags: []
  });

  useEffect(() => {
    if (user) {
      fetchProducts();
      fetchStats();
    }
  }, [user, statusFilter, categoryFilter, currentPage]);

  const fetchProducts = async () => {
    if (!user) return;
    const result = await getSellerProducts(
      user.id,
      statusFilter !== 'all' ? statusFilter : undefined,
      categoryFilter !== 'all' ? categoryFilter : undefined,
      searchQuery || undefined,
      currentPage,
      12
    );
    setProducts(result.products);
    setTotalPages(result.totalPages);
  };

  const fetchStats = async () => {
    if (!user) return;
    const result = await getProductStats(user.id);
    setStats(result);
  };

  const handleSearch = () => {
    setCurrentPage(1);
    fetchProducts();
  };

  const handleCreateProduct = async () => {
    if (!user) return;
    if (!productForm.name || !productForm.price) {
      toast({
        title: "Champs requis",
        description: "Le nom et le prix sont obligatoires",
        variant: "destructive"
      });
      return;
    }

    const result = await createProduct(user.id, productForm);
    if (result) {
      toast({
        title: "Produit créé",
        description: "Votre produit a été ajouté avec succès"
      });
      setShowProductModal(false);
      resetForm();
      fetchProducts();
      fetchStats();
    }
  };

  const handleUpdateProduct = async () => {
    if (!user || !editingProduct) return;
    
    const result = await updateProduct(editingProduct.id, user.id, productForm);
    if (result) {
      toast({
        title: "Produit mis à jour",
        description: "Les modifications ont été enregistrées"
      });
      setShowProductModal(false);
      setEditingProduct(null);
      resetForm();
      fetchProducts();
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!user) return;
    
    const result = await deleteProduct(productId, user.id);
    if (result) {
      toast({
        title: "Produit supprimé",
        description: "Le produit a été supprimé de votre catalogue"
      });
      setShowDeleteConfirm(null);
      fetchProducts();
      fetchStats();
    }
  };

  const handleToggleStatus = async (product: SellerProduct) => {
    if (!user) return;
    
    const result = await toggleProductStatus(product.id, user.id, !product.is_active);
    if (result) {
      toast({
        title: product.is_active ? "Produit désactivé" : "Produit activé",
        description: product.is_active 
          ? "Le produit n'est plus visible pour les acheteurs"
          : "Le produit est maintenant visible"
      });
      fetchProducts();
      fetchStats();
    }
  };

  const handleBulkDelete = async () => {
    if (!user || selectedProducts.length === 0) return;
    
    if (confirm(`Supprimer ${selectedProducts.length} produit(s) ?`)) {
      const result = await bulkDelete(selectedProducts, user.id);
      if (result) {
        toast({
          title: "Produits supprimés",
          description: `${selectedProducts.length} produit(s) supprimé(s)`
        });
        setSelectedProducts([]);
        fetchProducts();
        fetchStats();
      }
    }
  };

  const handleBulkToggle = async (activate: boolean) => {
    if (!user || selectedProducts.length === 0) return;
    
    const result = await bulkUpdateStatus(selectedProducts, user.id, activate);
    if (result) {
      toast({
        title: activate ? "Produits activés" : "Produits désactivés",
        description: `${selectedProducts.length} produit(s) mis à jour`
      });
      setSelectedProducts([]);
      fetchProducts();
      fetchStats();
    }
  };

  const resetForm = () => {
    setProductForm({
      name: '',
      description: '',
      price: 0,
      originalPrice: undefined,
      category: 'Électronique',
      imageUrl: '',
      stockQuantity: 0,
      sku: '',
      isActive: true,
      isFeatured: false,
      tags: []
    });
  };

  const openEditModal = (product: SellerProduct) => {
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      description: product.description || '',
      price: product.price,
      originalPrice: product.original_price,
      category: product.category,
      imageUrl: product.image_url || '',
      stockQuantity: product.stock_quantity,
      sku: product.sku || '',
      isActive: product.is_active,
      isFeatured: product.is_featured,
      tags: product.tags || []
    });
    setShowProductModal(true);
  };

  const toggleSelectProduct = (productId: string) => {
    setSelectedProducts(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const toggleSelectAll = () => {
    if (selectedProducts.length === products.length) {
      setSelectedProducts([]);
    } else {
      setSelectedProducts(products.map(p => p.id));
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Package className="w-5 h-5 text-white" />
            </div>
            <span className="text-slate-400 text-sm">Total</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats?.total || 0}</p>
        </div>
        <div className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-white" />
            </div>
            <span className="text-slate-400 text-sm">Actifs</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats?.active || 0}</p>
        </div>
        <div className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-slate-400 text-sm">Ventes</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats?.totalSales || 0}</p>
        </div>
        <div className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-pink-500 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-white" />
            </div>
            <span className="text-slate-400 text-sm">Rupture</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats?.outOfStock || 0}</p>
        </div>
      </div>

      {/* Filters & Actions */}
      <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher un produit..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
          >
            <option value="all">Tous les statuts</option>
            <option value="active">Actifs</option>
            <option value="inactive">Inactifs</option>
          </select>

          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
          >
            <option value="all">Toutes catégories</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          {/* Add Product Button */}
          <button
            onClick={() => {
              resetForm();
              setEditingProduct(null);
              setShowProductModal(true);
            }}
            className="px-6 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all flex items-center gap-2 whitespace-nowrap"
          >
            <Plus className="w-5 h-5" />
            Ajouter un produit
          </button>
        </div>

        {/* Bulk Actions */}
        {selectedProducts.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-700 flex items-center gap-4">
            <span className="text-slate-400 text-sm">{selectedProducts.length} sélectionné(s)</span>
            <button
              onClick={() => handleBulkToggle(true)}
              className="px-3 py-1.5 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium hover:bg-green-500/30 transition-colors"
            >
              Activer
            </button>
            <button
              onClick={() => handleBulkToggle(false)}
              className="px-3 py-1.5 bg-yellow-500/20 text-yellow-400 rounded-lg text-sm font-medium hover:bg-yellow-500/30 transition-colors"
            >
              Désactiver
            </button>
            <button
              onClick={handleBulkDelete}
              className="px-3 py-1.5 bg-red-500/20 text-red-400 rounded-lg text-sm font-medium hover:bg-red-500/30 transition-colors"
            >
              Supprimer
            </button>
            <button
              onClick={() => setSelectedProducts([])}
              className="px-3 py-1.5 bg-slate-700 text-slate-300 rounded-lg text-sm font-medium hover:bg-slate-600 transition-colors"
            >
              Annuler
            </button>
          </div>
        )}
      </div>

      {/* Products Grid */}
      {loading && products.length === 0 ? (
        <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
          <Loader2 className="w-12 h-12 text-orange-500 mx-auto mb-4 animate-spin" />
          <p className="text-slate-400">Chargement des produits...</p>
        </div>
      ) : products.length === 0 ? (
        <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
          <Package className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <h3 className="text-white text-xl font-semibold mb-2">Aucun produit</h3>
          <p className="text-slate-400 mb-6">Commencez par ajouter votre premier produit</p>
          <button
            onClick={() => {
              resetForm();
              setShowProductModal(true);
            }}
            className="px-6 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all"
          >
            Ajouter mon premier produit
          </button>
        </div>
      ) : (
        <>
          {/* Select All */}
          <div className="flex items-center gap-3 px-2">
            <input
              type="checkbox"
              checked={selectedProducts.length === products.length && products.length > 0}
              onChange={toggleSelectAll}
              className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-orange-500 focus:ring-orange-500"
            />
            <span className="text-slate-400 text-sm">Tout sélectionner</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {products.map(product => (
              <div
                key={product.id}
                className={`bg-slate-800/50 rounded-2xl border overflow-hidden transition-all ${
                  selectedProducts.includes(product.id) 
                    ? 'border-orange-500' 
                    : 'border-slate-700 hover:border-slate-600'
                }`}
              >
                {/* Product Image */}
                <div className="relative aspect-square bg-slate-900">
                  {product.image_url ? (
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Image className="w-12 h-12 text-slate-600" />
                    </div>
                  )}
                  
                  {/* Checkbox */}
                  <div className="absolute top-3 left-3">
                    <input
                      type="checkbox"
                      checked={selectedProducts.includes(product.id)}
                      onChange={() => toggleSelectProduct(product.id)}
                      className="w-5 h-5 rounded border-slate-600 bg-slate-800/80 text-orange-500 focus:ring-orange-500"
                    />
                  </div>

                  {/* Status Badge */}
                  <div className="absolute top-3 right-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      product.is_active 
                        ? 'bg-green-500/20 text-green-400' 
                        : 'bg-red-500/20 text-red-400'
                    }`}>
                      {product.is_active ? 'Actif' : 'Inactif'}
                    </span>
                  </div>

                  {/* Featured Badge */}
                  {product.is_featured && (
                    <div className="absolute bottom-3 left-3">
                      <span className="px-2 py-1 bg-orange-500 text-white text-xs font-medium rounded-full flex items-center gap-1">
                        <Star className="w-3 h-3" />
                        En vedette
                      </span>
                    </div>
                  )}
                </div>

                {/* Product Info */}
                <div className="p-4">
                  <h4 className="text-white font-semibold mb-1 line-clamp-1">{product.name}</h4>
                  <p className="text-slate-400 text-sm mb-2">{product.category}</p>
                  
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-orange-500 font-bold">{formatPrice(product.price)}</span>
                    {product.original_price && product.original_price > product.price && (
                      <span className="text-slate-500 text-sm line-through">
                        {formatPrice(product.original_price)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400 mb-4">
                    <span className="flex items-center gap-1">
                      <Box className="w-3 h-3" />
                      Stock: {product.stock_quantity}
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {product.views} vues
                    </span>
                    <span className="flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      {product.sales_count} ventes
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => openEditModal(product)}
                      className="flex-1 px-3 py-2 bg-slate-700 text-white rounded-lg text-sm font-medium hover:bg-slate-600 transition-colors flex items-center justify-center gap-1"
                    >
                      <Edit2 className="w-4 h-4" />
                      Modifier
                    </button>
                    <button
                      onClick={() => handleToggleStatus(product)}
                      className={`p-2 rounded-lg transition-colors ${
                        product.is_active 
                          ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30' 
                          : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                      }`}
                      title={product.is_active ? 'Désactiver' : 'Activer'}
                    >
                      {product.is_active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => setShowDeleteConfirm(product.id)}
                      className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                      title="Supprimer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-4 py-2 bg-slate-700 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-600 transition-colors"
              >
                Précédent
              </button>
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let page;
                  if (totalPages <= 5) {
                    page = i + 1;
                  } else if (currentPage <= 3) {
                    page = i + 1;
                  } else if (currentPage >= totalPages - 2) {
                    page = totalPages - 4 + i;
                  } else {
                    page = currentPage - 2 + i;
                  }
                  return (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`w-10 h-10 rounded-xl font-medium transition-colors ${
                        currentPage === page
                          ? 'bg-orange-500 text-white'
                          : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                      }`}
                    >
                      {page}
                    </button>
                  );
                })}
              </div>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-4 py-2 bg-slate-700 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-600 transition-colors"
              >
                Suivant
              </button>
            </div>
          )}
        </>
      )}

      {/* Product Modal */}
      {showProductModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-800 rounded-2xl w-full max-w-2xl my-8">
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <h3 className="text-white text-xl font-bold">
                  {editingProduct ? 'Modifier le produit' : 'Ajouter un produit'}
                </h3>
                <button 
                  onClick={() => {
                    setShowProductModal(false);
                    setEditingProduct(null);
                    resetForm();
                  }} 
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
              {/* Name */}
              <div>
                <label className="block text-white font-medium mb-2">Nom du produit *</label>
                <input
                  type="text"
                  value={productForm.name}
                  onChange={(e) => setProductForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Ex: iPhone 15 Pro Max"
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-white font-medium mb-2">Description</label>
                <textarea
                  value={productForm.description}
                  onChange={(e) => setProductForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Décrivez votre produit..."
                  rows={3}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 resize-none"
                />
              </div>

              {/* Price & Original Price */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-white font-medium mb-2">Prix (FCFA) *</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="number"
                      value={productForm.price || ''}
                      onChange={(e) => setProductForm(prev => ({ ...prev, price: Number(e.target.value) }))}
                      placeholder="0"
                      className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-white font-medium mb-2">Prix barré (optionnel)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="number"
                      value={productForm.originalPrice || ''}
                      onChange={(e) => setProductForm(prev => ({ ...prev, originalPrice: e.target.value ? Number(e.target.value) : undefined }))}
                      placeholder="0"
                      className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>
              </div>

              {/* Category & Stock */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-white font-medium mb-2">Catégorie</label>
                  <select
                    value={productForm.category}
                    onChange={(e) => setProductForm(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-white font-medium mb-2">Stock</label>
                  <div className="relative">
                    <Box className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="number"
                      value={productForm.stockQuantity || ''}
                      onChange={(e) => setProductForm(prev => ({ ...prev, stockQuantity: Number(e.target.value) }))}
                      placeholder="0"
                      className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>
              </div>

              {/* Image URL & SKU */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-white font-medium mb-2">URL de l'image</label>
                  <div className="relative">
                    <Image className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="url"
                      value={productForm.imageUrl}
                      onChange={(e) => setProductForm(prev => ({ ...prev, imageUrl: e.target.value }))}
                      placeholder="https://..."
                      className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-white font-medium mb-2">SKU (optionnel)</label>
                  <div className="relative">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      value={productForm.sku}
                      onChange={(e) => setProductForm(prev => ({ ...prev, sku: e.target.value }))}
                      placeholder="REF-001"
                      className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>
              </div>

              {/* Options */}
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={productForm.isActive}
                    onChange={(e) => setProductForm(prev => ({ ...prev, isActive: e.target.checked }))}
                    className="w-5 h-5 rounded border-slate-600 bg-slate-800 text-orange-500 focus:ring-orange-500"
                  />
                  <span className="text-white">Produit actif</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={productForm.isFeatured}
                    onChange={(e) => setProductForm(prev => ({ ...prev, isFeatured: e.target.checked }))}
                    className="w-5 h-5 rounded border-slate-600 bg-slate-800 text-orange-500 focus:ring-orange-500"
                  />
                  <span className="text-white">Mettre en vedette</span>
                </label>
              </div>

              {/* Image Preview */}
              {productForm.imageUrl && (
                <div>
                  <label className="block text-white font-medium mb-2">Aperçu</label>
                  <div className="w-32 h-32 rounded-xl overflow-hidden bg-slate-900">
                    <img 
                      src={productForm.imageUrl} 
                      alt="Aperçu" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="p-6 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowProductModal(false);
                  setEditingProduct(null);
                  resetForm();
                }}
                className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
              >
                Annuler
              </button>
              <button
                onClick={editingProduct ? handleUpdateProduct : handleCreateProduct}
                disabled={loading}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : editingProduct ? (
                  <>
                    <CheckCircle className="w-5 h-5" />
                    Enregistrer
                  </>
                ) : (
                  <>
                    <Plus className="w-5 h-5" />
                    Créer le produit
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-md p-6">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-500/20 flex items-center justify-center">
                <Trash2 className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-white text-xl font-bold mb-2">Supprimer ce produit ?</h3>
              <p className="text-slate-400 mb-6">
                Cette action est irréversible. Le produit sera définitivement supprimé de votre catalogue.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(null)}
                  className="flex-1 px-4 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
                >
                  Annuler
                </button>
                <button
                  onClick={() => handleDeleteProduct(showDeleteConfirm)}
                  disabled={loading}
                  className="flex-1 px-4 py-3 bg-red-500 text-white font-semibold rounded-xl hover:bg-red-600 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Trash2 className="w-5 h-5" />
                      Supprimer
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SellerProductsTab;
