import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { usePromoCodes, PromoCode, PromoCodeStats } from '@/hooks/usePromoCodes';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Pencil, Trash2, Copy, BarChart3, Tag, Percent, Calendar, Users, AlertCircle, CheckCircle, X } from 'lucide-react';
import { toast } from 'sonner';

export default function PromoCodesTab() {
  const { user } = useAuth();
  const { 
    loading, 
    promoCodes, 
    createPromoCode, 
    updatePromoCode, 
    deletePromoCode, 
    listPromoCodes,
    togglePromoCodeStatus,
    getPromoCodeStats
  } = usePromoCodes();

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showStatsModal, setShowStatsModal] = useState(false);
  const [selectedPromo, setSelectedPromo] = useState<PromoCode | null>(null);
  const [promoStats, setPromoStats] = useState<PromoCodeStats | null>(null);
  const [formData, setFormData] = useState({
    code: '',
    description: '',
    discount_type: 'percentage' as 'percentage' | 'fixed',
    discount_value: '',
    min_order_amount: '',
    max_discount_amount: '',
    usage_limit: '',
    start_date: '',
    end_date: ''
  });

  useEffect(() => {
    if (user?.id) {
      listPromoCodes(user.id);
    }
  }, [user?.id, listPromoCodes]);

  const resetForm = () => {
    setFormData({
      code: '',
      description: '',
      discount_type: 'percentage',
      discount_value: '',
      min_order_amount: '',
      max_discount_amount: '',
      usage_limit: '',
      start_date: '',
      end_date: ''
    });
  };

  const handleCreate = async () => {
    if (!user?.id || !formData.code || !formData.discount_value) {
      toast.error('Veuillez remplir les champs obligatoires');
      return;
    }

    try {
      await createPromoCode({
        seller_id: user.id,
        code: formData.code,
        description: formData.description || undefined,
        discount_type: formData.discount_type,
        discount_value: parseFloat(formData.discount_value),
        min_order_amount: formData.min_order_amount ? parseFloat(formData.min_order_amount) : undefined,
        max_discount_amount: formData.max_discount_amount ? parseFloat(formData.max_discount_amount) : undefined,
        usage_limit: formData.usage_limit ? parseInt(formData.usage_limit) : undefined,
        start_date: formData.start_date || undefined,
        end_date: formData.end_date || undefined
      });
      toast.success('Code promo créé avec succès !');
      setShowCreateModal(false);
      resetForm();
    } catch (err: any) {
      toast.error(err.message || 'Erreur lors de la création');
    }
  };

  const handleEdit = async () => {
    if (!selectedPromo) return;

    try {
      await updatePromoCode(selectedPromo.id, {
        code: formData.code,
        description: formData.description || null,
        discount_type: formData.discount_type,
        discount_value: parseFloat(formData.discount_value),
        min_order_amount: formData.min_order_amount ? parseFloat(formData.min_order_amount) : 0,
        max_discount_amount: formData.max_discount_amount ? parseFloat(formData.max_discount_amount) : null,
        usage_limit: formData.usage_limit ? parseInt(formData.usage_limit) : null,
        start_date: formData.start_date || selectedPromo.start_date,
        end_date: formData.end_date || null
      });
      toast.success('Code promo mis à jour !');
      setShowEditModal(false);
      setSelectedPromo(null);
      resetForm();
    } catch (err: any) {
      toast.error(err.message || 'Erreur lors de la mise à jour');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce code promo ?')) return;

    try {
      await deletePromoCode(id);
      toast.success('Code promo supprimé');
    } catch (err: any) {
      toast.error(err.message || 'Erreur lors de la suppression');
    }
  };

  const handleToggleStatus = async (promo: PromoCode) => {
    try {
      await togglePromoCodeStatus(promo.id, !promo.is_active);
      toast.success(promo.is_active ? 'Code promo désactivé' : 'Code promo activé');
    } catch (err: any) {
      toast.error(err.message || 'Erreur lors du changement de statut');
    }
  };

  const openEditModal = (promo: PromoCode) => {
    setSelectedPromo(promo);
    setFormData({
      code: promo.code,
      description: promo.description || '',
      discount_type: promo.discount_type,
      discount_value: promo.discount_value.toString(),
      min_order_amount: promo.min_order_amount?.toString() || '',
      max_discount_amount: promo.max_discount_amount?.toString() || '',
      usage_limit: promo.usage_limit?.toString() || '',
      start_date: promo.start_date ? promo.start_date.split('T')[0] : '',
      end_date: promo.end_date ? promo.end_date.split('T')[0] : ''
    });
    setShowEditModal(true);
  };

  const openStatsModal = async (promo: PromoCode) => {
    setSelectedPromo(promo);
    const stats = await getPromoCodeStats(promo.id);
    setPromoStats(stats);
    setShowStatsModal(true);
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success('Code copié !');
  };

  const getStatusBadge = (promo: PromoCode) => {
    if (!promo.is_active) {
      return <Badge variant="secondary">Inactif</Badge>;
    }
    if (promo.end_date && new Date(promo.end_date) < new Date()) {
      return <Badge variant="destructive">Expiré</Badge>;
    }
    if (promo.usage_limit && promo.usage_count >= promo.usage_limit) {
      return <Badge variant="outline">Épuisé</Badge>;
    }
    return <Badge className="bg-green-500">Actif</Badge>;
  };

  const formatDiscount = (promo: PromoCode) => {
    if (promo.discount_type === 'percentage') {
      return `${promo.discount_value}%`;
    }
    return `${promo.discount_value.toLocaleString()} FCFA`;
  };

  // Statistiques globales
  const activePromos = promoCodes.filter(p => p.is_active && (!p.end_date || new Date(p.end_date) > new Date()));
  const totalUsage = promoCodes.reduce((sum, p) => sum + p.usage_count, 0);

  return (
    <div className="space-y-6">
      {/* En-tête avec statistiques */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Tag className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{promoCodes.length}</p>
                <p className="text-sm text-gray-500">Total codes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activePromos.length}</p>
                <p className="text-sm text-gray-500">Codes actifs</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalUsage}</p>
                <p className="text-sm text-gray-500">Utilisations</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
              <DialogTrigger asChild>
                <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Nouveau code
                </Button>
              </DialogTrigger>
            </Dialog>
          </CardContent>
        </Card>
      </div>

      {/* Liste des codes promo */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Percent className="h-5 w-5" />
            Mes codes promo
          </CardTitle>
          <CardDescription>
            Gérez vos codes promotionnels et suivez leur utilisation
          </CardDescription>
        </CardHeader>
        <CardContent>
          {promoCodes.length === 0 ? (
            <div className="text-center py-12">
              <Tag className="h-12 w-12 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun code promo</h3>
              <p className="text-gray-500 mb-4">Créez votre premier code promo pour attirer plus de clients</p>
              <Button onClick={() => setShowCreateModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Créer un code promo
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Réduction</TableHead>
                    <TableHead>Conditions</TableHead>
                    <TableHead>Utilisation</TableHead>
                    <TableHead>Validité</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {promoCodes.map((promo) => (
                    <TableRow key={promo.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <code className="bg-gray-100 px-2 py-1 rounded font-mono text-sm">
                            {promo.code}
                          </code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyCode(promo.code)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                        {promo.description && (
                          <p className="text-xs text-gray-500 mt-1">{promo.description}</p>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="font-semibold text-purple-600">
                          {formatDiscount(promo)}
                        </span>
                        {promo.max_discount_amount && promo.discount_type === 'percentage' && (
                          <p className="text-xs text-gray-500">
                            Max: {promo.max_discount_amount.toLocaleString()} FCFA
                          </p>
                        )}
                      </TableCell>
                      <TableCell>
                        {promo.min_order_amount > 0 ? (
                          <span className="text-sm">
                            Min: {promo.min_order_amount.toLocaleString()} FCFA
                          </span>
                        ) : (
                          <span className="text-sm text-gray-400">Aucune</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <span className="font-medium">{promo.usage_count}</span>
                          {promo.usage_limit && (
                            <span className="text-gray-400">/ {promo.usage_limit}</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {promo.end_date ? (
                          <div className="text-sm">
                            <p>Jusqu'au</p>
                            <p className="font-medium">
                              {new Date(promo.end_date).toLocaleDateString('fr-FR')}
                            </p>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-400">Illimitée</span>
                        )}
                      </TableCell>
                      <TableCell>{getStatusBadge(promo)}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Switch
                            checked={promo.is_active}
                            onCheckedChange={() => handleToggleStatus(promo)}
                          />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openStatsModal(promo)}
                          >
                            <BarChart3 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditModal(promo)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(promo.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de création */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Créer un code promo</DialogTitle>
            <DialogDescription>
              Créez un nouveau code promotionnel pour vos clients
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="code">Code promo *</Label>
              <Input
                id="code"
                placeholder="ex: SOLDES20"
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                className="uppercase"
              />
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="ex: Soldes d'été - 20% de réduction"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Type de réduction *</Label>
                <Select
                  value={formData.discount_type}
                  onValueChange={(value: 'percentage' | 'fixed') => 
                    setFormData({ ...formData, discount_type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Pourcentage (%)</SelectItem>
                    <SelectItem value="fixed">Montant fixe (FCFA)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="discount_value">Valeur *</Label>
                <Input
                  id="discount_value"
                  type="number"
                  placeholder={formData.discount_type === 'percentage' ? 'ex: 20' : 'ex: 5000'}
                  value={formData.discount_value}
                  onChange={(e) => setFormData({ ...formData, discount_value: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="min_order_amount">Commande min. (FCFA)</Label>
                <Input
                  id="min_order_amount"
                  type="number"
                  placeholder="ex: 10000"
                  value={formData.min_order_amount}
                  onChange={(e) => setFormData({ ...formData, min_order_amount: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="max_discount_amount">Réduction max. (FCFA)</Label>
                <Input
                  id="max_discount_amount"
                  type="number"
                  placeholder="ex: 5000"
                  value={formData.max_discount_amount}
                  onChange={(e) => setFormData({ ...formData, max_discount_amount: e.target.value })}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="usage_limit">Limite d'utilisation</Label>
              <Input
                id="usage_limit"
                type="number"
                placeholder="Laisser vide pour illimité"
                value={formData.usage_limit}
                onChange={(e) => setFormData({ ...formData, usage_limit: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start_date">Date de début</Label>
                <Input
                  id="start_date"
                  type="date"
                  value={formData.start_date}
                  onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="end_date">Date de fin</Label>
                <Input
                  id="end_date"
                  type="date"
                  value={formData.end_date}
                  onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowCreateModal(false); resetForm(); }}>
              Annuler
            </Button>
            <Button onClick={handleCreate} disabled={loading}>
              {loading ? 'Création...' : 'Créer le code'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal d'édition */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Modifier le code promo</DialogTitle>
            <DialogDescription>
              Modifiez les paramètres de votre code promotionnel
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-code">Code promo *</Label>
              <Input
                id="edit-code"
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                className="uppercase"
              />
            </div>

            <div>
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Type de réduction *</Label>
                <Select
                  value={formData.discount_type}
                  onValueChange={(value: 'percentage' | 'fixed') => 
                    setFormData({ ...formData, discount_type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Pourcentage (%)</SelectItem>
                    <SelectItem value="fixed">Montant fixe (FCFA)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit-discount_value">Valeur *</Label>
                <Input
                  id="edit-discount_value"
                  type="number"
                  value={formData.discount_value}
                  onChange={(e) => setFormData({ ...formData, discount_value: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-min_order_amount">Commande min. (FCFA)</Label>
                <Input
                  id="edit-min_order_amount"
                  type="number"
                  value={formData.min_order_amount}
                  onChange={(e) => setFormData({ ...formData, min_order_amount: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="edit-max_discount_amount">Réduction max. (FCFA)</Label>
                <Input
                  id="edit-max_discount_amount"
                  type="number"
                  value={formData.max_discount_amount}
                  onChange={(e) => setFormData({ ...formData, max_discount_amount: e.target.value })}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="edit-usage_limit">Limite d'utilisation</Label>
              <Input
                id="edit-usage_limit"
                type="number"
                placeholder="Laisser vide pour illimité"
                value={formData.usage_limit}
                onChange={(e) => setFormData({ ...formData, usage_limit: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-start_date">Date de début</Label>
                <Input
                  id="edit-start_date"
                  type="date"
                  value={formData.start_date}
                  onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="edit-end_date">Date de fin</Label>
                <Input
                  id="edit-end_date"
                  type="date"
                  value={formData.end_date}
                  onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowEditModal(false); setSelectedPromo(null); resetForm(); }}>
              Annuler
            </Button>
            <Button onClick={handleEdit} disabled={loading}>
              {loading ? 'Mise à jour...' : 'Enregistrer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de statistiques */}
      <Dialog open={showStatsModal} onOpenChange={setShowStatsModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Statistiques - {selectedPromo?.code}
            </DialogTitle>
          </DialogHeader>
          {promoStats ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardContent className="pt-4">
                    <p className="text-3xl font-bold text-purple-600">{promoStats.total_uses}</p>
                    <p className="text-sm text-gray-500">Utilisations totales</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-4">
                    <p className="text-3xl font-bold text-green-600">
                      {promoStats.total_discount.toLocaleString()}
                    </p>
                    <p className="text-sm text-gray-500">FCFA de réductions</p>
                  </CardContent>
                </Card>
              </div>

              {promoStats.usage_history.length > 0 ? (
                <div>
                  <h4 className="font-medium mb-2">Historique d'utilisation</h4>
                  <div className="max-h-48 overflow-y-auto space-y-2">
                    {promoStats.usage_history.map((usage) => (
                      <div key={usage.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <div>
                          <p className="text-sm font-medium">{usage.user_email}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(usage.used_at).toLocaleString('fr-FR')}
                          </p>
                        </div>
                        <span className="text-green-600 font-medium">
                          -{usage.discount_applied.toLocaleString()} FCFA
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="text-center text-gray-500 py-4">
                  Aucune utilisation pour le moment
                </p>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="animate-spin h-8 w-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto"></div>
              <p className="mt-2 text-gray-500">Chargement des statistiques...</p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowStatsModal(false); setSelectedPromo(null); setPromoStats(null); }}>
              Fermer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
