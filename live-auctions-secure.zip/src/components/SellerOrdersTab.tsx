import React, { useState, useEffect } from 'react';
import {
  ShoppingBag, Search, Filter, ChevronDown, ChevronUp, Package,
  Truck, Home, Clock, CheckCircle, X, MapPin, Phone, User,
  Copy, ExternalLink, MessageSquare, DollarSign, Calendar,
  AlertCircle, RefreshCw
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders, Order, OrderStats } from '@/hooks/useOrders';
import { formatPrice } from '@/data/mockData';
import { toast } from '@/components/ui/use-toast';



const SellerOrdersTab: React.FC = () => {
  const { user } = useAuth();
  const {
    loading,
    getSellerOrders,
    getOrderStats,
    updateOrderStatus,
    addShippingInfo,
    getStatusLabel,
    getStatusColor,
    getPaymentStatusLabel,
    getPaymentStatusColor
  } = useOrders();

  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState<OrderStats | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [showShippingModal, setShowShippingModal] = useState<string | null>(null);
  const [shippingForm, setShippingForm] = useState({
    carrier: '',
    trackingNumber: '',
    trackingUrl: '',
    estimatedDelivery: '',
    shippingNotes: ''
  });

  useEffect(() => {
    if (user) {
      fetchOrders();
      fetchStats();
    }
  }, [user, statusFilter, currentPage]);

  const fetchOrders = async () => {
    if (!user) return;
    const result = await getSellerOrders(user.id, statusFilter, currentPage, 10);
    setOrders(result.orders);
    setTotalPages(result.totalPages);
  };

  const fetchStats = async () => {
    if (!user) return;
    const result = await getOrderStats(user.id);
    setStats(result);
  };

  const handleStatusUpdate = async (orderId: string, newStatus: Order['status'], notes: string = '') => {
    if (!user) return;
    
    const statusNotes: Record<Order['status'], string> = {
      pending: 'Commande en attente',
      confirmed: 'Commande confirmée par le vendeur',
      shipped: 'Commande expédiée',
      delivered: 'Commande livrée',
      cancelled: notes || 'Commande annulée'
    };

    const result = await updateOrderStatus(orderId, newStatus, statusNotes[newStatus], user.id);
    if (result) {
      toast({
        title: "Statut mis à jour",
        description: `La commande est maintenant "${getStatusLabel(newStatus)}"`,
      });
      fetchOrders();
      fetchStats();
    }
  };

  const handleAddShipping = async (orderId: string) => {
    const result = await addShippingInfo(
      orderId,
      shippingForm.carrier,
      shippingForm.trackingNumber,
      shippingForm.trackingUrl,
      shippingForm.estimatedDelivery || undefined,
      shippingForm.shippingNotes
    );
    
    if (result) {
      toast({
        title: "Informations de livraison ajoutées",
        description: "Le client peut maintenant suivre sa commande",
      });
      setShowShippingModal(null);
      setShippingForm({
        carrier: '',
        trackingNumber: '',
        trackingUrl: '',
        estimatedDelivery: '',
        shippingNotes: ''
      });
      fetchOrders();
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copié!",
      description: "Le texte a été copié dans le presse-papier",
    });
  };

  const filteredOrders = orders.filter(order => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      order.order_number.toLowerCase().includes(query) ||
      order.order_items?.some(item => item.product_name.toLowerCase().includes(query))
    );
  });

  const statusOptions = [
    { value: 'all', label: 'Toutes', count: stats?.total || 0 },
    { value: 'pending', label: 'En attente', count: stats?.pending || 0 },
    { value: 'confirmed', label: 'Confirmées', count: stats?.confirmed || 0 },
    { value: 'shipped', label: 'Expédiées', count: stats?.shipped || 0 },
    { value: 'delivered', label: 'Livrées', count: stats?.delivered || 0 },
    { value: 'cancelled', label: 'Annulées', count: stats?.cancelled || 0 }
  ];

  const carriers = [
    'Chronopost CI',
    'DHL Express',
    'Fedex',
    'Jumia Express',
    'Livraison personnelle',
    'Autre'
  ];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
            <span className="text-slate-400 text-sm">Total</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats?.total || 0}</p>
        </div>
        <div className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <span className="text-slate-400 text-sm">En attente</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats?.pending || 0}</p>
        </div>
        <div className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Truck className="w-5 h-5 text-white" />
            </div>
            <span className="text-slate-400 text-sm">En transit</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats?.shipped || 0}</p>
        </div>
        <div className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-slate-400 text-sm">Revenus</span>
          </div>
          <p className="text-2xl font-bold text-white">{formatPrice(stats?.totalRevenue || 0)}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher par numéro ou produit..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
            />
          </div>
          
          {/* Status Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
            {statusOptions.map(option => (
              <button
                key={option.value}
                onClick={() => {
                  setStatusFilter(option.value);
                  setCurrentPage(1);
                }}
                className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all flex items-center gap-2 ${
                  statusFilter === option.value
                    ? 'bg-orange-500 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                {option.label}
                <span className={`px-1.5 py-0.5 rounded text-xs ${
                  statusFilter === option.value ? 'bg-white/20' : 'bg-slate-600'
                }`}>
                  {option.count}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {loading ? (
          <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
            <div className="w-12 h-12 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-slate-400">Chargement des commandes...</p>
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
            <ShoppingBag className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <h3 className="text-white text-xl font-semibold mb-2">Aucune commande</h3>
            <p className="text-slate-400">
              {statusFilter !== 'all' 
                ? `Aucune commande avec le statut "${statusOptions.find(o => o.value === statusFilter)?.label}"`
                : 'Vous n\'avez pas encore reçu de commandes'}
            </p>
          </div>
        ) : (
          filteredOrders.map(order => (
            <div key={order.id} className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
              {/* Order Header */}
              <div 
                className="p-4 cursor-pointer hover:bg-slate-700/30 transition-colors"
                onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-slate-700 flex items-center justify-center">
                      <Package className="w-6 h-6 text-slate-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-white font-semibold">{order.order_number}</h4>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                          {getStatusLabel(order.status)}
                        </span>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getPaymentStatusColor(order.payment_status)}`}>
                          {getPaymentStatusLabel(order.payment_status)}
                        </span>
                      </div>
                      <p className="text-slate-400 text-sm">
                        {order.order_items?.length || 0} article(s) • {new Date(order.created_at).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-orange-500 font-bold">{formatPrice(order.total)}</p>
                      <p className="text-slate-500 text-xs">Frais livraison: {formatPrice(order.shipping_fee)}</p>
                    </div>
                    {expandedOrder === order.id ? (
                      <ChevronUp className="w-5 h-5 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-400" />
                    )}
                  </div>
                </div>
              </div>

              {/* Expanded Content */}
              {expandedOrder === order.id && (
                <div className="border-t border-slate-700 p-4 space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">

                    {/* Order Items */}
                    <div>
                      <h5 className="text-white font-medium mb-3">Articles commandés</h5>
                      <div className="space-y-3">
                        {order.order_items?.map(item => (
                          <div key={item.id} className="flex items-center gap-3 p-3 bg-slate-900/50 rounded-xl">
                            {item.product_image ? (
                              <img 
                                src={item.product_image} 
                                alt={item.product_name}
                                className="w-14 h-14 rounded-lg object-cover"
                              />
                            ) : (
                              <div className="w-14 h-14 rounded-lg bg-slate-700 flex items-center justify-center">
                                <Package className="w-6 h-6 text-slate-500" />
                              </div>
                            )}
                            <div className="flex-1">
                              <p className="text-white font-medium text-sm">{item.product_name}</p>
                              <p className="text-slate-400 text-xs">
                                {formatPrice(item.unit_price)} x {item.quantity}
                              </p>
                            </div>
                            <p className="text-orange-500 font-semibold">{formatPrice(item.total_price)}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Delivery Address - Simplified */}
                    <div>
                      <h5 className="text-white font-medium mb-3">Adresse de livraison</h5>
                      {order.delivery_addresses ? (
                        <div className="p-4 bg-slate-900/50 rounded-xl space-y-3">
                          <div className="flex items-center gap-2 text-white">
                            <User className="w-4 h-4 text-slate-400" />
                            <span className="font-medium">{order.delivery_addresses.name}</span>
                          </div>
                          <div className="flex items-center gap-2 text-slate-300">
                            <Phone className="w-4 h-4 text-slate-400" />
                            <span>{order.delivery_addresses.phone}</span>
                            <button 
                              onClick={() => copyToClipboard(order.delivery_addresses!.phone)}
                              className="p-1 hover:bg-slate-700 rounded"
                            >
                              <Copy className="w-3 h-3 text-slate-500" />
                            </button>
                          </div>
                          <div className="flex items-start gap-2 text-slate-300">
                            <MapPin className="w-4 h-4 text-slate-400 mt-0.5" />
                            <p className="flex-1">{order.delivery_addresses.location}</p>
                          </div>
                        </div>
                      ) : (
                        <div className="p-4 bg-slate-900/50 rounded-xl text-center">
                          <AlertCircle className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                          <p className="text-slate-400 text-sm">Adresse non renseignée</p>
                        </div>
                      )}

                      {/* Shipping Info */}
                      {order.shipping_info && order.shipping_info[0] && (
                        <div className="mt-4 p-4 bg-slate-900/50 rounded-xl">
                          <h6 className="text-white font-medium mb-2 flex items-center gap-2">
                            <Truck className="w-4 h-4 text-purple-400" />
                            Informations de livraison
                          </h6>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-slate-400">Transporteur</span>
                              <span className="text-white">{order.shipping_info[0].carrier || '-'}</span>
                            </div>
                            {order.shipping_info[0].tracking_number && (
                              <div className="flex justify-between items-center">
                                <span className="text-slate-400">N° de suivi</span>
                                <div className="flex items-center gap-2">
                                  <span className="text-white font-mono">{order.shipping_info[0].tracking_number}</span>
                                  <button 
                                    onClick={() => copyToClipboard(order.shipping_info![0].tracking_number!)}
                                    className="p-1 hover:bg-slate-700 rounded"
                                  >
                                    <Copy className="w-3 h-3 text-slate-500" />
                                  </button>
                                </div>
                              </div>
                            )}
                            {order.shipping_info[0].tracking_url && (
                              <a 
                                href={order.shipping_info[0].tracking_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 text-orange-500 hover:underline"
                              >
                                <ExternalLink className="w-3 h-3" />
                                Suivre le colis
                              </a>
                            )}
                            {order.shipping_info[0].estimated_delivery && (
                              <div className="flex justify-between">
                                <span className="text-slate-400">Livraison estimée</span>
                                <span className="text-white">
                                  {new Date(order.shipping_info[0].estimated_delivery).toLocaleDateString('fr-FR')}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-3 pt-4 border-t border-slate-700">
                    {order.status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleStatusUpdate(order.id, 'confirmed')}
                          disabled={loading}
                          className="px-4 py-2 bg-blue-500 text-white font-semibold rounded-xl hover:bg-blue-600 transition-all flex items-center gap-2 disabled:opacity-50"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Confirmer
                        </button>
                        <button
                          onClick={() => {
                            const reason = prompt('Raison de l\'annulation:');
                            if (reason) handleStatusUpdate(order.id, 'cancelled', reason);
                          }}
                          disabled={loading}
                          className="px-4 py-2 bg-red-500/20 text-red-400 font-semibold rounded-xl hover:bg-red-500/30 transition-all flex items-center gap-2 disabled:opacity-50"
                        >
                          <X className="w-4 h-4" />
                          Annuler
                        </button>
                      </>
                    )}
                    {order.status === 'confirmed' && (
                      <>
                        <button
                          onClick={() => setShowShippingModal(order.id)}
                          disabled={loading}
                          className="px-4 py-2 bg-purple-500 text-white font-semibold rounded-xl hover:bg-purple-600 transition-all flex items-center gap-2 disabled:opacity-50"
                        >
                          <Truck className="w-4 h-4" />
                          Marquer comme expédié
                        </button>
                      </>
                    )}
                    {order.status === 'shipped' && (
                      <>
                        <button
                          onClick={() => handleStatusUpdate(order.id, 'delivered')}
                          disabled={loading}
                          className="px-4 py-2 bg-green-500 text-white font-semibold rounded-xl hover:bg-green-600 transition-all flex items-center gap-2 disabled:opacity-50"
                        >
                          <Home className="w-4 h-4" />
                          Marquer comme livré
                        </button>
                        <button
                          onClick={() => setShowShippingModal(order.id)}
                          disabled={loading}
                          className="px-4 py-2 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all flex items-center gap-2 disabled:opacity-50"
                        >
                          <RefreshCw className="w-4 h-4" />
                          Modifier suivi
                        </button>
                      </>
                    )}
                    <button className="px-4 py-2 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all flex items-center gap-2">
                      <MessageSquare className="w-4 h-4" />
                      Contacter client
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-2">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="px-4 py-2 bg-slate-700 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-600 transition-colors"
          >
            Précédent
          </button>
          <div className="flex items-center gap-1">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-10 h-10 rounded-xl font-medium transition-colors ${
                  currentPage === page
                    ? 'bg-orange-500 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                {page}
              </button>
            ))}
          </div>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="px-4 py-2 bg-slate-700 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-600 transition-colors"
          >
            Suivant
          </button>
        </div>
      )}

      {/* Shipping Modal */}
      {showShippingModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <h3 className="text-white text-xl font-bold">Informations de livraison</h3>
                <button onClick={() => setShowShippingModal(null)} className="text-slate-400 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-white font-medium mb-2">Transporteur</label>
                <select
                  value={shippingForm.carrier}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, carrier: e.target.value }))}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="">Sélectionner un transporteur</option>
                  {carriers.map(carrier => (
                    <option key={carrier} value={carrier}>{carrier}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">Numéro de suivi</label>
                <input
                  type="text"
                  value={shippingForm.trackingNumber}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, trackingNumber: e.target.value }))}
                  placeholder="Ex: CI1234567890"
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">URL de suivi (optionnel)</label>
                <input
                  type="url"
                  value={shippingForm.trackingUrl}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, trackingUrl: e.target.value }))}
                  placeholder="https://..."
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">Date de livraison estimée</label>
                <input
                  type="date"
                  value={shippingForm.estimatedDelivery}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, estimatedDelivery: e.target.value }))}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">Notes (optionnel)</label>
                <textarea
                  value={shippingForm.shippingNotes}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, shippingNotes: e.target.value }))}
                  placeholder="Instructions spéciales..."
                  rows={2}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 resize-none"
                />
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowShippingModal(null)}
                className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
              >
                Annuler
              </button>
              <button
                onClick={() => {
                  handleAddShipping(showShippingModal);
                  handleStatusUpdate(showShippingModal, 'shipped');
                }}
                disabled={loading || !shippingForm.carrier}
                className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Truck className="w-5 h-5" />
                    Confirmer l'expédition
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SellerOrdersTab;
