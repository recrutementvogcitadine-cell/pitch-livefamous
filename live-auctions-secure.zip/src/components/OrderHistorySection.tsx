import React, { useState, useEffect } from 'react';
import { 
  Package, Clock, CheckCircle, Truck, Check, X, 
  ChevronDown, ChevronUp, Store, MapPin, Phone,
  CreditCard, Calendar, RefreshCw, AlertCircle, Copy,
  MessageCircle
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders, Order } from '@/hooks/useOrders';
import { formatPrice } from '@/data/mockData';
import { toast } from '@/components/ui/use-toast';

interface OrderHistorySectionProps {
  onViewOrderDetails?: (order: Order) => void;
}

const OrderHistorySection: React.FC<OrderHistorySectionProps> = ({ onViewOrderDetails }) => {
  const { user } = useAuth();
  const { 
    loading, 
    getBuyerOrders, 
    getStatusLabel, 
    getStatusColor,
    getPaymentStatusLabel,
    getPaymentStatusColor
  } = useOrders();

  const [orders, setOrders] = useState<Order[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [stats, setStats] = useState({
    pending: 0,
    confirmed: 0,
    shipped: 0,
    delivered: 0,
    cancelled: 0
  });

  useEffect(() => {
    if (user) {
      fetchOrders();
    }
  }, [user, statusFilter, currentPage]);

  const fetchOrders = async () => {
    if (!user) return;
    
    const filterStatus = statusFilter === 'all' ? undefined : statusFilter;
    const result = await getBuyerOrders(user.id, filterStatus, currentPage, 10);
    setOrders(result.orders);
    setTotalPages(result.totalPages);

    // Calculate stats from all orders
    if (statusFilter === 'all') {
      const newStats = {
        pending: result.orders.filter(o => o.status === 'pending').length,
        confirmed: result.orders.filter(o => o.status === 'confirmed').length,
        shipped: result.orders.filter(o => o.status === 'shipped').length,
        delivered: result.orders.filter(o => o.status === 'delivered').length,
        cancelled: result.orders.filter(o => o.status === 'cancelled').length
      };
      setStats(newStats);
    }
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'confirmed': return <CheckCircle className="w-4 h-4" />;
      case 'shipped': return <Truck className="w-4 h-4" />;
      case 'delivered': return <Check className="w-4 h-4" />;
      case 'cancelled': return <X className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  const getStatusBgColor = (status: Order['status']) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'confirmed': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'shipped': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'delivered': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'cancelled': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  const copyOrderNumber = (orderNumber: string) => {
    navigator.clipboard.writeText(orderNumber);
    toast({
      title: "Copié!",
      description: "Numéro de commande copié dans le presse-papier"
    });
  };

  const contactSeller = (order: Order) => {
    const message = `Bonjour, je souhaite avoir des informations sur ma commande ${order.order_number}`;
    const encodedMessage = encodeURIComponent(message);
    // In production, use actual seller phone
    window.open(`https://wa.me/+2250700000000?text=${encodedMessage}`, '_blank');
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div 
          onClick={() => setStatusFilter('pending')}
          className={`bg-slate-900 rounded-xl border p-4 text-center cursor-pointer transition-all ${
            statusFilter === 'pending' ? 'border-yellow-500' : 'border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-yellow-500/20 flex items-center justify-center">
            <Clock className="w-5 h-5 text-yellow-500" />
          </div>
          <p className="text-2xl font-bold text-white">{stats.pending}</p>
          <p className="text-slate-400 text-sm">En attente</p>
        </div>
        
        <div 
          onClick={() => setStatusFilter('confirmed')}
          className={`bg-slate-900 rounded-xl border p-4 text-center cursor-pointer transition-all ${
            statusFilter === 'confirmed' ? 'border-blue-500' : 'border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-blue-500/20 flex items-center justify-center">
            <CheckCircle className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-2xl font-bold text-white">{stats.confirmed}</p>
          <p className="text-slate-400 text-sm">Confirmées</p>
        </div>
        
        <div 
          onClick={() => setStatusFilter('shipped')}
          className={`bg-slate-900 rounded-xl border p-4 text-center cursor-pointer transition-all ${
            statusFilter === 'shipped' ? 'border-purple-500' : 'border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-purple-500/20 flex items-center justify-center">
            <Truck className="w-5 h-5 text-purple-500" />
          </div>
          <p className="text-2xl font-bold text-white">{stats.shipped}</p>
          <p className="text-slate-400 text-sm">En livraison</p>
        </div>
        
        <div 
          onClick={() => setStatusFilter('delivered')}
          className={`bg-slate-900 rounded-xl border p-4 text-center cursor-pointer transition-all ${
            statusFilter === 'delivered' ? 'border-green-500' : 'border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-green-500/20 flex items-center justify-center">
            <Check className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-2xl font-bold text-white">{stats.delivered}</p>
          <p className="text-slate-400 text-sm">Livrées</p>
        </div>
        
        <div 
          onClick={() => setStatusFilter('cancelled')}
          className={`bg-slate-900 rounded-xl border p-4 text-center cursor-pointer transition-all ${
            statusFilter === 'cancelled' ? 'border-red-500' : 'border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-red-500/20 flex items-center justify-center">
            <X className="w-5 h-5 text-red-500" />
          </div>
          <p className="text-2xl font-bold text-white">{stats.cancelled}</p>
          <p className="text-slate-400 text-sm">Annulées</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              statusFilter === 'all'
                ? 'bg-orange-500 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Toutes
          </button>
        </div>
        <button
          onClick={fetchOrders}
          disabled={loading}
          className="p-2 text-slate-400 hover:text-white transition-colors"
        >
          <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Orders List */}
      {loading && orders.length === 0 ? (
        <div className="text-center py-12">
          <RefreshCw className="w-8 h-8 text-orange-500 mx-auto mb-4 animate-spin" />
          <p className="text-slate-400">Chargement des commandes...</p>
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-12 bg-slate-900 rounded-2xl border border-slate-800">
          <Package className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">Aucune commande</h3>
          <p className="text-slate-400">
            {statusFilter === 'all' 
              ? "Vous n'avez pas encore passé de commande"
              : `Aucune commande avec le statut "${getStatusLabel(statusFilter as Order['status'])}"`
            }
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div 
              key={order.id} 
              className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden"
            >
              {/* Order Header */}
              <div 
                className="p-4 flex flex-wrap items-center justify-between gap-3 cursor-pointer hover:bg-slate-800/50 transition-colors"
                onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
              >
                <div className="flex items-center gap-3">
                  <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full border ${getStatusBgColor(order.status)}`}>
                    {getStatusIcon(order.status)}
                    <span className="text-sm font-medium">{getStatusLabel(order.status)}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-white font-semibold">{order.order_number}</p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          copyOrderNumber(order.order_number);
                        }}
                        className="p-1 text-slate-500 hover:text-orange-500 transition-colors"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-slate-400 text-sm flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {formatDate(order.created_at)}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-orange-500 font-bold text-lg">{formatPrice(order.total)}</p>
                    <p className={`text-xs px-2 py-0.5 rounded-full ${getPaymentStatusColor(order.payment_status)}`}>
                      {getPaymentStatusLabel(order.payment_status)}
                    </p>
                  </div>
                  {expandedOrder === order.id ? (
                    <ChevronUp className="w-5 h-5 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Expanded Content */}
              {expandedOrder === order.id && (
                <div className="border-t border-slate-800">
                  {/* Order Items */}
                  <div className="p-4 space-y-3">
                    <h4 className="text-white font-semibold flex items-center gap-2">
                      <Package className="w-4 h-4 text-orange-500" />
                      Articles ({order.order_items?.length || 0})
                    </h4>
                    {order.order_items?.map((item) => (
                      <div key={item.id} className="flex items-center gap-4 p-3 bg-slate-800/50 rounded-xl">
                        {item.product_image && (
                          <img 
                            src={item.product_image}
                            alt={item.product_name}
                            className="w-16 h-16 rounded-lg object-cover"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-white font-medium truncate">{item.product_name}</p>
                          <p className="text-slate-400 text-sm">
                            {formatPrice(item.unit_price)} x {item.quantity}
                          </p>
                        </div>
                        <p className="text-orange-500 font-semibold">{formatPrice(item.total_price)}</p>
                      </div>
                    ))}
                  </div>

                  {/* Delivery Address */}
                  {order.delivery_addresses && (
                    <div className="p-4 border-t border-slate-800">
                      <h4 className="text-white font-semibold flex items-center gap-2 mb-3">
                        <MapPin className="w-4 h-4 text-orange-500" />
                        Adresse de livraison
                      </h4>
                      <div className="p-3 bg-slate-800/50 rounded-xl">
                        <p className="text-white font-medium">{order.delivery_addresses.name}</p>
                        <p className="text-slate-400 text-sm flex items-center gap-1 mt-1">
                          <Phone className="w-3.5 h-3.5" />
                          {order.delivery_addresses.phone}
                        </p>
                        <p className="text-slate-400 text-sm mt-1">{order.delivery_addresses.location}</p>
                      </div>
                    </div>
                  )}

                  {/* Order Timeline */}
                  {order.order_status_history && order.order_status_history.length > 0 && (
                    <div className="p-4 border-t border-slate-800">
                      <h4 className="text-white font-semibold flex items-center gap-2 mb-3">
                        <Clock className="w-4 h-4 text-orange-500" />
                        Historique
                      </h4>
                      <div className="space-y-3">
                        {order.order_status_history.map((history, index) => (
                          <div key={history.id} className="flex gap-3">
                            <div className="flex flex-col items-center">
                              <div className={`w-3 h-3 rounded-full ${
                                index === 0 ? 'bg-orange-500' : 'bg-slate-600'
                              }`} />
                              {index < order.order_status_history!.length - 1 && (
                                <div className="w-0.5 h-full bg-slate-700 my-1" />
                              )}
                            </div>
                            <div className="flex-1 pb-3">
                              <p className="text-white font-medium text-sm">
                                {getStatusLabel(history.status as Order['status'])}
                              </p>
                              {history.notes && (
                                <p className="text-slate-400 text-xs mt-0.5">{history.notes}</p>
                              )}
                              <p className="text-slate-500 text-xs mt-1">
                                {formatDate(history.created_at)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Order Summary */}
                  <div className="p-4 bg-slate-800/30 border-t border-slate-800">
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-slate-400 text-sm">
                        <span>Sous-total</span>
                        <span className="text-white">{formatPrice(order.subtotal)}</span>
                      </div>
                      <div className="flex justify-between text-slate-400 text-sm">
                        <span>Frais de livraison</span>
                        <span className="text-white">{formatPrice(order.shipping_fee)}</span>
                      </div>
                      <div className="flex justify-between pt-2 border-t border-slate-700">
                        <span className="text-white font-semibold">Total</span>
                        <span className="text-orange-500 font-bold">{formatPrice(order.total)}</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <button
                        onClick={() => contactSeller(order)}
                        className="flex-1 py-2.5 bg-green-500/20 text-green-400 font-semibold rounded-xl hover:bg-green-500/30 transition-all flex items-center justify-center gap-2"
                      >
                        <MessageCircle className="w-4 h-4" />
                        Contacter le vendeur
                      </button>
                      {order.status === 'pending' && (
                        <button className="px-4 py-2.5 bg-red-500/20 text-red-400 font-semibold rounded-xl hover:bg-red-500/30 transition-all">
                          Annuler
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
            className="px-4 py-2 bg-slate-800 text-slate-400 rounded-lg disabled:opacity-50 hover:text-white transition-colors"
          >
            Précédent
          </button>
          <span className="text-slate-400">
            Page {currentPage} sur {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
            className="px-4 py-2 bg-slate-800 text-slate-400 rounded-lg disabled:opacity-50 hover:text-white transition-colors"
          >
            Suivant
          </button>
        </div>
      )}
    </div>
  );
};

export default OrderHistorySection;
