import React, { useState, useEffect } from 'react';
import { ChevronRight, Play, Search, Users, TrendingUp, RotateCcw, Eye, Clock } from 'lucide-react';
import { liveStreams, LiveStream, formatPrice } from '@/data/mockData';
import LiveStreamCard from './LiveStreamCard';
import LiveStreamModal from './LiveStreamModal';
import ReplayModal from './ReplayModal';
import FollowButton from './FollowButton';
import AuthModal from './AuthModal';
import { useLiveStream, LiveStreamData } from '@/hooks/useLiveStream';

interface LiveStreamsSectionProps {
  searchQuery?: string;
  onJoinStream?: (stream: LiveStream) => void;
}

const LiveStreamsSection: React.FC<LiveStreamsSectionProps> = ({ 
  searchQuery: externalSearchQuery, 
  onJoinStream: externalOnJoinStream
}) => {
  const [selectedStream, setSelectedStream] = useState<LiveStream | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showReplayModal, setShowReplayModal] = useState(false);
  const [selectedReplayId, setSelectedReplayId] = useState<string | null>(null);
  const [filter, setFilter] = useState('all');
  const [internalSearchQuery, setInternalSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'live' | 'replay'>('live');
  const [replays, setReplays] = useState<LiveStreamData[]>([]);
  const [showAuthModal, setShowAuthModal] = useState(false);


  const { fetchPublicReplays, loading } = useLiveStream();

  const searchQuery = externalSearchQuery ?? internalSearchQuery;
  const setSearchQuery = externalSearchQuery !== undefined ? () => {} : setInternalSearchQuery;

  const categories = ['all', 'Électronique', 'Mode', 'Beauté', 'Maison', 'Bijoux', 'Chaussures', 'Auto'];

  useEffect(() => {
    loadReplays();
  }, []);

  const loadReplays = async () => {
    const data = await fetchPublicReplays({ limit: 20 });
    setReplays(data);
  };

  const filteredStreams = liveStreams.filter(stream => {
    const matchesCategory = filter === 'all' || stream.category === filter;
    const matchesSearch = stream.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         stream.seller.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const filteredReplays = replays.filter(replay => {
    const matchesCategory = filter === 'all' || replay.category === filter;
    const matchesSearch = replay.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (replay.profiles?.full_name || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleJoinStream = (stream: LiveStream) => {
    if (externalOnJoinStream) {
      externalOnJoinStream(stream);
    } else {
      setSelectedStream(stream);
      setShowModal(true);
    }
  };

  const handleWatchReplay = (replayId: string) => {
    setSelectedReplayId(replayId);
    setShowReplayModal(true);
  };

  const formatDuration = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    
    if (hrs > 0) {
      return `${hrs}h ${mins}min`;
    }
    return `${mins} min`;
  };

  const totalViewers = liveStreams.reduce((sum, s) => sum + s.viewers, 0);

  return (
    <section id="lives" className="py-12 bg-gradient-to-b from-slate-900 to-slate-800">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-red-500 rounded-full">
                <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                <span className="text-white text-sm font-bold">LIVE</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white">Lives & Rediffusions</h2>
            </div>
            <div className="flex items-center gap-4 text-slate-400">
              <div className="flex items-center gap-1.5">
                <Play className="w-4 h-4 text-red-500" />
                <span>{liveStreams.length} lives actifs</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-orange-500" />
                <span>{totalViewers.toLocaleString()} spectateurs</span>
              </div>
              <div className="flex items-center gap-1.5">
                <RotateCcw className="w-4 h-4 text-purple-500" />
                <span>{replays.length} rediffusions</span>
              </div>
            </div>
          </div>

          <button className="flex items-center gap-2 px-4 py-2 bg-orange-500/10 border border-orange-500/30 text-orange-500 rounded-xl hover:bg-orange-500/20 transition-all">
            <TrendingUp className="w-4 h-4" />
            Voir tout
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab('live')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
              activeTab === 'live'
                ? 'bg-gradient-to-r from-red-500 to-orange-500 text-white shadow-lg shadow-red-500/30'
                : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
            }`}
          >
            <Play className="w-5 h-5" />
            Lives en direct
            <span className={`px-2 py-0.5 rounded-full text-xs ${
              activeTab === 'live' ? 'bg-white/20' : 'bg-slate-700'
            }`}>
              {liveStreams.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('replay')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
              activeTab === 'replay'
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/30'
                : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
            }`}
          >
            <RotateCcw className="w-5 h-5" />
            Rediffusions
            <span className={`px-2 py-0.5 rounded-full text-xs ${
              activeTab === 'replay' ? 'bg-white/20' : 'bg-slate-700'
            }`}>
              {replays.length}
            </span>
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={activeTab === 'live' ? "Rechercher un live..." : "Rechercher une rediffusion..."}
              className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                  filter === cat
                    ? 'bg-orange-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                }`}
              >
                {cat === 'all' ? 'Tous' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Live Streams Grid */}
        {activeTab === 'live' && (
          <>
            {filteredStreams.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredStreams.map((stream) => (
                  <LiveStreamCard
                    key={stream.id}
                    stream={stream}
                    onJoin={handleJoinStream}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Play className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <h3 className="text-white text-xl font-semibold mb-2">Aucun live trouvé</h3>
                <p className="text-slate-400">Essayez de modifier vos filtres ou revenez plus tard</p>
              </div>
            )}
          </>
        )}

        {/* Replays Grid */}
        {activeTab === 'replay' && (
          <>
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="bg-slate-800 rounded-2xl overflow-hidden animate-pulse">
                    <div className="aspect-video bg-slate-700"></div>
                    <div className="p-4 space-y-3">
                      <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                      <div className="h-3 bg-slate-700 rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredReplays.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredReplays.map((replay) => (
                  <div 
                    key={replay.id}
                    className="group bg-slate-800 rounded-2xl overflow-hidden border border-slate-700 hover:border-purple-500/50 transition-all cursor-pointer"
                    onClick={() => handleWatchReplay(replay.id)}
                  >
                    {/* Thumbnail */}
                    <div className="relative aspect-video overflow-hidden">
                      <img 
                        src={replay.replay_thumbnail || replay.thumbnail_url || 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400'}
                        alt={replay.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                      
                      {/* Replay Badge */}
                      <div className="absolute top-3 left-3 flex items-center gap-2 px-2.5 py-1 bg-purple-500 rounded-full">
                        <RotateCcw className="w-3 h-3 text-white" />
                        <span className="text-white text-xs font-bold">REPLAY</span>
                      </div>

                      {/* Duration */}
                      {replay.duration_seconds && (
                        <div className="absolute bottom-3 right-3 flex items-center gap-1.5 px-2 py-1 bg-black/70 backdrop-blur rounded-full">
                          <Clock className="w-3 h-3 text-white" />
                          <span className="text-white text-xs">{formatDuration(replay.duration_seconds)}</span>
                        </div>
                      )}

                      {/* Views */}
                      <div className="absolute bottom-3 left-3 flex items-center gap-1.5 px-2 py-1 bg-black/70 backdrop-blur rounded-full">
                        <Eye className="w-3 h-3 text-white" />
                        <span className="text-white text-xs">{(replay.replay_views || 0).toLocaleString()} vues</span>
                      </div>

                      {/* Play Overlay */}
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-16 h-16 bg-purple-500/80 rounded-full flex items-center justify-center transform group-hover:scale-110 transition-transform">
                          <Play className="w-8 h-8 text-white ml-1" />
                        </div>
                      </div>
                    </div>

                    {/* Info */}
                    <div className="p-4">
                      <h3 className="text-white font-semibold line-clamp-2 mb-2 group-hover:text-purple-400 transition-colors">
                        {replay.title}
                      </h3>
                      
                      <div className="flex items-center gap-2 mb-3">
                        <img 
                          src={replay.profiles?.avatar_url || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50'}
                          alt={replay.profiles?.full_name || 'Vendeur'}
                          className="w-6 h-6 rounded-full"
                        />
                        <span className="text-slate-400 text-sm">{replay.profiles?.full_name || 'Vendeur'}</span>
                        {replay.profiles?.is_verified && (
                          <span className="px-1.5 py-0.5 bg-blue-500/20 text-blue-400 text-xs rounded">Vérifié</span>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-3 text-slate-500">
                          <span className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            {replay.peak_viewers || 0} max
                          </span>
                          {replay.total_sales > 0 && (
                            <span className="text-green-400">{replay.total_sales} ventes</span>
                          )}
                        </div>
                        {replay.category && (
                          <span className="px-2 py-1 bg-slate-700 text-slate-300 text-xs rounded-full">
                            {replay.category}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <RotateCcw className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <h3 className="text-white text-xl font-semibold mb-2">Aucune rediffusion disponible</h3>
                <p className="text-slate-400">Les rediffusions des lives apparaîtront ici</p>
              </div>
            )}
          </>
        )}

        {/* Featured Live Banner */}
        {activeTab === 'live' && filteredStreams.length > 0 && (
          <div className="mt-12 relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-600 via-pink-500 to-orange-500 p-1">
            <div className="bg-slate-900 rounded-[22px] p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="relative w-full md:w-64 aspect-video rounded-xl overflow-hidden">
                  <img 
                    src={filteredStreams[0].thumbnail}
                    alt={filteredStreams[0].title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute top-3 left-3 flex items-center gap-2 px-2.5 py-1 bg-red-500 rounded-full">
                    <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
                    <span className="text-white text-xs font-bold">LIVE</span>
                  </div>
                  <div className="absolute bottom-3 right-3 flex items-center gap-1.5 px-2 py-1 bg-black/50 backdrop-blur rounded-full">
                    <Users className="w-3 h-3 text-white" />
                    <span className="text-white text-xs">{filteredStreams[0].viewers.toLocaleString()}</span>
                  </div>
                </div>

                <div className="flex-1 text-center md:text-left">
                  <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
                    <span className="px-2.5 py-1 bg-orange-500/20 text-orange-400 text-xs font-medium rounded-full">
                      Live Populaire
                    </span>
                    <span className="px-2.5 py-1 bg-purple-500/20 text-purple-400 text-xs font-medium rounded-full">
                      {filteredStreams[0].category}
                    </span>
                  </div>
                  <h3 className="text-white text-xl md:text-2xl font-bold mb-2">{filteredStreams[0].title}</h3>
                  <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
                    <img 
                      src={filteredStreams[0].seller.avatar}
                      alt={filteredStreams[0].seller.name}
                      className="w-8 h-8 rounded-full border border-slate-600"
                    />
                    <span className="text-slate-300">{filteredStreams[0].seller.name}</span>
                  </div>
                  <button
                    onClick={() => handleJoinStream(filteredStreams[0])}
                    className="px-6 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all flex items-center gap-2 mx-auto md:mx-0"
                  >
                    <Play className="w-5 h-5" />
                    Rejoindre le Live
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Featured Replay Banner */}
        {activeTab === 'replay' && filteredReplays.length > 0 && (
          <div className="mt-12 relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-600 via-pink-500 to-indigo-600 p-1">
            <div className="bg-slate-900 rounded-[22px] p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="relative w-full md:w-64 aspect-video rounded-xl overflow-hidden">
                  <img 
                    src={filteredReplays[0].replay_thumbnail || filteredReplays[0].thumbnail_url || 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400'}
                    alt={filteredReplays[0].title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute top-3 left-3 flex items-center gap-2 px-2.5 py-1 bg-purple-500 rounded-full">
                    <RotateCcw className="w-3 h-3 text-white" />
                    <span className="text-white text-xs font-bold">REPLAY</span>
                  </div>
                  <div className="absolute bottom-3 right-3 flex items-center gap-1.5 px-2 py-1 bg-black/50 backdrop-blur rounded-full">
                    <Eye className="w-3 h-3 text-white" />
                    <span className="text-white text-xs">{(filteredReplays[0].replay_views || 0).toLocaleString()} vues</span>
                  </div>
                </div>

                <div className="flex-1 text-center md:text-left">
                  <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
                    <span className="px-2.5 py-1 bg-purple-500/20 text-purple-400 text-xs font-medium rounded-full">
                      Rediffusion Populaire
                    </span>
                    {filteredReplays[0].category && (
                      <span className="px-2.5 py-1 bg-pink-500/20 text-pink-400 text-xs font-medium rounded-full">
                        {filteredReplays[0].category}
                      </span>
                    )}
                  </div>
                  <h3 className="text-white text-xl md:text-2xl font-bold mb-2">{filteredReplays[0].title}</h3>
                  <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
                    <img 
                      src={filteredReplays[0].profiles?.avatar_url || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50'}
                      alt={filteredReplays[0].profiles?.full_name || 'Vendeur'}
                      className="w-8 h-8 rounded-full border border-slate-600"
                    />
                    <span className="text-slate-300">{filteredReplays[0].profiles?.full_name || 'Vendeur'}</span>
                    <span className="text-slate-500">•</span>
                    <span className="text-slate-400 text-sm flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {filteredReplays[0].peak_viewers || 0} spectateurs max
                    </span>
                  </div>
                  <button
                    onClick={() => handleWatchReplay(filteredReplays[0].id)}
                    className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-purple-500/30 transition-all flex items-center gap-2 mx-auto md:mx-0"
                  >
                    <Play className="w-5 h-5" />
                    Regarder la Rediffusion
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Live Stream Modal - only show if using internal state */}
      {!externalOnJoinStream && (
        <LiveStreamModal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          stream={selectedStream}
        />
      )}

      {/* Replay Modal */}
      <ReplayModal
        isOpen={showReplayModal}
        onClose={() => {
          setShowReplayModal(false);
          setSelectedReplayId(null);
        }}
        replayId={selectedReplayId}
      />
    </section>
  );
};

export default LiveStreamsSection;
