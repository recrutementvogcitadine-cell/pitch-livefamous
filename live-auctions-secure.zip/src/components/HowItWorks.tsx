import React from 'react';
import { Play, Search, MessageCircle, Handshake } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: Play,
      title: 'Regardez les Lives',
      description: 'Rejoignez les diffusions en direct de nos vendeurs vérifiés et découvrez leurs produits en temps réel.',
      color: 'from-red-500 to-red-600'
    },
    {
      icon: Search,
      title: 'Trouvez vos Produits',
      description: 'Parcourez notre catalogue de produits authentiques présentés par des vendeurs de confiance.',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: MessageCircle,
      title: 'Contactez le Vendeur',
      description: 'Contactez directement le vendeur via WhatsApp ou téléphone pour discuter et négocier.',
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Handshake,
      title: 'Finalisez l\'Achat',
      description: 'Convenez des modalités de paiement et de livraison directement avec le vendeur.',
      color: 'from-red-500 to-red-600'
    }
  ];

  return (
    <section className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-red-500/10 text-red-500 rounded-full text-sm font-semibold mb-4">
            Comment ça marche
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Achetez en{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">
              4 étapes simples
            </span>
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            PITCH connecte acheteurs et vendeurs. Les transactions se font directement entre vous, 
            en toute confiance et transparence.
          </p>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div 
              key={index}
              className="relative group"
            >
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-1/2 w-full h-0.5 bg-gradient-to-r from-slate-700 to-slate-700/0"></div>
              )}

              <div className="relative bg-slate-800/50 rounded-2xl p-6 border border-slate-700 hover:border-red-500/50 transition-all duration-300 hover:-translate-y-2">
                {/* Step Number */}
                <div className="absolute -top-3 -right-3 w-8 h-8 bg-slate-900 border border-slate-700 rounded-full flex items-center justify-center">
                  <span className="text-red-500 font-bold text-sm">{index + 1}</span>
                </div>

                {/* Icon */}
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}>
                  <step.icon className="w-7 h-7 text-white" />
                </div>

                {/* Content */}
                <h3 className="text-white font-semibold text-lg mb-3">{step.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Info Box */}
        <div className="mt-16 bg-gradient-to-r from-red-500/10 to-red-600/10 rounded-2xl p-8 border border-red-500/20">
          <div className="flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
            <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Handshake className="w-10 h-10 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-white font-bold text-xl mb-2">Transactions directes et sécurisées</h3>
              <p className="text-slate-300">
                Sur PITCH, vous négociez et achetez directement auprès des vendeurs. 
                Nous vérifions l'identité de chaque vendeur pour garantir votre sécurité. 
                Vous gardez le contrôle total de vos transactions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
