import React, { useState, useMemo, useEffect } from 'react';
import {
  TrendingUp, TrendingDown, Calendar, Download, RefreshCw,
  Eye, ShoppingBag, DollarSign, Users, Package, Video,
  ArrowUpRight, ArrowDownRight, BarChart3, PieChart,
  ChevronDown, FileText, FileSpreadsheet, Filter, Target,
  AlertTriangle, Star, MessageSquare, Plus, X, Check,
  Award, Zap, Clock, ChevronRight, Edit2, Trash2
} from 'lucide-react';
import { formatPrice } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { useProducts, SalesGoal, StockAlert, ProductReview } from '@/hooks/useProducts';
import { toast } from '@/components/ui/use-toast';

interface DateRange {
  label: string;
  value: string;
  days: number;
}

interface AnalyticsData {
  revenue: number[];
  orders: number[];
  viewers: number[];
  products: number[];
  labels: string[];
}

const dateRanges: DateRange[] = [
  { label: '7 derniers jours', value: '7d', days: 7 },
  { label: '30 derniers jours', value: '30d', days: 30 },
  { label: '90 derniers jours', value: '90d', days: 90 },
  { label: 'Cette année', value: 'year', days: 365 },
];

// Generate mock analytics data based on date range
const generateAnalyticsData = (days: number): AnalyticsData => {
  const labels: string[] = [];
  const revenue: number[] = [];
  const orders: number[] = [];
  const viewers: number[] = [];
  const products: number[] = [];

  const today = new Date();
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    
    if (days <= 7) {
      labels.push(date.toLocaleDateString('fr-FR', { weekday: 'short' }));
    } else if (days <= 30) {
      labels.push(date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }));
    } else if (days <= 90) {
      if (i % 7 === 0) {
        labels.push(date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }));
      }
    } else {
      if (i % 30 === 0) {
        labels.push(date.toLocaleDateString('fr-FR', { month: 'short' }));
      }
    }
    
    // Generate random but realistic data
    const baseRevenue = 150000 + Math.random() * 100000;
    const baseOrders = 5 + Math.floor(Math.random() * 15);
    const baseViewers = 200 + Math.floor(Math.random() * 500);
    const baseProducts = 2 + Math.floor(Math.random() * 8);
    
    revenue.push(Math.round(baseRevenue));
    orders.push(baseOrders);
    viewers.push(baseViewers);
    products.push(baseProducts);
  }

  return { revenue, orders, viewers, products, labels };
};

// Product performance data
const productPerformance = [
  { id: 1, name: 'iPhone 15 Pro Max', sales: 45, revenue: 38250000, views: 2340, conversion: 1.92, trend: 12, stock: 23 },
  { id: 2, name: 'Samsung Galaxy S24', sales: 38, revenue: 24700000, views: 1890, conversion: 2.01, trend: 8, stock: 15 },
  { id: 3, name: 'MacBook Air M3', sales: 22, revenue: 26400000, views: 1456, conversion: 1.51, trend: -3, stock: 8 },
  { id: 4, name: 'AirPods Pro 2', sales: 67, revenue: 12060000, views: 3210, conversion: 2.09, trend: 15, stock: 5 },
  { id: 5, name: 'Apple Watch Ultra', sales: 28, revenue: 16800000, views: 1678, conversion: 1.67, trend: 5, stock: 12 },
  { id: 6, name: 'iPad Pro 12.9"', sales: 19, revenue: 17100000, views: 1234, conversion: 1.54, trend: -2, stock: 0 },
  { id: 7, name: 'Sony WH-1000XM5', sales: 34, revenue: 8500000, views: 1567, conversion: 2.17, trend: 18, stock: 3 },
  { id: 8, name: 'DJI Mini 3 Pro', sales: 12, revenue: 9600000, views: 890, conversion: 1.35, trend: 7, stock: 7 },
];

// Mock reviews data
const mockReviews: ProductReview[] = [
  { id: '1', product_id: '1', seller_id: '1', buyer_id: '1', buyer_name: 'Aminata K.', rating: 5, title: 'Excellent produit!', comment: 'Livraison rapide et produit conforme. Je recommande vivement ce vendeur.', is_verified_purchase: true, helpful_count: 12, status: 'published', created_at: new Date(Date.now() - 86400000).toISOString(), updated_at: new Date().toISOString() },
  { id: '2', product_id: '2', seller_id: '1', buyer_id: '2', buyer_name: 'Kouadio M.', rating: 4, title: 'Très satisfait', comment: 'Bon rapport qualité-prix. Emballage soigné.', is_verified_purchase: true, helpful_count: 8, status: 'published', created_at: new Date(Date.now() - 172800000).toISOString(), updated_at: new Date().toISOString() },
  { id: '3', product_id: '3', seller_id: '1', buyer_id: '3', buyer_name: 'Fatou S.', rating: 5, title: 'Parfait!', comment: 'Le MacBook est exactement comme décrit. Service client au top!', is_verified_purchase: true, helpful_count: 15, seller_response: 'Merci beaucoup pour votre avis! Nous sommes ravis que vous soyez satisfaite.', seller_response_at: new Date().toISOString(), status: 'published', created_at: new Date(Date.now() - 259200000).toISOString(), updated_at: new Date().toISOString() },
  { id: '4', product_id: '4', seller_id: '1', buyer_id: '4', buyer_name: 'Ibrahim T.', rating: 3, title: 'Correct', comment: 'Produit correct mais livraison un peu longue.', is_verified_purchase: true, helpful_count: 3, status: 'published', created_at: new Date(Date.now() - 345600000).toISOString(), updated_at: new Date().toISOString() },
  { id: '5', product_id: '5', seller_id: '1', buyer_id: '5', buyer_name: 'Marie L.', rating: 5, title: 'Super vendeur', comment: 'Très professionnel, je commanderai à nouveau!', is_verified_purchase: true, helpful_count: 20, status: 'published', created_at: new Date(Date.now() - 432000000).toISOString(), updated_at: new Date().toISOString() },
];

// Mock stock alerts
const mockStockAlerts: StockAlert[] = [
  { id: '1', seller_id: '1', product_id: '6', product_name: 'iPad Pro 12.9"', current_stock: 0, threshold: 10, alert_type: 'out_of_stock', is_read: false, created_at: new Date().toISOString() },
  { id: '2', seller_id: '1', product_id: '7', product_name: 'Sony WH-1000XM5', current_stock: 3, threshold: 10, alert_type: 'low_stock', is_read: false, created_at: new Date().toISOString() },
  { id: '3', seller_id: '1', product_id: '4', product_name: 'AirPods Pro 2', current_stock: 5, threshold: 10, alert_type: 'low_stock', is_read: true, created_at: new Date(Date.now() - 86400000).toISOString() },
];

// Mock sales goals
const mockSalesGoals: SalesGoal[] = [
  { id: '1', seller_id: '1', goal_type: 'revenue', target_value: 5000000, current_value: 3750000, period: 'monthly', start_date: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString(), end_date: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString(), is_active: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: '2', seller_id: '1', goal_type: 'orders', target_value: 200, current_value: 156, period: 'monthly', start_date: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString(), end_date: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString(), is_active: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: '3', seller_id: '1', goal_type: 'new_customers', target_value: 50, current_value: 38, period: 'monthly', start_date: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString(), end_date: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString(), is_active: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
];

const SellerAnalytics: React.FC = () => {
  const { user } = useAuth();
  const { getSalesGoals, createSalesGoal, deleteSalesGoal, getStockAlerts, getProductReviews, respondToReview, loading } = useProducts();
  
  const [selectedRange, setSelectedRange] = useState<DateRange>(dateRanges[1]);
  const [showRangeDropdown, setShowRangeDropdown] = useState(false);
  const [compareWithPrevious, setCompareWithPrevious] = useState(true);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [activeChart, setActiveChart] = useState<'revenue' | 'orders' | 'viewers'>('revenue');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeSection, setActiveSection] = useState<'overview' | 'goals' | 'reviews' | 'stock'>('overview');
  
  // Goals state
  const [salesGoals, setSalesGoals] = useState<SalesGoal[]>(mockSalesGoals);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [newGoal, setNewGoal] = useState({
    goalType: 'revenue' as const,
    targetValue: 0,
    period: 'monthly' as const
  });
  
  // Stock alerts state
  const [stockAlerts, setStockAlerts] = useState<StockAlert[]>(mockStockAlerts);
  
  // Reviews state
  const [reviews, setReviews] = useState<ProductReview[]>(mockReviews);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const analyticsData = useMemo(() => generateAnalyticsData(selectedRange.days), [selectedRange]);
  
  // Calculate totals and changes
  const currentPeriodTotals = useMemo(() => {
    const midPoint = Math.floor(analyticsData.revenue.length / 2);
    const currentRevenue = analyticsData.revenue.slice(midPoint).reduce((a, b) => a + b, 0);
    const previousRevenue = analyticsData.revenue.slice(0, midPoint).reduce((a, b) => a + b, 0);
    const currentOrders = analyticsData.orders.slice(midPoint).reduce((a, b) => a + b, 0);
    const previousOrders = analyticsData.orders.slice(0, midPoint).reduce((a, b) => a + b, 0);
    const currentViewers = analyticsData.viewers.slice(midPoint).reduce((a, b) => a + b, 0);
    const previousViewers = analyticsData.viewers.slice(0, midPoint).reduce((a, b) => a + b, 0);
    
    return {
      revenue: analyticsData.revenue.reduce((a, b) => a + b, 0),
      revenueChange: previousRevenue > 0 ? ((currentRevenue - previousRevenue) / previousRevenue * 100).toFixed(1) : '0',
      orders: analyticsData.orders.reduce((a, b) => a + b, 0),
      ordersChange: previousOrders > 0 ? ((currentOrders - previousOrders) / previousOrders * 100).toFixed(1) : '0',
      viewers: analyticsData.viewers.reduce((a, b) => a + b, 0),
      viewersChange: previousViewers > 0 ? ((currentViewers - previousViewers) / previousViewers * 100).toFixed(1) : '0',
      avgOrderValue: analyticsData.orders.reduce((a, b) => a + b, 0) > 0 
        ? analyticsData.revenue.reduce((a, b) => a + b, 0) / analyticsData.orders.reduce((a, b) => a + b, 0)
        : 0,
      conversionRate: (analyticsData.orders.reduce((a, b) => a + b, 0) / analyticsData.viewers.reduce((a, b) => a + b, 0) * 100).toFixed(2)
    };
  }, [analyticsData]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const handleExport = (format: 'csv' | 'pdf') => {
    setShowExportMenu(false);
    
    if (format === 'csv') {
      let csvContent = 'Date,Revenus,Commandes,Vues,Produits Vendus\n';
      analyticsData.labels.forEach((label, index) => {
        csvContent += `${label},${analyticsData.revenue[index]},${analyticsData.orders[index]},${analyticsData.viewers[index]},${analyticsData.products[index]}\n`;
      });
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `analytics_${selectedRange.value}_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
    } else {
      const printContent = `
        <html>
          <head>
            <title>Rapport Analytics - PITCH</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; }
              h1 { color: #dc2626; }
              table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #dc2626; color: white; }
              .metric { margin: 10px 0; padding: 15px; background: #f5f5f5; border-radius: 8px; }
            </style>
          </head>
          <body>
            <h1>Rapport Analytics - PITCH</h1>
            <p>Période: ${selectedRange.label}</p>
            <div class="metric"><strong>Revenus Total:</strong> ${formatPrice(currentPeriodTotals.revenue)}</div>
            <div class="metric"><strong>Commandes:</strong> ${currentPeriodTotals.orders}</div>
            <div class="metric"><strong>Vues Total:</strong> ${currentPeriodTotals.viewers.toLocaleString()}</div>
            <div class="metric"><strong>Taux de Conversion:</strong> ${currentPeriodTotals.conversionRate}%</div>
            <h2>Performance Produits</h2>
            <table>
              <tr><th>Produit</th><th>Ventes</th><th>Revenus</th><th>Vues</th><th>Conversion</th></tr>
              ${productPerformance.map(p => `<tr><td>${p.name}</td><td>${p.sales}</td><td>${formatPrice(p.revenue)}</td><td>${p.views}</td><td>${p.conversion}%</td></tr>`).join('')}
            </table>
          </body>
        </html>
      `;
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  const handleCreateGoal = async () => {
    const now = new Date();
    let startDate = new Date();
    let endDate = new Date();
    
    switch (newGoal.period) {
      case 'daily':
        endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        break;
      case 'weekly':
        endDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        break;
      case 'monthly':
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        break;
      case 'quarterly':
        endDate = new Date(now.getFullYear(), now.getMonth() + 3, 0);
        break;
      case 'yearly':
        endDate = new Date(now.getFullYear(), 11, 31);
        break;
    }
    
    const goal: SalesGoal = {
      id: Date.now().toString(),
      seller_id: user?.id || '',
      goal_type: newGoal.goalType,
      target_value: newGoal.targetValue,
      current_value: 0,
      period: newGoal.period,
      start_date: startDate.toISOString(),
      end_date: endDate.toISOString(),
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    setSalesGoals([...salesGoals, goal]);
    setShowGoalModal(false);
    setNewGoal({ goalType: 'revenue', targetValue: 0, period: 'monthly' });
    toast({ title: 'Objectif créé', description: 'Votre nouvel objectif a été ajouté' });
  };

  const handleDeleteGoal = (goalId: string) => {
    setSalesGoals(salesGoals.filter(g => g.id !== goalId));
    toast({ title: 'Objectif supprimé' });
  };

  const handleReplyToReview = (reviewId: string) => {
    const updatedReviews = reviews.map(r => 
      r.id === reviewId 
        ? { ...r, seller_response: replyText, seller_response_at: new Date().toISOString() }
        : r
    );
    setReviews(updatedReviews);
    setReplyingTo(null);
    setReplyText('');
    toast({ title: 'Réponse envoyée', description: 'Votre réponse a été publiée' });
  };

  const getGoalTypeLabel = (type: string) => {
    switch (type) {
      case 'revenue': return 'Chiffre d\'affaires';
      case 'orders': return 'Commandes';
      case 'products_sold': return 'Produits vendus';
      case 'new_customers': return 'Nouveaux clients';
      default: return type;
    }
  };

  const getGoalIcon = (type: string) => {
    switch (type) {
      case 'revenue': return <DollarSign className="w-5 h-5" />;
      case 'orders': return <ShoppingBag className="w-5 h-5" />;
      case 'products_sold': return <Package className="w-5 h-5" />;
      case 'new_customers': return <Users className="w-5 h-5" />;
      default: return <Target className="w-5 h-5" />;
    }
  };

  // Simple bar chart component
  const BarChartSimple: React.FC<{ data: number[]; labels: string[]; color: string; maxBars?: number }> = ({ 
    data, labels, color, maxBars = 12 
  }) => {
    const displayData = data.slice(-maxBars);
    const displayLabels = labels.slice(-maxBars);
    const maxValue = Math.max(...displayData);
    
    return (
      <div className="flex items-end justify-between h-48 gap-1">
        {displayData.map((value, index) => (
          <div key={index} className="flex flex-col items-center flex-1 group">
            <div className="relative w-full flex justify-center mb-2">
              <div 
                className={`w-full max-w-8 rounded-t-md transition-all duration-300 ${color} group-hover:opacity-80`}
                style={{ height: `${(value / maxValue) * 160}px`, minHeight: '4px' }}
              />
              <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-700 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                {activeChart === 'revenue' ? formatPrice(value) : value.toLocaleString()}
              </div>
            </div>
            <span className="text-slate-500 text-xs truncate w-full text-center">
              {displayLabels[index]}
            </span>
          </div>
        ))}
      </div>
    );
  };

  const stats = [
    {
      label: 'Revenus Total',
      value: formatPrice(currentPeriodTotals.revenue),
      change: currentPeriodTotals.revenueChange,
      icon: <DollarSign className="w-5 h-5" />,
      color: 'from-green-500 to-emerald-500'
    },
    {
      label: 'Commandes',
      value: currentPeriodTotals.orders.toString(),
      change: currentPeriodTotals.ordersChange,
      icon: <ShoppingBag className="w-5 h-5" />,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      label: 'Vues Total',
      value: currentPeriodTotals.viewers.toLocaleString(),
      change: currentPeriodTotals.viewersChange,
      icon: <Eye className="w-5 h-5" />,
      color: 'from-purple-500 to-pink-500'
    },
    {
      label: 'Panier Moyen',
      value: formatPrice(currentPeriodTotals.avgOrderValue),
      change: '5.2',
      icon: <Package className="w-5 h-5" />,
      color: 'from-orange-500 to-yellow-500'
    },
    {
      label: 'Taux de Conversion',
      value: `${currentPeriodTotals.conversionRate}%`,
      change: '0.3',
      icon: <TrendingUp className="w-5 h-5" />,
      color: 'from-cyan-500 to-blue-500'
    },
    {
      label: 'Lives Réalisés',
      value: '12',
      change: '20',
      icon: <Video className="w-5 h-5" />,
      color: 'from-red-500 to-pink-500'
    }
  ];

  const avgRating = (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1);
  const unreadAlerts = stockAlerts.filter(a => !a.is_read).length;

  return (
    <div className="space-y-6">
      {/* Header with filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-white text-2xl font-bold">Tableau de Bord Analytics</h2>
          <p className="text-slate-400 text-sm mt-1">Suivez vos performances et optimisez vos ventes</p>
        </div>
        
        <div className="flex items-center gap-3 flex-wrap">
          {/* Section tabs */}
          <div className="flex gap-1 bg-slate-800 p-1 rounded-xl">
            {[
              { id: 'overview', label: 'Aperçu', icon: <BarChart3 className="w-4 h-4" /> },
              { id: 'goals', label: 'Objectifs', icon: <Target className="w-4 h-4" /> },
              { id: 'reviews', label: 'Avis', icon: <Star className="w-4 h-4" />, badge: reviews.filter(r => !r.seller_response).length },
              { id: 'stock', label: 'Stock', icon: <AlertTriangle className="w-4 h-4" />, badge: unreadAlerts }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveSection(tab.id as any)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all relative ${
                  activeSection === tab.id
                    ? 'bg-orange-500 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.icon}
                <span className="hidden sm:inline">{tab.label}</span>
                {tab.badge && tab.badge > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {tab.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Overview Section */}
      {activeSection === 'overview' && (
        <>
          {/* Filters Row */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <button
              onClick={() => setCompareWithPrevious(!compareWithPrevious)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                compareWithPrevious 
                  ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30' 
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              Comparer
            </button>

            <div className="flex items-center gap-3">
              {/* Date range selector */}
              <div className="relative">
                <button
                  onClick={() => setShowRangeDropdown(!showRangeDropdown)}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm font-medium hover:border-slate-600 transition-all"
                >
                  <Calendar className="w-4 h-4 text-slate-400" />
                  {selectedRange.label}
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${showRangeDropdown ? 'rotate-180' : ''}`} />
                </button>
                
                {showRangeDropdown && (
                  <div className="absolute right-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-xl shadow-xl z-20 overflow-hidden">
                    {dateRanges.map((range) => (
                      <button
                        key={range.value}
                        onClick={() => {
                          setSelectedRange(range);
                          setShowRangeDropdown(false);
                        }}
                        className={`w-full px-4 py-3 text-left text-sm transition-colors ${
                          selectedRange.value === range.value
                            ? 'bg-orange-500/20 text-orange-400'
                            : 'text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {range.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Export button */}
              <div className="relative">
                <button
                  onClick={() => setShowExportMenu(!showExportMenu)}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-yellow-500 text-white text-sm font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all"
                >
                  <Download className="w-4 h-4" />
                  Exporter
                </button>
                
                {showExportMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-xl shadow-xl z-20 overflow-hidden">
                    <button
                      onClick={() => handleExport('csv')}
                      className="w-full flex items-center gap-3 px-4 py-3 text-left text-sm text-slate-300 hover:bg-slate-700 transition-colors"
                    >
                      <FileSpreadsheet className="w-4 h-4 text-green-400" />
                      Exporter en CSV
                    </button>
                    <button
                      onClick={() => handleExport('pdf')}
                      className="w-full flex items-center gap-3 px-4 py-3 text-left text-sm text-slate-300 hover:bg-slate-700 transition-colors"
                    >
                      <FileText className="w-4 h-4 text-red-400" />
                      Exporter en PDF
                    </button>
                  </div>
                )}
              </div>

              <button
                onClick={handleRefresh}
                className={`p-2 bg-slate-800 border border-slate-700 rounded-xl text-slate-400 hover:text-white hover:border-slate-600 transition-all ${isRefreshing ? 'animate-spin' : ''}`}
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {stats.map((stat, index) => {
              const isPositive = parseFloat(stat.change) >= 0;
              return (
                <div
                  key={index}
                  className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700 hover:border-slate-600 transition-all"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center text-white`}>
                      {stat.icon}
                    </div>
                    {compareWithPrevious && (
                      <div className={`flex items-center gap-1 text-xs font-medium ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                        {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                        {Math.abs(parseFloat(stat.change))}%
                      </div>
                    )}
                  </div>
                  <p className="text-xl font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-slate-400 text-xs">{stat.label}</p>
                </div>
              );
            })}
          </div>

          {/* Main Chart Section */}
          <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <h3 className="text-white font-semibold text-lg">Évolution des Performances</h3>
              <div className="flex gap-2">
                {[
                  { key: 'revenue', label: 'Revenus', color: 'from-green-500 to-emerald-500' },
                  { key: 'orders', label: 'Commandes', color: 'from-blue-500 to-cyan-500' },
                  { key: 'viewers', label: 'Vues', color: 'from-purple-500 to-pink-500' }
                ].map((chart) => (
                  <button
                    key={chart.key}
                    onClick={() => setActiveChart(chart.key as any)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                      activeChart === chart.key
                        ? `bg-gradient-to-r ${chart.color} text-white`
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {chart.label}
                  </button>
                ))}
              </div>
            </div>
            
            <BarChartSimple
              data={activeChart === 'revenue' ? analyticsData.revenue : activeChart === 'orders' ? analyticsData.orders : analyticsData.viewers}
              labels={analyticsData.labels}
              color={activeChart === 'revenue' ? 'bg-gradient-to-t from-green-600 to-emerald-400' : activeChart === 'orders' ? 'bg-gradient-to-t from-blue-600 to-cyan-400' : 'bg-gradient-to-t from-purple-600 to-pink-400'}
            />
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Top Products */}
            <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-white font-semibold text-lg">Top Produits Vendus</h3>
                <span className="text-slate-400 text-sm">{productPerformance.length} produits</span>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-slate-400 text-xs uppercase">
                      <th className="text-left pb-4">Produit</th>
                      <th className="text-right pb-4">Ventes</th>
                      <th className="text-right pb-4">Revenus</th>
                      <th className="text-right pb-4">Conv.</th>
                      <th className="text-right pb-4">Trend</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700">
                    {productPerformance.slice(0, 5).map((product, index) => (
                      <tr key={product.id} className="hover:bg-slate-700/30 transition-colors">
                        <td className="py-3">
                          <div className="flex items-center gap-2">
                            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                              index === 0 ? 'bg-yellow-500 text-yellow-900' :
                              index === 1 ? 'bg-slate-400 text-slate-900' :
                              index === 2 ? 'bg-orange-600 text-orange-100' :
                              'bg-slate-700 text-slate-300'
                            }`}>
                              {index + 1}
                            </span>
                            <div>
                              <p className="text-white text-sm font-medium truncate max-w-[120px]">{product.name}</p>
                              <p className="text-slate-500 text-xs">{product.views.toLocaleString()} vues</p>
                            </div>
                          </div>
                        </td>
                        <td className="text-right py-3">
                          <span className="text-white font-medium">{product.sales}</span>
                        </td>
                        <td className="text-right py-3">
                          <span className="text-orange-400 font-medium text-sm">{formatPrice(product.revenue)}</span>
                        </td>
                        <td className="text-right py-3">
                          <span className="text-slate-300 text-sm">{product.conversion}%</span>
                        </td>
                        <td className="text-right py-3">
                          <span className={`flex items-center justify-end gap-1 text-sm font-medium ${product.trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {product.trend >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                            {Math.abs(product.trend)}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recent Reviews */}
            <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-white font-semibold text-lg">Avis Récents</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${star <= Math.round(parseFloat(avgRating)) ? 'text-yellow-400 fill-yellow-400' : 'text-slate-600'}`}
                        />
                      ))}
                    </div>
                    <span className="text-white font-bold">{avgRating}</span>
                    <span className="text-slate-400 text-sm">({reviews.length} avis)</span>
                  </div>
                </div>
                <button 
                  onClick={() => setActiveSection('reviews')}
                  className="text-orange-500 text-sm font-medium flex items-center gap-1 hover:underline"
                >
                  Voir tout <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              
              <div className="space-y-4">
                {reviews.slice(0, 3).map((review) => (
                  <div key={review.id} className="p-3 bg-slate-900/50 rounded-xl">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-white font-medium text-sm">{review.buyer_name}</span>
                          <div className="flex items-center gap-0.5">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-3 h-3 ${star <= review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-slate-600'}`}
                              />
                            ))}
                          </div>
                          {review.is_verified_purchase && (
                            <span className="px-1.5 py-0.5 bg-green-500/20 text-green-400 text-xs rounded">Vérifié</span>
                          )}
                        </div>
                        <p className="text-slate-300 text-sm line-clamp-2">{review.comment}</p>
                        <p className="text-slate-500 text-xs mt-1">
                          {new Date(review.created_at).toLocaleDateString('fr-FR')}
                        </p>
                      </div>
                    </div>
                    {review.seller_response && (
                      <div className="mt-2 pl-3 border-l-2 border-orange-500">
                        <p className="text-slate-400 text-xs">Votre réponse:</p>
                        <p className="text-slate-300 text-sm">{review.seller_response}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Insights */}
          <div className="grid md:grid-cols-3 gap-4">
            {[
              {
                title: 'Meilleur jour de vente',
                value: 'Samedi',
                detail: '28% des ventes',
                icon: <Calendar className="w-5 h-5" />,
                color: 'from-green-500 to-emerald-500'
              },
              {
                title: 'Heure de pointe',
                value: '19h - 21h',
                detail: 'Plus de spectateurs',
                icon: <Clock className="w-5 h-5" />,
                color: 'from-blue-500 to-cyan-500'
              },
              {
                title: 'Catégorie populaire',
                value: 'Électronique',
                detail: '45% des revenus',
                icon: <PieChart className="w-5 h-5" />,
                color: 'from-purple-500 to-pink-500'
              }
            ].map((insight, index) => (
              <div key={index} className="bg-slate-800/50 rounded-2xl p-5 border border-slate-700 flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${insight.color} flex items-center justify-center text-white shrink-0`}>
                  {insight.icon}
                </div>
                <div>
                  <p className="text-slate-400 text-xs">{insight.title}</p>
                  <p className="text-white font-bold text-lg">{insight.value}</p>
                  <p className="text-slate-500 text-xs">{insight.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Sales Goals Section */}
      {activeSection === 'goals' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white text-xl font-bold">Objectifs de Vente</h3>
              <p className="text-slate-400 text-sm">Définissez et suivez vos objectifs commerciaux</p>
            </div>
            <button
              onClick={() => setShowGoalModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all"
            >
              <Plus className="w-4 h-4" />
              Nouvel Objectif
            </button>
          </div>

          {/* Goals Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {salesGoals.map((goal) => {
              const progress = (goal.current_value / goal.target_value) * 100;
              const isCompleted = progress >= 100;
              const daysLeft = Math.ceil((new Date(goal.end_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
              
              return (
                <div key={goal.id} className={`bg-slate-800/50 rounded-2xl p-6 border ${isCompleted ? 'border-green-500/50' : 'border-slate-700'}`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      isCompleted ? 'bg-green-500/20 text-green-400' : 'bg-orange-500/20 text-orange-400'
                    }`}>
                      {isCompleted ? <Award className="w-6 h-6" /> : getGoalIcon(goal.goal_type)}
                    </div>
                    <button
                      onClick={() => handleDeleteGoal(goal.id)}
                      className="p-1.5 text-slate-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <h4 className="text-white font-semibold mb-1">{getGoalTypeLabel(goal.goal_type)}</h4>
                  <p className="text-slate-400 text-sm mb-4">
                    {goal.period === 'daily' ? 'Journalier' : 
                     goal.period === 'weekly' ? 'Hebdomadaire' : 
                     goal.period === 'monthly' ? 'Mensuel' : 
                     goal.period === 'quarterly' ? 'Trimestriel' : 'Annuel'}
                  </p>
                  
                  <div className="mb-3">
                    <div className="flex items-end justify-between mb-2">
                      <span className="text-2xl font-bold text-white">
                        {goal.goal_type === 'revenue' ? formatPrice(goal.current_value) : goal.current_value.toLocaleString()}
                      </span>
                      <span className="text-slate-400 text-sm">
                        / {goal.goal_type === 'revenue' ? formatPrice(goal.target_value) : goal.target_value.toLocaleString()}
                      </span>
                    </div>
                    <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all ${
                          isCompleted ? 'bg-green-500' : 'bg-gradient-to-r from-orange-500 to-yellow-500'
                        }`}
                        style={{ width: `${Math.min(100, progress)}%` }}
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className={`font-medium ${isCompleted ? 'text-green-400' : 'text-orange-400'}`}>
                      {progress.toFixed(0)}% atteint
                    </span>
                    {!isCompleted && (
                      <span className="text-slate-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {daysLeft > 0 ? `${daysLeft}j restants` : 'Expiré'}
                      </span>
                    )}
                    {isCompleted && (
                      <span className="text-green-400 flex items-center gap-1">
                        <Check className="w-4 h-4" />
                        Complété!
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {salesGoals.length === 0 && (
            <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
              <Target className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              <h3 className="text-white text-xl font-semibold mb-2">Aucun objectif défini</h3>
              <p className="text-slate-400 mb-6">Créez votre premier objectif pour suivre vos performances</p>
              <button
                onClick={() => setShowGoalModal(true)}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl"
              >
                Créer un objectif
              </button>
            </div>
          )}
        </div>
      )}

      {/* Reviews Section */}
      {activeSection === 'reviews' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white text-xl font-bold">Gestion des Avis</h3>
              <div className="flex items-center gap-3 mt-1">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-5 h-5 ${star <= Math.round(parseFloat(avgRating)) ? 'text-yellow-400 fill-yellow-400' : 'text-slate-600'}`}
                    />
                  ))}
                </div>
                <span className="text-white font-bold text-lg">{avgRating}</span>
                <span className="text-slate-400">({reviews.length} avis)</span>
              </div>
            </div>
          </div>

          {/* Rating Distribution */}
          <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <h4 className="text-white font-semibold mb-4">Distribution des Notes</h4>
            <div className="space-y-3">
              {[5, 4, 3, 2, 1].map((rating) => {
                const count = reviews.filter(r => r.rating === rating).length;
                const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
                return (
                  <div key={rating} className="flex items-center gap-3">
                    <div className="flex items-center gap-1 w-20">
                      <span className="text-white font-medium">{rating}</span>
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    </div>
                    <div className="flex-1 h-3 bg-slate-700 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-yellow-400 rounded-full transition-all"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-slate-400 text-sm w-16 text-right">{count} avis</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Reviews List */}
          <div className="space-y-4">
            {reviews.map((review) => (
              <div key={review.id} className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                        {review.buyer_name.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-medium">{review.buyer_name}</span>
                          {review.is_verified_purchase && (
                            <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded-full flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              Achat vérifié
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-0.5">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${star <= review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-slate-600'}`}
                              />
                            ))}
                          </div>
                          <span className="text-slate-500 text-sm">
                            {new Date(review.created_at).toLocaleDateString('fr-FR')}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    {review.title && (
                      <h5 className="text-white font-medium mb-1">{review.title}</h5>
                    )}
                    <p className="text-slate-300">{review.comment}</p>
                    
                    {review.seller_response && (
                      <div className="mt-4 p-4 bg-slate-900/50 rounded-xl border-l-2 border-orange-500">
                        <p className="text-orange-400 text-sm font-medium mb-1">Votre réponse</p>
                        <p className="text-slate-300">{review.seller_response}</p>
                        <p className="text-slate-500 text-xs mt-2">
                          {review.seller_response_at && new Date(review.seller_response_at).toLocaleDateString('fr-FR')}
                        </p>
                      </div>
                    )}
                    
                    {!review.seller_response && replyingTo === review.id && (
                      <div className="mt-4 space-y-3">
                        <textarea
                          value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          placeholder="Écrivez votre réponse..."
                          className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 resize-none"
                          rows={3}
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => { setReplyingTo(null); setReplyText(''); }}
                            className="px-4 py-2 bg-slate-700 text-white rounded-xl hover:bg-slate-600 transition-all"
                          >
                            Annuler
                          </button>
                          <button
                            onClick={() => handleReplyToReview(review.id)}
                            disabled={!replyText.trim()}
                            className="px-4 py-2 bg-orange-500 text-white font-semibold rounded-xl hover:bg-orange-600 transition-all disabled:opacity-50"
                          >
                            Répondre
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {!review.seller_response && replyingTo !== review.id && (
                    <button
                      onClick={() => setReplyingTo(review.id)}
                      className="flex items-center gap-2 px-4 py-2 bg-slate-700 text-white rounded-xl hover:bg-slate-600 transition-all"
                    >
                      <MessageSquare className="w-4 h-4" />
                      Répondre
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stock Alerts Section */}
      {activeSection === 'stock' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white text-xl font-bold">Alertes de Stock</h3>
              <p className="text-slate-400 text-sm">Surveillez vos niveaux de stock et évitez les ruptures</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1.5 bg-red-500/20 text-red-400 rounded-full text-sm font-medium">
                {stockAlerts.filter(a => a.alert_type === 'out_of_stock').length} en rupture
              </span>
              <span className="px-3 py-1.5 bg-yellow-500/20 text-yellow-400 rounded-full text-sm font-medium">
                {stockAlerts.filter(a => a.alert_type === 'low_stock').length} stock bas
              </span>
            </div>
          </div>

          {/* Stock Alerts List */}
          <div className="space-y-4">
            {stockAlerts.map((alert) => (
              <div 
                key={alert.id} 
                className={`bg-slate-800/50 rounded-2xl p-6 border ${
                  alert.alert_type === 'out_of_stock' 
                    ? 'border-red-500/50' 
                    : 'border-yellow-500/50'
                } ${alert.is_read ? 'opacity-60' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      alert.alert_type === 'out_of_stock' 
                        ? 'bg-red-500/20' 
                        : 'bg-yellow-500/20'
                    }`}>
                      <AlertTriangle className={`w-6 h-6 ${
                        alert.alert_type === 'out_of_stock' 
                          ? 'text-red-400' 
                          : 'text-yellow-400'
                      }`} />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold">{alert.product_name}</h4>
                      <p className={`text-sm ${
                        alert.alert_type === 'out_of_stock' 
                          ? 'text-red-400' 
                          : 'text-yellow-400'
                      }`}>
                        {alert.alert_type === 'out_of_stock' 
                          ? 'Rupture de stock!' 
                          : `Stock bas: ${alert.current_stock} unités restantes`}
                      </p>
                      <p className="text-slate-500 text-xs mt-1">
                        {new Date(alert.created_at).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button className="px-4 py-2 bg-slate-700 text-white rounded-xl hover:bg-slate-600 transition-all text-sm">
                      Réapprovisionner
                    </button>
                    {!alert.is_read && (
                      <button 
                        onClick={() => {
                          setStockAlerts(stockAlerts.map(a => 
                            a.id === alert.id ? { ...a, is_read: true } : a
                          ));
                        }}
                        className="p-2 text-slate-400 hover:text-white transition-colors"
                      >
                        <Check className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {stockAlerts.length === 0 && (
            <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
              <Package className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-white text-xl font-semibold mb-2">Tout va bien!</h3>
              <p className="text-slate-400">Aucune alerte de stock pour le moment</p>
            </div>
          )}

          {/* Products with Low Stock */}
          <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <h4 className="text-white font-semibold mb-4">Produits à surveiller</h4>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-slate-400 text-xs uppercase">
                    <th className="text-left pb-4">Produit</th>
                    <th className="text-right pb-4">Stock</th>
                    <th className="text-right pb-4">Ventes/sem</th>
                    <th className="text-right pb-4">Jours restants</th>
                    <th className="text-right pb-4">Statut</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700">
                  {productPerformance.filter(p => p.stock <= 10).map((product) => {
                    const weeklyAvg = Math.ceil(product.sales / 4);
                    const daysLeft = weeklyAvg > 0 ? Math.floor(product.stock / (weeklyAvg / 7)) : 999;
                    
                    return (
                      <tr key={product.id} className="hover:bg-slate-700/30 transition-colors">
                        <td className="py-3">
                          <p className="text-white font-medium">{product.name}</p>
                        </td>
                        <td className="text-right py-3">
                          <span className={`font-bold ${
                            product.stock === 0 ? 'text-red-400' : 
                            product.stock <= 5 ? 'text-yellow-400' : 'text-white'
                          }`}>
                            {product.stock}
                          </span>
                        </td>
                        <td className="text-right py-3">
                          <span className="text-slate-300">{weeklyAvg}</span>
                        </td>
                        <td className="text-right py-3">
                          <span className={`${
                            daysLeft <= 3 ? 'text-red-400' : 
                            daysLeft <= 7 ? 'text-yellow-400' : 'text-slate-300'
                          }`}>
                            {product.stock === 0 ? '-' : `~${daysLeft}j`}
                          </span>
                        </td>
                        <td className="text-right py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            product.stock === 0 
                              ? 'bg-red-500/20 text-red-400' 
                              : 'bg-yellow-500/20 text-yellow-400'
                          }`}>
                            {product.stock === 0 ? 'Rupture' : 'Stock bas'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Create Goal Modal */}
      {showGoalModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-md">
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <h3 className="text-white text-xl font-bold">Nouvel Objectif</h3>
                <button onClick={() => setShowGoalModal(false)} className="text-slate-400 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <label className="block text-white font-medium mb-2">Type d'objectif</label>
                <select
                  value={newGoal.goalType}
                  onChange={(e) => setNewGoal({ ...newGoal, goalType: e.target.value as any })}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="revenue">Chiffre d'affaires</option>
                  <option value="orders">Nombre de commandes</option>
                  <option value="products_sold">Produits vendus</option>
                  <option value="new_customers">Nouveaux clients</option>
                </select>
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">Objectif cible</label>
                <input
                  type="number"
                  value={newGoal.targetValue || ''}
                  onChange={(e) => setNewGoal({ ...newGoal, targetValue: parseInt(e.target.value) || 0 })}
                  placeholder={newGoal.goalType === 'revenue' ? 'Ex: 5000000' : 'Ex: 100'}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                />
                {newGoal.goalType === 'revenue' && newGoal.targetValue > 0 && (
                  <p className="text-slate-400 text-sm mt-1">{formatPrice(newGoal.targetValue)}</p>
                )}
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">Période</label>
                <select
                  value={newGoal.period}
                  onChange={(e) => setNewGoal({ ...newGoal, period: e.target.value as any })}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="daily">Journalier</option>
                  <option value="weekly">Hebdomadaire</option>
                  <option value="monthly">Mensuel</option>
                  <option value="quarterly">Trimestriel</option>
                  <option value="yearly">Annuel</option>
                </select>
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowGoalModal(false)}
                className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
              >
                Annuler
              </button>
              <button
                onClick={handleCreateGoal}
                disabled={!newGoal.targetValue}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50"
              >
                Créer l'objectif
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SellerAnalytics;
