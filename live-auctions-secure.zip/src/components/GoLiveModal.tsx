import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  X, Video, Mic, MicOff, VideoOff, Monitor,
  Radio, Users, Clock, Package, CheckCircle, AlertCircle,
  Camera, Wifi, Zap, ChevronDown, RefreshCw, StopCircle,
  MessageSquare, ShoppingBag, Eye, Shield, Film, Disc, Flame
} from 'lucide-react';
import { useAgoraStream } from '@/hooks/useAgoraStream';
import { useAuth } from '@/contexts/AuthContext';
import { useLiveStream } from '@/hooks/useLiveStream';
import { useFlashSales, FlashSale } from '@/hooks/useFlashSales';
import { formatPrice, products as mockProducts } from '@/data/mockData';
import { toast } from '@/components/ui/use-toast';
import LiveChat from './LiveChat';
import FlashSaleModal from './FlashSaleModal';

interface GoLiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLiveStarted?: (liveId: string) => void;
  onLiveEnded?: () => void;
}

interface MediaDevice {
  deviceId: string;
  label: string;
  kind: string;
}

type StreamQuality = 'low' | 'medium' | 'high' | 'ultra';

const QUALITY_OPTIONS: { value: StreamQuality; label: string; description: string }[] = [
  { value: 'low', label: '360p', description: 'Économie de données' },
  { value: 'medium', label: '720p HD', description: 'Recommandé' },
  { value: 'high', label: '1080p Full HD', description: 'Haute qualité' },
  { value: 'ultra', label: '1080p 60fps', description: 'Ultra fluide' }
];

// Flash Sale Countdown Component
const FlashSaleCountdown: React.FC<{ flashSale: FlashSale; onEnd: () => void }> = ({ flashSale, onEnd }) => {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const end = new Date(flashSale.ends_at).getTime();
      return Math.max(0, Math.floor((end - now) / 1000));
    };

    setTimeLeft(calculateTimeLeft());
    const interval = setInterval(() => {
      const remaining = calculateTimeLeft();
      setTimeLeft(remaining);
      if (remaining <= 0) {
        clearInterval(interval);
        onEnd();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [flashSale.ends_at, onEnd]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-xl p-3 animate-pulse">
      <div className="flex items-center gap-2 mb-2">
        <Flame className="w-4 h-4 text-white" />
        <span className="text-white font-bold text-sm">VENTE FLASH</span>
        <span className="ml-auto text-white font-mono font-bold">
          {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
        </span>
      </div>
      <div className="flex items-center gap-2">
        {flashSale.product_image && (
          <img src={flashSale.product_image} alt="" className="w-10 h-10 rounded-lg object-cover" />
        )}
        <div className="flex-1 min-w-0">
          <p className="text-white text-xs font-medium truncate">{flashSale.product_name}</p>
          <div className="flex items-center gap-2">
            <span className="text-white font-bold text-sm">{formatPrice(flashSale.flash_price)}</span>
            <span className="text-white/60 text-xs line-through">{formatPrice(flashSale.original_price)}</span>
            <span className="bg-white/20 px-1.5 py-0.5 rounded text-white text-xs font-bold">-{flashSale.discount_percent}%</span>
          </div>
        </div>
      </div>
      {flashSale.max_units && (
        <div className="mt-2">
          <div className="flex justify-between text-white text-xs mb-1">
            <span>{flashSale.units_sold} vendus</span>
            <span>{flashSale.max_units - flashSale.units_sold} restants</span>
          </div>
          <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
            <div 
              className="h-full bg-white rounded-full transition-all"
              style={{ width: `${(flashSale.units_sold / flashSale.max_units) * 100}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

const GoLiveModal: React.FC<GoLiveModalProps> = ({
  isOpen,
  onClose,
  onLiveStarted,
  onLiveEnded
}) => {
  const { user, profile } = useAuth();
  const { scheduleLive, startLive, endLive } = useLiveStream();
  const {
    isPublishing,
    isScreenSharing,
    isMuted,
    isVideoOff,
    localVideoTrack,
    streamStats,
    error: agoraError,
    loading: agoraLoading,
    recordingState,
    joinAsHost,
    leave,
    toggleMute,
    toggleVideo,
    startScreenShare,
    stopScreenShare,
    setVideoQuality,
    startRecording,
    stopRecording
  } = useAgoraStream();

  const [step, setStep] = useState<'setup' | 'preview' | 'live'>('setup');
  const [streamTitle, setStreamTitle] = useState('');
  const [streamDescription, setStreamDescription] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Électronique');
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [quality, setQuality] = useState<StreamQuality>('medium');
  const [cameras, setCameras] = useState<MediaDevice[]>([]);
  const [microphones, setMicrophones] = useState<MediaDevice[]>([]);
  const [selectedCamera, setSelectedCamera] = useState<string>('');
  const [selectedMicrophone, setSelectedMicrophone] = useState<string>('');
  const [isLoadingDevices, setIsLoadingDevices] = useState(false);
  const [previewStream, setPreviewStream] = useState<MediaStream | null>(null);
  const [currentLiveId, setCurrentLiveId] = useState<string | null>(null);
  const [viewerCount, setViewerCount] = useState(0);
  const [liveDuration, setLiveDuration] = useState(0);
  const [showChat, setShowChat] = useState(true);
  const [showProducts, setShowProducts] = useState(true);
  const [enableRecording, setEnableRecording] = useState(true);
  const [isEndingLive, setIsEndingLive] = useState(false);
  const [showFlashSaleModal, setShowFlashSaleModal] = useState(false);

  // Flash sales hook
  const { 
    activeFlashSales, 
    createFlashSale, 
    endFlashSale,
    loading: flashSaleLoading 
  } = useFlashSales(currentLiveId || undefined);

  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const liveVideoRef = useRef<HTMLDivElement>(null);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const viewerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const categories = ['Électronique', 'Mode', 'Beauté', 'Maison', 'Bijoux', 'Chaussures', 'Auto', 'Accessoires'];

  // Get products for flash sale modal
  const liveProducts = selectedProducts.map(id => {
    const product = mockProducts.find(p => p.id === id);
    return product ? { id: product.id, name: product.name, price: product.price, image: product.image } : null;
  }).filter(Boolean) as { id: string; name: string; price: number; image?: string }[];

  const getMediaDevices = useCallback(async () => {
    setIsLoadingDevices(true);
    try {
      await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      const devices = await navigator.mediaDevices.enumerateDevices();
      
      const videoDevices = devices
        .filter(d => d.kind === 'videoinput')
        .map(d => ({ deviceId: d.deviceId, label: d.label || `Camera ${d.deviceId.slice(0, 8)}`, kind: d.kind }));
      
      const audioDevices = devices
        .filter(d => d.kind === 'audioinput')
        .map(d => ({ deviceId: d.deviceId, label: d.label || `Microphone ${d.deviceId.slice(0, 8)}`, kind: d.kind }));

      setCameras(videoDevices);
      setMicrophones(audioDevices);

      if (videoDevices.length > 0 && !selectedCamera) setSelectedCamera(videoDevices[0].deviceId);
      if (audioDevices.length > 0 && !selectedMicrophone) setSelectedMicrophone(audioDevices[0].deviceId);
    } catch (err) {
      console.error('Error getting media devices:', err);
      toast({ title: "Erreur d'accès", description: "Impossible d'accéder à la caméra ou au microphone.", variant: "destructive" });
    } finally {
      setIsLoadingDevices(false);
    }
  }, [selectedCamera, selectedMicrophone]);

  const startPreview = useCallback(async () => {
    try {
      if (previewStream) previewStream.getTracks().forEach(track => track.stop());
      const constraints: MediaStreamConstraints = {
        video: selectedCamera ? { deviceId: { exact: selectedCamera } } : true,
        audio: selectedMicrophone ? { deviceId: { exact: selectedMicrophone } } : true
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setPreviewStream(stream);
      if (videoPreviewRef.current) videoPreviewRef.current.srcObject = stream;
    } catch (err) {
      console.error('Error starting preview:', err);
      toast({ title: "Erreur de prévisualisation", description: "Impossible de démarrer la prévisualisation.", variant: "destructive" });
    }
  }, [selectedCamera, selectedMicrophone, previewStream]);

  const stopPreview = useCallback(() => {
    if (previewStream) {
      previewStream.getTracks().forEach(track => track.stop());
      setPreviewStream(null);
    }
    if (videoPreviewRef.current) videoPreviewRef.current.srcObject = null;
  }, [previewStream]);

  const goToPreview = useCallback(async () => {
    if (!streamTitle.trim()) {
      toast({ title: "Titre requis", description: "Veuillez entrer un titre pour votre live", variant: "destructive" });
      return;
    }
    await startPreview();
    setStep('preview');
  }, [streamTitle, startPreview]);

  const handleStartLive = useCallback(async () => {
    if (!user) return;
    try {
      stopPreview();
      const selectedProductsData = mockProducts
        .filter(p => selectedProducts.includes(p.id))
        .map(p => ({ id: p.id, name: p.name, price: p.price, image: p.image, originalPrice: p.originalPrice }));

      const liveData = await scheduleLive({
        title: streamTitle,
        description: streamDescription,
        scheduledAt: new Date().toISOString(),
        category: selectedCategory,
        products: selectedProductsData
      });

      if (!liveData) throw new Error('Failed to create live stream');

      const channelName = `live_${liveData.id}`;
      const joined = await joinAsHost(channelName);
      if (!joined) throw new Error('Failed to join streaming channel');

      await setVideoQuality(quality);

      let recordingResourceId: string | undefined;
      let recordingSid: string | undefined;
      
      if (enableRecording) {
        const recordingStarted = await startRecording(liveData.id);
        if (recordingStarted) {
          toast({ title: "Enregistrement démarré", description: "Votre live sera automatiquement enregistré pour la rediffusion" });
        }
      }

      await startLive(liveData.id, recordingResourceId, recordingSid);

      setCurrentLiveId(liveData.id);
      setStep('live');

      durationIntervalRef.current = setInterval(() => setLiveDuration(prev => prev + 1), 1000);
      viewerIntervalRef.current = setInterval(() => {
        setViewerCount(prev => Math.max(0, prev + Math.floor(Math.random() * 5) - 1));
      }, 5000);

      toast({ title: "Vous êtes en direct!", description: "Votre live a commencé. Bonne diffusion!" });
      onLiveStarted?.(liveData.id);

    } catch (err: any) {
      console.error('Error starting live:', err);
      toast({ title: "Erreur", description: err.message || "Impossible de démarrer le live", variant: "destructive" });
    }
  }, [user, streamTitle, streamDescription, selectedCategory, selectedProducts, quality, enableRecording, joinAsHost, setVideoQuality, scheduleLive, startLive, startRecording, stopPreview, onLiveStarted]);

  const handleEndLive = useCallback(async () => {
    if (isEndingLive) return;
    setIsEndingLive(true);
    
    try {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
        durationIntervalRef.current = null;
      }
      if (viewerIntervalRef.current) {
        clearInterval(viewerIntervalRef.current);
        viewerIntervalRef.current = null;
      }

      let replayUrl: string | null = null;
      if (currentLiveId && recordingState.isRecording) {
        toast({ title: "Traitement en cours", description: "Enregistrement de la rediffusion..." });
        replayUrl = await stopRecording(currentLiveId);
        if (replayUrl) {
          toast({ title: "Rediffusion disponible", description: "Votre live a été enregistré et peut être rediffusé" });
        }
      }

      await leave();
      
      if (currentLiveId) {
        await endLive(currentLiveId, true, replayUrl || undefined);
      }
      
      toast({ title: "Live terminé", description: "Merci pour votre diffusion!" });
      onLiveEnded?.();
      handleClose();
    } catch (err: any) {
      console.error('Error ending live:', err);
      toast({ title: "Erreur", description: "Erreur lors de la fin du live", variant: "destructive" });
    } finally {
      setIsEndingLive(false);
    }
  }, [leave, endLive, stopRecording, currentLiveId, recordingState.isRecording, onLiveEnded, isEndingLive]);

  const handleClose = useCallback(() => {
    stopPreview();
    if (isPublishing) leave();
    if (durationIntervalRef.current) clearInterval(durationIntervalRef.current);
    if (viewerIntervalRef.current) clearInterval(viewerIntervalRef.current);
    setStep('setup');
    setStreamTitle('');
    setStreamDescription('');
    setSelectedProducts([]);
    setCurrentLiveId(null);
    setViewerCount(0);
    setLiveDuration(0);
    setIsEndingLive(false);
    onClose();
  }, [stopPreview, isPublishing, leave, onClose]);

  const formatDuration = (seconds: number): string => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (isOpen) getMediaDevices();
    return () => { stopPreview(); };
  }, [isOpen]);

  useEffect(() => {
    if (step === 'preview' && (selectedCamera || selectedMicrophone)) startPreview();
  }, [selectedCamera, selectedMicrophone]);

  useEffect(() => {
    if (step === 'live' && localVideoTrack && liveVideoRef.current) localVideoTrack.play(liveVideoRef.current);
  }, [step, localVideoTrack]);

  if (!isOpen) return null;

  const isVerified = profile?.is_verified || false;

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center">
        <div className={`bg-slate-900 rounded-2xl overflow-hidden ${step === 'live' ? 'w-full h-full' : 'w-full max-w-4xl max-h-[90vh]'}`}>
          
          {/* Setup Step */}
          {step === 'setup' && (
            <>
              <div className="p-6 border-b border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500 to-pink-500 flex items-center justify-center">
                    <Video className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-white text-xl font-bold">Démarrer un Live</h2>
                    <p className="text-slate-400 text-sm">Configurez votre diffusion en direct</p>
                  </div>
                </div>
                <button onClick={handleClose} className="p-2 text-slate-400 hover:text-white transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-6 overflow-y-auto max-h-[calc(90vh-180px)]">
                {!isVerified && (
                  <div className="mb-6 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
                    <div className="flex items-start gap-3">
                      <Shield className="w-5 h-5 text-yellow-400 mt-0.5" />
                      <div>
                        <p className="text-yellow-400 font-medium">Compte non vérifié</p>
                        <p className="text-slate-400 text-sm">Les vendeurs vérifiés ont plus de visibilité.</p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="space-y-6">
                    <div>
                      <label className="block text-white font-medium mb-2">Titre du Live <span className="text-red-400">*</span></label>
                      <input type="text" value={streamTitle} onChange={(e) => setStreamTitle(e.target.value)} placeholder="Ex: Vente Flash Smartphones" className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-red-500" />
                    </div>
                    <div>
                      <label className="block text-white font-medium mb-2">Description</label>
                      <textarea value={streamDescription} onChange={(e) => setStreamDescription(e.target.value)} placeholder="Décrivez ce que vous allez présenter..." rows={3} className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-red-500 resize-none" />
                    </div>
                    <div>
                      <label className="block text-white font-medium mb-2">Catégorie</label>
                      <div className="relative">
                        <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-red-500 appearance-none cursor-pointer">
                          {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-white font-medium mb-2">Produits à présenter ({selectedProducts.length})</label>
                      <div className="grid grid-cols-3 gap-2 max-h-40 overflow-y-auto p-2 bg-slate-800 rounded-xl border border-slate-700">
                        {mockProducts.slice(0, 12).map(product => (
                          <label key={product.id} className={`relative cursor-pointer rounded-lg overflow-hidden border-2 transition-all ${selectedProducts.includes(product.id) ? 'border-red-500 ring-2 ring-red-500/30' : 'border-transparent hover:border-slate-600'}`}>
                            <input type="checkbox" checked={selectedProducts.includes(product.id)} onChange={(e) => {
                              if (e.target.checked) setSelectedProducts(prev => [...prev, product.id]);
                              else setSelectedProducts(prev => prev.filter(id => id !== product.id));
                            }} className="sr-only" />
                            <img src={product.image} alt={product.name} className="w-full aspect-square object-cover" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-1.5">
                              <p className="text-white text-[10px] font-medium line-clamp-1">{product.name}</p>
                            </div>
                            {selectedProducts.includes(product.id) && (
                              <div className="absolute top-1 right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                                <CheckCircle className="w-3 h-3 text-white" />
                              </div>
                            )}
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <label className="block text-white font-medium mb-2 flex items-center gap-2"><Camera className="w-4 h-4 text-slate-400" />Caméra</label>
                      <div className="relative">
                        <select value={selectedCamera} onChange={(e) => setSelectedCamera(e.target.value)} disabled={isLoadingDevices || cameras.length === 0} className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-red-500 appearance-none cursor-pointer disabled:opacity-50">
                          {cameras.length === 0 ? <option>Aucune caméra détectée</option> : cameras.map(cam => <option key={cam.deviceId} value={cam.deviceId}>{cam.label}</option>)}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-white font-medium mb-2 flex items-center gap-2"><Mic className="w-4 h-4 text-slate-400" />Microphone</label>
                      <div className="relative">
                        <select value={selectedMicrophone} onChange={(e) => setSelectedMicrophone(e.target.value)} disabled={isLoadingDevices || microphones.length === 0} className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-red-500 appearance-none cursor-pointer disabled:opacity-50">
                          {microphones.length === 0 ? <option>Aucun microphone détecté</option> : microphones.map(mic => <option key={mic.deviceId} value={mic.deviceId}>{mic.label}</option>)}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-white font-medium mb-2 flex items-center gap-2"><Zap className="w-4 h-4 text-slate-400" />Qualité de diffusion</label>
                      <div className="grid grid-cols-2 gap-2">
                        {QUALITY_OPTIONS.map(opt => (
                          <button key={opt.value} onClick={() => setQuality(opt.value)} className={`p-3 rounded-xl border-2 text-left transition-all ${quality === opt.value ? 'border-red-500 bg-red-500/10' : 'border-slate-700 bg-slate-800 hover:border-slate-600'}`}>
                            <p className={`font-medium ${quality === opt.value ? 'text-red-400' : 'text-white'}`}>{opt.label}</p>
                            <p className="text-slate-500 text-xs">{opt.description}</p>
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    <div className="p-4 bg-slate-800 rounded-xl border border-slate-700">
                      <label className="flex items-center justify-between cursor-pointer">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${enableRecording ? 'bg-red-500/20' : 'bg-slate-700'}`}>
                            <Film className={`w-5 h-5 ${enableRecording ? 'text-red-400' : 'text-slate-500'}`} />
                          </div>
                          <div>
                            <p className="text-white font-medium">Enregistrer pour rediffusion</p>
                            <p className="text-slate-400 text-xs">Sauvegardez automatiquement votre live</p>
                          </div>
                        </div>
                        <div className={`relative w-12 h-6 rounded-full transition-colors ${enableRecording ? 'bg-red-500' : 'bg-slate-600'}`}>
                          <input type="checkbox" checked={enableRecording} onChange={(e) => setEnableRecording(e.target.checked)} className="sr-only" />
                          <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${enableRecording ? 'translate-x-7' : 'translate-x-1'}`} />
                        </div>
                      </label>
                    </div>
                    
                    <button onClick={getMediaDevices} disabled={isLoadingDevices} className="flex items-center gap-2 px-4 py-2 text-slate-400 hover:text-white transition-colors">
                      <RefreshCw className={`w-4 h-4 ${isLoadingDevices ? 'animate-spin' : ''}`} />
                      Actualiser les appareils
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-slate-700 flex justify-between items-center">
                <button onClick={handleClose} className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors">Annuler</button>
                <button onClick={goToPreview} disabled={!streamTitle.trim() || cameras.length === 0} className="px-8 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2">
                  <Eye className="w-5 h-5" />Prévisualiser
                </button>
              </div>
            </>
          )}

          {/* Preview Step */}
          {step === 'preview' && (
            <>
              <div className="p-6 border-b border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                    <Eye className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-white text-xl font-bold">Prévisualisation</h2>
                    <p className="text-slate-400 text-sm">Vérifiez votre caméra et microphone</p>
                  </div>
                </div>
                <button onClick={handleClose} className="p-2 text-slate-400 hover:text-white transition-colors"><X className="w-6 h-6" /></button>
              </div>

              <div className="p-6">
                <div className="grid lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <div className="relative aspect-video bg-slate-800 rounded-2xl overflow-hidden">
                      <video ref={videoPreviewRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                      <div className="absolute top-4 left-4 flex items-center gap-2">
                        <div className="px-3 py-1.5 bg-black/60 backdrop-blur-sm rounded-full flex items-center gap-2">
                          <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
                          <span className="text-white text-sm font-medium">Prévisualisation</span>
                        </div>
                        {enableRecording && (
                          <div className="px-3 py-1.5 bg-red-500/20 backdrop-blur-sm rounded-full flex items-center gap-2">
                            <Disc className="w-3 h-3 text-red-400" />
                            <span className="text-red-400 text-sm font-medium">Enregistrement activé</span>
                          </div>
                        )}
                      </div>
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="bg-black/60 backdrop-blur-sm rounded-xl p-4">
                          <h3 className="text-white font-bold text-lg">{streamTitle}</h3>
                          <p className="text-slate-300 text-sm">{selectedCategory}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center justify-center gap-4 mt-4">
                      <button className="p-4 rounded-full bg-slate-700 text-white hover:bg-slate-600 transition-all"><Mic className="w-6 h-6" /></button>
                      <button className="p-4 rounded-full bg-slate-700 text-white hover:bg-slate-600 transition-all"><Video className="w-6 h-6" /></button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-slate-800 rounded-xl p-4">
                      <h4 className="text-white font-semibold mb-3">Résumé du Live</h4>
                      <div className="space-y-3 text-sm">
                        <div className="flex justify-between"><span className="text-slate-400">Titre</span><span className="text-white font-medium truncate ml-2 max-w-[150px]">{streamTitle}</span></div>
                        <div className="flex justify-between"><span className="text-slate-400">Catégorie</span><span className="text-white">{selectedCategory}</span></div>
                        <div className="flex justify-between"><span className="text-slate-400">Qualité</span><span className="text-white">{QUALITY_OPTIONS.find(q => q.value === quality)?.label}</span></div>
                        <div className="flex justify-between"><span className="text-slate-400">Produits</span><span className="text-white">{selectedProducts.length} sélectionnés</span></div>
                        <div className="flex justify-between"><span className="text-slate-400">Enregistrement</span><span className={enableRecording ? 'text-green-400' : 'text-slate-500'}>{enableRecording ? 'Activé' : 'Désactivé'}</span></div>
                      </div>
                    </div>
                    {selectedProducts.length > 0 && (
                      <div className="bg-slate-800 rounded-xl p-4">
                        <h4 className="text-white font-semibold mb-3 flex items-center gap-2"><Package className="w-4 h-4 text-slate-400" />Produits</h4>
                        <div className="flex gap-2 overflow-x-auto pb-2">
                          {selectedProducts.slice(0, 4).map(productId => {
                            const product = mockProducts.find(p => p.id === productId);
                            if (!product) return null;
                            return <div key={productId} className="flex-shrink-0 w-14 h-14 rounded-lg overflow-hidden"><img src={product.image} alt={product.name} className="w-full h-full object-cover" /></div>;
                          })}
                          {selectedProducts.length > 4 && <div className="flex-shrink-0 w-14 h-14 rounded-lg bg-slate-700 flex items-center justify-center"><span className="text-white text-sm font-medium">+{selectedProducts.length - 4}</span></div>}
                        </div>
                      </div>
                    )}
                    <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
                      <h4 className="text-blue-400 font-semibold mb-2 flex items-center gap-2"><Zap className="w-4 h-4" />Conseils</h4>
                      <ul className="text-slate-300 text-sm space-y-1">
                        <li>• Assurez-vous d'avoir un bon éclairage</li>
                        <li>• Testez votre connexion internet</li>
                        <li>• Préparez vos produits à portée de main</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-slate-700 flex justify-between items-center">
                <button onClick={() => { stopPreview(); setStep('setup'); }} className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors">Retour</button>
                <button onClick={handleStartLive} disabled={agoraLoading} className="px-8 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all disabled:opacity-50 flex items-center gap-2">
                  {agoraLoading ? <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />Connexion...</> : <><Radio className="w-5 h-5" />Démarrer le Live</>}
                </button>
              </div>
            </>
          )}

          {/* Live Step */}
          {step === 'live' && (
            <div className="h-full flex flex-col">
              <div className="p-4 border-b border-slate-700 flex items-center justify-between bg-slate-900/95 backdrop-blur-sm">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-red-500 rounded-full">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                    <span className="text-white text-sm font-bold">EN DIRECT</span>
                  </div>
                  {recordingState.isRecording && (
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-red-500/20 rounded-full">
                      <Disc className="w-3 h-3 text-red-400 animate-pulse" />
                      <span className="text-red-400 text-sm font-medium">REC</span>
                    </div>
                  )}
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-slate-300 flex items-center gap-1"><Users className="w-4 h-4" />{viewerCount} spectateurs</span>
                    <span className="text-slate-300 flex items-center gap-1"><Clock className="w-4 h-4" />{formatDuration(liveDuration)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {streamStats && (
                    <div className="hidden md:flex items-center gap-3 px-3 py-1.5 bg-slate-800 rounded-lg text-xs">
                      <span className="text-green-400 flex items-center gap-1"><Wifi className="w-3 h-3" />{Math.round(streamStats.bitrate / 1000)} Mbps</span>
                      <span className="text-slate-400">{streamStats.resolution}</span>
                      <span className="text-slate-400">{streamStats.frameRate} fps</span>
                    </div>
                  )}
                  <button 
                    onClick={handleEndLive} 
                    disabled={isEndingLive}
                    className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition-colors flex items-center gap-2 disabled:opacity-50"
                  >
                    {isEndingLive ? (
                      <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />Fin en cours...</>
                    ) : (
                      <><StopCircle className="w-4 h-4" />Terminer</>
                    )}
                  </button>
                </div>
              </div>

              <div className="flex-1 flex overflow-hidden">
                <div className="flex-1 relative bg-black">
                  <div ref={liveVideoRef} className="absolute inset-0 flex items-center justify-center" />
                  
                  {/* Flash Sale Button - Bottom Left */}
                  <div className="absolute bottom-24 left-4 z-10">
                    <button
                      onClick={() => setShowFlashSaleModal(true)}
                      disabled={selectedProducts.length === 0}
                      className="flex items-center gap-2 px-4 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Flame className="w-5 h-5" />
                      Vente Flash
                    </button>
                  </div>

                  {/* Active Flash Sales Display */}
                  {activeFlashSales.length > 0 && (
                    <div className="absolute bottom-24 right-4 z-10 w-72 space-y-2">
                      {activeFlashSales.map(flashSale => (
                        <div key={flashSale.id} className="relative">
                          <FlashSaleCountdown 
                            flashSale={flashSale} 
                            onEnd={() => {}} 
                          />
                          <button
                            onClick={() => user && endFlashSale(flashSale.id, user.id)}
                            className="absolute top-2 right-2 p-1 bg-black/40 rounded-full hover:bg-black/60 transition-colors"
                          >
                            <X className="w-3 h-3 text-white" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-3">
                    <button onClick={toggleMute} className={`p-4 rounded-full transition-all ${isMuted ? 'bg-red-500 text-white' : 'bg-white/20 backdrop-blur-sm text-white hover:bg-white/30'}`}>
                      {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                    </button>
                    <button onClick={toggleVideo} className={`p-4 rounded-full transition-all ${isVideoOff ? 'bg-red-500 text-white' : 'bg-white/20 backdrop-blur-sm text-white hover:bg-white/30'}`}>
                      {isVideoOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
                    </button>
                    <button onClick={isScreenSharing ? stopScreenShare : startScreenShare} className={`p-4 rounded-full transition-all ${isScreenSharing ? 'bg-blue-500 text-white' : 'bg-white/20 backdrop-blur-sm text-white hover:bg-white/30'}`}>
                      <Monitor className="w-6 h-6" />
                    </button>
                  </div>
                  <div className="absolute top-4 right-4 flex items-center gap-2">
                    <button onClick={() => setShowProducts(!showProducts)} className={`p-2 rounded-lg transition-all ${showProducts ? 'bg-orange-500 text-white' : 'bg-white/20 backdrop-blur-sm text-white'}`}><ShoppingBag className="w-5 h-5" /></button>
                    <button onClick={() => setShowChat(!showChat)} className={`p-2 rounded-lg transition-all ${showChat ? 'bg-purple-500 text-white' : 'bg-white/20 backdrop-blur-sm text-white'}`}><MessageSquare className="w-5 h-5" /></button>
                  </div>
                  <div className="absolute top-4 left-4"><div className="bg-black/60 backdrop-blur-sm rounded-xl px-4 py-2"><h3 className="text-white font-bold">{streamTitle}</h3></div></div>
                </div>

                {(showChat || showProducts) && (
                  <div className="w-80 bg-slate-900 border-l border-slate-700 flex flex-col">
                    {showProducts && selectedProducts.length > 0 && (
                      <div className={`${showChat ? 'h-1/3' : 'flex-1'} border-b border-slate-700 overflow-hidden`}>
                        <div className="p-3 border-b border-slate-700 flex items-center justify-between">
                          <h4 className="text-white font-semibold flex items-center gap-2"><ShoppingBag className="w-4 h-4 text-orange-400" />Produits ({selectedProducts.length})</h4>
                        </div>
                        <div className="p-3 overflow-y-auto h-[calc(100%-48px)]">
                          <div className="space-y-2">
                            {selectedProducts.map(productId => {
                              const product = mockProducts.find(p => p.id === productId);
                              if (!product) return null;
                              const activeFlashSale = activeFlashSales.find(fs => fs.product_id === productId);
                              return (
                                <div key={productId} className={`flex items-center gap-3 p-2 rounded-lg ${activeFlashSale ? 'bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30' : 'bg-slate-800'}`}>
                                  <img src={product.image} alt={product.name} className="w-12 h-12 rounded-lg object-cover" />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-white text-sm font-medium truncate">{product.name}</p>
                                    {activeFlashSale ? (
                                      <div className="flex items-center gap-2">
                                        <p className="text-orange-400 text-sm font-bold">{formatPrice(activeFlashSale.flash_price)}</p>
                                        <span className="text-slate-500 text-xs line-through">{formatPrice(product.price)}</span>
                                        <span className="bg-orange-500 px-1 py-0.5 rounded text-white text-[10px] font-bold">-{activeFlashSale.discount_percent}%</span>
                                      </div>
                                    ) : (
                                      <p className="text-orange-400 text-sm font-bold">{formatPrice(product.price)}</p>
                                    )}
                                  </div>
                                  {activeFlashSale && <Flame className="w-4 h-4 text-orange-400 animate-pulse" />}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}
                    {showChat && currentLiveId && (
                      <div className="flex-1 overflow-hidden">
                        <LiveChat streamId={currentLiveId} isStreamOwner={true} />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {agoraError && (
            <div className="absolute bottom-4 left-4 right-4 p-4 bg-red-500/20 border border-red-500/50 rounded-xl flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
              <p className="text-red-300 text-sm">{agoraError}</p>
            </div>
          )}
        </div>
      </div>

      {/* Flash Sale Modal */}
      {showFlashSaleModal && currentLiveId && user && (
        <FlashSaleModal
          isOpen={showFlashSaleModal}
          onClose={() => setShowFlashSaleModal(false)}
          products={liveProducts}
          streamId={currentLiveId}
          sellerId={user.id}
          onCreateFlashSale={createFlashSale}
          isLoading={flashSaleLoading}
        />
      )}
    </>
  );
};

export default GoLiveModal;
