import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useSocialSharing, SocialAccount } from '@/hooks/useSocialSharing';
import { 
  Share2, 
  Instagram, 
  Twitter, 
  Facebook, 
  Youtube, 
  Check, 
  Plus, 
  X, 
  Calendar as CalendarIcon,
  Clock,
  Sparkles,
  ExternalLink,
  Loader2,
  Hash,
  AlertCircle
} from 'lucide-react';
import { format } from 'date-fns';

interface SocialShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  clip: {
    id: string;
    title: string;
    thumbnail_url?: string;
    duration?: number;
  };
}

const platformIcons: Record<string, React.ReactNode> = {
  instagram: <Instagram className="h-5 w-5" />,
  tiktok: (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
    </svg>
  ),
  facebook: <Facebook className="h-5 w-5" />,
  twitter: <Twitter className="h-5 w-5" />,
  youtube: <Youtube className="h-5 w-5" />
};

const platformColors: Record<string, string> = {
  instagram: 'bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500',
  tiktok: 'bg-black',
  facebook: 'bg-blue-600',
  twitter: 'bg-sky-500',
  youtube: 'bg-red-600'
};

const platformNames: Record<string, string> = {
  instagram: 'Instagram',
  tiktok: 'TikTok',
  facebook: 'Facebook',
  twitter: 'Twitter/X',
  youtube: 'YouTube'
};

export function SocialShareModal({ isOpen, onClose, clip }: SocialShareModalProps) {
  const { 
    accounts, 
    loading, 
    suggestedHashtags,
    connectAccount, 
    shareClip, 
    getSuggestedHashtags 
  } = useSocialSharing();

  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [captions, setCaptions] = useState<Record<string, string>>({});
  const [hashtags, setHashtags] = useState<Record<string, string[]>>({});
  const [newHashtag, setNewHashtag] = useState('');
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledDate, setScheduledDate] = useState<Date>();
  const [scheduledTime, setScheduledTime] = useState('12:00');
  const [sharing, setSharing] = useState(false);
  const [shareResults, setShareResults] = useState<Record<string, { success: boolean; url?: string; error?: string }>>({});
  const [activeTab, setActiveTab] = useState('select');
  const [connectingPlatform, setConnectingPlatform] = useState<string | null>(null);

  // Get connected platforms
  const connectedPlatforms = accounts.filter(a => a.is_connected);
  const availablePlatforms = ['instagram', 'tiktok', 'facebook', 'twitter', 'youtube'];

  useEffect(() => {
    if (isOpen) {
      // Initialize captions with clip title
      const initialCaptions: Record<string, string> = {};
      const initialHashtags: Record<string, string[]> = {};
      availablePlatforms.forEach(p => {
        initialCaptions[p] = clip.title || '';
        initialHashtags[p] = [];
      });
      setCaptions(initialCaptions);
      setHashtags(initialHashtags);
      setSelectedPlatforms([]);
      setShareResults({});
      setActiveTab('select');
    }
  }, [isOpen, clip.title]);

  const togglePlatform = (platform: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platform) 
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  const handleConnectAccount = async (platform: string) => {
    setConnectingPlatform(platform);
    try {
      // Simulate OAuth flow - in production, this would open OAuth popup
      await connectAccount(platform as SocialAccount['platform'], {
        account_name: `My ${platformNames[platform]}`,
        account_handle: `@myaccount_${platform}`,
        follower_count: Math.floor(Math.random() * 50000) + 1000
      });
    } finally {
      setConnectingPlatform(null);
    }
  };

  const handleGetSuggestions = async (platform: string) => {
    await getSuggestedHashtags(platform, undefined, clip.title?.split(' '));
  };

  const addHashtag = (platform: string, tag: string) => {
    const cleanTag = tag.startsWith('#') ? tag : `#${tag}`;
    if (!hashtags[platform]?.includes(cleanTag)) {
      setHashtags(prev => ({
        ...prev,
        [platform]: [...(prev[platform] || []), cleanTag]
      }));
    }
  };

  const removeHashtag = (platform: string, tag: string) => {
    setHashtags(prev => ({
      ...prev,
      [platform]: prev[platform]?.filter(t => t !== tag) || []
    }));
  };

  const handleShare = async () => {
    if (selectedPlatforms.length === 0) return;

    setSharing(true);
    const results: Record<string, { success: boolean; url?: string; error?: string }> = {};

    for (const platform of selectedPlatforms) {
      const account = connectedPlatforms.find(a => a.platform === platform);
      if (!account) continue;

      try {
        const scheduledFor = isScheduled && scheduledDate 
          ? new Date(`${format(scheduledDate, 'yyyy-MM-dd')}T${scheduledTime}`).toISOString()
          : undefined;

        const share = await shareClip(
          clip.id,
          platform,
          account.id,
          captions[platform] || clip.title,
          hashtags[platform] || [],
          scheduledFor
        );

        results[platform] = { 
          success: true, 
          url: share?.post_url 
        };
      } catch (error: any) {
        results[platform] = { 
          success: false, 
          error: error.message 
        };
      }
    }

    setShareResults(results);
    setSharing(false);
    setActiveTab('results');
  };

  const allShared = Object.keys(shareResults).length > 0 && 
    Object.values(shareResults).every(r => r.success);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5 text-primary" />
            Share to Social Media
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="select">Select Platforms</TabsTrigger>
            <TabsTrigger value="customize" disabled={selectedPlatforms.length === 0}>
              Customize
            </TabsTrigger>
            <TabsTrigger value="results" disabled={Object.keys(shareResults).length === 0}>
              Results
            </TabsTrigger>
          </TabsList>

          {/* Platform Selection Tab */}
          <TabsContent value="select" className="space-y-4">
            {/* Clip Preview */}
            <Card>
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <div className="w-32 h-20 bg-gray-200 dark:bg-gray-700 rounded-lg overflow-hidden flex-shrink-0">
                    {clip.thumbnail_url ? (
                      <img 
                        src={clip.thumbnail_url} 
                        alt={clip.title} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-400">
                        No Preview
                      </div>
                    )}
                  </div>
                  <div>
                    <h4 className="font-medium">{clip.title}</h4>
                    {clip.duration && (
                      <p className="text-sm text-muted-foreground">
                        Duration: {Math.floor(clip.duration / 60)}:{(clip.duration % 60).toString().padStart(2, '0')}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Connected Accounts */}
            <div className="space-y-3">
              <h4 className="font-medium">Connected Accounts</h4>
              {connectedPlatforms.length > 0 ? (
                <div className="grid grid-cols-1 gap-2">
                  {connectedPlatforms.map(account => (
                    <div 
                      key={account.id}
                      onClick={() => togglePlatform(account.platform)}
                      className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedPlatforms.includes(account.platform)
                          ? 'border-primary bg-primary/5'
                          : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full ${platformColors[account.platform]} flex items-center justify-center text-white`}>
                          {platformIcons[account.platform]}
                        </div>
                        <div>
                          <p className="font-medium">{account.account_name}</p>
                          <p className="text-sm text-muted-foreground">
                            {account.account_handle} • {account.follower_count?.toLocaleString()} followers
                          </p>
                        </div>
                      </div>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        selectedPlatforms.includes(account.platform)
                          ? 'border-primary bg-primary text-white'
                          : 'border-gray-300'
                      }`}>
                        {selectedPlatforms.includes(account.platform) && <Check className="h-4 w-4" />}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No accounts connected yet.</p>
              )}
            </div>

            {/* Connect New Account */}
            <div className="space-y-3">
              <h4 className="font-medium">Connect More Accounts</h4>
              <div className="flex flex-wrap gap-2">
                {availablePlatforms
                  .filter(p => !connectedPlatforms.some(a => a.platform === p))
                  .map(platform => (
                    <Button
                      key={platform}
                      variant="outline"
                      size="sm"
                      onClick={() => handleConnectAccount(platform)}
                      disabled={connectingPlatform === platform}
                      className="gap-2"
                    >
                      {connectingPlatform === platform ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        platformIcons[platform]
                      )}
                      {platformNames[platform]}
                      <Plus className="h-3 w-3" />
                    </Button>
                  ))}
              </div>
            </div>

            {/* Schedule Option */}
            <div className="space-y-3 pt-4 border-t">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  <Label>Schedule for later</Label>
                </div>
                <Switch checked={isScheduled} onCheckedChange={setIsScheduled} />
              </div>

              {isScheduled && (
                <div className="flex gap-3">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="flex-1 justify-start">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {scheduledDate ? format(scheduledDate, 'PPP') : 'Pick a date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={scheduledDate}
                        onSelect={setScheduledDate}
                        initialFocus
                        disabled={(date) => date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <Input
                      type="time"
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                      className="w-32"
                    />
                  </div>
                </div>
              )}
            </div>

            <Button 
              className="w-full" 
              disabled={selectedPlatforms.length === 0}
              onClick={() => setActiveTab('customize')}
            >
              Continue to Customize
            </Button>
          </TabsContent>

          {/* Customize Tab */}
          <TabsContent value="customize" className="space-y-4">
            {selectedPlatforms.map(platform => {
              const account = connectedPlatforms.find(a => a.platform === platform);
              return (
                <Card key={platform}>
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full ${platformColors[platform]} flex items-center justify-center text-white`}>
                        {platformIcons[platform]}
                      </div>
                      <div>
                        <p className="font-medium">{platformNames[platform]}</p>
                        <p className="text-xs text-muted-foreground">{account?.account_handle}</p>
                      </div>
                    </div>

                    {/* Caption */}
                    <div className="space-y-2">
                      <Label>Caption</Label>
                      <Textarea
                        value={captions[platform] || ''}
                        onChange={(e) => setCaptions(prev => ({ ...prev, [platform]: e.target.value }))}
                        placeholder="Write a caption..."
                        rows={3}
                        maxLength={platform === 'twitter' ? 280 : 2200}
                      />
                      <p className="text-xs text-muted-foreground text-right">
                        {(captions[platform] || '').length} / {platform === 'twitter' ? 280 : 2200}
                      </p>
                    </div>

                    {/* Hashtags */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="flex items-center gap-1">
                          <Hash className="h-3 w-3" />
                          Hashtags
                        </Label>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => handleGetSuggestions(platform)}
                          className="text-xs gap-1"
                        >
                          <Sparkles className="h-3 w-3" />
                          Get Suggestions
                        </Button>
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {hashtags[platform]?.map(tag => (
                          <Badge key={tag} variant="secondary" className="gap-1">
                            {tag}
                            <X 
                              className="h-3 w-3 cursor-pointer hover:text-destructive" 
                              onClick={() => removeHashtag(platform, tag)}
                            />
                          </Badge>
                        ))}
                      </div>

                      <div className="flex gap-2">
                        <Input
                          placeholder="Add hashtag..."
                          value={newHashtag}
                          onChange={(e) => setNewHashtag(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && newHashtag) {
                              addHashtag(platform, newHashtag);
                              setNewHashtag('');
                            }
                          }}
                        />
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => {
                            if (newHashtag) {
                              addHashtag(platform, newHashtag);
                              setNewHashtag('');
                            }
                          }}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>

                      {/* Suggested Hashtags */}
                      {suggestedHashtags.length > 0 && (
                        <div className="space-y-1">
                          <p className="text-xs text-muted-foreground">Suggested:</p>
                          <div className="flex flex-wrap gap-1">
                            {suggestedHashtags.slice(0, 10).map(tag => (
                              <Badge 
                                key={tag} 
                                variant="outline" 
                                className="cursor-pointer hover:bg-primary/10"
                                onClick={() => addHashtag(platform, tag)}
                              >
                                {tag}
                                <Plus className="h-2 w-2 ml-1" />
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setActiveTab('select')} className="flex-1">
                Back
              </Button>
              <Button 
                onClick={handleShare} 
                disabled={sharing}
                className="flex-1 gap-2"
              >
                {sharing ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Sharing...
                  </>
                ) : isScheduled ? (
                  <>
                    <CalendarIcon className="h-4 w-4" />
                    Schedule Posts
                  </>
                ) : (
                  <>
                    <Share2 className="h-4 w-4" />
                    Share Now
                  </>
                )}
              </Button>
            </div>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-4">
            <div className="text-center py-4">
              {allShared ? (
                <div className="space-y-2">
                  <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-lg font-semibold">
                    {isScheduled ? 'Posts Scheduled!' : 'Shared Successfully!'}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Your clip has been {isScheduled ? 'scheduled for' : 'shared to'} {selectedPlatforms.length} platform{selectedPlatforms.length > 1 ? 's' : ''}.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="w-16 h-16 rounded-full bg-yellow-100 dark:bg-yellow-900/30 flex items-center justify-center mx-auto">
                    <AlertCircle className="h-8 w-8 text-yellow-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Partial Success</h3>
                  <p className="text-sm text-muted-foreground">
                    Some posts may have failed. Check the details below.
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              {Object.entries(shareResults).map(([platform, result]) => (
                <div 
                  key={platform}
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    result.success 
                      ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20'
                      : 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full ${platformColors[platform]} flex items-center justify-center text-white`}>
                      {platformIcons[platform]}
                    </div>
                    <div>
                      <p className="font-medium">{platformNames[platform]}</p>
                      {result.success ? (
                        <p className="text-xs text-green-600 dark:text-green-400">
                          {isScheduled ? 'Scheduled' : 'Published'}
                        </p>
                      ) : (
                        <p className="text-xs text-red-600 dark:text-red-400">
                          {result.error || 'Failed to share'}
                        </p>
                      )}
                    </div>
                  </div>
                  {result.success && result.url && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => window.open(result.url, '_blank')}
                      className="gap-1"
                    >
                      View
                      <ExternalLink className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            <Button onClick={onClose} className="w-full">
              Done
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
