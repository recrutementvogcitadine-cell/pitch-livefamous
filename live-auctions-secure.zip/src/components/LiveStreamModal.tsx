import React, { useState, useEffect } from 'react';
import { 
  X, Users, Heart, Share2, 
  CheckCircle, Volume2, VolumeX, Maximize2, 
  MessageCircle, Package, Star, Phone, ShoppingBag,
  ChevronDown, ChevronUp, Flame, Clock
} from 'lucide-react';
import { formatPrice, LiveStream } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { useFlashSales, FlashSale } from '@/hooks/useFlashSales';
import OrderFormModal from './OrderFormModal';
import RealtimeLiveChat from './RealtimeLiveChat';
import FollowButton from './FollowButton';
import AuthModal from './AuthModal';


interface LiveStreamModalProps {
  isOpen: boolean;
  onClose: () => void;
  stream: LiveStream | null;
}

interface StreamProduct {
  id: string;
  product_id: string;
  product_name: string;
  product_price: number;
  product_image?: string;
  product_original_price?: number;
  is_highlighted: boolean;
  units_sold: number;
}

// Flash Sale Viewer Display Component
const FlashSaleViewerDisplay: React.FC<{ flashSale: FlashSale; onOrder: (flashSale: FlashSale) => void }> = ({ flashSale, onOrder }) => {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const end = new Date(flashSale.ends_at).getTime();
      return Math.max(0, Math.floor((end - now) / 1000));
    };

    setTimeLeft(calculateTimeLeft());
    const interval = setInterval(() => {
      const remaining = calculateTimeLeft();
      setTimeLeft(remaining);
      if (remaining <= 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [flashSale.ends_at]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  if (timeLeft <= 0) return null;

  return (
    <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-xl p-3 mb-3 shadow-lg shadow-orange-500/30">
      <div className="flex items-center gap-2 mb-2">
        <Flame className="w-5 h-5 text-white animate-bounce" />
        <span className="text-white font-bold">VENTE FLASH</span>
        <div className="ml-auto flex items-center gap-1 bg-white/20 px-2 py-1 rounded-lg">
          <Clock className="w-3 h-3 text-white" />
          <span className="text-white font-mono font-bold text-sm">
            {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
          </span>
        </div>
      </div>
      <div className="flex items-center gap-3">
        {flashSale.product_image && (
          <img src={flashSale.product_image} alt="" className="w-14 h-14 rounded-lg object-cover border-2 border-white/30" />
        )}
        <div className="flex-1 min-w-0">
          <p className="text-white font-medium text-sm truncate">{flashSale.product_name}</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-white font-bold text-lg">{formatPrice(flashSale.flash_price)}</span>
            <span className="text-white/60 text-sm line-through">{formatPrice(flashSale.original_price)}</span>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <span className="bg-white text-orange-500 px-2 py-0.5 rounded-full text-xs font-bold">-{flashSale.discount_percent}%</span>
            {flashSale.max_units && (
              <span className="text-white/80 text-xs">{flashSale.max_units - flashSale.units_sold} restants</span>
            )}
          </div>
        </div>
      </div>
      {flashSale.max_units && (
        <div className="mt-2">
          <div className="h-2 bg-white/20 rounded-full overflow-hidden">
            <div 
              className="h-full bg-white rounded-full transition-all"
              style={{ width: `${(flashSale.units_sold / flashSale.max_units) * 100}%` }}
            />
          </div>
        </div>
      )}
      <button
        onClick={() => onOrder(flashSale)}
        className="w-full mt-3 py-2.5 bg-white text-orange-500 font-bold rounded-lg hover:bg-white/90 transition-all flex items-center justify-center gap-2"
      >
        <ShoppingBag className="w-4 h-4" />
        Commander maintenant
      </button>
    </div>
  );
};

const LiveStreamModal: React.FC<LiveStreamModalProps> = ({ isOpen, onClose, stream }) => {
  const { user } = useAuth();
  const [products, setProducts] = useState<StreamProduct[]>([]);
  const [viewerCount, setViewerCount] = useState(stream?.viewers || 0);
  const [isMuted, setIsMuted] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [showProducts, setShowProducts] = useState(true);
  const [highlightedProduct, setHighlightedProduct] = useState<StreamProduct | null>(null);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [selectedProductForOrder, setSelectedProductForOrder] = useState<any>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isProductsExpanded, setIsProductsExpanded] = useState(false);

  // Default seller phone for demo
  const sellerPhone = '+2250700000000';

  // Check if current user is the stream owner
  const isStreamOwner = user?.id === stream?.seller?.id;

  // Mock stream ID for demo (in production, this would come from the stream object)
  const streamId = stream?.id || 'demo-stream-1';

  // Flash sales hook
  const { activeFlashSales, recordPurchase } = useFlashSales(streamId);

  // Mock products for demo
  const mockProducts: StreamProduct[] = [
    { id: '1', product_id: '1', product_name: 'iPhone 15 Pro Max', product_price: 850000, product_original_price: 950000, product_image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', is_highlighted: true, units_sold: 12 },
    { id: '2', product_id: '2', product_name: 'Samsung Galaxy S24 Ultra', product_price: 750000, product_image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400', is_highlighted: false, units_sold: 8 },
    { id: '3', product_id: '3', product_name: 'AirPods Pro 2', product_price: 180000, product_original_price: 220000, product_image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=400', is_highlighted: false, units_sold: 25 },
    { id: '4', product_id: '4', product_name: 'MacBook Air M3', product_price: 1200000, product_image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400', is_highlighted: false, units_sold: 3 },
  ];

  useEffect(() => {
    if (isOpen && stream) {
      setProducts(mockProducts);
      setHighlightedProduct(mockProducts.find(p => p.is_highlighted) || null);
      setViewerCount(stream.viewers);

      document.body.style.overflow = 'hidden';

      const interval = setInterval(() => {
        setViewerCount(prev => Math.max(1, prev + Math.floor(Math.random() * 10) - 3));
      }, 5000);

      return () => {
        clearInterval(interval);
        document.body.style.overflow = '';
      };
    }
  }, [isOpen, stream]);

  const handleWhatsApp = (product: StreamProduct) => {
    const message = `Bonjour, je suis intéressé(e) par "${product.product_name}" à ${formatPrice(product.product_price)} vu sur votre live. Est-il toujours disponible ?`;
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${sellerPhone}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
    toast({
      title: "Redirection vers WhatsApp",
      description: `Vous allez contacter ${stream?.seller.name}`,
    });
  };

  const handleCall = () => {
    window.location.href = `tel:${sellerPhone}`;
    toast({
      title: "Appel en cours",
      description: `Appel vers ${stream?.seller.name}`,
    });
  };

  const handleOrder = (product: StreamProduct) => {
    if (!user) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour passer une commande",
        variant: "destructive"
      });
      setShowAuthModal(true);
      return;
    }

    setSelectedProductForOrder({
      id: product.product_id,
      name: product.product_name,
      price: product.product_price,
      originalPrice: product.product_original_price,
      image: product.product_image || '',
      seller: stream?.seller.name || 'Vendeur',
      sellerPhone: sellerPhone
    });
    setShowOrderModal(true);
  };

  const handleFlashSaleOrder = async (flashSale: FlashSale) => {
    if (!user) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour profiter de cette vente flash",
        variant: "destructive"
      });
      setShowAuthModal(true);
      return;
    }

    try {
      // Record the purchase
      await recordPurchase(flashSale.id);
      
      setSelectedProductForOrder({
        id: flashSale.product_id,
        name: flashSale.product_name,
        price: flashSale.flash_price,
        originalPrice: flashSale.original_price,
        image: flashSale.product_image || '',
        seller: stream?.seller.name || 'Vendeur',
        sellerPhone: sellerPhone,
        isFlashSale: true,
        discountPercent: flashSale.discount_percent
      });
      setShowOrderModal(true);
    } catch (err: any) {
      toast({
        title: "Erreur",
        description: err.message || "Impossible de passer la commande",
        variant: "destructive"
      });
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: stream?.title,
        text: `Regardez ce live sur PITCH: ${stream?.title}`,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Lien copié!",
        description: "Le lien du live a été copié dans le presse-papier"
      });
    }
  };


  if (!isOpen || !stream) return null;

  return (
    <>
      {/* Main Modal Overlay */}
      <div 
        className="fixed inset-0 z-[9999] bg-black"
        style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
      >
        {/* Mobile Layout (column) / Desktop Layout (row) */}
        <div className="h-full w-full flex flex-col lg:flex-row">
          
          {/* Video Section */}
          <div className="relative flex-1 min-h-0 lg:min-h-full bg-black">
            {/* Header Overlay */}
            <div className="absolute top-0 left-0 right-0 z-20 p-3 md:p-4 bg-gradient-to-b from-black/90 via-black/50 to-transparent">
              <div className="flex items-center justify-between">
                {/* Seller Info */}
                <div className="flex items-center gap-2 md:gap-3">
                  <div className="relative flex-shrink-0">
                    <img 
                      src={stream.seller.avatar} 
                      alt={stream.seller.name}
                      className="w-10 h-10 md:w-12 md:h-12 rounded-full border-2 border-orange-500 object-cover"
                    />
                    {stream.seller.verified && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 md:w-5 md:h-5 bg-blue-500 rounded-full flex items-center justify-center border-2 border-black">
                        <CheckCircle className="w-2.5 h-2.5 md:w-3 md:h-3 text-white" />
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-white font-bold text-sm md:text-base truncate max-w-[120px] md:max-w-none">{stream.seller.name}</h3>
                      {stream.seller.verified && (
                        <span className="hidden md:inline px-2 py-0.5 bg-blue-500/20 text-blue-400 text-xs rounded-full">Vérifié</span>
                      )}
                    </div>
                    <p className="text-slate-400 text-xs md:text-sm truncate max-w-[150px] md:max-w-[250px]">{stream.title}</p>
                  </div>
                  
                  {/* Follow Button - Hidden on very small screens */}
                  <div className="hidden sm:block">
                    <FollowButton
                      sellerId={stream.seller.id}
                      sellerName={stream.seller.name}
                      variant="compact"
                      onAuthRequired={() => setShowAuthModal(true)}
                    />
                  </div>
                </div>

                {/* Right Side: Live Badge, Viewers, Close */}
                <div className="flex items-center gap-2">
                  {/* Live Badge */}
                  <div className="flex items-center gap-1.5 px-2 md:px-3 py-1 md:py-1.5 bg-red-500 rounded-full">
                    <span className="w-1.5 h-1.5 md:w-2 md:h-2 bg-white rounded-full animate-pulse"></span>
                    <span className="text-white text-xs md:text-sm font-bold">LIVE</span>
                  </div>

                  {/* Viewers */}
                  <div className="flex items-center gap-1.5 px-2 md:px-3 py-1 md:py-1.5 bg-white/10 backdrop-blur rounded-full">
                    <Users className="w-3 h-3 md:w-4 md:h-4 text-white" />
                    <span className="text-white text-xs md:text-sm font-medium">{viewerCount.toLocaleString()}</span>
                  </div>

                  {/* Close Button */}
                  <button
                    onClick={onClose}
                    className="p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
                  >
                    <X className="w-5 h-5 md:w-6 md:h-6 text-white" />
                  </button>
                </div>
              </div>
            </div>

            {/* Video Content */}
            <div className="absolute inset-0 flex items-center justify-center">
              <img 
                src={stream.thumbnail}
                alt={stream.title}
                className="w-full h-full object-cover opacity-60"
              />
              
              {/* Simulated video overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 md:w-24 md:h-24 bg-orange-500/20 rounded-full flex items-center justify-center mb-3 md:mb-4 animate-pulse">
                    <div className="w-10 h-10 md:w-16 md:h-16 bg-orange-500/40 rounded-full flex items-center justify-center">
                      <div className="w-5 h-5 md:w-8 md:h-8 bg-orange-500 rounded-full"></div>
                    </div>
                  </div>
                  <p className="text-white/60 text-xs md:text-sm">Live en cours...</p>
                </div>
              </div>
            </div>

            {/* Flash Sale Overlay - Visible on video */}
            {activeFlashSales.length > 0 && (
              <div className="absolute bottom-20 left-4 right-4 md:right-auto md:w-80 z-10">
                {activeFlashSales.slice(0, 1).map(flashSale => (
                  <FlashSaleViewerDisplay 
                    key={flashSale.id} 
                    flashSale={flashSale} 
                    onOrder={handleFlashSaleOrder}
                  />
                ))}
              </div>
            )}

            {/* Highlighted Product Overlay - Only on larger screens, hidden if flash sale active */}
            {highlightedProduct && activeFlashSales.length === 0 && (
              <div className="hidden lg:block absolute bottom-20 left-4 w-80 bg-black/90 backdrop-blur-lg rounded-2xl p-4 border border-orange-500/50 z-10">
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-4 h-4 text-orange-500" />
                  <span className="text-orange-500 text-sm font-medium">Produit en vedette</span>
                </div>
                <div className="flex gap-3">
                  <img 
                    src={highlightedProduct.product_image}
                    alt={highlightedProduct.product_name}
                    className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-semibold text-sm line-clamp-2">{highlightedProduct.product_name}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-orange-500 font-bold text-sm">{formatPrice(highlightedProduct.product_price)}</span>
                      {highlightedProduct.product_original_price && (
                        <span className="text-slate-500 text-xs line-through">{formatPrice(highlightedProduct.product_original_price)}</span>
                      )}
                    </div>
                    <p className="text-green-400 text-xs mt-1">{highlightedProduct.units_sold} vendus</p>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={() => handleWhatsApp(highlightedProduct)}
                    className="flex-1 py-2 bg-green-500/20 text-green-400 font-semibold rounded-xl hover:bg-green-500/30 transition-all flex items-center justify-center gap-1 text-xs"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    WhatsApp
                  </button>
                  <button
                    onClick={handleCall}
                    className="flex-1 py-2 bg-blue-500/20 text-blue-400 font-semibold rounded-xl hover:bg-blue-500/30 transition-all flex items-center justify-center gap-1 text-xs"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    Appeler
                  </button>
                  <button
                    onClick={() => handleOrder(highlightedProduct)}
                    className="flex-1 py-2 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-1 text-xs"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    Commander
                  </button>
                </div>
              </div>
            )}

            {/* Bottom Controls */}
            <div className="absolute bottom-3 md:bottom-4 left-3 md:left-4 right-3 md:right-4 flex items-center justify-between z-10">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-2 md:p-3 bg-black/50 backdrop-blur rounded-full hover:bg-black/70 transition-colors"
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4 md:w-5 md:h-5 text-white" />
                  ) : (
                    <Volume2 className="w-4 h-4 md:w-5 md:h-5 text-white" />
                  )}
                </button>
                <button className="p-2 md:p-3 bg-black/50 backdrop-blur rounded-full hover:bg-black/70 transition-colors">
                  <Maximize2 className="w-4 h-4 md:w-5 md:h-5 text-white" />
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsLiked(!isLiked)}
                  className={`p-2 md:p-3 rounded-full transition-all ${
                    isLiked 
                      ? 'bg-red-500 text-white' 
                      : 'bg-black/50 backdrop-blur text-white hover:bg-black/70'
                  }`}
                >
                  <Heart className={`w-4 h-4 md:w-5 md:h-5 ${isLiked ? 'fill-current' : ''}`} />
                </button>
                <button
                  onClick={handleShare}
                  className="p-2 md:p-3 bg-black/50 backdrop-blur rounded-full hover:bg-black/70 transition-colors"
                >
                  <Share2 className="w-4 h-4 md:w-5 md:h-5 text-white" />
                </button>
              </div>
            </div>
          </div>

          {/* Sidebar - Products & Chat */}
          <div className="w-full lg:w-96 bg-slate-900 flex flex-col border-t lg:border-t-0 lg:border-l border-slate-800 max-h-[50vh] lg:max-h-full">
            {/* Tabs */}
            <div className="flex border-b border-slate-800 flex-shrink-0">
              <button
                onClick={() => setShowProducts(false)}
                className={`flex-1 flex items-center justify-center gap-2 py-3 md:py-4 font-medium transition-colors ${
                  !showProducts ? 'text-orange-500 border-b-2 border-orange-500' : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageCircle className="w-4 h-4" />
                <span className="text-sm md:text-base">Chat</span>
              </button>
              <button
                onClick={() => setShowProducts(true)}
                className={`flex-1 flex items-center justify-center gap-2 py-3 md:py-4 font-medium transition-colors ${
                  showProducts ? 'text-orange-500 border-b-2 border-orange-500' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Package className="w-4 h-4" />
                <span className="text-sm md:text-base">Produits ({products.length})</span>
              </button>
            </div>

            {/* Mobile: Expand/Collapse Button */}
            <button 
              onClick={() => setIsProductsExpanded(!isProductsExpanded)}
              className="lg:hidden flex items-center justify-center gap-2 py-2 bg-slate-800/50 text-slate-400 hover:text-white transition-colors"
            >
              {isProductsExpanded ? (
                <>
                  <ChevronDown className="w-4 h-4" />
                  <span className="text-xs">Réduire</span>
                </>
              ) : (
                <>
                  <ChevronUp className="w-4 h-4" />
                  <span className="text-xs">Voir plus</span>
                </>
              )}
            </button>

            {/* Content Area */}
            <div className={`flex-1 overflow-hidden ${isProductsExpanded ? 'max-h-[60vh]' : 'max-h-[30vh] lg:max-h-full'}`}>
              {showProducts ? (
                /* Products List */
                <div className="h-full overflow-y-auto p-3 md:p-4 space-y-3">
                  {/* Flash Sales in Products Tab */}
                  {activeFlashSales.map(flashSale => (
                    <FlashSaleViewerDisplay 
                      key={flashSale.id} 
                      flashSale={flashSale} 
                      onOrder={handleFlashSaleOrder}
                    />
                  ))}
                  
                  {products.map((product) => {
                    // Check if this product has an active flash sale
                    const flashSale = activeFlashSales.find(fs => fs.product_id === product.product_id);
                    
                    return (
                      <div 
                        key={product.id}
                        className={`p-3 rounded-xl border transition-all ${
                          flashSale
                            ? 'bg-gradient-to-r from-orange-500/10 to-red-500/10 border-orange-500/50'
                            : product.is_highlighted 
                              ? 'bg-gradient-to-r from-orange-500/10 to-yellow-500/10 border-orange-500/50' 
                              : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                        }`}
                      >
                        {flashSale && (
                          <div className="flex items-center gap-1 mb-2">
                            <Flame className="w-3 h-3 text-orange-500 animate-pulse" />
                            <span className="text-orange-500 text-xs font-bold">VENTE FLASH -{flashSale.discount_percent}%</span>
                          </div>
                        )}
                        {!flashSale && product.is_highlighted && (
                          <div className="flex items-center gap-1 mb-2">
                            <Star className="w-3 h-3 text-orange-500" />
                            <span className="text-orange-500 text-xs font-medium">Produit en vedette</span>
                          </div>
                        )}
                        <div className="flex gap-3">
                          <img 
                            src={product.product_image}
                            alt={product.product_name}
                            className="w-14 h-14 md:w-16 md:h-16 rounded-lg object-cover flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-white font-medium text-xs md:text-sm line-clamp-2">{product.product_name}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              {flashSale ? (
                                <>
                                  <span className="text-orange-500 font-bold text-xs md:text-sm">{formatPrice(flashSale.flash_price)}</span>
                                  <span className="text-slate-500 text-xs line-through">{formatPrice(product.product_price)}</span>
                                </>
                              ) : (
                                <>
                                  <span className="text-orange-500 font-bold text-xs md:text-sm">{formatPrice(product.product_price)}</span>
                                  {product.product_original_price && (
                                    <span className="text-slate-500 text-xs line-through">{formatPrice(product.product_original_price)}</span>
                                  )}
                                </>
                              )}
                            </div>
                            <p className="text-green-400 text-xs mt-0.5">{product.units_sold} vendus</p>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <button
                            onClick={() => handleWhatsApp(product)}
                            className="flex-1 py-1.5 md:py-2 bg-green-500/20 text-green-400 font-semibold rounded-lg hover:bg-green-500/30 transition-all text-xs flex items-center justify-center gap-1"
                          >
                            <MessageCircle className="w-3 h-3 md:w-3.5 md:h-3.5" />
                            <span className="hidden sm:inline">WhatsApp</span>
                          </button>
                          <button
                            onClick={handleCall}
                            className="flex-1 py-1.5 md:py-2 bg-blue-500/20 text-blue-400 font-semibold rounded-lg hover:bg-blue-500/30 transition-all text-xs flex items-center justify-center gap-1"
                          >
                            <Phone className="w-3 h-3 md:w-3.5 md:h-3.5" />
                            <span className="hidden sm:inline">Appeler</span>
                          </button>
                          <button
                            onClick={() => flashSale ? handleFlashSaleOrder(flashSale) : handleOrder(product)}
                            className={`flex-1 py-1.5 md:py-2 font-semibold rounded-lg transition-all text-xs flex items-center justify-center gap-1 ${
                              flashSale 
                                ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white hover:shadow-lg hover:shadow-orange-500/30'
                                : 'bg-gradient-to-r from-orange-500 to-yellow-500 text-white hover:shadow-lg'
                            }`}
                          >
                            <ShoppingBag className="w-3 h-3 md:w-3.5 md:h-3.5" />
                            <span className="hidden sm:inline">{flashSale ? 'Profiter' : 'Commander'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* Chat - Using the RealtimeLiveChat component */
                <RealtimeLiveChat 
                  streamId={streamId} 
                  isStreamOwner={isStreamOwner}
                  sellerName={stream.seller.name}
                />
              )}

            </div>
          </div>
        </div>
      </div>

      {/* Order Form Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 z-[10000]">
          <OrderFormModal
            isOpen={showOrderModal}
            onClose={() => {
              setShowOrderModal(false);
              setSelectedProductForOrder(null);
            }}
            product={selectedProductForOrder}
            onOrderSuccess={(orderId) => {
              toast({
                title: "Commande passée!",
                description: `Votre commande ${orderId.slice(0, 8).toUpperCase()} a été enregistrée`
              });
            }}
          />
        </div>
      )}

      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 z-[10000]">
          <AuthModal 
            isOpen={showAuthModal} 
            onClose={() => setShowAuthModal(false)} 
          />
        </div>
      )}
    </>
  );
};

export default LiveStreamModal;
