import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useNotifications, NotificationPreferences } from '@/hooks/useNotifications';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Bell, 
  ShoppingBag, 
  XCircle, 
  MessageSquare, 
  Package, 
  Star, 
  UserPlus,
  Mail,
  Smartphone,
  Monitor,
  Loader2,
  Check,
  Settings
} from 'lucide-react';
import { toast } from 'sonner';

interface SellerNotificationSettingsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface NotificationCategory {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  mainKey: keyof NotificationPreferences;
  pushKey: keyof NotificationPreferences;
  emailKey: keyof NotificationPreferences;
  inAppKey: keyof NotificationPreferences;
  color: string;
}

const notificationCategories: NotificationCategory[] = [
  {
    id: 'new_order',
    title: 'Nouvelles commandes',
    description: 'Soyez alerté dès qu\'un acheteur passe une commande',
    icon: <ShoppingBag className="h-5 w-5" />,
    mainKey: 'seller_new_order_notifications',
    pushKey: 'seller_new_order_push',
    emailKey: 'seller_new_order_email',
    inAppKey: 'seller_new_order_in_app',
    color: 'bg-green-500'
  },
  {
    id: 'order_cancelled',
    title: 'Annulations de commandes',
    description: 'Recevez une alerte quand une commande est annulée',
    icon: <XCircle className="h-5 w-5" />,
    mainKey: 'seller_order_cancelled_notifications',
    pushKey: 'seller_order_cancelled_push',
    emailKey: 'seller_order_cancelled_email',
    inAppKey: 'seller_order_cancelled_in_app',
    color: 'bg-red-500'
  },
  {
    id: 'buyer_message',
    title: 'Messages des acheteurs',
    description: 'Notifications pour les nouveaux messages reçus',
    icon: <MessageSquare className="h-5 w-5" />,
    mainKey: 'seller_buyer_message_notifications',
    pushKey: 'seller_buyer_message_push',
    emailKey: 'seller_buyer_message_email',
    inAppKey: 'seller_buyer_message_in_app',
    color: 'bg-blue-500'
  },
  {
    id: 'low_stock',
    title: 'Stock faible',
    description: 'Alertes quand vos produits sont en rupture de stock',
    icon: <Package className="h-5 w-5" />,
    mainKey: 'seller_low_stock_notifications',
    pushKey: 'seller_low_stock_push',
    emailKey: 'seller_low_stock_email',
    inAppKey: 'seller_low_stock_in_app',
    color: 'bg-orange-500'
  },
  {
    id: 'review',
    title: 'Nouveaux avis',
    description: 'Soyez informé des avis laissés sur vos produits',
    icon: <Star className="h-5 w-5" />,
    mainKey: 'seller_review_notifications',
    pushKey: 'seller_review_push',
    emailKey: 'seller_review_email',
    inAppKey: 'seller_review_in_app',
    color: 'bg-yellow-500'
  },
  {
    id: 'new_follower',
    title: 'Nouveaux abonnés',
    description: 'Notifications quand quelqu\'un commence à vous suivre',
    icon: <UserPlus className="h-5 w-5" />,
    mainKey: 'seller_new_follower_notifications',
    pushKey: 'seller_new_follower_push',
    emailKey: 'seller_new_follower_email',
    inAppKey: 'seller_new_follower_in_app',
    color: 'bg-purple-500'
  }
];

export function SellerNotificationSettings({ open, onOpenChange }: SellerNotificationSettingsProps) {
  const { user } = useAuth();
  const { fetchPreferences, updatePreferences, loading } = useNotifications();
  const [prefs, setPrefs] = useState<Partial<NotificationPreferences>>({});
  const [saving, setSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  useEffect(() => {
    if (open && user?.id) {
      loadPreferences();
    }
  }, [open, user?.id]);

  const loadPreferences = async () => {
    if (!user?.id) return;
    try {
      const data = await fetchPreferences(user.id);
      setPrefs(data || {});
      setHasChanges(false);
    } catch (error) {
      console.error('Error loading preferences:', error);
    }
  };

  const handleToggle = (key: keyof NotificationPreferences, value: boolean) => {
    setPrefs(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    if (!user?.id) return;
    setSaving(true);
    try {
      await updatePreferences(user.id, prefs);
      toast.success('Préférences enregistrées', {
        description: 'Vos préférences de notification ont été mises à jour.'
      });
      setHasChanges(false);
    } catch (error) {
      toast.error('Erreur', {
        description: 'Impossible d\'enregistrer les préférences.'
      });
    } finally {
      setSaving(false);
    }
  };

  const toggleCategory = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
  };

  const getChannelStatus = (category: NotificationCategory) => {
    const channels = [];
    if (prefs[category.pushKey]) channels.push('Push');
    if (prefs[category.emailKey]) channels.push('Email');
    if (prefs[category.inAppKey]) channels.push('In-app');
    return channels;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="p-2 bg-gradient-to-br from-orange-500 to-pink-500 rounded-lg">
              <Bell className="h-5 w-5 text-white" />
            </div>
            <div>
              <span className="text-xl">Notifications Vendeur</span>
              <p className="text-sm font-normal text-muted-foreground mt-1">
                Configurez comment vous souhaitez être alerté
              </p>
            </div>
          </DialogTitle>
        </DialogHeader>

        {loading && !Object.keys(prefs).length ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-4 mt-4">
            {/* Channel Legend */}
            <div className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg text-sm">
              <div className="flex items-center gap-1.5">
                <Smartphone className="h-4 w-4 text-blue-500" />
                <span>Push</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Mail className="h-4 w-4 text-green-500" />
                <span>Email</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Monitor className="h-4 w-4 text-purple-500" />
                <span>In-app</span>
              </div>
            </div>

            {/* Notification Categories */}
            <div className="space-y-3">
              {notificationCategories.map((category) => {
                const isEnabled = prefs[category.mainKey] !== false;
                const isExpanded = expandedCategory === category.id;
                const activeChannels = getChannelStatus(category);

                return (
                  <div 
                    key={category.id}
                    className={`border rounded-lg transition-all ${
                      isEnabled ? 'border-border' : 'border-border/50 opacity-60'
                    }`}
                  >
                    {/* Main Toggle */}
                    <div 
                      className="p-4 flex items-center justify-between cursor-pointer"
                      onClick={() => toggleCategory(category.id)}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${category.color} text-white`}>
                          {category.icon}
                        </div>
                        <div>
                          <div className="font-medium flex items-center gap-2">
                            {category.title}
                            {isEnabled && activeChannels.length > 0 && (
                              <div className="flex gap-1">
                                {activeChannels.map(ch => (
                                  <Badge key={ch} variant="secondary" className="text-xs px-1.5 py-0">
                                    {ch}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {category.description}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Settings className={`h-4 w-4 text-muted-foreground transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                        <Switch
                          checked={isEnabled}
                          onCheckedChange={(checked) => handleToggle(category.mainKey, checked)}
                          onClick={(e) => e.stopPropagation()}
                        />
                      </div>
                    </div>

                    {/* Channel Options */}
                    {isExpanded && isEnabled && (
                      <div className="px-4 pb-4 pt-2 border-t bg-muted/30">
                        <p className="text-xs text-muted-foreground mb-3">
                          Choisissez comment recevoir ces notifications:
                        </p>
                        <div className="grid grid-cols-3 gap-3">
                          {/* Push */}
                          <div 
                            className={`p-3 rounded-lg border cursor-pointer transition-all ${
                              prefs[category.pushKey] 
                                ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/30' 
                                : 'border-border hover:border-blue-300'
                            }`}
                            onClick={() => handleToggle(category.pushKey, !prefs[category.pushKey])}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <Smartphone className={`h-5 w-5 ${prefs[category.pushKey] ? 'text-blue-500' : 'text-muted-foreground'}`} />
                              {prefs[category.pushKey] && <Check className="h-4 w-4 text-blue-500" />}
                            </div>
                            <p className="text-sm font-medium">Push</p>
                            <p className="text-xs text-muted-foreground">Notification instantanée</p>
                          </div>

                          {/* Email */}
                          <div 
                            className={`p-3 rounded-lg border cursor-pointer transition-all ${
                              prefs[category.emailKey] 
                                ? 'border-green-500 bg-green-50 dark:bg-green-950/30' 
                                : 'border-border hover:border-green-300'
                            }`}
                            onClick={() => handleToggle(category.emailKey, !prefs[category.emailKey])}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <Mail className={`h-5 w-5 ${prefs[category.emailKey] ? 'text-green-500' : 'text-muted-foreground'}`} />
                              {prefs[category.emailKey] && <Check className="h-4 w-4 text-green-500" />}
                            </div>
                            <p className="text-sm font-medium">Email</p>
                            <p className="text-xs text-muted-foreground">Reçu par email</p>
                          </div>

                          {/* In-app */}
                          <div 
                            className={`p-3 rounded-lg border cursor-pointer transition-all ${
                              prefs[category.inAppKey] 
                                ? 'border-purple-500 bg-purple-50 dark:bg-purple-950/30' 
                                : 'border-border hover:border-purple-300'
                            }`}
                            onClick={() => handleToggle(category.inAppKey, !prefs[category.inAppKey])}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <Monitor className={`h-5 w-5 ${prefs[category.inAppKey] ? 'text-purple-500' : 'text-muted-foreground'}`} />
                              {prefs[category.inAppKey] && <Check className="h-4 w-4 text-purple-500" />}
                            </div>
                            <p className="text-sm font-medium">In-app</p>
                            <p className="text-xs text-muted-foreground">Dans l'application</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <Separator />

            {/* Quick Actions */}
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const allOn: Partial<NotificationPreferences> = {};
                    notificationCategories.forEach(cat => {
                      allOn[cat.mainKey] = true;
                      allOn[cat.pushKey] = true;
                      allOn[cat.emailKey] = false;
                      allOn[cat.inAppKey] = true;
                    });
                    setPrefs(prev => ({ ...prev, ...allOn }));
                    setHasChanges(true);
                  }}
                >
                  Tout activer
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const allOff: Partial<NotificationPreferences> = {};
                    notificationCategories.forEach(cat => {
                      allOff[cat.mainKey] = false;
                    });
                    setPrefs(prev => ({ ...prev, ...allOff }));
                    setHasChanges(true);
                  }}
                >
                  Tout désactiver
                </Button>
              </div>

              <Button
                onClick={handleSave}
                disabled={!hasChanges || saving}
                className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
              >
                {saving ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Enregistrement...
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4 mr-2" />
                    Enregistrer
                  </>
                )}
              </Button>
            </div>

            {/* Info Box */}
            <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
              <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">
                Conseils pour les vendeurs
              </h4>
              <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                <li>• Activez les notifications push pour les nouvelles commandes afin de répondre rapidement</li>
                <li>• Les alertes de stock faible par email vous permettent de planifier vos réapprovisionnements</li>
                <li>• Répondre rapidement aux messages améliore votre taux de conversion</li>
              </ul>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
