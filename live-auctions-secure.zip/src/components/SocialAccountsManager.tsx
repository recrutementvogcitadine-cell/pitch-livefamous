import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useSocialSharing, SocialAccount } from '@/hooks/useSocialSharing';
import { 
  Settings, 
  Instagram, 
  Twitter, 
  Facebook, 
  Youtube, 
  Plus, 
  X, 
  Check, 
  Loader2,
  Link2,
  Unlink,
  RefreshCw,
  Users,
  ExternalLink,
  AlertCircle
} from 'lucide-react';

interface SocialAccountsManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

const platformIcons: Record<string, React.ReactNode> = {
  instagram: <Instagram className="h-5 w-5" />,
  tiktok: (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
    </svg>
  ),
  facebook: <Facebook className="h-5 w-5" />,
  twitter: <Twitter className="h-5 w-5" />,
  youtube: <Youtube className="h-5 w-5" />
};

const platformColors: Record<string, string> = {
  instagram: 'bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500',
  tiktok: 'bg-black',
  facebook: 'bg-blue-600',
  twitter: 'bg-sky-500',
  youtube: 'bg-red-600'
};

const platformNames: Record<string, string> = {
  instagram: 'Instagram',
  tiktok: 'TikTok',
  facebook: 'Facebook',
  twitter: 'Twitter/X',
  youtube: 'YouTube'
};

const platformDescriptions: Record<string, string> = {
  instagram: 'Share Reels and Stories',
  tiktok: 'Post short-form videos',
  facebook: 'Share to your page or profile',
  twitter: 'Post video tweets',
  youtube: 'Upload Shorts and videos'
};

export function SocialAccountsManager({ isOpen, onClose }: SocialAccountsManagerProps) {
  const { 
    accounts, 
    loading, 
    fetchAccounts,
    connectAccount, 
    disconnectAccount 
  } = useSocialSharing();

  const [connectingPlatform, setConnectingPlatform] = useState<string | null>(null);
  const [showConnectForm, setShowConnectForm] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    account_name: '',
    account_handle: ''
  });

  const availablePlatforms = ['instagram', 'tiktok', 'facebook', 'twitter', 'youtube'];
  const connectedPlatforms = accounts.filter(a => a.is_connected);
  const unconnectedPlatforms = availablePlatforms.filter(
    p => !connectedPlatforms.some(a => a.platform === p)
  );

  useEffect(() => {
    if (isOpen) {
      fetchAccounts();
    }
  }, [isOpen, fetchAccounts]);

  const handleConnect = async (platform: string) => {
    if (!formData.account_name) return;
    
    setConnectingPlatform(platform);
    try {
      await connectAccount(platform as SocialAccount['platform'], {
        account_name: formData.account_name,
        account_handle: formData.account_handle || `@${formData.account_name.toLowerCase().replace(/\s+/g, '')}`,
        follower_count: Math.floor(Math.random() * 50000) + 1000
      });
      setShowConnectForm(null);
      setFormData({ account_name: '', account_handle: '' });
    } finally {
      setConnectingPlatform(null);
    }
  };

  const handleDisconnect = async (accountId: string) => {
    if (!confirm('Are you sure you want to disconnect this account?')) return;
    await disconnectAccount(accountId);
  };

  const simulateOAuth = (platform: string) => {
    // In production, this would open the OAuth flow
    // For now, we show a form to simulate account connection
    setShowConnectForm(platform);
    setFormData({
      account_name: `My ${platformNames[platform]} Account`,
      account_handle: ''
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Settings className="h-5 w-5 text-purple-400" />
            Social Media Accounts
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Connected Accounts */}
          <div className="space-y-3">
            <h4 className="text-white font-medium flex items-center gap-2">
              <Link2 className="h-4 w-4 text-green-400" />
              Connected Accounts ({connectedPlatforms.length})
            </h4>
            
            {connectedPlatforms.length === 0 ? (
              <div className="text-center py-8 bg-slate-800/50 rounded-xl border border-slate-700">
                <Unlink className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No accounts connected</p>
                <p className="text-slate-500 text-sm">Connect your social media accounts to start sharing</p>
              </div>
            ) : (
              <div className="space-y-2">
                {connectedPlatforms.map(account => (
                  <Card key={account.id} className="bg-slate-800/50 border-slate-700">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-12 h-12 rounded-full ${platformColors[account.platform]} flex items-center justify-center text-white`}>
                            {platformIcons[account.platform]}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="text-white font-medium">{account.account_name}</p>
                              <Badge variant="outline" className="text-green-400 border-green-400/30 text-xs">
                                <Check className="h-3 w-3 mr-1" />
                                Connected
                              </Badge>
                            </div>
                            <p className="text-slate-400 text-sm">{account.account_handle}</p>
                            <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                              <span className="flex items-center gap-1">
                                <Users className="h-3 h-3" />
                                {account.follower_count?.toLocaleString()} followers
                              </span>
                              <span>
                                Connected {new Date(account.connected_at).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-slate-400 hover:text-white"
                            onClick={() => {
                              // Simulate refresh
                              fetchAccounts();
                            }}
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                            onClick={() => handleDisconnect(account.id)}
                          >
                            <Unlink className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Available Platforms */}
          {unconnectedPlatforms.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-white font-medium flex items-center gap-2">
                <Plus className="h-4 w-4 text-purple-400" />
                Connect New Account
              </h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {unconnectedPlatforms.map(platform => (
                  <Card 
                    key={platform} 
                    className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-colors cursor-pointer"
                    onClick={() => simulateOAuth(platform)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full ${platformColors[platform]} flex items-center justify-center text-white`}>
                          {platformIcons[platform]}
                        </div>
                        <div className="flex-1">
                          <p className="text-white font-medium">{platformNames[platform]}</p>
                          <p className="text-slate-500 text-xs">{platformDescriptions[platform]}</p>
                        </div>
                        <Plus className="h-5 w-5 text-slate-400" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Connect Form (Simulated OAuth) */}
          {showConnectForm && (
            <Card className="bg-slate-800 border-purple-500/50">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full ${platformColors[showConnectForm]} flex items-center justify-center text-white`}>
                    {platformIcons[showConnectForm]}
                  </div>
                  <div>
                    <p className="text-white font-medium">Connect {platformNames[showConnectForm]}</p>
                    <p className="text-slate-400 text-sm">Enter your account details</p>
                  </div>
                </div>

                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3 flex items-start gap-2">
                  <AlertCircle className="h-5 w-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="text-yellow-400 font-medium">Demo Mode</p>
                    <p className="text-yellow-400/80">In production, this would open the official {platformNames[showConnectForm]} OAuth flow for secure authentication.</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-slate-400 mb-1 block">Account Name</label>
                    <Input
                      value={formData.account_name}
                      onChange={(e) => setFormData(prev => ({ ...prev, account_name: e.target.value }))}
                      placeholder="Your account name"
                      className="bg-slate-900 border-slate-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-slate-400 mb-1 block">Handle (optional)</label>
                    <Input
                      value={formData.account_handle}
                      onChange={(e) => setFormData(prev => ({ ...prev, account_handle: e.target.value }))}
                      placeholder="@yourhandle"
                      className="bg-slate-900 border-slate-700 text-white"
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowConnectForm(null);
                      setFormData({ account_name: '', account_handle: '' });
                    }}
                    className="flex-1 border-slate-600"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => handleConnect(showConnectForm)}
                    disabled={!formData.account_name || connectingPlatform === showConnectForm}
                    className={`flex-1 ${platformColors[showConnectForm]} text-white`}
                  >
                    {connectingPlatform === showConnectForm ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Connecting...
                      </>
                    ) : (
                      <>
                        <Link2 className="h-4 w-4 mr-2" />
                        Connect
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Info */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <h5 className="text-white font-medium mb-2 flex items-center gap-2">
              <ExternalLink className="h-4 w-4 text-purple-400" />
              About Social Sharing
            </h5>
            <ul className="text-slate-400 text-sm space-y-1">
              <li>• Connected accounts allow you to share clips directly to social media</li>
              <li>• You can customize captions and hashtags for each platform</li>
              <li>• Schedule posts for optimal engagement times</li>
              <li>• Track analytics and performance across all platforms</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
