import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Aminata Koné',
      role: 'Acheteuse régulière',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
      content: 'J\'adore pouvoir contacter directement les vendeurs sur WhatsApp. J\'ai négocié un super prix pour mon téléphone et le vendeur était très réactif!',
      rating: 5,
      location: 'Abidjan'
    },
    {
      id: 2,
      name: 'Kouadio Marcel',
      role: 'Vendeur Pro',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
      content: 'Grâce à PITCH, je reçois des clients qualifiés qui me contactent directement. Les lives me permettent de montrer mes produits en détail.',
      rating: 5,
      location: 'Cocody'
    },
    {
      id: 3,
      name: 'Fatou Diallo',
      role: 'Acheteuse',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
      content: 'Le fait de pouvoir voir les produits en live avant de contacter le vendeur me rassure beaucoup. J\'ai fait plusieurs achats sans aucun problème.',
      rating: 5,
      location: 'Yopougon'
    },
    {
      id: 4,
      name: 'Ibrahim Touré',
      role: 'Vendeur',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop',
      content: 'La plateforme est simple et efficace. Les clients me contactent via WhatsApp, on discute, et on conclut la vente. Pas de commission à payer!',
      rating: 5,
      location: 'Marcory'
    },
    {
      id: 5,
      name: 'Marie Aka',
      role: 'Acheteuse fidèle',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop',
      content: 'J\'apprécie de pouvoir négocier les prix directement avec les vendeurs. C\'est comme au marché mais en version moderne!',
      rating: 5,
      location: 'Plateau'
    },
    {
      id: 6,
      name: 'Jean-Baptiste Koffi',
      role: 'Vendeur Premium',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop',
      content: 'Mes ventes ont augmenté de 200% depuis que je fais des lives. Les clients adorent voir les produits en action avant d\'acheter.',
      rating: 5,
      location: 'Treichville'
    }
  ];

  return (
    <section className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-red-500/10 text-red-500 rounded-full text-sm font-semibold mb-4">
            Témoignages
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ce que disent nos{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">
              utilisateurs
            </span>
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Découvrez les expériences de notre communauté d'acheteurs et de vendeurs
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700 hover:border-red-500/30 transition-all duration-300"
            >
              {/* Quote Icon */}
              <div className="mb-4">
                <Quote className="w-8 h-8 text-red-500/30" />
              </div>

              {/* Content */}
              <p className="text-slate-300 mb-6 leading-relaxed">
                "{testimonial.content}"
              </p>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                ))}
              </div>

              {/* Author */}
              <div className="flex items-center gap-3">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-red-500/30"
                />
                <div>
                  <h4 className="text-white font-semibold">{testimonial.name}</h4>
                  <p className="text-slate-400 text-sm">{testimonial.role} • {testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: '50K+', label: 'Transactions réussies' },
            { value: '4.8/5', label: 'Note moyenne' },
            { value: '500+', label: 'Vendeurs actifs' },
            { value: '15 min', label: 'Temps de réponse moyen' },
          ].map((stat, index) => (
            <div key={index} className="text-center p-6 bg-slate-800/30 rounded-2xl border border-slate-700">
              <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600 mb-2">
                {stat.value}
              </div>
              <div className="text-slate-400 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
