import React, { useState, useEffect } from 'react';
import { 
  X, Shield, CheckCircle, XCircle, Clock, Eye, Search, Filter, Loader2, 
  AlertCircle, Users, Package, ShoppingCart, TrendingUp, Ban, UserCheck,
  Tag, FileText, Download, ChevronLeft, ChevronRight, MoreVertical,
  Plus, Edit2, Trash2, BarChart3, Activity, DollarSign, Store,
  Smartphone, Shirt, Sparkles, Home, Footprints, Gem, Car, Dumbbell,
  Percent, Gift, Calendar, Hash, ToggleLeft, ToggleRight, Copy, Ticket,
  Bell, Send, BellRing
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useAdmin, AdminUser, AdminProduct, AdminCategory, ActivityLog, PromoCode, PromoCodeFormData } from '@/hooks/useAdmin';
import { useNotifications } from '@/hooks/useNotifications';
import { formatPrice } from '@/data/mockData';


interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

type TabType = 'dashboard' | 'users' | 'products' | 'categories' | 'promotions' | 'reports';

const iconMap: Record<string, React.ReactNode> = {
  'Smartphone': <Smartphone className="w-5 h-5" />,
  'Shirt': <Shirt className="w-5 h-5" />,
  'Sparkles': <Sparkles className="w-5 h-5" />,
  'Home': <Home className="w-5 h-5" />,
  'Footprints': <Footprints className="w-5 h-5" />,
  'Gem': <Gem className="w-5 h-5" />,
  'Car': <Car className="w-5 h-5" />,
  'Dumbbell': <Dumbbell className="w-5 h-5" />,
};

const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose }) => {
  const { user, profile } = useAuth();
  const {
    loading, statistics, users, products, categories, activityLogs, promoCodes, pagination,
    fetchStatistics, fetchUsers, banUser, unbanUser, verifySeller, unverifySeller,
    fetchProductsForModeration, moderateProduct, fetchCategories, createCategory,
    updateCategory, deleteCategory, fetchActivityLogs, exportReport,
    fetchPromoCodes, createPromoCode, updatePromoCode, togglePromoCode, deletePromoCode
  } = useAdmin();

  const { notifyPromoCode, broadcastNotification } = useNotifications();

  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [userFilter, setUserFilter] = useState({ type: 'all', status: 'all' });
  const [productFilter, setProductFilter] = useState('all');
  const [promoFilter, setPromoFilter] = useState('all');
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<AdminProduct | null>(null);
  const [selectedPromoCode, setSelectedPromoCode] = useState<PromoCode | null>(null);
  const [showBanModal, setShowBanModal] = useState(false);
  const [showModerationModal, setShowModerationModal] = useState(false);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showPromoModal, setShowPromoModal] = useState(false);
  const [showPromoStatsModal, setShowPromoStatsModal] = useState(false);
  const [showNotifyModal, setShowNotifyModal] = useState(false);
  const [banReason, setBanReason] = useState('');
  const [moderationNotes, setModerationNotes] = useState('');
  const [editingCategory, setEditingCategory] = useState<AdminCategory | null>(null);
  const [categoryForm, setCategoryForm] = useState({ name: '', slug: '', icon: 'Tag', description: '' });
  const [reportDateRange, setReportDateRange] = useState({ start: '', end: '' });
  const [processing, setProcessing] = useState(false);
  const [notificationSent, setNotificationSent] = useState(false);
  
  // Promo code form
  const [promoForm, setPromoForm] = useState<PromoCodeFormData>({
    code: '',
    description: '',
    discountType: 'percentage',
    discountValue: 10,
    minPurchaseAmount: 0,
    maxUses: undefined,
    startDate: '',
    endDate: '',
    categoryRestrictions: [],
    sellerRestrictions: []
  });


  const isAdmin = profile?.user_type === 'admin';

  useEffect(() => {
    if (isOpen && isAdmin) {
      fetchStatistics();
    }
  }, [isOpen, isAdmin]);

  useEffect(() => {
    if (isOpen && isAdmin && activeTab === 'users') {
      fetchUsers({ search: searchQuery, userType: userFilter.type, status: userFilter.status });
    }
  }, [activeTab, searchQuery, userFilter, isOpen, isAdmin]);

  useEffect(() => {
    if (isOpen && isAdmin && activeTab === 'products') {
      fetchProductsForModeration({ status: productFilter, search: searchQuery });
    }
  }, [activeTab, productFilter, searchQuery, isOpen, isAdmin]);

  useEffect(() => {
    if (isOpen && isAdmin && activeTab === 'categories') {
      fetchCategories();
    }
  }, [activeTab, isOpen, isAdmin]);

  useEffect(() => {
    if (isOpen && isAdmin && activeTab === 'promotions') {
      fetchPromoCodes({ status: promoFilter, search: searchQuery });
    }
  }, [activeTab, promoFilter, searchQuery, isOpen, isAdmin]);

  useEffect(() => {
    if (isOpen && isAdmin && activeTab === 'reports') {
      fetchActivityLogs();
    }
  }, [activeTab, isOpen, isAdmin]);

  const handleBanUser = async () => {
    if (!selectedUser || !user) return;
    setProcessing(true);
    const success = await banUser(selectedUser.user_id, banReason, user.id);
    if (success) {
      setShowBanModal(false);
      setBanReason('');
      setSelectedUser(null);
      fetchUsers({ search: searchQuery, userType: userFilter.type, status: userFilter.status });
    }
    setProcessing(false);
  };

  const handleUnbanUser = async (targetUser: AdminUser) => {
    if (!user) return;
    setProcessing(true);
    const success = await unbanUser(targetUser.user_id, user.id);
    if (success) {
      fetchUsers({ search: searchQuery, userType: userFilter.type, status: userFilter.status });
    }
    setProcessing(false);
  };

  const handleVerifySeller = async (targetUser: AdminUser) => {
    if (!user) return;
    setProcessing(true);
    const success = await verifySeller(targetUser.user_id, user.id);
    if (success) {
      fetchUsers({ search: searchQuery, userType: userFilter.type, status: userFilter.status });
    }
    setProcessing(false);
  };

  const handleUnverifySeller = async (targetUser: AdminUser) => {
    if (!user) return;
    setProcessing(true);
    const success = await unverifySeller(targetUser.user_id, user.id);
    if (success) {
      fetchUsers({ search: searchQuery, userType: userFilter.type, status: userFilter.status });
    }
    setProcessing(false);
  };

  const handleModerateProduct = async (status: 'approved' | 'rejected' | 'flagged') => {
    if (!selectedProduct || !user) return;
    setProcessing(true);
    const success = await moderateProduct(selectedProduct.id, status, moderationNotes, user.id);
    if (success) {
      setShowModerationModal(false);
      setModerationNotes('');
      setSelectedProduct(null);
      fetchProductsForModeration({ status: productFilter, search: searchQuery });
    }
    setProcessing(false);
  };

  const handleSaveCategory = async () => {
    if (!user) return;
    setProcessing(true);
    if (editingCategory) {
      await updateCategory(editingCategory.id, {
        name: categoryForm.name,
        slug: categoryForm.slug,
        icon: categoryForm.icon,
        category_description: categoryForm.description
      } as any, user.id);
    } else {
      await createCategory(categoryForm.name, categoryForm.slug, categoryForm.icon, categoryForm.description, user.id);
    }
    setShowCategoryModal(false);
    setCategoryForm({ name: '', slug: '', icon: 'Tag', description: '' });
    setEditingCategory(null);
    fetchCategories();
    setProcessing(false);
  };

  const handleDeleteCategory = async (category: AdminCategory) => {
    if (!user || !confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?')) return;
    setProcessing(true);
    await deleteCategory(category.id, user.id);
    fetchCategories();
    setProcessing(false);
  };

  const handleSavePromoCode = async () => {
    if (!user) return;
    setProcessing(true);
    
    if (selectedPromoCode) {
      await updatePromoCode(selectedPromoCode.id, promoForm, user.id);
    } else {
      await createPromoCode(promoForm, user.id);
    }
    
    setShowPromoModal(false);
    resetPromoForm();
    fetchPromoCodes({ status: promoFilter, search: searchQuery });
    setProcessing(false);
  };

  const handleTogglePromoCode = async (promo: PromoCode) => {
    if (!user) return;
    setProcessing(true);
    await togglePromoCode(promo.id, !promo.is_active, user.id);
    fetchPromoCodes({ status: promoFilter, search: searchQuery });
    setProcessing(false);
  };

  const handleDeletePromoCode = async (promo: PromoCode) => {
    if (!user || !confirm(`Êtes-vous sûr de vouloir supprimer le code "${promo.code}" ?`)) return;
    setProcessing(true);
    await deletePromoCode(promo.id, user.id);
    fetchPromoCodes({ status: promoFilter, search: searchQuery });
    setProcessing(false);
  };

  const resetPromoForm = () => {
    setPromoForm({
      code: '',
      description: '',
      discountType: 'percentage',
      discountValue: 10,
      minPurchaseAmount: 0,
      maxUses: undefined,
      startDate: '',
      endDate: '',
      categoryRestrictions: [],
      sellerRestrictions: []
    });
    setSelectedPromoCode(null);
  };

  const openEditPromoModal = (promo: PromoCode) => {
    setSelectedPromoCode(promo);
    setPromoForm({
      code: promo.code,
      description: promo.description || '',
      discountType: promo.discount_type,
      discountValue: promo.discount_value,
      minPurchaseAmount: promo.min_purchase_amount,
      maxUses: promo.max_uses,
      startDate: promo.start_date ? promo.start_date.split('T')[0] : '',
      endDate: promo.end_date ? promo.end_date.split('T')[0] : '',
      categoryRestrictions: promo.category_restrictions || [],
      sellerRestrictions: promo.seller_restrictions || []
    });
    setShowPromoModal(true);
  };

  const copyPromoCode = (code: string) => {
    navigator.clipboard.writeText(code);
    // Could add a toast here
  };

  const handleExport = (type: 'users' | 'products' | 'orders' | 'activity' | 'promo_codes') => {
    exportReport(type, reportDateRange.start || undefined, reportDateRange.end || undefined);
  };

  const generateRandomCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPromoForm(f => ({ ...f, code }));
  };

  if (!isOpen) return null;

  if (!isAdmin) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
        <div className="bg-slate-800 rounded-2xl p-8 text-center max-w-md">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Accès Refusé</h2>
          <p className="text-slate-400 mb-6">
            Vous n'avez pas les permissions nécessaires pour accéder au panneau d'administration.
          </p>
          <button onClick={onClose} className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors">
            Fermer
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 overflow-hidden">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg">Panneau d'Administration</h1>
              <p className="text-slate-400 text-sm">Gestion complète de la plateforme</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mt-4 bg-slate-900/50 p-1 rounded-xl w-fit overflow-x-auto">
          {[
            { id: 'dashboard', label: 'Tableau de bord', icon: <BarChart3 className="w-4 h-4" /> },
            { id: 'users', label: 'Utilisateurs', icon: <Users className="w-4 h-4" /> },
            { id: 'products', label: 'Produits', icon: <Package className="w-4 h-4" /> },
            { id: 'categories', label: 'Catégories', icon: <Tag className="w-4 h-4" /> },
            { id: 'promotions', label: 'Promotions', icon: <Ticket className="w-4 h-4" /> },
            { id: 'reports', label: 'Rapports', icon: <FileText className="w-4 h-4" /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
                activeTab === tab.id ? 'bg-purple-500 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      {/* Content */}
      <div className="h-[calc(100vh-140px)] overflow-y-auto p-6">
        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
              </div>
            ) : statistics ? (
              <>
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                  <StatCard
                    title="Utilisateurs"
                    value={statistics.users.total}
                    subtitle={`+${statistics.users.newThisMonth} ce mois`}
                    icon={<Users className="w-6 h-6" />}
                    color="from-blue-500 to-cyan-500"
                  />
                  <StatCard
                    title="Produits"
                    value={statistics.products.total}
                    subtitle={`${statistics.products.pending} en attente`}
                    icon={<Package className="w-6 h-6" />}
                    color="from-orange-500 to-yellow-500"
                  />
                  <StatCard
                    title="Commandes"
                    value={statistics.orders.total}
                    subtitle={`${statistics.orders.completed} livrées`}
                    icon={<ShoppingCart className="w-6 h-6" />}
                    color="from-green-500 to-emerald-500"
                  />
                  <StatCard
                    title="Revenus"
                    value={formatPrice(statistics.orders.totalRevenue)}
                    subtitle="Total des ventes"
                    icon={<DollarSign className="w-6 h-6" />}
                    color="from-purple-500 to-pink-500"
                    isPrice
                  />
                  <StatCard
                    title="Codes Promo"
                    value={statistics.promoCodes?.total || 0}
                    subtitle={`${statistics.promoCodes?.active || 0} actifs`}
                    icon={<Ticket className="w-6 h-6" />}
                    color="from-pink-500 to-rose-500"
                  />
                </div>

                {/* Detailed Stats */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Users Breakdown */}
                  <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                    <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                      <Users className="w-5 h-5 text-blue-400" />
                      Répartition Utilisateurs
                    </h3>
                    <div className="space-y-3">
                      <StatRow label="Acheteurs" value={statistics.users.buyers} color="bg-blue-500" />
                      <StatRow label="Vendeurs" value={statistics.users.sellers} color="bg-orange-500" />
                      <StatRow label="Vendeurs vérifiés" value={statistics.users.verifiedSellers} color="bg-green-500" />
                      <StatRow label="Utilisateurs bannis" value={statistics.users.banned} color="bg-red-500" />
                    </div>
                  </div>

                  {/* Products Breakdown */}
                  <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                    <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                      <Package className="w-5 h-5 text-orange-400" />
                      État des Produits
                    </h3>
                    <div className="space-y-3">
                      <StatRow label="En attente" value={statistics.products.pending} color="bg-yellow-500" />
                      <StatRow label="Approuvés" value={statistics.products.approved} color="bg-green-500" />
                      <StatRow label="Signalés" value={statistics.products.flagged} color="bg-red-500" />
                      <StatRow label="Nouveaux ce mois" value={statistics.products.newThisMonth} color="bg-purple-500" />
                    </div>
                  </div>

                  {/* Orders Breakdown */}
                  <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                    <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                      <ShoppingCart className="w-5 h-5 text-green-400" />
                      État des Commandes
                    </h3>
                    <div className="space-y-3">
                      <StatRow label="En attente" value={statistics.orders.pending} color="bg-yellow-500" />
                      <StatRow label="Livrées" value={statistics.orders.completed} color="bg-green-500" />
                      <StatRow label="Vérifications en attente" value={statistics.verifications.pending} color="bg-purple-500" />
                      <StatRow label="Utilisations promo" value={statistics.promoCodes?.totalUses || 0} color="bg-pink-500" />
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">Impossible de charger les statistiques</p>
              </div>
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            {/* Filters */}
            <div className="flex flex-wrap gap-4">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Rechercher par nom, email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <select
                value={userFilter.type}
                onChange={(e) => setUserFilter(f => ({ ...f, type: e.target.value }))}
                className="px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
              >
                <option value="all">Tous les types</option>
                <option value="buyer">Acheteurs</option>
                <option value="seller">Vendeurs</option>
              </select>
              <select
                value={userFilter.status}
                onChange={(e) => setUserFilter(f => ({ ...f, status: e.target.value }))}
                className="px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="active">Actifs</option>
                <option value="verified">Vérifiés</option>
                <option value="banned">Bannis</option>
              </select>
            </div>

            {/* Users Table */}
            <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
                </div>
              ) : users.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-slate-400">Aucun utilisateur trouvé</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-900/50">
                      <tr>
                        <th className="text-left text-slate-400 text-sm font-medium px-4 py-3">Utilisateur</th>
                        <th className="text-left text-slate-400 text-sm font-medium px-4 py-3">Type</th>
                        <th className="text-left text-slate-400 text-sm font-medium px-4 py-3">Statut</th>
                        <th className="text-left text-slate-400 text-sm font-medium px-4 py-3">Inscrit le</th>
                        <th className="text-right text-slate-400 text-sm font-medium px-4 py-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700">
                      {users.map((u) => (
                        <tr key={u.id} className="hover:bg-slate-800/30">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                                {u.full_name?.charAt(0).toUpperCase() || 'U'}
                              </div>
                              <div>
                                <p className="text-white font-medium">{u.full_name || 'N/A'}</p>
                                <p className="text-slate-400 text-sm">{u.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              u.user_type === 'seller' ? 'bg-orange-500/20 text-orange-400' :
                              u.user_type === 'admin' ? 'bg-purple-500/20 text-purple-400' :
                              'bg-blue-500/20 text-blue-400'
                            }`}>
                              {u.user_type === 'seller' ? 'Vendeur' : u.user_type === 'admin' ? 'Admin' : 'Acheteur'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              {u.is_banned && (
                                <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-500/20 text-red-400">Banni</span>
                              )}
                              {u.is_verified && (
                                <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-500/20 text-green-400">Vérifié</span>
                              )}
                              {!u.is_banned && !u.is_verified && (
                                <span className="px-2 py-1 rounded-full text-xs font-medium bg-slate-500/20 text-slate-400">Standard</span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-slate-400 text-sm">
                            {new Date(u.created_at).toLocaleDateString('fr-FR')}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center justify-end gap-2">
                              {u.user_type === 'seller' && !u.is_verified && (
                                <button
                                  onClick={() => handleVerifySeller(u)}
                                  disabled={processing}
                                  className="p-2 text-green-400 hover:bg-green-500/20 rounded-lg transition-colors"
                                  title="Vérifier le vendeur"
                                >
                                  <UserCheck className="w-4 h-4" />
                                </button>
                              )}
                              {u.user_type === 'seller' && u.is_verified && (
                                <button
                                  onClick={() => handleUnverifySeller(u)}
                                  disabled={processing}
                                  className="p-2 text-yellow-400 hover:bg-yellow-500/20 rounded-lg transition-colors"
                                  title="Retirer la vérification"
                                >
                                  <XCircle className="w-4 h-4" />
                                </button>
                              )}
                              {u.is_banned ? (
                                <button
                                  onClick={() => handleUnbanUser(u)}
                                  disabled={processing}
                                  className="p-2 text-blue-400 hover:bg-blue-500/20 rounded-lg transition-colors"
                                  title="Débannir"
                                >
                                  <CheckCircle className="w-4 h-4" />
                                </button>
                              ) : (
                                <button
                                  onClick={() => { setSelectedUser(u); setShowBanModal(true); }}
                                  disabled={processing || u.user_type === 'admin'}
                                  className="p-2 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors disabled:opacity-50"
                                  title="Bannir"
                                >
                                  <Ban className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex items-center justify-center gap-2">
                <button
                  onClick={() => fetchUsers({ page: pagination.page - 1, search: searchQuery, userType: userFilter.type, status: userFilter.status })}
                  disabled={pagination.page === 1}
                  className="p-2 text-slate-400 hover:text-white disabled:opacity-50"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <span className="text-slate-400">
                  Page {pagination.page} sur {pagination.totalPages}
                </span>
                <button
                  onClick={() => fetchUsers({ page: pagination.page + 1, search: searchQuery, userType: userFilter.type, status: userFilter.status })}
                  disabled={pagination.page === pagination.totalPages}
                  className="p-2 text-slate-400 hover:text-white disabled:opacity-50"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Products Tab */}
        {activeTab === 'products' && (
          <div className="space-y-4">
            {/* Filters */}
            <div className="flex flex-wrap gap-4">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Rechercher un produit..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <select
                value={productFilter}
                onChange={(e) => setProductFilter(e.target.value)}
                className="px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="pending">En attente</option>
                <option value="approved">Approuvés</option>
                <option value="rejected">Rejetés</option>
                <option value="flagged">Signalés</option>
              </select>
            </div>

            {/* Products Grid */}
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-12 bg-slate-800/50 rounded-2xl border border-slate-700">
                <Package className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">Aucun produit trouvé</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {products.map((product) => (
                  <div key={product.id} className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
                    <div className="aspect-video bg-slate-900 relative">
                      {product.images?.[0] ? (
                        <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="w-12 h-12 text-slate-600" />
                        </div>
                      )}
                      <span className={`absolute top-2 right-2 px-2 py-1 rounded-full text-xs font-medium ${
                        product.moderation_status === 'pending' ? 'bg-yellow-500/90 text-yellow-900' :
                        product.moderation_status === 'approved' ? 'bg-green-500/90 text-green-900' :
                        product.moderation_status === 'rejected' ? 'bg-red-500/90 text-red-900' :
                        'bg-orange-500/90 text-orange-900'
                      }`}>
                        {product.moderation_status === 'pending' ? 'En attente' :
                         product.moderation_status === 'approved' ? 'Approuvé' :
                         product.moderation_status === 'rejected' ? 'Rejeté' : 'Signalé'}
                      </span>
                    </div>
                    <div className="p-4">
                      <h3 className="text-white font-medium truncate">{product.name}</h3>
                      <p className="text-slate-400 text-sm truncate">{product.user_profiles?.store_name || 'Vendeur inconnu'}</p>
                      <p className="text-purple-400 font-bold mt-2">{formatPrice(product.price)}</p>
                      <div className="flex gap-2 mt-3">
                        <button
                          onClick={() => { setSelectedProduct(product); setShowModerationModal(true); }}
                          className="flex-1 py-2 bg-purple-500/20 text-purple-400 font-medium rounded-lg hover:bg-purple-500/30 transition-colors text-sm"
                        >
                          Modérer
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Categories Tab */}
        {activeTab === 'categories' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-white font-semibold text-lg">Gestion des Catégories</h2>
              <button
                onClick={() => { setEditingCategory(null); setCategoryForm({ name: '', slug: '', icon: 'Tag', description: '' }); setShowCategoryModal(true); }}
                className="flex items-center gap-2 px-4 py-2 bg-purple-500 text-white font-medium rounded-xl hover:bg-purple-600 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Nouvelle catégorie
              </button>
            </div>

            {loading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
              </div>
            ) : categories.length === 0 ? (
              <div className="text-center py-12 bg-slate-800/50 rounded-2xl border border-slate-700">
                <Tag className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">Aucune catégorie trouvée</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categories.map((category) => (
                  <div key={category.id} className="bg-slate-800/50 rounded-2xl border border-slate-700 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${category.is_active ? 'bg-purple-500/20 text-purple-400' : 'bg-slate-700 text-slate-500'}`}>
                          {iconMap[category.icon || ''] || <Tag className="w-6 h-6" />}
                        </div>
                        <div>
                          <h3 className="text-white font-medium">{category.name}</h3>
                          <p className="text-slate-400 text-sm">{category.slug}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setEditingCategory(category);
                            setCategoryForm({
                              name: category.name,
                              slug: category.slug,
                              icon: category.icon || 'Tag',
                              description: category.category_description || ''
                            });
                            setShowCategoryModal(true);
                          }}
                          className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteCategory(category)}
                          className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/20 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    {category.category_description && (
                      <p className="text-slate-500 text-sm mt-3">{category.category_description}</p>
                    )}
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-700">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${category.is_active ? 'bg-green-500/20 text-green-400' : 'bg-slate-500/20 text-slate-400'}`}>
                        {category.is_active ? 'Active' : 'Inactive'}
                      </span>
                      <span className="text-slate-500 text-xs">Ordre: {category.sort_order}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Promotions Tab */}
        {activeTab === 'promotions' && (
          <div className="space-y-4">
            <div className="flex flex-wrap justify-between items-center gap-4">
              <h2 className="text-white font-semibold text-lg flex items-center gap-2">
                <Ticket className="w-5 h-5 text-pink-400" />
                Gestion des Codes Promo
              </h2>
              <button
                onClick={() => { resetPromoForm(); setShowPromoModal(true); }}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-500 to-purple-500 text-white font-medium rounded-xl hover:from-pink-600 hover:to-purple-600 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Nouveau code promo
              </button>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-4">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Rechercher un code..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <select
                value={promoFilter}
                onChange={(e) => setPromoFilter(e.target.value)}
                className="px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="active">Actifs</option>
                <option value="inactive">Inactifs</option>
              </select>
            </div>

            {/* Promo Codes Grid */}
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
              </div>
            ) : promoCodes.length === 0 ? (
              <div className="text-center py-12 bg-slate-800/50 rounded-2xl border border-slate-700">
                <Ticket className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">Aucun code promo trouvé</p>
                <button
                  onClick={() => { resetPromoForm(); setShowPromoModal(true); }}
                  className="mt-4 px-4 py-2 bg-purple-500/20 text-purple-400 font-medium rounded-lg hover:bg-purple-500/30 transition-colors"
                >
                  Créer votre premier code
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {promoCodes.map((promo) => (
                  <div key={promo.id} className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
                    {/* Header with code */}
                    <div className={`p-4 ${promo.is_active ? 'bg-gradient-to-r from-pink-500/20 to-purple-500/20' : 'bg-slate-700/30'}`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <code className="text-xl font-bold text-white tracking-wider">{promo.code}</code>
                          <button
                            onClick={() => copyPromoCode(promo.code)}
                            className="p-1 text-slate-400 hover:text-white transition-colors"
                            title="Copier le code"
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                        </div>
                        <button
                          onClick={() => handleTogglePromoCode(promo)}
                          disabled={processing}
                          className={`p-1 transition-colors ${promo.is_active ? 'text-green-400' : 'text-slate-500'}`}
                          title={promo.is_active ? 'Désactiver' : 'Activer'}
                        >
                          {promo.is_active ? <ToggleRight className="w-6 h-6" /> : <ToggleLeft className="w-6 h-6" />}
                        </button>
                      </div>
                      <p className="text-slate-400 text-sm mt-1">{promo.description || 'Aucune description'}</p>
                    </div>

                    {/* Discount info */}
                    <div className="p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-sm">Réduction</span>
                        <span className="text-white font-bold flex items-center gap-1">
                          {promo.discount_type === 'percentage' ? (
                            <><Percent className="w-4 h-4 text-pink-400" />{promo.discount_value}%</>
                          ) : (
                            <>{formatPrice(promo.discount_value)}</>
                          )}
                        </span>
                      </div>

                      {promo.min_purchase_amount > 0 && (
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 text-sm">Minimum d'achat</span>
                          <span className="text-white">{formatPrice(promo.min_purchase_amount)}</span>
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-sm">Utilisations</span>
                        <span className="text-white">
                          {promo.current_uses}{promo.max_uses ? ` / ${promo.max_uses}` : ' / ∞'}
                        </span>
                      </div>

                      {(promo.start_date || promo.end_date) && (
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 text-sm flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            Validité
                          </span>
                          <span className="text-white text-sm">
                            {promo.start_date ? new Date(promo.start_date).toLocaleDateString('fr-FR') : '...'} - {promo.end_date ? new Date(promo.end_date).toLocaleDateString('fr-FR') : '...'}
                          </span>
                        </div>
                      )}

                      {/* Stats */}
                      {promo.usage_stats && promo.usage_stats.total_uses > 0 && (
                        <div className="pt-3 border-t border-slate-700">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-slate-400">Total économisé</span>
                            <span className="text-green-400 font-medium">{formatPrice(promo.usage_stats.total_discount_given)}</span>
                          </div>
                          <div className="flex items-center justify-between text-sm mt-1">
                            <span className="text-slate-400">CA généré</span>
                            <span className="text-purple-400 font-medium">{formatPrice(promo.usage_stats.total_order_value)}</span>
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2 pt-3 border-t border-slate-700">
                        <button
                          onClick={async () => {
                            setProcessing(true);
                            try {
                              await notifyPromoCode(
                                promo.code,
                                promo.discount_type,
                                promo.discount_value,
                                promo.min_purchase_amount,
                                promo.end_date
                              );
                              setNotificationSent(true);
                              setTimeout(() => setNotificationSent(false), 3000);
                            } catch (err) {
                              console.error('Failed to send notification:', err);
                            }
                            setProcessing(false);
                          }}
                          disabled={processing || !promo.is_active}
                          className="py-2 px-3 bg-cyan-500/20 text-cyan-400 font-medium rounded-lg hover:bg-cyan-500/30 transition-colors text-sm flex items-center justify-center gap-1 disabled:opacity-50"
                          title="Notifier les utilisateurs"
                        >
                          <Bell className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => { setSelectedPromoCode(promo); setShowPromoStatsModal(true); }}
                          className="flex-1 py-2 bg-slate-700 text-slate-300 font-medium rounded-lg hover:bg-slate-600 transition-colors text-sm flex items-center justify-center gap-1"
                        >
                          <BarChart3 className="w-4 h-4" />
                          Stats
                        </button>
                        <button
                          onClick={() => openEditPromoModal(promo)}
                          className="flex-1 py-2 bg-purple-500/20 text-purple-400 font-medium rounded-lg hover:bg-purple-500/30 transition-colors text-sm flex items-center justify-center gap-1"
                        >
                          <Edit2 className="w-4 h-4" />
                          Modifier
                        </button>
                        <button
                          onClick={() => handleDeletePromoCode(promo)}
                          disabled={processing}
                          className="py-2 px-3 bg-red-500/20 text-red-400 font-medium rounded-lg hover:bg-red-500/30 transition-colors text-sm"
                        >
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}


        {/* Reports Tab */}
        {activeTab === 'reports' && (
          <div className="space-y-6">
            {/* Export Section */}
            <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-6">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <Download className="w-5 h-5 text-green-400" />
                Exporter les Rapports
              </h3>
              <div className="flex flex-wrap gap-4 mb-4">
                <div>
                  <label className="text-slate-400 text-sm block mb-1">Date de début</label>
                  <input
                    type="date"
                    value={reportDateRange.start}
                    onChange={(e) => setReportDateRange(r => ({ ...r, start: e.target.value }))}
                    className="px-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-sm block mb-1">Date de fin</label>
                  <input
                    type="date"
                    value={reportDateRange.end}
                    onChange={(e) => setReportDateRange(r => ({ ...r, end: e.target.value }))}
                    className="px-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                <button onClick={() => handleExport('users')} className="flex items-center justify-center gap-2 px-4 py-3 bg-blue-500/20 text-blue-400 font-medium rounded-xl hover:bg-blue-500/30 transition-colors">
                  <Users className="w-4 h-4" />
                  Utilisateurs
                </button>
                <button onClick={() => handleExport('products')} className="flex items-center justify-center gap-2 px-4 py-3 bg-orange-500/20 text-orange-400 font-medium rounded-xl hover:bg-orange-500/30 transition-colors">
                  <Package className="w-4 h-4" />
                  Produits
                </button>
                <button onClick={() => handleExport('orders')} className="flex items-center justify-center gap-2 px-4 py-3 bg-green-500/20 text-green-400 font-medium rounded-xl hover:bg-green-500/30 transition-colors">
                  <ShoppingCart className="w-4 h-4" />
                  Commandes
                </button>
                <button onClick={() => handleExport('promo_codes')} className="flex items-center justify-center gap-2 px-4 py-3 bg-pink-500/20 text-pink-400 font-medium rounded-xl hover:bg-pink-500/30 transition-colors">
                  <Ticket className="w-4 h-4" />
                  Codes Promo
                </button>
                <button onClick={() => handleExport('activity')} className="flex items-center justify-center gap-2 px-4 py-3 bg-purple-500/20 text-purple-400 font-medium rounded-xl hover:bg-purple-500/30 transition-colors">
                  <Activity className="w-4 h-4" />
                  Activité
                </button>
              </div>
            </div>

            {/* Activity Logs */}
            <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
              <div className="p-4 border-b border-slate-700">
                <h3 className="text-white font-semibold flex items-center gap-2">
                  <Activity className="w-5 h-5 text-purple-400" />
                  Journal d'Activité
                </h3>
              </div>
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
                </div>
              ) : activityLogs.length === 0 ? (
                <div className="text-center py-12">
                  <Activity className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-slate-400">Aucune activité enregistrée</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-700 max-h-96 overflow-y-auto">
                  {activityLogs.map((log) => (
                    <div key={log.id} className="p-4 hover:bg-slate-800/30">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                            log.action_type.includes('banned') || log.action_type.includes('deleted') ? 'bg-red-500/20 text-red-400' :
                            log.action_type.includes('verified') || log.action_type.includes('approved') || log.action_type.includes('activated') ? 'bg-green-500/20 text-green-400' :
                            log.action_type.includes('created') ? 'bg-blue-500/20 text-blue-400' :
                            log.action_type.includes('promo') ? 'bg-pink-500/20 text-pink-400' :
                            'bg-slate-700 text-slate-400'
                          }`}>
                            <Activity className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-white font-medium">{formatActionType(log.action_type)}</p>
                            <p className="text-slate-400 text-sm">{log.entity_type}</p>
                          </div>
                        </div>
                        <span className="text-slate-500 text-sm">
                          {new Date(log.created_at).toLocaleString('fr-FR')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Ban Modal */}
      {showBanModal && selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-800 rounded-2xl w-full max-w-md border border-slate-700">
            <div className="p-6 border-b border-slate-700">
              <h3 className="text-xl font-bold text-white">Bannir l'utilisateur</h3>
              <p className="text-slate-400 text-sm mt-1">
                Bannir {selectedUser.full_name || selectedUser.email}
              </p>
            </div>
            <div className="p-6">
              <label className="text-slate-400 text-sm block mb-2">Raison du bannissement</label>
              <textarea
                value={banReason}
                onChange={(e) => setBanReason(e.target.value)}
                placeholder="Ex: Violation des conditions d'utilisation..."
                rows={4}
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-red-500 resize-none"
              />
            </div>
            <div className="p-6 border-t border-slate-700 flex gap-3">
              <button
                onClick={() => { setShowBanModal(false); setBanReason(''); setSelectedUser(null); }}
                className="flex-1 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleBanUser}
                disabled={processing || !banReason.trim()}
                className="flex-1 py-3 bg-red-500 text-white font-semibold rounded-xl hover:bg-red-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Ban className="w-5 h-5" />}
                Bannir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Moderation Modal */}
      {showModerationModal && selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg border border-slate-700">
            <div className="p-6 border-b border-slate-700">
              <h3 className="text-xl font-bold text-white">Modérer le produit</h3>
              <p className="text-slate-400 text-sm mt-1">{selectedProduct.name}</p>
            </div>
            <div className="p-6">
              <div className="aspect-video bg-slate-900 rounded-xl overflow-hidden mb-4">
                {selectedProduct.images?.[0] ? (
                  <img src={selectedProduct.images[0]} alt={selectedProduct.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Package className="w-12 h-12 text-slate-600" />
                  </div>
                )}
              </div>
              <p className="text-slate-300 text-sm mb-4">{selectedProduct.description || 'Aucune description'}</p>
              <label className="text-slate-400 text-sm block mb-2">Notes de modération (optionnel)</label>
              <textarea
                value={moderationNotes}
                onChange={(e) => setModerationNotes(e.target.value)}
                placeholder="Ex: Produit conforme aux règles..."
                rows={3}
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 resize-none"
              />
            </div>
            <div className="p-6 border-t border-slate-700 flex gap-3">
              <button
                onClick={() => { setShowModerationModal(false); setModerationNotes(''); setSelectedProduct(null); }}
                className="flex-1 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={() => handleModerateProduct('rejected')}
                disabled={processing}
                className="py-3 px-4 bg-red-500 text-white font-semibold rounded-xl hover:bg-red-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <XCircle className="w-5 h-5" />}
                Rejeter
              </button>
              <button
                onClick={() => handleModerateProduct('flagged')}
                disabled={processing}
                className="py-3 px-4 bg-orange-500 text-white font-semibold rounded-xl hover:bg-orange-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <AlertCircle className="w-5 h-5" />}
                Signaler
              </button>
              <button
                onClick={() => handleModerateProduct('approved')}
                disabled={processing}
                className="py-3 px-4 bg-green-500 text-white font-semibold rounded-xl hover:bg-green-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
                Approuver
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Category Modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-800 rounded-2xl w-full max-w-md border border-slate-700">
            <div className="p-6 border-b border-slate-700">
              <h3 className="text-xl font-bold text-white">
                {editingCategory ? 'Modifier la catégorie' : 'Nouvelle catégorie'}
              </h3>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-slate-400 text-sm block mb-2">Nom</label>
                <input
                  type="text"
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="Ex: Électronique"
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="text-slate-400 text-sm block mb-2">Slug</label>
                <input
                  type="text"
                  value={categoryForm.slug}
                  onChange={(e) => setCategoryForm(f => ({ ...f, slug: e.target.value.toLowerCase().replace(/\s+/g, '-') }))}
                  placeholder="Ex: electronics"
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="text-slate-400 text-sm block mb-2">Icône</label>
                <select
                  value={categoryForm.icon}
                  onChange={(e) => setCategoryForm(f => ({ ...f, icon: e.target.value }))}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="Smartphone">Smartphone</option>
                  <option value="Shirt">Mode</option>
                  <option value="Sparkles">Beauté</option>
                  <option value="Home">Maison</option>
                  <option value="Footprints">Chaussures</option>
                  <option value="Gem">Bijoux</option>
                  <option value="Car">Auto</option>
                  <option value="Dumbbell">Sport</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 text-sm block mb-2">Description</label>
                <textarea
                  value={categoryForm.description}
                  onChange={(e) => setCategoryForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="Description de la catégorie..."
                  rows={3}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 resize-none"
                />
              </div>
            </div>
            <div className="p-6 border-t border-slate-700 flex gap-3">
              <button
                onClick={() => { setShowCategoryModal(false); setCategoryForm({ name: '', slug: '', icon: 'Tag', description: '' }); setEditingCategory(null); }}
                className="flex-1 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSaveCategory}
                disabled={processing || !categoryForm.name.trim() || !categoryForm.slug.trim()}
                className="flex-1 py-3 bg-purple-500 text-white font-semibold rounded-xl hover:bg-purple-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
                {editingCategory ? 'Mettre à jour' : 'Créer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Promo Code Modal */}
      {showPromoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg border border-slate-700 my-8">
            <div className="p-6 border-b border-slate-700">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Ticket className="w-5 h-5 text-pink-400" />
                {selectedPromoCode ? 'Modifier le code promo' : 'Nouveau code promo'}
              </h3>
            </div>
            <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
              {/* Code */}
              <div>
                <label className="text-slate-400 text-sm block mb-2">Code promo</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={promoForm.code}
                    onChange={(e) => setPromoForm(f => ({ ...f, code: e.target.value.toUpperCase() }))}
                    placeholder="Ex: SUMMER2024"
                    className="flex-1 px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 uppercase"
                  />
                  <button
                    onClick={generateRandomCode}
                    className="px-4 py-3 bg-slate-700 text-slate-300 rounded-xl hover:bg-slate-600 transition-colors"
                    title="Générer un code aléatoire"
                  >
                    <Hash className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="text-slate-400 text-sm block mb-2">Description</label>
                <input
                  type="text"
                  value={promoForm.description}
                  onChange={(e) => setPromoForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="Ex: Soldes d'été - 20% de réduction"
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              {/* Discount Type & Value */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-400 text-sm block mb-2">Type de réduction</label>
                  <select
                    value={promoForm.discountType}
                    onChange={(e) => setPromoForm(f => ({ ...f, discountType: e.target.value as 'percentage' | 'fixed_amount' }))}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value="percentage">Pourcentage (%)</option>
                    <option value="fixed_amount">Montant fixe (FCFA)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 text-sm block mb-2">
                    Valeur {promoForm.discountType === 'percentage' ? '(%)' : '(FCFA)'}
                  </label>
                  <input
                    type="number"
                    value={promoForm.discountValue}
                    onChange={(e) => setPromoForm(f => ({ ...f, discountValue: parseFloat(e.target.value) || 0 }))}
                    min="0"
                    max={promoForm.discountType === 'percentage' ? 100 : undefined}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* Min Purchase & Max Uses */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-400 text-sm block mb-2">Montant min. d'achat (FCFA)</label>
                  <input
                    type="number"
                    value={promoForm.minPurchaseAmount}
                    onChange={(e) => setPromoForm(f => ({ ...f, minPurchaseAmount: parseFloat(e.target.value) || 0 }))}
                    min="0"
                    placeholder="0 = pas de minimum"
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-sm block mb-2">Utilisations max.</label>
                  <input
                    type="number"
                    value={promoForm.maxUses || ''}
                    onChange={(e) => setPromoForm(f => ({ ...f, maxUses: e.target.value ? parseInt(e.target.value) : undefined }))}
                    min="1"
                    placeholder="Illimité"
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-400 text-sm block mb-2">Date de début</label>
                  <input
                    type="date"
                    value={promoForm.startDate}
                    onChange={(e) => setPromoForm(f => ({ ...f, startDate: e.target.value }))}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-sm block mb-2">Date de fin</label>
                  <input
                    type="date"
                    value={promoForm.endDate}
                    onChange={(e) => setPromoForm(f => ({ ...f, endDate: e.target.value }))}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* Info note */}
              <div className="bg-slate-700/30 rounded-xl p-4">
                <p className="text-slate-400 text-sm">
                  <AlertCircle className="w-4 h-4 inline mr-1" />
                  Les restrictions par catégorie et vendeur peuvent être configurées après la création.
                </p>
              </div>
            </div>
            <div className="p-6 border-t border-slate-700 flex gap-3">
              <button
                onClick={() => { setShowPromoModal(false); resetPromoForm(); }}
                className="flex-1 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSavePromoCode}
                disabled={processing || !promoForm.code.trim() || promoForm.discountValue <= 0}
                className="flex-1 py-3 bg-gradient-to-r from-pink-500 to-purple-500 text-white font-semibold rounded-xl hover:from-pink-600 hover:to-purple-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
                {selectedPromoCode ? 'Mettre à jour' : 'Créer le code'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Promo Stats Modal */}
      {showPromoStatsModal && selectedPromoCode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg border border-slate-700">
            <div className="p-6 border-b border-slate-700">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-purple-400" />
                Statistiques - {selectedPromoCode.code}
              </h3>
            </div>
            <div className="p-6 space-y-4">
              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-700/30 rounded-xl p-4 text-center">
                  <p className="text-3xl font-bold text-white">{selectedPromoCode.current_uses}</p>
                  <p className="text-slate-400 text-sm">Utilisations</p>
                </div>
                <div className="bg-slate-700/30 rounded-xl p-4 text-center">
                  <p className="text-3xl font-bold text-green-400">
                    {formatPrice(selectedPromoCode.usage_stats?.total_discount_given || 0)}
                  </p>
                  <p className="text-slate-400 text-sm">Total économisé</p>
                </div>
                <div className="bg-slate-700/30 rounded-xl p-4 text-center">
                  <p className="text-3xl font-bold text-purple-400">
                    {formatPrice(selectedPromoCode.usage_stats?.total_order_value || 0)}
                  </p>
                  <p className="text-slate-400 text-sm">CA généré</p>
                </div>
                <div className="bg-slate-700/30 rounded-xl p-4 text-center">
                  <p className="text-3xl font-bold text-white">
                    {selectedPromoCode.max_uses ? `${selectedPromoCode.max_uses - selectedPromoCode.current_uses}` : '∞'}
                  </p>
                  <p className="text-slate-400 text-sm">Utilisations restantes</p>
                </div>
              </div>

              {/* Recent Uses */}
              {selectedPromoCode.usage_stats?.recent_uses && selectedPromoCode.usage_stats.recent_uses.length > 0 && (
                <div>
                  <h4 className="text-white font-medium mb-3">Dernières utilisations</h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {selectedPromoCode.usage_stats.recent_uses.slice(0, 10).map((use, idx) => (
                      <div key={idx} className="flex items-center justify-between bg-slate-700/30 rounded-lg p-3">
                        <div>
                          <p className="text-white text-sm">Commande: {formatPrice(use.order_total)}</p>
                          <p className="text-slate-400 text-xs">{new Date(use.used_at).toLocaleString('fr-FR')}</p>
                        </div>
                        <span className="text-green-400 font-medium">-{formatPrice(use.discount_applied)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="p-6 border-t border-slate-700">
              <button
                onClick={() => { setShowPromoStatsModal(false); setSelectedPromoCode(null); }}
                className="w-full py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper Components
const StatCard: React.FC<{
  title: string;
  value: number | string;
  subtitle: string;
  icon: React.ReactNode;
  color: string;
  isPrice?: boolean;
}> = ({ title, value, subtitle, icon, color, isPrice }) => (
  <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
    <div className="flex items-center justify-between mb-4">
      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center text-white`}>
        {icon}
      </div>
      <TrendingUp className="w-5 h-5 text-green-400" />
    </div>
    <p className={`text-2xl font-bold text-white ${isPrice ? 'text-xl' : ''}`}>{value}</p>
    <p className="text-slate-400 text-sm">{title}</p>
    <p className="text-slate-500 text-xs mt-1">{subtitle}</p>
  </div>
);

const StatRow: React.FC<{ label: string; value: number; color: string }> = ({ label, value, color }) => (
  <div className="flex items-center justify-between">
    <div className="flex items-center gap-2">
      <div className={`w-3 h-3 rounded-full ${color}`} />
      <span className="text-slate-400 text-sm">{label}</span>
    </div>
    <span className="text-white font-medium">{value}</span>
  </div>
);

const formatActionType = (action: string): string => {
  const actionMap: Record<string, string> = {
    'user_banned': 'Utilisateur banni',
    'user_unbanned': 'Utilisateur débanni',
    'seller_verified': 'Vendeur vérifié',
    'seller_unverified': 'Vérification retirée',
    'product_approved': 'Produit approuvé',
    'product_rejected': 'Produit rejeté',
    'product_flagged': 'Produit signalé',
    'category_created': 'Catégorie créée',
    'category_updated': 'Catégorie mise à jour',
    'category_deleted': 'Catégorie supprimée',
    'promo_code_created': 'Code promo créé',
    'promo_code_updated': 'Code promo mis à jour',
    'promo_code_deleted': 'Code promo supprimé',
    'promo_code_activated': 'Code promo activé',
    'promo_code_deactivated': 'Code promo désactivé'
  };
  return actionMap[action] || action;
};

export default AdminPanel;
