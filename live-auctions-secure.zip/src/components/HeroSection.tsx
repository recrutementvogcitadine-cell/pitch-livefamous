import React from 'react';
import { Play, Users, Star, Shield, MessageCircle } from 'lucide-react';

interface HeroSectionProps {
  onStartSelling: () => void;
  onDiscoverLives: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onStartSelling, onDiscoverLives }) => {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50"></div>
        <div className="absolute top-1/4 -left-20 w-96 h-96 bg-red-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-red-600/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-full text-red-400 text-sm font-medium mb-6">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              Le Live Devient un Métier
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Shopping en{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">
                Direct
              </span>
              <br />
              en Côte d'Ivoire
            </h1>

            <p className="text-lg text-slate-300 mb-8 max-w-xl mx-auto lg:mx-0">
              Découvrez des produits authentiques via des lives interactifs et contactez directement les vendeurs 
              pour négocier et acheter. Transactions simples et directes.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-10">
              <button
                onClick={onDiscoverLives}
                className="group px-8 py-4 bg-gradient-to-r from-red-500 to-red-600 text-white font-bold rounded-xl hover:shadow-xl hover:shadow-red-500/30 transition-all flex items-center justify-center gap-2"
              >
                <Play className="w-5 h-5 group-hover:scale-110 transition-transform" />
                Voir les Lives
              </button>
              <button
                onClick={onStartSelling}
                className="px-8 py-4 bg-slate-800 border border-slate-700 text-white font-semibold rounded-xl hover:border-red-500 transition-all"
              >
                Devenir Vendeur
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center lg:text-left">
                <div className="text-2xl sm:text-3xl font-bold text-white">500+</div>
                <div className="text-slate-400 text-sm">Vendeurs vérifiés</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-2xl sm:text-3xl font-bold text-white">10K+</div>
                <div className="text-slate-400 text-sm">Acheteurs actifs</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-2xl sm:text-3xl font-bold text-white">50K+</div>
                <div className="text-slate-400 text-sm">Transactions</div>
              </div>
            </div>
          </div>

          {/* Right Content - Live Preview Card */}
          <div className="relative">
            <div className="relative bg-slate-800/50 backdrop-blur rounded-3xl border border-slate-700 overflow-hidden">
              {/* Live Preview Image */}
              <div className="relative aspect-[4/3]">
                <img 
                  src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80" 
                  alt="Live Shopping"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/20 to-transparent"></div>
                
                {/* Live Badge */}
                <div className="absolute top-4 left-4 flex items-center gap-3">
                  <span className="flex items-center gap-1.5 px-3 py-1.5 bg-red-500 text-white text-sm font-bold rounded-full">
                    <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                    LIVE
                  </span>
                  <span className="flex items-center gap-1.5 px-3 py-1.5 bg-black/50 backdrop-blur text-white text-sm rounded-full">
                    <Users className="w-4 h-4" />
                    1,234
                  </span>
                </div>

                {/* Product Info Overlay */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-4 border border-slate-700">
                    <div className="flex items-center gap-3 mb-3">
                      <img 
                        src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop" 
                        alt="Seller"
                        className="w-10 h-10 rounded-full border-2 border-red-500"
                      />
                      <div>
                        <div className="flex items-center gap-1">
                          <span className="text-white font-semibold text-sm">TechStore CI</span>
                          <Shield className="w-4 h-4 text-blue-500" />
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                          <span className="text-slate-400 text-xs">4.9 (234 avis)</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-slate-400 text-xs">iPhone 15 Pro Max</p>
                        <p className="text-red-500 font-bold text-xl">850 000 FCFA</p>
                      </div>
                      <button className="px-4 py-2 bg-green-500 text-white font-semibold rounded-xl hover:bg-green-600 transition-colors flex items-center gap-2 text-sm">
                        <MessageCircle className="w-4 h-4" />
                        Contacter
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 bg-red-500 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg animate-bounce">
              Transactions directes
            </div>
            
            <div className="absolute -bottom-4 -left-4 bg-slate-800 border border-slate-700 rounded-2xl p-3 shadow-xl">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-red-500/20 rounded-full flex items-center justify-center">
                  <MessageCircle className="w-4 h-4 text-red-500" />
                </div>
                <div>
                  <p className="text-white text-xs font-medium">Négociez les prix</p>
                  <p className="text-slate-400 text-xs">Directement avec le vendeur</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
