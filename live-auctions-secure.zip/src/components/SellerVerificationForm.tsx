import React, { useState, useEffect } from 'react';
import { 
  X, Upload, FileText, CreditCard, Building2, 
  CheckCircle, AlertCircle, Loader2, Trash2, Shield
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { VerificationBadgeFull } from './VerificationBadge';

interface SellerVerificationFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

interface VerificationRequest {
  id: string;
  business_name: string;
  business_type: string;
  business_address: string;
  phone: string;
  id_type: string;
  id_number: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason?: string;
  submitted_at: string;
}

interface UploadedDocument {
  id?: string;
  document_type: 'id_card' | 'business_registration' | 'tax_certificate' | 'other';
  file_name: string;
  file_url?: string;
  file?: File;
  uploading?: boolean;
}

const SellerVerificationForm: React.FC<SellerVerificationFormProps> = ({ 
  isOpen, 
  onClose,
  onSuccess 
}) => {
  const { user, profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [existingRequest, setExistingRequest] = useState<VerificationRequest | null>(null);
  const [step, setStep] = useState(1);
  
  // Form data
  const [formData, setFormData] = useState({
    business_name: '',
    business_type: 'individual',
    business_address: '',
    phone: '',
    id_type: 'cni',
    id_number: ''
  });
  
  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Fetch existing verification request
  useEffect(() => {
    if (isOpen && user) {
      fetchExistingRequest();
    }
  }, [isOpen, user]);

  const fetchExistingRequest = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('seller_verification_requests')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (data && !error) {
        setExistingRequest(data as VerificationRequest);
        setFormData({
          business_name: data.business_name || '',
          business_type: data.business_type || 'individual',
          business_address: data.business_address || '',
          phone: data.phone || '',
          id_type: data.id_type || 'cni',
          id_number: data.id_number || ''
        });
      }
    } catch (err) {
      console.error('Error fetching verification request:', err);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>, docType: UploadedDocument['document_type']) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

    if (file.size > maxSize) {
      toast({
        title: "Fichier trop volumineux",
        description: "La taille maximale est de 5 Mo",
        variant: "destructive"
      });
      return;
    }

    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Format non supporté",
        description: "Formats acceptés: JPG, PNG, WebP, PDF",
        variant: "destructive"
      });
      return;
    }

    // Add to documents list
    setDocuments(prev => [
      ...prev.filter(d => d.document_type !== docType),
      {
        document_type: docType,
        file_name: file.name,
        file: file
      }
    ]);
  };

  const removeDocument = (docType: UploadedDocument['document_type']) => {
    setDocuments(prev => prev.filter(d => d.document_type !== docType));
  };

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.business_name.trim()) {
      newErrors.business_name = 'Le nom de l\'entreprise est requis';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Le numéro de téléphone est requis';
    }
    if (!formData.id_number.trim()) {
      newErrors.id_number = 'Le numéro de pièce d\'identité est requis';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const hasIdCard = documents.some(d => d.document_type === 'id_card');
    const hasBusinessDoc = documents.some(d => d.document_type === 'business_registration');

    if (!hasIdCard) {
      toast({
        title: "Document manquant",
        description: "Veuillez télécharger votre pièce d'identité",
        variant: "destructive"
      });
      return false;
    }

    if (formData.business_type !== 'individual' && !hasBusinessDoc) {
      toast({
        title: "Document manquant",
        description: "Veuillez télécharger votre registre de commerce",
        variant: "destructive"
      });
      return false;
    }

    return true;
  };

  const uploadDocuments = async (requestId: string) => {
    const uploadedDocs: { document_type: string; file_name: string; file_url: string; file_size: number }[] = [];

    for (const doc of documents) {
      if (!doc.file) continue;

      const fileExt = doc.file.name.split('.').pop();
      const fileName = `${user?.id}/${requestId}/${doc.document_type}_${Date.now()}.${fileExt}`;

      const { data, error } = await supabase.storage
        .from('verification-documents')
        .upload(fileName, doc.file);

      if (error) {
        console.error('Upload error:', error);
        throw new Error(`Erreur lors du téléchargement de ${doc.file_name}`);
      }

      const { data: urlData } = supabase.storage
        .from('verification-documents')
        .getPublicUrl(fileName);

      uploadedDocs.push({
        document_type: doc.document_type,
        file_name: doc.file_name,
        file_url: urlData.publicUrl || fileName,
        file_size: doc.file.size
      });
    }

    return uploadedDocs;
  };

  const handleSubmit = async () => {
    if (!user) return;

    if (!validateStep2()) return;

    setLoading(true);

    try {
      // Create verification request
      const { data: requestData, error: requestError } = await supabase
        .from('seller_verification_requests')
        .insert({
          user_id: user.id,
          business_name: formData.business_name,
          business_type: formData.business_type,
          business_address: formData.business_address,
          phone: formData.phone,
          id_type: formData.id_type,
          id_number: formData.id_number,
          status: 'pending'
        })
        .select()
        .single();

      if (requestError) throw requestError;

      // Upload documents
      const uploadedDocs = await uploadDocuments(requestData.id);

      // Save document references
      if (uploadedDocs.length > 0) {
        const { error: docsError } = await supabase
          .from('verification_documents')
          .insert(uploadedDocs.map(doc => ({
            request_id: requestData.id,
            ...doc
          })));

        if (docsError) {
          console.error('Error saving document references:', docsError);
        }
      }

      toast({
        title: "Demande soumise!",
        description: "Votre demande de vérification a été envoyée. Nous vous contacterons sous 48h.",
      });

      setExistingRequest(requestData as VerificationRequest);
      onSuccess?.();
      
    } catch (error: any) {
      console.error('Submission error:', error);
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de la soumission",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  // Show existing request status
  if (existingRequest && existingRequest.status !== 'rejected') {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
        <div className="bg-slate-800 rounded-2xl w-full max-w-md border border-slate-700 overflow-hidden">
          <div className="p-6 border-b border-slate-700 flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Statut de Vérification</h2>
            <button onClick={onClose} className="text-slate-400 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="p-6 text-center">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center">
              {existingRequest.status === 'pending' ? (
                <Loader2 className="w-10 h-10 text-yellow-500 animate-spin" />
              ) : (
                <CheckCircle className="w-10 h-10 text-green-500" />
              )}
            </div>

            <VerificationBadgeFull 
              status={existingRequest.status === 'approved' ? 'verified' : 'pending'} 
              className="mb-4"
            />

            <h3 className="text-white text-lg font-semibold mb-2">
              {existingRequest.status === 'pending' 
                ? 'Demande en cours de traitement' 
                : 'Félicitations! Vous êtes vérifié'}
            </h3>
            <p className="text-slate-400 text-sm mb-4">
              {existingRequest.status === 'pending'
                ? 'Notre équipe examine vos documents. Vous recevrez une notification sous 48h.'
                : 'Votre compte vendeur a été vérifié. Le badge de vérification est maintenant visible sur votre profil.'}
            </p>

            <div className="bg-slate-900/50 rounded-xl p-4 text-left">
              <p className="text-slate-400 text-xs mb-1">Entreprise</p>
              <p className="text-white font-medium">{existingRequest.business_name}</p>
              <p className="text-slate-400 text-xs mt-3 mb-1">Soumis le</p>
              <p className="text-white font-medium">
                {new Date(existingRequest.submitted_at).toLocaleDateString('fr-FR', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric'
                })}
              </p>
            </div>
          </div>

          <div className="p-6 border-t border-slate-700">
            <button
              onClick={onClose}
              className="w-full py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-slate-800 rounded-2xl w-full max-w-lg border border-slate-700 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-700 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Vérification Vendeur</h2>
              <p className="text-slate-400 text-sm">Étape {step} sur 2</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Progress bar */}
        <div className="px-6 pt-4 shrink-0">
          <div className="flex gap-2">
            <div className={`h-1 flex-1 rounded-full ${step >= 1 ? 'bg-blue-500' : 'bg-slate-700'}`} />
            <div className={`h-1 flex-1 rounded-full ${step >= 2 ? 'bg-blue-500' : 'bg-slate-700'}`} />
          </div>
        </div>

        {/* Rejection notice */}
        {existingRequest?.status === 'rejected' && (
          <div className="mx-6 mt-4 p-4 bg-red-500/20 border border-red-500/30 rounded-xl shrink-0">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-red-400 font-medium text-sm">Demande précédente refusée</p>
                <p className="text-red-400/80 text-xs mt-1">
                  {existingRequest.rejection_reason || 'Veuillez soumettre une nouvelle demande avec des documents valides.'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 text-sm font-medium mb-2">
                  Nom de l'entreprise / Boutique *
                </label>
                <input
                  type="text"
                  name="business_name"
                  value={formData.business_name}
                  onChange={handleInputChange}
                  placeholder="Ex: TechStore CI"
                  className={`w-full px-4 py-3 bg-slate-900/50 border ${errors.business_name ? 'border-red-500' : 'border-slate-700'} rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500`}
                />
                {errors.business_name && (
                  <p className="text-red-400 text-xs mt-1">{errors.business_name}</p>
                )}
              </div>

              <div>
                <label className="block text-slate-300 text-sm font-medium mb-2">
                  Type d'entreprise *
                </label>
                <select
                  name="business_type"
                  value={formData.business_type}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="individual">Particulier / Auto-entrepreneur</option>
                  <option value="sarl">SARL</option>
                  <option value="sa">SA</option>
                  <option value="sas">SAS</option>
                  <option value="other">Autre</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 text-sm font-medium mb-2">
                  Adresse de l'entreprise
                </label>
                <textarea
                  name="business_address"
                  value={formData.business_address}
                  onChange={handleInputChange}
                  placeholder="Adresse complète"
                  rows={2}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 text-sm font-medium mb-2">
                  Téléphone *
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="+225 07 XX XX XX XX"
                  className={`w-full px-4 py-3 bg-slate-900/50 border ${errors.phone ? 'border-red-500' : 'border-slate-700'} rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500`}
                />
                {errors.phone && (
                  <p className="text-red-400 text-xs mt-1">{errors.phone}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 text-sm font-medium mb-2">
                    Type de pièce d'identité *
                  </label>
                  <select
                    name="id_type"
                    value={formData.id_type}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="cni">CNI</option>
                    <option value="passport">Passeport</option>
                    <option value="residence">Carte de séjour</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 text-sm font-medium mb-2">
                    Numéro *
                  </label>
                  <input
                    type="text"
                    name="id_number"
                    value={formData.id_number}
                    onChange={handleInputChange}
                    placeholder="N° de pièce"
                    className={`w-full px-4 py-3 bg-slate-900/50 border ${errors.id_number ? 'border-red-500' : 'border-slate-700'} rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500`}
                  />
                  {errors.id_number && (
                    <p className="text-red-400 text-xs mt-1">{errors.id_number}</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <p className="text-slate-400 text-sm mb-4">
                Téléchargez les documents requis pour vérifier votre identité et votre entreprise.
              </p>

              {/* ID Card Upload */}
              <div className="border border-slate-700 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-3">
                  <CreditCard className="w-5 h-5 text-blue-400" />
                  <div>
                    <p className="text-white font-medium">Pièce d'identité *</p>
                    <p className="text-slate-400 text-xs">CNI, Passeport ou Carte de séjour</p>
                  </div>
                </div>
                
                {documents.find(d => d.document_type === 'id_card') ? (
                  <div className="flex items-center justify-between bg-slate-900/50 rounded-lg p-3">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-green-400" />
                      <span className="text-white text-sm truncate max-w-[200px]">
                        {documents.find(d => d.document_type === 'id_card')?.file_name}
                      </span>
                    </div>
                    <button 
                      onClick={() => removeDocument('id_card')}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-600 rounded-xl cursor-pointer hover:border-blue-500 transition-colors">
                    <Upload className="w-8 h-8 text-slate-500 mb-2" />
                    <span className="text-slate-400 text-sm">Cliquez pour télécharger</span>
                    <span className="text-slate-500 text-xs mt-1">JPG, PNG, PDF (max 5 Mo)</span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) => handleFileSelect(e, 'id_card')}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              {/* Business Registration Upload */}
              {formData.business_type !== 'individual' && (
                <div className="border border-slate-700 rounded-xl p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Building2 className="w-5 h-5 text-purple-400" />
                    <div>
                      <p className="text-white font-medium">Registre de Commerce *</p>
                      <p className="text-slate-400 text-xs">Document officiel d'enregistrement</p>
                    </div>
                  </div>
                  
                  {documents.find(d => d.document_type === 'business_registration') ? (
                    <div className="flex items-center justify-between bg-slate-900/50 rounded-lg p-3">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-green-400" />
                        <span className="text-white text-sm truncate max-w-[200px]">
                          {documents.find(d => d.document_type === 'business_registration')?.file_name}
                        </span>
                      </div>
                      <button 
                        onClick={() => removeDocument('business_registration')}
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-600 rounded-xl cursor-pointer hover:border-purple-500 transition-colors">
                      <Upload className="w-8 h-8 text-slate-500 mb-2" />
                      <span className="text-slate-400 text-sm">Cliquez pour télécharger</span>
                      <span className="text-slate-500 text-xs mt-1">JPG, PNG, PDF (max 5 Mo)</span>
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={(e) => handleFileSelect(e, 'business_registration')}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              )}

              {/* Tax Certificate (Optional) */}
              <div className="border border-slate-700 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-3">
                  <FileText className="w-5 h-5 text-green-400" />
                  <div>
                    <p className="text-white font-medium">Attestation Fiscale</p>
                    <p className="text-slate-400 text-xs">Optionnel - Accélère la vérification</p>
                  </div>
                </div>
                
                {documents.find(d => d.document_type === 'tax_certificate') ? (
                  <div className="flex items-center justify-between bg-slate-900/50 rounded-lg p-3">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-green-400" />
                      <span className="text-white text-sm truncate max-w-[200px]">
                        {documents.find(d => d.document_type === 'tax_certificate')?.file_name}
                      </span>
                    </div>
                    <button 
                      onClick={() => removeDocument('tax_certificate')}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-600 rounded-xl cursor-pointer hover:border-green-500 transition-colors">
                    <Upload className="w-6 h-6 text-slate-500 mb-1" />
                    <span className="text-slate-400 text-sm">Cliquez pour télécharger</span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) => handleFileSelect(e, 'tax_certificate')}
                      className="hidden"
                    />
                  </label>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-700 flex gap-3 shrink-0">
          {step > 1 && (
            <button
              onClick={() => setStep(step - 1)}
              className="flex-1 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-colors"
            >
              Retour
            </button>
          )}
          
          {step < 2 ? (
            <button
              onClick={() => {
                if (validateStep1()) setStep(2);
              }}
              className="flex-1 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold rounded-xl hover:shadow-lg transition-all"
            >
              Continuer
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="flex-1 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold rounded-xl hover:shadow-lg transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Envoi en cours...
                </>
              ) : (
                'Soumettre la demande'
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default SellerVerificationForm;
