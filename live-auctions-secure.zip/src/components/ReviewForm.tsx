import React, { useState, useRef } from 'react';
import { X, Upload, Image as ImageIcon, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { StarRating } from '@/components/StarRating';
import { useReviews, CreateReviewData } from '@/hooks/useReviews';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ReviewFormProps {
  productId: string;
  productName: string;
  productImage?: string;
  sellerId: string;
  buyerId: string;
  orderId?: string;
  verifiedPurchase?: boolean;
  onSuccess?: () => void;
  onCancel?: () => void;
  existingReview?: {
    id: string;
    rating: number;
    title?: string;
    review_text?: string;
    photos: string[];
  };
}

export function ReviewForm({
  productId,
  productName,
  productImage,
  sellerId,
  buyerId,
  orderId,
  verifiedPurchase = false,
  onSuccess,
  onCancel,
  existingReview
}: ReviewFormProps) {
  const [rating, setRating] = useState(existingReview?.rating || 0);
  const [title, setTitle] = useState(existingReview?.title || '');
  const [reviewText, setReviewText] = useState(existingReview?.review_text || '');
  const [photos, setPhotos] = useState<string[]>(existingReview?.photos || []);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { createReview, updateReview, uploadReviewPhoto, loading } = useReviews();
  const { toast } = useToast();

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (photos.length + files.length > 5) {
      toast({
        title: 'Too many photos',
        description: 'You can upload up to 5 photos per review.',
        variant: 'destructive'
      });
      return;
    }

    setUploading(true);
    try {
      const uploadPromises = Array.from(files).map(file => uploadReviewPhoto(file));
      const uploadedUrls = await Promise.all(uploadPromises);
      setPhotos(prev => [...prev, ...uploadedUrls]);
      toast({
        title: 'Photos uploaded',
        description: `${files.length} photo(s) uploaded successfully.`
      });
    } catch (err: any) {
      toast({
        title: 'Upload failed',
        description: err.message,
        variant: 'destructive'
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (rating === 0) {
      toast({
        title: 'Rating required',
        description: 'Please select a star rating.',
        variant: 'destructive'
      });
      return;
    }

    try {
      if (existingReview) {
        await updateReview(existingReview.id, buyerId, {
          rating,
          title: title || undefined,
          review_text: reviewText || undefined,
          photos
        });
        toast({
          title: 'Review updated',
          description: 'Your review has been updated successfully.'
        });
      } else {
        await createReview(buyerId, {
          product_id: productId,
          seller_id: sellerId,
          order_id: orderId,
          rating,
          title: title || undefined,
          review_text: reviewText || undefined,
          photos
        });
        toast({
          title: 'Review submitted',
          description: 'Thank you for your review!'
        });
      }
      onSuccess?.();
    } catch (err: any) {
      toast({
        title: 'Error',
        description: err.message,
        variant: 'destructive'
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Product info */}
      <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
        {productImage && (
          <img
            src={productImage}
            alt={productName}
            className="w-16 h-16 object-cover rounded-lg"
          />
        )}
        <div>
          <h3 className="font-medium text-gray-900 dark:text-white">{productName}</h3>
          {verifiedPurchase && (
            <span className="inline-flex items-center text-xs text-green-600 dark:text-green-400 mt-1">
              <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              Verified Purchase
            </span>
          )}
        </div>
      </div>

      {/* Star rating */}
      <div className="space-y-2">
        <Label className="text-base">Overall Rating *</Label>
        <div className="flex items-center gap-4">
          <StarRating
            rating={rating}
            size="lg"
            interactive
            onChange={setRating}
          />
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {rating === 0 && 'Select a rating'}
            {rating === 1 && 'Poor'}
            {rating === 2 && 'Fair'}
            {rating === 3 && 'Good'}
            {rating === 4 && 'Very Good'}
            {rating === 5 && 'Excellent'}
          </span>
        </div>
      </div>

      {/* Review title */}
      <div className="space-y-2">
        <Label htmlFor="title">Review Title</Label>
        <Input
          id="title"
          placeholder="Summarize your experience"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={200}
        />
        <p className="text-xs text-gray-500 dark:text-gray-400">
          {title.length}/200 characters
        </p>
      </div>

      {/* Review text */}
      <div className="space-y-2">
        <Label htmlFor="review">Your Review</Label>
        <Textarea
          id="review"
          placeholder="What did you like or dislike? How was your experience with this product?"
          value={reviewText}
          onChange={(e) => setReviewText(e.target.value)}
          rows={5}
          maxLength={2000}
        />
        <p className="text-xs text-gray-500 dark:text-gray-400">
          {reviewText.length}/2000 characters
        </p>
      </div>

      {/* Photo upload */}
      <div className="space-y-3">
        <Label>Add Photos (Optional)</Label>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Add up to 5 photos to help other buyers
        </p>

        {/* Photo previews */}
        {photos.length > 0 && (
          <div className="flex flex-wrap gap-3">
            {photos.map((photo, index) => (
              <div key={index} className="relative group">
                <img
                  src={photo}
                  alt={`Review photo ${index + 1}`}
                  className="w-20 h-20 object-cover rounded-lg border border-gray-200 dark:border-gray-700"
                />
                <button
                  type="button"
                  onClick={() => removePhoto(index)}
                  className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Upload button */}
        {photos.length < 5 && (
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handlePhotoUpload}
              className="hidden"
              id="photo-upload"
            />
            <label
              htmlFor="photo-upload"
              className={cn(
                'inline-flex items-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer transition-colors',
                'hover:border-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/20',
                uploading && 'opacity-50 cursor-not-allowed'
              )}
            >
              {uploading ? (
                <Loader2 className="w-5 h-5 animate-spin text-gray-500" />
              ) : (
                <Upload className="w-5 h-5 text-gray-500" />
              )}
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {uploading ? 'Uploading...' : 'Upload Photos'}
              </span>
            </label>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" disabled={loading || rating === 0}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              {existingReview ? 'Updating...' : 'Submitting...'}
            </>
          ) : (
            existingReview ? 'Update Review' : 'Submit Review'
          )}
        </Button>
      </div>
    </form>
  );
}
