import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Calendar, Clock, Bell, BellOff, Users, ExternalLink, Download, ChevronDown, Play } from 'lucide-react';
import VerificationBadge from './VerificationBadge';

import { ScheduledStream, useScheduledStreams } from '@/hooks/useScheduledStreams';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

interface ScheduledStreamCardProps {
  stream: ScheduledStream;
  onWatch?: () => void;
  onReminderChange?: () => void;
  showSellerInfo?: boolean;
  compact?: boolean;
}

export function ScheduledStreamCard({ 
  stream, 
  onWatch, 
  onReminderChange,
  showSellerInfo = true,
  compact = false 
}: ScheduledStreamCardProps) {
  const { user } = useAuth();
  const { setReminder, removeReminder, checkReminder, generateGoogleCalendarUrl, downloadICalFile } = useScheduledStreams();
  const [hasReminder, setHasReminder] = useState(false);
  const [countdown, setCountdown] = useState<{ days: number; hours: number; minutes: number; seconds: number } | null>(null);
  const [isLive, setIsLive] = useState(false);
  const [loadingReminder, setLoadingReminder] = useState(false);

  // Calculate countdown
  useEffect(() => {
    const calculateCountdown = () => {
      const now = new Date().getTime();
      const streamTime = new Date(stream.scheduled_at).getTime();
      const difference = streamTime - now;

      if (difference <= 0) {
        setCountdown(null);
        setIsLive(stream.status === 'live' || difference > -stream.duration_minutes * 60 * 1000);
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setCountdown({ days, hours, minutes, seconds });
      setIsLive(false);
    };

    calculateCountdown();
    const interval = setInterval(calculateCountdown, 1000);
    return () => clearInterval(interval);
  }, [stream.scheduled_at, stream.status, stream.duration_minutes]);

  // Check if user has reminder set
  useEffect(() => {
    const checkUserReminder = async () => {
      if (user?.id) {
        const result = await checkReminder(user.id, stream.id);
        setHasReminder(result);
      }
    };
    checkUserReminder();
  }, [user?.id, stream.id, checkReminder]);

  const handleToggleReminder = async () => {
    if (!user?.id) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour définir un rappel",
        variant: "destructive"
      });
      return;
    }

    setLoadingReminder(true);
    try {
      if (hasReminder) {
        await removeReminder(user.id, stream.id);
        setHasReminder(false);
        toast({
          title: "Rappel supprimé",
          description: "Vous ne recevrez plus de notification pour ce live"
        });
      } else {
        await setReminder(user.id, stream.id, 'both', 15);
        setHasReminder(true);
        toast({
          title: "Rappel activé",
          description: "Vous serez notifié 15 minutes avant le début du live"
        });
      }
      onReminderChange?.();
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de modifier le rappel",
        variant: "destructive"
      });
    } finally {
      setLoadingReminder(false);
    }
  };

  const handleAddToGoogleCalendar = () => {
    const url = generateGoogleCalendarUrl(stream);
    window.open(url, '_blank');
  };

  const handleDownloadIcal = () => {
    downloadICalFile(stream);
    toast({
      title: "Fichier téléchargé",
      description: "Le fichier iCal a été téléchargé"
    });
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long'
    });
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (compact) {
    return (
      <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            {/* Thumbnail */}
            <div className="relative w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
              {stream.thumbnail_url ? (
                <img src={stream.thumbnail_url} alt={stream.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                  <Play className="w-8 h-8 text-white" />
                </div>
              )}
              {isLive && (
                <div className="absolute top-1 left-1">
                  <Badge className="bg-red-500 text-white text-xs animate-pulse">LIVE</Badge>
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-sm line-clamp-1">{stream.title}</h4>
              {showSellerInfo && stream.seller && (
                <div className="flex items-center gap-1 mt-1">
                  <Avatar className="w-4 h-4">
                    <AvatarImage src={stream.seller.avatar_url || ''} />
                    <AvatarFallback className="text-[8px]">{stream.seller.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground">{stream.seller.name}</span>
                  {stream.seller.is_verified && <VerificationBadge status="verified" size="sm" />}

                </div>
              )}
              <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                <Clock className="w-3 h-3" />
                <span>{formatTime(stream.scheduled_at)}</span>
              </div>
            </div>

            {/* Countdown or Actions */}
            <div className="flex flex-col items-end gap-2">
              {countdown && (
                <div className="text-right">
                  <span className="text-xs text-muted-foreground">Dans</span>
                  <div className="font-mono text-sm font-bold text-purple-600">
                    {countdown.days > 0 && `${countdown.days}j `}
                    {countdown.hours}h {countdown.minutes}m
                  </div>
                </div>
              )}
              <Button
                size="sm"
                variant={hasReminder ? "secondary" : "outline"}
                onClick={handleToggleReminder}
                disabled={loadingReminder}
                className="h-7 px-2"
              >
                {hasReminder ? <BellOff className="w-3 h-3" /> : <Bell className="w-3 h-3" />}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 border-0 bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 group">
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        {stream.thumbnail_url ? (
          <img 
            src={stream.thumbnail_url} 
            alt={stream.title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 flex items-center justify-center">
            <div className="text-center text-white">
              <Play className="w-16 h-16 mx-auto mb-2 opacity-80" />
              <span className="text-sm opacity-80">Live à venir</span>
            </div>
          </div>
        )}

        {/* Status Badge */}
        <div className="absolute top-3 left-3">
          {isLive ? (
            <Badge className="bg-red-500 text-white animate-pulse shadow-lg">
              <span className="w-2 h-2 bg-white rounded-full mr-2 animate-ping" />
              EN DIRECT
            </Badge>
          ) : stream.status === 'cancelled' ? (
            <Badge variant="destructive">ANNULÉ</Badge>
          ) : (
            <Badge className="bg-purple-600 text-white shadow-lg">
              <Calendar className="w-3 h-3 mr-1" />
              PROGRAMMÉ
            </Badge>
          )}
        </div>

        {/* Category */}
        {stream.category && (
          <div className="absolute top-3 right-3">
            <Badge variant="secondary" className="bg-black/50 text-white backdrop-blur-sm">
              {stream.category}
            </Badge>
          </div>
        )}

        {/* Countdown Overlay */}
        {countdown && !isLive && (
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
            <div className="flex justify-center gap-3">
              {countdown.days > 0 && (
                <div className="text-center">
                  <div className="bg-white/20 backdrop-blur-sm rounded-lg px-3 py-2 min-w-[50px]">
                    <span className="text-2xl font-bold text-white">{countdown.days}</span>
                  </div>
                  <span className="text-xs text-white/80 mt-1">jours</span>
                </div>
              )}
              <div className="text-center">
                <div className="bg-white/20 backdrop-blur-sm rounded-lg px-3 py-2 min-w-[50px]">
                  <span className="text-2xl font-bold text-white">{countdown.hours.toString().padStart(2, '0')}</span>
                </div>
                <span className="text-xs text-white/80 mt-1">heures</span>
              </div>
              <div className="text-center">
                <div className="bg-white/20 backdrop-blur-sm rounded-lg px-3 py-2 min-w-[50px]">
                  <span className="text-2xl font-bold text-white">{countdown.minutes.toString().padStart(2, '0')}</span>
                </div>
                <span className="text-xs text-white/80 mt-1">min</span>
              </div>
              <div className="text-center">
                <div className="bg-white/20 backdrop-blur-sm rounded-lg px-3 py-2 min-w-[50px]">
                  <span className="text-2xl font-bold text-white">{countdown.seconds.toString().padStart(2, '0')}</span>
                </div>
                <span className="text-xs text-white/80 mt-1">sec</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <CardContent className="p-5">
        {/* Seller Info */}
        {showSellerInfo && stream.seller && (
          <div className="flex items-center gap-3 mb-3">
            <Avatar className="w-10 h-10 ring-2 ring-purple-200">
              <AvatarImage src={stream.seller.avatar_url || ''} />
              <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white">
                {stream.seller.name?.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-medium text-sm">{stream.seller.name}</span>
                {stream.seller.is_verified && <VerificationBadge status="verified" size="sm" />}

              </div>
              <span className="text-xs text-muted-foreground">Vendeur</span>
            </div>
          </div>
        )}

        {/* Title & Description */}
        <h3 className="font-bold text-lg line-clamp-2 mb-2 group-hover:text-purple-600 transition-colors">
          {stream.title}
        </h3>
        {stream.description && (
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {stream.description}
          </p>
        )}

        {/* Date & Time */}
        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
          <div className="flex items-center gap-1">
            <Calendar className="w-4 h-4 text-purple-500" />
            <span>{formatDate(stream.scheduled_at)}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4 text-purple-500" />
            <span>{formatTime(stream.scheduled_at)}</span>
          </div>
        </div>

        {/* Tags */}
        {stream.tags && stream.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-4">
            {stream.tags.slice(0, 3).map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                #{tag}
              </Badge>
            ))}
            {stream.tags.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{stream.tags.length - 3}
              </Badge>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2">
          {isLive ? (
            <Button 
              className="flex-1 bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600"
              onClick={onWatch}
            >
              <Play className="w-4 h-4 mr-2" />
              Regarder
            </Button>
          ) : (
            <Button
              variant={hasReminder ? "secondary" : "default"}
              className={`flex-1 ${!hasReminder ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700' : ''}`}
              onClick={handleToggleReminder}
              disabled={loadingReminder || stream.status === 'cancelled'}
            >
              {hasReminder ? (
                <>
                  <BellOff className="w-4 h-4 mr-2" />
                  Rappel activé
                </>
              ) : (
                <>
                  <Bell className="w-4 h-4 mr-2" />
                  Me rappeler
                </>
              )}
            </Button>
          )}

          {/* Calendar Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <Calendar className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleAddToGoogleCalendar}>
                <ExternalLink className="w-4 h-4 mr-2" />
                Google Calendar
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDownloadIcal}>
                <Download className="w-4 h-4 mr-2" />
                Télécharger iCal
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  );
}
