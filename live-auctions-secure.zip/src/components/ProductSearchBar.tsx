import React, { useState, useRef, useEffect } from 'react';
import { Search, X, Clock, Tag, User, Package, TrendingUp, Loader2 } from 'lucide-react';
import { SearchSuggestion } from '@/hooks/useProductSearch';

interface ProductSearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSearch: (query: string) => void;
  suggestions: SearchSuggestion[];
  recentSearches: string[];
  onClearRecentSearches: () => void;
  onRemoveRecentSearch: (query: string) => void;
  isSearching?: boolean;
  placeholder?: string;
  className?: string;
}

export const ProductSearchBar: React.FC<ProductSearchBarProps> = ({
  searchQuery,
  onSearchChange,
  onSearch,
  suggestions,
  recentSearches,
  onClearRecentSearches,
  onRemoveRecentSearch,
  isSearching = false,
  placeholder = "Rechercher des produits, vendeurs, catégories...",
  className = "",
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const showDropdown = isFocused && (suggestions.length > 0 || (recentSearches.length > 0 && !searchQuery.trim()));

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setIsFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Reset selected index when suggestions change
  useEffect(() => {
    setSelectedIndex(-1);
  }, [suggestions]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const items = suggestions.length > 0 ? suggestions : recentSearches.map(s => ({ type: 'recent' as const, text: s }));
    
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => (prev < items.length - 1 ? prev + 1 : prev));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => (prev > 0 ? prev - 1 : -1));
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && items[selectedIndex]) {
          const item = items[selectedIndex];
          onSearchChange(item.text);
          onSearch(item.text);
          setIsFocused(false);
        } else if (searchQuery.trim()) {
          onSearch(searchQuery);
          setIsFocused(false);
        }
        break;
      case 'Escape':
        setIsFocused(false);
        inputRef.current?.blur();
        break;
    }
  };

  const handleSuggestionClick = (suggestion: SearchSuggestion) => {
    onSearchChange(suggestion.text);
    onSearch(suggestion.text);
    setIsFocused(false);
  };

  const getSuggestionIcon = (type: SearchSuggestion['type']) => {
    switch (type) {
      case 'product':
        return <Package className="w-4 h-4" />;
      case 'category':
        return <Tag className="w-4 h-4" />;
      case 'seller':
        return <User className="w-4 h-4" />;
      case 'recent':
        return <Clock className="w-4 h-4" />;
      default:
        return <Search className="w-4 h-4" />;
    }
  };

  const getSuggestionLabel = (type: SearchSuggestion['type']) => {
    switch (type) {
      case 'product':
        return 'Produit';
      case 'category':
        return 'Catégorie';
      case 'seller':
        return 'Vendeur';
      case 'recent':
        return 'Récent';
      default:
        return '';
    }
  };

  return (
    <div className={`relative ${className}`}>
      {/* Search Input */}
      <div className="relative">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
          {isSearching ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Search className="w-5 h-5" />
          )}
        </div>
        <input
          ref={inputRef}
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full pl-12 pr-12 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all text-lg"
        />
        {searchQuery && (
          <button
            onClick={() => {
              onSearchChange('');
              inputRef.current?.focus();
            }}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Suggestions Dropdown */}
      {showDropdown && (
        <div
          ref={dropdownRef}
          className="absolute top-full left-0 right-0 mt-2 bg-slate-800 border border-slate-700 rounded-2xl shadow-xl z-50 overflow-hidden"
        >
          {/* Recent Searches Header */}
          {!searchQuery.trim() && recentSearches.length > 0 && (
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
              <div className="flex items-center gap-2 text-slate-400 text-sm">
                <Clock className="w-4 h-4" />
                <span>Recherches récentes</span>
              </div>
              <button
                onClick={onClearRecentSearches}
                className="text-xs text-orange-400 hover:text-orange-300 transition-colors"
              >
                Effacer tout
              </button>
            </div>
          )}

          {/* Trending/Suggestions Header */}
          {searchQuery.trim() && suggestions.length > 0 && (
            <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-700 text-slate-400 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>Suggestions</span>
            </div>
          )}

          {/* Suggestions List */}
          <div className="max-h-80 overflow-y-auto">
            {suggestions.map((suggestion, index) => (
              <button
                key={`${suggestion.type}-${suggestion.text}-${index}`}
                onClick={() => handleSuggestionClick(suggestion)}
                className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors ${
                  selectedIndex === index
                    ? 'bg-slate-700'
                    : 'hover:bg-slate-700/50'
                }`}
              >
                {/* Product Image or Icon */}
                {suggestion.type === 'product' && suggestion.image ? (
                  <img
                    src={suggestion.image}
                    alt=""
                    className="w-10 h-10 rounded-lg object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center text-slate-400">
                    {getSuggestionIcon(suggestion.type)}
                  </div>
                )}

                {/* Text */}
                <div className="flex-1 min-w-0">
                  <p className="text-white truncate">{suggestion.text}</p>
                  <p className="text-xs text-slate-400">{getSuggestionLabel(suggestion.type)}</p>
                </div>

                {/* Remove button for recent searches */}
                {suggestion.type === 'recent' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemoveRecentSearch(suggestion.text);
                    }}
                    className="p-1 text-slate-500 hover:text-slate-300 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </button>
            ))}
          </div>

          {/* No Results */}
          {searchQuery.trim() && suggestions.length === 0 && (
            <div className="px-4 py-8 text-center text-slate-400">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>Aucune suggestion pour "{searchQuery}"</p>
              <p className="text-sm mt-1">Appuyez sur Entrée pour rechercher</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProductSearchBar;
