import React, { useState } from 'react';
import { Users, CheckCircle } from 'lucide-react';
import { LiveStream } from '@/data/mockData';
import FollowButton from './FollowButton';
import AuthModal from './AuthModal';

interface LiveStreamCardProps {
  stream: LiveStream;
  onJoin: (stream: LiveStream) => void;
}

const LiveStreamCard: React.FC<LiveStreamCardProps> = ({ stream, onJoin }) => {
  const [showAuthModal, setShowAuthModal] = useState(false);

  return (
    <>
      <div 
        onClick={() => onJoin(stream)}
        className="group relative bg-slate-800/50 rounded-2xl overflow-hidden border border-slate-700/50 hover:border-orange-500/50 transition-all duration-300 cursor-pointer hover:shadow-xl hover:shadow-orange-500/10 hover:-translate-y-1"
      >
        {/* Thumbnail */}
        <div className="relative aspect-video overflow-hidden">
          <img 
            src={stream.thumbnail} 
            alt={stream.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

          {/* Live Badge */}
          <div className="absolute top-3 left-3 flex items-center gap-2">
            <span className="flex items-center gap-1.5 px-2.5 py-1 bg-red-500 text-white text-xs font-bold rounded-full">
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
              LIVE
            </span>
            {/* Verified Badge */}
            {stream.seller.verified && (
              <span className="flex items-center gap-1 px-2 py-1 bg-blue-500/90 backdrop-blur text-white text-xs font-bold rounded-full">
                <CheckCircle className="w-3 h-3" />
                Vérifié
              </span>
            )}
          </div>

          {/* Viewers */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 bg-black/50 backdrop-blur text-white text-xs rounded-full">
            <Users className="w-3.5 h-3.5" />
            {stream.viewers.toLocaleString()}
          </div>

          {/* Category Badge */}
          <div className="absolute bottom-3 left-3">
            <span className="px-2.5 py-1 bg-purple-500/80 backdrop-blur text-white text-xs font-medium rounded-full">
              {stream.category}
            </span>
          </div>

          {/* Play Overlay */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="w-16 h-16 bg-orange-500/90 rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-white ml-1" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          {/* Title */}
          <h3 className="text-white font-semibold text-sm mb-3 line-clamp-2 group-hover:text-orange-400 transition-colors">
            {stream.title}
          </h3>

          {/* Seller Info */}
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <div className="relative flex-shrink-0">
                <img 
                  src={stream.seller.avatar} 
                  alt={stream.seller.name}
                  className="w-8 h-8 rounded-full border border-slate-600"
                />
                {stream.seller.verified && (
                  <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center border border-slate-800">
                    <CheckCircle className="w-2.5 h-2.5 text-white" />
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-slate-300 text-sm truncate">{stream.seller.name}</p>
              </div>
            </div>
            
            {/* Follow Button */}
            <div onClick={(e) => e.stopPropagation()}>
              <FollowButton
                sellerId={stream.seller.id}
                sellerName={stream.seller.name}
                variant="icon-only"
                onAuthRequired={() => setShowAuthModal(true)}
              />
            </div>
          </div>

          {/* Join Button */}
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onJoin(stream);
            }}
            className="w-full mt-3 py-2.5 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all text-sm"
          >
            Rejoindre le Live
          </button>
        </div>
      </div>

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />
    </>
  );
};

export default LiveStreamCard;
