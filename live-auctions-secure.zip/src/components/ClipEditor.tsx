import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X, Play, Pause, SkipBack, SkipForward, Scissors, Plus, Trash2,
  Save, Eye, EyeOff, Type, Move, Palette, Download, Share2,
  Check, Edit2, Copy, Instagram, Youtube, Square, RectangleVertical,
  RectangleHorizontal, Sparkles, Clock, Settings, Layers, ChevronDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { useClips, VideoClip, TextOverlay } from '@/hooks/useClips';
import { Recording } from '@/hooks/useRecordings';

interface ClipEditorProps {
  isOpen: boolean;
  onClose: () => void;
  recording: Recording;
  initialStartTime?: number;
  initialEndTime?: number;
  existingClipId?: string;
  onSave?: () => void;
}

const ASPECT_RATIOS = [
  { id: '16:9', label: 'Paysage (16:9)', icon: RectangleHorizontal, desc: 'YouTube, Web' },
  { id: '9:16', label: 'Portrait (9:16)', icon: RectangleVertical, desc: 'TikTok, Reels, Stories' },
  { id: '1:1', label: 'Carré (1:1)', icon: Square, desc: 'Instagram, Facebook' },
  { id: '4:5', label: 'Portrait (4:5)', icon: RectangleVertical, desc: 'Instagram Feed' },
];

const EXPORT_FORMATS = [
  { id: 'mp4', label: 'MP4', desc: 'Meilleure qualité' },
  { id: 'webm', label: 'WebM', desc: 'Web optimisé' },
  { id: 'gif', label: 'GIF', desc: 'Animation courte' },
];

const RESOLUTIONS = [
  { id: '720p', label: '720p HD' },
  { id: '1080p', label: '1080p Full HD' },
  { id: '4k', label: '4K Ultra HD' },
];

const ANIMATIONS = [
  { id: 'none', label: 'Aucune' },
  { id: 'fade', label: 'Fondu' },
  { id: 'slide-up', label: 'Glisser haut' },
  { id: 'slide-down', label: 'Glisser bas' },
  { id: 'zoom', label: 'Zoom' },
  { id: 'bounce', label: 'Rebond' },
];

const FONTS = [
  'Inter', 'Arial', 'Helvetica', 'Georgia', 'Times New Roman', 
  'Courier New', 'Verdana', 'Impact', 'Comic Sans MS'
];

const ClipEditor: React.FC<ClipEditorProps> = ({
  isOpen,
  onClose,
  recording,
  initialStartTime = 0,
  initialEndTime,
  existingClipId,
  onSave
}) => {
  const {
    fetchClip,
    createClip,
    updateClip,
    publishClip,
    unpublishClip,
    processClip,
    addTextOverlay,
    updateTextOverlay,
    deleteTextOverlay,
    loading
  } = useClips();

  const [clip, setClip] = useState<VideoClip | null>(null);
  const [overlays, setOverlays] = useState<TextOverlay[]>([]);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(recording.duration_seconds || 0);
  
  const [startTime, setStartTime] = useState(initialStartTime);
  const [endTime, setEndTime] = useState(initialEndTime || recording.duration_seconds || 60);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1' | '4:5'>('16:9');
  const [exportFormat, setExportFormat] = useState<'mp4' | 'webm' | 'gif'>('mp4');
  const [resolution, setResolution] = useState<'720p' | '1080p' | '4k'>('1080p');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  
  const [activeTab, setActiveTab] = useState<'timeline' | 'text' | 'export'>('timeline');
  const [selectedOverlay, setSelectedOverlay] = useState<TextOverlay | null>(null);
  const [showAddText, setShowAddText] = useState(false);
  
  // New text overlay form
  const [newText, setNewText] = useState('');
  const [newFontSize, setNewFontSize] = useState(32);
  const [newFontColor, setNewFontColor] = useState('#FFFFFF');
  const [newBgColor, setNewBgColor] = useState('#8B5CF6');
  const [newHasBg, setNewHasBg] = useState(true);
  const [newAnimation, setNewAnimation] = useState<'none' | 'fade' | 'slide-up' | 'slide-down' | 'zoom' | 'bounce'>('fade');
  const [newPositionX, setNewPositionX] = useState(50);
  const [newPositionY, setNewPositionY] = useState(50);
  
  const [hasChanges, setHasChanges] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      if (existingClipId) {
        loadClip();
      } else {
        setTitle(`Clip - ${recording.title}`);
        setStartTime(initialStartTime);
        setEndTime(initialEndTime || Math.min(initialStartTime + 60, recording.duration_seconds));
      }
    }
  }, [isOpen, existingClipId]);

  const loadClip = async () => {
    if (!existingClipId) return;
    
    const { clip: loadedClip, overlays: loadedOverlays } = await fetchClip(existingClipId);
    if (loadedClip) {
      setClip(loadedClip);
      setOverlays(loadedOverlays);
      setTitle(loadedClip.title);
      setDescription(loadedClip.description || '');
      setStartTime(loadedClip.start_time_seconds);
      setEndTime(loadedClip.end_time_seconds);
      setAspectRatio(loadedClip.aspect_ratio);
      setExportFormat(loadedClip.export_format);
      setResolution(loadedClip.resolution);
      setTags(loadedClip.tags || []);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${mins}:${secs.toString().padStart(2, '0')}.${ms}`;
  };

  const handleTimeUpdate = useCallback(() => {
    if (videoRef.current) {
      const time = videoRef.current.currentTime;
      setCurrentTime(time);
      
      // Loop within clip bounds
      if (time >= endTime) {
        videoRef.current.currentTime = startTime;
      }
    }
  }, [startTime, endTime]);

  const handleLoadedMetadata = useCallback(() => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  }, []);

  const togglePlayback = () => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      if (videoRef.current.currentTime < startTime || videoRef.current.currentTime >= endTime) {
        videoRef.current.currentTime = startTime;
      }
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const seekTo = (time: number) => {
    if (!videoRef.current) return;
    const clampedTime = Math.max(0, Math.min(time, duration));
    videoRef.current.currentTime = clampedTime;
    setCurrentTime(clampedTime);
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressRef.current) return;
    const rect = progressRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    seekTo(percentage * duration);
  };

  const setStartAtCurrent = () => {
    if (currentTime < endTime - 1) {
      setStartTime(currentTime);
      setHasChanges(true);
    }
  };

  const setEndAtCurrent = () => {
    if (currentTime > startTime + 1) {
      setEndTime(currentTime);
      setHasChanges(true);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
      setHasChanges(true);
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
    setHasChanges(true);
  };

  const handleAddTextOverlay = async () => {
    if (!newText.trim()) {
      toast({
        title: "Erreur",
        description: "Le texte ne peut pas être vide",
        variant: "destructive"
      });
      return;
    }

    const clipDuration = endTime - startTime;
    const overlay = await addTextOverlay(clip?.id || 'temp', {
      text_content: newText,
      start_time_seconds: 0,
      end_time_seconds: clipDuration,
      position_x: newPositionX,
      position_y: newPositionY,
      font_size: newFontSize,
      font_color: newFontColor,
      background_color: newHasBg ? newBgColor : undefined,
      background_opacity: 0.8,
      animation_in: newAnimation,
      animation_out: 'fade'
    });

    if (overlay) {
      setOverlays([...overlays, overlay]);
      setNewText('');
      setShowAddText(false);
      toast({
        title: "Texte ajouté",
        description: "L'overlay de texte a été ajouté au clip"
      });
    }
  };

  const handleDeleteOverlay = async (overlayId: string) => {
    const success = await deleteTextOverlay(overlayId);
    if (success) {
      setOverlays(overlays.filter(o => o.id !== overlayId));
      if (selectedOverlay?.id === overlayId) {
        setSelectedOverlay(null);
      }
      toast({
        title: "Texte supprimé",
        description: "L'overlay de texte a été supprimé"
      });
    }
  };

  const handleSave = async () => {
    if (!title.trim()) {
      toast({
        title: "Erreur",
        description: "Le titre est requis",
        variant: "destructive"
      });
      return;
    }

    if (clip) {
      // Update existing clip
      const updated = await updateClip(clip.id, {
        title,
        description,
        startTime,
        endTime,
        aspectRatio,
        exportFormat,
        resolution,
        tags
      });

      if (updated) {
        setClip(updated);
        setHasChanges(false);
        toast({
          title: "Enregistré",
          description: "Le clip a été mis à jour"
        });
        onSave?.();
      }
    } else {
      // Create new clip
      const newClip = await createClip({
        recordingId: recording.id,
        title,
        description,
        startTime,
        endTime,
        aspectRatio,
        exportFormat,
        resolution,
        tags
      });

      if (newClip) {
        setClip(newClip);
        setHasChanges(false);
        toast({
          title: "Clip créé",
          description: "Le clip a été créé avec succès"
        });
        onSave?.();
      }
    }
  };

  const handleProcess = async () => {
    if (!clip) {
      await handleSave();
      return;
    }

    const success = await processClip(clip.id);
    if (success) {
      toast({
        title: "Traitement en cours",
        description: "Le clip est en cours de génération..."
      });
      // Reload clip to get updated status
      setTimeout(() => loadClip(), 3000);
    }
  };

  const handlePublish = async () => {
    if (!clip) return;

    const success = await publishClip(clip.id);
    if (success) {
      setClip({ ...clip, status: 'published', is_published: true });
      toast({
        title: "Publié",
        description: "Le clip est maintenant public"
      });
      onSave?.();
    }
  };

  const handleUnpublish = async () => {
    if (!clip) return;

    const success = await unpublishClip(clip.id);
    if (success) {
      setClip({ ...clip, status: 'ready', is_published: false });
      toast({
        title: "Dépublié",
        description: "Le clip n'est plus public"
      });
      onSave?.();
    }
  };

  const copyShareLink = () => {
    if (!clip) return;
    const url = `${window.location.origin}?clip=${clip.id}`;
    navigator.clipboard.writeText(url);
    toast({
      title: "Lien copié",
      description: "Le lien de partage a été copié"
    });
  };

  const getAspectRatioStyle = () => {
    switch (aspectRatio) {
      case '9:16': return { aspectRatio: '9/16', maxHeight: '400px' };
      case '1:1': return { aspectRatio: '1/1', maxHeight: '400px' };
      case '4:5': return { aspectRatio: '4/5', maxHeight: '400px' };
      default: return { aspectRatio: '16/9', maxHeight: '300px' };
    }
  };

  const getVisibleOverlays = () => {
    const relativeTime = currentTime - startTime;
    return overlays.filter(o => {
      const start = o.start_time_seconds;
      const end = o.end_time_seconds || (endTime - startTime);
      return relativeTime >= start && relativeTime <= end;
    });
  };

  if (!isOpen) return null;

  const clipDuration = endTime - startTime;
  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
  const startPercent = duration > 0 ? (startTime / duration) * 100 : 0;
  const endPercent = duration > 0 ? (endTime / duration) * 100 : 100;

  return (
    <div className="fixed inset-0 z-[9999] bg-black/95 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-800">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
            <X className="w-5 h-5 text-white" />
          </button>
          <div>
            <h2 className="text-white font-bold text-lg">Créateur de Clips</h2>
            <p className="text-slate-400 text-sm">
              {clip ? 'Modifier le clip' : 'Nouveau clip'} • {formatTime(clipDuration)} de durée
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {hasChanges && (
            <span className="text-yellow-400 text-sm">Modifications non sauvegardées</span>
          )}
          <Button
            onClick={handleSave}
            disabled={loading}
            className="bg-purple-500 hover:bg-purple-600"
          >
            <Save className="w-4 h-4 mr-2" />
            {clip ? 'Sauvegarder' : 'Créer le clip'}
          </Button>
          {clip && clip.status === 'draft' && (
            <Button
              onClick={handleProcess}
              disabled={loading}
              className="bg-blue-500 hover:bg-blue-600"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Générer
            </Button>
          )}
          {clip && (clip.status === 'ready' || clip.status === 'published') && (
            clip.is_published ? (
              <Button
                onClick={handleUnpublish}
                disabled={loading}
                variant="outline"
                className="border-orange-500 text-orange-500 hover:bg-orange-500/10"
              >
                <EyeOff className="w-4 h-4 mr-2" />
                Dépublier
              </Button>
            ) : (
              <Button
                onClick={handlePublish}
                disabled={loading}
                className="bg-green-500 hover:bg-green-600"
              >
                <Eye className="w-4 h-4 mr-2" />
                Publier
              </Button>
            )
          )}
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Preview Section */}
        <div className="flex-1 flex flex-col p-4">
          {/* Video Preview with Aspect Ratio */}
          <div className="flex-1 flex items-center justify-center bg-slate-900 rounded-xl overflow-hidden mb-4">
            <div 
              ref={previewRef}
              className="relative bg-black rounded-lg overflow-hidden"
              style={getAspectRatioStyle()}
            >
              {recording.processed_url ? (
                <video
                  ref={videoRef}
                  src={recording.processed_url}
                  className="w-full h-full object-cover"
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  onClick={togglePlayback}
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Scissors className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                    <p className="text-slate-400">Aperçu non disponible</p>
                  </div>
                </div>
              )}

              {/* Text Overlays Preview */}
              {getVisibleOverlays().map(overlay => (
                <div
                  key={overlay.id}
                  className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all ${
                    selectedOverlay?.id === overlay.id ? 'ring-2 ring-purple-500' : ''
                  }`}
                  style={{
                    left: `${overlay.position_x}%`,
                    top: `${overlay.position_y}%`,
                    fontFamily: overlay.font_family,
                    fontSize: `${overlay.font_size}px`,
                    fontWeight: overlay.font_weight,
                    color: overlay.font_color,
                    backgroundColor: overlay.background_color 
                      ? `${overlay.background_color}${Math.round(overlay.background_opacity * 255).toString(16).padStart(2, '0')}`
                      : 'transparent',
                    padding: overlay.background_color ? '8px 16px' : '0',
                    borderRadius: '8px',
                    textShadow: overlay.has_shadow 
                      ? `0 2px ${overlay.shadow_blur}px ${overlay.shadow_color}`
                      : 'none',
                    textAlign: overlay.text_align
                  }}
                  onClick={() => setSelectedOverlay(overlay)}
                >
                  {overlay.text_content}
                </div>
              ))}

              {/* Play/Pause Overlay */}
              {!isPlaying && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                  <button
                    onClick={togglePlayback}
                    className="w-16 h-16 bg-purple-500/80 hover:bg-purple-500 rounded-full flex items-center justify-center transition-all"
                  >
                    <Play className="w-8 h-8 text-white ml-1" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Timeline */}
          <div className="bg-slate-900 rounded-xl p-4">
            {/* Progress Bar with Selection */}
            <div className="relative mb-4">
              <div
                ref={progressRef}
                className="h-16 bg-slate-800 rounded-lg cursor-pointer relative overflow-hidden"
                onClick={handleProgressClick}
              >
                {/* Unselected regions (darker) */}
                <div
                  className="absolute inset-y-0 bg-slate-700/70"
                  style={{ left: 0, width: `${startPercent}%` }}
                />
                <div
                  className="absolute inset-y-0 bg-slate-700/70"
                  style={{ left: `${endPercent}%`, right: 0 }}
                />

                {/* Selected region */}
                <div
                  className="absolute inset-y-0 bg-gradient-to-r from-purple-500/40 to-pink-500/40"
                  style={{ left: `${startPercent}%`, width: `${endPercent - startPercent}%` }}
                />

                {/* Playhead */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-white z-10"
                  style={{ left: `${progress}%` }}
                >
                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full" />
                </div>

                {/* Selection handles */}
                <div
                  className="absolute top-0 bottom-0 w-2 bg-green-500 cursor-ew-resize z-20 rounded-l"
                  style={{ left: `${startPercent}%` }}
                />
                <div
                  className="absolute top-0 bottom-0 w-2 bg-red-500 cursor-ew-resize z-20 rounded-r"
                  style={{ left: `calc(${endPercent}% - 8px)` }}
                />

                {/* Text overlay markers */}
                {overlays.map(overlay => {
                  const overlayStart = startPercent + ((overlay.start_time_seconds / clipDuration) * (endPercent - startPercent));
                  const overlayEnd = overlay.end_time_seconds 
                    ? startPercent + ((overlay.end_time_seconds / clipDuration) * (endPercent - startPercent))
                    : endPercent;
                  return (
                    <div
                      key={overlay.id}
                      className="absolute top-1 h-3 bg-yellow-400/60 rounded"
                      style={{ 
                        left: `${overlayStart}%`, 
                        width: `${overlayEnd - overlayStart}%` 
                      }}
                    />
                  );
                })}
              </div>

              {/* Time labels */}
              <div className="flex justify-between text-slate-400 text-sm mt-2">
                <span>{formatTime(currentTime)}</span>
                <span className="text-purple-400">
                  Sélection: {formatTime(startTime)} - {formatTime(endTime)}
                </span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Playback Controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => seekTo(currentTime - 5)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                >
                  <SkipBack className="w-5 h-5 text-white" />
                </button>
                <button
                  onClick={togglePlayback}
                  className="p-3 bg-purple-500 hover:bg-purple-600 rounded-lg transition-colors"
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-white ml-0.5" />
                  )}
                </button>
                <button
                  onClick={() => seekTo(currentTime + 5)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                >
                  <SkipForward className="w-5 h-5 text-white" />
                </button>
              </div>

              {/* Selection Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={setStartAtCurrent}
                  className="flex items-center gap-2 px-3 py-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors"
                >
                  <span className="text-sm">Début: {formatTime(startTime)}</span>
                </button>
                <button
                  onClick={setEndAtCurrent}
                  className="flex items-center gap-2 px-3 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                >
                  <span className="text-sm">Fin: {formatTime(endTime)}</span>
                </button>
              </div>

              {/* Duration */}
              <div className="flex items-center gap-2 text-slate-400">
                <Clock className="w-4 h-4" />
                <span className="text-sm">Durée: {formatTime(clipDuration)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-96 bg-slate-900 border-l border-slate-800 flex flex-col">
          {/* Tabs */}
          <div className="flex border-b border-slate-800">
            <button
              onClick={() => setActiveTab('timeline')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'timeline' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Settings className="w-4 h-4 inline mr-2" />
              Détails
            </button>
            <button
              onClick={() => setActiveTab('text')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'text' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Type className="w-4 h-4 inline mr-2" />
              Texte
            </button>
            <button
              onClick={() => setActiveTab('export')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'export' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Download className="w-4 h-4 inline mr-2" />
              Export
            </button>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-4">
            {activeTab === 'timeline' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-slate-400 text-sm mb-2">Titre du clip</label>
                  <Input
                    value={title}
                    onChange={(e) => {
                      setTitle(e.target.value);
                      setHasChanges(true);
                    }}
                    placeholder="Titre du clip"
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                
                <div>
                  <label className="block text-slate-400 text-sm mb-2">Description</label>
                  <Textarea
                    value={description}
                    onChange={(e) => {
                      setDescription(e.target.value);
                      setHasChanges(true);
                    }}
                    placeholder="Description du clip"
                    className="bg-slate-800 border-slate-700 text-white resize-none"
                    rows={3}
                  />
                </div>

                <div>
                  <label className="block text-slate-400 text-sm mb-2">Tags</label>
                  <div className="flex gap-2 mb-2 flex-wrap">
                    {tags.map(tag => (
                      <span
                        key={tag}
                        className="px-2 py-1 bg-purple-500/20 text-purple-400 text-sm rounded-full flex items-center gap-1"
                      >
                        #{tag}
                        <button
                          onClick={() => handleRemoveTag(tag)}
                          className="hover:text-red-400"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      placeholder="Ajouter un tag"
                      className="bg-slate-800 border-slate-700 text-white flex-1"
                      onKeyDown={(e) => e.key === 'Enter' && handleAddTag()}
                    />
                    <Button onClick={handleAddTag} size="sm" className="bg-purple-500 hover:bg-purple-600">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Clip Info */}
                {clip && (
                  <div className="bg-slate-800 rounded-xl p-4">
                    <h4 className="text-white font-medium mb-3">Informations</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Statut</span>
                        <span className={`px-2 py-0.5 rounded text-xs ${
                          clip.status === 'published' ? 'bg-green-500/20 text-green-400' :
                          clip.status === 'processing' ? 'bg-blue-500/20 text-blue-400' :
                          clip.status === 'ready' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-slate-500/20 text-slate-400'
                        }`}>
                          {clip.status === 'published' ? 'Publié' :
                           clip.status === 'processing' ? 'En cours...' :
                           clip.status === 'ready' ? 'Prêt' : 'Brouillon'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Vues</span>
                        <span className="text-white">{clip.view_count}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Partages</span>
                        <span className="text-white">{clip.share_count}</span>
                      </div>
                    </div>
                    
                    {clip.is_published && (
                      <Button
                        onClick={copyShareLink}
                        variant="outline"
                        size="sm"
                        className="w-full mt-3 border-slate-600"
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copier le lien
                      </Button>
                    )}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'text' && (
              <div className="space-y-4">
                {/* Add Text Button */}
                {!showAddText && (
                  <Button
                    onClick={() => setShowAddText(true)}
                    className="w-full bg-purple-500 hover:bg-purple-600"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Ajouter du texte
                  </Button>
                )}

                {/* Add Text Form */}
                {showAddText && (
                  <div className="bg-slate-800 rounded-xl p-4 space-y-3">
                    <h4 className="text-white font-medium">Nouveau texte</h4>
                    
                    <Input
                      value={newText}
                      onChange={(e) => setNewText(e.target.value)}
                      placeholder="Votre texte..."
                      className="bg-slate-700 border-slate-600 text-white"
                    />

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 text-xs mb-1">Taille</label>
                        <Input
                          type="number"
                          value={newFontSize}
                          onChange={(e) => setNewFontSize(parseInt(e.target.value) || 32)}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-xs mb-1">Animation</label>
                        <select
                          value={newAnimation}
                          onChange={(e) => setNewAnimation(e.target.value as any)}
                          className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-md text-white text-sm"
                        >
                          {ANIMATIONS.map(a => (
                            <option key={a.id} value={a.id}>{a.label}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 text-xs mb-1">Couleur texte</label>
                        <div className="flex gap-2">
                          <input
                            type="color"
                            value={newFontColor}
                            onChange={(e) => setNewFontColor(e.target.value)}
                            className="w-10 h-10 rounded cursor-pointer"
                          />
                          <Input
                            value={newFontColor}
                            onChange={(e) => setNewFontColor(e.target.value)}
                            className="bg-slate-700 border-slate-600 text-white flex-1"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-slate-400 text-xs mb-1">Fond</label>
                        <div className="flex gap-2 items-center">
                          <input
                            type="checkbox"
                            checked={newHasBg}
                            onChange={(e) => setNewHasBg(e.target.checked)}
                            className="rounded"
                          />
                          {newHasBg && (
                            <input
                              type="color"
                              value={newBgColor}
                              onChange={(e) => setNewBgColor(e.target.value)}
                              className="w-10 h-10 rounded cursor-pointer"
                            />
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 text-xs mb-1">Position X (%)</label>
                        <Input
                          type="number"
                          value={newPositionX}
                          onChange={(e) => setNewPositionX(parseInt(e.target.value) || 50)}
                          min={0}
                          max={100}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-xs mb-1">Position Y (%)</label>
                        <Input
                          type="number"
                          value={newPositionY}
                          onChange={(e) => setNewPositionY(parseInt(e.target.value) || 50)}
                          min={0}
                          max={100}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={handleAddTextOverlay}
                        className="flex-1 bg-purple-500 hover:bg-purple-600"
                      >
                        Ajouter
                      </Button>
                      <Button
                        onClick={() => {
                          setShowAddText(false);
                          setNewText('');
                        }}
                        variant="outline"
                        className="border-slate-600"
                      >
                        Annuler
                      </Button>
                    </div>
                  </div>
                )}

                {/* Existing Overlays */}
                <div className="space-y-2">
                  <h4 className="text-slate-400 text-sm">Textes ({overlays.length})</h4>
                  {overlays.length === 0 ? (
                    <div className="text-center py-8">
                      <Type className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                      <p className="text-slate-400 text-sm">Aucun texte ajouté</p>
                    </div>
                  ) : (
                    overlays.map(overlay => (
                      <div
                        key={overlay.id}
                        className={`bg-slate-800 rounded-lg p-3 cursor-pointer hover:bg-slate-700 transition-colors ${
                          selectedOverlay?.id === overlay.id ? 'ring-2 ring-purple-500' : ''
                        }`}
                        onClick={() => setSelectedOverlay(overlay)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1 min-w-0">
                            <p className="text-white text-sm font-medium truncate">
                              {overlay.text_content}
                            </p>
                            <p className="text-slate-400 text-xs">
                              {formatTime(overlay.start_time_seconds)} - {formatTime(overlay.end_time_seconds || clipDuration)}
                            </p>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteOverlay(overlay.id);
                            }}
                            className="p-1.5 hover:bg-red-500/20 rounded transition-colors"
                          >
                            <Trash2 className="w-4 h-4 text-red-400" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {activeTab === 'export' && (
              <div className="space-y-4">
                {/* Aspect Ratio */}
                <div>
                  <label className="block text-slate-400 text-sm mb-2">Format d'image</label>
                  <div className="grid grid-cols-2 gap-2">
                    {ASPECT_RATIOS.map(ratio => {
                      const Icon = ratio.icon;
                      return (
                        <button
                          key={ratio.id}
                          onClick={() => {
                            setAspectRatio(ratio.id as any);
                            setHasChanges(true);
                          }}
                          className={`p-3 rounded-lg border transition-colors text-left ${
                            aspectRatio === ratio.id
                              ? 'border-purple-500 bg-purple-500/20'
                              : 'border-slate-700 bg-slate-800 hover:border-slate-600'
                          }`}
                        >
                          <Icon className={`w-5 h-5 mb-1 ${
                            aspectRatio === ratio.id ? 'text-purple-400' : 'text-slate-400'
                          }`} />
                          <p className="text-white text-sm font-medium">{ratio.label}</p>
                          <p className="text-slate-400 text-xs">{ratio.desc}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Export Format */}
                <div>
                  <label className="block text-slate-400 text-sm mb-2">Format de fichier</label>
                  <div className="space-y-2">
                    {EXPORT_FORMATS.map(format => (
                      <button
                        key={format.id}
                        onClick={() => {
                          setExportFormat(format.id as any);
                          setHasChanges(true);
                        }}
                        className={`w-full p-3 rounded-lg border transition-colors text-left flex items-center justify-between ${
                          exportFormat === format.id
                            ? 'border-purple-500 bg-purple-500/20'
                            : 'border-slate-700 bg-slate-800 hover:border-slate-600'
                        }`}
                      >
                        <div>
                          <p className="text-white font-medium">{format.label}</p>
                          <p className="text-slate-400 text-xs">{format.desc}</p>
                        </div>
                        {exportFormat === format.id && (
                          <Check className="w-5 h-5 text-purple-400" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Resolution */}
                <div>
                  <label className="block text-slate-400 text-sm mb-2">Résolution</label>
                  <select
                    value={resolution}
                    onChange={(e) => {
                      setResolution(e.target.value as any);
                      setHasChanges(true);
                    }}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  >
                    {RESOLUTIONS.map(res => (
                      <option key={res.id} value={res.id}>{res.label}</option>
                    ))}
                  </select>
                </div>

                {/* Quick Share */}
                <div className="bg-slate-800 rounded-xl p-4">
                  <h4 className="text-white font-medium mb-3">Partage rapide</h4>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => {
                        setAspectRatio('9:16');
                        setHasChanges(true);
                      }}
                      className="p-3 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg text-white text-center hover:opacity-90 transition-opacity"
                    >
                      <Instagram className="w-5 h-5 mx-auto mb-1" />
                      <span className="text-xs">Reels</span>
                    </button>
                    <button
                      onClick={() => {
                        setAspectRatio('9:16');
                        setHasChanges(true);
                      }}
                      className="p-3 bg-black rounded-lg text-white text-center hover:bg-slate-900 transition-colors border border-slate-700"
                    >
                      <svg className="w-5 h-5 mx-auto mb-1" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z"/>
                      </svg>
                      <span className="text-xs">TikTok</span>
                    </button>
                    <button
                      onClick={() => {
                        setAspectRatio('16:9');
                        setHasChanges(true);
                      }}
                      className="p-3 bg-red-600 rounded-lg text-white text-center hover:bg-red-700 transition-colors"
                    >
                      <Youtube className="w-5 h-5 mx-auto mb-1" />
                      <span className="text-xs">YouTube</span>
                    </button>
                  </div>
                </div>

                {/* Export Button */}
                {clip && clip.status === 'ready' && (
                  <Button
                    onClick={() => {
                      // In production, this would trigger a download
                      toast({
                        title: "Téléchargement",
                        description: "Le clip sera téléchargé..."
                      });
                    }}
                    className="w-full bg-green-500 hover:bg-green-600"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Télécharger le clip
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClipEditor;
