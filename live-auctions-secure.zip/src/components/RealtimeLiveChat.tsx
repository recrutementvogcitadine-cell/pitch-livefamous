import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Pin, Trash2, Ban, MoreVertical, Star, 
  MessageCircle, ShieldAlert, X, Clock, AlertTriangle,
  ThumbsUp, Heart, Laugh, Flame, PartyPopper, Users, Eye
} from 'lucide-react';
import { useRealtimeChat, ChatMessage, TypingUser, PresentUser } from '@/hooks/useRealtimeChat';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';

interface RealtimeLiveChatProps {
  streamId: string;
  isStreamOwner?: boolean;
  sellerName?: string;
}

// Typing indicator component
const TypingIndicator: React.FC<{ users: TypingUser[] }> = ({ users }) => {
  if (users.length === 0) return null;

  const displayNames = users.slice(0, 3).map(u => u.user_name.split(' ')[0]);
  let text = '';
  
  if (users.length === 1) {
    text = `${displayNames[0]} est en train d'écrire...`;
  } else if (users.length === 2) {
    text = `${displayNames.join(' et ')} sont en train d'écrire...`;
  } else {
    text = `${displayNames.slice(0, 2).join(', ')} et ${users.length - 2} autres écrivent...`;
  }

  return (
    <div className="flex items-center gap-2 px-3 py-2 text-slate-400 text-sm">
      <div className="flex gap-1">
        <span className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
        <span className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
        <span className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
      </div>
      <span>{text}</span>
    </div>
  );
};

// Viewer list component
const ViewerList: React.FC<{ users: PresentUser[]; onClose: () => void }> = ({ users, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
      <div className="bg-slate-800 rounded-2xl p-6 max-w-md w-full mx-4 border border-slate-700 max-h-[80vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-orange-400" />
            <h3 className="text-white font-semibold">Spectateurs ({users.length})</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-700 rounded"
          >
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {users.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <Eye className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>Aucun spectateur pour le moment</p>
            </div>
          ) : (
            <div className="space-y-2">
              {users.map(viewer => (
                <div key={viewer.user_id} className="p-3 bg-slate-700/50 rounded-lg flex items-center gap-3">
                  {viewer.user_avatar ? (
                    <img src={viewer.user_avatar} alt="" className="w-10 h-10 rounded-full" />
                  ) : (
                    <div className="w-10 h-10 bg-orange-500/30 rounded-full flex items-center justify-center text-orange-300 font-bold">
                      {viewer.user_name.charAt(0)}
                    </div>
                  )}
                  <div className="flex-1">
                    <p className="text-white font-medium">{viewer.user_name}</p>
                    <div className="flex items-center gap-1 text-slate-400 text-xs">
                      <span className={`w-2 h-2 rounded-full ${
                        viewer.status === 'online' ? 'bg-green-400' : 
                        viewer.status === 'away' ? 'bg-yellow-400' : 'bg-slate-400'
                      }`} />
                      <span>
                        {viewer.status === 'online' ? 'En ligne' : 
                         viewer.status === 'away' ? 'Absent' : 'Hors ligne'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const RealtimeLiveChat: React.FC<RealtimeLiveChatProps> = ({ streamId, isStreamOwner = false, sellerName }) => {
  const { user, profile } = useAuth();
  const {
    messages,
    pinnedMessages,
    loading,
    isBanned,
    bannedUsers,
    typingUsers,
    presentUsers,
    viewerCount,
    quickReactions,
    sendMessage,
    addReaction,
    pinMessage,
    unpinMessage,
    highlightMessage,
    deleteMessage,
    banUser,
    unbanUser,
    addSystemMessage,
    setTyping
  } = useRealtimeChat(streamId, isStreamOwner);

  const [newMessage, setNewMessage] = useState('');
  const [showReactions, setShowReactions] = useState<string | null>(null);
  const [showMessageMenu, setShowMessageMenu] = useState<string | null>(null);
  const [showBanModal, setShowBanModal] = useState<{ userId: string; userName: string } | null>(null);
  const [banDuration, setBanDuration] = useState<number | null>(null);
  const [banReason, setBanReason] = useState('');
  const [showBannedList, setShowBannedList] = useState(false);
  const [showViewerList, setShowViewerList] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  // Handle typing indicator
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewMessage(e.target.value);
    if (e.target.value.length > 0) {
      setTyping(true);
    } else {
      setTyping(false);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;

    if (!user) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour envoyer un message",
        variant: "destructive"
      });
      return;
    }

    const isQuestion = newMessage.startsWith('?') || newMessage.toLowerCase().startsWith('question:');
    const messageType = isQuestion ? 'question' : 'chat';
    const messageText = isQuestion ? newMessage.replace(/^\?|^question:/i, '').trim() : newMessage;

    const success = await sendMessage(messageText, messageType);
    if (success) {
      setNewMessage('');
      setTyping(false);
    }
  };

  const handleReaction = async (messageId: string, reaction: string) => {
    await addReaction(messageId, reaction);
    setShowReactions(null);
  };

  const handleBanUser = async () => {
    if (!showBanModal) return;

    await banUser(showBanModal.userId, banReason, banDuration || undefined);
    setShowBanModal(null);
    setBanDuration(null);
    setBanReason('');
  };

  const getMessageStyle = (msg: ChatMessage) => {
    if (msg.is_highlighted || msg.is_pinned) {
      return 'bg-gradient-to-r from-orange-500/20 to-yellow-500/20 border border-orange-500/30';
    }
    switch (msg.message_type) {
      case 'purchase':
        return 'bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30';
      case 'join':
        return 'bg-blue-500/10 text-blue-400 text-sm';
      case 'leave':
        return 'bg-slate-500/10 text-slate-400 text-sm';
      case 'question':
        return 'bg-purple-500/10 border border-purple-500/30';
      case 'system':
        return 'bg-slate-700/50 text-slate-300 text-sm italic';
      default:
        return '';
    }
  };

  const getReactionIcon = (reaction: string) => {
    switch (reaction) {
      case '👍': return <ThumbsUp className="w-3.5 h-3.5" />;
      case '❤️': return <Heart className="w-3.5 h-3.5" />;
      case '😂': return <Laugh className="w-3.5 h-3.5" />;
      case '🔥': return <Flame className="w-3.5 h-3.5" />;
      case '🎉': return <PartyPopper className="w-3.5 h-3.5" />;
      default: return reaction;
    }
  };

  const renderMessage = (msg: ChatMessage) => {
    const isOwnMessage = user?.id === msg.user_id;
    const reactionCount = Object.entries(msg.reactions || {}).reduce((acc, [_, users]) => acc + users.length, 0);

    return (
      <div 
        key={msg.id}
        className={`group relative p-2.5 rounded-lg transition-all ${getMessageStyle(msg)}`}
      >
        {/* Pinned indicator */}
        {msg.is_pinned && (
          <div className="flex items-center gap-1 mb-1 text-orange-400 text-xs">
            <Pin className="w-3 h-3" />
            <span>Message épinglé</span>
          </div>
        )}

        {/* Message content based on type */}
        {msg.message_type === 'join' ? (
          <p className="text-blue-400 text-sm">
            <span className="font-medium">{msg.user_name}</span> a rejoint le live
          </p>
        ) : msg.message_type === 'leave' ? (
          <p className="text-slate-400 text-sm">
            <span className="font-medium">{msg.user_name}</span> a quitté le live
          </p>
        ) : msg.message_type === 'purchase' ? (
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
              <Star className="w-3.5 h-3.5 text-white" />
            </div>
            <p className="text-green-400 text-sm">
              <span className="font-bold">{msg.user_name}</span> {msg.message}
            </p>
          </div>
        ) : msg.message_type === 'question' ? (
          <div>
            <div className="flex items-center gap-1.5 mb-1">
              <MessageCircle className="w-3.5 h-3.5 text-purple-400" />
              <span className="text-purple-400 text-xs font-medium">Question</span>
            </div>
            <div className="flex items-start gap-2">
              {msg.user_avatar ? (
                <img src={msg.user_avatar} alt="" className="w-6 h-6 rounded-full" />
              ) : (
                <div className="w-6 h-6 bg-purple-500/30 rounded-full flex items-center justify-center text-purple-300 text-xs font-bold">
                  {msg.user_name.charAt(0)}
                </div>
              )}
              <div className="flex-1">
                <span className="text-purple-400 font-medium text-sm">{msg.user_name}</span>
                <p className="text-white text-sm">{msg.message}</p>
              </div>
            </div>
          </div>
        ) : msg.message_type === 'system' ? (
          <p className="text-slate-400 text-sm text-center">{msg.message}</p>
        ) : (
          <div className="flex items-start gap-2">
            {msg.user_avatar ? (
              <img src={msg.user_avatar} alt="" className="w-6 h-6 rounded-full flex-shrink-0" />
            ) : (
              <div className="w-6 h-6 bg-orange-500/30 rounded-full flex items-center justify-center text-orange-300 text-xs font-bold flex-shrink-0">
                {msg.user_name.charAt(0)}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <span className={`font-medium text-sm ${
                msg.user_name === sellerName ? 'text-orange-400' : 'text-slate-300'
              }`}>
                {msg.user_name}
                {msg.user_name === sellerName && (
                  <span className="ml-1.5 px-1.5 py-0.5 bg-orange-500/20 text-orange-400 text-xs rounded">Vendeur</span>
                )}
              </span>
              <p className="text-white text-sm break-words">{msg.message}</p>
            </div>
          </div>
        )}

        {/* Reactions display */}
        {reactionCount > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {Object.entries(msg.reactions || {}).map(([reaction, users]) => (
              users.length > 0 && (
                <button
                  key={reaction}
                  onClick={() => handleReaction(msg.id, reaction)}
                  className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs transition-colors ${
                    users.includes(user?.id || '')
                      ? 'bg-orange-500/30 text-orange-300'
                      : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <span>{reaction}</span>
                  <span>{users.length}</span>
                </button>
              )
            ))}
          </div>
        )}

        {/* Action buttons (visible on hover) */}
        {user && msg.message_type === 'chat' && (
          <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
            {/* Quick reaction button */}
            <div className="relative">
              <button
                onClick={() => setShowReactions(showReactions === msg.id ? null : msg.id)}
                className="p-1 bg-slate-700/80 hover:bg-slate-600 rounded text-slate-300"
              >
                <Heart className="w-3.5 h-3.5" />
              </button>
              
              {/* Reaction picker */}
              {showReactions === msg.id && (
                <div className="absolute bottom-full right-0 mb-1 p-1.5 bg-slate-800 rounded-lg shadow-xl border border-slate-700 flex gap-1 z-10">
                  {quickReactions.map(reaction => (
                    <button
                      key={reaction}
                      onClick={() => handleReaction(msg.id, reaction)}
                      className="p-1.5 hover:bg-slate-700 rounded transition-colors text-sm"
                    >
                      {reaction}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* More options (for owner or own messages) */}
            {(isStreamOwner || isOwnMessage) && (
              <div className="relative">
                <button
                  onClick={() => setShowMessageMenu(showMessageMenu === msg.id ? null : msg.id)}
                  className="p-1 bg-slate-700/80 hover:bg-slate-600 rounded text-slate-300"
                >
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>

                {showMessageMenu === msg.id && (
                  <div className="absolute bottom-full right-0 mb-1 py-1 bg-slate-800 rounded-lg shadow-xl border border-slate-700 min-w-[140px] z-10">
                    {isStreamOwner && !msg.is_pinned && (
                      <button
                        onClick={() => { pinMessage(msg.id); setShowMessageMenu(null); }}
                        className="w-full px-3 py-1.5 text-left text-sm text-slate-300 hover:bg-slate-700 flex items-center gap-2"
                      >
                        <Pin className="w-3.5 h-3.5" />
                        Épingler
                      </button>
                    )}
                    {isStreamOwner && msg.is_pinned && (
                      <button
                        onClick={() => { unpinMessage(msg.id); setShowMessageMenu(null); }}
                        className="w-full px-3 py-1.5 text-left text-sm text-slate-300 hover:bg-slate-700 flex items-center gap-2"
                      >
                        <Pin className="w-3.5 h-3.5" />
                        Désépingler
                      </button>
                    )}
                    {isStreamOwner && !msg.is_highlighted && (
                      <button
                        onClick={() => { highlightMessage(msg.id, true); setShowMessageMenu(null); }}
                        className="w-full px-3 py-1.5 text-left text-sm text-slate-300 hover:bg-slate-700 flex items-center gap-2"
                      >
                        <Star className="w-3.5 h-3.5" />
                        Mettre en avant
                      </button>
                    )}
                    <button
                      onClick={() => { deleteMessage(msg.id); setShowMessageMenu(null); }}
                      className="w-full px-3 py-1.5 text-left text-sm text-red-400 hover:bg-slate-700 flex items-center gap-2"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Supprimer
                    </button>
                    {isStreamOwner && !isOwnMessage && (
                      <button
                        onClick={() => { 
                          setShowBanModal({ userId: msg.user_id, userName: msg.user_name }); 
                          setShowMessageMenu(null); 
                        }}
                        className="w-full px-3 py-1.5 text-left text-sm text-red-400 hover:bg-slate-700 flex items-center gap-2"
                      >
                        <Ban className="w-3.5 h-3.5" />
                        Bannir
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header with viewer count */}
      <div className="p-3 border-b border-slate-700 bg-slate-800/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5 text-orange-400" />
          <span className="text-white font-medium">Chat en direct</span>
          <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded-full flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
            En temps réel
          </span>
        </div>
        <button
          onClick={() => setShowViewerList(true)}
          className="flex items-center gap-1.5 px-2 py-1 bg-slate-700/50 hover:bg-slate-700 rounded-lg text-slate-300 text-sm transition-colors"
        >
          <Eye className="w-4 h-4" />
          <span>{viewerCount}</span>
        </button>
      </div>

      {/* Pinned messages */}
      {pinnedMessages.length > 0 && (
        <div className="p-3 border-b border-slate-700 bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2 text-orange-400 text-xs font-medium">
            <Pin className="w-3.5 h-3.5" />
            <span>Messages épinglés ({pinnedMessages.length})</span>
          </div>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {pinnedMessages.map(msg => (
              <div key={msg.id} className="p-2 bg-orange-500/10 rounded-lg border border-orange-500/20">
                <div className="flex items-center gap-2">
                  <span className="text-orange-400 font-medium text-sm">{msg.user_name}</span>
                  {isStreamOwner && (
                    <button
                      onClick={() => unpinMessage(msg.id)}
                      className="ml-auto p-1 hover:bg-orange-500/20 rounded"
                    >
                      <X className="w-3 h-3 text-orange-400" />
                    </button>
                  )}
                </div>
                <p className="text-white text-sm">{msg.message}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Moderation bar for stream owner */}
      {isStreamOwner && (
        <div className="p-2 border-b border-slate-700 bg-slate-800/30 flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-400 text-xs">
            <ShieldAlert className="w-4 h-4" />
            <span>Mode modérateur</span>
          </div>
          <button
            onClick={() => setShowBannedList(true)}
            className="px-2 py-1 text-xs bg-slate-700 hover:bg-slate-600 rounded text-slate-300 flex items-center gap-1"
          >
            <Ban className="w-3 h-3" />
            Bannis ({bannedUsers.length})
          </button>
        </div>
      )}

      {/* Chat messages */}
      <div ref={chatRef} className="flex-1 overflow-y-auto p-3 space-y-2">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-500">
            <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p className="text-sm">Chargement des messages...</p>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-500">
            <MessageCircle className="w-12 h-12 mb-2 opacity-50" />
            <p className="text-sm">Soyez le premier à envoyer un message!</p>
          </div>
        ) : (
          messages.map(renderMessage)
        )}
      </div>

      {/* Typing indicator */}
      <TypingIndicator users={typingUsers} />

      {/* Banned notice */}
      {isBanned && (
        <div className="p-3 bg-red-500/10 border-t border-red-500/30">
          <div className="flex items-center gap-2 text-red-400 text-sm">
            <AlertTriangle className="w-4 h-4" />
            <span>Vous avez été banni de ce chat</span>
          </div>
        </div>
      )}

      {/* Chat input */}
      <div className="p-3 border-t border-slate-700">
        <div className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={handleInputChange}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            onBlur={() => setTyping(false)}
            placeholder={
              isBanned 
                ? "Vous êtes banni" 
                : user 
                  ? "Envoyer un message... (? pour question)" 
                  : "Connectez-vous pour chatter"
            }
            disabled={!user || isBanned}
            className="flex-1 px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 disabled:opacity-50 text-sm"
          />
          <button
            onClick={handleSendMessage}
            disabled={!user || !newMessage.trim() || isBanned}
            className="px-4 py-2.5 bg-gradient-to-r from-orange-500 to-yellow-500 text-white rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
        
        {/* Quick reactions bar */}
        {user && !isBanned && (
          <div className="flex items-center gap-1 mt-2">
            <span className="text-slate-500 text-xs mr-2">Réactions rapides:</span>
            {quickReactions.slice(0, 5).map(reaction => (
              <button
                key={reaction}
                onClick={() => {
                  // Send reaction as a message
                  sendMessage(reaction, 'chat');
                }}
                className="p-1.5 hover:bg-slate-700 rounded transition-colors"
              >
                {reaction}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Ban Modal */}
      {showBanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="bg-slate-800 rounded-2xl p-6 max-w-md w-full mx-4 border border-slate-700">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-red-500/20 rounded-full flex items-center justify-center">
                <Ban className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold">Bannir {showBanModal.userName}</h3>
                <p className="text-slate-400 text-sm">Cette personne ne pourra plus envoyer de messages</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 text-sm mb-2">Durée du bannissement</label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: '5 min', value: 5 },
                    { label: '15 min', value: 15 },
                    { label: '1 heure', value: 60 },
                    { label: 'Permanent', value: null }
                  ].map(option => (
                    <button
                      key={option.label}
                      onClick={() => setBanDuration(option.value)}
                      className={`py-2 px-3 rounded-lg text-sm transition-colors ${
                        banDuration === option.value
                          ? 'bg-red-500 text-white'
                          : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 text-sm mb-2">Raison (optionnel)</label>
                <input
                  type="text"
                  value={banReason}
                  onChange={(e) => setBanReason(e.target.value)}
                  placeholder="Ex: Spam, langage inapproprié..."
                  className="w-full px-4 py-2.5 bg-slate-700 border border-slate-600 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowBanModal(null)}
                className="flex-1 py-2.5 bg-slate-700 text-slate-300 rounded-xl hover:bg-slate-600 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleBanUser}
                className="flex-1 py-2.5 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-colors"
              >
                Bannir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Banned Users List Modal */}
      {showBannedList && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="bg-slate-800 rounded-2xl p-6 max-w-md w-full mx-4 border border-slate-700 max-h-[80vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">Utilisateurs bannis</h3>
              <button
                onClick={() => setShowBannedList(false)}
                className="p-1 hover:bg-slate-700 rounded"
              >
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto">
              {bannedUsers.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <Ban className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Aucun utilisateur banni</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {bannedUsers.map(banned => (
                    <div key={banned.id} className="p-3 bg-slate-700/50 rounded-lg flex items-center justify-between">
                      <div>
                        <p className="text-white text-sm font-medium">ID: {banned.user_id.slice(0, 8)}...</p>
                        {banned.reason && (
                          <p className="text-slate-400 text-xs">Raison: {banned.reason}</p>
                        )}
                        {banned.banned_until && (
                          <div className="flex items-center gap-1 text-slate-400 text-xs mt-1">
                            <Clock className="w-3 h-3" />
                            <span>Jusqu'à {new Date(banned.banned_until).toLocaleString('fr-FR')}</span>
                          </div>
                        )}
                      </div>
                      <button
                        onClick={() => unbanUser(banned.user_id)}
                        className="px-3 py-1.5 bg-green-500/20 text-green-400 rounded-lg text-sm hover:bg-green-500/30 transition-colors"
                      >
                        Débannir
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Viewer List Modal */}
      {showViewerList && (
        <ViewerList users={presentUsers} onClose={() => setShowViewerList(false)} />
      )}
    </div>
  );
};

export default RealtimeLiveChat;
