import React, { useState } from 'react';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin, Send } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast({
        title: "Inscription réussie!",
        description: "Vous recevrez nos dernières actualités et offres."
      });
      setEmail('');
    }
  };
  const footerLinks = {
    company: [{
      label: 'À propos',
      href: '#'
    }, {
      label: 'Comment ça marche',
      href: '#'
    }, {
      label: 'Carrières',
      href: '#'
    }, {
      label: 'Presse',
      href: '#'
    }],
    support: [{
      label: 'Centre d\'aide',
      href: '#'
    }, {
      label: 'Sécurité',
      href: '#'
    }, {
      label: 'Signaler un problème',
      href: '#'
    }, {
      label: 'Contact',
      href: '#'
    }],
    sellers: [{
      label: 'Devenir vendeur',
      href: '#subscriptions'
    }, {
      label: 'Guide du vendeur',
      href: '#'
    }, {
      label: 'Tarifs',
      href: '#'
    }, {
      label: 'Conseils de vente',
      href: '#'
    }],
    legal: [{
      label: 'Conditions d\'utilisation',
      href: '#'
    }, {
      label: 'Politique de confidentialité',
      href: '#'
    }, {
      label: 'Politique de cookies',
      href: '#'
    }, {
      label: 'Mentions légales',
      href: '#'
    }]
  };
  const socialLinks = [{
    icon: Facebook,
    href: '#',
    label: 'Facebook'
  }, {
    icon: Instagram,
    href: '#',
    label: 'Instagram'
  }, {
    icon: Twitter,
    href: '#',
    label: 'Twitter'
  }, {
    icon: Youtube,
    href: '#',
    label: 'Youtube'
  }];
  return <footer className="bg-slate-950 border-t border-slate-800">
      {/* Newsletter Section */}
      <div className="border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-center lg:text-left">
              <h3 className="text-2xl font-bold text-white mb-2">
                Restez informé des nouveaux vendeurs
              </h3>
              <p className="text-slate-400">
                Recevez les dernières actualités et découvrez de nouveaux vendeurs chaque semaine.
              </p>
            </div>
            <form onSubmit={handleNewsletterSubmit} className="flex gap-3 w-full lg:w-auto">
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Votre email" className="flex-1 lg:w-72 px-5 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500" required />
              <button type="submit" className="px-6 py-3 bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all flex items-center gap-2">
                <Send className="w-5 h-5" />
                <span className="hidden sm:inline">S'inscrire</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-3 lg:col-span-2"><div className="flex items-center gap-3 mb-4">
              <img src="https://d64gsuwffb70l.cloudfront.net/697513d586d0577d49bce648_1769467497622_9f8e043e.png" alt="PITCH Logo" className="h-10 w-auto" />
            </div><p className="text-slate-400 text-sm mb-6 max-w-xs">
              La première plateforme de live shopping en Côte d'Ivoire. 
              Connectez-vous directement avec les vendeurs et achetez en toute confiance.
            </p>{/* Contact Info */}<div className="space-y-3">
              <a href="mailto:contact@livepitch.ci" className="flex items-center gap-3 text-slate-400 hover:text-red-500 transition-colors text-sm">
                <Mail className="w-4 h-4" />
                contact@livepitch.ci
              </a>
              <a href="tel:+2250700000000" className="flex items-center gap-3 text-slate-400 hover:text-red-500 transition-colors text-sm">
                <Phone className="w-4 h-4" />
                +225 07 00 00 00 00
              </a>
              <div className="flex items-center gap-3 text-slate-400 text-sm">
                <MapPin className="w-4 h-4" />
                Abidjan, Côte d'Ivoire
              </div>
            </div>{/* Social Links */}<div className="flex gap-3 mt-6">
              {socialLinks.map(social => <a key={social.label} href={social.href} aria-label={social.label} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center text-slate-400 hover:bg-red-500 hover:text-white transition-all">
                  <social.icon className="w-5 h-5" />
                </a>)}
            </div>La première plateforme de live shopping en Côte d'Ivoire. Connectez-vous directement avec les vendeurs et achetez en toute confiance!!</div>

          {/* Links Columns */}
          <div>
            <h4 className="text-white font-semibold mb-4">Entreprise</h4>
            <ul className="space-y-3">
              {footerLinks.company.map(link => <li key={link.label}>
                  <a href={link.href} className="text-slate-400 hover:text-red-500 transition-colors text-sm">
                    {link.label}
                  </a>
                </li>)}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Support</h4>
            <ul className="space-y-3">
              {footerLinks.support.map(link => <li key={link.label}>
                  <a href={link.href} className="text-slate-400 hover:text-red-500 transition-colors text-sm">
                    {link.label}
                  </a>
                </li>)}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Vendeurs</h4>
            <ul className="space-y-3">
              {footerLinks.sellers.map(link => <li key={link.label}>
                  <a href={link.href} className="text-slate-400 hover:text-red-500 transition-colors text-sm">
                    {link.label}
                  </a>
                </li>)}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Légal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map(link => <li key={link.label}>
                  <a href={link.href} className="text-slate-400 hover:text-red-500 transition-colors text-sm">
                    {link.label}
                  </a>
                </li>)}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-slate-500 text-sm text-center md:text-left">
              © 2026 PITCH. Tous droits réservés. Le Live Devient un Métier.
            </p>
            <div className="flex items-center gap-6">
              <span className="text-slate-500 text-sm">Fait avec passion en Côte d'Ivoire</span>
            </div>
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;