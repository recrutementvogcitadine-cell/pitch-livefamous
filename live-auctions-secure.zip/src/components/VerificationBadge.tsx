import React from 'react';
import { CheckCircle, Clock, XCircle, Shield } from 'lucide-react';

interface VerificationBadgeProps {
  status: 'verified' | 'pending' | 'rejected' | 'none';
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}

const VerificationBadge: React.FC<VerificationBadgeProps> = ({ 
  status, 
  size = 'md', 
  showLabel = false,
  className = ''
}) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  const labelSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };

  const badgeConfig = {
    verified: {
      icon: <CheckCircle className={sizeClasses[size]} />,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/20',
      label: 'Vérifié',
      tooltip: 'Vendeur vérifié par PITCH'
    },
    pending: {
      icon: <Clock className={sizeClasses[size]} />,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/20',
      label: 'En attente',
      tooltip: 'Vérification en cours'
    },
    rejected: {
      icon: <XCircle className={sizeClasses[size]} />,
      color: 'text-red-500',
      bgColor: 'bg-red-500/20',
      label: 'Refusé',
      tooltip: 'Vérification refusée'
    },
    none: {
      icon: <Shield className={sizeClasses[size]} />,
      color: 'text-slate-500',
      bgColor: 'bg-slate-500/20',
      label: 'Non vérifié',
      tooltip: 'Vendeur non vérifié'
    }
  };

  const config = badgeConfig[status];

  if (status === 'none' && !showLabel) {
    return null;
  }

  return (
    <div 
      className={`inline-flex items-center gap-1.5 ${className}`}
      title={config.tooltip}
    >
      <span className={`${config.color}`}>
        {config.icon}
      </span>
      {showLabel && (
        <span className={`${config.color} ${labelSizeClasses[size]} font-medium`}>
          {config.label}
        </span>
      )}
    </div>
  );
};

// Compact badge for cards
export const VerificationBadgeCompact: React.FC<{ verified: boolean; className?: string }> = ({ 
  verified, 
  className = '' 
}) => {
  if (!verified) return null;
  
  return (
    <div 
      className={`inline-flex items-center justify-center w-5 h-5 bg-blue-500 rounded-full ${className}`}
      title="Vendeur vérifié"
    >
      <CheckCircle className="w-3 h-3 text-white" />
    </div>
  );
};

// Full verification badge with background
export const VerificationBadgeFull: React.FC<{ 
  status: 'verified' | 'pending' | 'rejected' | 'none';
  className?: string;
}> = ({ status, className = '' }) => {
  const config = {
    verified: {
      icon: <CheckCircle className="w-4 h-4" />,
      text: 'Vendeur Vérifié',
      bgColor: 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20',
      borderColor: 'border-blue-500/30',
      textColor: 'text-blue-400'
    },
    pending: {
      icon: <Clock className="w-4 h-4" />,
      text: 'Vérification en cours',
      bgColor: 'bg-gradient-to-r from-yellow-500/20 to-orange-500/20',
      borderColor: 'border-yellow-500/30',
      textColor: 'text-yellow-400'
    },
    rejected: {
      icon: <XCircle className="w-4 h-4" />,
      text: 'Vérification refusée',
      bgColor: 'bg-gradient-to-r from-red-500/20 to-pink-500/20',
      borderColor: 'border-red-500/30',
      textColor: 'text-red-400'
    },
    none: {
      icon: <Shield className="w-4 h-4" />,
      text: 'Non vérifié',
      bgColor: 'bg-slate-500/20',
      borderColor: 'border-slate-500/30',
      textColor: 'text-slate-400'
    }
  };

  const c = config[status];

  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full ${c.bgColor} border ${c.borderColor} ${className}`}>
      <span className={c.textColor}>{c.icon}</span>
      <span className={`${c.textColor} text-sm font-medium`}>{c.text}</span>
    </div>
  );
};

export default VerificationBadge;
