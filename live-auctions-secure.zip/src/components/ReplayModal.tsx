import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  X, Users, Heart, Share2, Eye, Clock,
  CheckCircle, Volume2, VolumeX, Maximize2, Minimize2,
  MessageCircle, Package, Star, Phone, ShoppingBag,
  Play, Pause, SkipBack, SkipForward, RotateCcw,
  ChevronDown, ChevronUp, Settings, Film, List, ChevronRight
} from 'lucide-react';
import { formatPrice } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { useLiveStream, LiveStreamData, StreamProduct, ChatMessage } from '@/hooks/useLiveStream';
import { useRecordings, Chapter } from '@/hooks/useRecordings';
import OrderFormModal from './OrderFormModal';
import FollowButton from './FollowButton';
import AuthModal from './AuthModal';

interface ReplayModalProps {
  isOpen: boolean;
  onClose: () => void;
  replayId: string | null;
}

const ReplayModal: React.FC<ReplayModalProps> = ({ isOpen, onClose, replayId }) => {
  const { user } = useAuth();
  const { fetchReplayWithMessages, incrementReplayViews, fetchReplayChatByOffset } = useLiveStream();
  const { getChapters } = useRecordings();
  
  const [replay, setReplay] = useState<LiveStreamData | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [products, setProducts] = useState<StreamProduct[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [isMuted, setIsMuted] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'products' | 'chapters'>('products');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [visibleMessages, setVisibleMessages] = useState<ChatMessage[]>([]);
  const [isProductsExpanded, setIsProductsExpanded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showSettings, setShowSettings] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [currentChapter, setCurrentChapter] = useState<Chapter | null>(null);
  
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [selectedProductForOrder, setSelectedProductForOrder] = useState<any>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastChatUpdateRef = useRef<number>(0);

  // Default seller phone for demo
  const sellerPhone = '+2250700000000';

  useEffect(() => {
    if (isOpen && replayId) {
      loadReplay();
      document.body.style.overflow = 'hidden';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen, replayId]);

  // Sync chat messages with video playback and update current chapter
  useEffect(() => {
    if (!replay) return;

    const currentTimeMs = currentTime * 1000;
    
    // Update current chapter
    if (chapters.length > 0) {
      const current = [...chapters]
        .reverse()
        .find(ch => ch.timestamp_seconds <= currentTime);
      setCurrentChapter(current || null);
    }

    if (messages.length === 0) return;
    
    // Only update if time has changed significantly (100ms threshold)
    if (Math.abs(currentTimeMs - lastChatUpdateRef.current) < 100) return;
    lastChatUpdateRef.current = currentTimeMs;

    // Filter messages that should be visible at current playback time
    const visible = messages.filter(msg => {
      const offsetMs = msg.timestamp_offset_ms || 0;
      return offsetMs <= currentTimeMs;
    });
    
    setVisibleMessages(visible);
    
    // Auto-scroll chat to bottom
    if (chatContainerRef.current) {
      setTimeout(() => {
        if (chatContainerRef.current) {
          chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
      }, 50);
    }
  }, [currentTime, messages, replay, chapters]);

  const loadReplay = async () => {
    if (!replayId) return;
    
    setLoading(true);
    try {
      const { replay: replayData, messages: chatMessages } = await fetchReplayWithMessages(replayId);
      
      if (replayData) {
        setReplay(replayData);
        setMessages(chatMessages);
        setProducts(replayData.live_stream_products || []);
        setDuration(replayData.duration_seconds || 0);
        
        // Fetch chapters
        const chaptersData = await getChapters({ liveStreamId: replayId });
        setChapters(chaptersData);
        
        // Increment view count
        await incrementReplayViews(replayId);
      }
    } catch (err) {
      console.error('Error loading replay:', err);
      toast({
        title: "Erreur",
        description: "Impossible de charger la rediffusion",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };




  const handleVideoTimeUpdate = useCallback(() => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  }, []);

  const handleVideoLoadedMetadata = useCallback(() => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration || replay?.duration_seconds || 0);
    }
  }, [replay]);

  const handleVideoEnded = useCallback(() => {
    setIsPlaying(false);
  }, []);

  const handleVideoWaiting = useCallback(() => {
    setBuffering(true);
  }, []);

  const handleVideoCanPlay = useCallback(() => {
    setBuffering(false);
  }, []);

  const togglePlayback = useCallback(() => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  const seekTo = useCallback((time: number) => {
    if (!videoRef.current) return;
    const clampedTime = Math.max(0, Math.min(time, duration));
    videoRef.current.currentTime = clampedTime;
    setCurrentTime(clampedTime);
  }, [duration]);

  const skipForward = () => seekTo(currentTime + 10);
  const skipBackward = () => seekTo(currentTime - 10);
  
  const restart = useCallback(() => {
    seekTo(0);
    setVisibleMessages([]);
    lastChatUpdateRef.current = 0;
  }, [seekTo]);

  const handleProgressClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    seekTo(percentage * duration);
  }, [duration, seekTo]);

  const toggleMute = useCallback(() => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  }, [isMuted]);

  const toggleFullscreen = useCallback(async () => {
    if (!containerRef.current) return;
    
    try {
      if (!document.fullscreenElement) {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch (err) {
      console.error('Fullscreen error:', err);
    }
  }, []);

  const changePlaybackRate = useCallback((rate: number) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
      setPlaybackRate(rate);
    }
    setShowSettings(false);
  }, []);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleWhatsApp = (product: StreamProduct) => {
    const message = `Bonjour, je suis intéressé(e) par "${product.product_name}" à ${formatPrice(product.product_price)} vu sur votre rediffusion. Est-il toujours disponible ?`;
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${sellerPhone}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleCall = () => {
    window.location.href = `tel:${sellerPhone}`;
  };

  const handleOrder = (product: StreamProduct) => {
    if (!user) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour passer une commande",
        variant: "destructive"
      });
      return;
    }

    setSelectedProductForOrder({
      id: product.product_id,
      name: product.product_name,
      price: product.product_price,
      originalPrice: product.product_original_price,
      image: product.product_image || '',
      seller: replay?.seller?.full_name || replay?.profiles?.full_name || 'Vendeur',
      sellerPhone: sellerPhone
    });
    setShowOrderModal(true);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: replay?.title,
        text: `Regardez cette rediffusion sur PITCH: ${replay?.title}`,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Lien copié!",
        description: "Le lien de la rediffusion a été copié"
      });
    }
  };

  const getMessageTypeStyle = (type: string) => {
    switch (type) {
      case 'purchase':
        return 'bg-green-500/20 border-green-500/30';
      case 'join':
        return 'bg-blue-500/10 border-blue-500/20';
      case 'highlight':
        return 'bg-orange-500/20 border-orange-500/30';
      case 'question':
        return 'bg-purple-500/20 border-purple-500/30';
      default:
        return 'bg-slate-800/50 border-slate-700/50';
    }
  };

  const getMessageTimestamp = (msg: ChatMessage) => {
    const offsetMs = msg.timestamp_offset_ms || 0;
    return formatTime(offsetMs / 1000);
  };

  if (!isOpen) return null;

  if (loading) {
    return (
      <div 
        className="fixed inset-0 z-[9999] bg-black flex items-center justify-center"
        style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
      >
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-white">Chargement de la rediffusion...</p>
        </div>
      </div>
    );
  }

  if (!replay) {
    return (
      <div 
        className="fixed inset-0 z-[9999] bg-black flex items-center justify-center"
        style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
      >
        <div className="text-center">
          <Film className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <p className="text-white mb-4">Rediffusion non disponible</p>
          <button onClick={onClose} className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
            Fermer
          </button>
        </div>
      </div>
    );
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
  const hasVideoUrl = replay.replay_url && replay.replay_url.length > 0;
  const sellerName = replay.seller?.full_name || replay.profiles?.full_name || 'Vendeur';
  const sellerAvatar = replay.seller?.avatar_url || replay.profiles?.avatar_url || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100';
  const isVerified = replay.seller?.is_verified || replay.profiles?.is_verified || false;

  return (
    <>
      {/* Main Modal Overlay */}
      <div 
        ref={containerRef}
        className="fixed inset-0 z-[9999] bg-black"
        style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
      >
        {/* Mobile Layout (column) / Desktop Layout (row) */}
        <div className="h-full w-full flex flex-col lg:flex-row">
          
          {/* Video Section */}
          <div className="relative flex-1 min-h-0 lg:min-h-full bg-black group">
            {/* Header Overlay */}
            <div className="absolute top-0 left-0 right-0 z-20 p-3 md:p-4 bg-gradient-to-b from-black/90 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="flex items-center justify-between">
                {/* Seller Info */}
                <div className="flex items-center gap-2 md:gap-3">
                  <div className="relative flex-shrink-0">
                    <img 
                      src={sellerAvatar} 
                      alt={sellerName}
                      className="w-10 h-10 md:w-12 md:h-12 rounded-full border-2 border-purple-500 object-cover"
                    />
                    {isVerified && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 md:w-5 md:h-5 bg-blue-500 rounded-full flex items-center justify-center border-2 border-black">
                        <CheckCircle className="w-2.5 h-2.5 md:w-3 md:h-3 text-white" />
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-white font-bold text-sm md:text-base truncate max-w-[120px] md:max-w-none">{sellerName}</h3>
                      {isVerified && (
                        <span className="hidden md:inline px-2 py-0.5 bg-blue-500/20 text-blue-400 text-xs rounded-full">Vérifié</span>
                      )}
                    </div>
                    <p className="text-slate-400 text-xs md:text-sm truncate max-w-[150px] md:max-w-[250px]">{replay.title}</p>
                  </div>
                  
                  {/* Follow Button */}
                  <div className="hidden sm:block">
                    <FollowButton
                      sellerId={replay.seller_id}
                      sellerName={sellerName}
                      variant="compact"
                      onAuthRequired={() => setShowAuthModal(true)}
                    />
                  </div>
                </div>

                {/* Right Side: Replay Badge, Views, Close */}
                <div className="flex items-center gap-2">
                  {/* Replay Badge */}
                  <div className="flex items-center gap-1.5 px-2 md:px-3 py-1 md:py-1.5 bg-purple-500 rounded-full">
                    <RotateCcw className="w-3 h-3 md:w-4 md:h-4 text-white" />
                    <span className="text-white text-xs md:text-sm font-bold hidden sm:inline">REPLAY</span>
                  </div>

                  {/* Views */}
                  <div className="flex items-center gap-1.5 px-2 md:px-3 py-1 md:py-1.5 bg-white/10 backdrop-blur rounded-full">
                    <Eye className="w-3 h-3 md:w-4 md:h-4 text-white" />
                    <span className="text-white text-xs md:text-sm font-medium">{(replay.replay_views || 0).toLocaleString()}</span>
                  </div>

                  {/* Close Button */}
                  <button
                    onClick={onClose}
                    className="p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
                  >
                    <X className="w-5 h-5 md:w-6 md:h-6 text-white" />
                  </button>
                </div>
              </div>
            </div>

            {/* Video Content */}
            <div className="absolute inset-0 flex items-center justify-center">
              {hasVideoUrl ? (
                <video
                  ref={videoRef}
                  src={replay.replay_url}
                  className="w-full h-full object-contain"
                  poster={replay.replay_thumbnail || replay.thumbnail_url}
                  onTimeUpdate={handleVideoTimeUpdate}
                  onLoadedMetadata={handleVideoLoadedMetadata}
                  onEnded={handleVideoEnded}
                  onWaiting={handleVideoWaiting}
                  onCanPlay={handleVideoCanPlay}
                  onClick={togglePlayback}
                  playsInline
                />
              ) : (
                <>
                  <img 
                    src={replay.replay_thumbnail || replay.thumbnail_url || 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800'}
                    alt={replay.title}
                    className="w-full h-full object-cover opacity-60"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                    <div className="text-center">
                      <Film className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                      <p className="text-white text-lg font-medium">Vidéo en cours de traitement</p>
                      <p className="text-slate-400 text-sm mt-2">La rediffusion sera bientôt disponible</p>
                    </div>
                  </div>
                </>
              )}
              
              {/* Buffering indicator */}
              {buffering && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                  <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
              
              {/* Play/Pause Overlay (when paused) */}
              {!isPlaying && hasVideoUrl && !buffering && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <button
                    onClick={togglePlayback}
                    className="w-16 h-16 md:w-20 md:h-20 bg-purple-500/80 hover:bg-purple-500 rounded-full flex items-center justify-center transition-all transform hover:scale-110"
                  >
                    <Play className="w-8 h-8 md:w-10 md:h-10 text-white ml-1" />
                  </button>
                </div>
              )}
            </div>

            {/* Playback Controls */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-3 md:p-4 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              {/* Progress Bar */}
              <div className="mb-3 md:mb-4">
                <div 
                  className="h-1.5 md:h-2 bg-white/20 rounded-full cursor-pointer relative group/progress"
                  onClick={handleProgressClick}
                >
                  {/* Buffered progress (if available) */}
                  <div 
                    className="absolute h-full bg-white/30 rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                  {/* Played progress */}
                  <div 
                    className="absolute h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                    style={{ width: `${progress}%` }}
                  >
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 md:w-4 md:h-4 bg-white rounded-full shadow-lg opacity-0 group-hover/progress:opacity-100 transition-opacity"></div>
                  </div>
                </div>
                <div className="flex justify-between text-white/60 text-xs md:text-sm mt-1">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              {/* Control Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 md:gap-2">
                  <button
                    onClick={restart}
                    className="p-2 md:p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
                    title="Recommencer"
                  >
                    <RotateCcw className="w-4 h-4 md:w-5 md:h-5 text-white" />
                  </button>
                  <button
                    onClick={skipBackward}
                    className="p-2 md:p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
                    title="-10s"
                  >
                    <SkipBack className="w-4 h-4 md:w-5 md:h-5 text-white" />
                  </button>
                  <button
                    onClick={togglePlayback}
                    className="p-3 md:p-4 bg-purple-500 rounded-full hover:bg-purple-600 transition-colors"
                    disabled={!hasVideoUrl}
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5 md:w-6 md:h-6 text-white" />
                    ) : (
                      <Play className="w-5 h-5 md:w-6 md:h-6 text-white ml-0.5" />
                    )}
                  </button>
                  <button
                    onClick={skipForward}
                    className="p-2 md:p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
                    title="+10s"
                  >
                    <SkipForward className="w-4 h-4 md:w-5 md:h-5 text-white" />
                  </button>
                  <button
                    onClick={toggleMute}
                    className="p-2 md:p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
                  >
                    {isMuted ? (
                      <VolumeX className="w-4 h-4 md:w-5 md:h-5 text-white" />
                    ) : (
                      <Volume2 className="w-4 h-4 md:w-5 md:h-5 text-white" />
                    )}
                  </button>
                </div>

                <div className="flex items-center gap-1 md:gap-2">
                  {/* Playback Speed */}
                  <div className="relative">
                    <button
                      onClick={() => setShowSettings(!showSettings)}
                      className="p-2 md:p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors flex items-center gap-1"
                    >
                      <Settings className="w-4 h-4 md:w-5 md:h-5 text-white" />
                      <span className="text-white text-xs hidden md:inline">{playbackRate}x</span>
                    </button>
                    
                    {showSettings && (
                      <div className="absolute bottom-full right-0 mb-2 bg-slate-800 rounded-lg shadow-xl border border-slate-700 overflow-hidden">
                        <div className="p-2 border-b border-slate-700">
                          <p className="text-slate-400 text-xs">Vitesse</p>
                        </div>
                        {[0.5, 0.75, 1, 1.25, 1.5, 2].map(rate => (
                          <button
                            key={rate}
                            onClick={() => changePlaybackRate(rate)}
                            className={`w-full px-4 py-2 text-left text-sm hover:bg-slate-700 transition-colors ${
                              playbackRate === rate ? 'text-purple-400 bg-purple-500/10' : 'text-white'
                            }`}
                          >
                            {rate}x
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <button
                    onClick={() => setIsLiked(!isLiked)}
                    className={`p-2 md:p-3 rounded-full transition-all ${
                      isLiked 
                        ? 'bg-red-500 text-white' 
                        : 'bg-white/10 backdrop-blur text-white hover:bg-white/20'
                    }`}
                  >
                    <Heart className={`w-4 h-4 md:w-5 md:h-5 ${isLiked ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={handleShare}
                    className="p-2 md:p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
                  >
                    <Share2 className="w-4 h-4 md:w-5 md:h-5 text-white" />
                  </button>
                  <button 
                    onClick={toggleFullscreen}
                    className="hidden md:block p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
                  >
                    {isFullscreen ? (
                      <Minimize2 className="w-5 h-5 text-white" />
                    ) : (
                      <Maximize2 className="w-5 h-5 text-white" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Products, Chat & Chapters */}
          <div className="w-full lg:w-96 bg-slate-900 flex flex-col border-t lg:border-t-0 lg:border-l border-slate-800 max-h-[50vh] lg:max-h-full">
            {/* Tabs */}
            <div className="flex border-b border-slate-800 flex-shrink-0">
              <button
                onClick={() => setActiveTab('products')}
                className={`flex-1 flex items-center justify-center gap-1 py-3 md:py-4 font-medium transition-colors text-xs md:text-sm ${
                  activeTab === 'products' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>Produits</span>
              </button>
              <button
                onClick={() => setActiveTab('chat')}
                className={`flex-1 flex items-center justify-center gap-1 py-3 md:py-4 font-medium transition-colors text-xs md:text-sm ${
                  activeTab === 'chat' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat</span>
              </button>
              {chapters.length > 0 && (
                <button
                  onClick={() => setActiveTab('chapters')}
                  className={`flex-1 flex items-center justify-center gap-1 py-3 md:py-4 font-medium transition-colors text-xs md:text-sm ${
                    activeTab === 'chapters' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <List className="w-4 h-4" />
                  <span>Chapitres</span>
                </button>
              )}
            </div>

            {/* Current Chapter Indicator */}
            {currentChapter && activeTab !== 'chapters' && (
              <div 
                className="px-4 py-2 bg-yellow-500/10 border-b border-yellow-500/20 flex-shrink-0 cursor-pointer hover:bg-yellow-500/20 transition-colors"
                onClick={() => setActiveTab('chapters')}
              >
                <p className="text-yellow-400 text-sm flex items-center gap-2">
                  <List className="w-4 h-4" />
                  <span className="truncate">{currentChapter.title}</span>
                  <ChevronRight className="w-4 h-4 ml-auto flex-shrink-0" />
                </p>
              </div>
            )}

            {/* Mobile: Expand/Collapse Button */}
            <button 
              onClick={() => setIsProductsExpanded(!isProductsExpanded)}
              className="lg:hidden flex items-center justify-center gap-2 py-2 bg-slate-800/50 text-slate-400 hover:text-white transition-colors"
            >
              {isProductsExpanded ? (
                <>
                  <ChevronDown className="w-4 h-4" />
                  <span className="text-xs">Réduire</span>
                </>
              ) : (
                <>
                  <ChevronUp className="w-4 h-4" />
                  <span className="text-xs">Voir plus</span>
                </>
              )}
            </button>

            {/* Content Area */}
            <div className={`flex-1 overflow-hidden ${isProductsExpanded ? 'max-h-[60vh]' : 'max-h-[30vh] lg:max-h-full'}`}>
              {activeTab === 'products' && (
                /* Products List */
                <div className="h-full overflow-y-auto p-3 md:p-4 space-y-3">
                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-slate-800/50 rounded-xl p-3 text-center">
                      <p className="text-slate-400 text-xs">Ventes</p>
                      <p className="text-white font-bold text-lg">{replay.total_sales || 0}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-xl p-3 text-center">
                      <p className="text-slate-400 text-xs">Revenus</p>
                      <p className="text-green-400 font-bold text-lg">{formatPrice(replay.total_revenue || 0)}</p>
                    </div>
                  </div>

                  {products.length === 0 ? (
                    <div className="text-center py-8">
                      <Package className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                      <p className="text-slate-500 text-sm">Aucun produit dans ce live</p>
                    </div>
                  ) : (
                    products.map((product) => (
                      <div 
                        key={product.id}
                        className={`p-3 rounded-xl border transition-all ${
                          product.is_highlighted 
                            ? 'bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/50' 
                            : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                        }`}
                      >
                        {product.is_highlighted && (
                          <div className="flex items-center gap-1 mb-2">
                            <Star className="w-3 h-3 text-purple-500" />
                            <span className="text-purple-500 text-xs font-medium">En vedette</span>
                          </div>
                        )}
                        <div className="flex gap-3">
                          <img 
                            src={product.product_image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                            alt={product.product_name}
                            className="w-14 h-14 md:w-16 md:h-16 rounded-lg object-cover flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-white font-medium text-xs md:text-sm line-clamp-2">{product.product_name}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-purple-500 font-bold text-xs md:text-sm">{formatPrice(product.product_price)}</span>
                              {product.product_original_price && (
                                <span className="text-slate-500 text-xs line-through">{formatPrice(product.product_original_price)}</span>
                              )}
                            </div>
                            <p className="text-green-400 text-xs mt-0.5">{product.units_sold || 0} vendus</p>
                          </div>
                        </div>
                        {/* Contact & Order Buttons */}
                        <div className="flex gap-2 mt-3">
                          <button
                            onClick={() => handleWhatsApp(product)}
                            className="flex-1 py-1.5 md:py-2 bg-green-500/20 text-green-400 font-semibold rounded-lg hover:bg-green-500/30 transition-all text-xs flex items-center justify-center gap-1"
                          >
                            <MessageCircle className="w-3 h-3 md:w-3.5 md:h-3.5" />
                            <span className="hidden sm:inline">WhatsApp</span>
                          </button>
                          <button
                            onClick={handleCall}
                            className="flex-1 py-1.5 md:py-2 bg-blue-500/20 text-blue-400 font-semibold rounded-lg hover:bg-blue-500/30 transition-all text-xs flex items-center justify-center gap-1"
                          >
                            <Phone className="w-3 h-3 md:w-3.5 md:h-3.5" />
                            <span className="hidden sm:inline">Appeler</span>
                          </button>
                          <button
                            onClick={() => handleOrder(product)}
                            className="flex-1 py-1.5 md:py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold rounded-lg hover:shadow-lg transition-all text-xs flex items-center justify-center gap-1"
                          >
                            <ShoppingBag className="w-3 h-3 md:w-3.5 md:h-3.5" />
                            <span className="hidden sm:inline">Commander</span>
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {activeTab === 'chat' && (
                /* Chat Replay */
                <div className="h-full flex flex-col">
                  <div className="px-4 py-2 bg-purple-500/10 border-b border-purple-500/20 flex-shrink-0">
                    <p className="text-purple-400 text-sm flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Chat synchronisé avec la vidéo
                    </p>
                  </div>
                  
                  <div 
                    ref={chatContainerRef}
                    className="flex-1 overflow-y-auto p-3 md:p-4 space-y-3"
                  >
                    {visibleMessages.length === 0 ? (
                      <div className="text-center text-slate-500 py-8">
                        <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">Lancez la lecture pour voir le chat</p>
                      </div>
                    ) : (
                      visibleMessages.map((msg) => (
                        <div 
                          key={msg.id}
                          className={`p-2 md:p-3 rounded-xl border animate-in fade-in slide-in-from-bottom-2 ${getMessageTypeStyle(msg.message_type)}`}
                        >
                          <div className="flex items-start gap-2">
                            <img 
                              src={msg.user_avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50'}
                              alt={msg.user_name}
                              className="w-6 h-6 md:w-8 md:h-8 rounded-full flex-shrink-0"
                            />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-white font-medium text-xs md:text-sm">{msg.user_name}</span>
                                <span className="text-slate-500 text-xs">{getMessageTimestamp(msg)}</span>
                                {msg.message_type === 'purchase' && (
                                  <span className="px-1.5 py-0.5 bg-green-500/20 text-green-400 text-xs rounded">Achat</span>
                                )}
                                {msg.message_type === 'highlight' && (
                                  <span className="px-1.5 py-0.5 bg-orange-500/20 text-orange-400 text-xs rounded">Produit</span>
                                )}
                              </div>
                              <p className="text-slate-300 text-xs md:text-sm mt-0.5 break-words">{msg.message}</p>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Info about chat replay */}
                  <div className="p-3 md:p-4 bg-slate-800/50 border-t border-slate-700 flex-shrink-0">
                    <p className="text-slate-400 text-xs md:text-sm text-center">
                      Le chat est en lecture seule pendant la rediffusion
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'chapters' && (
                /* Chapters List */
                <div className="h-full overflow-y-auto p-3 md:p-4 space-y-2">
                  <div className="mb-4">
                    <p className="text-slate-400 text-sm">{chapters.length} chapitre{chapters.length !== 1 ? 's' : ''}</p>
                  </div>
                  {chapters.map((chapter, index) => {
                    const isActive = currentChapter?.id === chapter.id;
                    return (
                      <button
                        key={chapter.id}
                        onClick={() => seekTo(chapter.timestamp_seconds)}
                        className={`w-full p-3 rounded-xl border text-left transition-all ${
                          isActive
                            ? 'bg-purple-500/20 border-purple-500/50'
                            : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            isActive ? 'bg-purple-500 text-white' : 'bg-slate-700 text-slate-400'
                          }`}>
                            <span className="text-sm font-bold">{index + 1}</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <h4 className={`font-medium text-sm truncate ${isActive ? 'text-purple-300' : 'text-white'}`}>
                                {chapter.title}
                              </h4>
                              {isActive && (
                                <span className="px-1.5 py-0.5 bg-purple-500/30 text-purple-300 text-xs rounded">En cours</span>
                              )}
                            </div>
                            {chapter.description && (
                              <p className="text-slate-400 text-xs mt-1 line-clamp-2">{chapter.description}</p>
                            )}
                            <p className="text-slate-500 text-xs mt-1 font-mono">
                              {formatTime(chapter.timestamp_seconds)}
                            </p>
                          </div>
                          <ChevronRight className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-purple-400' : 'text-slate-500'}`} />
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>


      {/* Order Form Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 z-[10000]">
          <OrderFormModal
            isOpen={showOrderModal}
            onClose={() => {
              setShowOrderModal(false);
              setSelectedProductForOrder(null);
            }}
            product={selectedProductForOrder}
            onOrderSuccess={(orderId) => {
              toast({
                title: "Commande passée!",
                description: `Votre commande ${orderId.slice(0, 8).toUpperCase()} a été enregistrée`
              });
            }}
          />
        </div>
      )}

      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 z-[10000]">
          <AuthModal 
            isOpen={showAuthModal} 
            onClose={() => setShowAuthModal(false)} 
          />
        </div>
      )}
    </>
  );
};

export default ReplayModal;
