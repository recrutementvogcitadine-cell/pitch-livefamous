import React, { useState, useEffect, useRef } from 'react';
import { UserPlus, UserCheck, Bell, BellOff, ChevronDown, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useNotifications } from '@/hooks/useNotifications';
import { toast } from '@/components/ui/use-toast';

interface FollowButtonProps {
  sellerId: string;
  sellerName: string;
  variant?: 'default' | 'compact' | 'icon-only';
  className?: string;
  onAuthRequired?: () => void;
}

const FollowButton: React.FC<FollowButtonProps> = ({
  sellerId,
  sellerName,
  variant = 'default',
  className = '',
  onAuthRequired
}) => {
  const { user } = useAuth();
  const { followSeller, unfollowSeller, toggleSellerNotifications, checkFollowing, loading } = useNotifications();
  
  const [isFollowing, setIsFollowing] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [showDropdown, setShowDropdown] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Check if user is following this seller
  useEffect(() => {
    const checkFollowStatus = async () => {
      if (!user) {
        setIsFollowing(false);
        setIsChecking(false);
        return;
      }

      try {
        const result = await checkFollowing(user.id, sellerId);
        setIsFollowing(result.is_following || false);
        setNotificationsEnabled(result.notifications_enabled ?? true);
      } catch (error) {
        console.error('Error checking follow status:', error);
      } finally {
        setIsChecking(false);
      }
    };

    checkFollowStatus();
  }, [user, sellerId, checkFollowing]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleFollow = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!user) {
      if (onAuthRequired) {
        onAuthRequired();
      } else {
        toast({
          title: "Connexion requise",
          description: "Veuillez vous connecter pour suivre ce vendeur",
          variant: "destructive"
        });
      }
      return;
    }

    setIsLoading(true);
    try {
      if (isFollowing) {
        await unfollowSeller(user.id, sellerId);
        setIsFollowing(false);
        setShowDropdown(false);
        toast({
          title: "Désabonné",
          description: `Vous ne suivez plus ${sellerName}`,
        });
      } else {
        await followSeller(user.id, sellerId);
        setIsFollowing(true);
        setNotificationsEnabled(true);
        toast({
          title: "Abonné!",
          description: `Vous suivez maintenant ${sellerName}. Vous serez notifié de ses lives.`,
        });
      }
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleNotifications = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!user) return;

    setIsLoading(true);
    try {
      const newState = !notificationsEnabled;
      await toggleSellerNotifications(user.id, sellerId, newState);
      setNotificationsEnabled(newState);
      toast({
        title: newState ? "Notifications activées" : "Notifications désactivées",
        description: newState 
          ? `Vous recevrez des notifications de ${sellerName}`
          : `Vous ne recevrez plus de notifications de ${sellerName}`,
      });
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDropdownToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isFollowing) {
      setShowDropdown(!showDropdown);
    }
  };

  if (isChecking) {
    return (
      <button
        disabled
        className={`flex items-center justify-center gap-2 px-4 py-2 bg-slate-700 text-slate-400 rounded-xl ${className}`}
      >
        <Loader2 className="w-4 h-4 animate-spin" />
        {variant !== 'icon-only' && <span>...</span>}
      </button>
    );
  }

  // Icon-only variant
  if (variant === 'icon-only') {
    return (
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={isFollowing ? handleDropdownToggle : handleFollow}
          disabled={isLoading}
          className={`p-2 rounded-full transition-all ${
            isFollowing
              ? 'bg-purple-500/20 text-purple-400 hover:bg-purple-500/30'
              : 'bg-slate-700 text-slate-300 hover:bg-slate-600 hover:text-white'
          } ${className}`}
          title={isFollowing ? `Suivi - ${sellerName}` : `Suivre ${sellerName}`}
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : isFollowing ? (
            <UserCheck className="w-4 h-4" />
          ) : (
            <UserPlus className="w-4 h-4" />
          )}
        </button>

        {/* Dropdown for icon-only */}
        {showDropdown && isFollowing && (
          <div className="absolute right-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-xl shadow-xl z-50 overflow-hidden">
            <button
              onClick={handleToggleNotifications}
              className="w-full flex items-center gap-3 px-4 py-3 text-sm text-left hover:bg-slate-700 transition-colors"
            >
              {notificationsEnabled ? (
                <>
                  <BellOff className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-300">Désactiver notifications</span>
                </>
              ) : (
                <>
                  <Bell className="w-4 h-4 text-purple-400" />
                  <span className="text-slate-300">Activer notifications</span>
                </>
              )}
            </button>
            <button
              onClick={handleFollow}
              className="w-full flex items-center gap-3 px-4 py-3 text-sm text-left hover:bg-slate-700 transition-colors border-t border-slate-700"
            >
              <UserPlus className="w-4 h-4 text-red-400" />
              <span className="text-red-400">Se désabonner</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  // Compact variant
  if (variant === 'compact') {
    return (
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={isFollowing ? handleDropdownToggle : handleFollow}
          disabled={isLoading}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
            isFollowing
              ? 'bg-purple-500/20 text-purple-400 hover:bg-purple-500/30'
              : 'bg-slate-700 text-white hover:bg-slate-600'
          } ${className}`}
        >
          {isLoading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : isFollowing ? (
            <>
              <UserCheck className="w-3.5 h-3.5" />
              <span>Suivi</span>
              <ChevronDown className="w-3 h-3" />
            </>
          ) : (
            <>
              <UserPlus className="w-3.5 h-3.5" />
              <span>Suivre</span>
            </>
          )}
        </button>

        {/* Dropdown */}
        {showDropdown && isFollowing && (
          <div className="absolute right-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-xl shadow-xl z-50 overflow-hidden">
            <button
              onClick={handleToggleNotifications}
              className="w-full flex items-center gap-3 px-4 py-3 text-sm text-left hover:bg-slate-700 transition-colors"
            >
              {notificationsEnabled ? (
                <>
                  <BellOff className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-300">Désactiver notifications</span>
                </>
              ) : (
                <>
                  <Bell className="w-4 h-4 text-purple-400" />
                  <span className="text-slate-300">Activer notifications</span>
                </>
              )}
            </button>
            <button
              onClick={handleFollow}
              className="w-full flex items-center gap-3 px-4 py-3 text-sm text-left hover:bg-slate-700 transition-colors border-t border-slate-700"
            >
              <UserPlus className="w-4 h-4 text-red-400" />
              <span className="text-red-400">Se désabonner</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  // Default variant
  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={isFollowing ? handleDropdownToggle : handleFollow}
        disabled={isLoading}
        className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-medium transition-all ${
          isFollowing
            ? 'bg-purple-500/20 text-purple-400 hover:bg-purple-500/30 border border-purple-500/30'
            : 'bg-slate-700 text-white hover:bg-slate-600'
        } ${className}`}
      >
        {isLoading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : isFollowing ? (
          <>
            <UserCheck className="w-4 h-4" />
            <span>Suivi</span>
            {notificationsEnabled && <Bell className="w-3.5 h-3.5 text-purple-300" />}
            <ChevronDown className="w-4 h-4" />
          </>
        ) : (
          <>
            <UserPlus className="w-4 h-4" />
            <span>Suivre</span>
          </>
        )}
      </button>

      {/* Dropdown */}
      {showDropdown && isFollowing && (
        <div className="absolute left-0 right-0 mt-2 bg-slate-800 border border-slate-700 rounded-xl shadow-xl z-50 overflow-hidden min-w-[200px]">
          <div className="px-4 py-3 border-b border-slate-700">
            <p className="text-white font-medium text-sm">{sellerName}</p>
            <p className="text-slate-400 text-xs mt-0.5">Gérer les notifications</p>
          </div>
          
          <button
            onClick={handleToggleNotifications}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm text-left hover:bg-slate-700 transition-colors"
          >
            {notificationsEnabled ? (
              <>
                <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Bell className="w-4 h-4 text-purple-400" />
                </div>
                <div className="flex-1">
                  <p className="text-white font-medium">Notifications actives</p>
                  <p className="text-slate-400 text-xs">Cliquez pour désactiver</p>
                </div>
              </>
            ) : (
              <>
                <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
                  <BellOff className="w-4 h-4 text-slate-400" />
                </div>
                <div className="flex-1">
                  <p className="text-white font-medium">Notifications désactivées</p>
                  <p className="text-slate-400 text-xs">Cliquez pour activer</p>
                </div>
              </>
            )}
          </button>

          <button
            onClick={handleFollow}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm text-left hover:bg-red-500/10 transition-colors border-t border-slate-700"
          >
            <div className="w-8 h-8 rounded-full bg-red-500/20 flex items-center justify-center">
              <UserPlus className="w-4 h-4 text-red-400" />
            </div>
            <div className="flex-1">
              <p className="text-red-400 font-medium">Se désabonner</p>
              <p className="text-slate-400 text-xs">Ne plus suivre ce vendeur</p>
            </div>
          </button>
        </div>
      )}
    </div>
  );
};

export default FollowButton;
