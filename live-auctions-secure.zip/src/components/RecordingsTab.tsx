import React, { useState, useEffect } from 'react';
import {
  Film, Play, Eye, EyeOff, Edit2, Trash2, Clock, Users,
  Calendar, BarChart3, CheckCircle, AlertCircle, Upload,
  Search, Filter, MoreVertical, ExternalLink, Copy, List
} from 'lucide-react';
import { formatPrice } from '@/data/mockData';
import { useRecordings, Recording } from '@/hooks/useRecordings';
import RecordingEditor from './RecordingEditor';
import { toast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const RecordingsTab: React.FC = () => {
  const {
    fetchRecordings,
    publishRecording,
    unpublishRecording,
    deleteRecording,
    loading
  } = useRecordings();

  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [filteredRecordings, setFilteredRecordings] = useState<Recording[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [editingRecordingId, setEditingRecordingId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadRecordings();
  }, []);

  useEffect(() => {
    filterRecordings();
  }, [recordings, searchQuery, statusFilter]);

  const loadRecordings = async () => {
    setIsLoading(true);
    const data = await fetchRecordings();
    setRecordings(data);
    setIsLoading(false);
  };

  const filterRecordings = () => {
    let filtered = [...recordings];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(r => 
        r.title.toLowerCase().includes(query) ||
        r.description?.toLowerCase().includes(query)
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(r => r.status === statusFilter);
    }

    setFilteredRecordings(filtered);
  };

  const handlePublish = async (recordingId: string) => {
    const success = await publishRecording(recordingId);
    if (success) {
      setRecordings(recordings.map(r => 
        r.id === recordingId ? { ...r, status: 'published' as const, is_published: true } : r
      ));
      toast({
        title: "Publié",
        description: "La rediffusion est maintenant visible"
      });
    }
  };

  const handleUnpublish = async (recordingId: string) => {
    const success = await unpublishRecording(recordingId);
    if (success) {
      setRecordings(recordings.map(r => 
        r.id === recordingId ? { ...r, status: 'ready' as const, is_published: false } : r
      ));
      toast({
        title: "Dépublié",
        description: "La rediffusion n'est plus visible"
      });
    }
  };

  const handleDelete = async (recordingId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette rediffusion?')) return;
    
    const success = await deleteRecording(recordingId);
    if (success) {
      setRecordings(recordings.filter(r => r.id !== recordingId));
      toast({
        title: "Supprimé",
        description: "La rediffusion a été supprimée"
      });
    }
  };

  const copyLink = (recordingId: string) => {
    const url = `${window.location.origin}?replay=${recordingId}`;
    navigator.clipboard.writeText(url);
    toast({
      title: "Lien copié",
      description: "Le lien de la rediffusion a été copié"
    });
  };

  const formatDuration = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    if (hrs > 0) {
      return `${hrs}h ${mins}min`;
    }
    return `${mins} min`;
  };

  const getStatusBadge = (status: string, isPublished: boolean) => {
    if (status === 'processing') {
      return (
        <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded-full flex items-center gap-1">
          <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full animate-pulse" />
          En traitement
        </span>
      );
    }
    if (status === 'failed') {
      return (
        <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded-full flex items-center gap-1">
          <AlertCircle className="w-3 h-3" />
          Échec
        </span>
      );
    }
    if (isPublished) {
      return (
        <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full flex items-center gap-1">
          <CheckCircle className="w-3 h-3" />
          Publié
        </span>
      );
    }
    return (
      <span className="px-2 py-1 bg-slate-500/20 text-slate-400 text-xs rounded-full">
        Brouillon
      </span>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white">
              <Film className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg">Gestion des Rediffusions</h3>
              <p className="text-slate-400 text-sm">
                {recordings.length} enregistrement{recordings.length !== 1 ? 's' : ''} • {recordings.filter(r => r.is_published).length} publié{recordings.filter(r => r.is_published).length !== 1 ? 's' : ''}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher une rediffusion..."
            className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
        >
          <option value="all">Tous les statuts</option>
          <option value="published">Publiés</option>
          <option value="ready">Brouillons</option>
          <option value="processing">En traitement</option>
        </select>
      </div>

      {/* Recordings List */}
      {filteredRecordings.length === 0 ? (
        <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
          <Film className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <h3 className="text-white text-xl font-semibold mb-2">
            {searchQuery || statusFilter !== 'all' ? 'Aucun résultat' : 'Aucune rediffusion'}
          </h3>
          <p className="text-slate-400">
            {searchQuery || statusFilter !== 'all' 
              ? 'Essayez de modifier vos filtres'
              : 'Vos lives enregistrés apparaîtront ici'
            }
          </p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredRecordings.map((recording) => (
            <div
              key={recording.id}
              className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden hover:border-slate-600 transition-colors"
            >
              <div className="flex flex-col md:flex-row">
                {/* Thumbnail */}
                <div className="md:w-64 h-40 md:h-auto relative bg-slate-900 flex-shrink-0">
                  {recording.thumbnail_url ? (
                    <img
                      src={recording.thumbnail_url}
                      alt={recording.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Film className="w-12 h-12 text-slate-700" />
                    </div>
                  )}
                  {/* Duration badge */}
                  <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/80 rounded text-white text-xs font-medium">
                    {formatDuration(recording.duration_seconds)}
                  </div>
                  {/* Status overlay for processing */}
                  {recording.status === 'processing' && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-8 h-8 border-3 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                        <p className="text-white text-sm">Traitement...</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 p-4 md:p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <h4 className="text-white font-semibold truncate">{recording.title}</h4>
                        {getStatusBadge(recording.status, recording.is_published)}
                      </div>
                      <p className="text-slate-400 text-sm line-clamp-2 mb-4">
                        {recording.description || 'Pas de description'}
                      </p>

                      {/* Stats */}
                      <div className="flex flex-wrap gap-4 text-sm">
                        <span className="text-slate-500 flex items-center gap-1">
                          <Eye className="w-4 h-4" />
                          {recording.view_count} vues
                        </span>
                        <span className="text-slate-500 flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(recording.created_at).toLocaleDateString('fr-FR', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric'
                          })}
                        </span>
                        {recording.live_streams?.category && (
                          <span className="text-slate-500 flex items-center gap-1">
                            <List className="w-4 h-4" />
                            {recording.live_streams.category}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      {recording.status === 'ready' || recording.status === 'published' ? (
                        <>
                          <button
                            onClick={() => setEditingRecordingId(recording.id)}
                            className="p-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
                            title="Éditer"
                          >
                            <Edit2 className="w-4 h-4 text-white" />
                          </button>
                          
                          {recording.is_published ? (
                            <button
                              onClick={() => handleUnpublish(recording.id)}
                              disabled={loading}
                              className="p-2 bg-orange-500/20 hover:bg-orange-500/30 rounded-lg transition-colors"
                              title="Dépublier"
                            >
                              <EyeOff className="w-4 h-4 text-orange-400" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handlePublish(recording.id)}
                              disabled={loading}
                              className="p-2 bg-green-500/20 hover:bg-green-500/30 rounded-lg transition-colors"
                              title="Publier"
                            >
                              <Eye className="w-4 h-4 text-green-400" />
                            </button>
                          )}
                        </>
                      ) : null}

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button className="p-2 hover:bg-slate-700 rounded-lg transition-colors">
                            <MoreVertical className="w-4 h-4 text-slate-400" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                          {recording.is_published && (
                            <>
                              <DropdownMenuItem
                                onClick={() => copyLink(recording.id)}
                                className="text-slate-300 hover:text-white hover:bg-slate-700 cursor-pointer"
                              >
                                <Copy className="w-4 h-4 mr-2" />
                                Copier le lien
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => window.open(`?replay=${recording.live_stream_id}`, '_blank')}
                                className="text-slate-300 hover:text-white hover:bg-slate-700 cursor-pointer"
                              >
                                <ExternalLink className="w-4 h-4 mr-2" />
                                Voir la rediffusion
                              </DropdownMenuItem>
                              <DropdownMenuSeparator className="bg-slate-700" />
                            </>
                          )}
                          <DropdownMenuItem
                            onClick={() => setEditingRecordingId(recording.id)}
                            className="text-slate-300 hover:text-white hover:bg-slate-700 cursor-pointer"
                          >
                            <Edit2 className="w-4 h-4 mr-2" />
                            Éditer
                          </DropdownMenuItem>
                          <DropdownMenuSeparator className="bg-slate-700" />
                          <DropdownMenuItem
                            onClick={() => handleDelete(recording.id)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Supprimer
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>

                  {/* Trim info if trimmed */}
                  {(recording.trim_start_seconds > 0 || (recording.trim_end_seconds && recording.trim_end_seconds < recording.duration_seconds)) && (
                    <div className="mt-4 pt-4 border-t border-slate-700">
                      <p className="text-slate-500 text-xs flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5" />
                        Découpé: {formatDuration(recording.trim_start_seconds)} - {formatDuration(recording.trim_end_seconds || recording.duration_seconds)}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Recording Editor Modal */}
      {editingRecordingId && (
        <RecordingEditor
          isOpen={!!editingRecordingId}
          onClose={() => setEditingRecordingId(null)}
          recordingId={editingRecordingId}
          onSave={() => {
            loadRecordings();
          }}
        />
      )}
    </div>
  );
};

export default RecordingsTab;
