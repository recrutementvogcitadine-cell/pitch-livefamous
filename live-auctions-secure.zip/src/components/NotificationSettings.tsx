import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Bell, BellOff, BellRing, Smartphone, Globe, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export function NotificationSettings() {
  const { user } = useAuth();
  const {
    isSupported,
    permission,
    isSubscribed,
    loading,
    error,
    requestPermission,
    subscribe,
    unsubscribe,
    showNotification
  } = usePushNotifications();

  const [testingNotification, setTestingNotification] = useState(false);

  const handleEnableNotifications = async () => {
    if (!user) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour activer les notifications",
        variant: "destructive"
      });
      return;
    }

    const success = await subscribe();
    if (success) {
      toast({
        title: "Notifications activées",
        description: "Vous recevrez des rappels pour vos lives programmés"
      });
    }
  };

  const handleDisableNotifications = async () => {
    const success = await unsubscribe();
    if (success) {
      toast({
        title: "Notifications désactivées",
        description: "Vous ne recevrez plus de notifications push"
      });
    }
  };

  const handleTestNotification = async () => {
    setTestingNotification(true);
    const success = await showNotification('Test de notification', {
      body: 'Ceci est une notification de test. Si vous voyez ceci, les notifications fonctionnent correctement!',
      tag: 'test-notification',
      data: { type: 'test' }
    });

    if (success) {
      toast({
        title: "Notification envoyée",
        description: "Vérifiez vos notifications"
      });
    } else {
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer la notification de test",
        variant: "destructive"
      });
    }
    setTestingNotification(false);
  };

  const getPermissionBadge = () => {
    switch (permission) {
      case 'granted':
        return <Badge className="bg-green-500">Autorisé</Badge>;
      case 'denied':
        return <Badge variant="destructive">Refusé</Badge>;
      default:
        return <Badge variant="secondary">Non demandé</Badge>;
    }
  };

  if (!isSupported) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BellOff className="w-5 h-5" />
            Notifications Push
          </CardTitle>
          <CardDescription>
            Recevez des rappels avant le début des lives
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Votre navigateur ne supporte pas les notifications push. 
              Essayez d'utiliser un navigateur moderne comme Chrome, Firefox ou Edge.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notifications Push
        </CardTitle>
        <CardDescription>
          Recevez des rappels avant le début des lives que vous suivez
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Permission Status */}
        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full ${
              permission === 'granted' ? 'bg-green-100 text-green-600' :
              permission === 'denied' ? 'bg-red-100 text-red-600' :
              'bg-gray-100 text-gray-600'
            }`}>
              {permission === 'granted' ? (
                <CheckCircle2 className="w-5 h-5" />
              ) : permission === 'denied' ? (
                <BellOff className="w-5 h-5" />
              ) : (
                <Bell className="w-5 h-5" />
              )}
            </div>
            <div>
              <p className="font-medium">Permission du navigateur</p>
              <p className="text-sm text-muted-foreground">
                {permission === 'granted' ? 'Les notifications sont autorisées' :
                 permission === 'denied' ? 'Les notifications sont bloquées' :
                 'Permission non encore demandée'}
              </p>
            </div>
          </div>
          {getPermissionBadge()}
        </div>

        {/* Denied Permission Warning */}
        {permission === 'denied' && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Les notifications sont bloquées. Pour les activer, cliquez sur l'icône de cadenas 
              dans la barre d'adresse de votre navigateur et autorisez les notifications.
            </AlertDescription>
          </Alert>
        )}

        {/* Enable/Disable Toggle */}
        {permission !== 'denied' && (
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              <BellRing className="w-5 h-5 text-purple-600" />
              <div>
                <Label htmlFor="push-notifications" className="font-medium">
                  Activer les notifications push
                </Label>
                <p className="text-sm text-muted-foreground">
                  Recevez des alertes quand un live va commencer
                </p>
              </div>
            </div>
            <Switch
              id="push-notifications"
              checked={isSubscribed}
              onCheckedChange={(checked) => {
                if (checked) {
                  handleEnableNotifications();
                } else {
                  handleDisableNotifications();
                }
              }}
              disabled={loading}
            />
          </div>
        )}

        {/* Request Permission Button */}
        {permission === 'default' && !isSubscribed && (
          <Button
            onClick={handleEnableNotifications}
            disabled={loading}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Activation...
              </>
            ) : (
              <>
                <Bell className="w-4 h-4 mr-2" />
                Activer les notifications
              </>
            )}
          </Button>
        )}

        {/* Test Notification */}
        {isSubscribed && permission === 'granted' && (
          <div className="pt-4 border-t">
            <Button
              variant="outline"
              onClick={handleTestNotification}
              disabled={testingNotification}
              className="w-full"
            >
              {testingNotification ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Envoi en cours...
                </>
              ) : (
                <>
                  <Smartphone className="w-4 h-4 mr-2" />
                  Tester les notifications
                </>
              )}
            </Button>
            <p className="text-xs text-muted-foreground text-center mt-2">
              Envoyez une notification de test pour vérifier que tout fonctionne
            </p>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Info Section */}
        <div className="pt-4 border-t space-y-3">
          <h4 className="font-medium text-sm">Types de notifications</h4>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 rounded-full bg-purple-500" />
              Rappels avant le début d'un live programmé
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              Notification quand un vendeur suivi passe en direct
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 rounded-full bg-blue-500" />
              Alertes pour les lives annulés ou reprogrammés
            </div>
          </div>
        </div>

        {/* Browser Support Info */}
        <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg text-sm">
          <Globe className="w-4 h-4 text-blue-600" />
          <span className="text-blue-700 dark:text-blue-300">
            Les notifications fonctionnent même quand l'onglet est fermé
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
