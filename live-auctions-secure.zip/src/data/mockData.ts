// Types
export interface LiveStream {
  id: string;
  title: string;
  seller: {
    name: string;
    avatar: string;
    verified: boolean;
  };
  thumbnail: string;
  viewers: number;
  category: string;
  isLive: boolean;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  seller: string;
  rating: number;
  reviews: number;
  category: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  period: string;
  features: string[];
  popular: boolean;
  color: string;
}

export interface Order {
  id: string;
  product: string;
  price: number;
  status: 'pending' | 'confirmed' | 'in_transit' | 'delivered';
  date: string;
  seller: string;
}

// Mock Data
export const liveStreams: LiveStream[] = [
  {
    id: '1',
    title: 'Vente Flash - Téléphones Samsung',
    seller: { name: 'TechStore CI', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400',
    viewers: 1247,
    category: 'Électronique',
    isLive: true
  },
  {
    id: '2',
    title: 'Mode Africaine - Pagnes Wax',
    seller: { name: 'Awa Fashion', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=400',
    viewers: 892,
    category: 'Mode',
    isLive: true
  },
  {
    id: '3',
    title: 'Bijoux Artisanaux Ivoiriens',
    seller: { name: 'Bijoux d\'Or', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', verified: false },
    thumbnail: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400',
    viewers: 654,
    category: 'Bijoux',
    isLive: true
  },
  {
    id: '4',
    title: 'Électroménager - Promo Semaine',
    seller: { name: 'Maison Plus', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400',
    viewers: 1089,
    category: 'Maison',
    isLive: true
  },
  {
    id: '5',
    title: 'Sneakers Originaux - Nike & Adidas',
    seller: { name: 'SneakerHead ABJ', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400',
    viewers: 2341,
    category: 'Chaussures',
    isLive: true
  },
  {
    id: '6',
    title: 'Cosmétiques Naturels Bio',
    seller: { name: 'Beauty Queen', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400',
    viewers: 567,
    category: 'Beauté',
    isLive: true
  },
  {
    id: '7',
    title: 'Montres de Luxe Authentiques',
    seller: { name: 'Chrono Luxe', avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400',
    viewers: 789,
    category: 'Accessoires',
    isLive: true
  },
  {
    id: '8',
    title: 'Meubles Design Moderne',
    seller: { name: 'Déco Intérieur', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100', verified: false },
    thumbnail: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400',
    viewers: 432,
    category: 'Maison',
    isLive: true
  },
  {
    id: '9',
    title: 'Parfums Originaux - Grandes Marques',
    seller: { name: 'Parfum Palace', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=400',
    viewers: 1456,
    category: 'Beauté',
    isLive: true
  },
  {
    id: '10',
    title: 'Accessoires Auto Premium',
    seller: { name: 'Auto Style CI', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400',
    viewers: 678,
    category: 'Auto',
    isLive: true
  },
  {
    id: '11',
    title: 'Sacs à Main Designer',
    seller: { name: 'Luxe Bags', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400',
    viewers: 923,
    category: 'Mode',
    isLive: true
  },
  {
    id: '12',
    title: 'Gadgets High-Tech 2026',
    seller: { name: 'Gadget World', avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=100', verified: true },
    thumbnail: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=400',
    viewers: 1876,
    category: 'Électronique',
    isLive: true
  }
];

export const products: Product[] = [
  { id: '1', name: 'iPhone 15 Pro Max', price: 850000, originalPrice: 950000, image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', seller: 'TechStore CI', rating: 4.8, reviews: 234, category: 'Électronique' },
  { id: '2', name: 'Ensemble Wax Traditionnel', price: 45000, image: 'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=400', seller: 'Awa Fashion', rating: 4.9, reviews: 189, category: 'Mode' },
  { id: '3', name: 'Collier Perles Africaines', price: 28000, originalPrice: 35000, image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=400', seller: 'Bijoux d\'Or', rating: 4.7, reviews: 67, category: 'Bijoux' },
  { id: '4', name: 'Climatiseur Samsung 18000 BTU', price: 420000, image: 'https://images.unsplash.com/photo-1631545806609-35d4ae440431?w=400', seller: 'Maison Plus', rating: 4.6, reviews: 156, category: 'Maison' },
  { id: '5', name: 'Nike Air Max 270', price: 85000, originalPrice: 110000, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400', seller: 'SneakerHead ABJ', rating: 4.9, reviews: 312, category: 'Chaussures' },
  { id: '6', name: 'Kit Beauté Naturel', price: 32000, image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400', seller: 'Beauty Queen', rating: 4.5, reviews: 98, category: 'Beauté' },
  { id: '7', name: 'Montre Casio G-Shock', price: 75000, originalPrice: 95000, image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400', seller: 'Chrono Luxe', rating: 4.8, reviews: 201, category: 'Accessoires' },
  { id: '8', name: 'Canapé 3 Places Moderne', price: 280000, image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400', seller: 'Déco Intérieur', rating: 4.4, reviews: 45, category: 'Maison' }
];

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'starter',
    name: 'Starter',
    price: 15000,
    period: 'mois',
    features: ['5 Lives par mois', '20 produits max', 'Support email', 'Statistiques basiques'],
    popular: false,
    color: 'from-blue-500 to-cyan-500'
  },
  {
    id: 'pro',
    name: 'Professionnel',
    price: 35000,
    period: 'mois',
    features: ['Lives illimités', '100 produits max', 'Support prioritaire', 'Statistiques avancées', 'Badge vérifié', 'Promotion en page d\'accueil'],
    popular: true,
    color: 'from-orange-500 to-yellow-500'
  },
  {
    id: 'enterprise',
    name: 'Entreprise',
    price: 75000,
    period: 'mois',
    features: ['Tout du Pro', 'Produits illimités', 'Manager dédié', 'API personnalisée', 'Multi-utilisateurs', 'Formation incluse', 'Publicité gratuite'],
    popular: false,
    color: 'from-purple-500 to-pink-500'
  }
];

export const categories = [
  { id: 'all', name: 'Tous', icon: '🏠' },
  { id: 'electronics', name: 'Électronique', icon: '📱' },
  { id: 'fashion', name: 'Mode', icon: '👗' },
  { id: 'beauty', name: 'Beauté', icon: '💄' },
  { id: 'home', name: 'Maison', icon: '🏡' },
  { id: 'shoes', name: 'Chaussures', icon: '👟' },
  { id: 'jewelry', name: 'Bijoux', icon: '💍' },
  { id: 'auto', name: 'Auto', icon: '🚗' }
];

// Only cash on delivery payment - customers pay the seller directly
export const paymentMethod = {
  id: 'cod',
  name: 'Paiement à la livraison',
  description: 'Payez directement au vendeur lors de la réception'
};

export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('fr-CI', { style: 'currency', currency: 'XOF', minimumFractionDigits: 0 }).format(price);
};
