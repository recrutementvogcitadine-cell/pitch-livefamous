import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export interface SocialAccount {
  id: string;
  user_id: string;
  platform: 'instagram' | 'tiktok' | 'facebook' | 'twitter' | 'youtube';
  account_name: string;
  account_handle?: string;
  account_avatar_url?: string;
  is_connected: boolean;
  follower_count: number;
  connected_at: string;
  last_sync_at?: string;
}

export interface SocialShare {
  id: string;
  clip_id: string;
  user_id: string;
  social_account_id?: string;
  platform: string;
  post_id?: string;
  post_url?: string;
  caption?: string;
  hashtags?: string[];
  status: 'pending' | 'processing' | 'published' | 'failed' | 'scheduled';
  scheduled_for?: string;
  published_at?: string;
  error_message?: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  reach: number;
  engagement_rate: number;
  analytics_updated_at?: string;
  created_at: string;
  bulk_share_group_id?: string;
  social_accounts?: {
    account_name: string;
    account_handle?: string;
    account_avatar_url?: string;
  };
}

export interface PlatformAnalytics {
  platform: string;
  posts: number;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  avgEngagement: string;
}
export interface TotalAnalytics {
  posts: number;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  avgEngagement: string;
}

export interface BulkShareResult {
  clip_id: string;
  platform: string;
  success: boolean;
  share?: SocialShare;
  scheduled_for?: string;
  error?: string;
}

export interface BulkShareResponse {
  success: boolean;
  total_shares: number;
  successful: number;
  failed: number;
  results: BulkShareResult[];
}



export interface OptimalTimeRecommendation {
  platform: string;
  best_days: string[];
  best_hours: number[];
  peak_engagement_window: string;
  reasoning: string;
  confidence_score: number;
}

export interface HeatmapData {
  [platform: string]: {
    [day: string]: {
      [hour: string]: number;
    };
  };
}

export interface OptimalSlot {
  datetime: string;
  day: string;
  hour: number;
  expected_engagement: number;
  reasoning: string;
  is_optimal: boolean;
}

export interface OptimalTimesAnalysis {
  recommendations: OptimalTimeRecommendation[];
  heatmap_data: HeatmapData;
  insights: string[];
  data_points: number;
  analyzed_at: string;
}

// Audience Insights Types
export interface AgeGroup {
  range: string;
  percentage: number;
  engagement_index: number;
}

export interface GenderData {
  type: string;
  percentage: number;
}

export interface LocationData {
  location: string;
  percentage: number;
  city: string;
}

export interface Demographics {
  age_groups: AgeGroup[];
  gender: GenderData[];
  top_locations: LocationData[];
}

export interface EngagementSegment {
  segment_name: string;
  percentage: number;
  characteristics: string[];
  avg_engagement_rate: number;
  recommended_content: string;
}

export interface ContentType {
  type: string;
  avg_engagement: number;
  avg_views: number;
  trend: 'up' | 'down' | 'stable';
}

export interface HashtagPerformance {
  hashtag: string;
  reach_multiplier: number;
}

export interface ContentPreferences {
  top_performing_types: ContentType[];
  optimal_content_length: {
    video: string;
    caption: string;
    hashtags: string;
  };
  trending_topics: string[];
  hashtag_performance: HashtagPerformance[];
}

export interface GrowthDataPoint {
  period: string;
  followers: number;
  change: number;
}

export interface EngagementTrendPoint {
  period: string;
  rate: number;
}

export interface GrowthTrends {
  follower_growth: GrowthDataPoint[];
  engagement_trend: EngagementTrendPoint[];
  growth_rate_percentage: number;
  projected_monthly_growth: number;
  best_growth_drivers: string[];
}

export interface AIRecommendation {
  category: string;
  priority: 'high' | 'medium' | 'low';
  recommendation: string;
  expected_impact: string;
}

export interface AudienceInsights {
  demographics: Demographics;
  engagement_segments: EngagementSegment[];
  content_preferences: ContentPreferences;
  growth_trends: GrowthTrends;
  ai_recommendations: AIRecommendation[];
}

export interface AudienceInsightsResponse {
  success: boolean;
  insights: AudienceInsights;
  data_points: number;
  accounts_analyzed: number;
  analyzed_at: string;
}




// Demo social accounts for testing
const demoAccounts: SocialAccount[] = [
  {
    id: 'demo-instagram',
    user_id: 'demo',
    platform: 'instagram',
    account_name: 'My Instagram',
    account_handle: '@myshop',
    account_avatar_url: 'https://images.unsplash.com/photo-1611262588024-d12430b98920?w=100&h=100&fit=crop',
    is_connected: true,
    follower_count: 15420,
    connected_at: new Date().toISOString()
  },
  {
    id: 'demo-tiktok',
    user_id: 'demo',
    platform: 'tiktok',
    account_name: 'My TikTok',
    account_handle: '@myshoptiktok',
    account_avatar_url: 'https://images.unsplash.com/photo-1611605698335-8b1569810432?w=100&h=100&fit=crop',
    is_connected: true,
    follower_count: 52300,
    connected_at: new Date().toISOString()
  },
  {
    id: 'demo-twitter',
    user_id: 'demo',
    platform: 'twitter',
    account_name: 'My Twitter',
    account_handle: '@myshoptwitter',
    account_avatar_url: 'https://images.unsplash.com/photo-1611605698335-8b1569810432?w=100&h=100&fit=crop',
    is_connected: true,
    follower_count: 8900,
    connected_at: new Date().toISOString()
  }
];

// Demo shares for testing
const demoShares: SocialShare[] = [
  {
    id: 'demo-share-1',
    clip_id: 'demo-clip-1',
    user_id: 'demo',
    social_account_id: 'demo-instagram',
    platform: 'instagram',
    post_id: 'ig_123456',
    post_url: 'https://instagram.com/reel/ig_123456',
    caption: 'Check out our latest product!',
    hashtags: ['#fashion', '#style', '#newdrop'],
    status: 'published',
    published_at: new Date(Date.now() - 86400000).toISOString(),
    views: 12500,
    likes: 890,
    comments: 45,
    shares: 120,
    saves: 230,
    reach: 18000,
    engagement_rate: 8.44,
    created_at: new Date(Date.now() - 86400000).toISOString(),
    social_accounts: {
      account_name: 'My Instagram',
      account_handle: '@myshop'
    }
  },
  {
    id: 'demo-share-2',
    clip_id: 'demo-clip-1',
    user_id: 'demo',
    social_account_id: 'demo-tiktok',
    platform: 'tiktok',
    post_id: 'tt_789012',
    post_url: 'https://tiktok.com/@user/video/tt_789012',
    caption: 'This is going viral!',
    hashtags: ['#fyp', '#viral', '#trending'],
    status: 'published',
    published_at: new Date(Date.now() - 172800000).toISOString(),
    views: 85000,
    likes: 5200,
    comments: 320,
    shares: 890,
    saves: 1200,
    reach: 120000,
    engagement_rate: 7.54,
    created_at: new Date(Date.now() - 172800000).toISOString(),
    social_accounts: {
      account_name: 'My TikTok',
      account_handle: '@myshoptiktok'
    }
  }
];

export function useSocialSharing() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [accounts, setAccounts] = useState<SocialAccount[]>([]);
  const [shares, setShares] = useState<SocialShare[]>([]);
  const [scheduledShares, setScheduledShares] = useState<SocialShare[]>([]);
  const [analytics, setAnalytics] = useState<{ platforms: PlatformAnalytics[]; totals: TotalAnalytics } | null>(null);
  const [loading, setLoading] = useState(false);
  const [suggestedHashtags, setSuggestedHashtags] = useState<string[]>([]);

  // Fetch connected accounts
  const fetchAccounts = useCallback(async () => {
    if (!user?.id) {
      setAccounts(demoAccounts);
      return demoAccounts;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'get_accounts', user_id: user.id }
      });

      if (error) throw error;
      const accountsData = data.accounts?.length > 0 ? data.accounts : demoAccounts;
      setAccounts(accountsData);
      return accountsData;
    } catch (error) {
      console.error('Error fetching accounts:', error);
      setAccounts(demoAccounts);
      return demoAccounts;
    }
  }, [user?.id]);

  // Connect a social account (simulated OAuth flow)
  const connectAccount = useCallback(async (
    platform: SocialAccount['platform'],
    accountData: {
      account_name: string;
      account_handle?: string;
      account_avatar_url?: string;
      follower_count?: number;
    }
  ) => {
    if (!user?.id) {
      // Demo mode - add to local state
      const newAccount: SocialAccount = {
        id: `demo-${platform}-${Date.now()}`,
        user_id: 'demo',
        platform,
        ...accountData,
        is_connected: true,
        follower_count: accountData.follower_count || 0,
        connected_at: new Date().toISOString()
      };
      setAccounts(prev => [...prev.filter(a => a.platform !== platform), newAccount]);
      toast({ title: 'Account Connected', description: `Your ${platform} account has been connected.` });
      return newAccount;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: {
          action: 'connect_account',
          user_id: user.id,
          platform,
          ...accountData,
          access_token: 'simulated_token', // In production, this would come from OAuth
          refresh_token: 'simulated_refresh'
        }
      });

      if (error) throw error;
      await fetchAccounts();
      toast({ title: 'Account Connected', description: `Your ${platform} account has been connected.` });
      return data.account;
    } catch (error: any) {
      toast({ title: 'Connection Failed', description: error.message, variant: 'destructive' });
      throw error;
    } finally {
      setLoading(false);
    }
  }, [user?.id, fetchAccounts, toast]);

  // Disconnect an account
  const disconnectAccount = useCallback(async (accountId: string) => {
    if (!user?.id) {
      setAccounts(prev => prev.filter(a => a.id !== accountId));
      toast({ title: 'Account Disconnected' });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'disconnect_account', account_id: accountId, user_id: user.id }
      });

      if (error) throw error;
      await fetchAccounts();
      toast({ title: 'Account Disconnected' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [user?.id, fetchAccounts, toast]);

  // Share a clip to social media
  const shareClip = useCallback(async (
    clipId: string,
    platform: string,
    socialAccountId: string,
    caption: string,
    hashtags: string[],
    scheduledFor?: string
  ) => {
    if (!user?.id) {
      // Demo mode
      const newShare: SocialShare = {
        id: `demo-share-${Date.now()}`,
        clip_id: clipId,
        user_id: 'demo',
        social_account_id: socialAccountId,
        platform,
        post_id: `${platform}_${Date.now()}`,
        post_url: `https://${platform}.com/post/${Date.now()}`,
        caption,
        hashtags,
        status: scheduledFor ? 'scheduled' : 'published',
        scheduled_for: scheduledFor,
        published_at: scheduledFor ? undefined : new Date().toISOString(),
        views: 0,
        likes: 0,
        comments: 0,
        shares: 0,
        saves: 0,
        reach: 0,
        engagement_rate: 0,
        created_at: new Date().toISOString()
      };
      setShares(prev => [newShare, ...prev]);
      toast({ 
        title: scheduledFor ? 'Share Scheduled' : 'Shared Successfully', 
        description: `Your clip has been ${scheduledFor ? 'scheduled for' : 'shared to'} ${platform}.` 
      });
      return newShare;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: {
          action: 'share_clip',
          clip_id: clipId,
          user_id: user.id,
          platform,
          social_account_id: socialAccountId,
          caption,
          hashtags,
          scheduled_for: scheduledFor
        }
      });

      if (error) throw error;
      toast({ 
        title: scheduledFor ? 'Share Scheduled' : 'Shared Successfully', 
        description: `Your clip has been ${scheduledFor ? 'scheduled for' : 'shared to'} ${platform}.` 
      });
      return data.share;
    } catch (error: any) {
      toast({ title: 'Share Failed', description: error.message, variant: 'destructive' });
      throw error;
    } finally {
      setLoading(false);
    }
  }, [user?.id, toast]);

  // Bulk share multiple clips
  const bulkShareClips = useCallback(async (
    clips: { clip_id: string; title: string }[],
    platforms: { platform: string; social_account_id: string }[],
    captionTemplate: string,
    hashtags: string[],
    staggerMinutes: number,
    startTime?: string
  ): Promise<BulkShareResponse> => {
    if (!user?.id) {
      // Demo mode - simulate bulk sharing
      const results: BulkShareResult[] = [];
      const startDate = new Date(startTime || Date.now());

      for (let i = 0; i < clips.length; i++) {
        const clip = clips[i];
        const scheduledTime = new Date(startDate.getTime() + (i * staggerMinutes * 60 * 1000));
        
        const processedCaption = captionTemplate
          .replace(/{clip_title}/g, clip.title || `Clip ${i + 1}`)
          .replace(/{clip_number}/g, String(i + 1))
          .replace(/{total_clips}/g, String(clips.length))
          .replace(/{date}/g, scheduledTime.toLocaleDateString())
          .replace(/{time}/g, scheduledTime.toLocaleTimeString());

        for (const platformInfo of platforms) {
          const isScheduled = scheduledTime > new Date();
          
          const newShare: SocialShare = {
            id: `demo-bulk-${Date.now()}-${i}-${platformInfo.platform}`,
            clip_id: clip.clip_id,
            user_id: 'demo',
            social_account_id: platformInfo.social_account_id,
            platform: platformInfo.platform,
            post_id: isScheduled ? undefined : `${platformInfo.platform}_${Date.now()}_${i}`,
            post_url: isScheduled ? undefined : `https://${platformInfo.platform}.com/post/${Date.now()}_${i}`,
            caption: processedCaption,
            hashtags,
            status: isScheduled ? 'scheduled' : 'published',
            scheduled_for: isScheduled ? scheduledTime.toISOString() : undefined,
            published_at: isScheduled ? undefined : new Date().toISOString(),
            views: 0,
            likes: 0,
            comments: 0,
            shares: 0,
            saves: 0,
            reach: 0,
            engagement_rate: 0,
            created_at: new Date().toISOString(),
            bulk_share_group_id: `bulk_${Date.now()}`
          };

          setShares(prev => [newShare, ...prev]);
          if (isScheduled) {
            setScheduledShares(prev => [...prev, newShare]);
          }

          results.push({
            clip_id: clip.clip_id,
            platform: platformInfo.platform,
            success: true,
            share: newShare,
            scheduled_for: isScheduled ? scheduledTime.toISOString() : undefined
          });
        }
      }

      toast({ 
        title: 'Bulk Share Complete', 
        description: `${results.length} posts have been scheduled/shared.` 
      });

      return {
        success: true,
        total_shares: results.length,
        successful: results.length,
        failed: 0,
        results
      };
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: {
          action: 'bulk_share',
          clips,
          user_id: user.id,
          platforms,
          caption_template: captionTemplate,
          hashtags,
          stagger_minutes: staggerMinutes,
          start_time: startTime
        }
      });

      if (error) throw error;
      
      toast({ 
        title: 'Bulk Share Complete', 
        description: `${data.successful} of ${data.total_shares} posts scheduled/shared successfully.` 
      });
      
      // Refresh shares
      await fetchShares();
      
      return data as BulkShareResponse;
    } catch (error: any) {
      toast({ title: 'Bulk Share Failed', description: error.message, variant: 'destructive' });
      throw error;
    } finally {
      setLoading(false);
    }
  }, [user?.id, toast]);

  // Fetch scheduled shares for content calendar
  const fetchScheduledShares = useCallback(async (startDate?: string, endDate?: string) => {
    if (!user?.id) {
      // Demo scheduled shares
      const now = new Date();
      const demoScheduled: SocialShare[] = [
        {
          id: 'demo-scheduled-1',
          clip_id: 'demo-clip-1',
          user_id: 'demo',
          platform: 'instagram',
          caption: 'Upcoming post 1',
          hashtags: ['#scheduled'],
          status: 'scheduled',
          scheduled_for: new Date(now.getTime() + 3600000).toISOString(),
          views: 0, likes: 0, comments: 0, shares: 0, saves: 0, reach: 0, engagement_rate: 0,
          created_at: new Date().toISOString()
        },
        {
          id: 'demo-scheduled-2',
          clip_id: 'demo-clip-2',
          user_id: 'demo',
          platform: 'tiktok',
          caption: 'Upcoming post 2',
          hashtags: ['#fyp'],
          status: 'scheduled',
          scheduled_for: new Date(now.getTime() + 7200000).toISOString(),
          views: 0, likes: 0, comments: 0, shares: 0, saves: 0, reach: 0, engagement_rate: 0,
          created_at: new Date().toISOString()
        }
      ];
      setScheduledShares(demoScheduled);
      return demoScheduled;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { 
          action: 'get_scheduled_shares', 
          user_id: user.id,
          start_date: startDate,
          end_date: endDate
        }
      });

      if (error) throw error;
      setScheduledShares(data.shares || []);
      return data.shares;
    } catch (error) {
      console.error('Error fetching scheduled shares:', error);
      return [];
    }
  }, [user?.id]);

  // Cancel a scheduled share
  const cancelScheduledShare = useCallback(async (shareId: string) => {
    if (!user?.id) {
      setScheduledShares(prev => prev.filter(s => s.id !== shareId));
      setShares(prev => prev.filter(s => s.id !== shareId));
      toast({ title: 'Scheduled Post Cancelled' });
      return;
    }

    try {
      const { error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'cancel_scheduled_share', share_id: shareId, user_id: user.id }
      });

      if (error) throw error;
      setScheduledShares(prev => prev.filter(s => s.id !== shareId));
      toast({ title: 'Scheduled Post Cancelled' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  }, [user?.id, toast]);

  // Reschedule a share
  const rescheduleShare = useCallback(async (shareId: string, newScheduledFor: string) => {
    if (!user?.id) {
      setScheduledShares(prev => prev.map(s => 
        s.id === shareId ? { ...s, scheduled_for: newScheduledFor } : s
      ));
      toast({ title: 'Post Rescheduled' });
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { 
          action: 'reschedule_share', 
          share_id: shareId, 
          user_id: user.id,
          new_scheduled_for: newScheduledFor
        }
      });

      if (error) throw error;
      setScheduledShares(prev => prev.map(s => 
        s.id === shareId ? data.share : s
      ));
      toast({ title: 'Post Rescheduled' });
      return data.share;
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  }, [user?.id, toast]);

  // Fetch shares for a clip or all shares
  const fetchShares = useCallback(async (clipId?: string) => {
    if (!user?.id) {
      setShares(clipId ? demoShares.filter(s => s.clip_id === clipId) : demoShares);
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'get_shares', clip_id: clipId, user_id: user.id }
      });

      if (error) throw error;
      setShares(data.shares?.length > 0 ? data.shares : demoShares);
    } catch (error) {
      console.error('Error fetching shares:', error);
      setShares(demoShares);
    }
  }, [user?.id]);

  // Fetch analytics
  const fetchAnalytics = useCallback(async () => {
    if (!user?.id) {
      // Demo analytics
      setAnalytics({
        platforms: [
          { platform: 'instagram', posts: 5, views: 45000, likes: 3200, comments: 180, shares: 420, saves: 890, avgEngagement: '8.44' },
          { platform: 'tiktok', posts: 8, views: 320000, likes: 18500, comments: 1200, shares: 4500, saves: 6200, avgEngagement: '7.56' }
        ],
        totals: { posts: 13, views: 365000, likes: 21700, comments: 1380, shares: 4920, avgEngagement: '7.67' }
      });
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'get_all_analytics', user_id: user.id }
      });

      if (error) throw error;
      setAnalytics(data.analytics);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    }
  }, [user?.id]);

  // Refresh analytics for a specific share
  const refreshShareAnalytics = useCallback(async (shareId: string) => {
    if (!user?.id) return;

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'get_share_analytics', share_id: shareId, user_id: user.id }
      });

      if (error) throw error;
      setShares(prev => prev.map(s => s.id === shareId ? data.analytics : s));
      return data.analytics;
    } catch (error) {
      console.error('Error refreshing analytics:', error);
    }
  }, [user?.id]);

  // Get suggested hashtags
  const getSuggestedHashtags = useCallback(async (platform: string, category?: string, keywords?: string[]) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'get_suggested_hashtags', platform, category, keywords }
      });

      if (error) throw error;
      setSuggestedHashtags(data.hashtags);
      return data.hashtags;
    } catch (error) {
      // Fallback hashtags
      const fallback = ['#viral', '#trending', '#fyp', '#mustwatch', '#amazing'];
      setSuggestedHashtags(fallback);
      return fallback;
    }
  }, []);

  // Retry a failed share
  const retryShare = useCallback(async (shareId: string) => {
    if (!user?.id) {
      setShares(prev => prev.map(s => 
        s.id === shareId ? { ...s, status: 'published' as const, published_at: new Date().toISOString() } : s
      ));
      toast({ title: 'Share Retried', description: 'Your clip has been shared successfully.' });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'retry_share', share_id: shareId, user_id: user.id }
      });

      if (error) throw error;
      await fetchShares();
      toast({ title: 'Share Retried', description: 'Your clip has been shared successfully.' });
      return data.share;
    } catch (error: any) {
      toast({ title: 'Retry Failed', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [user?.id, fetchShares, toast]);

  // Delete a share
  const deleteShare = useCallback(async (shareId: string) => {
    if (!user?.id) {
      setShares(prev => prev.filter(s => s.id !== shareId));
      toast({ title: 'Share Deleted' });
      return;
    }

    try {
      const { error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'delete_share', share_id: shareId, user_id: user.id }
      });

      if (error) throw error;
      setShares(prev => prev.filter(s => s.id !== shareId));
      toast({ title: 'Share Deleted' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  }, [user?.id, toast]);

  // Analyze optimal posting times with AI

  const [optimalTimesAnalysis, setOptimalTimesAnalysis] = useState<OptimalTimesAnalysis | null>(null);
  const [optimalSlots, setOptimalSlots] = useState<OptimalSlot[]>([]);
  const [analyzingTimes, setAnalyzingTimes] = useState(false);

  const analyzeOptimalTimes = useCallback(async (platform?: string): Promise<OptimalTimesAnalysis | null> => {
    setAnalyzingTimes(true);
    
    // Demo mode - generate sample data
    if (!user?.id) {
      const demoAnalysis: OptimalTimesAnalysis = {
        recommendations: [
          {
            platform: platform || 'instagram',
            best_days: ['Tuesday', 'Wednesday', 'Friday'],
            best_hours: [11, 13, 19, 21],
            peak_engagement_window: '7PM - 9PM',
            reasoning: 'Based on your audience activity patterns, evening hours show 40% higher engagement',
            confidence_score: 82
          },
          {
            platform: 'tiktok',
            best_days: ['Tuesday', 'Thursday', 'Friday'],
            best_hours: [9, 12, 19, 22],
            peak_engagement_window: '7PM - 11PM',
            reasoning: 'TikTok users in your niche are most active during late evening hours',
            confidence_score: 78
          }
        ],
        heatmap_data: generateDemoHeatmap(platform),
        insights: [
          'Your posts perform 35% better when published between 7-9 PM',
          'Tuesday and Friday consistently show the highest engagement rates',
          'Avoid posting between 2-5 AM when your audience is least active',
          'Consider posting 15-30 minutes before peak hours to maximize reach'
        ],
        data_points: 47,
        analyzed_at: new Date().toISOString()
      };
      
      setOptimalTimesAnalysis(demoAnalysis);
      setAnalyzingTimes(false);
      return demoAnalysis;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'analyze_optimal_times', user_id: user.id, platform }
      });

      if (error) throw error;
      
      const analysis: OptimalTimesAnalysis = {
        recommendations: data.recommendations || [],
        heatmap_data: data.heatmap_data || {},
        insights: data.insights || [],
        data_points: data.data_points || 0,
        analyzed_at: data.analyzed_at || new Date().toISOString()
      };
      
      setOptimalTimesAnalysis(analysis);
      return analysis;
    } catch (error) {
      console.error('Error analyzing optimal times:', error);
      toast({ title: 'Analysis Failed', description: 'Could not analyze optimal posting times', variant: 'destructive' });
      return null;
    } finally {
      setAnalyzingTimes(false);
    }
  }, [user?.id, toast]);

  // Get optimal time slots for scheduling
  const getOptimalSlots = useCallback(async (platform: string, count: number = 7): Promise<OptimalSlot[]> => {
    if (!user?.id) {
      // Generate demo slots
      const slots: OptimalSlot[] = [];
      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const bestHours = [11, 13, 19, 21];
      const bestDays = ['Tuesday', 'Wednesday', 'Friday'];
      
      let currentDate = new Date();
      let slotsGenerated = 0;
      
      while (slotsGenerated < count) {
        currentDate.setDate(currentDate.getDate() + 1);
        const dayName = dayNames[currentDate.getDay()];
        const isBestDay = bestDays.includes(dayName);
        
        if (isBestDay || slotsGenerated < count / 2) {
          const hour = bestHours[Math.floor(Math.random() * bestHours.length)];
          const slotDate = new Date(currentDate);
          slotDate.setHours(hour, Math.floor(Math.random() * 30), 0, 0);
          
          slots.push({
            datetime: slotDate.toISOString(),
            day: dayName,
            hour,
            expected_engagement: isBestDay ? Math.round(70 + Math.random() * 25) : Math.round(50 + Math.random() * 30),
            reasoning: isBestDay 
              ? `${dayName} at ${hour}:00 is a peak engagement time for ${platform}`
              : `Good posting time based on ${platform} user activity patterns`,
            is_optimal: isBestDay
          });
          slotsGenerated++;
        }
      }
      
      setOptimalSlots(slots);
      return slots;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'get_optimal_slots', user_id: user.id, platform, count }
      });

      if (error) throw error;
      setOptimalSlots(data.slots || []);
      return data.slots || [];
    } catch (error) {
      console.error('Error getting optimal slots:', error);
      return [];
    }
  }, [user?.id]);

  // Auto-schedule clips at optimal times
  const autoScheduleAtOptimalTimes = useCallback(async (
    clips: { clip_id: string; title: string }[],
    platform: string,
    socialAccountId: string,
    captionTemplate: string,
    hashtags: string[],
    count: number = 7
  ) => {
    setLoading(true);
    
    if (!user?.id) {
      // Demo mode
      const slots = await getOptimalSlots(platform, count);
      const results: BulkShareResult[] = [];
      
      for (let i = 0; i < Math.min(clips.length, slots.length); i++) {
        const clip = clips[i];
        const slot = slots[i];
        
        const processedCaption = captionTemplate
          .replace(/{clip_title}/g, clip.title || `Clip ${i + 1}`)
          .replace(/{clip_number}/g, String(i + 1))
          .replace(/{total_clips}/g, String(clips.length))
          .replace(/{date}/g, new Date(slot.datetime).toLocaleDateString())
          .replace(/{time}/g, new Date(slot.datetime).toLocaleTimeString());

        const newShare: SocialShare = {
          id: `demo-auto-${Date.now()}-${i}`,
          clip_id: clip.clip_id,
          user_id: 'demo',
          social_account_id: socialAccountId,
          platform,
          caption: processedCaption,
          hashtags,
          status: 'scheduled',
          scheduled_for: slot.datetime,
          views: 0, likes: 0, comments: 0, shares: 0, saves: 0, reach: 0, engagement_rate: 0,
          created_at: new Date().toISOString(),
          bulk_share_group_id: `auto_optimal_${Date.now()}`
        };

        setShares(prev => [newShare, ...prev]);
        setScheduledShares(prev => [...prev, newShare]);

        results.push({
          clip_id: clip.clip_id,
          platform,
          success: true,
          share: newShare,
          scheduled_for: slot.datetime
        });
      }

      toast({
        title: 'Auto-Scheduled Successfully',
        description: `${results.length} clips scheduled at optimal times for ${platform}`
      });

      setLoading(false);
      return { success: true, total_scheduled: results.length, results };
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: {
          action: 'auto_schedule_optimal',
          user_id: user.id,
          clips,
          platform,
          social_account_id: socialAccountId,
          caption_template: captionTemplate,
          hashtags,
          count
        }
      });

      if (error) throw error;
      
      toast({
        title: 'Auto-Scheduled Successfully',
        description: `${data.total_scheduled} clips scheduled at optimal times`
      });
      
      await fetchScheduledShares();
      return data;
    } catch (error: any) {
      toast({ title: 'Auto-Schedule Failed', description: error.message, variant: 'destructive' });
      throw error;
    } finally {
      setLoading(false);
    }
  }, [user?.id, getOptimalSlots, fetchScheduledShares, toast]);

  // Audience Insights
  const [audienceInsights, setAudienceInsights] = useState<AudienceInsights | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  const fetchAudienceInsights = useCallback(async (platform?: string): Promise<AudienceInsights | null> => {
    setLoadingInsights(true);
    
    if (!user?.id) {
      // Generate demo audience insights
      const demoInsights: AudienceInsights = generateDemoAudienceInsights();
      setAudienceInsights(demoInsights);
      setLoadingInsights(false);
      return demoInsights;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-social-sharing', {
        body: { action: 'get_audience_insights', user_id: user.id, platform }
      });

      if (error) throw error;
      setAudienceInsights(data.insights);
      return data.insights;
    } catch (error) {
      console.error('Error fetching audience insights:', error);
      toast({ title: 'Analysis Failed', description: 'Could not fetch audience insights', variant: 'destructive' });
      // Return demo data on error
      const demoInsights = generateDemoAudienceInsights();
      setAudienceInsights(demoInsights);
      return demoInsights;
    } finally {
      setLoadingInsights(false);
    }
  }, [user?.id, toast]);

  useEffect(() => {
    fetchAccounts();
  }, [fetchAccounts]);

  return {
    accounts,
    shares,
    scheduledShares,
    analytics,
    loading,
    suggestedHashtags,
    optimalTimesAnalysis,
    optimalSlots,
    analyzingTimes,
    audienceInsights,
    loadingInsights,
    fetchAccounts,
    connectAccount,
    disconnectAccount,
    shareClip,
    bulkShareClips,
    fetchShares,
    fetchScheduledShares,
    cancelScheduledShare,
    rescheduleShare,
    fetchAnalytics,
    refreshShareAnalytics,
    getSuggestedHashtags,
    retryShare,
    deleteShare,
    analyzeOptimalTimes,
    getOptimalSlots,
    autoScheduleAtOptimalTimes,
    fetchAudienceInsights
  };
}

// Helper function to generate demo heatmap data
function generateDemoHeatmap(platform?: string): HeatmapData {
  const platforms = platform ? [platform] : ['instagram', 'tiktok', 'twitter', 'facebook', 'youtube'];
  const heatmap: HeatmapData = {};
  
  const platformPeaks: Record<string, { days: number[]; hours: number[] }> = {
    instagram: { days: [2, 3, 5], hours: [11, 13, 19, 21] },
    tiktok: { days: [2, 4, 5], hours: [9, 12, 19, 22] },
    twitter: { days: [1, 2, 3], hours: [8, 12, 17, 18] },
    facebook: { days: [3, 4, 5], hours: [9, 13, 16, 19] },
    youtube: { days: [4, 5, 6], hours: [12, 15, 18, 21] }
  };

  platforms.forEach(p => {
    heatmap[p] = {};
    const peaks = platformPeaks[p] || platformPeaks.instagram;
    
    for (let day = 0; day < 7; day++) {
      heatmap[p][day] = {};
      const isDayBest = peaks.days.includes(day);
      
      for (let hour = 0; hour < 24; hour++) {
        const isHourBest = peaks.hours.includes(hour);
        let score = 20 + Math.random() * 20;
        
        if (isDayBest) score += 25;
        if (isHourBest) score += 30;
        if (isDayBest && isHourBest) score += 15;
        
        score = Math.min(100, Math.max(0, score + (Math.random() - 0.5) * 10));
        heatmap[p][day][hour] = Math.round(score);
      }
    }
  });

  return heatmap;
}

// Helper function to generate demo audience insights
function generateDemoAudienceInsights(): AudienceInsights {
  return {
    demographics: {
      age_groups: [
        { range: "18-24", percentage: 32, engagement_index: 1.3 },
        { range: "25-34", percentage: 38, engagement_index: 1.5 },
        { range: "35-44", percentage: 18, engagement_index: 1.0 },
        { range: "45-54", percentage: 8, engagement_index: 0.7 },
        { range: "55+", percentage: 4, engagement_index: 0.5 }
      ],
      gender: [
        { type: "Female", percentage: 58 },
        { type: "Male", percentage: 38 },
        { type: "Other", percentage: 4 }
      ],
      top_locations: [
        { location: "United States", percentage: 42, city: "Los Angeles" },
        { location: "United Kingdom", percentage: 18, city: "London" },
        { location: "Canada", percentage: 14, city: "Toronto" },
        { location: "Australia", percentage: 10, city: "Sydney" },
        { location: "Germany", percentage: 6, city: "Berlin" }
      ]
    },
    engagement_segments: [
      { segment_name: "Super Fans", percentage: 6, characteristics: ["Engage with every post", "Share content frequently", "Comment regularly"], avg_engagement_rate: 18.5, recommended_content: "Exclusive behind-the-scenes, early access" },
      { segment_name: "Active Followers", percentage: 22, characteristics: ["Like most posts", "Occasional comments", "Regular viewers"], avg_engagement_rate: 9.2, recommended_content: "Product showcases, tutorials, tips" },
      { segment_name: "Casual Viewers", percentage: 48, characteristics: ["View stories", "Occasional likes", "Scroll-through behavior"], avg_engagement_rate: 3.5, recommended_content: "Eye-catching visuals, short-form content" },
      { segment_name: "Passive Followers", percentage: 24, characteristics: ["Rarely engage", "May have notifications off", "Infrequent visitors"], avg_engagement_rate: 0.8, recommended_content: "Re-engagement campaigns, contests" }
    ],
    content_preferences: {
      top_performing_types: [
        { type: "Product Demos", avg_engagement: 11.5, avg_views: 14000, trend: "up" },
        { type: "Behind-the-Scenes", avg_engagement: 9.8, avg_views: 11000, trend: "up" },
        { type: "Tutorials", avg_engagement: 8.5, avg_views: 16000, trend: "stable" },
        { type: "User-Generated Content", avg_engagement: 7.8, avg_views: 8500, trend: "up" },
        { type: "Promotional Posts", avg_engagement: 3.8, avg_views: 7000, trend: "down" }
      ],
      optimal_content_length: { video: "15-30 seconds", caption: "100-150 characters", hashtags: "5-8 relevant tags" },
      trending_topics: ["sustainability", "authenticity", "behind-the-scenes", "tutorials", "lifestyle"],
      hashtag_performance: [
        { hashtag: "#fyp", reach_multiplier: 2.1 },
        { hashtag: "#trending", reach_multiplier: 1.7 },
        { hashtag: "#viral", reach_multiplier: 1.4 }
      ]
    },
    growth_trends: {
      follower_growth: [
        { period: "Week 1", followers: 14200, change: 0 },
        { period: "Week 2", followers: 14580, change: 380 },
        { period: "Week 3", followers: 14920, change: 340 },
        { period: "Week 4", followers: 15420, change: 500 }
      ],
      engagement_trend: [
        { period: "Week 1", rate: 5.8 },
        { period: "Week 2", rate: 6.4 },
        { period: "Week 3", rate: 6.9 },
        { period: "Week 4", rate: 7.2 }
      ],
      growth_rate_percentage: 8.2,
      projected_monthly_growth: 1200,
      best_growth_drivers: ["Consistent posting schedule", "Engaging with comments", "Collaborations with similar creators"]
    },
    ai_recommendations: [
      { category: "Content Strategy", priority: "high", recommendation: "Increase behind-the-scenes content by 30% - your audience shows 2x higher engagement with authentic, unpolished content", expected_impact: "+15% engagement rate" },
      { category: "Posting Schedule", priority: "high", recommendation: "Shift 40% of posts to evening hours (7-9 PM) when your 25-34 age segment is most active", expected_impact: "+20% reach" },
      { category: "Audience Growth", priority: "medium", recommendation: "Create more tutorial content - this format attracts new followers at 3x the rate of promotional posts", expected_impact: "+500 followers/month" },
      { category: "Engagement", priority: "medium", recommendation: "Respond to comments within 1 hour to boost algorithm visibility and build community", expected_impact: "+25% comment rate" },
      { category: "Content Topics", priority: "medium", recommendation: "Incorporate sustainability messaging - 58% of your audience (females 25-34) highly values eco-conscious brands", expected_impact: "+10% saves and shares" }
    ]
  };
}
