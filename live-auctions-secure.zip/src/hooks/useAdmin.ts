import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

export interface AdminStatistics {
  users: {
    total: number;
    sellers: number;
    buyers: number;
    verifiedSellers: number;
    banned: number;
    newThisMonth: number;
  };
  products: {
    total: number;
    pending: number;
    approved: number;
    flagged: number;
    newThisMonth: number;
  };
  orders: {
    total: number;
    completed: number;
    pending: number;
    totalRevenue: number;
  };
  verifications: {
    pending: number;
  };
  promoCodes: {
    total: number;
    active: number;
    totalUses: number;
  };
}

export interface AdminUser {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  phone?: string;
  user_type: 'buyer' | 'seller' | 'admin';
  store_name?: string;
  avatar_url?: string;
  is_verified: boolean;
  is_banned: boolean;
  ban_reason?: string;
  banned_at?: string;
  created_at: string;
}

export interface AdminProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  seller_id: string;
  moderation_status: 'pending' | 'approved' | 'rejected' | 'flagged';
  moderation_notes?: string;
  created_at: string;
  user_profiles?: {
    full_name: string;
    store_name: string;
    email: string;
  };
}

export interface AdminCategory {
  id: string;
  name: string;
  slug: string;
  icon?: string;
  category_description?: string;
  is_active: boolean;
  sort_order: number;
  created_at: string;
}

export interface ActivityLog {
  id: string;
  action_type: string;
  entity_type: string;
  entity_id?: string;
  user_id?: string;
  admin_id?: string;
  details?: any;
  created_at: string;
}

export interface PromoCode {
  id: string;
  code: string;
  description?: string;
  discount_type: 'percentage' | 'fixed_amount';
  discount_value: number;
  min_purchase_amount: number;
  max_uses?: number;
  current_uses: number;
  start_date?: string;
  end_date?: string;
  is_active: boolean;
  category_restrictions: string[];
  seller_restrictions: string[];
  created_by?: string;
  created_at: string;
  updated_at: string;
  usage_stats?: {
    total_uses: number;
    total_discount_given: number;
    total_order_value: number;
    recent_uses: Array<{
      discount_applied: number;
      order_total: number;
      used_at: string;
    }>;
  };
}

export interface PromoCodeFormData {
  code: string;
  description: string;
  discountType: 'percentage' | 'fixed_amount';
  discountValue: number;
  minPurchaseAmount: number;
  maxUses?: number;
  startDate?: string;
  endDate?: string;
  categoryRestrictions: string[];
  sellerRestrictions: string[];
}

export const useAdmin = () => {
  const [loading, setLoading] = useState(false);
  const [statistics, setStatistics] = useState<AdminStatistics | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [products, setProducts] = useState<AdminProduct[]>([]);
  const [categories, setCategories] = useState<AdminCategory[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([]);
  const [pagination, setPagination] = useState({ total: 0, page: 1, totalPages: 1 });

  const fetchStatistics = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'get_statistics' }
      });

      if (error) throw error;
      if (data.success) {
        setStatistics(data.statistics);
      }
    } catch (error: any) {
      console.error('Error fetching statistics:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les statistiques",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchUsers = useCallback(async (params: {
    page?: number;
    limit?: number;
    search?: string;
    userType?: string;
    status?: string;
  } = {}) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'get_users', ...params }
      });

      if (error) throw error;
      if (data.success) {
        setUsers(data.users);
        setPagination({
          total: data.total,
          page: data.page,
          totalPages: data.totalPages
        });
      }
    } catch (error: any) {
      console.error('Error fetching users:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les utilisateurs",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, []);

  const banUser = useCallback(async (userId: string, reason: string, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'ban_user', userId, reason, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Utilisateur banni",
          description: "L'utilisateur a été banni avec succès"
        });
        return true;
      }
    } catch (error: any) {
      console.error('Error banning user:', error);
      toast({
        title: "Erreur",
        description: "Impossible de bannir l'utilisateur",
        variant: "destructive"
      });
    }
    return false;
  }, []);

  const unbanUser = useCallback(async (userId: string, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'unban_user', userId, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Utilisateur débanni",
          description: "L'utilisateur a été débanni avec succès"
        });
        return true;
      }
    } catch (error: any) {
      console.error('Error unbanning user:', error);
      toast({
        title: "Erreur",
        description: "Impossible de débannir l'utilisateur",
        variant: "destructive"
      });
    }
    return false;
  }, []);

  const verifySeller = useCallback(async (userId: string, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'verify_seller', userId, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Vendeur vérifié",
          description: "Le vendeur a été vérifié avec succès"
        });
        return true;
      }
    } catch (error: any) {
      console.error('Error verifying seller:', error);
      toast({
        title: "Erreur",
        description: "Impossible de vérifier le vendeur",
        variant: "destructive"
      });
    }
    return false;
  }, []);

  const unverifySeller = useCallback(async (userId: string, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'unverify_seller', userId, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Vérification retirée",
          description: "La vérification du vendeur a été retirée"
        });
        return true;
      }
    } catch (error: any) {
      console.error('Error unverifying seller:', error);
      toast({
        title: "Erreur",
        description: "Impossible de retirer la vérification",
        variant: "destructive"
      });
    }
    return false;
  }, []);

  const fetchProductsForModeration = useCallback(async (params: {
    page?: number;
    limit?: number;
    status?: string;
    search?: string;
  } = {}) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'get_products_for_moderation', ...params }
      });

      if (error) throw error;
      if (data.success) {
        setProducts(data.products);
        setPagination({
          total: data.total,
          page: data.page,
          totalPages: data.totalPages
        });
      }
    } catch (error: any) {
      console.error('Error fetching products:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les produits",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, []);

  const moderateProduct = useCallback(async (
    productId: string,
    status: 'approved' | 'rejected' | 'flagged',
    notes: string,
    adminId: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'moderate_product', productId, status, notes, adminId }
      });

      if (error) throw error;
      if (data.success) {
        const statusText = status === 'approved' ? 'approuvé' : status === 'rejected' ? 'rejeté' : 'signalé';
        toast({
          title: `Produit ${statusText}`,
          description: `Le produit a été ${statusText} avec succès`
        });
        return true;
      }
    } catch (error: any) {
      console.error('Error moderating product:', error);
      toast({
        title: "Erreur",
        description: "Impossible de modérer le produit",
        variant: "destructive"
      });
    }
    return false;
  }, []);

  const fetchCategories = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'get_categories' }
      });

      if (error) throw error;
      if (data.success) {
        setCategories(data.categories);
      }
    } catch (error: any) {
      console.error('Error fetching categories:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les catégories",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, []);

  const createCategory = useCallback(async (
    name: string,
    slug: string,
    icon: string,
    description: string,
    adminId: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'create_category', name, slug, icon, description, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Catégorie créée",
          description: "La catégorie a été créée avec succès"
        });
        return data.category;
      }
    } catch (error: any) {
      console.error('Error creating category:', error);
      toast({
        title: "Erreur",
        description: "Impossible de créer la catégorie",
        variant: "destructive"
      });
    }
    return null;
  }, []);

  const updateCategory = useCallback(async (
    categoryId: string,
    updates: Partial<AdminCategory>,
    adminId: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'update_category', categoryId, ...updates, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Catégorie mise à jour",
          description: "La catégorie a été mise à jour avec succès"
        });
        return data.category;
      }
    } catch (error: any) {
      console.error('Error updating category:', error);
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour la catégorie",
        variant: "destructive"
      });
    }
    return null;
  }, []);

  const deleteCategory = useCallback(async (categoryId: string, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'delete_category', categoryId, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Catégorie supprimée",
          description: "La catégorie a été supprimée avec succès"
        });
        return true;
      }
    } catch (error: any) {
      console.error('Error deleting category:', error);
      toast({
        title: "Erreur",
        description: "Impossible de supprimer la catégorie",
        variant: "destructive"
      });
    }
    return false;
  }, []);

  const fetchActivityLogs = useCallback(async (params: {
    page?: number;
    limit?: number;
    actionType?: string;
    startDate?: string;
    endDate?: string;
  } = {}) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'get_activity_logs', ...params }
      });

      if (error) throw error;
      if (data.success) {
        setActivityLogs(data.logs);
        setPagination({
          total: data.total,
          page: data.page,
          totalPages: data.totalPages
        });
      }
    } catch (error: any) {
      console.error('Error fetching activity logs:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les logs d'activité",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, []);

  const exportReport = useCallback(async (
    reportType: 'users' | 'products' | 'orders' | 'activity' | 'promo_codes',
    startDate?: string,
    endDate?: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'export_report', reportType, startDate, endDate }
      });

      if (error) throw error;
      if (data.success) {
        const items = data.data;
        if (items.length === 0) {
          toast({
            title: "Aucune donnée",
            description: "Aucune donnée à exporter pour cette période",
            variant: "destructive"
          });
          return;
        }

        const headers = Object.keys(items[0]);
        const csvContent = [
          headers.join(','),
          ...items.map((item: any) => 
            headers.map(h => {
              const val = item[h];
              if (val === null || val === undefined) return '';
              if (typeof val === 'object') return JSON.stringify(val).replace(/,/g, ';');
              return String(val).replace(/,/g, ';');
            }).join(',')
          )
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `rapport_${reportType}_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        toast({
          title: "Export réussi",
          description: "Le rapport a été téléchargé avec succès"
        });
      }
    } catch (error: any) {
      console.error('Error exporting report:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'exporter le rapport",
        variant: "destructive"
      });
    }
  }, []);

  // PROMO CODES FUNCTIONS
  const fetchPromoCodes = useCallback(async (params: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
  } = {}) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'get_promo_codes', ...params }
      });

      if (error) throw error;
      if (data.success) {
        setPromoCodes(data.promoCodes);
        setPagination({
          total: data.total,
          page: data.page,
          totalPages: data.totalPages
        });
      }
    } catch (error: any) {
      console.error('Error fetching promo codes:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les codes promo",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, []);

  const createPromoCode = useCallback(async (formData: PromoCodeFormData, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'create_promo_code', ...formData, adminId }
      });

      if (error) throw error;
      
      if (data.success) {
        toast({
          title: "Code promo créé",
          description: `Le code ${formData.code.toUpperCase()} a été créé avec succès`
        });
        return data.promoCode;
      } else {
        toast({
          title: "Erreur",
          description: data.error || "Impossible de créer le code promo",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      console.error('Error creating promo code:', error);
      toast({
        title: "Erreur",
        description: "Impossible de créer le code promo",
        variant: "destructive"
      });
    }
    return null;
  }, []);

  const updatePromoCode = useCallback(async (promoCodeId: string, formData: Partial<PromoCodeFormData>, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'update_promo_code', promoCodeId, ...formData, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Code promo mis à jour",
          description: "Le code promo a été mis à jour avec succès"
        });
        return data.promoCode;
      }
    } catch (error: any) {
      console.error('Error updating promo code:', error);
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour le code promo",
        variant: "destructive"
      });
    }
    return null;
  }, []);

  const togglePromoCode = useCallback(async (promoCodeId: string, isActive: boolean, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'toggle_promo_code', promoCodeId, isActive, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: isActive ? "Code promo activé" : "Code promo désactivé",
          description: `Le code promo a été ${isActive ? 'activé' : 'désactivé'} avec succès`
        });
        return data.promoCode;
      }
    } catch (error: any) {
      console.error('Error toggling promo code:', error);
      toast({
        title: "Erreur",
        description: "Impossible de modifier le statut du code promo",
        variant: "destructive"
      });
    }
    return null;
  }, []);

  const deletePromoCode = useCallback(async (promoCodeId: string, adminId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'delete_promo_code', promoCodeId, adminId }
      });

      if (error) throw error;
      if (data.success) {
        toast({
          title: "Code promo supprimé",
          description: "Le code promo a été supprimé avec succès"
        });
        return true;
      }
    } catch (error: any) {
      console.error('Error deleting promo code:', error);
      toast({
        title: "Erreur",
        description: "Impossible de supprimer le code promo",
        variant: "destructive"
      });
    }
    return false;
  }, []);

  const validatePromoCode = useCallback(async (
    code: string,
    cartTotal: number,
    categoryId?: string,
    sellerId?: string,
    userId?: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-admin', {
        body: { action: 'validate_promo_code', code, cartTotal, categoryId, sellerId, userId }
      });

      if (error) throw error;
      return data;
    } catch (error: any) {
      console.error('Error validating promo code:', error);
      return { success: false, error: 'Erreur de validation' };
    }
  }, []);

  return {
    loading,
    statistics,
    users,
    products,
    categories,
    activityLogs,
    promoCodes,
    pagination,
    fetchStatistics,
    fetchUsers,
    banUser,
    unbanUser,
    verifySeller,
    unverifySeller,
    fetchProductsForModeration,
    moderateProduct,
    fetchCategories,
    createCategory,
    updateCategory,
    deleteCategory,
    fetchActivityLogs,
    exportReport,
    // Promo codes
    fetchPromoCodes,
    createPromoCode,
    updatePromoCode,
    togglePromoCode,
    deletePromoCode,
    validatePromoCode
  };
};
