import { useState, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

// Demo mode flag
const isDemoMode = !isSupabaseConfigured;

export interface LiveStreamData {
  id: string;
  seller_id: string;
  title: string;
  description?: string;
  thumbnail_url?: string;
  stream_url?: string;
  status: 'scheduled' | 'live' | 'ended' | 'cancelled';
  category?: string;
  viewer_count?: number;
  peak_viewers?: number;
  max_viewers?: number;
  scheduled_at?: string;
  started_at?: string;
  ended_at?: string;
  created_at?: string;
  replay_enabled?: boolean;
  replay_url?: string;
  replay_views?: number;
  replay_thumbnail?: string;
  duration_seconds?: number;
  total_sales?: number;
  total_revenue?: number;
  recording_status?: 'none' | 'recording' | 'processing' | 'completed' | 'simulated';
  recording_resource_id?: string;
  recording_sid?: string;
  live_stream_products?: StreamProduct[];
  profiles?: {
    id: string;
    full_name: string;
    avatar_url?: string;
    is_verified?: boolean;
  };
  seller?: {
    id: string;
    full_name: string;
    avatar_url?: string;
    store_name?: string;
    is_verified?: boolean;
  };
}

export interface StreamProduct {
  id: string;
  live_stream_id: string;
  product_id?: string;
  product_name: string;
  product_price: number;
  product_image?: string;
  product_original_price?: number;
  is_highlighted?: boolean;
  highlighted_at?: string;
  units_sold?: number;
  display_order?: number;
}

export interface ChatMessage {
  id: string;
  stream_id: string;
  user_id: string;
  user_name: string;
  user_avatar?: string;
  message: string;
  message_type: 'chat' | 'join' | 'leave' | 'purchase' | 'highlight';
  created_at: string;
  timestamp_offset_ms?: number;
}

// Demo data for live streams
const demoReplays: LiveStreamData[] = [
  {
    id: 'demo-replay-1',
    seller_id: 'demo-seller-1',
    title: 'Collection Printemps - Mode Femme',
    description: 'Découvrez notre collection printemps avec des pièces exclusives',
    thumbnail_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=300&fit=crop',
    status: 'ended',
    category: 'Mode',
    viewer_count: 0,
    peak_viewers: 245,
    replay_enabled: true,
    replay_views: 1250,
    duration_seconds: 3600,
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    seller: {
      id: 'demo-seller-1',
      full_name: 'Fashion Store',
      avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      store_name: 'Fashion Store',
      is_verified: true
    }
  },
  {
    id: 'demo-replay-2',
    seller_id: 'demo-seller-2',
    title: 'Tech Unboxing - iPhone 16 Pro',
    description: 'Unboxing et test du nouveau iPhone 16 Pro',
    thumbnail_url: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400&h=300&fit=crop',
    status: 'ended',
    category: 'Électronique',
    viewer_count: 0,
    peak_viewers: 520,
    replay_enabled: true,
    replay_views: 3400,
    duration_seconds: 2700,
    created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    seller: {
      id: 'demo-seller-2',
      full_name: 'Tech World',
      avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      store_name: 'Tech World',
      is_verified: true
    }
  }
];

const demoLiveStreams: LiveStreamData[] = [
  {
    id: 'demo-live-1',
    seller_id: 'demo-seller-3',
    title: 'Vente Flash Beauté - 50% de réduction',
    description: 'Profitez de nos offres exceptionnelles sur les produits de beauté',
    thumbnail_url: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=300&fit=crop',
    status: 'live',
    category: 'Beauté',
    viewer_count: 156,
    peak_viewers: 200,
    started_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString(),
    seller: {
      id: 'demo-seller-3',
      full_name: 'Beauty Corner',
      avatar_url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      store_name: 'Beauty Corner',
      is_verified: true
    }
  }
];

export const useLiveStream = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPublicReplays = useCallback(async (options?: { 
    sellerId?: string; 
    category?: string; 
    limit?: number; 
    offset?: number 
  }): Promise<LiveStreamData[]> => {
    // Always return demo data to avoid network errors
    let filtered = [...demoReplays];
    if (options?.sellerId) {
      filtered = filtered.filter(r => r.seller_id === options.sellerId);
    }
    if (options?.category) {
      filtered = filtered.filter(r => r.category === options.category);
    }
    return filtered;
  }, []);



  const fetchReplayWithMessages = useCallback(async (liveStreamId: string): Promise<{
    replay: LiveStreamData | null;
    messages: ChatMessage[];
  }> => {
    setLoading(true);
    setError(null);
    
    // Return demo data in demo mode
    if (isDemoMode) {
      const replay = demoReplays.find(r => r.id === liveStreamId) || null;
      setLoading(false);
      return { 
        replay, 
        messages: [
          {
            id: 'msg-1',
            stream_id: liveStreamId,
            user_id: 'user-1',
            user_name: 'Marie',
            message: 'Super collection !',
            message_type: 'chat',
            created_at: new Date().toISOString(),
            timestamp_offset_ms: 5000
          },
          {
            id: 'msg-2',
            stream_id: liveStreamId,
            user_id: 'user-2',
            user_name: 'Jean',
            message: 'J\'adore les couleurs',
            message_type: 'chat',
            created_at: new Date().toISOString(),
            timestamp_offset_ms: 15000
          }
        ]
      };
    }

    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'get_replay', liveStreamId }
      });

      if (fnError) throw fnError;
      if (!data?.success) throw new Error(data?.error || 'Failed to fetch replay');
      
      return { replay: data.replay || null, messages: data.messages || [] };
    } catch (err: any) {
      console.error('Error fetching replay:', err);
      setError(err.message);
      return { replay: null, messages: [] };
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchReplayChatByOffset = useCallback(async (
    liveStreamId: string, 
    fromOffsetMs: number, 
    toOffsetMs?: number
  ): Promise<ChatMessage[]> => {
    // Return demo data in demo mode
    if (isDemoMode) {
      return [];
    }

    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { 
          action: 'get_replay_chat', 
          liveStreamId,
          fromOffsetMs,
          toOffsetMs
        }
      });

      if (fnError) throw fnError;
      return data?.messages || [];
    } catch (err: any) {
      console.error('Error fetching replay chat:', err);
      return [];
    }
  }, []);

  const incrementReplayViews = useCallback(async (liveStreamId: string): Promise<number> => {
    // In demo mode, just return a mock value
    if (isDemoMode) {
      return Math.floor(Math.random() * 1000) + 100;
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'increment_replay_views', liveStreamId }
      });
      return data?.views || 0;
    } catch (err: any) {
      console.error('Error incrementing replay views:', err);
      return 0;
    }
  }, []);

  const checkLimits = useCallback(async () => {
    setLoading(true);
    
    // Return demo limits in demo mode
    if (isDemoMode) {
      setLoading(false);
      return {
        canGoLive: true,
        livesThisMonth: 2,
        maxLivesPerMonth: 10,
        productsCount: 5,
        maxProducts: 50
      };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'check_limits' }
      });
      return data;
    } catch (err: any) {
      console.error('Error checking limits:', err);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const scheduleLive = useCallback(async (liveData: any) => {
    setLoading(true);
    
    // In demo mode, return a mock scheduled live
    if (isDemoMode) {
      setLoading(false);
      return {
        id: `demo-scheduled-${Date.now()}`,
        ...liveData,
        status: 'scheduled',
        created_at: new Date().toISOString()
      };
    }

    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'schedule', ...liveData }
      });
      if (fnError) throw fnError;
      return data?.liveStream;
    } catch (err: any) {
      console.error('Error scheduling live:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const startLive = useCallback(async (
    liveStreamId: string, 
    recordingResourceId?: string, 
    recordingSid?: string
  ) => {
    // In demo mode, return a mock response
    if (isDemoMode) {
      return {
        success: true,
        liveStream: {
          id: liveStreamId,
          status: 'live',
          started_at: new Date().toISOString()
        }
      };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { 
          action: 'start', 
          liveStreamId,
          recordingResourceId,
          recordingSid
        }
      });
      return data;
    } catch (err: any) {
      console.error('Error starting live:', err);
      throw err;
    }
  }, []);

  const endLive = useCallback(async (
    liveStreamId: string, 
    enableReplay: boolean = true,
    replayUrl?: string
  ) => {
    // In demo mode, return a mock response
    if (isDemoMode) {
      return {
        success: true,
        liveStream: {
          id: liveStreamId,
          status: 'ended',
          ended_at: new Date().toISOString(),
          replay_enabled: enableReplay
        }
      };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { 
          action: 'end', 
          liveStreamId, 
          enableReplay,
          replayUrl
        }
      });
      return data;
    } catch (err: any) {
      console.error('Error ending live:', err);
      throw err;
    }
  }, []);

  const updateReplayUrl = useCallback(async (liveStreamId: string, replayUrl: string) => {
    // In demo mode, return a mock response
    if (isDemoMode) {
      return { success: true };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { 
          action: 'update_replay_url', 
          liveStreamId,
          replayUrl
        }
      });
      return data;
    } catch (err: any) {
      console.error('Error updating replay URL:', err);
      throw err;
    }
  }, []);

  const toggleReplay = useCallback(async (liveStreamId: string, enabled: boolean) => {
    // In demo mode, return a mock response
    if (isDemoMode) {
      return { success: true, replay_enabled: enabled };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'toggle_replay', liveStreamId, enabled }
      });
      return data;
    } catch (err: any) {
      console.error('Error toggling replay:', err);
      throw err;
    }
  }, []);

  const fetchSellerReplays = useCallback(async (): Promise<LiveStreamData[]> => {
    // Return demo data in demo mode
    if (isDemoMode) {
      return demoReplays;
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'get_seller_replays' }
      });
      return data?.replays || [];
    } catch (err: any) {
      console.error('Error fetching seller replays:', err);
      return demoReplays;
    }
  }, []);

  const fetchSellerLives = useCallback(async (): Promise<LiveStreamData[]> => {
    // Return demo data in demo mode
    if (isDemoMode) {
      return demoLiveStreams;
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'get_seller_lives' }
      });
      return data?.lives || [];
    } catch (err: any) {
      console.error('Error fetching seller lives:', err);
      return [];
    }
  }, []);

  const joinLive = useCallback(async (liveStreamId: string) => {
    // In demo mode, return a mock response
    if (isDemoMode) {
      return { success: true, viewer_count: Math.floor(Math.random() * 200) + 50 };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'join', liveStreamId }
      });
      return data;
    } catch (err: any) {
      return null;
    }
  }, []);

  const leaveLive = useCallback(async (liveStreamId: string) => {
    // In demo mode, return a mock response
    if (isDemoMode) {
      return { success: true };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'leave', liveStreamId }
      });
      return data;
    } catch (err: any) {
      return null;
    }
  }, []);

  const sendMessage = useCallback(async (liveStreamId: string, message: string) => {
    // In demo mode, return a mock message
    if (isDemoMode) {
      return {
        id: `msg-${Date.now()}`,
        stream_id: liveStreamId,
        user_id: 'demo-user',
        user_name: 'Vous',
        message,
        message_type: 'chat',
        created_at: new Date().toISOString()
      };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'send_message', liveStreamId, message }
      });
      return data?.message;
    } catch (err: any) {
      return null;
    }
  }, []);

  const highlightProduct = useCallback(async (liveStreamId: string, productId: string) => {
    // In demo mode, return a mock response
    if (isDemoMode) {
      return { id: productId, is_highlighted: true };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'highlight_product', liveStreamId, productId }
      });
      return data?.product;
    } catch (err: any) {
      return null;
    }
  }, []);

  const cancelLive = useCallback(async (liveStreamId: string) => {
    // In demo mode, return a mock response
    if (isDemoMode) {
      return { id: liveStreamId, status: 'cancelled' };
    }

    try {
      const { data } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'cancel', liveStreamId }
      });
      return data?.liveStream;
    } catch (err: any) {
      throw err;
    }
  }, []);

  return {
    loading,
    error,
    checkLimits,
    scheduleLive,
    startLive,
    endLive,
    updateReplayUrl,
    toggleReplay,
    fetchSellerReplays,
    fetchSellerLives,
    fetchPublicReplays,
    fetchReplayWithMessages,
    fetchReplayChatByOffset,
    incrementReplayViews,
    joinLive,
    leaveLive,
    sendMessage,
    highlightProduct,
    cancelLive
  };
};
