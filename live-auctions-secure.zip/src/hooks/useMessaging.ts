import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

// Demo mode flag
const isDemoMode = !isSupabaseConfigured;

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  sender_type: 'buyer' | 'seller';
  message_type: 'text' | 'image' | 'price_offer' | 'price_response' | 'system';
  content: string | null;
  image_url: string | null;
  offered_price: number | null;
  original_price: number | null;
  price_status: 'pending' | 'accepted' | 'rejected' | 'countered' | null;
  is_read: boolean;
  created_at: string;
}

export interface Conversation {
  id: string;
  buyer_id: string;
  seller_id: string;
  product_id: string | null;
  product_name: string | null;
  product_image: string | null;
  product_price: number | null;
  last_message: string | null;
  last_message_at: string;
  buyer_unread_count: number;
  seller_unread_count: number;
  status: 'active' | 'archived' | 'blocked';
  created_at: string;
  updated_at: string;
  other_user_presence?: UserPresence;
  // UI helpers
  other_user_name?: string;
  other_user_avatar?: string;
}

export interface UserPresence {
  user_id: string;
  is_online: boolean;
  last_seen: string;
}

// Demo data
const demoConversations: Conversation[] = [
  {
    id: 'demo-conv-1',
    buyer_id: 'demo-buyer',
    seller_id: 'demo-seller-1',
    product_id: 'prod-1',
    product_name: 'iPhone 15 Pro Max',
    product_image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=100&h=100&fit=crop',
    product_price: 450000,
    last_message: 'Bonjour, est-ce que le produit est toujours disponible ?',
    last_message_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    buyer_unread_count: 0,
    seller_unread_count: 1,
    status: 'active',
    created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    other_user_name: 'Tech World',
    other_user_avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
  }
];

const demoMessages: Message[] = [
  {
    id: 'msg-1',
    conversation_id: 'demo-conv-1',
    sender_id: 'demo-buyer',
    sender_type: 'buyer',
    message_type: 'text',
    content: 'Bonjour, est-ce que le produit est toujours disponible ?',
    image_url: null,
    offered_price: null,
    original_price: null,
    price_status: null,
    is_read: true,
    created_at: new Date(Date.now() - 30 * 60 * 1000).toISOString()
  },
  {
    id: 'msg-2',
    conversation_id: 'demo-conv-1',
    sender_id: 'demo-seller-1',
    sender_type: 'seller',
    message_type: 'text',
    content: 'Oui, il est disponible ! Voulez-vous plus d\'informations ?',
    image_url: null,
    offered_price: null,
    original_price: null,
    price_status: null,
    is_read: true,
    created_at: new Date(Date.now() - 25 * 60 * 1000).toISOString()
  }
];

export function useMessaging() {
  const { user, profile } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const presenceRef = useRef<NodeJS.Timeout | null>(null);

  // Update user presence
  const updatePresence = useCallback(async (isOnline: boolean) => {
    if (!user?.id || isDemoMode) return;
    
    try {
      await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'update_presence',
          user_id: user.id,
          is_online: isOnline
        }
      });
    } catch (err) {
      console.error('Failed to update presence:', err);
    }
  }, [user?.id]);

  // Set up presence tracking
  useEffect(() => {
    if (!user?.id || isDemoMode) return;

    // Set online when component mounts
    updatePresence(true);

    // Update presence every 30 seconds
    presenceRef.current = setInterval(() => {
      updatePresence(true);
    }, 30000);

    // Set offline when page unloads
    const handleUnload = () => {
      updatePresence(false);
    };

    window.addEventListener('beforeunload', handleUnload);

    return () => {
      if (presenceRef.current) {
        clearInterval(presenceRef.current);
      }
      window.removeEventListener('beforeunload', handleUnload);
      updatePresence(false);
    };
  }, [user?.id, updatePresence]);

  // Get unread count
  const fetchUnreadCount = useCallback(async () => {
    if (!user?.id) return;

    // In demo mode, return 0
    if (isDemoMode) {
      setUnreadCount(0);
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'get_unread_count',
          user_id: user.id
        }
      });

      if (error) throw error;
      if (data?.success) {
        setUnreadCount(data.unread_count);
      }
    } catch (err) {
      console.error('Failed to fetch unread count:', err);
    }
  }, [user?.id]);

  // Fetch conversations
  const fetchConversations = useCallback(async () => {
    if (!user?.id) return;

    setLoading(true);
    
    // In demo mode, return demo conversations
    if (isDemoMode) {
      setConversations(demoConversations);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'get_conversations',
          user_id: user.id
        }
      });

      if (error) throw error;
      if (data?.success) {
        // Add mock user names for now (in real app, fetch from profiles)
        const enrichedConversations = data.conversations.map((conv: Conversation) => ({
          ...conv,
          other_user_name: conv.buyer_id === user.id ? 'Vendeur' : 'Acheteur',
          other_user_avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${conv.buyer_id === user.id ? conv.seller_id : conv.buyer_id}`
        }));
        setConversations(enrichedConversations);
      }
    } catch (err: any) {
      setError(err.message);
      // Fallback to demo data
      setConversations(demoConversations);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  // Fetch messages for a conversation
  const fetchMessages = useCallback(async (conversationId: string) => {
    if (!user?.id) return;

    setLoading(true);
    
    // In demo mode, return demo messages
    if (isDemoMode) {
      setMessages(demoMessages.filter(m => m.conversation_id === conversationId));
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'get_messages',
          conversation_id: conversationId
        }
      });

      if (error) throw error;
      if (data?.success) {
        setMessages(data.messages);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  // Create or get conversation
  const createConversation = useCallback(async (
    sellerId: string,
    productId?: string,
    productName?: string,
    productImage?: string,
    productPrice?: number
  ): Promise<Conversation | null> => {
    if (!user?.id) return null;

    // In demo mode, create a mock conversation
    if (isDemoMode) {
      const newConv: Conversation = {
        id: `demo-conv-${Date.now()}`,
        buyer_id: user.id,
        seller_id: sellerId,
        product_id: productId || null,
        product_name: productName || null,
        product_image: productImage || null,
        product_price: productPrice || null,
        last_message: null,
        last_message_at: new Date().toISOString(),
        buyer_unread_count: 0,
        seller_unread_count: 0,
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        other_user_name: 'Vendeur',
        other_user_avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${sellerId}`
      };
      setConversations(prev => [newConv, ...prev]);
      return newConv;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'create_conversation',
          buyer_id: user.id,
          seller_id: sellerId,
          product_id: productId,
          product_name: productName,
          product_image: productImage,
          product_price: productPrice
        }
      });

      if (error) throw error;
      if (data?.success) {
        await fetchConversations();
        return data.conversation;
      }
      return null;
    } catch (err: any) {
      setError(err.message);
      return null;
    }
  }, [user?.id, fetchConversations]);

  // Upload image to storage
  const uploadImage = useCallback(async (
    conversationId: string,
    file: File
  ): Promise<string | null> => {
    if (!user?.id) return null;

    // In demo mode, return a placeholder URL
    if (isDemoMode) {
      return 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=300&fit=crop';
    }

    setUploading(true);
    try {
      // Convert file to base64
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const result = reader.result as string;
          // Remove data URL prefix to get pure base64
          const base64 = result.split(',')[1];
          resolve(base64);
        };
        reader.onerror = reject;
      });
      reader.readAsDataURL(file);
      
      const fileBase64 = await base64Promise;

      const { data, error } = await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'upload_image',
          conversation_id: conversationId,
          sender_id: user.id,
          file_name: file.name,
          file_type: file.type,
          file_base64: fileBase64
        }
      });

      if (error) throw error;
      if (data?.success) {
        return data.image_url;
      }
      return null;
    } catch (err: any) {
      setError(err.message);
      console.error('Image upload error:', err);
      return null;
    } finally {
      setUploading(false);
    }
  }, [user?.id]);

  // Send message
  const sendMessage = useCallback(async (
    conversationId: string,
    content: string,
    messageType: 'text' | 'image' | 'price_offer' = 'text',
    imageUrl?: string,
    offeredPrice?: number,
    originalPrice?: number
  ): Promise<Message | null> => {
    if (!user?.id) return null;

    const senderType = profile?.user_type === 'seller' ? 'seller' : 'buyer';

    // In demo mode, create a mock message
    if (isDemoMode) {
      const newMsg: Message = {
        id: `msg-${Date.now()}`,
        conversation_id: conversationId,
        sender_id: user.id,
        sender_type: senderType,
        message_type: messageType,
        content,
        image_url: imageUrl || null,
        offered_price: offeredPrice || null,
        original_price: originalPrice || null,
        price_status: messageType === 'price_offer' ? 'pending' : null,
        is_read: false,
        created_at: new Date().toISOString()
      };
      setMessages(prev => [...prev, newMsg]);
      return newMsg;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'send_message',
          conversation_id: conversationId,
          sender_id: user.id,
          sender_type: senderType,
          message_type: messageType,
          content,
          image_url: imageUrl,
          offered_price: offeredPrice,
          original_price: originalPrice
        }
      });

      if (error) throw error;
      if (data?.success) {
        setMessages(prev => [...prev, data.message]);
        await fetchConversations();
        return data.message;
      }
      return null;
    } catch (err: any) {
      setError(err.message);
      return null;
    }
  }, [user?.id, profile, fetchConversations]);

  // Send image message
  const sendImageMessage = useCallback(async (
    conversationId: string,
    file: File,
    caption?: string
  ): Promise<Message | null> => {
    // First upload the image
    const imageUrl = await uploadImage(conversationId, file);
    if (!imageUrl) return null;

    // Then send the message with the image URL
    return sendMessage(
      conversationId,
      caption || 'Image',
      'image',
      imageUrl
    );
  }, [uploadImage, sendMessage]);

  // Respond to price offer
  const respondToPrice = useCallback(async (
    messageId: string,
    response: 'accepted' | 'rejected' | 'countered',
    counterPrice?: number
  ): Promise<Message | null> => {
    // In demo mode, update local state
    if (isDemoMode) {
      setMessages(prev => prev.map(m => 
        m.id === messageId ? { ...m, price_status: response } : m
      ));
      return null;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'respond_to_price',
          message_id: messageId,
          response,
          counter_price: counterPrice
        }
      });

      if (error) throw error;
      if (data?.success) {
        // Update local messages
        setMessages(prev => prev.map(m => 
          m.id === messageId ? { ...m, price_status: response } : m
        ));
        setMessages(prev => [...prev, data.message]);
        return data.message;
      }
      return null;
    } catch (err: any) {
      setError(err.message);
      return null;
    }
  }, []);

  // Mark messages as read
  const markAsRead = useCallback(async (conversationId: string) => {
    if (!user?.id) return;

    // In demo mode, just update local state
    if (isDemoMode) {
      setConversations(prev => prev.map(c => 
        c.id === conversationId 
          ? { ...c, buyer_unread_count: 0, seller_unread_count: 0 }
          : c
      ));
      return;
    }

    const userType = profile?.user_type === 'seller' ? 'seller' : 'buyer';

    try {
      await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'mark_as_read',
          conversation_id: conversationId,
          user_id: user.id,
          user_type: userType
        }
      });

      await fetchUnreadCount();
      await fetchConversations();
    } catch (err) {
      console.error('Failed to mark as read:', err);
    }
  }, [user?.id, profile, fetchUnreadCount, fetchConversations]);

  // Archive conversation
  const archiveConversation = useCallback(async (conversationId: string) => {
    // In demo mode, update local state
    if (isDemoMode) {
      setConversations(prev => prev.filter(c => c.id !== conversationId));
      return;
    }

    try {
      const { error } = await supabase.functions.invoke('manage-messaging', {
        body: {
          action: 'archive_conversation',
          conversation_id: conversationId
        }
      });

      if (error) throw error;
      await fetchConversations();
    } catch (err: any) {
      setError(err.message);
    }
  }, [fetchConversations]);

  // Open conversation
  const openConversation = useCallback(async (conversation: Conversation) => {
    setCurrentConversation(conversation);
    await fetchMessages(conversation.id);
    await markAsRead(conversation.id);
  }, [fetchMessages, markAsRead]);

  // Close conversation
  const closeConversation = useCallback(() => {
    setCurrentConversation(null);
    setMessages([]);
  }, []);

  // Start polling for new messages when conversation is open
  useEffect(() => {
    if (currentConversation && !isDemoMode) {
      pollingRef.current = setInterval(() => {
        fetchMessages(currentConversation.id);
      }, 3000);
    }

    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    };
  }, [currentConversation, fetchMessages]);

  // Initial fetch
  useEffect(() => {
    if (user?.id) {
      fetchConversations();
      fetchUnreadCount();

      // Poll for unread count (only in non-demo mode)
      if (!isDemoMode) {
        const interval = setInterval(fetchUnreadCount, 10000);
        return () => clearInterval(interval);
      }
    }
  }, [user?.id, fetchConversations, fetchUnreadCount]);

  // Format last seen time
  const formatLastSeen = (lastSeen: string): string => {
    const date = new Date(lastSeen);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;
    return date.toLocaleDateString('fr-FR');
  };

  // Format message time
  const formatMessageTime = (timestamp: string): string => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  };

  return {
    conversations,
    currentConversation,
    messages,
    unreadCount,
    loading,
    uploading,
    error,
    createConversation,
    openConversation,
    closeConversation,
    sendMessage,
    sendImageMessage,
    uploadImage,
    respondToPrice,
    markAsRead,
    archiveConversation,
    fetchConversations,
    fetchMessages,
    formatLastSeen,
    formatMessageTime,
    updatePresence
  };
}
