import { useState, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

// Demo mode flag
const isDemoMode = !isSupabaseConfigured;

export interface DeliveryAddress {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  location: string;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  product_image?: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  variant_info?: any;
  created_at: string;
}

export interface ShippingInfo {
  id: string;
  order_id: string;
  carrier?: string;
  tracking_number?: string;
  tracking_url?: string;
  estimated_delivery?: string;
  actual_delivery?: string;
  shipping_notes?: string;
  created_at: string;
  updated_at: string;
}

export interface OrderStatusHistory {
  id: string;
  order_id: string;
  status: string;
  notes?: string;
  updated_by?: string;
  created_at: string;
}

export interface Order {
  id: string;
  order_number: string;
  buyer_id: string;
  seller_id: string;
  delivery_address_id?: string;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  subtotal: number;
  shipping_fee: number;
  total: number;
  payment_method?: string;
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  payment_reference?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  confirmed_at?: string;
  shipped_at?: string;
  delivered_at?: string;
  cancelled_at?: string;
  cancellation_reason?: string;
  order_items?: OrderItem[];
  shipping_info?: ShippingInfo[];
  delivery_addresses?: DeliveryAddress;
  order_status_history?: OrderStatusHistory[];
}

export interface OrderStats {
  total: number;
  pending: number;
  confirmed: number;
  shipped: number;
  delivered: number;
  cancelled: number;
  totalRevenue: number;
}

// Demo data
const demoOrders: Order[] = [
  {
    id: 'demo-order-1',
    order_number: 'ORD-12345678',
    buyer_id: 'demo-buyer',
    seller_id: 'demo-seller-1',
    status: 'delivered',
    subtotal: 45000,
    shipping_fee: 2500,
    total: 47500,
    payment_method: 'orange_money',
    payment_status: 'paid',
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    order_items: [
      {
        id: 'item-1',
        order_id: 'demo-order-1',
        product_id: 'prod-1',
        product_name: 'T-shirt Premium',
        product_image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=100&h=100&fit=crop',
        quantity: 2,
        unit_price: 15000,
        total_price: 30000,
        created_at: new Date().toISOString()
      }
    ]
  }
];

const demoAddresses: DeliveryAddress[] = [
  {
    id: 'addr-1',
    user_id: 'demo-user',
    name: 'Maison',
    phone: '+225 07 00 00 00 00',
    location: 'Cocody, Abidjan',
    is_default: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

export function useOrders() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAddresses = useCallback(async (userId: string): Promise<DeliveryAddress[]> => {
    if (isDemoMode) return demoAddresses;
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'get_addresses', userId }
      });
      if (fnError) throw fnError;
      return data?.addresses || [];
    } catch (err: any) {
      setError(err.message);
      return demoAddresses;
    } finally {
      setLoading(false);
    }
  }, []);

  const addAddress = useCallback(async (userId: string, address: Partial<DeliveryAddress>): Promise<DeliveryAddress | null> => {
    if (isDemoMode) {
      const newAddr: DeliveryAddress = { ...address, id: `addr-${Date.now()}`, user_id: userId, created_at: new Date().toISOString(), updated_at: new Date().toISOString() } as DeliveryAddress;
      return newAddr;
    }
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'add_address', userId, address }
      });
      if (fnError) throw fnError;
      return data?.address || null;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateAddress = useCallback(async (addressId: string, userId: string, address: Partial<DeliveryAddress>): Promise<DeliveryAddress | null> => {
    if (isDemoMode) return { ...demoAddresses[0], ...address } as DeliveryAddress;
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'update_address', addressId, userId, address }
      });
      if (fnError) throw fnError;
      return data?.address || null;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const deleteAddress = useCallback(async (addressId: string): Promise<boolean> => {
    if (isDemoMode) return true;
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'delete_address', addressId }
      });
      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const createOrder = useCallback(async (
    buyerId: string, sellerId: string, items: any[], deliveryAddressId: string,
    paymentMethod: string, notes?: string, shippingFee: number = 0
  ): Promise<Order | null> => {
    if (isDemoMode) {
      const subtotal = items.reduce((sum, item) => sum + item.unit_price * item.quantity, 0);
      return {
        id: `demo-order-${Date.now()}`,
        order_number: `ORD-${Date.now().toString().slice(-8)}`,
        buyer_id: buyerId,
        seller_id: sellerId,
        status: 'pending',
        subtotal,
        shipping_fee: shippingFee,
        total: subtotal + shippingFee,
        payment_method: paymentMethod,
        payment_status: 'pending',
        notes,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    }
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'create_order', buyerId, sellerId, items, deliveryAddressId, paymentMethod, notes, shippingFee }
      });
      if (fnError) throw fnError;
      return data?.order || null;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateOrderStatus = useCallback(async (orderId: string, status: Order['status'], notes: string, updatedBy: string): Promise<Order | null> => {
    if (isDemoMode) return { ...demoOrders[0], status };
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'update_order_status', orderId, status, notes, updatedBy }
      });
      if (fnError) throw fnError;
      return data?.order || null;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const updatePaymentStatus = useCallback(async (orderId: string, paymentStatus: Order['payment_status'], paymentReference?: string): Promise<Order | null> => {
    if (isDemoMode) return { ...demoOrders[0], payment_status: paymentStatus };
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'update_payment_status', orderId, paymentStatus, paymentReference }
      });
      if (fnError) throw fnError;
      return data?.order || null;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const addShippingInfo = useCallback(async (orderId: string, carrier?: string, trackingNumber?: string, trackingUrl?: string, estimatedDelivery?: string, shippingNotes?: string): Promise<ShippingInfo | null> => {
    if (isDemoMode) return { id: `ship-${Date.now()}`, order_id: orderId, carrier, tracking_number: trackingNumber, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'add_shipping_info', orderId, carrier, trackingNumber, trackingUrl, estimatedDelivery, shippingNotes }
      });
      if (fnError) throw fnError;
      return data?.shippingInfo || null;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const getBuyerOrders = useCallback(async (buyerId: string, status?: string, page: number = 1, limit: number = 10): Promise<{ orders: Order[]; total: number; totalPages: number }> => {
    if (isDemoMode) return { orders: demoOrders, total: 1, totalPages: 1 };
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'get_buyer_orders', buyerId, status, page, limit }
      });
      if (fnError) throw fnError;
      return { orders: data?.orders || [], total: data?.total || 0, totalPages: data?.totalPages || 0 };
    } catch (err: any) {
      setError(err.message);
      return { orders: demoOrders, total: 1, totalPages: 1 };
    } finally {
      setLoading(false);
    }
  }, []);

  const getSellerOrders = useCallback(async (sellerId: string, status?: string, page: number = 1, limit: number = 10): Promise<{ orders: Order[]; total: number; totalPages: number }> => {
    if (isDemoMode) return { orders: demoOrders, total: 1, totalPages: 1 };
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'get_seller_orders', sellerId, status, page, limit }
      });
      if (fnError) throw fnError;
      return { orders: data?.orders || [], total: data?.total || 0, totalPages: data?.totalPages || 0 };
    } catch (err: any) {
      setError(err.message);
      return { orders: demoOrders, total: 1, totalPages: 1 };
    } finally {
      setLoading(false);
    }
  }, []);

  const getOrderDetails = useCallback(async (orderId: string): Promise<Order | null> => {
    if (isDemoMode) return demoOrders[0];
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'get_order_details', orderId }
      });
      if (fnError) throw fnError;
      return data?.order || null;
    } catch (err: any) {
      setError(err.message);
      return demoOrders[0];
    } finally {
      setLoading(false);
    }
  }, []);

  const getOrderStats = useCallback(async (sellerId: string): Promise<OrderStats | null> => {
    if (isDemoMode) return { total: 15, pending: 3, confirmed: 2, shipped: 4, delivered: 5, cancelled: 1, totalRevenue: 450000 };
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-orders', {
        body: { action: 'get_order_stats', sellerId }
      });
      if (fnError) throw fnError;
      return data?.stats || null;
    } catch (err: any) {
      setError(err.message);
      return { total: 15, pending: 3, confirmed: 2, shipped: 4, delivered: 5, cancelled: 1, totalRevenue: 450000 };
    } finally {
      setLoading(false);
    }
  }, []);

  const getStatusLabel = (status: Order['status']): string => {
    const labels: Record<Order['status'], string> = { pending: 'En attente', confirmed: 'Confirmée', shipped: 'Expédiée', delivered: 'Livrée', cancelled: 'Annulée' };
    return labels[status] || status;
  };

  const getStatusColor = (status: Order['status']): string => {
    const colors: Record<Order['status'], string> = { pending: 'bg-yellow-100 text-yellow-800', confirmed: 'bg-blue-100 text-blue-800', shipped: 'bg-purple-100 text-purple-800', delivered: 'bg-green-100 text-green-800', cancelled: 'bg-red-100 text-red-800' };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getPaymentStatusLabel = (status: Order['payment_status']): string => {
    const labels: Record<Order['payment_status'], string> = { pending: 'En attente', paid: 'Payé', failed: 'Échoué', refunded: 'Remboursé' };
    return labels[status] || status;
  };

  const getPaymentStatusColor = (status: Order['payment_status']): string => {
    const colors: Record<Order['payment_status'], string> = { pending: 'bg-yellow-100 text-yellow-800', paid: 'bg-green-100 text-green-800', failed: 'bg-red-100 text-red-800', refunded: 'bg-gray-100 text-gray-800' };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  return {
    loading, error,
    getAddresses, addAddress, updateAddress, deleteAddress,
    createOrder, updateOrderStatus, updatePaymentStatus, addShippingInfo,
    getBuyerOrders, getSellerOrders, getOrderDetails, getOrderStats,
    getStatusLabel, getStatusColor, getPaymentStatusLabel, getPaymentStatusColor
  };
}
