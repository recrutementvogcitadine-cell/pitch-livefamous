import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

export interface FlashSale {
  id: string;
  stream_id: string;
  product_id: string;
  product_name: string;
  product_image?: string;
  original_price: number;
  flash_price: number;
  discount_percent: number;
  duration_minutes: number;
  started_at: string;
  ends_at: string;
  is_active: boolean;
  units_sold: number;
  max_units?: number;
  seller_id: string;
  created_at: string;
}

interface CreateFlashSaleParams {
  stream_id: string;
  product_id: string;
  product_name: string;
  product_image?: string;
  original_price: number;
  discount_percent: number;
  duration_minutes: number;
  max_units?: number;
  seller_id: string;
}

export function useFlashSales(streamId?: string) {
  const [activeFlashSales, setActiveFlashSales] = useState<FlashSale[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const refreshIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const createFlashSale = useCallback(async (params: CreateFlashSaleParams): Promise<FlashSale | null> => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-flash-sales', {
        body: {
          action: 'create',
          ...params
        }
      });

      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);

      const flashSale = data.data as FlashSale;
      setActiveFlashSales(prev => [flashSale, ...prev]);

      toast({
        title: "🔥 Vente Flash activée!",
        description: `${params.discount_percent}% de réduction pendant ${params.duration_minutes} minutes`
      });

      return flashSale;
    } catch (err: any) {
      console.error('Error creating flash sale:', err);
      setError(err.message);
      toast({
        title: "Erreur",
        description: "Impossible de créer la vente flash",
        variant: "destructive"
      });
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchActiveFlashSales = useCallback(async (targetStreamId?: string) => {
    const sid = targetStreamId || streamId;
    if (!sid) return;

    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-flash-sales', {
        body: {
          action: 'get_active',
          stream_id: sid
        }
      });

      if (fnError) {
        // Silently fail - don't spam console
        return;
      }
      if (!data?.success) {
        // Silently fail - don't spam console
        return;
      }

      setActiveFlashSales(data.data || []);
    } catch (err: any) {
      // Silently fail to avoid console spam
    }
  }, [streamId]);


  const endFlashSale = useCallback(async (flashSaleId: string, sellerId: string): Promise<boolean> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-flash-sales', {
        body: {
          action: 'end',
          flash_sale_id: flashSaleId,
          seller_id: sellerId
        }
      });

      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);

      setActiveFlashSales(prev => prev.filter(fs => fs.id !== flashSaleId));

      toast({
        title: "Vente Flash terminée",
        description: "La promotion a été désactivée"
      });

      return true;
    } catch (err: any) {
      console.error('Error ending flash sale:', err);
      toast({
        title: "Erreur",
        description: "Impossible de terminer la vente flash",
        variant: "destructive"
      });
      return false;
    }
  }, []);

  const recordPurchase = useCallback(async (flashSaleId: string): Promise<FlashSale | null> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-flash-sales', {
        body: {
          action: 'purchase',
          flash_sale_id: flashSaleId
        }
      });

      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);

      // Update local state
      setActiveFlashSales(prev => 
        prev.map(fs => fs.id === flashSaleId ? data.data : fs)
      );

      return data.data;
    } catch (err: any) {
      console.error('Error recording purchase:', err);
      throw err;
    }
  }, []);

  const getFlashSaleHistory = useCallback(async (sellerId: string, limit = 50): Promise<FlashSale[]> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-flash-sales', {
        body: {
          action: 'history',
          seller_id: sellerId,
          limit
        }
      });

      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);

      return data.data || [];
    } catch (err: any) {
      console.error('Error fetching flash sale history:', err);
      return [];
    }
  }, []);

  // Auto-refresh active flash sales and remove expired ones
  useEffect(() => {
    if (!streamId) return;

    // Initial fetch
    fetchActiveFlashSales();

    // Set up polling for updates
    refreshIntervalRef.current = setInterval(() => {
      // Remove expired flash sales from local state
      setActiveFlashSales(prev => 
        prev.filter(fs => new Date(fs.ends_at) > new Date() && fs.is_active)
      );
      
      // Fetch fresh data
      fetchActiveFlashSales();
    }, 5000);

    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
    };
  }, [streamId, fetchActiveFlashSales]);

  // Subscribe to realtime updates
  useEffect(() => {
    if (!streamId) return;

    const channel = supabase
      .channel(`flash_sales_${streamId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'flash_sales',
          filter: `stream_id=eq.${streamId}`
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            const newSale = payload.new as FlashSale;
            setActiveFlashSales(prev => {
              if (prev.some(fs => fs.id === newSale.id)) return prev;
              return [newSale, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            const updatedSale = payload.new as FlashSale;
            if (!updatedSale.is_active || new Date(updatedSale.ends_at) <= new Date()) {
              setActiveFlashSales(prev => prev.filter(fs => fs.id !== updatedSale.id));
            } else {
              setActiveFlashSales(prev => 
                prev.map(fs => fs.id === updatedSale.id ? updatedSale : fs)
              );
            }
          } else if (payload.eventType === 'DELETE') {
            setActiveFlashSales(prev => prev.filter(fs => fs.id !== payload.old.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [streamId]);

  return {
    activeFlashSales,
    loading,
    error,
    createFlashSale,
    endFlashSale,
    recordPurchase,
    getFlashSaleHistory,
    fetchActiveFlashSales
  };
}
