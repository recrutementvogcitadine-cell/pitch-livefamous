import { useState, useEffect } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

// Demo mode flag
const isDemoMode = !isSupabaseConfigured;

// Types
export interface SubscriptionPlan {
  id: string;
  name: string;
  slug: string;
  price: number;
  period: string;
  features: string[];
  max_products: number;
  max_lives_per_month: number;
  is_popular: boolean;
  is_active: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  is_active: boolean;
}

export interface SellerProfile {
  id: string;
  user_id: string;
  store_name: string;
  store_description: string;
  store_logo: string;
  rating: number;
  total_reviews: number;
  total_sales: number;
  is_verified: boolean;
}

// Demo data for when Supabase is not configured
const demoPlans: SubscriptionPlan[] = [
  {
    id: '1',
    name: 'Starter',
    slug: 'starter',
    price: 0,
    period: 'month',
    features: ['5 produits', '2 lives/mois', 'Support email'],
    max_products: 5,
    max_lives_per_month: 2,
    is_popular: false,
    is_active: true
  },
  {
    id: '2',
    name: 'Pro',
    slug: 'pro',
    price: 9900,
    period: 'month',
    features: ['50 produits', '10 lives/mois', 'Support prioritaire', 'Analytics'],
    max_products: 50,
    max_lives_per_month: 10,
    is_popular: true,
    is_active: true
  },
  {
    id: '3',
    name: 'Business',
    slug: 'business',
    price: 29900,
    period: 'month',
    features: ['Produits illimités', 'Lives illimités', 'Support 24/7', 'API Access'],
    max_products: -1,
    max_lives_per_month: -1,
    is_popular: false,
    is_active: true
  }
];

const demoCategories: Category[] = [
  { id: '1', name: 'Mode', slug: 'mode', icon: 'Shirt', is_active: true },
  { id: '2', name: 'Électronique', slug: 'electronique', icon: 'Smartphone', is_active: true },
  { id: '3', name: 'Maison', slug: 'maison', icon: 'Home', is_active: true },
  { id: '4', name: 'Beauté', slug: 'beaute', icon: 'Sparkles', is_active: true },
  { id: '5', name: 'Sport', slug: 'sport', icon: 'Dumbbell', is_active: true },
  { id: '6', name: 'Alimentation', slug: 'alimentation', icon: 'UtensilsCrossed', is_active: true }
];

const demoSellers: SellerProfile[] = [
  {
    id: '1',
    user_id: 'demo1',
    store_name: 'Fashion Store',
    store_description: 'Les dernières tendances mode',
    store_logo: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=100&h=100&fit=crop',
    rating: 4.8,
    total_reviews: 156,
    total_sales: 1250,
    is_verified: true
  },
  {
    id: '2',
    user_id: 'demo2',
    store_name: 'Tech World',
    store_description: 'Gadgets et électronique',
    store_logo: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=100&h=100&fit=crop',
    rating: 4.6,
    total_reviews: 89,
    total_sales: 780,
    is_verified: true
  },
  {
    id: '3',
    user_id: 'demo3',
    store_name: 'Beauty Corner',
    store_description: 'Cosmétiques et soins',
    store_logo: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=100&h=100&fit=crop',
    rating: 4.9,
    total_reviews: 234,
    total_sales: 2100,
    is_verified: true
  }
];

// Hook for fetching subscription plans
export const useSubscriptionPlans = () => {
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPlans = async () => {
      // Use demo data in demo mode
      if (isDemoMode) {
        setPlans(demoPlans);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('subscription_plans')
          .select('*')
          .eq('is_active', true)
          .order('price', { ascending: true });

        if (error) throw error;
        setPlans(data || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error fetching plans');
        // Fallback to demo data on error
        setPlans(demoPlans);
      } finally {
        setLoading(false);
      }
    };

    fetchPlans();
  }, []);

  return { plans, loading, error };
};

// Hook for fetching categories
export const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCategories = async () => {
      // Use demo data in demo mode
      if (isDemoMode) {
        setCategories(demoCategories);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('categories')
          .select('*')
          .eq('is_active', true);

        if (error) throw error;
        setCategories(data || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error fetching categories');
        // Fallback to demo data on error
        setCategories(demoCategories);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  return { categories, loading, error };
};

// Hook for fetching seller profiles
export const useSellerProfiles = () => {
  const [sellers, setSellers] = useState<SellerProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSellers = async () => {
      // Use demo data in demo mode
      if (isDemoMode) {
        setSellers(demoSellers);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('seller_profiles')
          .select('*')
          .order('rating', { ascending: false })
          .limit(10);

        if (error) throw error;
        setSellers(data || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error fetching sellers');
        // Fallback to demo data on error
        setSellers(demoSellers);
      } finally {
        setLoading(false);
      }
    };

    fetchSellers();
  }, []);

  return { sellers, loading, error };
};

// Function to create an order
export const createOrder = async (orderData: {
  userId?: string;
  sellerId?: string;
  items: Array<{ productId?: string; liveProductId?: string; name: string; price: number; quantity: number }>;
  subtotal: number;
  shippingFee: number;
  total: number;
  paymentMethod: string;
  shippingAddress: {
    fullName: string;
    phone: string;
    address: string;
    city: string;
    commune: string;
  };
}) => {
  const orderNumber = `ORD-${Date.now().toString().slice(-8)}`;

  // In demo mode, return a mock order
  if (isDemoMode) {
    const mockOrder = {
      id: `demo_${Date.now()}`,
      order_number: orderNumber,
      user_id: orderData.userId,
      seller_id: orderData.sellerId,
      subtotal: orderData.subtotal,
      shipping_fee: orderData.shippingFee,
      total: orderData.total,
      payment_method: orderData.paymentMethod,
      shipping_address: orderData.shippingAddress,
      status: 'pending',
      payment_status: 'pending',
      created_at: new Date().toISOString()
    };
    
    // Store in localStorage for demo purposes
    try {
      const existingOrders = JSON.parse(localStorage.getItem('demo_orders') || '[]');
      existingOrders.push(mockOrder);
      localStorage.setItem('demo_orders', JSON.stringify(existingOrders));
    } catch (e) {
      console.warn('Error storing demo order:', e);
    }
    
    return mockOrder;
  }

  const { data: order, error: orderError } = await supabase
    .from('orders')
    .insert({
      order_number: orderNumber,
      user_id: orderData.userId,
      seller_id: orderData.sellerId,
      subtotal: orderData.subtotal,
      shipping_fee: orderData.shippingFee,
      total: orderData.total,
      payment_method: orderData.paymentMethod,
      shipping_address: orderData.shippingAddress,
      status: 'pending',
      payment_status: orderData.paymentMethod === 'cod' ? 'pending' : 'pending'
    })
    .select()
    .single();

  if (orderError) throw orderError;

  // Insert order items
  const orderItems = orderData.items.map(item => ({
    order_id: order.id,
    product_id: item.productId,
    live_product_id: item.liveProductId,
    name: item.name,
    price: item.price,
    quantity: item.quantity
  }));

  const { error: itemsError } = await supabase
    .from('order_items')
    .insert(orderItems);

  if (itemsError) throw itemsError;

  return order;
};
