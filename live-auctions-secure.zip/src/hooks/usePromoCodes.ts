import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export interface PromoCode {
  id: string;
  seller_id: string;
  code: string;
  description: string | null;
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  min_order_amount: number;
  max_discount_amount: number | null;
  usage_limit: number | null;
  usage_count: number;
  start_date: string;
  end_date: string | null;
  is_active: boolean;
  applies_to: 'all' | 'specific_products' | 'specific_categories';
  product_ids: string[];
  created_at: string;
  updated_at: string;
}

export interface PromoValidationResult {
  valid: boolean;
  error?: string;
  promo?: {
    id: string;
    code: string;
    description: string | null;
    discount_type: 'percentage' | 'fixed';
    discount_value: number;
  };
  discount?: number;
  final_amount?: number;
}

export interface PromoCodeStats {
  total_uses: number;
  total_discount: number;
  usage_history: Array<{
    id: string;
    order_id: string;
    user_email: string;
    discount_applied: number;
    used_at: string;
  }>;
}

export function usePromoCodes() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([]);

  const createPromoCode = useCallback(async (data: {
    seller_id: string;
    code: string;
    description?: string;
    discount_type: 'percentage' | 'fixed';
    discount_value: number;
    min_order_amount?: number;
    max_discount_amount?: number;
    usage_limit?: number;
    start_date?: string;
    end_date?: string;
    applies_to?: 'all' | 'specific_products' | 'specific_categories';
    product_ids?: string[];
  }) => {
    setLoading(true);
    setError(null);
    try {
      const { data: result, error: fnError } = await supabase.functions.invoke('manage-promo-codes', {
        body: { action: 'create', ...data }
      });

      if (fnError) throw fnError;
      if (result.error) throw new Error(result.error);

      setPromoCodes(prev => [result.promo, ...prev]);
      return result.promo as PromoCode;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updatePromoCode = useCallback(async (id: string, updates: Partial<PromoCode>) => {
    setLoading(true);
    setError(null);
    try {
      const { data: result, error: fnError } = await supabase.functions.invoke('manage-promo-codes', {
        body: { action: 'update', id, ...updates }
      });

      if (fnError) throw fnError;
      if (result.error) throw new Error(result.error);

      setPromoCodes(prev => prev.map(p => p.id === id ? result.promo : p));
      return result.promo as PromoCode;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const deletePromoCode = useCallback(async (id: string) => {
    setLoading(true);
    setError(null);
    try {
      const { data: result, error: fnError } = await supabase.functions.invoke('manage-promo-codes', {
        body: { action: 'delete', id }
      });

      if (fnError) throw fnError;
      if (result.error) throw new Error(result.error);

      setPromoCodes(prev => prev.filter(p => p.id !== id));
      return true;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const listPromoCodes = useCallback(async (seller_id: string) => {
    setLoading(true);
    setError(null);
    try {
      const { data: result, error: fnError } = await supabase.functions.invoke('manage-promo-codes', {
        body: { action: 'list', seller_id }
      });

      if (fnError) throw fnError;
      if (result.error) throw new Error(result.error);

      setPromoCodes(result.promos || []);
      return result.promos as PromoCode[];
    } catch (err: any) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const validatePromoCode = useCallback(async (data: {
    code: string;
    seller_id: string;
    order_amount: number;
    product_id?: string;
    user_email?: string;
  }): Promise<PromoValidationResult> => {
    setLoading(true);
    setError(null);
    try {
      const { data: result, error: fnError } = await supabase.functions.invoke('manage-promo-codes', {
        body: { action: 'validate', ...data }
      });

      if (fnError) throw fnError;

      return result as PromoValidationResult;
    } catch (err: any) {
      setError(err.message);
      return { valid: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  const applyPromoCode = useCallback(async (data: {
    promo_code_id: string;
    order_id: string;
    user_id?: string;
    user_email: string;
    discount_applied: number;
  }) => {
    setLoading(true);
    setError(null);
    try {
      const { data: result, error: fnError } = await supabase.functions.invoke('manage-promo-codes', {
        body: { action: 'apply', ...data }
      });

      if (fnError) throw fnError;
      if (result.error) throw new Error(result.error);

      return true;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const getPromoCodeStats = useCallback(async (promo_code_id: string): Promise<PromoCodeStats | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data: result, error: fnError } = await supabase.functions.invoke('manage-promo-codes', {
        body: { action: 'get_stats', promo_code_id }
      });

      if (fnError) throw fnError;
      if (result.error) throw new Error(result.error);

      return result.stats as PromoCodeStats;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const togglePromoCodeStatus = useCallback(async (id: string, is_active: boolean) => {
    return updatePromoCode(id, { is_active });
  }, [updatePromoCode]);

  return {
    loading,
    error,
    promoCodes,
    createPromoCode,
    updatePromoCode,
    deletePromoCode,
    listPromoCodes,
    validatePromoCode,
    applyPromoCode,
    getPromoCodeStats,
    togglePromoCodeStatus
  };
}
