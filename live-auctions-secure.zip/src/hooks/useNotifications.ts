import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export interface NotificationPreferences {
  user_id: string;
  email_notifications: boolean;
  push_notifications: boolean;
  in_app_notifications: boolean;
  live_start_notifications: boolean;
  replay_notifications: boolean;
  order_notifications: boolean;
  order_confirmed_notifications: boolean;
  order_shipped_notifications: boolean;
  order_delivered_notifications: boolean;
  order_cancelled_notifications: boolean;
  promo_notifications: boolean;
  message_notifications: boolean;
  product_sale_notifications: boolean;
  new_follower_notifications: boolean;
  review_notifications: boolean;
  price_drop_notifications: boolean;
  stock_alert_notifications: boolean;
  weekly_digest: boolean;
  marketing_emails: boolean;
  sound_enabled: boolean;
  // Seller-specific notification preferences
  seller_new_order_notifications: boolean;
  seller_new_order_push: boolean;
  seller_new_order_email: boolean;
  seller_new_order_in_app: boolean;
  seller_order_cancelled_notifications: boolean;
  seller_order_cancelled_push: boolean;
  seller_order_cancelled_email: boolean;
  seller_order_cancelled_in_app: boolean;
  seller_buyer_message_notifications: boolean;
  seller_buyer_message_push: boolean;
  seller_buyer_message_email: boolean;
  seller_buyer_message_in_app: boolean;
  seller_low_stock_notifications: boolean;
  seller_low_stock_push: boolean;
  seller_low_stock_email: boolean;
  seller_low_stock_in_app: boolean;
  seller_review_notifications: boolean;
  seller_review_push: boolean;
  seller_review_email: boolean;
  seller_review_in_app: boolean;
  seller_new_follower_notifications: boolean;
  seller_new_follower_push: boolean;
  seller_new_follower_email: boolean;
  seller_new_follower_in_app: boolean;
}

export interface Notification {
  id: string;
  user_id: string;
  type: 'live_start' | 'replay_available' | 'order_update' | 'promo' | 'message' | 'system' | 'price_drop' | 'review' | 'product_sale' | 'seller_new_order' | 'seller_order_cancelled' | 'seller_buyer_message' | 'seller_low_stock' | 'seller_new_review' | 'seller_new_follower';
  title: string;
  message: string;
  image_url?: string;
  action_url?: string;
  action_data?: Record<string, any>;
  is_read: boolean;
  category?: string;
  priority?: 'low' | 'normal' | 'high';
  sender_id?: string;
  sender_name?: string;
  sender_avatar?: string;
  expires_at?: string;
  created_at: string;
}

export interface FollowedSeller {
  id: string;
  follower_id: string;
  seller_id: string;
  notifications_enabled: boolean;
  created_at: string;
}

export interface NotificationStats {
  total_sent: number;
  total_unread: number;
  sent_last_24h: number;
  by_type: Record<string, number>;
}

export function useNotifications() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [countsByType, setCountsByType] = useState<Record<string, number>>({});
  const [preferences, setPreferences] = useState<NotificationPreferences | null>(null);
  const [following, setFollowing] = useState<FollowedSeller[]>([]);

  // ============ FOLLOWER MANAGEMENT ============
  const followSeller = useCallback(async (followerId: string, sellerId: string) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'follow_seller', follower_id: followerId, seller_id: sellerId }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const unfollowSeller = useCallback(async (followerId: string, sellerId: string) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'unfollow_seller', follower_id: followerId, seller_id: sellerId }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const toggleSellerNotifications = useCallback(async (followerId: string, sellerId: string, enabled: boolean) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'toggle_seller_notifications', follower_id: followerId, seller_id: sellerId, enabled }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchFollowing = useCallback(async (userId: string) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'get_following', user_id: userId }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      setFollowing(data.data || []);
      return data.data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchFollowers = useCallback(async (sellerId: string) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'get_followers', seller_id: sellerId }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const checkFollowing = useCallback(async (followerId: string, sellerId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'check_following', follower_id: followerId, seller_id: sellerId }
      });
      if (error) {
        console.error('Error checking follow status:', error);
        return { is_following: false, notifications_enabled: true };
      }
      if (data.error) {
        console.error('Error checking follow status:', data.error);
        return { is_following: false, notifications_enabled: true };
      }
      return data;
    } catch (err: any) {
      console.error('Error checking follow status:', err);
      return { is_following: false, notifications_enabled: true };
    }
  }, []);


  // ============ NOTIFICATION PREFERENCES ============
  const fetchPreferences = useCallback(async (userId: string) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'get_preferences', user_id: userId }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      setPreferences(data.data);
      return data.data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updatePreferences = useCallback(async (userId: string, newPreferences: Partial<NotificationPreferences>) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'update_preferences', user_id: userId, preferences: newPreferences }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      setPreferences(data.data);
      return data.data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // ============ NOTIFICATIONS ============
  const notifyFollowers = useCallback(async (
    sellerId: string,
    sellerName: string,
    type: 'live_start' | 'replay_available' | 'product_sale',
    title: string,
    message: string,
    imageUrl?: string,
    actionUrl?: string,
    actionData?: Record<string, any>,
    sellerAvatar?: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_followers',
          seller_id: sellerId,
          seller_name: sellerName,
          type,
          title,
          message,
          image_url: imageUrl,
          action_url: actionUrl,
          action_data: actionData,
          seller_avatar: sellerAvatar
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const sendNotification = useCallback(async (
    userId: string,
    type: Notification['type'],
    title: string,
    message: string,
    options?: {
      imageUrl?: string;
      actionUrl?: string;
      actionData?: Record<string, any>;
      category?: string;
      priority?: 'low' | 'normal' | 'high';
      senderId?: string;
      senderName?: string;
      senderAvatar?: string;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'send_notification',
          user_id: userId,
          type,
          title,
          message,
          image_url: options?.imageUrl,
          action_url: options?.actionUrl,
          action_data: options?.actionData,
          category: options?.category,
          priority: options?.priority,
          sender_id: options?.senderId,
          sender_name: options?.senderName,
          sender_avatar: options?.senderAvatar
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const broadcastNotification = useCallback(async (
    type: Notification['type'],
    title: string,
    message: string,
    options?: {
      imageUrl?: string;
      actionUrl?: string;
      actionData?: Record<string, any>;
      category?: string;
      priority?: 'low' | 'normal' | 'high';
      filterPromoEnabled?: boolean;
      expiresAt?: string;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'broadcast_notification',
          type,
          title,
          message,
          image_url: options?.imageUrl,
          action_url: options?.actionUrl,
          action_data: options?.actionData,
          category: options?.category,
          priority: options?.priority,
          filter_promo_enabled: options?.filterPromoEnabled,
          expires_at: options?.expiresAt
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const notifyPromoCode = useCallback(async (
    promoCode: string,
    discountType: 'percentage' | 'fixed',
    discountValue: number,
    minPurchase?: number,
    expiresAt?: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_promo_code',
          promo_code: promoCode,
          discount_type: discountType,
          discount_value: discountValue,
          min_purchase: minPurchase,
          expires_at: expiresAt
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const notifyOrderUpdate = useCallback(async (
    userId: string,
    orderId: string,
    status: 'confirmed' | 'shipped' | 'delivered' | 'cancelled',
    options?: {
      orderTotal?: number;
      sellerName?: string;
      sellerId?: string;
      sellerAvatar?: string;
      orderNumber?: string;
      productName?: string;
      productImage?: string;
      trackingNumber?: string;
      estimatedDelivery?: string;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_order_update',
          user_id: userId,
          order_id: orderId,
          status,
          order_total: options?.orderTotal,
          seller_name: options?.sellerName,
          seller_id: options?.sellerId,
          seller_avatar: options?.sellerAvatar,
          order_number: options?.orderNumber,
          product_name: options?.productName,
          product_image: options?.productImage,
          tracking_number: options?.trackingNumber,
          estimated_delivery: options?.estimatedDelivery
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);


  const notifyNewMessage = useCallback(async (
    userId: string,
    senderId: string,
    senderName: string,
    messagePreview: string,
    conversationId: string,
    senderAvatar?: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_new_message',
          user_id: userId,
          sender_id: senderId,
          sender_name: senderName,
          sender_avatar: senderAvatar,
          message_preview: messagePreview,
          conversation_id: conversationId
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  // ============ SELLER NOTIFICATIONS ============
  const notifySellerNewOrder = useCallback(async (
    sellerId: string,
    options: {
      buyerId?: string;
      buyerName?: string;
      buyerAvatar?: string;
      orderId: string;
      orderNumber?: string;
      orderTotal?: number;
      productName?: string;
      productImage?: string;
      productQuantity?: number;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_seller_new_order',
          seller_id: sellerId,
          buyer_id: options.buyerId,
          buyer_name: options.buyerName,
          buyer_avatar: options.buyerAvatar,
          order_id: options.orderId,
          order_number: options.orderNumber,
          order_total: options.orderTotal,
          product_name: options.productName,
          product_image: options.productImage,
          product_quantity: options.productQuantity
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const notifySellerOrderCancelled = useCallback(async (
    sellerId: string,
    options: {
      buyerId?: string;
      buyerName?: string;
      buyerAvatar?: string;
      orderId: string;
      orderNumber?: string;
      orderTotal?: number;
      productName?: string;
      cancellationReason?: string;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_seller_order_cancelled',
          seller_id: sellerId,
          buyer_id: options.buyerId,
          buyer_name: options.buyerName,
          buyer_avatar: options.buyerAvatar,
          order_id: options.orderId,
          order_number: options.orderNumber,
          order_total: options.orderTotal,
          product_name: options.productName,
          cancellation_reason: options.cancellationReason
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const notifySellerBuyerMessage = useCallback(async (
    sellerId: string,
    options: {
      buyerId: string;
      buyerName: string;
      buyerAvatar?: string;
      messagePreview: string;
      conversationId: string;
      productId?: string;
      productName?: string;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_seller_buyer_message',
          seller_id: sellerId,
          buyer_id: options.buyerId,
          buyer_name: options.buyerName,
          buyer_avatar: options.buyerAvatar,
          message_preview: options.messagePreview,
          conversation_id: options.conversationId,
          product_id: options.productId,
          product_name: options.productName
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const notifySellerLowStock = useCallback(async (
    sellerId: string,
    options: {
      productId: string;
      productName: string;
      productImage?: string;
      currentStock: number;
      threshold?: number;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_seller_low_stock',
          seller_id: sellerId,
          product_id: options.productId,
          product_name: options.productName,
          product_image: options.productImage,
          current_stock: options.currentStock,
          threshold: options.threshold
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const notifySellerNewReview = useCallback(async (
    sellerId: string,
    options: {
      buyerId?: string;
      buyerName?: string;
      buyerAvatar?: string;
      productId: string;
      productName: string;
      productImage?: string;
      rating: number;
      reviewText?: string;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_seller_new_review',
          seller_id: sellerId,
          buyer_id: options.buyerId,
          buyer_name: options.buyerName,
          buyer_avatar: options.buyerAvatar,
          product_id: options.productId,
          product_name: options.productName,
          product_image: options.productImage,
          rating: options.rating,
          review_text: options.reviewText
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const notifySellerNewFollower = useCallback(async (
    sellerId: string,
    options: {
      followerId: string;
      followerName: string;
      followerAvatar?: string;
    }
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: {
          action: 'notify_seller_new_follower',
          seller_id: sellerId,
          follower_id: options.followerId,
          follower_name: options.followerName,
          follower_avatar: options.followerAvatar
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const fetchNotifications = useCallback(async (
    userId: string, 
    limit = 50, 
    offset = 0, 
    unreadOnly = false,
    typeFilter?: string,
    categoryFilter?: string
  ) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { 
          action: 'get_notifications', 
          user_id: userId, 
          limit, 
          offset, 
          unread_only: unreadOnly,
          type_filter: typeFilter,
          category_filter: categoryFilter
        }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      setNotifications(data.data || []);
      setUnreadCount(data.unread_count || 0);
      setCountsByType(data.counts_by_type || {});
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const markAsRead = useCallback(async (notificationId: string, userId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'mark_as_read', notification_id: notificationId, user_id: userId }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      setNotifications(prev => prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const markAllAsRead = useCallback(async (userId: string, typeFilter?: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'mark_all_as_read', user_id: userId, type_filter: typeFilter }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      if (typeFilter) {
        setNotifications(prev => prev.map(n => n.type === typeFilter ? { ...n, is_read: true } : n));
      } else {
        setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
        setUnreadCount(0);
      }
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const deleteNotification = useCallback(async (notificationId: string, userId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'delete_notification', notification_id: notificationId, user_id: userId }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      const notification = notifications.find(n => n.id === notificationId);
      setNotifications(prev => prev.filter(n => n.id !== notificationId));
      if (notification && !notification.is_read) {
        setUnreadCount(prev => Math.max(0, prev - 1));
      }
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, [notifications]);

  const clearAllNotifications = useCallback(async (userId: string, typeFilter?: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'clear_all_notifications', user_id: userId, type_filter: typeFilter }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      if (typeFilter) {
        setNotifications(prev => prev.filter(n => n.type !== typeFilter));
      } else {
        setNotifications([]);
        setUnreadCount(0);
      }
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  const getNotificationStats = useCallback(async (): Promise<NotificationStats | null> => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-notifications', {
        body: { action: 'get_notification_stats' }
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data.stats;
    } catch (err: any) {
      setError(err.message);
      return null;
    }
  }, []);

  return {
    loading,
    error,
    notifications,
    unreadCount,
    countsByType,
    preferences,
    following,
    // Follower management
    followSeller,
    unfollowSeller,
    toggleSellerNotifications,
    fetchFollowing,
    fetchFollowers,
    checkFollowing,
    // Preferences
    fetchPreferences,
    updatePreferences,
    // Notifications
    notifyFollowers,
    sendNotification,
    broadcastNotification,
    notifyPromoCode,
    notifyOrderUpdate,
    notifyNewMessage,
    // Seller notifications
    notifySellerNewOrder,
    notifySellerOrderCancelled,
    notifySellerBuyerMessage,
    notifySellerLowStock,
    notifySellerNewReview,
    notifySellerNewFollower,
    // Notification management
    fetchNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAllNotifications,
    getNotificationStats
  };
}
