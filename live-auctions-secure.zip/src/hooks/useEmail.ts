import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export interface OrderEmailData {
  order_id: string;
  order_number: string;
  order_date?: string;
  buyer_name: string;
  email?: string;
  seller_name: string;
  total: number;
  subtotal?: number;
  shipping_cost?: number;
  items?: Array<{
    name: string;
    quantity: number;
    price: number;
    image?: string;
  }>;
  shipping_address?: {
    name: string;
    address: string;
    city: string;
    postal_code: string;
    phone: string;
  };
  order_url?: string;
  tracking_number?: string;
  carrier?: string;
  estimated_delivery?: string;
  tracking_url?: string;
  review_url?: string;
  support_url?: string;
  cancellation_reason?: string;
  refund_info?: boolean;
  shop_url?: string;
}

export interface MessageEmailData {
  sender_name: string;
  sender_avatar?: string;
  message_preview: string;
  conversation_url?: string;
  product_name?: string;
  product_image?: string;
  email?: string;
}

export interface SellerOrderEmailData {
  order_number: string;
  buyer_name: string;
  total: number;
  items?: Array<{
    name: string;
    quantity: number;
    price: number;
    image?: string;
  }>;
  product_name?: string;
  product_image?: string;
  quantity?: number;
  shipping_address?: {
    name: string;
    address: string;
    city: string;
    postal_code: string;
    phone: string;
  };
  order_management_url?: string;
  seller_email?: string;
}

export interface ReviewEmailData {
  buyer_name: string;
  product_name: string;
  product_image?: string;
  rating: number;
  review_text?: string;
  review_url?: string;
  seller_email?: string;
}

export interface StockAlertEmailData {
  product_name: string;
  product_image?: string;
  current_stock: number;
  threshold?: number;
  product_url?: string;
  seller_email?: string;
}

export interface LiveReminderEmailData {
  seller_name: string;
  seller_avatar?: string;
  seller_description?: string;
  stream_title: string;
  scheduled_time: string;
  minutes_until?: number;
  stream_url?: string;
  email?: string;
}

export interface PromoEmailData {
  promo_code: string;
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  min_purchase?: number;
  expires_at?: string;
  shop_url?: string;
  email?: string;
}

export interface WelcomeEmailData {
  name: string;
  email: string;
  app_url?: string;
}

export interface EmailNotificationStatus {
  order_emails_enabled: boolean;
  message_emails_enabled: boolean;
  marketing_emails_enabled: boolean;
  seller_emails_enabled: boolean;
}

export function useEmail() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Send order confirmation email
  const sendOrderConfirmation = useCallback(async (userId: string, orderData: OrderEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_order_confirmation', user_id: userId, order_data: orderData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending order confirmation email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send shipping update email
  const sendShippingUpdate = useCallback(async (userId: string, shippingData: OrderEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_shipping_update', user_id: userId, shipping_data: shippingData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending shipping update email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send delivery confirmation email
  const sendDeliveryConfirmation = useCallback(async (userId: string, deliveryData: OrderEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_delivery_confirmation', user_id: userId, delivery_data: deliveryData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending delivery confirmation email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send order cancelled email
  const sendOrderCancelled = useCallback(async (userId: string, cancellationData: OrderEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_order_cancelled', user_id: userId, cancellation_data: cancellationData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending order cancelled email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send new message email
  const sendNewMessageEmail = useCallback(async (userId: string, messageData: MessageEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_new_message', user_id: userId, message_data: messageData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending new message email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send seller new order email
  const sendSellerNewOrderEmail = useCallback(async (sellerId: string, orderData: SellerOrderEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_seller_new_order', seller_id: sellerId, order_data: orderData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending seller new order email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send seller new review email
  const sendSellerNewReviewEmail = useCallback(async (sellerId: string, reviewData: ReviewEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_seller_new_review', seller_id: sellerId, review_data: reviewData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending seller new review email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send seller low stock email
  const sendSellerLowStockEmail = useCallback(async (sellerId: string, stockData: StockAlertEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_seller_low_stock', seller_id: sellerId, stock_data: stockData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending seller low stock email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send welcome email
  const sendWelcomeEmail = useCallback(async (userId: string, userData: WelcomeEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_welcome', user_id: userId, user_data: userData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending welcome email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send live reminder email
  const sendLiveReminderEmail = useCallback(async (userId: string, reminderData: LiveReminderEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_live_reminder', user_id: userId, reminder_data: reminderData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending live reminder email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Send promo code email
  const sendPromoCodeEmail = useCallback(async (userId: string, promoData: PromoEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'send_promo_code', user_id: userId, promo_data: promoData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error sending promo code email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Broadcast promo email to all users
  const broadcastPromoEmail = useCallback(async (promoData: PromoEmailData) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'broadcast_promo_email', promo_data: promoData }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error broadcasting promo email:', err);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  // Get email logs for a user
  const getEmailLogs = useCallback(async (userId: string, limit = 50, offset = 0) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'get_email_logs', user_id: userId, limit, offset }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data.logs || [];
    } catch (err: any) {
      setError(err.message);
      console.error('Error getting email logs:', err);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  // Get email stats
  const getEmailStats = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: { action: 'get_email_stats' }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data.stats || null;
    } catch (err: any) {
      setError(err.message);
      console.error('Error getting email stats:', err);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Process pending message notifications (can be called periodically)
  const processPendingNotifications = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('manage-messaging', {
        body: { action: 'process_pending_notifications' }
      });
      if (error) throw error;
      return data;
    } catch (err: any) {
      console.error('Error processing pending notifications:', err);
      return { success: false, error: err.message };
    }
  }, []);

  return {
    loading,
    error,
    // Order emails (now automatically sent by edge functions)
    sendOrderConfirmation,
    sendShippingUpdate,
    sendDeliveryConfirmation,
    sendOrderCancelled,
    // Communication emails (now automatically sent with delay by edge functions)
    sendNewMessageEmail,
    // Seller emails (review emails now automatically sent by edge functions)
    sendSellerNewOrderEmail,
    sendSellerNewReviewEmail,
    sendSellerLowStockEmail,
    // User emails
    sendWelcomeEmail,
    sendLiveReminderEmail,
    sendPromoCodeEmail,
    // Broadcast
    broadcastPromoEmail,
    // Logs & Stats
    getEmailLogs,
    getEmailStats,
    // Utility
    processPendingNotifications
  };
}
