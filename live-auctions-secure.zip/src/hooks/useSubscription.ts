import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

export interface SubscriptionPlan {
  id: string;
  name: string;
  slug: string;
  price: number;
  period: string;
  features: string[];
  max_products: number;
  max_lives_per_month: number;
  is_popular: boolean;
  is_active: boolean;
}

export interface SellerSubscription {
  id: string;
  seller_id: string;
  plan_id: string;
  status: string;
  starts_at: string;
  ends_at: string;
  auto_renew: boolean;
  payment_method: string;
  payment_reference: string;
}

export interface SubscriptionLimits {
  maxProducts: number;
  maxLivesPerMonth: number;
  hasVerificationBadge: boolean;
  hasPromotion: boolean;
  hasAdvancedAnalytics: boolean;
  hasPrioritySupport: boolean;
  hasApiAccess: boolean;
  hasMultiUsers: boolean;
}

// Default plans as fallback when database is unavailable
const DEFAULT_PLANS: SubscriptionPlan[] = [
  {
    id: 'starter-default',
    name: 'Starter',
    slug: 'starter',
    price: 15000,
    period: 'month',
    features: [
      '5 Lives par mois',
      '20 produits max',
      'Support email',
      'Statistiques basiques'
    ],
    max_products: 20,
    max_lives_per_month: 5,
    is_popular: false,
    is_active: true
  },
  {
    id: 'pro-default',
    name: 'Professionnel',
    slug: 'pro',
    price: 35000,
    period: 'month',
    features: [
      'Lives illimités',
      '100 produits max',
      'Support prioritaire',
      'Statistiques avancées',
      'Badge vérifié',
      'Promotion en page d\'accueil'
    ],
    max_products: 100,
    max_lives_per_month: -1,
    is_popular: true,
    is_active: true
  },
  {
    id: 'enterprise-default',
    name: 'Entreprise',
    slug: 'enterprise',
    price: 75000,
    period: 'month',
    features: [
      'Tout du Pro',
      'Produits illimités',
      'Manager dédié',
      'API personnalisée',
      'Multi-utilisateurs',
      'Formation incluse',
      'Publicité gratuite'
    ],
    max_products: -1,
    max_lives_per_month: -1,
    is_popular: false,
    is_active: true
  }
];

export const useSubscription = () => {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<SellerSubscription | null>(null);
  const [plan, setPlan] = useState<SubscriptionPlan | null>(null);
  const [plans, setPlans] = useState<SubscriptionPlan[]>(DEFAULT_PLANS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPlans = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true)
        .order('price', { ascending: true });

      if (error) {
        console.warn('Error fetching plans from database, using defaults:', error);
        setPlans(DEFAULT_PLANS);
        return DEFAULT_PLANS;
      }
      
      if (data && data.length > 0) {
        setPlans(data);
        return data;
      } else {
        setPlans(DEFAULT_PLANS);
        return DEFAULT_PLANS;
      }
    } catch (err) {
      console.warn('Error fetching plans, using defaults:', err);
      setPlans(DEFAULT_PLANS);
      return DEFAULT_PLANS;
    }
  }, []);

  const fetchSubscription = useCallback(async () => {
    if (!user) {
      setSubscription(null);
      setPlan(null);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Fetch subscription
      const { data: subData, error: subError } = await supabase
        .from('seller_subscriptions')
        .select('*')
        .eq('seller_id', user.id)
        .in('status', ['active', 'canceling'])
        .single();

      if (subError && subError.code !== 'PGRST116') {
        // PGRST116 is "no rows returned" which is expected for new users
        console.warn('Error fetching subscription:', subError);
      }

      setSubscription(subData || null);

      // Fetch plan details if subscription exists
      if (subData) {
        // First try to get from database
        const { data: planData, error: planError } = await supabase
          .from('subscription_plans')
          .select('*')
          .eq('id', subData.plan_id)
          .single();

        if (planError) {
          // Fallback to finding in local plans
          const localPlan = plans.find(p => p.id === subData.plan_id);
          setPlan(localPlan || null);
        } else {
          setPlan(planData || null);
        }
      } else {
        setPlan(null);
      }
    } catch (err) {
      console.warn('Error fetching subscription:', err);
      setError(err instanceof Error ? err.message : 'Error fetching subscription');
    } finally {
      setLoading(false);
    }
  }, [user, plans]);

  useEffect(() => {
    fetchPlans();
  }, [fetchPlans]);

  useEffect(() => {
    fetchSubscription();
  }, [user]);

  const getSubscriptionLimits = useCallback((): SubscriptionLimits => {
    // Default limits for free users
    const defaultLimits: SubscriptionLimits = {
      maxProducts: 5,
      maxLivesPerMonth: 2,
      hasVerificationBadge: false,
      hasPromotion: false,
      hasAdvancedAnalytics: false,
      hasPrioritySupport: false,
      hasApiAccess: false,
      hasMultiUsers: false
    };

    if (!plan) return defaultLimits;

    const features = plan.features.map(f => f.toLowerCase());

    return {
      maxProducts: plan.max_products,
      maxLivesPerMonth: plan.max_lives_per_month,
      hasVerificationBadge: features.some(f => f.includes('badge') || f.includes('vérifié')),
      hasPromotion: features.some(f => f.includes('promotion') || f.includes('publicité')),
      hasAdvancedAnalytics: features.some(f => f.includes('avancé') || f.includes('premium')),
      hasPrioritySupport: features.some(f => f.includes('prioritaire') || f.includes('dédié')),
      hasApiAccess: features.some(f => f.includes('api')),
      hasMultiUsers: features.some(f => f.includes('multi') || f.includes('utilisateur'))
    };
  }, [plan]);

  const isSubscribed = useCallback(() => {
    return subscription !== null && subscription.status === 'active';
  }, [subscription]);

  const isPlanActive = useCallback((planSlug: string) => {
    return plan?.slug === planSlug && subscription?.status === 'active';
  }, [plan, subscription]);

  const canUpgrade = useCallback((targetPlanId: string) => {
    if (!subscription || !plan) return true;
    const targetPlan = plans.find(p => p.id === targetPlanId);
    if (!targetPlan) return false;
    return targetPlan.price > plan.price;
  }, [subscription, plan, plans]);

  const getDaysRemaining = useCallback(() => {
    if (!subscription) return 0;
    const endDate = new Date(subscription.ends_at);
    const now = new Date();
    const diff = endDate.getTime() - now.getTime();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  }, [subscription]);

  const isExpiringSoon = useCallback(() => {
    return getDaysRemaining() <= 7 && getDaysRemaining() > 0;
  }, [getDaysRemaining]);

  const isExpired = useCallback(() => {
    if (!subscription) return false;
    return new Date(subscription.ends_at) < new Date();
  }, [subscription]);

  const getPlanBySlug = useCallback((slug: string) => {
    return plans.find(p => p.slug === slug) || null;
  }, [plans]);

  const refreshSubscription = useCallback(async () => {
    await fetchSubscription();
  }, [fetchSubscription]);

  return {
    subscription,
    plan,
    plans,
    loading,
    error,
    limits: getSubscriptionLimits(),
    isSubscribed: isSubscribed(),
    isPlanActive,
    canUpgrade,
    getDaysRemaining,
    isExpiringSoon: isExpiringSoon(),
    isExpired: isExpired(),
    getPlanBySlug,
    refreshSubscription,
    fetchPlans
  };
};
