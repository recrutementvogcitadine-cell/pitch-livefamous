import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export interface SellerProduct {
  id: string;
  seller_id: string;
  name: string;
  description?: string;
  price: number;
  original_price?: number;
  category: string;
  image_url?: string;
  images: string[];
  stock_quantity: number;
  sku?: string;
  is_active: boolean;
  is_featured: boolean;
  views: number;
  sales_count: number;
  rating: number;
  reviews_count: number;
  tags: string[];
  specifications: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface ProductStats {
  total: number;
  active: number;
  inactive: number;
  outOfStock: number;
  lowStock: number;
  totalViews: number;
  totalSales: number;
  totalValue: number;
}

export interface CreateProductData {
  name: string;
  description?: string;
  price: number;
  originalPrice?: number;
  category: string;
  imageUrl?: string;
  images?: string[];
  stockQuantity?: number;
  sku?: string;
  isActive?: boolean;
  isFeatured?: boolean;
  tags?: string[];
  specifications?: Record<string, any>;
}

export interface StockAlert {
  id: string;
  seller_id: string;
  product_id: string;
  product_name: string;
  current_stock: number;
  threshold: number;
  alert_type: 'low_stock' | 'out_of_stock';
  is_read: boolean;
  created_at: string;
}

export interface SalesGoal {
  id: string;
  seller_id: string;
  goal_type: 'revenue' | 'orders' | 'products_sold' | 'new_customers';
  target_value: number;
  current_value: number;
  period: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  start_date: string;
  end_date: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProductReview {
  id: string;
  product_id: string;
  seller_id: string;
  buyer_id: string;
  buyer_name: string;
  rating: number;
  title?: string;
  comment?: string;
  images?: string[];
  is_verified_purchase: boolean;
  helpful_count: number;
  seller_response?: string;
  seller_response_at?: string;
  status: 'pending' | 'published' | 'hidden';
  created_at: string;
  updated_at: string;
}

export interface DailyAnalytics {
  id: string;
  seller_id: string;
  date: string;
  revenue: number;
  orders_count: number;
  products_sold: number;
  views: number;
  unique_visitors: number;
  new_customers: number;
  returning_customers: number;
  live_viewers: number;
  live_revenue: number;
  avg_order_value: number;
  conversion_rate: number;
}

export interface AnalyticsData {
  dailyData: DailyAnalytics[];
  totals: {
    revenue: number;
    orders: number;
    views: number;
    productsSold: number;
    avgConversionRate: string;
    avgOrderValue: string;
  };
  topProducts: Array<SellerProduct & { conversion: string; revenue: number }>;
  recentReviews: ProductReview[];
}

export interface CreateSalesGoalData {
  goalType: 'revenue' | 'orders' | 'products_sold' | 'new_customers';
  targetValue: number;
  currentValue?: number;
  period: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  startDate: string;
  endDate: string;
}

export function useProducts() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get seller products with filters
  const getSellerProducts = useCallback(async (
    sellerId: string,
    status?: string,
    category?: string,
    search?: string,
    page: number = 1,
    limit: number = 20
  ): Promise<{ products: SellerProduct[]; total: number; totalPages: number }> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'get_seller_products', sellerId, status, category, search, page, limit }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return { products: data.products, total: data.total, totalPages: data.totalPages };
    } catch (err: any) {
      setError(err.message);
      return { products: [], total: 0, totalPages: 0 };
    } finally {
      setLoading(false);
    }
  }, []);

  // Get single product
  const getProduct = useCallback(async (productId: string): Promise<SellerProduct | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'get_product', productId }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.product;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Create product
  const createProduct = useCallback(async (
    sellerId: string,
    product: CreateProductData
  ): Promise<SellerProduct | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'create_product', sellerId, product }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.product;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Update product
  const updateProduct = useCallback(async (
    productId: string,
    sellerId: string,
    product: Partial<CreateProductData>
  ): Promise<SellerProduct | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'update_product', productId, sellerId, product }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.product;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Delete product
  const deleteProduct = useCallback(async (productId: string, sellerId: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'delete_product', productId, sellerId }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Toggle product status
  const toggleProductStatus = useCallback(async (
    productId: string,
    sellerId: string,
    isActive: boolean
  ): Promise<SellerProduct | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'toggle_product_status', productId, sellerId, isActive }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.product;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get product stats
  const getProductStats = useCallback(async (sellerId: string): Promise<ProductStats | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'get_product_stats', sellerId }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.stats;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get stock alerts
  const getStockAlerts = useCallback(async (
    sellerId: string,
    unreadOnly: boolean = false
  ): Promise<StockAlert[]> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'get_stock_alerts', sellerId, unreadOnly }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.alerts || [];
    } catch (err: any) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  // Mark stock alert as read
  const markStockAlertRead = useCallback(async (
    alertId: string,
    sellerId: string
  ): Promise<boolean> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'mark_stock_alert_read', alertId, sellerId }
      });
      if (fnError) throw fnError;
      return data.success;
    } catch (err: any) {
      setError(err.message);
      return false;
    }
  }, []);

  // Get seller analytics
  const getSellerAnalytics = useCallback(async (
    sellerId: string,
    startDate: string,
    endDate: string,
    period: string = 'daily'
  ): Promise<AnalyticsData | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'get_seller_analytics', sellerId, startDate, endDate, period }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.analytics;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get sales goals
  const getSalesGoals = useCallback(async (sellerId: string): Promise<SalesGoal[]> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'get_sales_goals', sellerId }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.goals || [];
    } catch (err: any) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  // Create sales goal
  const createSalesGoal = useCallback(async (
    sellerId: string,
    goal: CreateSalesGoalData
  ): Promise<SalesGoal | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'create_sales_goal', sellerId, goal }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.goal;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Update sales goal
  const updateSalesGoal = useCallback(async (
    goalId: string,
    sellerId: string,
    goal: Partial<CreateSalesGoalData & { isActive: boolean }>
  ): Promise<SalesGoal | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'update_sales_goal', goalId, sellerId, goal }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.goal;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Delete sales goal
  const deleteSalesGoal = useCallback(async (
    goalId: string,
    sellerId: string
  ): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'delete_sales_goal', goalId, sellerId }
      });
      if (fnError) throw fnError;
      return data.success;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get product reviews
  const getProductReviews = useCallback(async (
    sellerId: string,
    productId?: string,
    status?: string,
    page: number = 1,
    limit: number = 20
  ): Promise<{
    reviews: ProductReview[];
    total: number;
    totalPages: number;
    avgRating: string;
    ratingDistribution: Array<{ rating: number; count: number }>;
  }> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'get_product_reviews', sellerId, productId, status, page, limit }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return {
        reviews: data.reviews || [],
        total: data.total || 0,
        totalPages: data.totalPages || 0,
        avgRating: data.avgRating || '0.0',
        ratingDistribution: data.ratingDistribution || []
      };
    } catch (err: any) {
      setError(err.message);
      return { reviews: [], total: 0, totalPages: 0, avgRating: '0.0', ratingDistribution: [] };
    } finally {
      setLoading(false);
    }
  }, []);

  // Respond to review
  const respondToReview = useCallback(async (
    reviewId: string,
    sellerId: string,
    response: string
  ): Promise<ProductReview | null> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'respond_to_review', reviewId, sellerId, response }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return data.review;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Bulk update status
  const bulkUpdateStatus = useCallback(async (
    productIds: string[],
    sellerId: string,
    isActive: boolean
  ): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'bulk_update_status', productIds, sellerId, isActive }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Bulk delete
  const bulkDelete = useCallback(async (productIds: string[], sellerId: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-products', {
        body: { action: 'bulk_delete', productIds, sellerId }
      });
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error);
      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    getSellerProducts,
    getProduct,
    createProduct,
    updateProduct,
    deleteProduct,
    toggleProductStatus,
    getProductStats,
    getStockAlerts,
    markStockAlertRead,
    getSellerAnalytics,
    getSalesGoals,
    createSalesGoal,
    updateSalesGoal,
    deleteSalesGoal,
    getProductReviews,
    respondToReview,
    bulkUpdateStatus,
    bulkDelete
  };
}
