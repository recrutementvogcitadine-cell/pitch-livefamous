import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { usePushNotifications } from './usePushNotifications';

// Demo mode flag
const isDemoMode = !isSupabaseConfigured;

export interface ScheduledStream {
  id: string;
  seller_id: string;
  title: string;
  description: string | null;
  thumbnail_url: string | null;
  scheduled_at: string;
  duration_minutes: number;
  category: string | null;
  tags: string[];
  status: 'scheduled' | 'live' | 'completed' | 'cancelled';
  live_stream_id: string | null;
  viewer_count_estimate: number;
  created_at: string;
  updated_at: string;
  seller?: {
    id: string;
    name: string;
    avatar_url: string | null;
    is_verified: boolean;
  };
}

export interface StreamReminder {
  id: string;
  user_id: string;
  scheduled_stream_id: string;
  reminder_type: 'email' | 'push' | 'both';
  remind_before_minutes: number;
  reminder_sent: boolean;
  push_enabled: boolean;
  created_at: string;
  scheduled_streams?: ScheduledStream;
}

// Demo data for scheduled streams
const demoScheduledStreams: ScheduledStream[] = [
  {
    id: 'demo-stream-1',
    seller_id: 'demo-seller-1',
    title: 'Collection Été 2026 - Nouveautés Mode',
    description: 'Découvrez notre nouvelle collection été avec des pièces exclusives',
    thumbnail_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=300&fit=crop',
    scheduled_at: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
    duration_minutes: 60,
    category: 'Mode',
    tags: ['mode', 'été', 'nouveautés'],
    status: 'scheduled',
    live_stream_id: null,
    viewer_count_estimate: 150,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    seller: {
      id: 'demo-seller-1',
      name: 'Fashion Store',
      avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      is_verified: true
    }
  },
  {
    id: 'demo-stream-2',
    seller_id: 'demo-seller-2',
    title: 'Tech Deals - Smartphones & Accessoires',
    description: 'Les meilleures offres tech de la semaine',
    thumbnail_url: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400&h=300&fit=crop',
    scheduled_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Tomorrow
    duration_minutes: 90,
    category: 'Électronique',
    tags: ['tech', 'smartphones', 'deals'],
    status: 'scheduled',
    live_stream_id: null,
    viewer_count_estimate: 300,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    seller: {
      id: 'demo-seller-2',
      name: 'Tech World',
      avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      is_verified: true
    }
  },
  {
    id: 'demo-stream-3',
    seller_id: 'demo-seller-3',
    title: 'Routine Beauté - Conseils & Produits',
    description: 'Découvrez nos conseils beauté et nos produits favoris',
    thumbnail_url: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=300&fit=crop',
    scheduled_at: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(), // In 2 days
    duration_minutes: 45,
    category: 'Beauté',
    tags: ['beauté', 'skincare', 'conseils'],
    status: 'scheduled',
    live_stream_id: null,
    viewer_count_estimate: 200,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    seller: {
      id: 'demo-seller-3',
      name: 'Beauty Corner',
      avatar_url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      is_verified: true
    }
  }
];

export function useScheduledStreams() {
  const [upcomingStreams, setUpcomingStreams] = useState<ScheduledStream[]>([]);
  const [followedStreams, setFollowedStreams] = useState<ScheduledStream[]>([]);
  const [sellerStreams, setSellerStreams] = useState<ScheduledStream[]>([]);
  const [userReminders, setUserReminders] = useState<StreamReminder[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { showStreamReminder, isSubscribed, permission } = usePushNotifications();
  const reminderTimeoutsRef = useRef<Map<string, NodeJS.Timeout>>(new Map());

  // Schedule local notifications for reminders
  const scheduleLocalReminders = useCallback((reminders: StreamReminder[]) => {
    // Clear existing timeouts
    reminderTimeoutsRef.current.forEach((timeout) => clearTimeout(timeout));
    reminderTimeoutsRef.current.clear();

    if (permission !== 'granted') return;

    const now = new Date().getTime();

    reminders.forEach((reminder) => {
      if (reminder.reminder_sent || !reminder.push_enabled) return;
      
      const stream = reminder.scheduled_streams;
      if (!stream || stream.status !== 'scheduled') return;

      const streamTime = new Date(stream.scheduled_at).getTime();
      const reminderTime = streamTime - (reminder.remind_before_minutes * 60 * 1000);
      const delay = reminderTime - now;

      if (delay > 0 && delay < 24 * 60 * 60 * 1000) { // Only schedule if within 24 hours
        const timeout = setTimeout(() => {
          showStreamReminder(
            stream.title,
            stream.seller?.name || 'Seller',
            stream.id,
            stream.thumbnail_url || undefined,
            reminder.remind_before_minutes
          );
          
          // Mark reminder as sent
          markReminderSent(reminder.id);
        }, delay);

        reminderTimeoutsRef.current.set(reminder.id, timeout);
      }
    });
  }, [permission, showStreamReminder]);

  // Mark reminder as sent
  const markReminderSent = async (reminderId: string) => {
    if (isDemoMode) {
      // In demo mode, just update local state
      setUserReminders(prev => 
        prev.map(r => r.id === reminderId ? { ...r, reminder_sent: true } : r)
      );
      return;
    }

    try {
      await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'mark_reminder_sent', reminder_id: reminderId }
      });
    } catch (err) {
      console.error('Failed to mark reminder as sent:', err);
    }
  };

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      reminderTimeoutsRef.current.forEach((timeout) => clearTimeout(timeout));
    };
  }, []);

  const fetchUpcomingStreams = useCallback(async (limit = 20, offset = 0) => {
    setLoading(true);
    setError(null);
    
    // Return demo data in demo mode
    if (isDemoMode) {
      setUpcomingStreams(demoScheduledStreams);
      setLoading(false);
      return demoScheduledStreams;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'get_upcoming_streams', limit, offset }
      });
      if (error) throw error;
      if (data?.success) {
        setUpcomingStreams(data.data || []);
        return data.data;
      }
      throw new Error(data?.error || 'Failed to fetch upcoming streams');
    } catch (err: any) {
      setError(err.message);
      // Fallback to demo data on error
      setUpcomingStreams(demoScheduledStreams);
      return demoScheduledStreams;
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchFollowedStreams = useCallback(async (userId: string, limit = 20) => {
    setLoading(true);
    setError(null);
    
    // Return demo data in demo mode
    if (isDemoMode) {
      setFollowedStreams(demoScheduledStreams.slice(0, 2));
      setLoading(false);
      return demoScheduledStreams.slice(0, 2);
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'get_upcoming_streams', user_id: userId, followed_only: true, limit }
      });
      if (error) throw error;
      if (data?.success) {
        setFollowedStreams(data.data || []);
        return data.data;
      }
      throw new Error(data?.error || 'Failed to fetch followed streams');
    } catch (err: any) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchSellerStreams = useCallback(async (sellerId: string) => {
    setLoading(true);
    setError(null);
    
    // Return demo data in demo mode
    if (isDemoMode) {
      const filtered = demoScheduledStreams.filter(s => s.seller_id === sellerId);
      setSellerStreams(filtered.length > 0 ? filtered : demoScheduledStreams.slice(0, 1));
      setLoading(false);
      return filtered.length > 0 ? filtered : demoScheduledStreams.slice(0, 1);
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'get_seller_scheduled_streams', seller_id: sellerId }
      });
      if (error) throw error;
      if (data?.success) {
        setSellerStreams(data.data || []);
        return data.data;
      }
      throw new Error(data?.error || 'Failed to fetch seller streams');
    } catch (err: any) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const createScheduledStream = useCallback(async (streamData: {
    seller_id: string;
    title: string;
    description?: string;
    thumbnail_url?: string;
    scheduled_at: string;
    duration_minutes?: number;
    category?: string;
    tags?: string[];
  }) => {
    setLoading(true);
    setError(null);
    
    // In demo mode, create a mock stream
    if (isDemoMode) {
      const newStream: ScheduledStream = {
        id: `demo-stream-${Date.now()}`,
        seller_id: streamData.seller_id,
        title: streamData.title,
        description: streamData.description || null,
        thumbnail_url: streamData.thumbnail_url || null,
        scheduled_at: streamData.scheduled_at,
        duration_minutes: streamData.duration_minutes || 60,
        category: streamData.category || null,
        tags: streamData.tags || [],
        status: 'scheduled',
        live_stream_id: null,
        viewer_count_estimate: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      setSellerStreams(prev => [...prev, newStream]);
      setLoading(false);
      return newStream;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'create_scheduled_stream', ...streamData }
      });
      if (error) throw error;
      if (data?.success) {
        return data.data;
      }
      throw new Error(data?.error || 'Failed to create scheduled stream');
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateScheduledStream = useCallback(async (streamId: string, sellerId: string, updates: Partial<ScheduledStream>) => {
    setLoading(true);
    setError(null);
    
    // In demo mode, update local state
    if (isDemoMode) {
      setSellerStreams(prev => 
        prev.map(s => s.id === streamId ? { ...s, ...updates, updated_at: new Date().toISOString() } : s)
      );
      setLoading(false);
      return { id: streamId, ...updates };
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'update_scheduled_stream', stream_id: streamId, seller_id: sellerId, ...updates }
      });
      if (error) throw error;
      if (data?.success) {
        return data.data;
      }
      throw new Error(data?.error || 'Failed to update scheduled stream');
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const cancelScheduledStream = useCallback(async (streamId: string, sellerId: string) => {
    setLoading(true);
    setError(null);
    
    // In demo mode, update local state
    if (isDemoMode) {
      setSellerStreams(prev => 
        prev.map(s => s.id === streamId ? { ...s, status: 'cancelled' } : s)
      );
      setLoading(false);
      return true;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'cancel_scheduled_stream', stream_id: streamId, seller_id: sellerId }
      });
      if (error) throw error;
      if (data?.success) {
        return true;
      }
      throw new Error(data?.error || 'Failed to cancel scheduled stream');
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const setReminder = useCallback(async (
    userId: string, 
    scheduledStreamId: string, 
    reminderType: 'email' | 'push' | 'both' = 'both', 
    remindBeforeMinutes = 15,
    pushEnabled = true
  ) => {
    setLoading(true);
    setError(null);
    
    // In demo mode, create a mock reminder
    if (isDemoMode) {
      const stream = [...upcomingStreams, ...demoScheduledStreams].find(s => s.id === scheduledStreamId);
      const newReminder: StreamReminder = {
        id: `demo-reminder-${Date.now()}`,
        user_id: userId,
        scheduled_stream_id: scheduledStreamId,
        reminder_type: reminderType,
        remind_before_minutes: remindBeforeMinutes,
        reminder_sent: false,
        push_enabled: pushEnabled,
        created_at: new Date().toISOString(),
        scheduled_streams: stream
      };
      setUserReminders(prev => [...prev, newReminder]);
      setLoading(false);
      return newReminder;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { 
          action: 'set_reminder', 
          user_id: userId, 
          scheduled_stream_id: scheduledStreamId,
          reminder_type: reminderType,
          remind_before_minutes: remindBeforeMinutes,
          push_enabled: pushEnabled
        }
      });
      if (error) throw error;
      if (data?.success) {
        return data.data;
      }
      throw new Error(data?.error || 'Failed to set reminder');
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, [upcomingStreams]);

  const removeReminder = useCallback(async (userId: string, scheduledStreamId: string) => {
    setLoading(true);
    setError(null);
    
    // In demo mode, remove from local state
    if (isDemoMode) {
      const reminder = userReminders.find(r => r.scheduled_stream_id === scheduledStreamId);
      if (reminder && reminderTimeoutsRef.current.has(reminder.id)) {
        clearTimeout(reminderTimeoutsRef.current.get(reminder.id));
        reminderTimeoutsRef.current.delete(reminder.id);
      }
      setUserReminders(prev => prev.filter(r => r.scheduled_stream_id !== scheduledStreamId));
      setLoading(false);
      return true;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'remove_reminder', user_id: userId, scheduled_stream_id: scheduledStreamId }
      });
      if (error) throw error;
      if (data?.success) {
        // Clear local timeout if exists
        const reminder = userReminders.find(r => r.scheduled_stream_id === scheduledStreamId);
        if (reminder && reminderTimeoutsRef.current.has(reminder.id)) {
          clearTimeout(reminderTimeoutsRef.current.get(reminder.id));
          reminderTimeoutsRef.current.delete(reminder.id);
        }
        return true;
      }
      throw new Error(data?.error || 'Failed to remove reminder');
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, [userReminders]);

  const checkReminder = useCallback(async (userId: string, scheduledStreamId: string) => {
    // In demo mode, check local state
    if (isDemoMode) {
      return userReminders.some(r => r.scheduled_stream_id === scheduledStreamId && r.user_id === userId);
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'check_reminder', user_id: userId, scheduled_stream_id: scheduledStreamId }
      });
      if (error) throw error;
      return data?.hasReminder || false;
    } catch (err: any) {
      return false;
    }
  }, [userReminders]);

  const fetchUserReminders = useCallback(async (userId: string) => {
    setLoading(true);
    setError(null);
    
    // In demo mode, return local reminders
    if (isDemoMode) {
      setLoading(false);
      return userReminders;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-scheduled-streams', {
        body: { action: 'get_user_reminders', user_id: userId }
      });
      if (error) throw error;
      if (data?.success) {
        const reminders = data.data || [];
        setUserReminders(reminders);
        
        // Schedule local push notifications
        scheduleLocalReminders(reminders);
        
        return reminders;
      }
      throw new Error(data?.error || 'Failed to fetch user reminders');
    } catch (err: any) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, [scheduleLocalReminders, userReminders]);

  // Generate Google Calendar URL
  const generateGoogleCalendarUrl = useCallback((stream: ScheduledStream) => {
    const startDate = new Date(stream.scheduled_at);
    const endDate = new Date(startDate.getTime() + (stream.duration_minutes || 60) * 60 * 1000);
    
    const formatDate = (date: Date) => {
      return date.toISOString().replace(/-|:|\.\d{3}/g, '');
    };

    const params = new URLSearchParams({
      action: 'TEMPLATE',
      text: `Live Stream: ${stream.title}`,
      dates: `${formatDate(startDate)}/${formatDate(endDate)}`,
      details: stream.description || `Live stream by ${stream.seller?.name || 'Seller'}`,
      location: window.location.origin,
    });

    return `https://calendar.google.com/calendar/render?${params.toString()}`;
  }, []);

  // Generate iCal file content
  const generateICalContent = useCallback((stream: ScheduledStream) => {
    const startDate = new Date(stream.scheduled_at);
    const endDate = new Date(startDate.getTime() + (stream.duration_minutes || 60) * 60 * 1000);
    
    const formatDate = (date: Date) => {
      return date.toISOString().replace(/-|:|\.\d{3}/g, '').slice(0, -1) + 'Z';
    };

    const icalContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Famous.ai//Live Stream//EN
BEGIN:VEVENT
UID:${stream.id}@famous.ai
DTSTAMP:${formatDate(new Date())}
DTSTART:${formatDate(startDate)}
DTEND:${formatDate(endDate)}
SUMMARY:Live Stream: ${stream.title}
DESCRIPTION:${stream.description || `Live stream by ${stream.seller?.name || 'Seller'}`}
URL:${window.location.origin}
END:VEVENT
END:VCALENDAR`;

    return icalContent;
  }, []);

  // Download iCal file
  const downloadICalFile = useCallback((stream: ScheduledStream) => {
    const content = generateICalContent(stream);
    const blob = new Blob([content], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `live-stream-${stream.id}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [generateICalContent]);

  return {
    upcomingStreams,
    followedStreams,
    sellerStreams,
    userReminders,
    loading,
    error,
    fetchUpcomingStreams,
    fetchFollowedStreams,
    fetchSellerStreams,
    createScheduledStream,
    updateScheduledStream,
    cancelScheduledStream,
    setReminder,
    removeReminder,
    checkReminder,
    fetchUserReminders,
    generateGoogleCalendarUrl,
    generateICalContent,
    downloadICalFile,
    scheduleLocalReminders
  };
}
