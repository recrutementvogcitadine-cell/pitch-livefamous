import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export type PaymentMethod = 'orange_money' | 'mtn_money' | 'wave' | 'moov_money' | 'card' | 'paypal' | 'cod';
export type PaymentStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'refunded' | 'cancelled';

export interface Payment {
  id: string;
  user_id: string;
  order_id?: string;
  transaction_id: string;
  amount: number;
  currency: string;
  payment_method: PaymentMethod;
  payment_provider: string;
  status: PaymentStatus;
  phone_number?: string;
  card_last_four?: string;
  card_brand?: string;
  paypal_email?: string;
  provider_reference?: string;
  failure_reason?: string;
  metadata?: Record<string, any>;
  created_at: string;
  updated_at: string;
  completed_at?: string;
  refunded_at?: string;
}

export interface SavedPaymentMethod {
  id: string;
  user_id: string;
  method_type: PaymentMethod;
  provider: string;
  label: string;
  phone_number?: string;
  card_last_four?: string;
  card_brand?: string;
  card_expiry?: string;
  paypal_email?: string;
  is_default: boolean;
  is_active: boolean;
  created_at: string;
}

export interface PaymentRequest {
  orderId?: string;
  amount: number;
  currency?: string;
  paymentMethod: PaymentMethod;
  phoneNumber?: string;
  customerName: string;
  customerEmail?: string;
  cardLastFour?: string;
  cardBrand?: string;
  paypalEmail?: string;
  savePaymentMethod?: boolean;
}

export interface PaymentResponse {
  success: boolean;
  transactionId?: string;
  paymentId?: string;
  message: string;
  status: PaymentStatus;
  instructions?: string[];
  qrCode?: string;
  redirectUrl?: string;
  providerInfo?: {
    provider: string;
    name: string;
    color: string;
  };
  error?: string;
}

export interface PaymentMethodInfo {
  id: PaymentMethod;
  name: string;
  provider: string;
  icon: string;
  color: string;
  category: 'mobile_money' | 'card' | 'online' | 'cash';
  requiresPhone: boolean;
  requiresCard: boolean;
  requiresEmail: boolean;
  description: string;
}

export const PAYMENT_METHODS: PaymentMethodInfo[] = [
  {
    id: 'orange_money',
    name: 'Orange Money',
    provider: 'Orange',
    icon: 'orange',
    color: '#FF6600',
    category: 'mobile_money',
    requiresPhone: true,
    requiresCard: false,
    requiresEmail: false,
    description: 'Payez avec votre compte Orange Money'
  },
  {
    id: 'mtn_money',
    name: 'MTN Mobile Money',
    provider: 'MTN',
    icon: 'mtn',
    color: '#FFCC00',
    category: 'mobile_money',
    requiresPhone: true,
    requiresCard: false,
    requiresEmail: false,
    description: 'Payez avec votre compte MTN MoMo'
  },
  {
    id: 'wave',
    name: 'Wave',
    provider: 'Wave',
    icon: 'wave',
    color: '#1DC8F2',
    category: 'mobile_money',
    requiresPhone: true,
    requiresCard: false,
    requiresEmail: false,
    description: 'Payez avec votre compte Wave'
  },
  {
    id: 'moov_money',
    name: 'Moov Money',
    provider: 'Moov',
    icon: 'moov',
    color: '#0066CC',
    category: 'mobile_money',
    requiresPhone: true,
    requiresCard: false,
    requiresEmail: false,
    description: 'Payez avec votre compte Moov Money'
  },
  {
    id: 'card',
    name: 'Carte Bancaire',
    provider: 'Visa/Mastercard',
    icon: 'card',
    color: '#635BFF',
    category: 'card',
    requiresPhone: false,
    requiresCard: true,
    requiresEmail: false,
    description: 'Payez par carte Visa ou Mastercard'
  },
  {
    id: 'paypal',
    name: 'PayPal',
    provider: 'PayPal',
    icon: 'paypal',
    color: '#003087',
    category: 'online',
    requiresPhone: false,
    requiresCard: false,
    requiresEmail: true,
    description: 'Payez avec votre compte PayPal'
  },
  {
    id: 'cod',
    name: 'Paiement à la livraison',
    provider: 'COD',
    icon: 'cash',
    color: '#10B981',
    category: 'cash',
    requiresPhone: false,
    requiresCard: false,
    requiresEmail: false,
    description: 'Payez en espèces à la réception'
  }
];

export const usePayment = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processPayment = useCallback(async (request: PaymentRequest): Promise<PaymentResponse> => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'process', ...request }
      });

      if (fnError) throw new Error(fnError.message);
      if (!data?.success) throw new Error(data?.error || 'Erreur de paiement');

      return data as PaymentResponse;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur de paiement';
      setError(message);
      return {
        success: false,
        message,
        status: 'failed',
        error: message
      };
    } finally {
      setLoading(false);
    }
  }, []);

  const confirmPayment = useCallback(async (transactionId: string): Promise<boolean> => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'confirm', transactionId }
      });

      if (fnError) throw new Error(fnError.message);
      return data?.success || false;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur de confirmation';
      setError(message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const cancelPayment = useCallback(async (transactionId: string): Promise<boolean> => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'cancel', transactionId }
      });

      if (fnError) throw new Error(fnError.message);
      return data?.success || false;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur d\'annulation';
      setError(message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const checkPaymentStatus = useCallback(async (transactionId: string): Promise<Payment | null> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'check_status', transactionId }
      });

      if (fnError) throw new Error(fnError.message);
      return data?.payment || null;
    } catch (err) {
      console.error('Error checking payment status:', err);
      return null;
    }
  }, []);

  const getPaymentHistory = useCallback(async (limit = 20, offset = 0): Promise<{
    payments: Payment[];
    total: number;
    hasMore: boolean;
  }> => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'get_history', limit, offset }
      });

      if (fnError) throw new Error(fnError.message);
      return {
        payments: data?.payments || [],
        total: data?.total || 0,
        hasMore: data?.hasMore || false
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur de chargement';
      setError(message);
      return { payments: [], total: 0, hasMore: false };
    } finally {
      setLoading(false);
    }
  }, []);

  const getSavedPaymentMethods = useCallback(async (): Promise<SavedPaymentMethod[]> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'get_saved_methods' }
      });

      if (fnError) throw new Error(fnError.message);
      return data?.methods || [];
    } catch (err) {
      console.error('Error fetching saved methods:', err);
      return [];
    }
  }, []);

  const savePaymentMethod = useCallback(async (method: {
    paymentMethod: PaymentMethod;
    phoneNumber?: string;
    cardLastFour?: string;
    cardBrand?: string;
    cardExpiry?: string;
    paypalEmail?: string;
  }): Promise<SavedPaymentMethod | null> => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'save_method', ...method }
      });

      if (fnError) throw new Error(fnError.message);
      return data?.method || null;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur d\'enregistrement';
      setError(message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const deletePaymentMethod = useCallback(async (savedMethodId: string): Promise<boolean> => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'delete_method', savedMethodId }
      });

      if (fnError) throw new Error(fnError.message);
      return data?.success || false;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur de suppression';
      setError(message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const setDefaultPaymentMethod = useCallback(async (savedMethodId: string): Promise<boolean> => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('process-payment', {
        body: { action: 'set_default_method', savedMethodId }
      });

      if (fnError) throw new Error(fnError.message);
      return data?.success || false;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur de mise à jour';
      setError(message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const getPaymentMethodInfo = useCallback((methodId: PaymentMethod): PaymentMethodInfo | undefined => {
    return PAYMENT_METHODS.find(m => m.id === methodId);
  }, []);

  const formatAmount = useCallback((amount: number, currency = 'XOF'): string => {
    if (currency === 'XOF' || currency === 'FCFA') {
      return `${amount.toLocaleString('fr-FR')} FCFA`;
    }
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency
    }).format(amount);
  }, []);

  const getStatusLabel = useCallback((status: PaymentStatus): string => {
    switch (status) {
      case 'pending': return 'En attente';
      case 'processing': return 'En cours';
      case 'completed': return 'Complété';
      case 'failed': return 'Échoué';
      case 'refunded': return 'Remboursé';
      case 'cancelled': return 'Annulé';
      default: return status;
    }
  }, []);

  const getStatusColor = useCallback((status: PaymentStatus): string => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'processing': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'completed': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'failed': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'refunded': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'cancelled': return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  }, []);

  return {
    loading,
    error,
    processPayment,
    confirmPayment,
    cancelPayment,
    checkPaymentStatus,
    getPaymentHistory,
    getSavedPaymentMethods,
    savePaymentMethod,
    deletePaymentMethod,
    setDefaultPaymentMethod,
    getPaymentMethodInfo,
    formatAmount,
    getStatusLabel,
    getStatusColor,
    PAYMENT_METHODS
  };
};
