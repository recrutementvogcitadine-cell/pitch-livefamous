import { useState, useEffect, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

// Demo mode flag
const isDemoMode = !isSupabaseConfigured;

interface PushSubscriptionData {
  endpoint: string;
  p256dh_key: string;
  auth_key: string;
}

interface NotificationOptions {
  body: string;
  icon?: string;
  badge?: string;
  tag?: string;
  image?: string;
  data?: Record<string, any>;
  requireInteraction?: boolean;
  actions?: Array<{ action: string; title: string; icon?: string }>;
}

export function usePushNotifications() {
  const { user } = useAuth();
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isSupported, setIsSupported] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [registration, setRegistration] = useState<ServiceWorkerRegistration | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check if notifications are supported
  useEffect(() => {
    const supported = 'Notification' in window && 'serviceWorker' in navigator;
    setIsSupported(supported);
    
    if (supported) {
      setPermission(Notification.permission);
    }
  }, []);

  // Register service worker
  useEffect(() => {
    if (!isSupported) return;

    const registerServiceWorker = async () => {
      try {
        const reg = await navigator.serviceWorker.register('/sw.js', {
          scope: '/'
        });
        console.log('Service Worker registered:', reg);
        setRegistration(reg);

        // Check for updates
        reg.addEventListener('updatefound', () => {
          const newWorker = reg.installing;
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                console.log('New service worker available');
              }
            });
          }
        });
      } catch (err) {
        console.error('Service Worker registration failed:', err);
        setError('Failed to register service worker');
      }
    };

    registerServiceWorker();
  }, [isSupported]);

  // Check subscription status when user changes
  useEffect(() => {
    if (!user || !registration) {
      setIsSubscribed(false);
      return;
    }

    // In demo mode, check localStorage
    if (isDemoMode) {
      const demoSubscribed = localStorage.getItem('demo_push_subscribed') === 'true';
      setIsSubscribed(demoSubscribed);
      return;
    }

    const checkSubscription = async () => {
      try {
        const { data } = await supabase
          .from('push_subscriptions')
          .select('id')
          .eq('user_id', user.id)
          .eq('is_active', true)
          .limit(1);

        setIsSubscribed(data && data.length > 0);
      } catch (err) {
        console.error('Error checking subscription:', err);
      }
    };

    checkSubscription();
  }, [user, registration]);

  // Listen for notification clicks from service worker
  useEffect(() => {
    if (!navigator.serviceWorker) return;

    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'NOTIFICATION_CLICK') {
        console.log('Notification clicked:', event.data);
        
        // Handle navigation to stream
        if (event.data.data?.streamId) {
          window.dispatchEvent(new CustomEvent('open-stream', {
            detail: { streamId: event.data.data.streamId }
          }));
        }
      }
    };

    navigator.serviceWorker.addEventListener('message', handleMessage);
    return () => {
      navigator.serviceWorker.removeEventListener('message', handleMessage);
    };
  }, []);

  // Request notification permission
  const requestPermission = useCallback(async (): Promise<boolean> => {
    if (!isSupported) {
      setError('Notifications are not supported in this browser');
      return false;
    }

    setLoading(true);
    setError(null);

    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      
      if (result === 'granted') {
        return true;
      } else if (result === 'denied') {
        setError('Notification permission was denied');
        return false;
      } else {
        setError('Notification permission was dismissed');
        return false;
      }
    } catch (err) {
      console.error('Error requesting permission:', err);
      setError('Failed to request notification permission');
      return false;
    } finally {
      setLoading(false);
    }
  }, [isSupported]);

  // Subscribe to push notifications
  const subscribe = useCallback(async (): Promise<boolean> => {
    if (!user && !isDemoMode) {
      setError('You must be logged in to enable notifications');
      return false;
    }

    if (!registration) {
      setError('Service worker not registered');
      return false;
    }

    if (permission !== 'granted') {
      const granted = await requestPermission();
      if (!granted) return false;
    }

    setLoading(true);
    setError(null);

    try {
      // In demo mode, store in localStorage
      if (isDemoMode) {
        localStorage.setItem('demo_push_subscribed', 'true');
        setIsSubscribed(true);
        
        // Show confirmation notification
        showNotification('Notifications Enabled', {
          body: 'You will now receive reminders for upcoming live streams!',
          tag: 'subscription-confirmed'
        });
        
        setLoading(false);
        return true;
      }

      // For now, we'll store a basic subscription record
      // In production, you'd use VAPID keys for true push notifications
      const subscriptionData: PushSubscriptionData = {
        endpoint: `${window.location.origin}/notifications/${user!.id}`,
        p256dh_key: btoa(String(Date.now())), // Placeholder
        auth_key: btoa(user!.id), // Placeholder
      };

      const { error: dbError } = await supabase
        .from('push_subscriptions')
        .upsert({
          user_id: user!.id,
          endpoint: subscriptionData.endpoint,
          p256dh_key: subscriptionData.p256dh_key,
          auth_key: subscriptionData.auth_key,
          user_agent: navigator.userAgent,
          is_active: true,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id,endpoint'
        });

      if (dbError) throw dbError;

      setIsSubscribed(true);
      
      // Show confirmation notification
      showNotification('Notifications Enabled', {
        body: 'You will now receive reminders for upcoming live streams!',
        tag: 'subscription-confirmed'
      });

      return true;
    } catch (err) {
      console.error('Error subscribing:', err);
      setError('Failed to enable notifications');
      return false;
    } finally {
      setLoading(false);
    }
  }, [user, registration, permission, requestPermission]);

  // Unsubscribe from push notifications
  const unsubscribe = useCallback(async (): Promise<boolean> => {
    if (!user && !isDemoMode) return false;

    setLoading(true);
    setError(null);

    try {
      // In demo mode, update localStorage
      if (isDemoMode) {
        localStorage.setItem('demo_push_subscribed', 'false');
        setIsSubscribed(false);
        setLoading(false);
        return true;
      }

      const { error: dbError } = await supabase
        .from('push_subscriptions')
        .update({ is_active: false, updated_at: new Date().toISOString() })
        .eq('user_id', user!.id);

      if (dbError) throw dbError;

      setIsSubscribed(false);
      return true;
    } catch (err) {
      console.error('Error unsubscribing:', err);
      setError('Failed to disable notifications');
      return false;
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Show a notification
  const showNotification = useCallback(async (
    title: string,
    options: NotificationOptions
  ): Promise<boolean> => {
    if (permission !== 'granted') {
      console.warn('Notification permission not granted');
      return false;
    }

    try {
      // Try to use service worker for richer notifications
      if (registration && registration.active) {
        registration.active.postMessage({
          type: 'SHOW_NOTIFICATION',
          title,
          options: {
            ...options,
            icon: options.icon || '/favicon.ico',
            badge: options.badge || '/favicon.ico',
          }
        });
        return true;
      }

      // Fallback to basic Notification API
      const notification = new Notification(title, {
        body: options.body,
        icon: options.icon || '/favicon.ico',
        tag: options.tag,
        data: options.data,
        requireInteraction: options.requireInteraction
      });

      notification.onclick = () => {
        window.focus();
        if (options.data?.streamId) {
          window.dispatchEvent(new CustomEvent('open-stream', {
            detail: { streamId: options.data.streamId }
          }));
        }
        notification.close();
      };

      return true;
    } catch (err) {
      console.error('Error showing notification:', err);
      return false;
    }
  }, [permission, registration]);

  // Schedule a notification for a specific time
  const scheduleNotification = useCallback(async (
    title: string,
    options: NotificationOptions,
    scheduledTime: Date
  ): Promise<NodeJS.Timeout | null> => {
    const now = new Date();
    const delay = scheduledTime.getTime() - now.getTime();

    if (delay <= 0) {
      // Time has already passed, show immediately
      showNotification(title, options);
      return null;
    }

    // Schedule the notification
    const timeoutId = setTimeout(() => {
      showNotification(title, options);
    }, delay);

    return timeoutId;
  }, [showNotification]);

  // Show stream reminder notification
  const showStreamReminder = useCallback(async (
    streamTitle: string,
    sellerName: string,
    streamId: string,
    thumbnail?: string,
    minutesUntilStart?: number
  ): Promise<boolean> => {
    const timeText = minutesUntilStart 
      ? `Starting in ${minutesUntilStart} minute${minutesUntilStart !== 1 ? 's' : ''}!`
      : 'Starting now!';

    return showNotification(`${sellerName} is going live!`, {
      body: `${streamTitle}\n${timeText}`,
      tag: `stream-reminder-${streamId}`,
      image: thumbnail,
      data: {
        streamId,
        type: 'stream_reminder'
      },
      requireInteraction: true,
      actions: [
        { action: 'watch', title: 'Watch Now' },
        { action: 'dismiss', title: 'Dismiss' }
      ]
    });
  }, [showNotification]);

  return {
    isSupported,
    permission,
    isSubscribed,
    loading,
    error,
    requestPermission,
    subscribe,
    unsubscribe,
    showNotification,
    scheduleNotification,
    showStreamReminder
  };
}
