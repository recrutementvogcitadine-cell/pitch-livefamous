import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export interface TestResult {
  id: string;
  test_type: string;
  test_name: string;
  status: 'passed' | 'failed' | 'warning' | 'running';
  duration_ms: number;
  error_message?: string;
  details?: Record<string, any>;
  created_at: string;
}

export interface ScheduledTest {
  id: string;
  name: string;
  test_types: string[];
  scheduled_time?: string;
  days_of_week?: number[];
  is_active: boolean;
  last_run_at?: string;
  next_run_at?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface AlertConfig {
  id?: string;
  user_id: string;
  alert_type: 'email' | 'push' | 'both';
  email_address?: string;
  notify_on_failure: boolean;
  notify_on_warning: boolean;
  notify_on_recovery: boolean;
  is_active: boolean;
}

export interface TestStats {
  stats: Record<string, { passed: number; failed: number; warning: number; total: number }>;
  dailyStats: Record<string, { passed: number; failed: number; warning: number }>;
  totalTests: number;
}

export const TEST_TYPES = [
  { id: 'database', name: 'Base de données', description: 'Vérifie la connexion à la base de données' },
  { id: 'agora', name: 'Agora Credentials', description: 'Vérifie les identifiants Agora' },
  { id: 'storage', name: 'Stockage', description: 'Vérifie les buckets de stockage' },
  { id: 'edge_functions', name: 'Edge Functions', description: 'Vérifie la disponibilité des fonctions' },
  { id: 'realtime', name: 'Temps réel', description: 'Vérifie la connexion temps réel' },
  { id: 'email', name: 'Service Email', description: 'Vérifie le service d\'envoi d\'emails' },
  { id: 'tables', name: 'Tables Live', description: 'Vérifie les tables du système de live' }
];

export const DAYS_OF_WEEK = [
  { id: 0, name: 'Dimanche', short: 'Dim' },
  { id: 1, name: 'Lundi', short: 'Lun' },
  { id: 2, name: 'Mardi', short: 'Mar' },
  { id: 3, name: 'Mercredi', short: 'Mer' },
  { id: 4, name: 'Jeudi', short: 'Jeu' },
  { id: 5, name: 'Vendredi', short: 'Ven' },
  { id: 6, name: 'Samedi', short: 'Sam' }
];

export function useAutomatedTests() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Run all tests
  const runAllTests = useCallback(async (): Promise<TestResult[] | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { action: 'run_all_tests' }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to run tests');
      
      return data.results;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Run a specific test
  const runSpecificTest = useCallback(async (testType: string): Promise<TestResult | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { action: 'run_specific_test', test_type: testType }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to run test');
      
      return data.result;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get test history
  const getTestHistory = useCallback(async (
    limit?: number,
    testType?: string,
    startDate?: string,
    endDate?: string
  ): Promise<TestResult[] | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { 
          action: 'get_test_history',
          limit,
          test_type: testType,
          start_date: startDate,
          end_date: endDate
        }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to get history');
      
      return data.data;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get test statistics
  const getTestStats = useCallback(async (days: number = 7): Promise<TestStats | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { action: 'get_test_stats', days }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to get stats');
      
      return {
        stats: data.stats,
        dailyStats: data.dailyStats,
        totalTests: data.totalTests
      };
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Create a scheduled test
  const createSchedule = useCallback(async (
    name: string,
    testTypes: string[],
    scheduledTime: string,
    daysOfWeek: number[],
    userId: string
  ): Promise<ScheduledTest | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { 
          action: 'create_schedule',
          name,
          test_types: testTypes,
          scheduled_time: scheduledTime,
          days_of_week: daysOfWeek,
          user_id: userId
        }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to create schedule');
      
      return data.data;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get all schedules
  const getSchedules = useCallback(async (): Promise<ScheduledTest[] | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { action: 'get_schedules' }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to get schedules');
      
      return data.data;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Update a schedule
  const updateSchedule = useCallback(async (
    id: string,
    updates: Partial<ScheduledTest>
  ): Promise<ScheduledTest | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { 
          action: 'update_schedule',
          id,
          ...updates
        }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to update schedule');
      
      return data.data;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Delete a schedule
  const deleteSchedule = useCallback(async (id: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { action: 'delete_schedule', id }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to delete schedule');
      
      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Save alert configuration
  const saveAlertConfig = useCallback(async (config: AlertConfig): Promise<AlertConfig | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { 
          action: 'save_alert_config',
          ...config
        }
      });
      
      if (fnError) throw fnError;
      if (!data.success) throw new Error(data.error || 'Failed to save alert config');
      
      return data.data;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get alert configuration
  const getAlertConfig = useCallback(async (userId: string): Promise<AlertConfig | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-automated-tests', {
        body: { action: 'get_alert_config', user_id: userId }
      });
      
      if (fnError) throw fnError;
      
      return data.data;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Helper functions
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'failed': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'warning': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'running': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'passed': return 'Réussi';
      case 'failed': return 'Échec';
      case 'warning': return 'Attention';
      case 'running': return 'En cours';
      default: return status;
    }
  };

  const getTestTypeLabel = (type: string) => {
    const testType = TEST_TYPES.find(t => t.id === type);
    return testType?.name || type;
  };

  return {
    loading,
    error,
    runAllTests,
    runSpecificTest,
    getTestHistory,
    getTestStats,
    createSchedule,
    getSchedules,
    updateSchedule,
    deleteSchedule,
    saveAlertConfig,
    getAlertConfig,
    getStatusColor,
    getStatusLabel,
    getTestTypeLabel
  };
}
