import { useState, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

const isDemoMode = !isSupabaseConfigured;

export interface Recording {
  id: string;
  live_stream_id: string;
  seller_id: string;
  title: string;
  description?: string;
  original_url?: string;
  processed_url?: string;
  thumbnail_url?: string;
  status: 'processing' | 'ready' | 'published' | 'archived' | 'failed';
  duration_seconds: number;
  file_size_bytes: number;
  trim_start_seconds: number;
  trim_end_seconds?: number;
  is_published: boolean;
  publish_date?: string;
  view_count: number;
  created_at: string;
  updated_at: string;
  live_streams?: {
    title: string;
    thumbnail_url?: string;
    category?: string;
    started_at?: string;
    ended_at?: string;
  };
}

export interface Chapter {
  id: string;
  recording_id: string;
  title: string;
  description?: string;
  timestamp_seconds: number;
  thumbnail_url?: string;
  display_order: number;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  stream_id: string;
  user_id: string;
  user_name: string;
  user_avatar?: string;
  message: string;
  message_type: 'chat' | 'join' | 'leave' | 'purchase' | 'highlight';
  timestamp_offset_ms: number;
  created_at: string;
}

// Demo data
const demoRecordings: Recording[] = [
  {
    id: 'demo-rec-1',
    live_stream_id: 'demo-live-1',
    seller_id: 'demo-seller-1',
    title: 'Collection Printemps - Mode Femme',
    description: 'Découvrez notre nouvelle collection printemps',
    original_url: 'https://example.com/video1.mp4',
    processed_url: 'https://example.com/video1.mp4',
    thumbnail_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=300&fit=crop',
    status: 'published',
    duration_seconds: 3600,
    file_size_bytes: 1024000000,
    trim_start_seconds: 0,
    trim_end_seconds: 3600,
    is_published: true,
    publish_date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    view_count: 1250,
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    live_streams: {
      title: 'Collection Printemps - Mode Femme',
      thumbnail_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=300&fit=crop',
      category: 'Mode'
    }
  },
  {
    id: 'demo-rec-2',
    live_stream_id: 'demo-live-2',
    seller_id: 'demo-seller-1',
    title: 'Tech Unboxing - iPhone 16 Pro',
    description: 'Unboxing et test du nouveau iPhone',
    original_url: 'https://example.com/video2.mp4',
    processed_url: 'https://example.com/video2.mp4',
    thumbnail_url: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400&h=300&fit=crop',
    status: 'ready',
    duration_seconds: 2700,
    file_size_bytes: 768000000,
    trim_start_seconds: 30,
    trim_end_seconds: 2650,
    is_published: false,
    view_count: 0,
    created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    live_streams: {
      title: 'Tech Unboxing - iPhone 16 Pro',
      thumbnail_url: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400&h=300&fit=crop',
      category: 'Électronique'
    }
  }
];

const demoChapters: Chapter[] = [
  {
    id: 'demo-chapter-1',
    recording_id: 'demo-rec-1',
    title: 'Introduction',
    description: 'Bienvenue dans ce live',
    timestamp_seconds: 0,
    display_order: 0,
    created_at: new Date().toISOString()
  },
  {
    id: 'demo-chapter-2',
    recording_id: 'demo-rec-1',
    title: 'Présentation des robes',
    description: 'Découvrez notre collection de robes',
    timestamp_seconds: 300,
    display_order: 1,
    created_at: new Date().toISOString()
  },
  {
    id: 'demo-chapter-3',
    recording_id: 'demo-rec-1',
    title: 'Accessoires',
    description: 'Les accessoires assortis',
    timestamp_seconds: 1200,
    display_order: 2,
    created_at: new Date().toISOString()
  },
  {
    id: 'demo-chapter-4',
    recording_id: 'demo-rec-1',
    title: 'Questions & Réponses',
    description: 'Réponses à vos questions',
    timestamp_seconds: 2400,
    display_order: 3,
    created_at: new Date().toISOString()
  }
];

export const useRecordings = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch all recordings for the seller
  const fetchRecordings = useCallback(async (status?: string): Promise<Recording[]> => {
    if (isDemoMode) {
      let filtered = [...demoRecordings];
      if (status) {
        filtered = filtered.filter(r => r.status === status);
      }
      return filtered;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'get_recordings', status }
      });

      if (fnError) throw fnError;
      return data?.recordings || [];
    } catch (err: any) {
      console.error('Error fetching recordings:', err);
      setError(err.message);
      return demoRecordings;
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch single recording with chapters and messages
  const fetchRecording = useCallback(async (recordingId: string): Promise<{
    recording: Recording | null;
    chapters: Chapter[];
    messages: ChatMessage[];
  }> => {
    if (isDemoMode) {
      const recording = demoRecordings.find(r => r.id === recordingId) || null;
      const chapters = demoChapters.filter(c => c.recording_id === recordingId);
      return { 
        recording, 
        chapters,
        messages: [
          {
            id: 'msg-1',
            stream_id: recording?.live_stream_id || '',
            user_id: 'user-1',
            user_name: 'Marie',
            message: 'Super collection !',
            message_type: 'chat',
            timestamp_offset_ms: 5000,
            created_at: new Date().toISOString()
          },
          {
            id: 'msg-2',
            stream_id: recording?.live_stream_id || '',
            user_id: 'user-2',
            user_name: 'Jean',
            message: 'J\'adore les couleurs',
            message_type: 'chat',
            timestamp_offset_ms: 15000,
            created_at: new Date().toISOString()
          }
        ]
      };
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'get_recording', recordingId }
      });

      if (fnError) throw fnError;
      return {
        recording: data?.recording || null,
        chapters: data?.chapters || [],
        messages: data?.messages || []
      };
    } catch (err: any) {
      console.error('Error fetching recording:', err);
      setError(err.message);
      return { recording: null, chapters: [], messages: [] };
    } finally {
      setLoading(false);
    }
  }, []);

  // Update recording metadata
  const updateRecording = useCallback(async (
    recordingId: string,
    updates: {
      title?: string;
      description?: string;
      trimStart?: number;
      trimEnd?: number;
      thumbnailUrl?: string;
    }
  ): Promise<Recording | null> => {
    if (isDemoMode) {
      const recording = demoRecordings.find(r => r.id === recordingId);
      if (recording) {
        return { ...recording, ...updates };
      }
      return null;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'update_recording', recordingId, ...updates }
      });

      if (fnError) throw fnError;
      return data?.recording || null;
    } catch (err: any) {
      console.error('Error updating recording:', err);
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Publish recording
  const publishRecording = useCallback(async (recordingId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'publish_recording', recordingId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error publishing recording:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Unpublish recording
  const unpublishRecording = useCallback(async (recordingId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'unpublish_recording', recordingId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error unpublishing recording:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Delete recording
  const deleteRecording = useCallback(async (recordingId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'delete_recording', recordingId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error deleting recording:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Add chapter
  const addChapter = useCallback(async (
    recordingId: string,
    chapter: {
      title: string;
      description?: string;
      timestampSeconds: number;
      thumbnailUrl?: string;
    }
  ): Promise<Chapter | null> => {
    if (isDemoMode) {
      return {
        id: `demo-chapter-${Date.now()}`,
        recording_id: recordingId,
        title: chapter.title,
        description: chapter.description,
        timestamp_seconds: chapter.timestampSeconds,
        thumbnail_url: chapter.thumbnailUrl,
        display_order: demoChapters.length,
        created_at: new Date().toISOString()
      };
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'add_chapter', recordingId, ...chapter }
      });

      if (fnError) throw fnError;
      return data?.chapter || null;
    } catch (err: any) {
      console.error('Error adding chapter:', err);
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Update chapter
  const updateChapter = useCallback(async (
    chapterId: string,
    updates: {
      title?: string;
      description?: string;
      timestampSeconds?: number;
      thumbnailUrl?: string;
    }
  ): Promise<Chapter | null> => {
    if (isDemoMode) {
      const chapter = demoChapters.find(c => c.id === chapterId);
      if (chapter) {
        return { ...chapter, ...updates };
      }
      return null;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'update_chapter', chapterId, ...updates }
      });

      if (fnError) throw fnError;
      return data?.chapter || null;
    } catch (err: any) {
      console.error('Error updating chapter:', err);
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Delete chapter
  const deleteChapter = useCallback(async (chapterId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'delete_chapter', chapterId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error deleting chapter:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Get chapters for a recording or live stream
  const getChapters = useCallback(async (params: { recordingId?: string; liveStreamId?: string }): Promise<Chapter[]> => {
    if (isDemoMode) {
      if (params.recordingId) {
        return demoChapters.filter(c => c.recording_id === params.recordingId);
      }
      return demoChapters;
    }

    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'get_recording_chapters', ...params }
      });

      if (fnError) throw fnError;
      return data?.chapters || [];
    } catch (err: any) {
      console.error('Error fetching chapters:', err);
      return [];
    }
  }, []);

  // Reorder chapters
  const reorderChapters = useCallback(async (recordingId: string, chapterIds: string[]): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'reorder_chapters', recordingId, chapterIds }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error reordering chapters:', err);
      return false;
    }
  }, []);

  return {
    loading,
    error,
    fetchRecordings,
    fetchRecording,
    updateRecording,
    publishRecording,
    unpublishRecording,
    deleteRecording,
    addChapter,
    updateChapter,
    deleteChapter,
    getChapters,
    reorderChapters
  };
};
