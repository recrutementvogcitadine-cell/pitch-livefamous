import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';

export interface ChatMessage {
  id: string;
  stream_id: string;
  user_id: string;
  user_name: string;
  user_avatar?: string;
  message: string;
  message_type: 'chat' | 'purchase' | 'join' | 'leave' | 'system' | 'question';
  is_pinned: boolean;
  is_highlighted: boolean;
  is_deleted: boolean;
  reactions: Record<string, string[]>;
  reply_to?: string;
  created_at: string;
}

export interface BannedUser {
  id: string;
  stream_id: string;
  user_id: string;
  banned_by: string;
  reason?: string;
  banned_until?: string;
  created_at: string;
}

export const useLiveChat = (streamId: string | null, isStreamOwner: boolean = false) => {
  const { user, profile } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [pinnedMessages, setPinnedMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [isBanned, setIsBanned] = useState(false);
  const [bannedUsers, setBannedUsers] = useState<BannedUser[]>([]);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const lastMessageRef = useRef<string | null>(null);

  const quickReactions = ['👍', '❤️', '😂', '😮', '🔥', '👏', '💯', '🎉'];

  // Fetch messages - silently handle errors
  const fetchMessages = useCallback(async (before?: string) => {
    if (!streamId) return;

    try {
      const { data, error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'get_messages', streamId, limit: 50, before }
      });

      if (error || !data?.success) return;

      if (data?.messages && data.messages.length > 0) {
        if (before) {
          setMessages(prev => [...data.messages, ...prev]);
        } else {
          setMessages(data.messages);
          if (data.messages.length > 0) {
            lastMessageRef.current = data.messages[data.messages.length - 1].created_at;
          }
        }
      }

      if (data?.pinnedMessages) {
        setPinnedMessages(data.pinnedMessages);
      }
    } catch (err) {
      // Silently handle
    }
  }, [streamId]);

  // Check if user is banned - silently handle errors
  const checkBanned = useCallback(async () => {
    if (!streamId || !user) return;

    try {
      const { data } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'check_banned', streamId }
      });
      setIsBanned(data?.isBanned || false);
    } catch (err) {
      // Silently handle
    }
  }, [streamId, user]);

  // Fetch banned users - silently handle errors
  const fetchBannedUsers = useCallback(async () => {
    if (!streamId || !isStreamOwner) return;

    try {
      const { data } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'get_banned_users', streamId }
      });
      setBannedUsers(data?.bannedUsers || []);
    } catch (err) {
      // Silently handle
    }
  }, [streamId, isStreamOwner]);

  // Send message
  const sendMessage = useCallback(async (message: string, messageType: string = 'chat'): Promise<boolean> => {
    if (!streamId || !user) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour envoyer un message",
        variant: "destructive"
      });
      return false;
    }

    if (isBanned) {
      toast({
        title: "Vous êtes banni",
        description: "Vous ne pouvez pas envoyer de messages dans ce chat",
        variant: "destructive"
      });
      return false;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'send_message', streamId, message, messageType }
      });

      if (error) throw error;

      if (data?.message) {
        setMessages(prev => [...prev, data.message]);
      }

      return true;
    } catch (err: any) {
      if (err.message?.includes('banned')) {
        setIsBanned(true);
        toast({
          title: "Vous êtes banni",
          description: "Vous ne pouvez pas envoyer de messages dans ce chat",
          variant: "destructive"
        });
      }
      return false;
    }
  }, [streamId, user, isBanned]);

  // Add reaction
  const addReaction = useCallback(async (messageId: string, reaction: string): Promise<boolean> => {
    if (!user) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour réagir",
        variant: "destructive"
      });
      return false;
    }

    try {
      const { data, error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'add_reaction', messageId, reaction }
      });

      if (error) throw error;

      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? { ...msg, reactions: data.reactions } : msg
      ));

      return true;
    } catch (err) {
      return false;
    }
  }, [user]);

  // Pin message
  const pinMessage = useCallback(async (messageId: string): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    try {
      const { error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'pin_message', streamId, messageId }
      });

      if (error) throw error;

      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? { ...msg, is_pinned: true, is_highlighted: true } : msg
      ));

      const pinnedMsg = messages.find(m => m.id === messageId);
      if (pinnedMsg) {
        setPinnedMessages(prev => [...prev, { ...pinnedMsg, is_pinned: true, is_highlighted: true }]);
      }

      toast({ title: "Message épinglé" });
      return true;
    } catch (err) {
      return false;
    }
  }, [streamId, isStreamOwner, messages]);

  // Unpin message
  const unpinMessage = useCallback(async (messageId: string): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    try {
      const { error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'unpin_message', streamId, messageId }
      });

      if (error) throw error;

      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? { ...msg, is_pinned: false, is_highlighted: false } : msg
      ));
      setPinnedMessages(prev => prev.filter(m => m.id !== messageId));

      toast({ title: "Message désépinglé" });
      return true;
    } catch (err) {
      return false;
    }
  }, [streamId, isStreamOwner]);

  // Highlight message
  const highlightMessage = useCallback(async (messageId: string, highlighted: boolean = true): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    try {
      const { error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'highlight_message', streamId, messageId, highlighted }
      });

      if (error) throw error;

      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? { ...msg, is_highlighted: highlighted } : msg
      ));

      return true;
    } catch (err) {
      return false;
    }
  }, [streamId, isStreamOwner]);

  // Delete message
  const deleteMessage = useCallback(async (messageId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'delete_message', messageId }
      });

      if (error) throw error;

      setMessages(prev => prev.filter(m => m.id !== messageId));
      setPinnedMessages(prev => prev.filter(m => m.id !== messageId));

      toast({ title: "Message supprimé" });
      return true;
    } catch (err) {
      return false;
    }
  }, [user]);

  // Ban user
  const banUser = useCallback(async (targetUserId: string, reason?: string, duration?: number): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    try {
      const { error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'ban_user', streamId, targetUserId, reason, duration }
      });

      if (error) throw error;

      toast({
        title: "Utilisateur banni",
        description: duration 
          ? `Banni pour ${duration} minutes`
          : "Banni définitivement"
      });

      await fetchBannedUsers();
      return true;
    } catch (err) {
      return false;
    }
  }, [streamId, isStreamOwner, fetchBannedUsers]);

  // Unban user
  const unbanUser = useCallback(async (targetUserId: string): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    try {
      const { error } = await supabase.functions.invoke('manage-live-chat', {
        body: { action: 'unban_user', streamId, targetUserId }
      });

      if (error) throw error;

      setBannedUsers(prev => prev.filter(u => u.user_id !== targetUserId));
      toast({ title: "Utilisateur débanni" });
      return true;
    } catch (err) {
      return false;
    }
  }, [streamId, isStreamOwner]);

  // Poll for new messages
  useEffect(() => {
    if (!streamId) return;

    fetchMessages();
    checkBanned();

    if (isStreamOwner) {
      fetchBannedUsers();
    }

    pollingRef.current = setInterval(() => {
      fetchMessages();
    }, 3000);

    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    };
  }, [streamId, fetchMessages, checkBanned, isStreamOwner, fetchBannedUsers]);

  // Add system message locally
  const addSystemMessage = useCallback((message: string, type: 'join' | 'leave' | 'system' | 'purchase') => {
    const systemMsg: ChatMessage = {
      id: `system-${Date.now()}`,
      stream_id: streamId || '',
      user_id: 'system',
      user_name: profile?.full_name || 'Utilisateur',
      message,
      message_type: type,
      is_pinned: false,
      is_highlighted: type === 'purchase',
      is_deleted: false,
      reactions: {},
      created_at: new Date().toISOString()
    };
    setMessages(prev => [...prev, systemMsg]);
  }, [streamId, profile]);

  return {
    messages,
    pinnedMessages,
    loading,
    isBanned,
    bannedUsers,
    quickReactions,
    sendMessage,
    addReaction,
    pinMessage,
    unpinMessage,
    highlightMessage,
    deleteMessage,
    banUser,
    unbanUser,
    addSystemMessage,
    fetchMessages
  };
};
