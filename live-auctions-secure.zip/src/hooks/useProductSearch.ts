import { useState, useEffect, useMemo, useCallback } from 'react';
import { Product } from '@/data/mockData';

const RECENT_SEARCHES_KEY = 'pitch_recent_searches';
const MAX_RECENT_SEARCHES = 10;

export interface SearchFilters {
  minPrice: number | null;
  maxPrice: number | null;
  categories: string[];
  minRating: number | null;
  sortBy: 'relevance' | 'price_asc' | 'price_desc' | 'rating' | 'newest';
}

export interface SearchSuggestion {
  type: 'product' | 'category' | 'seller' | 'recent';
  text: string;
  productId?: string;
  image?: string;
}

export const useProductSearch = (products: Product[]) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [filters, setFilters] = useState<SearchFilters>({
    minPrice: null,
    maxPrice: null,
    categories: [],
    minRating: null,
    sortBy: 'relevance',
  });
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Load recent searches from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(RECENT_SEARCHES_KEY);
      if (stored) {
        setRecentSearches(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading recent searches:', error);
    }
  }, []);

  // Save recent searches to localStorage
  const saveRecentSearch = useCallback((query: string) => {
    if (!query.trim()) return;
    
    setRecentSearches(prev => {
      const filtered = prev.filter(s => s.toLowerCase() !== query.toLowerCase());
      const updated = [query, ...filtered].slice(0, MAX_RECENT_SEARCHES);
      try {
        localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error('Error saving recent searches:', error);
      }
      return updated;
    });
  }, []);

  // Clear recent searches
  const clearRecentSearches = useCallback(() => {
    setRecentSearches([]);
    try {
      localStorage.removeItem(RECENT_SEARCHES_KEY);
    } catch (error) {
      console.error('Error clearing recent searches:', error);
    }
  }, []);

  // Remove a single recent search
  const removeRecentSearch = useCallback((query: string) => {
    setRecentSearches(prev => {
      const updated = prev.filter(s => s !== query);
      try {
        localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error('Error removing recent search:', error);
      }
      return updated;
    });
  }, []);

  // Debounce search query
  useEffect(() => {
    setIsSearching(true);
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
      setIsSearching(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Get unique categories from products
  const allCategories = useMemo(() => {
    const categories = new Set(products.map(p => p.category));
    return Array.from(categories).sort();
  }, [products]);

  // Get unique sellers from products
  const allSellers = useMemo(() => {
    const sellers = new Set(products.map(p => p.seller));
    return Array.from(sellers).sort();
  }, [products]);

  // Get price range from products
  const priceRange = useMemo(() => {
    if (products.length === 0) return { min: 0, max: 1000000 };
    const prices = products.map(p => p.price);
    return {
      min: Math.min(...prices),
      max: Math.max(...prices),
    };
  }, [products]);

  // Generate search suggestions
  const suggestions = useMemo((): SearchSuggestion[] => {
    if (!searchQuery.trim()) {
      // Show recent searches when no query
      return recentSearches.map(text => ({
        type: 'recent' as const,
        text,
      }));
    }

    const query = searchQuery.toLowerCase();
    const results: SearchSuggestion[] = [];

    // Add matching products (limit to 5)
    const matchingProducts = products
      .filter(p => 
        p.name.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.seller.toLowerCase().includes(query)
      )
      .slice(0, 5);

    matchingProducts.forEach(p => {
      results.push({
        type: 'product',
        text: p.name,
        productId: p.id,
        image: p.image,
      });
    });

    // Add matching categories
    const matchingCategories = allCategories
      .filter(c => c.toLowerCase().includes(query))
      .slice(0, 3);

    matchingCategories.forEach(c => {
      if (!results.some(r => r.text === c)) {
        results.push({
          type: 'category',
          text: c,
        });
      }
    });

    // Add matching sellers
    const matchingSellers = allSellers
      .filter(s => s.toLowerCase().includes(query))
      .slice(0, 3);

    matchingSellers.forEach(s => {
      if (!results.some(r => r.text === s)) {
        results.push({
          type: 'seller',
          text: s,
        });
      }
    });

    return results.slice(0, 10);
  }, [searchQuery, products, allCategories, allSellers, recentSearches]);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Text search
    if (debouncedQuery.trim()) {
      const query = debouncedQuery.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.seller.toLowerCase().includes(query)
      );
    }

    // Price filter
    if (filters.minPrice !== null) {
      result = result.filter(p => p.price >= filters.minPrice!);
    }
    if (filters.maxPrice !== null) {
      result = result.filter(p => p.price <= filters.maxPrice!);
    }

    // Category filter
    if (filters.categories.length > 0) {
      result = result.filter(p => filters.categories.includes(p.category));
    }

    // Rating filter
    if (filters.minRating !== null) {
      result = result.filter(p => p.rating >= filters.minRating!);
    }

    // Sort
    switch (filters.sortBy) {
      case 'price_asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price_desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        // For mock data, we'll just reverse the order
        result.reverse();
        break;
      case 'relevance':
      default:
        // Keep original order for relevance (or could implement scoring)
        if (debouncedQuery.trim()) {
          const query = debouncedQuery.toLowerCase();
          result.sort((a, b) => {
            const aNameMatch = a.name.toLowerCase().includes(query) ? 2 : 0;
            const bNameMatch = b.name.toLowerCase().includes(query) ? 2 : 0;
            const aCatMatch = a.category.toLowerCase().includes(query) ? 1 : 0;
            const bCatMatch = b.category.toLowerCase().includes(query) ? 1 : 0;
            return (bNameMatch + bCatMatch) - (aNameMatch + aCatMatch);
          });
        }
        break;
    }

    return result;
  }, [products, debouncedQuery, filters]);

  // Update filters
  const updateFilters = useCallback((newFilters: Partial<SearchFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  }, []);

  // Reset filters
  const resetFilters = useCallback(() => {
    setFilters({
      minPrice: null,
      maxPrice: null,
      categories: [],
      minRating: null,
      sortBy: 'relevance',
    });
  }, []);

  // Toggle category filter
  const toggleCategory = useCallback((category: string) => {
    setFilters(prev => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter(c => c !== category)
        : [...prev.categories, category],
    }));
  }, []);

  return {
    searchQuery,
    setSearchQuery,
    debouncedQuery,
    filters,
    updateFilters,
    resetFilters,
    toggleCategory,
    filteredProducts,
    suggestions,
    recentSearches,
    saveRecentSearch,
    clearRecentSearches,
    removeRecentSearch,
    isSearching,
    allCategories,
    allSellers,
    priceRange,
    totalResults: filteredProducts.length,
    hasActiveFilters: 
      filters.minPrice !== null ||
      filters.maxPrice !== null ||
      filters.categories.length > 0 ||
      filters.minRating !== null,
  };
};
