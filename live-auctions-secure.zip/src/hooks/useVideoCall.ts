import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

export interface VideoCall {
  id: string;
  conversation_id: string;
  caller_id: string;
  callee_id: string;
  status: 'pending' | 'ringing' | 'accepted' | 'rejected' | 'ended' | 'missed' | 'busy';
  started_at: string | null;
  ended_at: string | null;
  duration_seconds: number | null;
  created_at: string;
}

interface UseVideoCallOptions {
  conversationId?: string;
  otherUserId?: string;
  otherUserName?: string;
}

// STUN servers for NAT traversal
const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
];

export function useVideoCall(options: UseVideoCallOptions = {}) {
  const { user, profile } = useAuth();
  const { conversationId, otherUserId, otherUserName } = options;

  const [currentCall, setCurrentCall] = useState<VideoCall | null>(null);
  const [incomingCall, setIncomingCall] = useState<VideoCall | null>(null);
  const [callStatus, setCallStatus] = useState<'idle' | 'calling' | 'ringing' | 'connected' | 'ended'>('idle');
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [callDuration, setCallDuration] = useState(0);

  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const signalingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const callCheckIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const pendingCandidatesRef = useRef<RTCIceCandidate[]>([]);
  const currentCallRef = useRef<VideoCall | null>(null);


  // Initialize media stream
  const initializeMedia = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      setLocalStream(stream);
      return stream;
    } catch (err: any) {
      console.error('Failed to get media:', err);
      setError('Impossible d\'accéder à la caméra ou au microphone');
      return null;
    }
  }, []);

  // Create peer connection
  const createPeerConnection = useCallback((stream: MediaStream) => {
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    // Add local tracks
    stream.getTracks().forEach(track => {
      pc.addTrack(track, stream);
    });

    // Handle remote stream
    pc.ontrack = (event) => {
      const [remoteStream] = event.streams;
      setRemoteStream(remoteStream);
    };

    // Handle ICE candidates
    pc.onicecandidate = async (event) => {
      if (event.candidate && currentCall) {
        await sendSignal(currentCall.id, 'ice_candidate', event.candidate.toJSON());
      }
    };

    pc.oniceconnectionstatechange = () => {
      console.log('ICE connection state:', pc.iceConnectionState);
      if (pc.iceConnectionState === 'disconnected' || pc.iceConnectionState === 'failed') {
        // Connection lost
        setError('Connexion perdue');
      }
    };

    peerConnectionRef.current = pc;
    return pc;
  }, [currentCall]);

  // Send signaling data
  const sendSignal = async (callId: string, signalType: string, signalData: any) => {
    if (!user?.id) return;

    try {
      await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'send_signal',
          call_id: callId,
          sender_id: user.id,
          signal_type: signalType,
          signal_data: signalData
        }
      });
    } catch (err) {
      console.error('Failed to send signal:', err);
    }
  };

  // Poll for signaling data
  const pollSignals = useCallback(async (callId: string) => {
    if (!user?.id) return;

    try {
      const { data } = await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'get_signals',
          call_id: callId,
          user_id: user.id
        }
      });

      if (data?.success && data.signals) {
        for (const signal of data.signals) {
          await handleSignal(signal);
        }
      }
    } catch (err) {
      console.error('Failed to poll signals:', err);
    }
  }, [user?.id]);

  // Handle incoming signal
  const handleSignal = async (signal: any) => {
    const pc = peerConnectionRef.current;
    if (!pc) return;

    try {
      if (signal.signal_type === 'offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.signal_data));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        if (currentCall) {
          await sendSignal(currentCall.id, 'answer', answer);
        }
        
        // Process pending candidates
        for (const candidate of pendingCandidatesRef.current) {
          await pc.addIceCandidate(candidate);
        }
        pendingCandidatesRef.current = [];
      } else if (signal.signal_type === 'answer') {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.signal_data));
        
        // Process pending candidates
        for (const candidate of pendingCandidatesRef.current) {
          await pc.addIceCandidate(candidate);
        }
        pendingCandidatesRef.current = [];
      } else if (signal.signal_type === 'ice_candidate') {
        const candidate = new RTCIceCandidate(signal.signal_data);
        if (pc.remoteDescription) {
          await pc.addIceCandidate(candidate);
        } else {
          pendingCandidatesRef.current.push(candidate);
        }
      }
    } catch (err) {
      console.error('Failed to handle signal:', err);
    }
  };

  // Initiate a call
  const initiateCall = useCallback(async () => {
    if (!user?.id || !conversationId || !otherUserId) {
      setError('Informations manquantes pour l\'appel');
      return;
    }

    setCallStatus('calling');
    setError(null);

    try {
      // Initialize media
      const stream = await initializeMedia();
      if (!stream) return;

      // Create call in database
      const { data } = await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'initiate_call',
          conversation_id: conversationId,
          caller_id: user.id,
          callee_id: otherUserId
        }
      });

      if (!data?.success) {
        throw new Error(data?.error || 'Échec de l\'initiation de l\'appel');
      }

      setCurrentCall(data.call);
      setCallStatus('ringing');

      // Create peer connection
      const pc = createPeerConnection(stream);

      // Create and send offer
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await sendSignal(data.call.id, 'offer', offer);

      // Start polling for signals
      signalingIntervalRef.current = setInterval(() => {
        pollSignals(data.call.id);
      }, 1000);

      // Check call status
      callCheckIntervalRef.current = setInterval(async () => {
        const { data: statusData } = await supabase.functions.invoke('manage-video-calls', {
          body: {
            action: 'get_call_status',
            call_id: data.call.id
          }
        });

        if (statusData?.success && statusData.call) {
          setCurrentCall(statusData.call);
          
          if (statusData.call.status === 'accepted') {
            setCallStatus('connected');
            // Start duration timer
            durationIntervalRef.current = setInterval(() => {
              setCallDuration(prev => prev + 1);
            }, 1000);
          } else if (['rejected', 'ended', 'missed'].includes(statusData.call.status)) {
            endCall();
          }
        }
      }, 2000);

    } catch (err: any) {
      console.error('Failed to initiate call:', err);
      setError(err.message);
      setCallStatus('idle');
      cleanup();
    }
  }, [user?.id, conversationId, otherUserId, initializeMedia, createPeerConnection, pollSignals]);

  // Answer incoming call
  const answerCall = useCallback(async (call: VideoCall) => {
    if (!user?.id) return;

    setCallStatus('connected');
    setError(null);
    setIncomingCall(null);

    try {
      // Initialize media
      const stream = await initializeMedia();
      if (!stream) return;

      // Accept call
      const { data } = await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'answer_call',
          call_id: call.id,
          accepted: true
        }
      });

      if (!data?.success) {
        throw new Error('Échec de l\'acceptation de l\'appel');
      }

      setCurrentCall(data.call);

      // Create peer connection
      createPeerConnection(stream);

      // Start polling for signals
      signalingIntervalRef.current = setInterval(() => {
        pollSignals(call.id);
      }, 1000);

      // Start duration timer
      durationIntervalRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);

    } catch (err: any) {
      console.error('Failed to answer call:', err);
      setError(err.message);
      setCallStatus('idle');
      cleanup();
    }
  }, [user?.id, initializeMedia, createPeerConnection, pollSignals]);

  // Reject incoming call
  const rejectCall = useCallback(async (call: VideoCall) => {
    try {
      await supabase.functions.invoke('manage-video-calls', {
        body: {
          action: 'answer_call',
          call_id: call.id,
          accepted: false
        }
      });
      setIncomingCall(null);
    } catch (err) {
      console.error('Failed to reject call:', err);
    }
  }, []);

  // End call
  const endCall = useCallback(async () => {
    if (currentCall) {
      try {
        await supabase.functions.invoke('manage-video-calls', {
          body: {
            action: 'end_call',
            call_id: currentCall.id
          }
        });
      } catch (err) {
        console.error('Failed to end call:', err);
      }
    }

    cleanup();
    setCallStatus('ended');
    setTimeout(() => setCallStatus('idle'), 2000);
  }, [currentCall]);

  // Cleanup resources
  const cleanup = useCallback(() => {
    // Stop intervals
    if (signalingIntervalRef.current) {
      clearInterval(signalingIntervalRef.current);
      signalingIntervalRef.current = null;
    }
    if (callCheckIntervalRef.current) {
      clearInterval(callCheckIntervalRef.current);
      callCheckIntervalRef.current = null;
    }
    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
      durationIntervalRef.current = null;
    }

    // Close peer connection
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    // Stop local stream
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }

    setLocalStream(null);
    setRemoteStream(null);
    setCurrentCall(null);
    setCallDuration(0);
    setIsMuted(false);
    setIsVideoOff(false);
    pendingCandidatesRef.current = [];
  }, [localStream]);

  // Toggle mute
  const toggleMute = useCallback(() => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    }
  }, [localStream]);

  // Toggle video
  const toggleVideo = useCallback(() => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoOff(!videoTrack.enabled);
      }
    }
  }, [localStream]);

  // Check for incoming calls
  useEffect(() => {
    if (!user?.id) return;

    const checkIncomingCalls = async () => {
      try {
        const { data } = await supabase.functions.invoke('manage-video-calls', {
          body: {
            action: 'get_incoming_calls',
            user_id: user.id
          }
        });

        if (data?.success && data.calls && data.calls.length > 0) {
          // Only show if not already in a call
          if (callStatus === 'idle' && !incomingCall) {
            setIncomingCall(data.calls[0]);
          }
        }
      } catch (err) {
        console.error('Failed to check incoming calls:', err);
      }
    };

    const interval = setInterval(checkIncomingCalls, 2000);
    return () => clearInterval(interval);
  }, [user?.id, callStatus, incomingCall]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cleanup();
    };
  }, []);

  // Format call duration
  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return {
    currentCall,
    incomingCall,
    callStatus,
    localStream,
    remoteStream,
    isMuted,
    isVideoOff,
    error,
    callDuration,
    localVideoRef,
    remoteVideoRef,
    initiateCall,
    answerCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleVideo,
    formatDuration,
    setIncomingCall
  };
}
