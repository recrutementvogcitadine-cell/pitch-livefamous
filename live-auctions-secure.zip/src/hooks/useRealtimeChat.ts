import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { RealtimeChannel, RealtimePostgresChangesPayload } from '@supabase/supabase-js';

export interface ChatMessage {
  id: string;
  live_stream_id: string;
  user_id: string;
  user_name: string;
  user_avatar?: string;
  message: string;
  message_type: 'chat' | 'purchase' | 'join' | 'leave' | 'system' | 'question';
  is_pinned: boolean;
  is_highlighted: boolean;
  is_deleted: boolean;
  reactions: Record<string, string[]>;
  reply_to?: string;
  created_at: string;
}

export interface TypingUser {
  user_id: string;
  user_name: string;
  user_avatar?: string;
}

export interface PresentUser {
  user_id: string;
  user_name: string;
  user_avatar?: string;
  status: 'online' | 'away' | 'offline';
  joined_at: string;
}

export interface BannedUser {
  id: string;
  stream_id: string;
  user_id: string;
  banned_by: string;
  reason?: string;
  banned_until?: string;
  created_at: string;
}

export const useRealtimeChat = (streamId: string | null, isStreamOwner: boolean = false) => {
  const { user, profile } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [pinnedMessages, setPinnedMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [isBanned, setIsBanned] = useState(false);
  const [bannedUsers, setBannedUsers] = useState<BannedUser[]>([]);
  const [typingUsers, setTypingUsers] = useState<TypingUser[]>([]);
  const [presentUsers, setPresentUsers] = useState<PresentUser[]>([]);
  const [viewerCount, setViewerCount] = useState(0);
  
  const channelRef = useRef<RealtimeChannel | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const presenceIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const isTypingRef = useRef(false);

  const quickReactions = ['👍', '❤️', '😂', '😮', '🔥', '👏', '💯', '🎉'];

  // Fetch initial messages from database
  // Fetch initial messages from database
  const fetchMessages = useCallback(async () => {
    if (!streamId) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('live_stream_messages')
        .select('*')
        .eq('live_stream_id', streamId)
        .eq('is_deleted', false)
        .order('created_at', { ascending: true })
        .limit(100);

      if (error) {
        // Silently handle errors - table might not exist yet
        console.log('Note: Could not fetch messages, table may not exist');
        setMessages([]);
        return;
      }

      const formattedMessages: ChatMessage[] = (data || []).map(msg => ({
        id: msg.id,
        live_stream_id: msg.live_stream_id,
        user_id: msg.user_id,
        user_name: msg.user_name,
        user_avatar: msg.user_avatar,
        message: msg.message,
        message_type: msg.message_type || 'chat',
        is_pinned: msg.is_pinned || false,
        is_highlighted: msg.is_highlighted || false,
        is_deleted: msg.is_deleted || false,
        reactions: msg.reactions || {},
        reply_to: msg.reply_to,
        created_at: msg.created_at
      }));

      setMessages(formattedMessages);
      setPinnedMessages(formattedMessages.filter(m => m.is_pinned));
    } catch (err) {
      // Silently handle errors
      console.log('Note: Error in fetchMessages, using empty state');
      setMessages([]);
    } finally {
      setLoading(false);
    }
  }, [streamId]);


  // Fetch present users
  const fetchPresentUsers = useCallback(async () => {
    if (!streamId) return;

    try {
      // Get users who were seen in the last 2 minutes
      const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000).toISOString();
      
      const { data, error } = await supabase
        .from('stream_presence')
        .select('*')
        .eq('stream_id', streamId)
        .gte('last_seen_at', twoMinutesAgo);

      if (error) {
        // Silently handle - table may not exist
        setPresentUsers([]);
        setViewerCount(0);
        return;
      }

      const users: PresentUser[] = (data || []).map(p => ({
        user_id: p.user_id,
        user_name: p.user_name,
        user_avatar: p.user_avatar,
        status: p.status,
        joined_at: p.joined_at
      }));

      setPresentUsers(users);
      setViewerCount(users.length);
    } catch (err) {
      // Silently handle errors
      setPresentUsers([]);
      setViewerCount(0);
    }
  }, [streamId]);


  // Update user presence (heartbeat)
  const updatePresence = useCallback(async () => {
    if (!streamId || !user || !profile) return;

    try {
      const { error } = await supabase
        .from('stream_presence')
        .upsert({
          stream_id: streamId,
          user_id: user.id,
          user_name: profile.full_name || 'Anonymous',
          user_avatar: profile.avatar_url,
          status: 'online',
          last_seen_at: new Date().toISOString()
        }, {
          onConflict: 'stream_id,user_id'
        });

      if (error) throw error;
    } catch (err) {
      console.error('Error updating presence:', err);
    }
  }, [streamId, user, profile]);

  // Leave presence
  const leavePresence = useCallback(async () => {
    if (!streamId || !user) return;

    try {
      await supabase
        .from('stream_presence')
        .delete()
        .eq('stream_id', streamId)
        .eq('user_id', user.id);
    } catch (err) {
      console.error('Error leaving presence:', err);
    }
  }, [streamId, user]);

  // Set typing indicator
  const setTyping = useCallback(async (isTyping: boolean) => {
    if (!streamId || !user || !profile) return;

    // Prevent duplicate updates
    if (isTypingRef.current === isTyping) return;
    isTypingRef.current = isTyping;

    try {
      if (isTyping) {
        await supabase
          .from('stream_typing_indicators')
          .upsert({
            stream_id: streamId,
            user_id: user.id,
            user_name: profile.full_name || 'Anonymous',
            user_avatar: profile.avatar_url,
            is_typing: true,
            updated_at: new Date().toISOString()
          }, {
            onConflict: 'stream_id,user_id'
          });

        // Auto-clear typing after 3 seconds
        if (typingTimeoutRef.current) {
          clearTimeout(typingTimeoutRef.current);
        }
        typingTimeoutRef.current = setTimeout(() => {
          setTyping(false);
        }, 3000);
      } else {
        await supabase
          .from('stream_typing_indicators')
          .delete()
          .eq('stream_id', streamId)
          .eq('user_id', user.id);
      }
    } catch (err) {
      console.error('Error setting typing:', err);
    }
  }, [streamId, user, profile]);

  // Fetch typing users
  const fetchTypingUsers = useCallback(async () => {
    if (!streamId) return;

    try {
      const threeSecondsAgo = new Date(Date.now() - 3000).toISOString();
      
      const { data, error } = await supabase
        .from('stream_typing_indicators')
        .select('*')
        .eq('stream_id', streamId)
        .eq('is_typing', true)
        .gte('updated_at', threeSecondsAgo);

      if (error) {
        // Silently handle - table may not exist
        setTypingUsers([]);
        return;
      }

      const users: TypingUser[] = (data || [])
        .filter(t => t.user_id !== user?.id)
        .map(t => ({
          user_id: t.user_id,
          user_name: t.user_name,
          user_avatar: t.user_avatar
        }));

      setTypingUsers(users);
    } catch (err) {
      // Silently handle errors
      setTypingUsers([]);
    }
  }, [streamId, user?.id]);


  // Send message
  const sendMessage = useCallback(async (message: string, messageType: string = 'chat'): Promise<boolean> => {
    if (!streamId || !user || !profile) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour envoyer un message",
        variant: "destructive"
      });
      return false;
    }

    if (isBanned) {
      toast({
        title: "Vous êtes banni",
        description: "Vous ne pouvez pas envoyer de messages dans ce chat",
        variant: "destructive"
      });
      return false;
    }

    try {
      // Clear typing indicator
      setTyping(false);

      const newMessage = {
        live_stream_id: streamId,
        user_id: user.id,
        user_name: profile.full_name || 'Anonymous',
        user_avatar: profile.avatar_url,
        message: message.trim(),
        message_type: messageType,
        is_pinned: false,
        is_highlighted: false,
        is_deleted: false,
        reactions: {}
      };

      const { data, error } = await supabase
        .from('live_stream_messages')
        .insert(newMessage)
        .select()
        .single();

      if (error) throw error;

      // Message will be added via realtime subscription
      return true;
    } catch (err: any) {
      console.error('Error sending message:', err);
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer le message",
        variant: "destructive"
      });
      return false;
    }
  }, [streamId, user, profile, isBanned, setTyping]);

  // Add reaction to message
  const addReaction = useCallback(async (messageId: string, reaction: string): Promise<boolean> => {
    if (!user) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour réagir",
        variant: "destructive"
      });
      return false;
    }

    try {
      // Get current message
      const { data: msgData, error: fetchError } = await supabase
        .from('live_stream_messages')
        .select('reactions')
        .eq('id', messageId)
        .single();

      if (fetchError) throw fetchError;

      const currentReactions = msgData?.reactions || {};
      const reactionUsers = currentReactions[reaction] || [];
      
      // Toggle reaction
      let newReactionUsers: string[];
      if (reactionUsers.includes(user.id)) {
        newReactionUsers = reactionUsers.filter((id: string) => id !== user.id);
      } else {
        newReactionUsers = [...reactionUsers, user.id];
      }

      const newReactions = {
        ...currentReactions,
        [reaction]: newReactionUsers
      };

      // Remove empty reaction arrays
      if (newReactionUsers.length === 0) {
        delete newReactions[reaction];
      }

      const { error } = await supabase
        .from('live_stream_messages')
        .update({ reactions: newReactions })
        .eq('id', messageId);

      if (error) throw error;

      return true;
    } catch (err) {
      console.error('Error adding reaction:', err);
      return false;
    }
  }, [user]);

  // Pin message
  const pinMessage = useCallback(async (messageId: string): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    try {
      const { error } = await supabase
        .from('live_stream_messages')
        .update({ is_pinned: true, is_highlighted: true })
        .eq('id', messageId);

      if (error) throw error;

      toast({ title: "Message épinglé" });
      return true;
    } catch (err) {
      console.error('Error pinning message:', err);
      return false;
    }
  }, [streamId, isStreamOwner]);

  // Unpin message
  const unpinMessage = useCallback(async (messageId: string): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    try {
      const { error } = await supabase
        .from('live_stream_messages')
        .update({ is_pinned: false, is_highlighted: false })
        .eq('id', messageId);

      if (error) throw error;

      toast({ title: "Message désépinglé" });
      return true;
    } catch (err) {
      console.error('Error unpinning message:', err);
      return false;
    }
  }, [streamId, isStreamOwner]);

  // Highlight message
  const highlightMessage = useCallback(async (messageId: string, highlighted: boolean = true): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    try {
      const { error } = await supabase
        .from('live_stream_messages')
        .update({ is_highlighted: highlighted })
        .eq('id', messageId);

      if (error) throw error;

      return true;
    } catch (err) {
      console.error('Error highlighting message:', err);
      return false;
    }
  }, [streamId, isStreamOwner]);

  // Delete message
  const deleteMessage = useCallback(async (messageId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('live_stream_messages')
        .update({ is_deleted: true })
        .eq('id', messageId);

      if (error) throw error;

      toast({ title: "Message supprimé" });
      return true;
    } catch (err) {
      console.error('Error deleting message:', err);
      return false;
    }
  }, [user]);

  // Ban user (simplified - stores in local state for now)
  const banUser = useCallback(async (targetUserId: string, reason?: string, duration?: number): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    const newBan: BannedUser = {
      id: `ban-${Date.now()}`,
      stream_id: streamId,
      user_id: targetUserId,
      banned_by: user?.id || '',
      reason,
      banned_until: duration ? new Date(Date.now() + duration * 60 * 1000).toISOString() : undefined,
      created_at: new Date().toISOString()
    };

    setBannedUsers(prev => [...prev, newBan]);
    
    toast({
      title: "Utilisateur banni",
      description: duration ? `Banni pour ${duration} minutes` : "Banni définitivement"
    });

    return true;
  }, [streamId, isStreamOwner, user?.id]);

  // Unban user
  const unbanUser = useCallback(async (targetUserId: string): Promise<boolean> => {
    if (!streamId || !isStreamOwner) return false;

    setBannedUsers(prev => prev.filter(u => u.user_id !== targetUserId));
    toast({ title: "Utilisateur débanni" });
    return true;
  }, [streamId, isStreamOwner]);

  // Add system message
  const addSystemMessage = useCallback((message: string, type: 'join' | 'leave' | 'system' | 'purchase') => {
    const systemMsg: ChatMessage = {
      id: `system-${Date.now()}`,
      live_stream_id: streamId || '',
      user_id: 'system',
      user_name: profile?.full_name || 'Utilisateur',
      message,
      message_type: type,
      is_pinned: false,
      is_highlighted: type === 'purchase',
      is_deleted: false,
      reactions: {},
      created_at: new Date().toISOString()
    };
    setMessages(prev => [...prev, systemMsg]);
  }, [streamId, profile]);

  // Set up realtime subscription
  useEffect(() => {
    if (!streamId) return;

    // Fetch initial data
    fetchMessages();
    fetchPresentUsers();
    fetchTypingUsers();

    // Update presence immediately if logged in
    if (user) {
      updatePresence();
      
      // Set up presence heartbeat every 30 seconds
      presenceIntervalRef.current = setInterval(() => {
        updatePresence();
        fetchPresentUsers();
        fetchTypingUsers();
      }, 30000);
    }

    // Subscribe to realtime changes for messages
    const channel = supabase
      .channel(`stream-chat-${streamId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'live_stream_messages',
          filter: `live_stream_id=eq.${streamId}`
        },
        (payload: RealtimePostgresChangesPayload<any>) => {
          const newMsg = payload.new as any;
          if (newMsg && !newMsg.is_deleted) {
            const formattedMsg: ChatMessage = {
              id: newMsg.id,
              live_stream_id: newMsg.live_stream_id,
              user_id: newMsg.user_id,
              user_name: newMsg.user_name,
              user_avatar: newMsg.user_avatar,
              message: newMsg.message,
              message_type: newMsg.message_type || 'chat',
              is_pinned: newMsg.is_pinned || false,
              is_highlighted: newMsg.is_highlighted || false,
              is_deleted: newMsg.is_deleted || false,
              reactions: newMsg.reactions || {},
              reply_to: newMsg.reply_to,
              created_at: newMsg.created_at
            };
            
            setMessages(prev => {
              // Avoid duplicates
              if (prev.some(m => m.id === formattedMsg.id)) return prev;
              return [...prev, formattedMsg];
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'live_stream_messages',
          filter: `live_stream_id=eq.${streamId}`
        },
        (payload: RealtimePostgresChangesPayload<any>) => {
          const updatedMsg = payload.new as any;
          if (updatedMsg) {
            if (updatedMsg.is_deleted) {
              setMessages(prev => prev.filter(m => m.id !== updatedMsg.id));
              setPinnedMessages(prev => prev.filter(m => m.id !== updatedMsg.id));
            } else {
              const formattedMsg: ChatMessage = {
                id: updatedMsg.id,
                live_stream_id: updatedMsg.live_stream_id,
                user_id: updatedMsg.user_id,
                user_name: updatedMsg.user_name,
                user_avatar: updatedMsg.user_avatar,
                message: updatedMsg.message,
                message_type: updatedMsg.message_type || 'chat',
                is_pinned: updatedMsg.is_pinned || false,
                is_highlighted: updatedMsg.is_highlighted || false,
                is_deleted: updatedMsg.is_deleted || false,
                reactions: updatedMsg.reactions || {},
                reply_to: updatedMsg.reply_to,
                created_at: updatedMsg.created_at
              };
              
              setMessages(prev => prev.map(m => m.id === formattedMsg.id ? formattedMsg : m));
              
              // Update pinned messages
              if (formattedMsg.is_pinned) {
                setPinnedMessages(prev => {
                  if (prev.some(m => m.id === formattedMsg.id)) {
                    return prev.map(m => m.id === formattedMsg.id ? formattedMsg : m);
                  }
                  return [...prev, formattedMsg];
                });
              } else {
                setPinnedMessages(prev => prev.filter(m => m.id !== formattedMsg.id));
              }
            }
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'stream_typing_indicators',
          filter: `stream_id=eq.${streamId}`
        },
        () => {
          // Refresh typing users on any change
          fetchTypingUsers();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'stream_presence',
          filter: `stream_id=eq.${streamId}`
        },
        () => {
          // Refresh presence on any change
          fetchPresentUsers();
        }
      )
      .subscribe();

    channelRef.current = channel;

    // Cleanup
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
      }
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      if (presenceIntervalRef.current) {
        clearInterval(presenceIntervalRef.current);
      }
      // Leave presence when unmounting
      if (user) {
        leavePresence();
      }
    };
  }, [streamId, user, fetchMessages, fetchPresentUsers, fetchTypingUsers, updatePresence, leavePresence]);

  return {
    messages,
    pinnedMessages,
    loading,
    isBanned,
    bannedUsers,
    typingUsers,
    presentUsers,
    viewerCount,
    quickReactions,
    sendMessage,
    addReaction,
    pinMessage,
    unpinMessage,
    highlightMessage,
    deleteMessage,
    banUser,
    unbanUser,
    addSystemMessage,
    setTyping,
    fetchMessages
  };
};
