import { useState, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

const isDemoMode = !isSupabaseConfigured;

export interface VideoClip {
  id: string;
  recording_id: string;
  seller_id: string;
  title: string;
  description?: string;
  start_time_seconds: number;
  end_time_seconds: number;
  duration_seconds: number;
  source_url?: string;
  processed_url?: string;
  thumbnail_url?: string;
  aspect_ratio: '16:9' | '9:16' | '1:1' | '4:5';
  export_format: 'mp4' | 'webm' | 'gif';
  resolution: '720p' | '1080p' | '4k';
  status: 'draft' | 'processing' | 'ready' | 'published' | 'failed';
  is_published: boolean;
  publish_date?: string;
  view_count: number;
  share_count: number;
  tags?: string[];
  category?: string;
  created_at: string;
  updated_at: string;
  stream_recordings?: {
    title: string;
    thumbnail_url?: string;
    processed_url?: string;
  };
}

export interface TextOverlay {
  id: string;
  clip_id: string;
  text_content: string;
  start_time_seconds: number;
  end_time_seconds?: number;
  position_x: number;
  position_y: number;
  font_family: string;
  font_size: number;
  font_weight: string;
  font_color: string;
  background_color?: string;
  background_opacity: number;
  text_align: 'left' | 'center' | 'right';
  animation_in: 'none' | 'fade' | 'slide-up' | 'slide-down' | 'zoom' | 'bounce';
  animation_out: 'none' | 'fade' | 'slide-up' | 'slide-down' | 'zoom' | 'bounce';
  animation_duration_ms: number;
  has_shadow: boolean;
  shadow_color: string;
  shadow_blur: number;
  display_order: number;
  created_at: string;
}

// Demo data
const demoClips: VideoClip[] = [
  {
    id: 'demo-clip-1',
    recording_id: 'demo-rec-1',
    seller_id: 'demo-seller-1',
    title: 'Highlight: Nouvelle Robe Printemps',
    description: 'Découvrez notre nouvelle robe de la collection printemps',
    start_time_seconds: 120,
    end_time_seconds: 150,
    duration_seconds: 30,
    source_url: 'https://example.com/video1.mp4',
    processed_url: 'https://example.com/clip1.mp4',
    thumbnail_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=300&fit=crop',
    aspect_ratio: '9:16',
    export_format: 'mp4',
    resolution: '1080p',
    status: 'published',
    is_published: true,
    publish_date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    view_count: 450,
    share_count: 32,
    tags: ['mode', 'printemps', 'robe'],
    category: 'Mode',
    created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    stream_recordings: {
      title: 'Collection Printemps - Mode Femme',
      thumbnail_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=300&fit=crop'
    }
  },
  {
    id: 'demo-clip-2',
    recording_id: 'demo-rec-2',
    seller_id: 'demo-seller-1',
    title: 'iPhone 16 Pro - Unboxing',
    description: 'Le moment du déballage',
    start_time_seconds: 60,
    end_time_seconds: 120,
    duration_seconds: 60,
    source_url: 'https://example.com/video2.mp4',
    thumbnail_url: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400&h=300&fit=crop',
    aspect_ratio: '1:1',
    export_format: 'mp4',
    resolution: '1080p',
    status: 'ready',
    is_published: false,
    view_count: 0,
    share_count: 0,
    tags: ['tech', 'iphone', 'unboxing'],
    category: 'Électronique',
    created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    stream_recordings: {
      title: 'Tech Unboxing - iPhone 16 Pro',
      thumbnail_url: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400&h=300&fit=crop'
    }
  }
];

const demoOverlays: TextOverlay[] = [
  {
    id: 'demo-overlay-1',
    clip_id: 'demo-clip-1',
    text_content: 'NOUVELLE COLLECTION',
    start_time_seconds: 0,
    end_time_seconds: 5,
    position_x: 50,
    position_y: 20,
    font_family: 'Inter',
    font_size: 48,
    font_weight: 'bold',
    font_color: '#FFFFFF',
    background_color: '#8B5CF6',
    background_opacity: 0.8,
    text_align: 'center',
    animation_in: 'slide-down',
    animation_out: 'fade',
    animation_duration_ms: 300,
    has_shadow: true,
    shadow_color: '#000000',
    shadow_blur: 8,
    display_order: 0,
    created_at: new Date().toISOString()
  },
  {
    id: 'demo-overlay-2',
    clip_id: 'demo-clip-1',
    text_content: '-20% avec le code SPRING',
    start_time_seconds: 25,
    end_time_seconds: 30,
    position_x: 50,
    position_y: 80,
    font_family: 'Inter',
    font_size: 32,
    font_weight: 'bold',
    font_color: '#FFFFFF',
    background_color: '#EC4899',
    background_opacity: 0.9,
    text_align: 'center',
    animation_in: 'bounce',
    animation_out: 'fade',
    animation_duration_ms: 500,
    has_shadow: true,
    shadow_color: '#000000',
    shadow_blur: 4,
    display_order: 1,
    created_at: new Date().toISOString()
  }
];

export const useClips = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch all clips for the seller
  const fetchClips = useCallback(async (recordingId?: string, status?: string): Promise<VideoClip[]> => {
    if (isDemoMode) {
      let filtered = [...demoClips];
      if (recordingId) {
        filtered = filtered.filter(c => c.recording_id === recordingId);
      }
      if (status) {
        filtered = filtered.filter(c => c.status === status);
      }
      return filtered;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'get_clips', recordingId, status }
      });

      if (fnError) throw fnError;
      return data?.clips || [];
    } catch (err: any) {
      console.error('Error fetching clips:', err);
      setError(err.message);
      return demoClips;
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch single clip with overlays
  const fetchClip = useCallback(async (clipId: string): Promise<{
    clip: VideoClip | null;
    overlays: TextOverlay[];
  }> => {
    if (isDemoMode) {
      const clip = demoClips.find(c => c.id === clipId) || null;
      const overlays = demoOverlays.filter(o => o.clip_id === clipId);
      return { clip, overlays };
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'get_clip', clipId }
      });

      if (fnError) throw fnError;
      return {
        clip: data?.clip || null,
        overlays: data?.overlays || []
      };
    } catch (err: any) {
      console.error('Error fetching clip:', err);
      setError(err.message);
      return { clip: null, overlays: [] };
    } finally {
      setLoading(false);
    }
  }, []);

  // Create a new clip
  const createClip = useCallback(async (params: {
    recordingId: string;
    title: string;
    description?: string;
    startTime: number;
    endTime: number;
    aspectRatio?: '16:9' | '9:16' | '1:1' | '4:5';
    exportFormat?: 'mp4' | 'webm' | 'gif';
    resolution?: '720p' | '1080p' | '4k';
    tags?: string[];
    category?: string;
  }): Promise<VideoClip | null> => {
    if (isDemoMode) {
      const newClip: VideoClip = {
        id: `demo-clip-${Date.now()}`,
        recording_id: params.recordingId,
        seller_id: 'demo-seller-1',
        title: params.title,
        description: params.description,
        start_time_seconds: params.startTime,
        end_time_seconds: params.endTime,
        duration_seconds: params.endTime - params.startTime,
        aspect_ratio: params.aspectRatio || '16:9',
        export_format: params.exportFormat || 'mp4',
        resolution: params.resolution || '1080p',
        status: 'draft',
        is_published: false,
        view_count: 0,
        share_count: 0,
        tags: params.tags,
        category: params.category,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      return newClip;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'create_clip', ...params }
      });

      if (fnError) throw fnError;
      return data?.clip || null;
    } catch (err: any) {
      console.error('Error creating clip:', err);
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Update clip
  const updateClip = useCallback(async (
    clipId: string,
    updates: Partial<{
      title: string;
      description: string;
      startTime: number;
      endTime: number;
      aspectRatio: '16:9' | '9:16' | '1:1' | '4:5';
      exportFormat: 'mp4' | 'webm' | 'gif';
      resolution: '720p' | '1080p' | '4k';
      tags: string[];
      category: string;
      thumbnailUrl: string;
    }>
  ): Promise<VideoClip | null> => {
    if (isDemoMode) {
      const clip = demoClips.find(c => c.id === clipId);
      if (clip) {
        return { ...clip, ...updates, updated_at: new Date().toISOString() };
      }
      return null;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'update_clip', clipId, ...updates }
      });

      if (fnError) throw fnError;
      return data?.clip || null;
    } catch (err: any) {
      console.error('Error updating clip:', err);
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Delete clip
  const deleteClip = useCallback(async (clipId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'delete_clip', clipId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error deleting clip:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Publish clip
  const publishClip = useCallback(async (clipId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'publish_clip', clipId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error publishing clip:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Unpublish clip
  const unpublishClip = useCallback(async (clipId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'unpublish_clip', clipId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error unpublishing clip:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Process clip (generate the actual video file)
  const processClip = useCallback(async (clipId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'process_clip', clipId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error processing clip:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Add text overlay
  const addTextOverlay = useCallback(async (
    clipId: string,
    overlay: Partial<Omit<TextOverlay, 'id' | 'clip_id' | 'created_at' | 'display_order'>>
  ): Promise<TextOverlay | null> => {
    if (isDemoMode) {
      const newOverlay: TextOverlay = {
        id: `demo-overlay-${Date.now()}`,
        clip_id: clipId,
        text_content: overlay.text_content || 'New Text',
        start_time_seconds: overlay.start_time_seconds || 0,
        end_time_seconds: overlay.end_time_seconds,
        position_x: overlay.position_x || 50,
        position_y: overlay.position_y || 50,
        font_family: overlay.font_family || 'Inter',
        font_size: overlay.font_size || 32,
        font_weight: overlay.font_weight || 'bold',
        font_color: overlay.font_color || '#FFFFFF',
        background_color: overlay.background_color,
        background_opacity: overlay.background_opacity || 0.7,
        text_align: overlay.text_align || 'center',
        animation_in: overlay.animation_in || 'fade',
        animation_out: overlay.animation_out || 'fade',
        animation_duration_ms: overlay.animation_duration_ms || 300,
        has_shadow: overlay.has_shadow ?? true,
        shadow_color: overlay.shadow_color || '#000000',
        shadow_blur: overlay.shadow_blur || 4,
        display_order: demoOverlays.length,
        created_at: new Date().toISOString()
      };
      return newOverlay;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { 
          action: 'add_text_overlay', 
          clipId,
          textContent: overlay.text_content,
          startTime: overlay.start_time_seconds,
          endTime: overlay.end_time_seconds,
          positionX: overlay.position_x,
          positionY: overlay.position_y,
          fontFamily: overlay.font_family,
          fontSize: overlay.font_size,
          fontWeight: overlay.font_weight,
          fontColor: overlay.font_color,
          backgroundColor: overlay.background_color,
          backgroundOpacity: overlay.background_opacity,
          textAlign: overlay.text_align,
          animationIn: overlay.animation_in,
          animationOut: overlay.animation_out,
          animationDuration: overlay.animation_duration_ms,
          hasShadow: overlay.has_shadow,
          shadowColor: overlay.shadow_color,
          shadowBlur: overlay.shadow_blur
        }
      });

      if (fnError) throw fnError;
      return data?.overlay || null;
    } catch (err: any) {
      console.error('Error adding text overlay:', err);
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Update text overlay
  const updateTextOverlay = useCallback(async (
    overlayId: string,
    updates: Partial<Omit<TextOverlay, 'id' | 'clip_id' | 'created_at' | 'display_order'>>
  ): Promise<TextOverlay | null> => {
    if (isDemoMode) {
      const overlay = demoOverlays.find(o => o.id === overlayId);
      if (overlay) {
        return { ...overlay, ...updates };
      }
      return null;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { 
          action: 'update_text_overlay', 
          overlayId,
          textContent: updates.text_content,
          startTime: updates.start_time_seconds,
          endTime: updates.end_time_seconds,
          positionX: updates.position_x,
          positionY: updates.position_y,
          fontFamily: updates.font_family,
          fontSize: updates.font_size,
          fontWeight: updates.font_weight,
          fontColor: updates.font_color,
          backgroundColor: updates.background_color,
          backgroundOpacity: updates.background_opacity,
          textAlign: updates.text_align,
          animationIn: updates.animation_in,
          animationOut: updates.animation_out,
          animationDuration: updates.animation_duration_ms,
          hasShadow: updates.has_shadow,
          shadowColor: updates.shadow_color,
          shadowBlur: updates.shadow_blur
        }
      });

      if (fnError) throw fnError;
      return data?.overlay || null;
    } catch (err: any) {
      console.error('Error updating text overlay:', err);
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Delete text overlay
  const deleteTextOverlay = useCallback(async (overlayId: string): Promise<boolean> => {
    if (isDemoMode) {
      return true;
    }

    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('manage-live-stream', {
        body: { action: 'delete_text_overlay', overlayId }
      });

      if (fnError) throw fnError;
      return data?.success || false;
    } catch (err: any) {
      console.error('Error deleting text overlay:', err);
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    fetchClips,
    fetchClip,
    createClip,
    updateClip,
    deleteClip,
    publishClip,
    unpublishClip,
    processClip,
    addTextOverlay,
    updateTextOverlay,
    deleteTextOverlay
  };
};
