import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider } from "@/contexts/AuthContext";
import { AppProvider } from "@/contexts/AppContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Profile from "./pages/Profile";
import Wishlist from "./pages/Wishlist";
import ResetPassword from "./pages/ResetPassword";
import LiveSchedule from "./pages/LiveSchedule";
import Categories from "./pages/Categories";
import SellerDiscovery from "./pages/SellerDiscovery";
import SellerProfile from "./pages/SellerProfile";
import SellerOrderManagement from "./pages/SellerOrderManagement";
import BuyerOrders from "./pages/BuyerOrders";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";
import LiveTestPage from "./pages/LiveTestPage";
import SystemHealthDashboard from "./pages/SystemHealthDashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <ThemeProvider defaultTheme="light">
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <AppProvider>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/products" element={<Products />} />
                <Route path="/products/:id" element={<ProductDetail />} />
                <Route 
                  path="/profile" 
                  element={
                    <ProtectedRoute>
                      <Profile />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/wishlist" 
                  element={
                    <ProtectedRoute>
                      <Wishlist />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/orders" 
                  element={
                    <ProtectedRoute>
                      <BuyerOrders />
                    </ProtectedRoute>
                  } 
                />
                <Route path="/reset-password" element={<ResetPassword />} />
                <Route path="/live-schedule" element={<LiveSchedule />} />
                <Route path="/live-test" element={<LiveTestPage />} />
                <Route path="/system-health" element={<SystemHealthDashboard />} />
                <Route path="/categories" element={<Categories />} />
                <Route path="/sellers" element={<SellerDiscovery />} />
                <Route path="/seller/:id" element={<SellerProfile />} />
                <Route 
                  path="/seller/orders" 
                  element={
                    <ProtectedRoute>
                      <SellerOrderManagement />
                    </ProtectedRoute>
                  } 
                />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </AppProvider>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
