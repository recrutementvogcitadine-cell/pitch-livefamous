import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  SlidersHorizontal,
  Star, 
  Users, 
  Package, 
  Video, 
  TrendingUp,
  ChevronDown,
  Grid3X3,
  List,
  Sparkles,
  Award,
  Clock,
  Eye,
  ShoppingBag,
  ArrowRight,
  X,
  CheckCircle,
  Play,
  Crown,
  Flame,
  Zap
} from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FollowButton from '@/components/FollowButton';
import { VerificationBadgeCompact } from '@/components/VerificationBadge';
import { formatPrice } from '@/data/mockData';
import AuthModal from '@/components/AuthModal';

// Seller interface
interface Seller {
  id: string;
  name: string;
  avatar: string;
  coverImage: string;
  verified: boolean;
  bio: string;
  category: string;
  followers: number;
  productCount: number;
  rating: number;
  reviewCount: number;
  totalSales: number;
  joinedDate: string;
  isLive: boolean;
  liveViewers?: number;
  recentStreams: {
    id: string;
    title: string;
    thumbnail: string;
    viewers: number;
    isLive: boolean;
  }[];
  topProducts: {
    id: string;
    name: string;
    image: string;
    price: number;
    originalPrice?: number;
  }[];
  badges: string[];
}

// Mock sellers data
const mockSellers: Seller[] = [
  {
    id: 'seller-1',
    name: 'TechStore CI',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200',
    coverImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800',
    verified: true,
    bio: 'Votre partenaire technologique #1 en Côte d\'Ivoire. Smartphones, laptops, accessoires et plus encore!',
    category: 'Électronique',
    followers: 15420,
    productCount: 156,
    rating: 4.8,
    reviewCount: 892,
    totalSales: 3240,
    joinedDate: '2024-03-15',
    isLive: true,
    liveViewers: 1247,
    recentStreams: [
      { id: 's1', title: 'Vente Flash - Samsung Galaxy', thumbnail: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400', viewers: 1247, isLive: true },
      { id: 's2', title: 'Nouveaux iPhone 16', thumbnail: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', viewers: 2100, isLive: false },
    ],
    topProducts: [
      { id: 'p1', name: 'iPhone 15 Pro Max', image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', price: 850000, originalPrice: 950000 },
      { id: 'p2', name: 'Samsung Galaxy S24', image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400', price: 650000 },
      { id: 'p3', name: 'MacBook Pro M3', image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400', price: 1200000 },
    ],
    badges: ['Top Vendeur', 'Livraison Express']
  },
  {
    id: 'seller-2',
    name: 'Awa Fashion',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
    coverImage: 'https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800',
    verified: true,
    bio: 'Mode africaine authentique et moderne. Pagnes wax, boubous, robes sur mesure. Livraison partout en Afrique!',
    category: 'Mode',
    followers: 28750,
    productCount: 324,
    rating: 4.9,
    reviewCount: 1456,
    totalSales: 5680,
    joinedDate: '2023-08-20',
    isLive: true,
    liveViewers: 892,
    recentStreams: [
      { id: 's3', title: 'Collection Wax 2026', thumbnail: 'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=400', viewers: 892, isLive: true },
      { id: 's4', title: 'Robes de Soirée', thumbnail: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400', viewers: 1560, isLive: false },
    ],
    topProducts: [
      { id: 'p4', name: 'Ensemble Wax Traditionnel', image: 'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=400', price: 45000 },
      { id: 'p5', name: 'Robe Africaine Moderne', image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400', price: 65000, originalPrice: 85000 },
      { id: 'p6', name: 'Boubou Homme Premium', image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400', price: 55000 },
    ],
    badges: ['Top Vendeur', 'Qualité Premium', 'Réponse Rapide']
  },
  {
    id: 'seller-3',
    name: 'Beauty Queen',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200',
    coverImage: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800',
    verified: true,
    bio: 'Cosmétiques naturels et bio. Soins de la peau, maquillage, parfums. Beauté africaine sublimée!',
    category: 'Beauté',
    followers: 19800,
    productCount: 245,
    rating: 4.7,
    reviewCount: 876,
    totalSales: 4120,
    joinedDate: '2024-01-10',
    isLive: false,
    recentStreams: [
      { id: 's5', title: 'Routine Skincare', thumbnail: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400', viewers: 1890, isLive: false },
      { id: 's6', title: 'Maquillage Naturel', thumbnail: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400', viewers: 2340, isLive: false },
    ],
    topProducts: [
      { id: 'p7', name: 'Kit Beauté Naturel', image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400', price: 32000 },
      { id: 'p8', name: 'Sérum Anti-âge', image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400', price: 28000, originalPrice: 35000 },
      { id: 'p9', name: 'Palette Maquillage Pro', image: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400', price: 45000 },
    ],
    badges: ['Produits Bio', 'Livraison Gratuite']
  },
  {
    id: 'seller-4',
    name: 'SneakerHead ABJ',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200',
    coverImage: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
    verified: true,
    bio: 'Sneakers authentiques 100% originaux. Nike, Adidas, Jordan, Puma. Le paradis des sneakerheads!',
    category: 'Chaussures',
    followers: 34200,
    productCount: 189,
    rating: 4.9,
    reviewCount: 2134,
    totalSales: 7890,
    joinedDate: '2023-05-12',
    isLive: true,
    liveViewers: 2341,
    recentStreams: [
      { id: 's7', title: 'Nouveautés Nike 2026', thumbnail: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400', viewers: 2341, isLive: true },
      { id: 's8', title: 'Jordan Collection', thumbnail: 'https://images.unsplash.com/photo-1556906781-9a412961c28c?w=400', viewers: 3200, isLive: false },
    ],
    topProducts: [
      { id: 'p10', name: 'Nike Air Max 270', image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400', price: 85000, originalPrice: 110000 },
      { id: 'p11', name: 'Adidas Yeezy Boost', image: 'https://images.unsplash.com/photo-1556906781-9a412961c28c?w=400', price: 180000 },
      { id: 'p12', name: 'Jordan 4 Retro', image: 'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=400', price: 220000 },
    ],
    badges: ['Top Vendeur', '100% Authentique', 'Meilleur Prix']
  },
  {
    id: 'seller-5',
    name: 'Bijoux d\'Or',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200',
    coverImage: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800',
    verified: false,
    bio: 'Bijoux artisanaux ivoiriens. Or, argent, perles africaines. Créations uniques faites main.',
    category: 'Bijoux',
    followers: 8920,
    productCount: 98,
    rating: 4.6,
    reviewCount: 345,
    totalSales: 1560,
    joinedDate: '2024-06-01',
    isLive: false,
    recentStreams: [
      { id: 's9', title: 'Collection Mariage', thumbnail: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400', viewers: 890, isLive: false },
    ],
    topProducts: [
      { id: 'p13', name: 'Collier Perles Africaines', image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=400', price: 28000, originalPrice: 35000 },
      { id: 'p14', name: 'Bracelet Or 18K', image: 'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=400', price: 125000 },
    ],
    badges: ['Fait Main', 'Artisan Local']
  },
  {
    id: 'seller-6',
    name: 'Maison Plus',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200',
    coverImage: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800',
    verified: true,
    bio: 'Électroménager et décoration intérieure. Les meilleures marques aux meilleurs prix!',
    category: 'Maison',
    followers: 12450,
    productCount: 278,
    rating: 4.5,
    reviewCount: 567,
    totalSales: 2340,
    joinedDate: '2024-02-28',
    isLive: false,
    recentStreams: [
      { id: 's10', title: 'Promo Électroménager', thumbnail: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400', viewers: 1089, isLive: false },
    ],
    topProducts: [
      { id: 'p15', name: 'Climatiseur Samsung', image: 'https://images.unsplash.com/photo-1631545806609-35d4ae440431?w=400', price: 420000 },
      { id: 'p16', name: 'Réfrigérateur LG', image: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=400', price: 380000, originalPrice: 450000 },
    ],
    badges: ['Garantie 2 Ans', 'Installation Gratuite']
  },
  {
    id: 'seller-7',
    name: 'Chrono Luxe',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200',
    coverImage: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800',
    verified: true,
    bio: 'Montres de luxe authentiques. Rolex, Omega, Tag Heuer, Casio. Certificat d\'authenticité inclus.',
    category: 'Accessoires',
    followers: 21300,
    productCount: 134,
    rating: 4.8,
    reviewCount: 789,
    totalSales: 3450,
    joinedDate: '2023-11-15',
    isLive: false,
    recentStreams: [
      { id: 's11', title: 'Montres de Luxe', thumbnail: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400', viewers: 1567, isLive: false },
    ],
    topProducts: [
      { id: 'p17', name: 'Casio G-Shock', image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400', price: 75000, originalPrice: 95000 },
      { id: 'p18', name: 'Montre Automatique', image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=400', price: 250000 },
    ],
    badges: ['Authentique', 'Garantie Internationale']
  },
  {
    id: 'seller-8',
    name: 'Auto Style CI',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200',
    coverImage: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800',
    verified: true,
    bio: 'Accessoires auto premium. Pièces détachées, tuning, entretien. Pour les passionnés d\'automobile!',
    category: 'Auto',
    followers: 9870,
    productCount: 312,
    rating: 4.6,
    reviewCount: 423,
    totalSales: 1890,
    joinedDate: '2024-04-20',
    isLive: false,
    recentStreams: [
      { id: 's12', title: 'Accessoires Auto Premium', thumbnail: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400', viewers: 678, isLive: false },
    ],
    topProducts: [
      { id: 'p19', name: 'Kit LED Phares', image: 'https://images.unsplash.com/photo-1489824904134-891ab64532f1?w=400', price: 45000 },
      { id: 'p20', name: 'Housse Siège Premium', image: 'https://images.unsplash.com/photo-1489824904134-891ab64532f1?w=400', price: 35000, originalPrice: 45000 },
    ],
    badges: ['Qualité OEM', 'Expert Auto']
  },
  {
    id: 'seller-9',
    name: 'Gadget World',
    avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=200',
    coverImage: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=800',
    verified: true,
    bio: 'Gadgets high-tech innovants. Drones, écouteurs, smartwatches, accessoires gaming et plus!',
    category: 'Électronique',
    followers: 16780,
    productCount: 267,
    rating: 4.7,
    reviewCount: 934,
    totalSales: 4560,
    joinedDate: '2023-09-10',
    isLive: true,
    liveViewers: 1876,
    recentStreams: [
      { id: 's13', title: 'Gadgets High-Tech 2026', thumbnail: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=400', viewers: 1876, isLive: true },
    ],
    topProducts: [
      { id: 'p21', name: 'AirPods Pro 2', image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=400', price: 180000 },
      { id: 'p22', name: 'DJI Mini 3 Pro', image: 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=400', price: 450000, originalPrice: 520000 },
    ],
    badges: ['Innovation', 'Tech Expert']
  },
  {
    id: 'seller-10',
    name: 'Luxe Bags',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200',
    coverImage: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800',
    verified: true,
    bio: 'Sacs à main designer et accessoires de luxe. Authenticité garantie, style assuré!',
    category: 'Mode',
    followers: 22100,
    productCount: 178,
    rating: 4.8,
    reviewCount: 1123,
    totalSales: 3890,
    joinedDate: '2023-07-25',
    isLive: false,
    recentStreams: [
      { id: 's14', title: 'Collection Sacs Designer', thumbnail: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400', viewers: 923, isLive: false },
    ],
    topProducts: [
      { id: 'p23', name: 'Sac Cuir Italien', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400', price: 95000 },
      { id: 'p24', name: 'Pochette Soirée', image: 'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?w=400', price: 45000, originalPrice: 60000 },
    ],
    badges: ['Luxe', 'Cuir Véritable']
  },
  {
    id: 'seller-11',
    name: 'Parfum Palace',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200',
    coverImage: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=800',
    verified: true,
    bio: 'Parfums originaux grandes marques. Dior, Chanel, Gucci, Tom Ford. Senteurs authentiques!',
    category: 'Beauté',
    followers: 18900,
    productCount: 156,
    rating: 4.9,
    reviewCount: 1567,
    totalSales: 5230,
    joinedDate: '2023-06-18',
    isLive: false,
    recentStreams: [
      { id: 's15', title: 'Parfums Grandes Marques', thumbnail: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=400', viewers: 1456, isLive: false },
    ],
    topProducts: [
      { id: 'p25', name: 'Dior Sauvage', image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=400', price: 85000 },
      { id: 'p26', name: 'Chanel N°5', image: 'https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?w=400', price: 120000, originalPrice: 145000 },
    ],
    badges: ['100% Original', 'Best Seller']
  },
  {
    id: 'seller-12',
    name: 'Sport Elite',
    avatar: 'https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=200',
    coverImage: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800',
    verified: false,
    bio: 'Équipements sportifs professionnels. Fitness, football, basketball, running. Performez!',
    category: 'Sport',
    followers: 7650,
    productCount: 234,
    rating: 4.5,
    reviewCount: 289,
    totalSales: 1230,
    joinedDate: '2024-08-05',
    isLive: false,
    recentStreams: [
      { id: 's16', title: 'Équipements Fitness', thumbnail: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=400', viewers: 456, isLive: false },
    ],
    topProducts: [
      { id: 'p27', name: 'Haltères Réglables', image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400', price: 65000 },
      { id: 'p28', name: 'Tapis Yoga Premium', image: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400', price: 25000, originalPrice: 35000 },
    ],
    badges: ['Nouveau', 'Sport Pro']
  }
];

const categories = [
  { id: 'all', name: 'Toutes', icon: Grid3X3 },
  { id: 'Électronique', name: 'Électronique', icon: Zap },
  { id: 'Mode', name: 'Mode', icon: ShoppingBag },
  { id: 'Beauté', name: 'Beauté', icon: Sparkles },
  { id: 'Maison', name: 'Maison', icon: Package },
  { id: 'Chaussures', name: 'Chaussures', icon: ShoppingBag },
  { id: 'Bijoux', name: 'Bijoux', icon: Award },
  { id: 'Accessoires', name: 'Accessoires', icon: Package },
  { id: 'Auto', name: 'Auto', icon: Package },
  { id: 'Sport', name: 'Sport', icon: TrendingUp },
];

const sortOptions = [
  { id: 'popular', name: 'Plus populaires', icon: TrendingUp },
  { id: 'followers', name: 'Plus de followers', icon: Users },
  { id: 'products', name: 'Plus de produits', icon: Package },
  { id: 'rating', name: 'Mieux notés', icon: Star },
  { id: 'newest', name: 'Plus récents', icon: Clock },
  { id: 'sales', name: 'Plus de ventes', icon: ShoppingBag },
];

const SellerDiscovery: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [headerSearchQuery, setHeaderSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('popular');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [expandedSeller, setExpandedSeller] = useState<string | null>(null);

  // Filter and sort sellers
  const filteredSellers = useMemo(() => {
    let result = [...mockSellers];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(seller => 
        seller.name.toLowerCase().includes(query) ||
        seller.bio.toLowerCase().includes(query) ||
        seller.category.toLowerCase().includes(query)
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      result = result.filter(seller => seller.category === selectedCategory);
    }

    // Sort
    switch (sortBy) {
      case 'popular':
        result.sort((a, b) => (b.followers + b.totalSales) - (a.followers + a.totalSales));
        break;
      case 'followers':
        result.sort((a, b) => b.followers - a.followers);
        break;
      case 'products':
        result.sort((a, b) => b.productCount - a.productCount);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        result.sort((a, b) => new Date(b.joinedDate).getTime() - new Date(a.joinedDate).getTime());
        break;
      case 'sales':
        result.sort((a, b) => b.totalSales - a.totalSales);
        break;
    }

    return result;
  }, [searchQuery, selectedCategory, sortBy]);

  // Featured sellers (top 4 by followers)
  const featuredSellers = useMemo(() => {
    return [...mockSellers]
      .sort((a, b) => b.followers - a.followers)
      .slice(0, 4);
  }, []);

  // Live sellers
  const liveSellers = useMemo(() => {
    return mockSellers.filter(s => s.isLive);
  }, []);

  // New sellers (joined in last 6 months)
  const newSellers = useMemo(() => {
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    return mockSellers
      .filter(s => new Date(s.joinedDate) > sixMonthsAgo)
      .sort((a, b) => new Date(b.joinedDate).getTime() - new Date(a.joinedDate).getTime())
      .slice(0, 4);
  }, []);

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  // Seller Card Component
  const SellerCard: React.FC<{ seller: Seller; expanded?: boolean }> = ({ seller, expanded = false }) => {
    const isExpanded = expandedSeller === seller.id || expanded;

    return (
      <div 
        className={`bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden hover:border-slate-600 transition-all duration-300 ${
          isExpanded ? 'col-span-2 row-span-2' : ''
        }`}
      >
        {/* Cover Image */}
        <div className="relative h-32 overflow-hidden">
          <img 
            src={seller.coverImage} 
            alt={seller.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent" />
          
          {/* Live Badge */}
          {seller.isLive && (
            <div className="absolute top-3 left-3 flex items-center gap-2 px-3 py-1.5 bg-red-500 text-white text-sm font-bold rounded-full animate-pulse">
              <span className="w-2 h-2 bg-white rounded-full" />
              EN DIRECT
              {seller.liveViewers && (
                <span className="flex items-center gap-1 ml-1">
                  <Eye className="w-3 h-3" />
                  {formatNumber(seller.liveViewers)}
                </span>
              )}
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-3 right-3 flex flex-wrap gap-1.5 justify-end max-w-[60%]">
            {seller.badges.slice(0, 2).map((badge, idx) => (
              <span 
                key={idx}
                className="px-2 py-1 bg-slate-900/80 backdrop-blur-sm text-xs text-slate-300 rounded-full"
              >
                {badge}
              </span>
            ))}
          </div>

          {/* Avatar */}
          <div className="absolute -bottom-8 left-4">
            <div className="relative">
              <img 
                src={seller.avatar} 
                alt={seller.name}
                className="w-16 h-16 rounded-xl object-cover border-4 border-slate-800"
              />
              {seller.verified && (
                <div className="absolute -bottom-1 -right-1">
                  <VerificationBadgeCompact verified={true} />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="pt-10 px-4 pb-4">
          {/* Header */}
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1 min-w-0">
              <h3 className="text-white font-bold text-lg truncate">{seller.name}</h3>
              <p className="text-slate-400 text-sm">{seller.category}</p>
            </div>
            <FollowButton 
              sellerId={seller.id}
              sellerName={seller.name}
              variant="compact"
              onAuthRequired={() => setShowAuthModal(true)}
            />
          </div>

          {/* Bio */}
          <p className="text-slate-400 text-sm mb-4 line-clamp-2">{seller.bio}</p>

          {/* Stats */}
          <div className="grid grid-cols-4 gap-2 mb-4">
            <div className="text-center p-2 bg-slate-700/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 text-white font-bold">
                <Users className="w-3.5 h-3.5 text-purple-400" />
                {formatNumber(seller.followers)}
              </div>
              <p className="text-slate-500 text-xs">Abonnés</p>
            </div>
            <div className="text-center p-2 bg-slate-700/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 text-white font-bold">
                <Package className="w-3.5 h-3.5 text-blue-400" />
                {seller.productCount}
              </div>
              <p className="text-slate-500 text-xs">Produits</p>
            </div>
            <div className="text-center p-2 bg-slate-700/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 text-white font-bold">
                <Star className="w-3.5 h-3.5 text-yellow-400" />
                {seller.rating}
              </div>
              <p className="text-slate-500 text-xs">Note</p>
            </div>
            <div className="text-center p-2 bg-slate-700/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 text-white font-bold">
                <ShoppingBag className="w-3.5 h-3.5 text-green-400" />
                {formatNumber(seller.totalSales)}
              </div>
              <p className="text-slate-500 text-xs">Ventes</p>
            </div>
          </div>

          {/* Recent Stream */}
          {seller.recentStreams.length > 0 && (
            <div className="mb-4">
              <p className="text-slate-400 text-xs font-medium mb-2 flex items-center gap-1">
                <Video className="w-3.5 h-3.5" />
                {seller.isLive ? 'Live en cours' : 'Dernier live'}
              </p>
              <div className="relative rounded-lg overflow-hidden group cursor-pointer">
                <img 
                  src={seller.recentStreams[0].thumbnail}
                  alt={seller.recentStreams[0].title}
                  className="w-full h-20 object-cover"
                />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Play className="w-8 h-8 text-white" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                  <p className="text-white text-xs font-medium truncate">{seller.recentStreams[0].title}</p>
                </div>
                {seller.recentStreams[0].isLive && (
                  <div className="absolute top-2 left-2 px-2 py-0.5 bg-red-500 text-white text-xs font-bold rounded">
                    LIVE
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Top Products */}
          <div>
            <p className="text-slate-400 text-xs font-medium mb-2 flex items-center gap-1">
              <ShoppingBag className="w-3.5 h-3.5" />
              Produits populaires
            </p>
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {seller.topProducts.slice(0, 3).map(product => (
                <div 
                  key={product.id}
                  className="flex-shrink-0 w-20 cursor-pointer group"
                >
                  <div className="relative rounded-lg overflow-hidden mb-1">
                    <img 
                      src={product.image}
                      alt={product.name}
                      className="w-20 h-20 object-cover group-hover:scale-110 transition-transform"
                    />
                    {product.originalPrice && (
                      <div className="absolute top-1 right-1 px-1.5 py-0.5 bg-red-500 text-white text-[10px] font-bold rounded">
                        -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                      </div>
                    )}
                  </div>
                  <p className="text-white text-xs font-medium truncate">{formatPrice(product.price)}</p>
                </div>
              ))}
            </div>
          </div>

          {/* View Profile Button */}
          <button 
            onClick={() => navigate(`/seller/${seller.id}`)}
            className="w-full mt-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-white text-sm font-medium rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            Voir le profil
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  };


  return (
    <div className="min-h-screen bg-slate-900">
      <Header 
        onAuthClick={() => setShowAuthModal(true)}
        searchQuery={headerSearchQuery}
        onSearchChange={setHeaderSearchQuery}
      />

      <main className="pt-24 pb-16">
        {/* Hero Section */}
        <section className="relative py-12 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 via-slate-900 to-pink-900/30" />
          <div className="absolute inset-0">
            <div className="absolute top-20 left-20 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl" />
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-500/20 border border-purple-500/30 rounded-full text-purple-300 text-sm font-medium mb-4">
                <Users className="w-4 h-4" />
                {mockSellers.length} vendeurs à découvrir
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                Découvrez nos <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">Vendeurs</span>
              </h1>
              <p className="text-xl text-slate-400 max-w-2xl mx-auto">
                Explorez notre communauté de vendeurs vérifiés et trouvez vos favoris
              </p>
            </div>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto">
              <div className="relative">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-400" />
                <input
                  type="text"
                  placeholder="Rechercher un vendeur, une catégorie..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-14 pr-5 py-4 bg-slate-800/80 backdrop-blur-sm border border-slate-700 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent text-lg"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="flex flex-wrap justify-center gap-6 mt-8">
              <div className="flex items-center gap-2 text-slate-400">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                <span className="font-medium">{liveSellers.length} vendeurs en live</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <CheckCircle className="w-4 h-4 text-blue-400" />
                <span className="font-medium">{mockSellers.filter(s => s.verified).length} vendeurs vérifiés</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Package className="w-4 h-4 text-green-400" />
                <span className="font-medium">{mockSellers.reduce((acc, s) => acc + s.productCount, 0).toLocaleString()} produits</span>
              </div>
            </div>
          </div>
        </section>

        {/* Live Sellers Section */}
        {liveSellers.length > 0 && (
          <section className="py-8 border-b border-slate-800">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="flex items-center gap-2 px-4 py-2 bg-red-500/20 rounded-full">
                  <span className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                  <span className="text-red-400 font-bold">EN DIRECT</span>
                </div>
                <h2 className="text-2xl font-bold text-white">Vendeurs en Live</h2>
              </div>

              <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
                {liveSellers.map(seller => (
                  <div 
                    key={seller.id}
                    className="flex-shrink-0 w-72 bg-slate-800/50 border border-red-500/30 rounded-xl overflow-hidden hover:border-red-500/50 transition-all cursor-pointer group"
                  >
                    <div className="relative">
                      <img 
                        src={seller.recentStreams[0]?.thumbnail || seller.coverImage}
                        alt={seller.name}
                        className="w-full h-40 object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                      <div className="absolute top-3 left-3 flex items-center gap-2 px-2.5 py-1 bg-red-500 text-white text-xs font-bold rounded-full">
                        <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                        LIVE
                      </div>
                      <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 bg-black/60 text-white text-xs rounded-full">
                        <Eye className="w-3 h-3" />
                        {formatNumber(seller.liveViewers || 0)}
                      </div>
                      <div className="absolute bottom-3 left-3 flex items-center gap-2">
                        <img 
                          src={seller.avatar}
                          alt={seller.name}
                          className="w-10 h-10 rounded-full border-2 border-red-500"
                        />
                        <div>
                          <div className="flex items-center gap-1">
                            <p className="text-white font-bold text-sm">{seller.name}</p>
                            {seller.verified && <VerificationBadgeCompact verified={true} />}
                          </div>
                          <p className="text-slate-300 text-xs">{seller.recentStreams[0]?.title}</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 flex items-center justify-between">
                      <div className="flex items-center gap-3 text-sm text-slate-400">
                        <span className="flex items-center gap-1">
                          <Users className="w-3.5 h-3.5" />
                          {formatNumber(seller.followers)}
                        </span>
                        <span className="flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 text-yellow-400" />
                          {seller.rating}
                        </span>
                      </div>
                      <button className="px-3 py-1.5 bg-red-500 hover:bg-red-600 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1">
                        <Play className="w-3 h-3" />
                        Regarder
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Featured Sellers */}
        <section className="py-12 border-b border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl">
                <Crown className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white">Top Vendeurs</h2>
              <span className="px-3 py-1 bg-yellow-500/20 text-yellow-400 text-sm font-medium rounded-full">
                Les plus suivis
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {featuredSellers.map((seller, idx) => (
                <div 
                  key={seller.id}
                  className="relative bg-gradient-to-br from-slate-800 to-slate-800/50 border border-slate-700 rounded-2xl p-4 hover:border-yellow-500/30 transition-all group"
                >
                  {/* Rank Badge */}
                  <div className={`absolute -top-2 -left-2 w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                    idx === 0 ? 'bg-gradient-to-br from-yellow-400 to-yellow-600 text-yellow-900' :
                    idx === 1 ? 'bg-gradient-to-br from-slate-300 to-slate-500 text-slate-800' :
                    idx === 2 ? 'bg-gradient-to-br from-orange-400 to-orange-600 text-orange-900' :
                    'bg-slate-700 text-slate-300'
                  }`}>
                    #{idx + 1}
                  </div>

                  <div className="flex items-center gap-3 mb-3">
                    <div className="relative">
                      <img 
                        src={seller.avatar}
                        alt={seller.name}
                        className="w-14 h-14 rounded-xl object-cover"
                      />
                      {seller.isLive && (
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-slate-800 animate-pulse" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-white font-bold truncate">{seller.name}</h3>
                        {seller.verified && <VerificationBadgeCompact verified={true} />}
                      </div>
                      <p className="text-slate-400 text-sm">{seller.category}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm mb-3">
                    <div className="flex items-center gap-1 text-purple-400">
                      <Users className="w-4 h-4" />
                      <span className="font-bold">{formatNumber(seller.followers)}</span>
                    </div>
                    <div className="flex items-center gap-1 text-yellow-400">
                      <Star className="w-4 h-4" />
                      <span className="font-bold">{seller.rating}</span>
                    </div>
                    <div className="flex items-center gap-1 text-green-400">
                      <ShoppingBag className="w-4 h-4" />
                      <span className="font-bold">{formatNumber(seller.totalSales)}</span>
                    </div>
                  </div>

                  <FollowButton 
                    sellerId={seller.id}
                    sellerName={seller.name}
                    variant="compact"
                    className="w-full justify-center"
                    onAuthRequired={() => setShowAuthModal(true)}
                  />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* New Sellers */}
        <section className="py-12 border-b border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white">Nouveaux Vendeurs</h2>
              <span className="px-3 py-1 bg-green-500/20 text-green-400 text-sm font-medium rounded-full">
                À découvrir
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {newSellers.map(seller => (
                <div 
                  key={seller.id}
                  className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 hover:border-green-500/30 transition-all"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <img 
                      src={seller.avatar}
                      alt={seller.name}
                      className="w-12 h-12 rounded-xl object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-white font-bold truncate">{seller.name}</h3>
                        {seller.verified && <VerificationBadgeCompact verified={true} />}
                      </div>
                      <p className="text-slate-400 text-sm">{seller.category}</p>
                    </div>
                    <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs font-medium rounded-full">
                      Nouveau
                    </span>
                  </div>

                  <p className="text-slate-400 text-sm mb-3 line-clamp-2">{seller.bio}</p>

                  <div className="flex items-center gap-4 text-sm text-slate-400 mb-3">
                    <span className="flex items-center gap-1">
                      <Package className="w-4 h-4" />
                      {seller.productCount} produits
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400" />
                      {seller.rating}
                    </span>
                  </div>

                  <FollowButton 
                    sellerId={seller.id}
                    sellerName={seller.name}
                    variant="compact"
                    className="w-full justify-center"
                    onAuthRequired={() => setShowAuthModal(true)}
                  />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* All Sellers Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Filters Header */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
              <div className="flex items-center gap-3">
                <h2 className="text-2xl font-bold text-white">Tous les Vendeurs</h2>
                <span className="px-3 py-1 bg-slate-700 text-slate-300 text-sm font-medium rounded-full">
                  {filteredSellers.length} résultats
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {/* Category Filter */}
                <div className="relative">
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="appearance-none pl-4 pr-10 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 cursor-pointer"
                  >
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                </div>

                {/* Sort Filter */}
                <div className="relative">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="appearance-none pl-4 pr-10 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 cursor-pointer"
                  >
                    {sortOptions.map(opt => (
                      <option key={opt.id} value={opt.id}>{opt.name}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                </div>

                {/* View Mode Toggle */}
                <div className="flex items-center bg-slate-800 border border-slate-700 rounded-xl p-1">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 rounded-lg transition-colors ${
                      viewMode === 'grid' ? 'bg-purple-500 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Grid3X3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 rounded-lg transition-colors ${
                      viewMode === 'list' ? 'bg-purple-500 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Category Pills */}
            <div className="flex flex-wrap gap-2 mb-8">
              {categories.map(cat => {
                const Icon = cat.icon;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                      selectedCategory === cat.id
                        ? 'bg-purple-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {cat.name}
                  </button>
                );
              })}
            </div>

            {/* Sellers Grid */}
            {filteredSellers.length > 0 ? (
              <div className={`grid gap-6 ${
                viewMode === 'grid' 
                  ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
                  : 'grid-cols-1'
              }`}>
                {filteredSellers.map(seller => (
                  <SellerCard key={seller.id} seller={seller} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-10 h-10 text-slate-600" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Aucun vendeur trouvé</h3>
                <p className="text-slate-400 mb-4">
                  Essayez de modifier vos filtres ou votre recherche
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                  }}
                  className="px-6 py-3 bg-purple-500 hover:bg-purple-600 text-white font-medium rounded-xl transition-colors"
                >
                  Réinitialiser les filtres
                </button>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />
    </div>
  );
};

export default SellerDiscovery;
