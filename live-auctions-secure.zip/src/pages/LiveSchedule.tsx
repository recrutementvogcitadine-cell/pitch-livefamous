import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar, Clock, Search, Filter, Bell, BellRing, Users, Sparkles, CalendarDays, ArrowLeft, Settings } from 'lucide-react';
import { ScheduledStreamCard } from '@/components/ScheduledStreamCard';
import { ScheduleStreamModal } from '@/components/ScheduleStreamModal';
import { NotificationSettings } from '@/components/NotificationSettings';
import { useScheduledStreams, ScheduledStream } from '@/hooks/useScheduledStreams';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useAuth } from '@/contexts/AuthContext';
import { Link } from 'react-router-dom';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

const CATEGORIES = [
  'Tous',
  'Mode & Vêtements',
  'Beauté & Cosmétiques',
  'Électronique',
  'Maison & Déco',
  'Sport & Fitness',
  'Bijoux & Accessoires',
  'Art & Artisanat',
  'Alimentation'
];

export default function LiveSchedule() {
  const { user, isSeller } = useAuth();
  const { 
    upcomingStreams, 
    followedStreams, 
    userReminders,
    loading, 
    fetchUpcomingStreams, 
    fetchFollowedStreams,
    fetchUserReminders 
  } = useScheduledStreams();
  const { isSubscribed, permission } = usePushNotifications();

  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tous');
  const [sortBy, setSortBy] = useState<'date' | 'popular'>('date');
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [isNotificationSettingsOpen, setIsNotificationSettingsOpen] = useState(false);

  useEffect(() => {
    fetchUpcomingStreams(50);
    if (user?.id) {
      fetchFollowedStreams(user.id, 50);
      fetchUserReminders(user.id);
    }
  }, [user?.id, fetchUpcomingStreams, fetchFollowedStreams, fetchUserReminders]);

  const refreshData = () => {
    fetchUpcomingStreams(50);
    if (user?.id) {
      fetchFollowedStreams(user.id, 50);
      fetchUserReminders(user.id);
    }
  };

  // Filter and sort streams
  const filterStreams = (streams: ScheduledStream[]) => {
    let filtered = streams;

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(stream => 
        stream.title.toLowerCase().includes(query) ||
        stream.description?.toLowerCase().includes(query) ||
        stream.seller?.name?.toLowerCase().includes(query) ||
        stream.tags?.some(tag => tag.toLowerCase().includes(query))
      );
    }

    // Category filter
    if (selectedCategory !== 'Tous') {
      filtered = filtered.filter(stream => stream.category === selectedCategory);
    }

    // Sort
    if (sortBy === 'date') {
      filtered.sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());
    } else {
      filtered.sort((a, b) => (b.viewer_count_estimate || 0) - (a.viewer_count_estimate || 0));
    }

    return filtered;
  };

  const displayedStreams = activeTab === 'followed' 
    ? filterStreams(followedStreams) 
    : activeTab === 'reminders'
    ? filterStreams(userReminders.map(r => r.scheduled_streams!).filter(Boolean))
    : filterStreams(upcomingStreams);

  // Group streams by date
  const groupStreamsByDate = (streams: ScheduledStream[]) => {
    const groups: { [key: string]: ScheduledStream[] } = {};
    
    streams.forEach(stream => {
      const date = new Date(stream.scheduled_at);
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      let dateKey: string;
      if (date.toDateString() === today.toDateString()) {
        dateKey = "Aujourd'hui";
      } else if (date.toDateString() === tomorrow.toDateString()) {
        dateKey = "Demain";
      } else {
        dateKey = date.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
      }
      
      if (!groups[dateKey]) {
        groups[dateKey] = [];
      }
      groups[dateKey].push(stream);
    });
    
    return groups;
  };

  const groupedStreams = groupStreamsByDate(displayedStreams);

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 via-white to-pink-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 text-white">
        <div className="absolute inset-0 bg-black/20" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yIDItNCAyLTRzLTItMi00LTItNCAwLTQgMiAwIDIgMiA0IDIgNHMtMiAyLTQgMi00IDAtNCAyIDAgMiAyIDQgMiA0IDItMiA0LTIgNC0yIDAtMi0yLTQtMi00eiIvPjwvZz48L2c+PC9zdmc+')] opacity-30" />
        
        <div className="relative max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
          <Link to="/" className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Retour à l'accueil
          </Link>
          
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-center lg:text-left">
              <div className="flex items-center justify-center lg:justify-start gap-3 mb-4">
                <CalendarDays className="w-10 h-10" />
                <h1 className="text-4xl md:text-5xl font-bold">Programme des Lives</h1>
              </div>
              <p className="text-xl text-white/90 max-w-2xl">
                Découvrez les prochains lives de vos vendeurs préférés et ne manquez aucun événement
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              {isSeller && (
                <Button 
                  size="lg"
                  onClick={() => setIsScheduleModalOpen(true)}
                  className="bg-white text-purple-600 hover:bg-white/90 shadow-xl"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Programmer un live
                </Button>
              )}
              
              {/* Notification Settings Button */}
              {user && (
                <Sheet open={isNotificationSettingsOpen} onOpenChange={setIsNotificationSettingsOpen}>
                  <SheetTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="lg"
                      className="bg-white/10 border-white/30 text-white hover:bg-white/20"
                    >
                      <Bell className={`w-5 h-5 mr-2 ${isSubscribed ? 'text-green-300' : ''}`} />
                      {isSubscribed ? 'Notifications actives' : 'Activer les notifications'}
                    </Button>
                  </SheetTrigger>
                  <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
                    <SheetHeader>
                      <SheetTitle>Paramètres de notification</SheetTitle>
                      <SheetDescription>
                        Configurez vos préférences de notification pour ne jamais manquer un live
                      </SheetDescription>
                    </SheetHeader>
                    <div className="mt-6">
                      <NotificationSettings />
                    </div>
                  </SheetContent>
                </Sheet>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-12 max-w-2xl mx-auto lg:mx-0">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold">{upcomingStreams.length}</div>
              <div className="text-sm text-white/80">Lives à venir</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold">{followedStreams.length}</div>
              <div className="text-sm text-white/80">De vos abonnements</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold">{userReminders.length}</div>
              <div className="text-sm text-white/80">Rappels actifs</div>
            </div>
          </div>
        </div>
      </div>



      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Filters */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Rechercher un live, vendeur ou tag..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full lg:w-[200px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Catégorie" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={sortBy} onValueChange={(v: 'date' | 'popular') => setSortBy(v)}>
              <SelectTrigger className="w-full lg:w-[180px]">
                <SelectValue placeholder="Trier par" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Date (proche)</SelectItem>
                <SelectItem value="popular">Popularité</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-white dark:bg-gray-800 p-1 rounded-xl shadow-md">
            <TabsTrigger value="all" className="rounded-lg px-6">
              <Calendar className="w-4 h-4 mr-2" />
              Tous les lives
            </TabsTrigger>
            <TabsTrigger value="followed" className="rounded-lg px-6" disabled={!user}>
              <Users className="w-4 h-4 mr-2" />
              Mes abonnements
              {followedStreams.length > 0 && (
                <Badge className="ml-2 bg-purple-100 text-purple-700">{followedStreams.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="reminders" className="rounded-lg px-6" disabled={!user}>
              <BellRing className="w-4 h-4 mr-2" />
              Mes rappels
              {userReminders.length > 0 && (
                <Badge className="ml-2 bg-pink-100 text-pink-700">{userReminders.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-8">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <div className="aspect-video bg-gray-200 dark:bg-gray-700" />
                    <CardContent className="p-4 space-y-3">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : displayedStreams.length === 0 ? (
              <div className="text-center py-16">
                <CalendarDays className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">Aucun live programmé</h3>
                <p className="text-muted-foreground mb-6">
                  {searchQuery || selectedCategory !== 'Tous' 
                    ? "Aucun résultat ne correspond à vos critères"
                    : "Il n'y a pas de lives programmés pour le moment"}
                </p>
                {(searchQuery || selectedCategory !== 'Tous') && (
                  <Button variant="outline" onClick={() => { setSearchQuery(''); setSelectedCategory('Tous'); }}>
                    Réinitialiser les filtres
                  </Button>
                )}
              </div>
            ) : (
              Object.entries(groupedStreams).map(([date, streams]) => (
                <div key={date}>
                  <div className="flex items-center gap-3 mb-4">
                    <h2 className="text-xl font-bold capitalize">{date}</h2>
                    <Badge variant="secondary">{streams.length} live{streams.length > 1 ? 's' : ''}</Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {streams.map(stream => (
                      <ScheduledStreamCard 
                        key={stream.id} 
                        stream={stream}
                        onReminderChange={refreshData}
                      />
                    ))}
                  </div>
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="followed" className="space-y-8">
            {!user ? (
              <div className="text-center py-16">
                <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">Connectez-vous</h3>
                <p className="text-muted-foreground">
                  Connectez-vous pour voir les lives de vos vendeurs favoris
                </p>
              </div>
            ) : displayedStreams.length === 0 ? (
              <div className="text-center py-16">
                <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">Aucun live de vos abonnements</h3>
                <p className="text-muted-foreground mb-6">
                  Les vendeurs que vous suivez n'ont pas encore programmé de lives
                </p>
                <Link to="/">
                  <Button>Découvrir des vendeurs</Button>
                </Link>
              </div>
            ) : (
              Object.entries(groupedStreams).map(([date, streams]) => (
                <div key={date}>
                  <div className="flex items-center gap-3 mb-4">
                    <h2 className="text-xl font-bold capitalize">{date}</h2>
                    <Badge variant="secondary">{streams.length} live{streams.length > 1 ? 's' : ''}</Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {streams.map(stream => (
                      <ScheduledStreamCard 
                        key={stream.id} 
                        stream={stream}
                        onReminderChange={refreshData}
                      />
                    ))}
                  </div>
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="reminders" className="space-y-8">
            {!user ? (
              <div className="text-center py-16">
                <Bell className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">Connectez-vous</h3>
                <p className="text-muted-foreground">
                  Connectez-vous pour gérer vos rappels
                </p>
              </div>
            ) : displayedStreams.length === 0 ? (
              <div className="text-center py-16">
                <Bell className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">Aucun rappel actif</h3>
                <p className="text-muted-foreground mb-6">
                  Activez des rappels sur les lives qui vous intéressent
                </p>
                <Button onClick={() => setActiveTab('all')}>
                  Parcourir les lives
                </Button>
              </div>
            ) : (
              Object.entries(groupedStreams).map(([date, streams]) => (
                <div key={date}>
                  <div className="flex items-center gap-3 mb-4">
                    <h2 className="text-xl font-bold capitalize">{date}</h2>
                    <Badge variant="secondary">{streams.length} rappel{streams.length > 1 ? 's' : ''}</Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {streams.map(stream => (
                      <ScheduledStreamCard 
                        key={stream.id} 
                        stream={stream}
                        onReminderChange={refreshData}
                      />
                    ))}
                  </div>
                </div>
              ))
            )}
          </TabsContent>
        </Tabs>

        {/* Upcoming Lives Sidebar for Today */}
        {activeTab === 'all' && displayedStreams.some(s => {
          const streamDate = new Date(s.scheduled_at);
          const today = new Date();
          return streamDate.toDateString() === today.toDateString();
        }) && (
          <div className="mt-12">
            <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Clock className="w-6 h-6" />
                  <h3 className="text-xl font-bold">Lives d'aujourd'hui</h3>
                </div>
                <div className="space-y-3">
                  {displayedStreams
                    .filter(s => {
                      const streamDate = new Date(s.scheduled_at);
                      const today = new Date();
                      return streamDate.toDateString() === today.toDateString();
                    })
                    .slice(0, 5)
                    .map(stream => (
                      <ScheduledStreamCard key={stream.id} stream={stream} compact onReminderChange={refreshData} />
                    ))
                  }
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Schedule Modal */}
      <ScheduleStreamModal 
        isOpen={isScheduleModalOpen}
        onClose={() => setIsScheduleModalOpen(false)}
        onSuccess={refreshData}
      />
    </div>
  );
}
