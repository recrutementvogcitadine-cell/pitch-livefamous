import React, { useState, useEffect, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  TrendingUp, 
  Play, 
  Clock, 
  Video, 
  Users, 
  Star,
  ChevronRight,
  Sparkles,
  Eye,
  Calendar,
  Flame,
  Heart,
  Grid3X3,
  LayoutGrid
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { liveStreams } from '@/data/mockData';

// Category data with thumbnails and metadata
const CATEGORIES_DATA = [
  {
    id: 'electronics',
    name: 'Électronique',
    slug: 'electronique',
    description: 'Smartphones, ordinateurs, gadgets et accessoires tech',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/697517e486d0577d49bd40f6_1769625224636_00ec48e3.png',
    color: 'from-blue-500 to-cyan-500',
    icon: '📱',
    liveCount: 8,
    upcomingCount: 12,
    replayCount: 45,
    totalViewers: 15420,
    popularSellers: [
      { name: 'TechStore CI', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100', verified: true, followers: 12500 },
      { name: 'Gadget World', avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=100', verified: true, followers: 8900 },
      { name: 'Phone Master', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', verified: false, followers: 5600 }
    ]
  },
  {
    id: 'fashion',
    name: 'Mode',
    slug: 'mode',
    description: 'Vêtements, pagnes wax, tenues traditionnelles et modernes',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/697517e486d0577d49bd40f6_1769625217496_9daabd20.jpg',
    color: 'from-pink-500 to-rose-500',
    icon: '👗',
    liveCount: 12,
    upcomingCount: 18,
    replayCount: 67,
    totalViewers: 23100,
    popularSellers: [
      { name: 'Awa Fashion', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100', verified: true, followers: 18200 },
      { name: 'Luxe Bags', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100', verified: true, followers: 14300 },
      { name: 'Style Africain', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100', verified: true, followers: 9800 }
    ]
  },
  {
    id: 'beauty',
    name: 'Beauté',
    slug: 'beaute',
    description: 'Cosmétiques, soins, parfums et produits de beauté',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/697517e486d0577d49bd40f6_1769625224844_73918b72.png',
    color: 'from-purple-500 to-pink-500',
    icon: '💄',
    liveCount: 6,
    upcomingCount: 9,
    replayCount: 38,
    totalViewers: 11200,
    popularSellers: [
      { name: 'Beauty Queen', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100', verified: true, followers: 15600 },
      { name: 'Parfum Palace', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100', verified: true, followers: 11200 },
      { name: 'Glow Natural', avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=100', verified: false, followers: 7400 }
    ]
  },
  {
    id: 'home',
    name: 'Maison & Déco',
    slug: 'maison',
    description: 'Meubles, électroménager, décoration intérieure',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/697517e486d0577d49bd40f6_1769625229926_c4ee0495.png',
    color: 'from-amber-500 to-orange-500',
    icon: '🏡',
    liveCount: 4,
    upcomingCount: 7,
    replayCount: 29,
    totalViewers: 8900,
    popularSellers: [
      { name: 'Maison Plus', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', verified: true, followers: 9800 },
      { name: 'Déco Intérieur', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100', verified: false, followers: 6500 },
      { name: 'Home Style', avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100', verified: true, followers: 4200 }
    ]
  },
  {
    id: 'shoes',
    name: 'Chaussures',
    slug: 'chaussures',
    description: 'Sneakers, chaussures de ville, sandales et accessoires',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/697517e486d0577d49bd40f6_1769625222262_ba2c0225.jpg',
    color: 'from-red-500 to-orange-500',
    icon: '👟',
    liveCount: 5,
    upcomingCount: 8,
    replayCount: 34,
    totalViewers: 12300,
    popularSellers: [
      { name: 'SneakerHead ABJ', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100', verified: true, followers: 21000 },
      { name: 'Shoe Palace', avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100', verified: true, followers: 13400 },
      { name: 'Kick Store', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100', verified: false, followers: 8700 }
    ]
  },
  {
    id: 'jewelry',
    name: 'Bijoux & Accessoires',
    slug: 'bijoux',
    description: 'Bijoux artisanaux, montres, sacs et accessoires de mode',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/697517e486d0577d49bd40f6_1769625225662_0703d657.jpg',
    color: 'from-yellow-500 to-amber-500',
    icon: '💍',
    liveCount: 7,
    upcomingCount: 11,
    replayCount: 42,
    totalViewers: 9800,
    popularSellers: [
      { name: "Bijoux d'Or", avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', verified: false, followers: 7600 },
      { name: 'Chrono Luxe', avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100', verified: true, followers: 11200 },
      { name: 'Perles Africa', avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=100', verified: true, followers: 5400 }
    ]
  },
  {
    id: 'auto',
    name: 'Auto & Moto',
    slug: 'auto',
    description: 'Accessoires auto, pièces détachées, équipements moto',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/697517e486d0577d49bd40f6_1769625229306_ad709bf0.jpg',
    color: 'from-slate-600 to-slate-800',
    icon: '🚗',
    liveCount: 3,
    upcomingCount: 5,
    replayCount: 21,
    totalViewers: 6700,
    popularSellers: [
      { name: 'Auto Style CI', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100', verified: true, followers: 8900 },
      { name: 'Moto Parts', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100', verified: false, followers: 4500 },
      { name: 'Car Accessories', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', verified: true, followers: 6200 }
    ]
  },
  {
    id: 'sports',
    name: 'Sport & Fitness',
    slug: 'sport',
    description: 'Équipements sportifs, vêtements de sport, accessoires fitness',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/697517e486d0577d49bd40f6_1769625227619_e2c4d95b.jpg',
    color: 'from-green-500 to-emerald-500',
    icon: '⚽',
    liveCount: 4,
    upcomingCount: 6,
    replayCount: 25,
    totalViewers: 7500,
    popularSellers: [
      { name: 'Sport Zone', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100', verified: true, followers: 10200 },
      { name: 'Fitness Pro', avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100', verified: true, followers: 8100 },
      { name: 'Gym Equipment', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100', verified: false, followers: 5600 }
    ]
  }
];

// Mock streams data for each category
const generateMockStreams = (categoryId: string, count: number, type: 'live' | 'upcoming' | 'replay') => {
  const category = CATEGORIES_DATA.find(c => c.id === categoryId);
  if (!category) return [];
  
  return Array.from({ length: count }, (_, i) => ({
    id: `${categoryId}-${type}-${i}`,
    title: `${type === 'live' ? '🔴 LIVE' : type === 'upcoming' ? '📅' : '▶️'} ${category.name} - Stream ${i + 1}`,
    seller: category.popularSellers[i % category.popularSellers.length],
    thumbnail: category.thumbnail,
    viewers: type === 'live' ? Math.floor(Math.random() * 2000) + 100 : type === 'replay' ? Math.floor(Math.random() * 5000) + 500 : 0,
    category: category.name,
    isLive: type === 'live',
    scheduledAt: type === 'upcoming' ? new Date(Date.now() + (i + 1) * 3600000 * (Math.random() * 24 + 1)).toISOString() : undefined,
    duration: type === 'replay' ? `${Math.floor(Math.random() * 60) + 30} min` : undefined
  }));
};

// Viewing history simulation (would come from user data in real app)
const getUserViewingHistory = () => {
  return ['electronics', 'fashion', 'beauty', 'shoes'];
};

export default function Categories() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedCategorySlug = searchParams.get('category');
  
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'live' | 'upcoming' | 'replays'>('all');
  const [sortBy, setSortBy] = useState<'popular' | 'recent' | 'viewers'>('popular');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Find selected category
  const selectedCategory = useMemo(() => {
    return CATEGORIES_DATA.find(c => c.slug === selectedCategorySlug);
  }, [selectedCategorySlug]);

  // Filter categories based on search
  const filteredCategories = useMemo(() => {
    if (!searchQuery) return CATEGORIES_DATA;
    const query = searchQuery.toLowerCase();
    return CATEGORIES_DATA.filter(cat => 
      cat.name.toLowerCase().includes(query) ||
      cat.description.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  // Trending categories (sorted by total viewers)
  const trendingCategories = useMemo(() => {
    return [...CATEGORIES_DATA]
      .sort((a, b) => b.totalViewers - a.totalViewers)
      .slice(0, 4);
  }, []);

  // Personalized recommendations based on viewing history
  const recommendedCategories = useMemo(() => {
    const history = getUserViewingHistory();
    return CATEGORIES_DATA.filter(cat => history.includes(cat.id));
  }, []);

  // Generate streams for selected category
  const categoryStreams = useMemo(() => {
    if (!selectedCategory) return { live: [], upcoming: [], replays: [] };
    return {
      live: generateMockStreams(selectedCategory.id, selectedCategory.liveCount, 'live'),
      upcoming: generateMockStreams(selectedCategory.id, selectedCategory.upcomingCount, 'upcoming'),
      replays: generateMockStreams(selectedCategory.id, selectedCategory.replayCount, 'replay')
    };
  }, [selectedCategory]);

  // Get filtered streams based on active filter
  const displayedStreams = useMemo(() => {
    switch (activeFilter) {
      case 'live':
        return categoryStreams.live;
      case 'upcoming':
        return categoryStreams.upcoming;
      case 'replays':
        return categoryStreams.replays;
      default:
        return [...categoryStreams.live, ...categoryStreams.upcoming.slice(0, 4), ...categoryStreams.replays.slice(0, 4)];
    }
  }, [activeFilter, categoryStreams]);

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k';
    }
    return num.toString();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffHours = Math.floor((date.getTime() - now.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 24) {
      return `Dans ${diffHours}h`;
    }
    return date.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  // Category detail view
  if (selectedCategory) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-slate-800">
        {/* Category Hero */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0">
            <img 
              src={selectedCategory.thumbnail} 
              alt={selectedCategory.name}
              className="w-full h-full object-cover opacity-30"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-slate-900/80 via-slate-900/90 to-slate-900" />
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
            <Link 
              to="/categories" 
              className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Toutes les catégories
            </Link>
            
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
              <div>
                <div className="flex items-center gap-4 mb-4">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${selectedCategory.color} flex items-center justify-center text-3xl`}>
                    {selectedCategory.icon}
                  </div>
                  <div>
                    <h1 className="text-4xl font-bold text-white">{selectedCategory.name}</h1>
                    <p className="text-slate-400 mt-1">{selectedCategory.description}</p>
                  </div>
                </div>
                
                {/* Stats */}
                <div className="flex flex-wrap gap-4 mt-6">
                  <div className="flex items-center gap-2 px-4 py-2 bg-red-500/20 rounded-xl">
                    <Play className="w-4 h-4 text-red-400" />
                    <span className="text-white font-semibold">{selectedCategory.liveCount}</span>
                    <span className="text-slate-400">En direct</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 rounded-xl">
                    <Calendar className="w-4 h-4 text-blue-400" />
                    <span className="text-white font-semibold">{selectedCategory.upcomingCount}</span>
                    <span className="text-slate-400">À venir</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-purple-500/20 rounded-xl">
                    <Video className="w-4 h-4 text-purple-400" />
                    <span className="text-white font-semibold">{selectedCategory.replayCount}</span>
                    <span className="text-slate-400">Replays</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-green-500/20 rounded-xl">
                    <Eye className="w-4 h-4 text-green-400" />
                    <span className="text-white font-semibold">{formatNumber(selectedCategory.totalViewers)}</span>
                    <span className="text-slate-400">Spectateurs</span>
                  </div>
                </div>
              </div>

              {/* Popular Sellers */}
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 w-full lg:w-auto">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-400" />
                  Vendeurs populaires
                </h3>
                <div className="flex flex-col gap-3">
                  {selectedCategory.popularSellers.map((seller, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="relative">
                        <img 
                          src={seller.avatar} 
                          alt={seller.name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        {seller.verified && (
                          <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                            <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-medium text-sm">{seller.name}</p>
                        <p className="text-slate-400 text-xs">{formatNumber(seller.followers)} abonnés</p>
                      </div>
                      <Button size="sm" variant="outline" className="text-xs border-slate-600 text-slate-300 hover:bg-slate-700">
                        Suivre
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Filters & Content */}
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          {/* Filter Tabs */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <Tabs value={activeFilter} onValueChange={(v) => setActiveFilter(v as any)} className="w-full sm:w-auto">
              <TabsList className="bg-slate-800 p-1">
                <TabsTrigger value="all" className="data-[state=active]:bg-slate-700">
                  Tous
                </TabsTrigger>
                <TabsTrigger value="live" className="data-[state=active]:bg-red-500 data-[state=active]:text-white">
                  <Play className="w-4 h-4 mr-1" />
                  En direct ({selectedCategory.liveCount})
                </TabsTrigger>
                <TabsTrigger value="upcoming" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
                  <Clock className="w-4 h-4 mr-1" />
                  À venir ({selectedCategory.upcomingCount})
                </TabsTrigger>
                <TabsTrigger value="replays" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
                  <Video className="w-4 h-4 mr-1" />
                  Replays ({selectedCategory.replayCount})
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex items-center gap-3">
              <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
                <SelectTrigger className="w-[160px] bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Trier par" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="popular">Plus populaires</SelectItem>
                  <SelectItem value="recent">Plus récents</SelectItem>
                  <SelectItem value="viewers">Plus de vues</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex bg-slate-800 rounded-lg p-1">
                <button 
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded ${viewMode === 'grid' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}
                >
                  <Grid3X3 className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded ${viewMode === 'list' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Streams Grid */}
          <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
            {displayedStreams.map((stream) => (
              <Card 
                key={stream.id} 
                className={`bg-slate-800 border-slate-700 overflow-hidden hover:border-slate-600 transition-all cursor-pointer group ${viewMode === 'list' ? 'flex flex-row' : ''}`}
              >
                <div className={`relative ${viewMode === 'list' ? 'w-48 flex-shrink-0' : 'aspect-video'}`}>
                  <img 
                    src={stream.thumbnail} 
                    alt={stream.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {stream.isLive && (
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 bg-red-500 rounded-lg">
                      <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                      <span className="text-white text-xs font-bold">LIVE</span>
                    </div>
                  )}
                  {stream.scheduledAt && (
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 bg-blue-500 rounded-lg">
                      <Clock className="w-3 h-3 text-white" />
                      <span className="text-white text-xs font-bold">{formatDate(stream.scheduledAt)}</span>
                    </div>
                  )}
                  {stream.duration && (
                    <div className="absolute bottom-3 right-3 px-2 py-1 bg-black/70 rounded text-white text-xs">
                      {stream.duration}
                    </div>
                  )}
                  {stream.viewers > 0 && (
                    <div className="absolute bottom-3 left-3 flex items-center gap-1 px-2 py-1 bg-black/70 rounded">
                      <Eye className="w-3 h-3 text-white" />
                      <span className="text-white text-xs">{formatNumber(stream.viewers)}</span>
                    </div>
                  )}
                </div>
                <CardContent className={`p-4 ${viewMode === 'list' ? 'flex-1' : ''}`}>
                  <h3 className="text-white font-semibold line-clamp-2 mb-2 group-hover:text-red-400 transition-colors">
                    {stream.title}
                  </h3>
                  <div className="flex items-center gap-2">
                    <img 
                      src={stream.seller.avatar} 
                      alt={stream.seller.name}
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="text-slate-400 text-sm">{stream.seller.name}</span>
                    {stream.seller.verified && (
                      <svg className="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {displayedStreams.length === 0 && (
            <div className="text-center py-16">
              <Video className="w-16 h-16 mx-auto text-slate-600 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Aucun stream disponible</h3>
              <p className="text-slate-400">Il n'y a pas de streams {activeFilter === 'live' ? 'en direct' : activeFilter === 'upcoming' ? 'à venir' : 'en replay'} dans cette catégorie pour le moment.</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Main categories listing view
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-slate-800">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-purple-600 via-pink-600 to-red-500">
        <div className="absolute inset-0 bg-black/20" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yIDItNCAyLTRzLTItMi00LTItNCAwLTQgMiAwIDIgMiA0IDIgNHMtMiAyLTQgMi00IDAtNCAyIDAgMiAyIDQgMiA0IDItMiA0LTIgNC0yIDAtMi0yLTQtMi00eiIvPjwvZz48L2c+PC9zdmc+')] opacity-30" />
        
        <div className="relative max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
          <Link to="/" className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Retour à l'accueil
          </Link>
          
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Grid3X3 className="w-10 h-10 text-white" />
              <h1 className="text-4xl md:text-5xl font-bold text-white">Explorer les Catégories</h1>
            </div>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Découvrez les lives et replays par catégorie. Trouvez exactement ce que vous cherchez !
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-xl mx-auto mt-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                placeholder="Rechercher une catégorie..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 py-6 bg-white/10 border-white/20 text-white placeholder-white/60 rounded-xl focus:bg-white/20"
              />
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 max-w-3xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-white">{CATEGORIES_DATA.length}</div>
              <div className="text-sm text-white/80">Catégories</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-white">{CATEGORIES_DATA.reduce((sum, c) => sum + c.liveCount, 0)}</div>
              <div className="text-sm text-white/80">Lives en direct</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-white">{CATEGORIES_DATA.reduce((sum, c) => sum + c.upcomingCount, 0)}</div>
              <div className="text-sm text-white/80">À venir</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-white">{formatNumber(CATEGORIES_DATA.reduce((sum, c) => sum + c.totalViewers, 0))}</div>
              <div className="text-sm text-white/80">Spectateurs</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {/* Trending Categories */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-gradient-to-br from-orange-500 to-red-500 rounded-xl">
              <Flame className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">Catégories Tendances</h2>
            <Badge className="bg-red-500/20 text-red-400 border-0">Hot</Badge>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {trendingCategories.map((category, idx) => (
              <Link 
                key={category.id}
                to={`/categories?category=${category.slug}`}
                className="group relative overflow-hidden rounded-2xl"
              >
                <div className="aspect-[4/3] relative">
                  <img 
                    src={category.thumbnail} 
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${category.color} opacity-60 group-hover:opacity-70 transition-opacity`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                  
                  {/* Trending Badge */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 bg-white/20 backdrop-blur-sm rounded-lg">
                    <TrendingUp className="w-4 h-4 text-white" />
                    <span className="text-white text-xs font-bold">#{idx + 1}</span>
                  </div>

                  {/* Live Badge */}
                  {category.liveCount > 0 && (
                    <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2 py-1 bg-red-500 rounded-lg">
                      <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                      <span className="text-white text-xs font-bold">{category.liveCount} LIVE</span>
                    </div>
                  )}

                  {/* Content */}
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">{category.icon}</span>
                      <h3 className="text-xl font-bold text-white">{category.name}</h3>
                    </div>
                    <div className="flex items-center gap-4 text-white/80 text-sm">
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {formatNumber(category.totalViewers)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Video className="w-4 h-4" />
                        {category.replayCount} replays
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Personalized Recommendations */}
        {user && recommendedCategories.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white">Recommandé pour vous</h2>
              <Badge className="bg-purple-500/20 text-purple-400 border-0">Personnalisé</Badge>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {recommendedCategories.map((category) => (
                <Link 
                  key={category.id}
                  to={`/categories?category=${category.slug}`}
                  className="group bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden hover:border-purple-500/50 transition-all"
                >
                  <div className="aspect-video relative">
                    <img 
                      src={category.thumbnail} 
                      alt={category.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                    
                    {category.liveCount > 0 && (
                      <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2 py-1 bg-red-500 rounded-lg">
                        <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                        <span className="text-white text-xs font-bold">{category.liveCount}</span>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xl">{category.icon}</span>
                      <h3 className="text-lg font-bold text-white group-hover:text-purple-400 transition-colors">{category.name}</h3>
                    </div>
                    <p className="text-slate-400 text-sm line-clamp-2 mb-3">{category.description}</p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-500">{category.upcomingCount} à venir</span>
                      <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-purple-400 group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* All Categories */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl">
                <Grid3X3 className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white">Toutes les Catégories</h2>
            </div>
            <span className="text-slate-400">{filteredCategories.length} catégories</span>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredCategories.map((category) => (
              <Link 
                key={category.id}
                to={`/categories?category=${category.slug}`}
                className="group bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden hover:border-slate-600 hover:shadow-xl hover:shadow-black/20 transition-all"
              >
                <div className="aspect-video relative">
                  <img 
                    src={category.thumbnail} 
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${category.color} opacity-40`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                  
                  {/* Badges */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                    {category.liveCount > 0 && (
                      <div className="flex items-center gap-1.5 px-2 py-1 bg-red-500 rounded-lg">
                        <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                        <span className="text-white text-xs font-bold">{category.liveCount} LIVE</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-black/50 backdrop-blur-sm rounded-lg ml-auto">
                      <Eye className="w-3 h-3 text-white" />
                      <span className="text-white text-xs">{formatNumber(category.totalViewers)}</span>
                    </div>
                  </div>

                  {/* Icon */}
                  <div className="absolute bottom-3 left-3">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center text-2xl shadow-lg`}>
                      {category.icon}
                    </div>
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="text-lg font-bold text-white group-hover:text-red-400 transition-colors mb-1">
                    {category.name}
                  </h3>
                  <p className="text-slate-400 text-sm line-clamp-2 mb-4">{category.description}</p>
                  
                  {/* Stats Row */}
                  <div className="flex items-center gap-3 text-xs text-slate-500 mb-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {category.upcomingCount} à venir
                    </span>
                    <span className="flex items-center gap-1">
                      <Video className="w-3 h-3" />
                      {category.replayCount} replays
                    </span>
                  </div>

                  {/* Popular Sellers */}
                  <div className="flex items-center justify-between">
                    <div className="flex -space-x-2">
                      {category.popularSellers.slice(0, 3).map((seller, idx) => (
                        <img 
                          key={idx}
                          src={seller.avatar} 
                          alt={seller.name}
                          className="w-7 h-7 rounded-full border-2 border-slate-800 object-cover"
                          title={seller.name}
                        />
                      ))}
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-red-400 group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {filteredCategories.length === 0 && (
            <div className="text-center py-16">
              <Search className="w-16 h-16 mx-auto text-slate-600 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Aucune catégorie trouvée</h3>
              <p className="text-slate-400 mb-6">Essayez avec d'autres termes de recherche</p>
              <Button variant="outline" onClick={() => setSearchQuery('')} className="border-slate-600 text-slate-300">
                Réinitialiser la recherche
              </Button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
