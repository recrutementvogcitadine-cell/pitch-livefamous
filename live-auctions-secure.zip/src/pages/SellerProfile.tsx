import React, { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft,
  Star, 
  Users, 
  Package, 
  Video, 
  TrendingUp,
  ChevronDown,
  Grid3X3,
  List,
  Eye,
  ShoppingBag,
  Play,
  Calendar,
  Clock,
  MessageCircle,
  Share2,
  Heart,
  MapPin,
  Phone,
  Mail,
  ExternalLink,
  ThumbsUp,
  ThumbsDown,
  Filter,
  Award,
  Zap,
  Shield,
  CheckCircle,
  Send,
  X,
  ChevronRight,
  BarChart3,
  Percent,
  RefreshCw,
  Copy,
  Facebook,
  Twitter
} from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FollowButton from '@/components/FollowButton';
import { VerificationBadgeCompact, VerificationBadgeFull } from '@/components/VerificationBadge';
import { formatPrice } from '@/data/mockData';
import AuthModal from '@/components/AuthModal';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';

// Extended Seller interface
interface SellerProfile {
  id: string;
  name: string;
  avatar: string;
  coverImage: string;
  verified: boolean;
  bio: string;
  fullDescription: string;
  category: string;
  followers: number;
  following: number;
  productCount: number;
  rating: number;
  reviewCount: number;
  totalSales: number;
  totalViews: number;
  joinedDate: string;
  location: string;
  phone: string;
  email: string;
  website?: string;
  socialLinks: {
    facebook?: string;
    instagram?: string;
    twitter?: string;
    tiktok?: string;
  };
  isLive: boolean;
  liveViewers?: number;
  responseTime: string;
  shippingTime: string;
  returnPolicy: string;
  badges: string[];
  stats: {
    totalLiveStreams: number;
    totalWatchTime: number;
    avgViewers: number;
    repeatCustomers: number;
    satisfactionRate: number;
  };
}

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  sold: number;
  category: string;
  inStock: boolean;
}

interface LiveStream {
  id: string;
  title: string;
  thumbnail: string;
  viewers: number;
  peakViewers: number;
  duration: string;
  date: string;
  isLive: boolean;
  hasReplay: boolean;
  products: number;
  sales: number;
}

interface Review {
  id: string;
  user: {
    name: string;
    avatar: string;
  };
  rating: number;
  comment: string;
  date: string;
  productName: string;
  helpful: number;
  images?: string[];
  sellerResponse?: string;
}

// Mock seller data
const mockSellerProfiles: Record<string, SellerProfile> = {
  'seller-1': {
    id: 'seller-1',
    name: 'TechStore CI',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200',
    coverImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200',
    verified: true,
    bio: 'Votre partenaire technologique #1 en Côte d\'Ivoire',
    fullDescription: 'TechStore CI est le leader de la vente de produits technologiques en Côte d\'Ivoire. Depuis 2020, nous proposons les derniers smartphones, laptops, accessoires et gadgets high-tech. Notre équipe d\'experts est disponible 7j/7 pour vous conseiller et vous accompagner dans vos achats. Livraison rapide sur Abidjan et envoi partout en Côte d\'Ivoire.',
    category: 'Électronique',
    followers: 15420,
    following: 45,
    productCount: 156,
    rating: 4.8,
    reviewCount: 892,
    totalSales: 3240,
    totalViews: 125000,
    joinedDate: '2024-03-15',
    location: 'Abidjan, Cocody',
    phone: '+225 07 00 00 00 00',
    email: 'contact@techstore.ci',
    website: 'www.techstore.ci',
    socialLinks: {
      facebook: 'techstoreci',
      instagram: 'techstore_ci',
      twitter: 'techstoreci'
    },
    isLive: true,
    liveViewers: 1247,
    responseTime: '< 1 heure',
    shippingTime: '24-48h',
    returnPolicy: '7 jours',
    badges: ['Top Vendeur', 'Livraison Express', 'Service Client 5★'],
    stats: {
      totalLiveStreams: 156,
      totalWatchTime: 45000,
      avgViewers: 850,
      repeatCustomers: 68,
      satisfactionRate: 98
    }
  },
  'seller-2': {
    id: 'seller-2',
    name: 'Awa Fashion',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
    coverImage: 'https://images.unsplash.com/photo-1558171813-4c088753af8f?w=1200',
    verified: true,
    bio: 'Mode africaine authentique et moderne',
    fullDescription: 'Awa Fashion célèbre la beauté et la richesse de la mode africaine. Nous créons et vendons des vêtements uniques en pagnes wax, des boubous traditionnels et des robes modernes inspirées de notre culture. Chaque pièce est confectionnée avec soin par des artisans locaux. Livraison partout en Afrique de l\'Ouest.',
    category: 'Mode',
    followers: 28750,
    following: 120,
    productCount: 324,
    rating: 4.9,
    reviewCount: 1456,
    totalSales: 5680,
    totalViews: 230000,
    joinedDate: '2023-08-20',
    location: 'Abidjan, Plateau',
    phone: '+225 07 11 11 11 11',
    email: 'contact@awafashion.ci',
    socialLinks: {
      facebook: 'awafashion',
      instagram: 'awa_fashion_ci',
      tiktok: 'awafashion'
    },
    isLive: true,
    liveViewers: 892,
    responseTime: '< 30 min',
    shippingTime: '48-72h',
    returnPolicy: '14 jours',
    badges: ['Top Vendeur', 'Qualité Premium', 'Réponse Rapide', 'Artisan Local'],
    stats: {
      totalLiveStreams: 234,
      totalWatchTime: 78000,
      avgViewers: 1200,
      repeatCustomers: 75,
      satisfactionRate: 99
    }
  }
};

// Generate mock products for a seller
const generateMockProducts = (sellerId: string): Product[] => {
  const products: Product[] = [
    { id: 'p1', name: 'iPhone 15 Pro Max 256GB', price: 850000, originalPrice: 950000, image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', rating: 4.9, reviews: 234, sold: 156, category: 'Smartphones', inStock: true },
    { id: 'p2', name: 'Samsung Galaxy S24 Ultra', price: 750000, image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400', rating: 4.8, reviews: 189, sold: 98, category: 'Smartphones', inStock: true },
    { id: 'p3', name: 'MacBook Pro M3 14"', price: 1200000, originalPrice: 1350000, image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400', rating: 4.9, reviews: 156, sold: 67, category: 'Laptops', inStock: true },
    { id: 'p4', name: 'AirPods Pro 2ème Gen', price: 180000, image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=400', rating: 4.7, reviews: 312, sold: 245, category: 'Audio', inStock: true },
    { id: 'p5', name: 'iPad Pro 12.9" M2', price: 680000, originalPrice: 780000, image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400', rating: 4.8, reviews: 98, sold: 45, category: 'Tablettes', inStock: true },
    { id: 'p6', name: 'Apple Watch Ultra 2', price: 520000, image: 'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=400', rating: 4.9, reviews: 167, sold: 89, category: 'Montres', inStock: false },
    { id: 'p7', name: 'Sony WH-1000XM5', price: 250000, originalPrice: 320000, image: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400', rating: 4.8, reviews: 234, sold: 178, category: 'Audio', inStock: true },
    { id: 'p8', name: 'DJI Mini 3 Pro', price: 450000, image: 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=400', rating: 4.7, reviews: 78, sold: 34, category: 'Drones', inStock: true },
    { id: 'p9', name: 'Nintendo Switch OLED', price: 280000, originalPrice: 320000, image: 'https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?w=400', rating: 4.8, reviews: 145, sold: 112, category: 'Gaming', inStock: true },
    { id: 'p10', name: 'PS5 Digital Edition', price: 350000, image: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400', rating: 4.9, reviews: 289, sold: 167, category: 'Gaming', inStock: false },
    { id: 'p11', name: 'Samsung 65" QLED 4K', price: 890000, originalPrice: 1100000, image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400', rating: 4.7, reviews: 56, sold: 23, category: 'TV', inStock: true },
    { id: 'p12', name: 'Bose SoundLink Max', price: 195000, image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400', rating: 4.6, reviews: 89, sold: 67, category: 'Audio', inStock: true },
  ];
  return products;
};

// Generate mock live streams
const generateMockStreams = (sellerId: string): LiveStream[] => {
  return [
    { id: 'ls1', title: 'Vente Flash - Samsung Galaxy S24', thumbnail: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400', viewers: 1247, peakViewers: 1890, duration: 'En cours', date: 'Maintenant', isLive: true, hasReplay: false, products: 12, sales: 45 },
    { id: 'ls2', title: 'Nouveautés iPhone 16 - Présentation', thumbnail: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', viewers: 2100, peakViewers: 3200, duration: '2h 15min', date: '2026-01-27', isLive: false, hasReplay: true, products: 8, sales: 67 },
    { id: 'ls3', title: 'MacBook Pro M3 - Test & Avis', thumbnail: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400', viewers: 1560, peakViewers: 2100, duration: '1h 45min', date: '2026-01-25', isLive: false, hasReplay: true, products: 5, sales: 34 },
    { id: 'ls4', title: 'Accessoires Gaming - Promo Spéciale', thumbnail: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400', viewers: 890, peakViewers: 1200, duration: '1h 30min', date: '2026-01-22', isLive: false, hasReplay: true, products: 15, sales: 89 },
    { id: 'ls5', title: 'Écouteurs & Casques - Comparatif', thumbnail: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400', viewers: 1100, peakViewers: 1450, duration: '2h 00min', date: '2026-01-20', isLive: false, hasReplay: true, products: 10, sales: 56 },
    { id: 'ls6', title: 'Drones DJI - Démonstration Live', thumbnail: 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=400', viewers: 2300, peakViewers: 3500, duration: '1h 20min', date: '2026-01-18', isLive: false, hasReplay: false, products: 6, sales: 23 },
  ];
};

// Generate mock reviews
const generateMockReviews = (sellerId: string): Review[] => {
  return [
    { id: 'r1', user: { name: 'Kouamé Jean', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' }, rating: 5, comment: 'Excellent vendeur ! iPhone reçu en parfait état, livraison rapide sur Abidjan. Je recommande vivement TechStore CI pour tous vos achats tech.', date: '2026-01-26', productName: 'iPhone 15 Pro Max', helpful: 45, images: ['https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=200'], sellerResponse: 'Merci beaucoup Kouamé ! Nous sommes ravis que votre achat vous satisfasse. À bientôt !' },
    { id: 'r2', user: { name: 'Aminata Diallo', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' }, rating: 5, comment: 'Service client au top ! J\'avais une question sur mon MacBook et ils m\'ont répondu en moins de 10 minutes. Produit authentique et de qualité.', date: '2026-01-24', productName: 'MacBook Pro M3', helpful: 32 },
    { id: 'r3', user: { name: 'Yao Koffi', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100' }, rating: 4, comment: 'Bon produit, conforme à la description. La livraison a pris un peu plus de temps que prévu mais le vendeur m\'a tenu informé. Je suis satisfait.', date: '2026-01-22', productName: 'AirPods Pro 2', helpful: 18 },
    { id: 'r4', user: { name: 'Marie Touré', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100' }, rating: 5, comment: 'Ma 3ème commande chez TechStore CI et toujours aussi satisfaite ! Les prix sont compétitifs et les produits sont garantis authentiques.', date: '2026-01-20', productName: 'Samsung Galaxy S24', helpful: 28, sellerResponse: 'Merci pour votre fidélité Marie ! C\'est toujours un plaisir de vous servir.' },
    { id: 'r5', user: { name: 'Ibrahim Sanogo', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100' }, rating: 5, comment: 'J\'ai acheté pendant un live et j\'ai eu une super réduction ! Le vendeur est très professionnel et répond à toutes les questions en direct.', date: '2026-01-18', productName: 'Sony WH-1000XM5', helpful: 41 },
    { id: 'r6', user: { name: 'Fatou Bamba', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100' }, rating: 4, comment: 'Très bon rapport qualité-prix. L\'emballage était soigné et le produit fonctionne parfaitement. Je recommande !', date: '2026-01-15', productName: 'Nintendo Switch OLED', helpful: 15 },
  ];
};

const SellerProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'products' | 'streams' | 'reviews' | 'about'>('products');
  const [productFilter, setProductFilter] = useState('all');
  const [productSort, setProductSort] = useState('popular');
  const [streamFilter, setStreamFilter] = useState<'all' | 'live' | 'replay'>('all');
  const [reviewFilter, setReviewFilter] = useState<'all' | '5' | '4' | '3' | '2' | '1'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [contactMessage, setContactMessage] = useState('');
  const [headerSearchQuery, setHeaderSearchQuery] = useState('');

  // Get seller data
  const seller = mockSellerProfiles[id || 'seller-1'] || mockSellerProfiles['seller-1'];
  const products = useMemo(() => generateMockProducts(seller.id), [seller.id]);
  const streams = useMemo(() => generateMockStreams(seller.id), [seller.id]);
  const reviews = useMemo(() => generateMockReviews(seller.id), [seller.id]);

  // Filter products
  const filteredProducts = useMemo(() => {
    let result = [...products];
    if (productFilter !== 'all') {
      result = result.filter(p => p.category === productFilter);
    }
    switch (productSort) {
      case 'price-low': result.sort((a, b) => a.price - b.price); break;
      case 'price-high': result.sort((a, b) => b.price - a.price); break;
      case 'rating': result.sort((a, b) => b.rating - a.rating); break;
      case 'newest': result.sort((a, b) => b.sold - a.sold); break;
      default: result.sort((a, b) => b.sold - a.sold);
    }
    return result;
  }, [products, productFilter, productSort]);

  // Filter streams
  const filteredStreams = useMemo(() => {
    if (streamFilter === 'live') return streams.filter(s => s.isLive);
    if (streamFilter === 'replay') return streams.filter(s => s.hasReplay && !s.isLive);
    return streams;
  }, [streams, streamFilter]);

  // Filter reviews
  const filteredReviews = useMemo(() => {
    if (reviewFilter === 'all') return reviews;
    return reviews.filter(r => r.rating === parseInt(reviewFilter));
  }, [reviews, reviewFilter]);

  // Get unique product categories
  const productCategories = useMemo(() => {
    const cats = [...new Set(products.map(p => p.category))];
    return ['all', ...cats];
  }, [products]);

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const formatDate = (dateStr: string): string => {
    if (dateStr === 'Maintenant') return dateStr;
    const date = new Date(dateStr);
    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  const handleShare = (platform: string) => {
    const url = window.location.href;
    const text = `Découvrez ${seller.name} sur PITCH !`;
    
    switch (platform) {
      case 'copy':
        navigator.clipboard.writeText(url);
        toast({ title: 'Lien copié !', description: 'Le lien a été copié dans le presse-papier' });
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`, '_blank');
        break;
    }
    setShowShareModal(false);
  };

  const handleSendMessage = () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    if (!contactMessage.trim()) {
      toast({ title: 'Message vide', description: 'Veuillez écrire un message', variant: 'destructive' });
      return;
    }
    toast({ title: 'Message envoyé !', description: `Votre message a été envoyé à ${seller.name}` });
    setContactMessage('');
    setShowContactForm(false);
  };

  return (
    <div className="min-h-screen bg-slate-900">
      <Header 
        onAuthClick={() => setShowAuthModal(true)}
        searchQuery={headerSearchQuery}
        onSearchChange={setHeaderSearchQuery}
      />

      <main className="pt-20">
        {/* Hero Banner */}
        <section className="relative h-64 md:h-80 overflow-hidden">
          <img 
            src={seller.coverImage}
            alt={seller.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent" />
          
          {/* Back Button */}
          <button
            onClick={() => navigate(-1)}
            className="absolute top-4 left-4 flex items-center gap-2 px-4 py-2 bg-black/50 backdrop-blur-sm text-white rounded-xl hover:bg-black/70 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="hidden sm:inline">Retour</span>
          </button>

          {/* Live Badge */}
          {seller.isLive && (
            <div className="absolute top-4 right-4 flex items-center gap-2 px-4 py-2 bg-red-500 text-white font-bold rounded-full animate-pulse">
              <span className="w-3 h-3 bg-white rounded-full" />
              EN DIRECT
              <span className="flex items-center gap-1 ml-1">
                <Eye className="w-4 h-4" />
                {formatNumber(seller.liveViewers || 0)}
              </span>
            </div>
          )}
        </section>

        {/* Profile Info */}
        <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20">
          <div className="bg-slate-800/90 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 md:p-8">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Avatar */}
              <div className="flex-shrink-0">
                <div className="relative">
                  <img 
                    src={seller.avatar}
                    alt={seller.name}
                    className="w-28 h-28 md:w-36 md:h-36 rounded-2xl object-cover border-4 border-slate-700"
                  />
                  {seller.verified && (
                    <div className="absolute -bottom-2 -right-2">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center border-4 border-slate-800">
                        <CheckCircle className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  )}
                  {seller.isLive && (
                    <div className="absolute -top-2 -left-2 w-6 h-6 bg-red-500 rounded-full border-4 border-slate-800 animate-pulse" />
                  )}
                </div>
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-3 flex-wrap">
                      <h1 className="text-2xl md:text-3xl font-bold text-white">{seller.name}</h1>
                      {seller.verified && <VerificationBadgeFull status="verified" />}
                    </div>
                    <p className="text-slate-400 mt-1">{seller.category}</p>
                    <div className="flex items-center gap-2 mt-2 text-slate-400 text-sm">
                      <MapPin className="w-4 h-4" />
                      <span>{seller.location}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-3">
                    <FollowButton 
                      sellerId={seller.id}
                      sellerName={seller.name}
                      onAuthRequired={() => setShowAuthModal(true)}
                    />
                    <button
                      onClick={() => setShowContactForm(true)}
                      className="flex items-center gap-2 px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span className="hidden sm:inline">Contacter</span>
                    </button>
                    <button
                      onClick={() => setShowShareModal(true)}
                      className="p-2.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl transition-colors"
                    >
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {/* Bio */}
                <p className="text-slate-300 mt-4 line-clamp-2">{seller.bio}</p>

                {/* Stats */}
                <div className="flex flex-wrap gap-6 mt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">{formatNumber(seller.followers)}</div>
                    <div className="text-slate-400 text-sm">Abonnés</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">{seller.productCount}</div>
                    <div className="text-slate-400 text-sm">Produits</div>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 text-2xl font-bold text-white">
                      <Star className="w-5 h-5 text-yellow-400" fill="currentColor" />
                      {seller.rating}
                    </div>
                    <div className="text-slate-400 text-sm">{seller.reviewCount} avis</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">{formatNumber(seller.totalSales)}</div>
                    <div className="text-slate-400 text-sm">Ventes</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">{seller.stats.totalLiveStreams}</div>
                    <div className="text-slate-400 text-sm">Lives</div>
                  </div>
                </div>

                {/* Badges */}
                <div className="flex flex-wrap gap-2 mt-4">
                  {seller.badges.map((badge, idx) => (
                    <span 
                      key={idx}
                      className="px-3 py-1 bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 text-purple-300 text-sm font-medium rounded-full"
                    >
                      {badge}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Tabs */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {[
              { id: 'products', label: 'Produits', icon: Package, count: products.length },
              { id: 'streams', label: 'Lives', icon: Video, count: streams.length },
              { id: 'reviews', label: 'Avis', icon: Star, count: reviews.length },
              { id: 'about', label: 'À propos', icon: Shield },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-purple-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
                {tab.count !== undefined && (
                  <span className={`px-2 py-0.5 rounded-full text-xs ${
                    activeTab === tab.id ? 'bg-white/20' : 'bg-slate-700'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </div>
        </section>

        {/* Tab Content */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Products Tab */}
          {activeTab === 'products' && (
            <div>
              {/* Filters */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div className="flex flex-wrap items-center gap-2">
                  {productCategories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setProductFilter(cat)}
                      className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                        productFilter === cat
                          ? 'bg-purple-500 text-white'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      {cat === 'all' ? 'Tous' : cat}
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-3">
                  <select
                    value={productSort}
                    onChange={(e) => setProductSort(e.target.value)}
                    className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="popular">Plus populaires</option>
                    <option value="price-low">Prix croissant</option>
                    <option value="price-high">Prix décroissant</option>
                    <option value="rating">Mieux notés</option>
                  </select>
                  <div className="flex items-center bg-slate-800 border border-slate-700 rounded-xl p-1">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-purple-500 text-white' : 'text-slate-400'}`}
                    >
                      <Grid3X3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-purple-500 text-white' : 'text-slate-400'}`}
                    >
                      <List className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Products Grid */}
              <div className={`grid gap-4 ${viewMode === 'grid' ? 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4' : 'grid-cols-1'}`}>
                {filteredProducts.map(product => (
                  <div 
                    key={product.id}
                    className={`bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden hover:border-slate-600 transition-all group cursor-pointer ${
                      viewMode === 'list' ? 'flex' : ''
                    }`}
                  >
                    <div className={`relative ${viewMode === 'list' ? 'w-40 flex-shrink-0' : ''}`}>
                      <img 
                        src={product.image}
                        alt={product.name}
                        className={`object-cover group-hover:scale-105 transition-transform ${viewMode === 'list' ? 'w-full h-full' : 'w-full h-48'}`}
                      />
                      {product.originalPrice && (
                        <div className="absolute top-2 left-2 px-2 py-1 bg-red-500 text-white text-xs font-bold rounded-lg">
                          -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                        </div>
                      )}
                      {!product.inStock && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                          <span className="px-3 py-1 bg-slate-800 text-slate-300 text-sm font-medium rounded-lg">Rupture</span>
                        </div>
                      )}
                      <button className="absolute top-2 right-2 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/70">
                        <Heart className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="p-4 flex-1">
                      <p className="text-slate-400 text-xs mb-1">{product.category}</p>
                      <h3 className="text-white font-medium line-clamp-2 mb-2">{product.name}</h3>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex items-center gap-1 text-yellow-400 text-sm">
                          <Star className="w-3.5 h-3.5" fill="currentColor" />
                          {product.rating}
                        </div>
                        <span className="text-slate-500 text-sm">({product.reviews})</span>
                        <span className="text-slate-500 text-sm">• {product.sold} vendus</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-white">{formatPrice(product.price)}</span>
                        {product.originalPrice && (
                          <span className="text-sm text-slate-500 line-through">{formatPrice(product.originalPrice)}</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Streams Tab */}
          {activeTab === 'streams' && (
            <div>
              {/* Filters */}
              <div className="flex items-center gap-3 mb-6">
                {[
                  { id: 'all', label: 'Tous' },
                  { id: 'live', label: 'En direct' },
                  { id: 'replay', label: 'Replays' },
                ].map(filter => (
                  <button
                    key={filter.id}
                    onClick={() => setStreamFilter(filter.id as any)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                      streamFilter === filter.id
                        ? 'bg-purple-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>

              {/* Streams Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredStreams.map(stream => (
                  <div 
                    key={stream.id}
                    className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden hover:border-slate-600 transition-all group cursor-pointer"
                  >
                    <div className="relative">
                      <img 
                        src={stream.thumbnail}
                        alt={stream.title}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      
                      {stream.isLive ? (
                        <div className="absolute top-3 left-3 flex items-center gap-2 px-3 py-1.5 bg-red-500 text-white text-sm font-bold rounded-full animate-pulse">
                          <span className="w-2 h-2 bg-white rounded-full" />
                          LIVE
                        </div>
                      ) : stream.hasReplay ? (
                        <div className="absolute top-3 left-3 flex items-center gap-2 px-3 py-1.5 bg-purple-500 text-white text-sm font-medium rounded-full">
                          <Play className="w-3 h-3" />
                          Replay
                        </div>
                      ) : (
                        <div className="absolute top-3 left-3 px-3 py-1.5 bg-slate-700 text-slate-300 text-sm rounded-full">
                          Terminé
                        </div>
                      )}

                      <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 bg-black/60 text-white text-sm rounded-full">
                        <Eye className="w-3.5 h-3.5" />
                        {formatNumber(stream.viewers)}
                      </div>

                      <div className="absolute bottom-3 left-3 right-3">
                        <h3 className="text-white font-bold line-clamp-2">{stream.title}</h3>
                      </div>

                      {(stream.hasReplay || stream.isLive) && (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                          <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                            <Play className="w-7 h-7 text-white ml-1" />
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="p-4">
                      <div className="flex items-center justify-between text-sm text-slate-400 mb-3">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {formatDate(stream.date)}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {stream.duration}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-slate-400">
                            <Package className="w-4 h-4 inline mr-1" />
                            {stream.products} produits
                          </span>
                          <span className="text-green-400">
                            <ShoppingBag className="w-4 h-4 inline mr-1" />
                            {stream.sales} ventes
                          </span>
                        </div>
                        <span className="text-slate-500 text-sm">
                          Max: {formatNumber(stream.peakViewers)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Reviews Tab */}
          {activeTab === 'reviews' && (
            <div>
              {/* Rating Summary */}
              <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6 mb-6">
                <div className="flex flex-col md:flex-row md:items-center gap-6">
                  <div className="text-center">
                    <div className="text-5xl font-bold text-white mb-2">{seller.rating}</div>
                    <div className="flex items-center justify-center gap-1 mb-1">
                      {[1, 2, 3, 4, 5].map(star => (
                        <Star 
                          key={star}
                          className={`w-5 h-5 ${star <= Math.round(seller.rating) ? 'text-yellow-400' : 'text-slate-600'}`}
                          fill={star <= Math.round(seller.rating) ? 'currentColor' : 'none'}
                        />
                      ))}
                    </div>
                    <p className="text-slate-400 text-sm">{seller.reviewCount} avis</p>
                  </div>
                  <div className="flex-1">
                    {[5, 4, 3, 2, 1].map(rating => {
                      const count = reviews.filter(r => r.rating === rating).length;
                      const percentage = (count / reviews.length) * 100;
                      return (
                        <div key={rating} className="flex items-center gap-3 mb-2">
                          <span className="text-slate-400 text-sm w-8">{rating}</span>
                          <Star className="w-4 h-4 text-yellow-400" fill="currentColor" />
                          <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-yellow-400 rounded-full"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                          <span className="text-slate-500 text-sm w-12">{count}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Filter */}
              <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
                {['all', '5', '4', '3', '2', '1'].map(filter => (
                  <button
                    key={filter}
                    onClick={() => setReviewFilter(filter as any)}
                    className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                      reviewFilter === filter
                        ? 'bg-purple-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    {filter === 'all' ? 'Tous' : (
                      <>
                        {filter}
                        <Star className="w-3.5 h-3.5" fill="currentColor" />
                      </>
                    )}
                  </button>
                ))}
              </div>

              {/* Reviews List */}
              <div className="space-y-4">
                {filteredReviews.map(review => (
                  <div key={review.id} className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5">
                    <div className="flex items-start gap-4">
                      <img 
                        src={review.user.avatar}
                        alt={review.user.name}
                        className="w-12 h-12 rounded-xl object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <div>
                            <h4 className="text-white font-medium">{review.user.name}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              <div className="flex items-center gap-0.5">
                                {[1, 2, 3, 4, 5].map(star => (
                                  <Star 
                                    key={star}
                                    className={`w-4 h-4 ${star <= review.rating ? 'text-yellow-400' : 'text-slate-600'}`}
                                    fill={star <= review.rating ? 'currentColor' : 'none'}
                                  />
                                ))}
                              </div>
                              <span className="text-slate-500 text-sm">• {formatDate(review.date)}</span>
                            </div>
                          </div>
                          <span className="px-3 py-1 bg-slate-700 text-slate-300 text-xs rounded-full">
                            {review.productName}
                          </span>
                        </div>
                        <p className="text-slate-300 mt-3">{review.comment}</p>
                        
                        {review.images && review.images.length > 0 && (
                          <div className="flex gap-2 mt-3">
                            {review.images.map((img, idx) => (
                              <img 
                                key={idx}
                                src={img}
                                alt="Review"
                                className="w-20 h-20 rounded-lg object-cover"
                              />
                            ))}
                          </div>
                        )}

                        {review.sellerResponse && (
                          <div className="mt-4 p-4 bg-slate-700/50 rounded-xl border-l-4 border-purple-500">
                            <div className="flex items-center gap-2 mb-2">
                              <img src={seller.avatar} alt={seller.name} className="w-6 h-6 rounded-full" />
                              <span className="text-purple-400 font-medium text-sm">Réponse de {seller.name}</span>
                            </div>
                            <p className="text-slate-300 text-sm">{review.sellerResponse}</p>
                          </div>
                        )}

                        <div className="flex items-center gap-4 mt-4">
                          <button className="flex items-center gap-1 text-slate-400 hover:text-white text-sm transition-colors">
                            <ThumbsUp className="w-4 h-4" />
                            Utile ({review.helpful})
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* About Tab */}
          {activeTab === 'about' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Info */}
              <div className="lg:col-span-2 space-y-6">
                {/* Description */}
                <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                  <h3 className="text-xl font-bold text-white mb-4">À propos de {seller.name}</h3>
                  <p className="text-slate-300 leading-relaxed">{seller.fullDescription}</p>
                </div>

                {/* Statistics Dashboard */}
                <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                  <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-purple-400" />
                    Statistiques du vendeur
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                      <Video className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{seller.stats.totalLiveStreams}</div>
                      <div className="text-slate-400 text-sm">Lives réalisés</div>
                    </div>
                    <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                      <Eye className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{formatNumber(seller.totalViews)}</div>
                      <div className="text-slate-400 text-sm">Vues totales</div>
                    </div>
                    <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                      <Users className="w-6 h-6 text-green-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{seller.stats.avgViewers}</div>
                      <div className="text-slate-400 text-sm">Viewers moyens</div>
                    </div>
                    <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                      <RefreshCw className="w-6 h-6 text-orange-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{seller.stats.repeatCustomers}%</div>
                      <div className="text-slate-400 text-sm">Clients fidèles</div>
                    </div>
                    <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                      <ThumbsUp className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{seller.stats.satisfactionRate}%</div>
                      <div className="text-slate-400 text-sm">Satisfaction</div>
                    </div>
                    <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                      <Clock className="w-6 h-6 text-pink-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{formatNumber(seller.stats.totalWatchTime)}</div>
                      <div className="text-slate-400 text-sm">Min. de watch</div>
                    </div>
                  </div>
                </div>

                {/* Policies */}
                <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Politiques</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center gap-3 p-4 bg-slate-700/50 rounded-xl">
                      <div className="w-10 h-10 bg-green-500/20 rounded-full flex items-center justify-center">
                        <Clock className="w-5 h-5 text-green-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Réponse</p>
                        <p className="text-slate-400 text-sm">{seller.responseTime}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-slate-700/50 rounded-xl">
                      <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
                        <Package className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Livraison</p>
                        <p className="text-slate-400 text-sm">{seller.shippingTime}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-slate-700/50 rounded-xl">
                      <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center">
                        <RefreshCw className="w-5 h-5 text-purple-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Retours</p>
                        <p className="text-slate-400 text-sm">{seller.returnPolicy}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Contact Info */}
                <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-white mb-4">Contact</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-slate-300">
                      <MapPin className="w-5 h-5 text-slate-400" />
                      <span>{seller.location}</span>
                    </div>
                    <div className="flex items-center gap-3 text-slate-300">
                      <Phone className="w-5 h-5 text-slate-400" />
                      <span>{seller.phone}</span>
                    </div>
                    <div className="flex items-center gap-3 text-slate-300">
                      <Mail className="w-5 h-5 text-slate-400" />
                      <span>{seller.email}</span>
                    </div>
                    {seller.website && (
                      <div className="flex items-center gap-3 text-slate-300">
                        <ExternalLink className="w-5 h-5 text-slate-400" />
                        <a href={`https://${seller.website}`} target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline">
                          {seller.website}
                        </a>
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => setShowContactForm(true)}
                    className="w-full mt-4 py-3 bg-purple-500 hover:bg-purple-600 text-white font-medium rounded-xl transition-colors flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-5 h-5" />
                    Envoyer un message
                  </button>
                </div>

                {/* Social Links */}
                {Object.keys(seller.socialLinks).length > 0 && (
                  <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                    <h3 className="text-lg font-bold text-white mb-4">Réseaux sociaux</h3>
                    <div className="flex flex-wrap gap-3">
                      {seller.socialLinks.facebook && (
                        <a href={`https://facebook.com/${seller.socialLinks.facebook}`} target="_blank" rel="noopener noreferrer" className="p-3 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 rounded-xl transition-colors">
                          <Facebook className="w-5 h-5" />
                        </a>
                      )}
                      {seller.socialLinks.instagram && (
                        <a href={`https://instagram.com/${seller.socialLinks.instagram}`} target="_blank" rel="noopener noreferrer" className="p-3 bg-pink-600/20 hover:bg-pink-600/30 text-pink-400 rounded-xl transition-colors">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                        </a>
                      )}
                      {seller.socialLinks.twitter && (
                        <a href={`https://twitter.com/${seller.socialLinks.twitter}`} target="_blank" rel="noopener noreferrer" className="p-3 bg-sky-600/20 hover:bg-sky-600/30 text-sky-400 rounded-xl transition-colors">
                          <Twitter className="w-5 h-5" />
                        </a>
                      )}
                      {seller.socialLinks.tiktok && (
                        <a href={`https://tiktok.com/@${seller.socialLinks.tiktok}`} target="_blank" rel="noopener noreferrer" className="p-3 bg-slate-600/20 hover:bg-slate-600/30 text-white rounded-xl transition-colors">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z"/></svg>
                        </a>
                      )}
                    </div>
                  </div>
                )}

                {/* Member Since */}
                <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-slate-400 text-sm">Membre depuis</p>
                      <p className="text-white font-medium">{formatDate(seller.joinedDate)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      </main>

      <Footer />

      {/* Contact Form Modal */}
      {showContactForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowContactForm(false)} />
          <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl overflow-hidden">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-6">
              <button onClick={() => setShowContactForm(false)} className="absolute top-4 right-4 p-2 bg-white/20 rounded-full text-white hover:bg-white/30">
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-4">
                <img src={seller.avatar} alt={seller.name} className="w-16 h-16 rounded-xl object-cover" />
                <div>
                  <h2 className="text-xl font-bold text-white">Contacter {seller.name}</h2>
                  <p className="text-white/80 text-sm">Temps de réponse: {seller.responseTime}</p>
                </div>
              </div>
            </div>
            <div className="p-6">
              <textarea
                value={contactMessage}
                onChange={(e) => setContactMessage(e.target.value)}
                rows={5}
                placeholder="Écrivez votre message..."
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
              />
              <button
                onClick={handleSendMessage}
                className="w-full mt-4 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-purple-500/30 transition-all flex items-center justify-center gap-2"
              >
                <Send className="w-5 h-5" />
                Envoyer le message
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowShareModal(false)} />
          <div className="relative w-full max-w-sm bg-slate-900 rounded-3xl p-6">
            <button onClick={() => setShowShareModal(false)} className="absolute top-4 right-4 p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-bold text-white mb-6">Partager ce profil</h2>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => handleShare('copy')} className="flex items-center justify-center gap-2 p-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors">
                <Copy className="w-5 h-5" />
                Copier le lien
              </button>
              <button onClick={() => handleShare('whatsapp')} className="flex items-center justify-center gap-2 p-4 bg-green-600/20 hover:bg-green-600/30 text-green-400 rounded-xl transition-colors">
                <MessageCircle className="w-5 h-5" />
                WhatsApp
              </button>
              <button onClick={() => handleShare('facebook')} className="flex items-center justify-center gap-2 p-4 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 rounded-xl transition-colors">
                <Facebook className="w-5 h-5" />
                Facebook
              </button>
              <button onClick={() => handleShare('twitter')} className="flex items-center justify-center gap-2 p-4 bg-sky-600/20 hover:bg-sky-600/30 text-sky-400 rounded-xl transition-colors">
                <Twitter className="w-5 h-5" />
                Twitter
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
};

export default SellerProfilePage;
