import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Activity, Play, RefreshCw, Calendar, Bell, Settings, CheckCircle2,
  XCircle, AlertTriangle, Loader2, ArrowLeft, Clock, TrendingUp,
  TrendingDown, BarChart3, Plus, Trash2, Mail, Smartphone, Save,
  ChevronDown, ChevronUp, Database, Cloud, Radio, Server, Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import {
  useAutomatedTests,
  TestResult,
  ScheduledTest,
  AlertConfig,
  TEST_TYPES,
  DAYS_OF_WEEK
} from '@/hooks/useAutomatedTests';
import AuthModal from '@/components/AuthModal';

const SystemHealthDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const automatedTests = useAutomatedTests();

  // State
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [testHistory, setTestHistory] = useState<TestResult[]>([]);
  const [schedules, setSchedules] = useState<ScheduledTest[]>([]);
  const [alertConfig, setAlertConfig] = useState<AlertConfig | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [runningTestId, setRunningTestId] = useState<string | null>(null);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [historyFilter, setHistoryFilter] = useState<string>('all');
  const [historyDays, setHistoryDays] = useState<number>(7);

  // New schedule form
  const [newSchedule, setNewSchedule] = useState({
    name: '',
    testTypes: [] as string[],
    scheduledTime: '08:00',
    daysOfWeek: [1, 2, 3, 4, 5] as number[]
  });

  // Alert config form
  const [alertForm, setAlertForm] = useState<AlertConfig>({
    user_id: '',
    alert_type: 'email',
    email_address: '',
    notify_on_failure: true,
    notify_on_warning: false,
    notify_on_recovery: true,
    is_active: true
  });

  // Load initial data
  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (user) {
      setAlertForm(prev => ({ ...prev, user_id: user.id }));
      loadAlertConfig();
    }
  }, [user]);

  const loadData = async () => {
    const [historyData, statsData, schedulesData] = await Promise.all([
      automatedTests.getTestHistory(100),
      automatedTests.getTestStats(historyDays),
      automatedTests.getSchedules()
    ]);

    if (historyData) setTestHistory(historyData);
    if (statsData) setStats(statsData);
    if (schedulesData) setSchedules(schedulesData);
  };

  const loadAlertConfig = async () => {
    if (!user) return;
    const config = await automatedTests.getAlertConfig(user.id);
    if (config) {
      setAlertConfig(config);
      setAlertForm(config);
    }
  };

  // Run all tests
  const handleRunAllTests = async () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }

    setIsRunningTests(true);
    setTestResults([]);

    const results = await automatedTests.runAllTests();
    
    if (results) {
      setTestResults(results);
      await loadData();
      
      const failed = results.filter(r => r.status === 'failed').length;
      const warnings = results.filter(r => r.status === 'warning').length;
      
      if (failed > 0) {
        toast({
          title: "Tests terminés avec des erreurs",
          description: `${failed} test(s) échoué(s), ${warnings} avertissement(s)`,
          variant: "destructive"
        });
      } else if (warnings > 0) {
        toast({
          title: "Tests terminés avec des avertissements",
          description: `Tous les tests passés, ${warnings} avertissement(s)`,
        });
      } else {
        toast({
          title: "Tous les tests réussis !",
          description: "Le système de live streaming est opérationnel",
        });
      }
    }

    setIsRunningTests(false);
  };

  // Run specific test
  const handleRunSpecificTest = async (testType: string) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }

    setRunningTestId(testType);
    const result = await automatedTests.runSpecificTest(testType);
    
    if (result) {
      setTestResults(prev => {
        const filtered = prev.filter(r => r.test_type !== result.test_type || r.test_name !== result.test_name);
        return [result, ...filtered];
      });
      await loadData();
    }
    
    setRunningTestId(null);
  };

  // Create schedule
  const handleCreateSchedule = async () => {
    if (!user || !newSchedule.name || newSchedule.testTypes.length === 0) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs requis",
        variant: "destructive"
      });
      return;
    }

    const schedule = await automatedTests.createSchedule(
      newSchedule.name,
      newSchedule.testTypes,
      newSchedule.scheduledTime,
      newSchedule.daysOfWeek,
      user.id
    );

    if (schedule) {
      setSchedules(prev => [schedule, ...prev]);
      setShowScheduleModal(false);
      setNewSchedule({
        name: '',
        testTypes: [],
        scheduledTime: '08:00',
        daysOfWeek: [1, 2, 3, 4, 5]
      });
      toast({
        title: "Planification créée",
        description: "Les tests seront exécutés selon le planning défini"
      });
    }
  };

  // Toggle schedule
  const handleToggleSchedule = async (schedule: ScheduledTest) => {
    const updated = await automatedTests.updateSchedule(schedule.id, {
      is_active: !schedule.is_active
    });

    if (updated) {
      setSchedules(prev => prev.map(s => s.id === schedule.id ? updated : s));
    }
  };

  // Delete schedule
  const handleDeleteSchedule = async (id: string) => {
    const success = await automatedTests.deleteSchedule(id);
    if (success) {
      setSchedules(prev => prev.filter(s => s.id !== id));
      toast({
        title: "Planification supprimée",
        description: "La planification a été supprimée avec succès"
      });
    }
  };

  // Save alert config
  const handleSaveAlertConfig = async () => {
    if (!user) return;

    const saved = await automatedTests.saveAlertConfig({
      ...alertForm,
      user_id: user.id
    });

    if (saved) {
      setAlertConfig(saved);
      toast({
        title: "Configuration sauvegardée",
        description: "Vos préférences d'alertes ont été mises à jour"
      });
    }
  };

  // Get test icon
  const getTestIcon = (testType: string) => {
    switch (testType) {
      case 'infrastructure': return <Database className="w-4 h-4" />;
      case 'live_streaming': return <Radio className="w-4 h-4" />;
      case 'notifications': return <Bell className="w-4 h-4" />;
      default: return <Server className="w-4 h-4" />;
    }
  };

  // Calculate health score
  const calculateHealthScore = () => {
    if (!stats || stats.totalTests === 0) return 100;
    
    let score = 100;
    Object.values(stats.stats).forEach((testStats: any) => {
      const failRate = testStats.failed / testStats.total;
      const warningRate = testStats.warning / testStats.total;
      score -= (failRate * 30) + (warningRate * 10);
    });
    
    return Math.max(0, Math.round(score));
  };

  const healthScore = calculateHealthScore();

  // Filter history
  const filteredHistory = testHistory.filter(result => {
    if (historyFilter === 'all') return true;
    return result.status === historyFilter;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/')}
                className="text-slate-400 hover:text-white"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-xl font-bold text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-orange-500" />
                  Santé du Système
                </h1>
                <p className="text-sm text-slate-400">Surveillance automatique du live streaming</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Health Score */}
              <div className={`hidden md:flex items-center gap-2 px-4 py-2 rounded-xl ${
                healthScore >= 80 ? 'bg-green-500/20 border border-green-500/30' :
                healthScore >= 50 ? 'bg-yellow-500/20 border border-yellow-500/30' :
                'bg-red-500/20 border border-red-500/30'
              }`}>
                <span className={`text-sm font-medium ${
                  healthScore >= 80 ? 'text-green-400' :
                  healthScore >= 50 ? 'text-yellow-400' :
                  'text-red-400'
                }`}>
                  Score: {healthScore}%
                </span>
              </div>

              <Button
                onClick={handleRunAllTests}
                className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white hover:shadow-lg hover:shadow-orange-500/25"
                disabled={isRunningTests}
              >
                {isRunningTests ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Tests en cours...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Lancer les tests
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-800/50 border border-slate-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-orange-500">
              <BarChart3 className="w-4 h-4 mr-2" />
              Vue d'ensemble
            </TabsTrigger>
            <TabsTrigger value="tests" className="data-[state=active]:bg-orange-500">
              <Zap className="w-4 h-4 mr-2" />
              Tests
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-orange-500">
              <Clock className="w-4 h-4 mr-2" />
              Historique
            </TabsTrigger>
            <TabsTrigger value="schedules" className="data-[state=active]:bg-orange-500">
              <Calendar className="w-4 h-4 mr-2" />
              Planification
            </TabsTrigger>
            <TabsTrigger value="alerts" className="data-[state=active]:bg-orange-500">
              <Bell className="w-4 h-4 mr-2" />
              Alertes
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Score de Santé</p>
                      <p className={`text-3xl font-bold ${
                        healthScore >= 80 ? 'text-green-400' :
                        healthScore >= 50 ? 'text-yellow-400' :
                        'text-red-400'
                      }`}>{healthScore}%</p>
                    </div>
                    <div className={`p-3 rounded-xl ${
                      healthScore >= 80 ? 'bg-green-500/20' :
                      healthScore >= 50 ? 'bg-yellow-500/20' :
                      'bg-red-500/20'
                    }`}>
                      {healthScore >= 80 ? (
                        <CheckCircle2 className="w-6 h-6 text-green-400" />
                      ) : healthScore >= 50 ? (
                        <AlertTriangle className="w-6 h-6 text-yellow-400" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-400" />
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Tests Réussis</p>
                      <p className="text-3xl font-bold text-green-400">
                        {Object.values(stats?.stats || {}).reduce((acc: number, s: any) => acc + s.passed, 0)}
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-green-500/20">
                      <TrendingUp className="w-6 h-6 text-green-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Échecs</p>
                      <p className="text-3xl font-bold text-red-400">
                        {Object.values(stats?.stats || {}).reduce((acc: number, s: any) => acc + s.failed, 0)}
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-red-500/20">
                      <TrendingDown className="w-6 h-6 text-red-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Total Tests</p>
                      <p className="text-3xl font-bold text-white">{stats?.totalTests || 0}</p>
                    </div>
                    <div className="p-3 rounded-xl bg-blue-500/20">
                      <BarChart3 className="w-6 h-6 text-blue-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Trend Chart */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Tendance des Tests (7 derniers jours)</CardTitle>
              </CardHeader>
              <CardContent>
                {stats?.dailyStats && Object.keys(stats.dailyStats).length > 0 ? (
                  <div className="space-y-4">
                    {Object.entries(stats.dailyStats).slice(-7).map(([date, dayStats]: [string, any]) => {
                      const total = dayStats.passed + dayStats.failed + dayStats.warning;
                      const passedPercent = total > 0 ? (dayStats.passed / total) * 100 : 0;
                      const failedPercent = total > 0 ? (dayStats.failed / total) * 100 : 0;
                      const warningPercent = total > 0 ? (dayStats.warning / total) * 100 : 0;

                      return (
                        <div key={date} className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-slate-400">{new Date(date).toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' })}</span>
                            <span className="text-slate-500">{total} tests</span>
                          </div>
                          <div className="h-4 bg-slate-800 rounded-full overflow-hidden flex">
                            <div 
                              className="bg-green-500 h-full transition-all"
                              style={{ width: `${passedPercent}%` }}
                            />
                            <div 
                              className="bg-yellow-500 h-full transition-all"
                              style={{ width: `${warningPercent}%` }}
                            />
                            <div 
                              className="bg-red-500 h-full transition-all"
                              style={{ width: `${failedPercent}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                    <div className="flex items-center justify-center gap-6 pt-4">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-green-500" />
                        <span className="text-slate-400 text-sm">Réussi</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-yellow-500" />
                        <span className="text-slate-400 text-sm">Attention</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-500" />
                        <span className="text-slate-400 text-sm">Échec</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-48 text-slate-500">
                    Aucune donnée disponible. Lancez des tests pour voir les tendances.
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Test Results by Type */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Résultats par Type de Test</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(stats?.stats || {}).map(([testName, testStats]: [string, any]) => {
                    const successRate = testStats.total > 0 
                      ? Math.round((testStats.passed / testStats.total) * 100) 
                      : 0;

                    return (
                      <div 
                        key={testName}
                        className="p-4 bg-slate-800/50 rounded-xl border border-slate-700"
                      >
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-white font-medium text-sm">{testName}</h4>
                          <Badge className={
                            successRate >= 80 ? 'bg-green-500/20 text-green-400' :
                            successRate >= 50 ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }>
                            {successRate}%
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-xs">
                          <span className="text-green-400">{testStats.passed} réussi</span>
                          <span className="text-yellow-400">{testStats.warning} attention</span>
                          <span className="text-red-400">{testStats.failed} échec</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tests Tab */}
          <TabsContent value="tests" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Available Tests */}
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white">Tests Disponibles</CardTitle>
                  <CardDescription className="text-slate-400">
                    Cliquez sur un test pour l'exécuter individuellement
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {TEST_TYPES.map((test) => (
                    <div
                      key={test.id}
                      className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:border-orange-500/50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-orange-500/20 rounded-lg">
                            {getTestIcon(test.id)}
                          </div>
                          <div>
                            <h4 className="text-white font-medium">{test.name}</h4>
                            <p className="text-slate-400 text-sm">{test.description}</p>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => handleRunSpecificTest(test.id)}
                          disabled={runningTestId === test.id}
                          className="bg-orange-500/20 text-orange-400 hover:bg-orange-500/30"
                        >
                          {runningTestId === test.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Play className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Recent Results */}
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white">Résultats Récents</CardTitle>
                  <CardDescription className="text-slate-400">
                    Derniers résultats de tests exécutés
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px] pr-4">
                    {testResults.length === 0 ? (
                      <div className="flex items-center justify-center h-32 text-slate-500">
                        Aucun test exécuté. Lancez des tests pour voir les résultats.
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {testResults.map((result, index) => (
                          <div
                            key={`${result.test_name}-${index}`}
                            className={`p-4 rounded-xl border ${
                              result.status === 'passed' ? 'bg-green-500/10 border-green-500/30' :
                              result.status === 'warning' ? 'bg-yellow-500/10 border-yellow-500/30' :
                              result.status === 'failed' ? 'bg-red-500/10 border-red-500/30' :
                              'bg-slate-800/50 border-slate-700'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="text-white font-medium">{result.test_name}</h4>
                              <Badge className={automatedTests.getStatusColor(result.status)}>
                                {automatedTests.getStatusLabel(result.status)}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-xs text-slate-400">
                              <span>Type: {result.test_type}</span>
                              <span>Durée: {result.duration_ms}ms</span>
                            </div>
                            {result.error_message && (
                              <p className="mt-2 text-sm text-red-400">{result.error_message}</p>
                            )}
                            {result.details && (
                              <div className="mt-2 p-2 bg-slate-800/50 rounded-lg">
                                <pre className="text-xs text-slate-400 overflow-x-auto">
                                  {JSON.stringify(result.details, null, 2)}
                                </pre>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">Historique des Tests</CardTitle>
                    <CardDescription className="text-slate-400">
                      Consultez l'historique complet des tests exécutés
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-3">
                    <Select value={historyFilter} onValueChange={setHistoryFilter}>
                      <SelectTrigger className="w-36 bg-slate-800 border-slate-700 text-white">
                        <SelectValue placeholder="Filtrer" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="all">Tous</SelectItem>
                        <SelectItem value="passed">Réussis</SelectItem>
                        <SelectItem value="failed">Échecs</SelectItem>
                        <SelectItem value="warning">Avertissements</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={loadData}
                      className="border-slate-700"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[500px] pr-4">
                  {filteredHistory.length === 0 ? (
                    <div className="flex items-center justify-center h-32 text-slate-500">
                      Aucun historique disponible
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {filteredHistory.map((result) => (
                        <div
                          key={result.id}
                          className="p-3 bg-slate-800/50 rounded-xl border border-slate-700 hover:border-slate-600 transition-colors"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              {result.status === 'passed' && <CheckCircle2 className="w-5 h-5 text-green-400" />}
                              {result.status === 'failed' && <XCircle className="w-5 h-5 text-red-400" />}
                              {result.status === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-400" />}
                              <div>
                                <h4 className="text-white font-medium">{result.test_name}</h4>
                                <p className="text-slate-400 text-xs">
                                  {new Date(result.created_at).toLocaleString('fr-FR')}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="text-slate-500 text-sm">{result.duration_ms}ms</span>
                              <Badge className={automatedTests.getStatusColor(result.status)}>
                                {automatedTests.getStatusLabel(result.status)}
                              </Badge>
                            </div>
                          </div>
                          {result.error_message && (
                            <p className="mt-2 text-sm text-red-400 pl-8">{result.error_message}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Schedules Tab */}
          <TabsContent value="schedules" className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">Planification des Tests</CardTitle>
                    <CardDescription className="text-slate-400">
                      Configurez des tests automatiques à des heures spécifiques
                    </CardDescription>
                  </div>
                  <Button
                    onClick={() => setShowScheduleModal(true)}
                    className="bg-orange-500 hover:bg-orange-600"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Nouvelle planification
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {schedules.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-48 text-slate-500">
                    <Calendar className="w-12 h-12 mb-4 opacity-50" />
                    <p>Aucune planification configurée</p>
                    <p className="text-sm">Créez une planification pour automatiser vos tests</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {schedules.map((schedule) => (
                      <div
                        key={schedule.id}
                        className="p-4 bg-slate-800/50 rounded-xl border border-slate-700"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <Switch
                              checked={schedule.is_active}
                              onCheckedChange={() => handleToggleSchedule(schedule)}
                            />
                            <div>
                              <h4 className="text-white font-medium">{schedule.name}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                <span className="text-slate-400 text-sm">
                                  {schedule.scheduled_time}
                                </span>
                                <span className="text-slate-600">•</span>
                                <span className="text-slate-400 text-sm">
                                  {schedule.days_of_week?.map(d => DAYS_OF_WEEK.find(day => day.id === d)?.short).join(', ')}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-slate-400 border-slate-600">
                              {schedule.test_types.length} tests
                            </Badge>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteSchedule(schedule.id)}
                              className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="mt-3 flex flex-wrap gap-2">
                          {schedule.test_types.map((type) => (
                            <Badge key={type} className="bg-slate-700 text-slate-300">
                              {automatedTests.getTestTypeLabel(type)}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Configuration des Alertes</CardTitle>
                <CardDescription className="text-slate-400">
                  Recevez des notifications en cas de problème détecté
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Alert Type */}
                <div className="space-y-3">
                  <Label className="text-white">Type d'alerte</Label>
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      onClick={() => setAlertForm(prev => ({ ...prev, alert_type: 'email' }))}
                      className={`p-4 rounded-xl border transition-colors ${
                        alertForm.alert_type === 'email'
                          ? 'bg-orange-500/20 border-orange-500'
                          : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                      }`}
                    >
                      <Mail className={`w-6 h-6 mx-auto mb-2 ${
                        alertForm.alert_type === 'email' ? 'text-orange-400' : 'text-slate-400'
                      }`} />
                      <span className={alertForm.alert_type === 'email' ? 'text-orange-400' : 'text-slate-400'}>
                        Email
                      </span>
                    </button>
                    <button
                      onClick={() => setAlertForm(prev => ({ ...prev, alert_type: 'push' }))}
                      className={`p-4 rounded-xl border transition-colors ${
                        alertForm.alert_type === 'push'
                          ? 'bg-orange-500/20 border-orange-500'
                          : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                      }`}
                    >
                      <Smartphone className={`w-6 h-6 mx-auto mb-2 ${
                        alertForm.alert_type === 'push' ? 'text-orange-400' : 'text-slate-400'
                      }`} />
                      <span className={alertForm.alert_type === 'push' ? 'text-orange-400' : 'text-slate-400'}>
                        Push
                      </span>
                    </button>
                    <button
                      onClick={() => setAlertForm(prev => ({ ...prev, alert_type: 'both' }))}
                      className={`p-4 rounded-xl border transition-colors ${
                        alertForm.alert_type === 'both'
                          ? 'bg-orange-500/20 border-orange-500'
                          : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                      }`}
                    >
                      <Bell className={`w-6 h-6 mx-auto mb-2 ${
                        alertForm.alert_type === 'both' ? 'text-orange-400' : 'text-slate-400'
                      }`} />
                      <span className={alertForm.alert_type === 'both' ? 'text-orange-400' : 'text-slate-400'}>
                        Les deux
                      </span>
                    </button>
                  </div>
                </div>

                {/* Email Address */}
                {(alertForm.alert_type === 'email' || alertForm.alert_type === 'both') && (
                  <div className="space-y-2">
                    <Label className="text-white">Adresse email</Label>
                    <Input
                      type="email"
                      value={alertForm.email_address || ''}
                      onChange={(e) => setAlertForm(prev => ({ ...prev, email_address: e.target.value }))}
                      placeholder="votre@email.com"
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                )}

                <Separator className="bg-slate-800" />

                {/* Notification Preferences */}
                <div className="space-y-4">
                  <Label className="text-white">Préférences de notification</Label>
                  
                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <XCircle className="w-5 h-5 text-red-400" />
                      <div>
                        <p className="text-white font-medium">Échecs de tests</p>
                        <p className="text-slate-400 text-sm">Recevoir une alerte quand un test échoue</p>
                      </div>
                    </div>
                    <Switch
                      checked={alertForm.notify_on_failure}
                      onCheckedChange={(checked) => setAlertForm(prev => ({ ...prev, notify_on_failure: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="w-5 h-5 text-yellow-400" />
                      <div>
                        <p className="text-white font-medium">Avertissements</p>
                        <p className="text-slate-400 text-sm">Recevoir une alerte pour les avertissements</p>
                      </div>
                    </div>
                    <Switch
                      checked={alertForm.notify_on_warning}
                      onCheckedChange={(checked) => setAlertForm(prev => ({ ...prev, notify_on_warning: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                      <div>
                        <p className="text-white font-medium">Récupération</p>
                        <p className="text-slate-400 text-sm">Recevoir une alerte quand le système récupère</p>
                      </div>
                    </div>
                    <Switch
                      checked={alertForm.notify_on_recovery}
                      onCheckedChange={(checked) => setAlertForm(prev => ({ ...prev, notify_on_recovery: checked }))}
                    />
                  </div>
                </div>

                <Separator className="bg-slate-800" />

                {/* Active Toggle */}
                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                  <div>
                    <p className="text-white font-medium">Activer les alertes</p>
                    <p className="text-slate-400 text-sm">Activer ou désactiver toutes les alertes</p>
                  </div>
                  <Switch
                    checked={alertForm.is_active}
                    onCheckedChange={(checked) => setAlertForm(prev => ({ ...prev, is_active: checked }))}
                  />
                </div>

                <Button
                  onClick={handleSaveAlertConfig}
                  className="w-full bg-orange-500 hover:bg-orange-600"
                  disabled={automatedTests.loading}
                >
                  {automatedTests.loading ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Sauvegarder la configuration
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Schedule Modal */}
      <Dialog open={showScheduleModal} onOpenChange={setShowScheduleModal}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle>Nouvelle Planification</DialogTitle>
            <DialogDescription className="text-slate-400">
              Configurez une exécution automatique des tests
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Name */}
            <div className="space-y-2">
              <Label>Nom de la planification</Label>
              <Input
                value={newSchedule.name}
                onChange={(e) => setNewSchedule(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Ex: Tests quotidiens du matin"
                className="bg-slate-800 border-slate-700"
              />
            </div>

            {/* Time */}
            <div className="space-y-2">
              <Label>Heure d'exécution</Label>
              <Input
                type="time"
                value={newSchedule.scheduledTime}
                onChange={(e) => setNewSchedule(prev => ({ ...prev, scheduledTime: e.target.value }))}
                className="bg-slate-800 border-slate-700"
              />
            </div>

            {/* Days */}
            <div className="space-y-2">
              <Label>Jours de la semaine</Label>
              <div className="flex flex-wrap gap-2">
                {DAYS_OF_WEEK.map((day) => (
                  <button
                    key={day.id}
                    onClick={() => {
                      setNewSchedule(prev => ({
                        ...prev,
                        daysOfWeek: prev.daysOfWeek.includes(day.id)
                          ? prev.daysOfWeek.filter(d => d !== day.id)
                          : [...prev.daysOfWeek, day.id]
                      }));
                    }}
                    className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                      newSchedule.daysOfWeek.includes(day.id)
                        ? 'bg-orange-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    {day.short}
                  </button>
                ))}
              </div>
            </div>

            {/* Tests */}
            <div className="space-y-2">
              <Label>Tests à exécuter</Label>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {TEST_TYPES.map((test) => (
                  <div
                    key={test.id}
                    className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg"
                  >
                    <Checkbox
                      checked={newSchedule.testTypes.includes(test.id)}
                      onCheckedChange={(checked) => {
                        setNewSchedule(prev => ({
                          ...prev,
                          testTypes: checked
                            ? [...prev.testTypes, test.id]
                            : prev.testTypes.filter(t => t !== test.id)
                        }));
                      }}
                    />
                    <div>
                      <p className="text-white text-sm">{test.name}</p>
                      <p className="text-slate-400 text-xs">{test.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowScheduleModal(false)}
              className="border-slate-700"
            >
              Annuler
            </Button>
            <Button
              onClick={handleCreateSchedule}
              className="bg-orange-500 hover:bg-orange-600"
              disabled={automatedTests.loading}
            >
              {automatedTests.loading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Plus className="w-4 h-4 mr-2" />
              )}
              Créer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
};

export default SystemHealthDashboard;
