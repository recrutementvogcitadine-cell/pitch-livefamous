import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Heart, 
  MessageCircle, 
  Trash2, 
  ArrowLeft, 
  Search, 
  Grid, 
  List,
  Star,
  Store,
  Clock,
  Share2,
  CheckCircle,
  XCircle,
  Sparkles,
  TrendingUp,
  Package,
  Phone
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useAppContext, WishlistItem } from '@/contexts/AppContext';
import { formatPrice } from '@/data/mockData';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import ContactSellerModal from '@/components/ContactSellerModal';
import { toast } from '@/components/ui/use-toast';

const Wishlist: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { 
    wishlist, 
    wishlistLoading, 
    removeFromWishlist
  } = useAppContext();

  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'date' | 'price-low' | 'price-high' | 'name'>('date');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [removingItems, setRemovingItems] = useState<Set<string>>(new Set());
  const [selectedProductForContact, setSelectedProductForContact] = useState<WishlistItem | null>(null);
  const [showContactModal, setShowContactModal] = useState(false);

  // Get unique categories from wishlist
  const categories = ['all', ...new Set(wishlist.map(item => item.product_category).filter(Boolean))];

  // Filter and sort wishlist
  const filteredWishlist = wishlist
    .filter(item => {
      const matchesSearch = item.product_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           item.product_seller.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategory === 'all' || item.product_category === filterCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.product_price - b.product_price;
        case 'price-high':
          return b.product_price - a.product_price;
        case 'name':
          return a.product_name.localeCompare(b.product_name);
        default:
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      }
    });

  const handleRemoveItem = async (productId: string) => {
    setRemovingItems(prev => new Set(prev).add(productId));
    await removeFromWishlist(productId);
    setRemovingItems(prev => {
      const newSet = new Set(prev);
      newSet.delete(productId);
      return newSet;
    });
    setSelectedItems(prev => prev.filter(id => id !== productId));
  };

  const handleContactSeller = (item: WishlistItem) => {
    setSelectedProductForContact(item);
    setShowContactModal(true);
  };

  const handleRemoveSelected = async () => {
    for (const productId of selectedItems) {
      await removeFromWishlist(productId);
    }
    setSelectedItems([]);
  };

  const toggleSelectItem = (productId: string) => {
    setSelectedItems(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const toggleSelectAll = () => {
    if (selectedItems.length === filteredWishlist.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(filteredWishlist.map(item => item.product_id));
    }
  };

  const handleShare = (item: WishlistItem) => {
    if (navigator.share) {
      navigator.share({
        title: item.product_name,
        text: `Découvrez ${item.product_name} sur PITCH!`,
        url: window.location.origin,
      });
    } else {
      navigator.clipboard.writeText(window.location.origin);
      toast({
        title: "Lien copié",
        description: "Le lien a été copié dans le presse-papier",
      });
    }
  };


  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Aujourd'hui";
    if (diffDays === 1) return "Hier";
    if (diffDays < 7) return `Il y a ${diffDays} jours`;
    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  };

  const getDiscountPercentage = (price: number, originalPrice?: number) => {
    if (!originalPrice || originalPrice <= price) return 0;
    return Math.round(((originalPrice - price) / originalPrice) * 100);
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header 
        onAuthClick={() => setShowAuthModal(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="pt-24 lg:pt-28 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="mb-8">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-sm text-slate-400 mb-4">
              <button 
                onClick={() => navigate('/')}
                className="hover:text-orange-500 transition-colors flex items-center gap-1"
              >
                <ArrowLeft className="w-4 h-4" />
                Accueil
              </button>
              <span>/</span>
              <span className="text-white">Mes Favoris</span>
            </div>

            {/* Title Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-pink-500 to-red-500 flex items-center justify-center">
                  <Heart className="w-8 h-8 text-white" fill="white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-white">Mes Favoris</h1>
                  <p className="text-slate-400">
                    {wishlist.length} produit{wishlist.length > 1 ? 's' : ''} sauvegardé{wishlist.length > 1 ? 's' : ''}
                  </p>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="flex items-center gap-4">
                <div className="px-4 py-2 bg-slate-800/50 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <span className="text-slate-400 text-sm">Valeur totale:</span>
                    <span className="text-white font-semibold">
                      {formatPrice(wishlist.reduce((sum, item) => sum + item.product_price, 0))}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Toolbar */}
          {wishlist.length > 0 && (
            <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-800 p-4 mb-6">
              <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
                {/* Left Side - Search & Filters */}
                <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
                  {/* Search */}
                  <div className="relative flex-1 lg:flex-none lg:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Rechercher dans les favoris..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                    />
                  </div>

                  {/* Category Filter */}
                  <select
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                    className="px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>
                        {cat === 'all' ? 'Toutes catégories' : cat}
                      </option>
                    ))}
                  </select>

                  {/* Sort */}
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="date">Plus récents</option>
                    <option value="price-low">Prix croissant</option>
                    <option value="price-high">Prix décroissant</option>
                    <option value="name">Nom A-Z</option>
                  </select>
                </div>

                {/* Right Side - View & Actions */}
                <div className="flex items-center gap-3 w-full lg:w-auto justify-between lg:justify-end">
                  {/* View Toggle */}
                  <div className="flex items-center bg-slate-800 rounded-xl p-1">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-orange-500 text-white' : 'text-slate-400 hover:text-white'}`}
                    >
                      <Grid className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-orange-500 text-white' : 'text-slate-400 hover:text-white'}`}
                    >
                      <List className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Bulk Actions */}
                  {selectedItems.length > 0 && (
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400 text-sm">{selectedItems.length} sélectionné(s)</span>
                      <button
                        onClick={handleRemoveSelected}
                        className="px-3 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors text-sm flex items-center gap-1"
                      >
                        <Trash2 className="w-4 h-4" />
                        Supprimer
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Select All */}
              <div className="mt-4 pt-4 border-t border-slate-700/50 flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedItems.length === filteredWishlist.length && filteredWishlist.length > 0}
                  onChange={toggleSelectAll}
                  className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-orange-500 focus:ring-orange-500"
                />
                <span className="text-slate-400 text-sm">Sélectionner tout ({filteredWishlist.length})</span>
              </div>
            </div>
          )}

          {/* Content */}
          {wishlistLoading ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-16 h-16 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin mb-4"></div>
              <p className="text-slate-400">Chargement de vos favoris...</p>
            </div>
          ) : wishlist.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-32 h-32 rounded-full bg-slate-800/50 flex items-center justify-center mb-6">
                <Heart className="w-16 h-16 text-slate-600" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Votre liste de favoris est vide</h2>
              <p className="text-slate-400 text-center max-w-md mb-8">
                Parcourez nos produits et cliquez sur le cœur pour ajouter vos articles préférés à votre liste de favoris.
              </p>
              <button
                onClick={() => navigate('/')}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white rounded-xl font-semibold hover:shadow-lg hover:shadow-orange-500/30 transition-all flex items-center gap-2"
              >
                <Sparkles className="w-5 h-5" />
                Découvrir les produits
              </button>
            </div>
          ) : filteredWishlist.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-24 h-24 rounded-full bg-slate-800/50 flex items-center justify-center mb-4">
                <Search className="w-12 h-12 text-slate-600" />
              </div>
              <h2 className="text-xl font-bold text-white mb-2">Aucun résultat</h2>
              <p className="text-slate-400">Aucun produit ne correspond à votre recherche</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setFilterCategory('all');
                }}
                className="mt-4 text-orange-500 hover:text-orange-400 transition-colors"
              >
                Réinitialiser les filtres
              </button>
            </div>
          ) : viewMode === 'grid' ? (
            /* Grid View */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredWishlist.map((item) => {
                const discount = getDiscountPercentage(item.product_price, item.product_original_price || undefined);
                const isRemoving = removingItems.has(item.product_id);
                const isSelected = selectedItems.includes(item.product_id);

                return (
                  <div
                    key={item.id}
                    className={`group relative bg-slate-900/50 rounded-2xl border overflow-hidden transition-all duration-300 ${
                      isSelected ? 'border-orange-500 ring-2 ring-orange-500/30' : 'border-slate-800 hover:border-slate-700'
                    } ${isRemoving ? 'opacity-50 scale-95' : ''}`}
                  >
                    {/* Selection Checkbox */}
                    <div className="absolute top-3 left-3 z-10">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectItem(item.product_id)}
                        className="w-5 h-5 rounded border-slate-600 bg-slate-800/80 text-orange-500 focus:ring-orange-500 cursor-pointer"
                      />
                    </div>

                    {/* Discount Badge */}
                    {discount > 0 && (
                      <div className="absolute top-3 right-3 z-10 px-2 py-1 bg-red-500 text-white text-xs font-bold rounded-lg">
                        -{discount}%
                      </div>
                    )}

                    {/* Image */}
                    <div className="relative aspect-square overflow-hidden">
                      <img
                        src={item.product_image}
                        alt={item.product_name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      
                      {/* Availability Overlay */}
                      {!item.is_available && (
                        <div className="absolute inset-0 bg-slate-900/80 flex items-center justify-center">
                          <div className="text-center">
                            <XCircle className="w-10 h-10 text-red-400 mx-auto mb-2" />
                            <span className="text-red-400 font-medium">Indisponible</span>
                          </div>
                        </div>
                      )}

                      {/* Quick Actions Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleContactSeller(item)}
                            disabled={!item.is_available}
                            className="px-4 py-2 bg-green-500 text-white rounded-xl font-medium hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                          >
                            <MessageCircle className="w-4 h-4" />
                            Contacter
                          </button>
                          <button
                            onClick={() => handleShare(item)}
                            className="p-2 bg-slate-800 text-white rounded-xl hover:bg-slate-700 transition-colors"
                          >
                            <Share2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleRemoveItem(item.product_id)}
                            disabled={isRemoving}
                            className="p-2 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="p-4">
                      {/* Category & Date */}
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-orange-500 font-medium">{item.product_category}</span>
                        <span className="text-xs text-slate-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatDate(item.created_at)}
                        </span>
                      </div>

                      {/* Product Name */}
                      <h3 className="text-white font-semibold mb-2 line-clamp-2 group-hover:text-orange-400 transition-colors">
                        {item.product_name}
                      </h3>

                      {/* Seller */}
                      <div className="flex items-center gap-2 mb-3">
                        <Store className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-400 text-sm">{item.product_seller}</span>
                      </div>

                      {/* Rating */}
                      <div className="flex items-center gap-1 mb-3">
                        <Star className="w-4 h-4 text-yellow-500" fill="#eab308" />
                        <span className="text-white text-sm font-medium">{item.product_rating}</span>
                        <span className="text-slate-500 text-sm">({item.product_reviews} avis)</span>
                      </div>

                      {/* Price */}
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <span className="text-xl font-bold text-white">{formatPrice(item.product_price)}</span>
                          {item.product_original_price && item.product_original_price > item.product_price && (
                            <span className="text-slate-500 text-sm line-through ml-2">
                              {formatPrice(item.product_original_price)}
                            </span>
                          )}
                        </div>
                        {item.is_available ? (
                          <span className="flex items-center gap-1 text-green-400 text-xs">
                            <CheckCircle className="w-3 h-3" />
                            En stock
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-red-400 text-xs">
                            <XCircle className="w-3 h-3" />
                            Rupture
                          </span>
                        )}
                      </div>

                      {/* Contact Buttons */}
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleContactSeller(item)}
                          disabled={!item.is_available}
                          className="flex-1 py-2 bg-green-500/20 text-green-400 rounded-lg text-xs font-medium hover:bg-green-500/30 transition-colors flex items-center justify-center gap-1 disabled:opacity-50"
                        >
                          <MessageCircle className="w-3 h-3" />
                          WhatsApp
                        </button>
                        <button
                          onClick={() => handleContactSeller(item)}
                          disabled={!item.is_available}
                          className="flex-1 py-2 bg-blue-500/20 text-blue-400 rounded-lg text-xs font-medium hover:bg-blue-500/30 transition-colors flex items-center justify-center gap-1 disabled:opacity-50"
                        >
                          <Phone className="w-3 h-3" />
                          Appeler
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* List View */
            <div className="space-y-4">
              {filteredWishlist.map((item) => {
                const discount = getDiscountPercentage(item.product_price, item.product_original_price || undefined);
                const isRemoving = removingItems.has(item.product_id);
                const isSelected = selectedItems.includes(item.product_id);

                return (
                  <div
                    key={item.id}
                    className={`group flex flex-col sm:flex-row gap-4 bg-slate-900/50 rounded-2xl border p-4 transition-all duration-300 ${
                      isSelected ? 'border-orange-500 ring-2 ring-orange-500/30' : 'border-slate-800 hover:border-slate-700'
                    } ${isRemoving ? 'opacity-50' : ''}`}
                  >
                    {/* Checkbox */}
                    <div className="flex items-start">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectItem(item.product_id)}
                        className="w-5 h-5 rounded border-slate-600 bg-slate-800 text-orange-500 focus:ring-orange-500 cursor-pointer mt-1"
                      />
                    </div>

                    {/* Image */}
                    <div className="relative w-full sm:w-40 h-40 rounded-xl overflow-hidden flex-shrink-0">
                      <img
                        src={item.product_image}
                        alt={item.product_name}
                        className="w-full h-full object-cover"
                      />
                      {discount > 0 && (
                        <div className="absolute top-2 left-2 px-2 py-1 bg-red-500 text-white text-xs font-bold rounded-lg">
                          -{discount}%
                        </div>
                      )}
                      {!item.is_available && (
                        <div className="absolute inset-0 bg-slate-900/80 flex items-center justify-center">
                          <span className="text-red-400 font-medium text-sm">Indisponible</span>
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          {/* Category & Date */}
                          <div className="flex items-center gap-3 mb-1">
                            <span className="text-xs text-orange-500 font-medium">{item.product_category}</span>
                            <span className="text-xs text-slate-500 flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {formatDate(item.created_at)}
                            </span>
                          </div>

                          {/* Product Name */}
                          <h3 className="text-lg text-white font-semibold mb-1 truncate group-hover:text-orange-400 transition-colors">
                            {item.product_name}
                          </h3>

                          {/* Seller */}
                          <div className="flex items-center gap-2 mb-2">
                            <Store className="w-4 h-4 text-slate-400" />
                            <span className="text-slate-400 text-sm">{item.product_seller}</span>
                          </div>

                          {/* Rating */}
                          <div className="flex items-center gap-1 mb-3">
                            <Star className="w-4 h-4 text-yellow-500" fill="#eab308" />
                            <span className="text-white text-sm font-medium">{item.product_rating}</span>
                            <span className="text-slate-500 text-sm">({item.product_reviews} avis)</span>
                            {item.is_available ? (
                              <span className="ml-3 flex items-center gap-1 text-green-400 text-xs">
                                <CheckCircle className="w-3 h-3" />
                                En stock
                              </span>
                            ) : (
                              <span className="ml-3 flex items-center gap-1 text-red-400 text-xs">
                                <XCircle className="w-3 h-3" />
                                Rupture
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Price */}
                        <div className="text-right">
                          <span className="text-2xl font-bold text-white">{formatPrice(item.product_price)}</span>
                          {item.product_original_price && item.product_original_price > item.product_price && (
                            <div className="text-slate-500 text-sm line-through">
                              {formatPrice(item.product_original_price)}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-3 mt-4">
                        <button
                          onClick={() => handleContactSeller(item)}
                          disabled={!item.is_available}
                          className="flex-1 sm:flex-none px-6 py-2.5 bg-green-500 text-white rounded-xl font-medium hover:bg-green-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                        >
                          <MessageCircle className="w-4 h-4" />
                          Contacter le vendeur
                        </button>
                        <button
                          onClick={() => handleShare(item)}
                          className="p-2.5 bg-slate-800 text-slate-400 rounded-xl hover:bg-slate-700 hover:text-white transition-colors"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleRemoveItem(item.product_id)}
                          disabled={isRemoving}
                          className="p-2.5 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Info Banner */}
          {wishlist.length > 0 && (
            <div className="mt-10 p-6 bg-slate-900/50 rounded-2xl border border-slate-700">
              <div className="flex flex-col md:flex-row items-center gap-4 text-center md:text-left">
                <div className="w-16 h-16 bg-green-500/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <MessageCircle className="w-8 h-8 text-green-500" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-semibold text-lg mb-1">Achetez directement auprès des vendeurs</h3>
                  <p className="text-slate-400 text-sm">
                    Contactez les vendeurs via WhatsApp ou téléphone pour négocier et finaliser vos achats. 
                    Les transactions se font directement entre vous et le vendeur.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Recommendations Section */}
          {wishlist.length > 0 && (
            <div className="mt-16">
              <div className="flex items-center gap-3 mb-6">
                <Sparkles className="w-6 h-6 text-orange-500" />
                <h2 className="text-2xl font-bold text-white">Vous pourriez aussi aimer</h2>
              </div>
              <div className="bg-slate-900/30 rounded-2xl border border-slate-800 p-8 text-center">
                <Package className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400">Les recommandations personnalisées arrivent bientôt!</p>
                <button
                  onClick={() => navigate('/')}
                  className="mt-4 text-orange-500 hover:text-orange-400 transition-colors"
                >
                  Explorer tous les produits
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />

      {/* Modals */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      
      {selectedProductForContact && (
        <ContactSellerModal
          isOpen={showContactModal}
          onClose={() => {
            setShowContactModal(false);
            setSelectedProductForContact(null);
          }}
          seller={{
            name: selectedProductForContact.product_seller,
            phone: '+2250700000000',
            whatsapp: '+2250700000000',
            location: 'Abidjan, Côte d\'Ivoire',
            rating: selectedProductForContact.product_rating,
            verified: true,
            responseTime: 'Répond en ~15 min'
          }}
          product={{
            name: selectedProductForContact.product_name,
            price: selectedProductForContact.product_price,
            image: selectedProductForContact.product_image
          }}
        />
      )}
    </div>
  );
};

export default Wishlist;
