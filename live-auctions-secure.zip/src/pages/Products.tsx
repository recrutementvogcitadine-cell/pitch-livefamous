import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  SlidersHorizontal, 
  Grid3X3, 
  LayoutList,
  Heart,
  ShoppingBag,
  MessageCircle,
  Eye,
  Star,
  Package,
  Search as SearchIcon
} from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import { ProductSearchBar } from '@/components/ProductSearchBar';
import { ProductFilters, MobileFiltersModal } from '@/components/ProductFilters';
import { useProductSearch } from '@/hooks/useProductSearch';
import { products as mockProducts, formatPrice, Product } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { useAppContext } from '@/contexts/AppContext';
import ContactSellerModal from '@/components/ContactSellerModal';
import OrderFormModal from '@/components/OrderFormModal';
import { toast } from '@/components/ui/use-toast';

// Extended products list for better search experience
const extendedProducts: Product[] = [
  ...mockProducts,
  { id: '9', name: 'Samsung Galaxy S24 Ultra', price: 780000, originalPrice: 850000, image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400', seller: 'TechStore CI', rating: 4.9, reviews: 156, category: 'Électronique' },
  { id: '10', name: 'Robe Wax Élégante', price: 35000, image: 'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=400', seller: 'Awa Fashion', rating: 4.7, reviews: 89, category: 'Mode' },
  { id: '11', name: 'Bracelet Or 18 Carats', price: 125000, originalPrice: 150000, image: 'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=400', seller: 'Bijoux d\'Or', rating: 4.8, reviews: 45, category: 'Bijoux' },
  { id: '12', name: 'Machine à Laver LG 8kg', price: 350000, image: 'https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=400', seller: 'Maison Plus', rating: 4.5, reviews: 78, category: 'Maison' },
  { id: '13', name: 'Adidas Ultraboost 22', price: 95000, originalPrice: 120000, image: 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=400', seller: 'SneakerHead ABJ', rating: 4.8, reviews: 234, category: 'Chaussures' },
  { id: '14', name: 'Sérum Anti-âge Premium', price: 45000, image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400', seller: 'Beauty Queen', rating: 4.6, reviews: 67, category: 'Beauté' },
  { id: '15', name: 'Montre Apple Watch Series 9', price: 450000, originalPrice: 520000, image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=400', seller: 'Chrono Luxe', rating: 4.9, reviews: 189, category: 'Accessoires' },
  { id: '16', name: 'Table Basse Design', price: 180000, image: 'https://images.unsplash.com/photo-1533090481720-856c6e3c1fdc?w=400', seller: 'Déco Intérieur', rating: 4.3, reviews: 34, category: 'Maison' },
  { id: '17', name: 'Parfum Dior Sauvage', price: 85000, originalPrice: 95000, image: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?w=400', seller: 'Parfum Palace', rating: 4.8, reviews: 267, category: 'Beauté' },
  { id: '18', name: 'Housse Siège Auto Cuir', price: 65000, image: 'https://images.unsplash.com/photo-1489824904134-891ab64532f1?w=400', seller: 'Auto Style CI', rating: 4.4, reviews: 56, category: 'Auto' },
  { id: '19', name: 'Sac Louis Vuitton Neverfull', price: 950000, image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400', seller: 'Luxe Bags', rating: 4.9, reviews: 123, category: 'Mode' },
  { id: '20', name: 'Drone DJI Mini 3 Pro', price: 580000, originalPrice: 650000, image: 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=400', seller: 'Gadget World', rating: 4.7, reviews: 89, category: 'Électronique' },
];

const Products: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useAppContext();
  
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [productForOrder, setProductForOrder] = useState<any>(null);

  // Initialize search from URL params
  const initialQuery = searchParams.get('q') || '';
  const initialCategory = searchParams.get('category') || '';

  const {
    searchQuery,
    setSearchQuery,
    filters,
    updateFilters,
    resetFilters,
    toggleCategory,
    filteredProducts,
    suggestions,
    recentSearches,
    saveRecentSearch,
    clearRecentSearches,
    removeRecentSearch,
    isSearching,
    allCategories,
    priceRange,
    hasActiveFilters,
    totalResults,
  } = useProductSearch(extendedProducts);

  // Set initial search query from URL
  useEffect(() => {
    if (initialQuery) {
      setSearchQuery(initialQuery);
    }
    if (initialCategory) {
      updateFilters({ categories: [initialCategory] });
    }
  }, []);

  // Update URL when search changes
  const handleSearch = (query: string) => {
    saveRecentSearch(query);
    if (query) {
      setSearchParams({ q: query });
    } else {
      setSearchParams({});
    }
  };

  const handleOpenAuth = (tab: 'login' | 'register' = 'login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const handleWishlistToggle = async (product: Product) => {
    if (!user) {
      handleOpenAuth('login');
      return;
    }

    if (isInWishlist(product.id)) {
      await removeFromWishlist(product.id);
    } else {
      await addToWishlist(product);
    }
  };

  const handleContactSeller = (product: Product) => {
    setSelectedProduct(product);
    setShowContactModal(true);
  };

  const handleOrder = (product: Product) => {
    if (!user) {
      handleOpenAuth('login');
      return;
    }

    setProductForOrder({
      id: product.id,
      name: product.name,
      price: product.price,
      originalPrice: product.originalPrice,
      image: product.image,
      seller: product.seller,
      sellerPhone: '+2250700000000'
    });
    setShowOrderModal(true);
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <Header 
        onAuthClick={() => handleOpenAuth('login')}
        searchQuery=""
        onSearchChange={() => {}}
      />

      {/* Main Content */}
      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="mb-8">
            <button
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-4"
            >
              <ArrowLeft className="w-5 h-5" />
              Retour
            </button>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              Rechercher des{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-500">
                Produits
              </span>
            </h1>
            <p className="text-slate-400">
              Trouvez les meilleurs produits de nos vendeurs vérifiés
            </p>
          </div>

          {/* Search Bar */}
          <div className="mb-8">
            <ProductSearchBar
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onSearch={handleSearch}
              suggestions={suggestions}
              recentSearches={recentSearches}
              onClearRecentSearches={clearRecentSearches}
              onRemoveRecentSearch={removeRecentSearch}
              isSearching={isSearching}
            />
          </div>

          {/* Active Filters Tags */}
          {hasActiveFilters && (
            <div className="flex flex-wrap gap-2 mb-6">
              {filters.categories.map(category => (
                <button
                  key={category}
                  onClick={() => toggleCategory(category)}
                  className="flex items-center gap-1 px-3 py-1.5 bg-orange-500/20 text-orange-400 rounded-full text-sm hover:bg-orange-500/30 transition-colors"
                >
                  {category}
                  <span className="ml-1">×</span>
                </button>
              ))}
              {filters.minRating && (
                <button
                  onClick={() => updateFilters({ minRating: null })}
                  className="flex items-center gap-1 px-3 py-1.5 bg-yellow-500/20 text-yellow-400 rounded-full text-sm hover:bg-yellow-500/30 transition-colors"
                >
                  <Star className="w-3 h-3 fill-current" />
                  {filters.minRating}+ étoiles
                  <span className="ml-1">×</span>
                </button>
              )}
              {(filters.minPrice || filters.maxPrice) && (
                <button
                  onClick={() => updateFilters({ minPrice: null, maxPrice: null })}
                  className="flex items-center gap-1 px-3 py-1.5 bg-green-500/20 text-green-400 rounded-full text-sm hover:bg-green-500/30 transition-colors"
                >
                  {formatPrice(filters.minPrice || 0)} - {formatPrice(filters.maxPrice || priceRange.max)}
                  <span className="ml-1">×</span>
                </button>
              )}
            </div>
          )}

          {/* Main Layout */}
          <div className="flex gap-8">
            {/* Sidebar Filters - Desktop */}
            <aside className="hidden lg:block w-72 flex-shrink-0">
              <div className="sticky top-24">
                <ProductFilters
                  filters={filters}
                  onUpdateFilters={updateFilters}
                  onResetFilters={resetFilters}
                  onToggleCategory={toggleCategory}
                  allCategories={allCategories}
                  priceRange={priceRange}
                  hasActiveFilters={hasActiveFilters}
                  totalResults={totalResults}
                />
              </div>
            </aside>

            {/* Products Grid */}
            <div className="flex-1">
              {/* Toolbar */}
              <div className="flex items-center justify-between mb-6">
                <p className="text-slate-400">
                  <span className="text-white font-semibold">{totalResults}</span> produit{totalResults !== 1 ? 's' : ''} trouvé{totalResults !== 1 ? 's' : ''}
                </p>
                <div className="flex items-center gap-3">
                  {/* Mobile Filter Button */}
                  <button
                    onClick={() => setShowMobileFilters(true)}
                    className="lg:hidden flex items-center gap-2 px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white hover:border-orange-500 transition-colors"
                  >
                    <SlidersHorizontal className="w-5 h-5" />
                    Filtres
                    {hasActiveFilters && (
                      <span className="w-2 h-2 bg-orange-500 rounded-full" />
                    )}
                  </button>

                  {/* View Mode Toggle */}
                  <div className="hidden sm:flex items-center bg-slate-800 rounded-xl p-1">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`p-2 rounded-lg transition-colors ${
                        viewMode === 'grid' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Grid3X3 className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={`p-2 rounded-lg transition-colors ${
                        viewMode === 'list' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <LayoutList className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* No Results */}
              {filteredProducts.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                    <SearchIcon className="w-10 h-10 text-slate-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Aucun produit trouvé</h3>
                  <p className="text-slate-400 mb-6">
                    Essayez de modifier vos filtres ou votre recherche
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      resetFilters();
                    }}
                    className="px-6 py-3 bg-orange-500 text-white font-semibold rounded-xl hover:bg-orange-600 transition-colors"
                  >
                    Réinitialiser la recherche
                  </button>
                </div>
              )}

              {/* Products Grid */}
              {filteredProducts.length > 0 && (
                <div className={
                  viewMode === 'grid'
                    ? 'grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6'
                    : 'space-y-4'
                }>
                  {filteredProducts.map((product) => {
                    const inWishlist = isInWishlist(product.id);

                    if (viewMode === 'list') {
                      return (
                        <div
                          key={product.id}
                          className="flex gap-4 bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden hover:border-orange-500/50 transition-all p-4"
                        >
                          <Link to={`/products/${product.id}`} className="flex-shrink-0">
                            <img
                              src={product.image}
                              alt={product.name}
                              className="w-32 h-32 object-cover rounded-xl"
                            />
                          </Link>
                          <div className="flex-1 min-w-0">
                            <p className="text-slate-400 text-sm">{product.seller}</p>
                            <Link to={`/products/${product.id}`}>
                              <h3 className="text-white font-medium mb-2 line-clamp-1 hover:text-orange-400 transition-colors">{product.name}</h3>
                            </Link>
                            <div className="flex items-center gap-1 mb-2">
                              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                              <span className="text-white text-sm">{product.rating}</span>
                              <span className="text-slate-400 text-sm">({product.reviews})</span>
                            </div>
                            <div className="flex items-center gap-2 mb-3">
                              <span className="text-orange-500 font-bold">{formatPrice(product.price)}</span>
                              {product.originalPrice && (
                                <span className="text-slate-500 text-sm line-through">{formatPrice(product.originalPrice)}</span>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <Link
                                to={`/products/${product.id}`}
                                className="px-4 py-2 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl text-sm"
                              >
                                Voir détails
                              </Link>
                              <button
                                onClick={() => handleContactSeller(product)}
                                className="px-4 py-2 bg-green-500/20 text-green-400 rounded-xl text-sm"
                              >
                                WhatsApp
                              </button>
                              <button
                                onClick={() => handleWishlistToggle(product)}
                                className={`p-2 rounded-xl transition-colors ${
                                  inWishlist ? 'bg-red-500/20 text-red-400' : 'bg-slate-700 text-slate-400 hover:text-white'
                                }`}
                              >
                                <Heart className="w-5 h-5" fill={inWishlist ? 'currentColor' : 'none'} />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    }



                    return (
                      <Link
                        key={product.id}
                        to={`/products/${product.id}`}
                        className="group bg-slate-900/50 rounded-2xl overflow-hidden border border-slate-700 hover:border-orange-500/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-orange-500/10"
                      >
                        {/* Image */}
                        <div className="relative aspect-square overflow-hidden">
                          <img 
                            src={product.image} 
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                          
                          {/* Discount Badge */}
                          {product.originalPrice && (
                            <div className="absolute top-3 left-3">
                              <span className="px-2 py-1 bg-red-500 text-white text-xs font-bold rounded-full">
                                -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                              </span>
                            </div>
                          )}

                          {/* Wishlist Button */}
                          <button 
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              handleWishlistToggle(product);
                            }}
                            className={`absolute top-3 right-3 w-9 h-9 backdrop-blur rounded-full flex items-center justify-center transition-all ${
                              inWishlist 
                                ? 'bg-red-500 text-white' 
                                : 'bg-white/10 text-white opacity-0 group-hover:opacity-100 hover:bg-red-500'
                            }`}
                          >
                            <Heart className="w-4 h-4" fill={inWishlist ? 'currentColor' : 'none'} />
                          </button>

                          {/* View Details on Hover */}
                          <div className="absolute bottom-3 left-3 right-3 py-2.5 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center gap-2 text-sm">
                            <Eye className="w-4 h-4" />
                            Voir détails
                          </div>
                        </div>

                        {/* Content */}
                        <div className="p-4">
                          <p className="text-slate-400 text-xs mb-1">{product.seller}</p>
                          <h3 className="text-white font-medium text-sm mb-2 line-clamp-2 group-hover:text-orange-400 transition-colors">
                            {product.name}
                          </h3>
                          
                          {/* Rating */}
                          <div className="flex items-center gap-1 mb-2">
                            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                            <span className="text-white text-sm">{product.rating}</span>
                            <span className="text-slate-400 text-sm">({product.reviews})</span>
                          </div>

                          {/* Price */}
                          <div className="flex items-center gap-2 mb-3">
                            <span className="text-orange-500 font-bold">{formatPrice(product.price)}</span>
                            {product.originalPrice && (
                              <span className="text-slate-500 text-sm line-through">{formatPrice(product.originalPrice)}</span>
                            )}
                          </div>

                          {/* Quick Action Buttons */}
                          <div className="flex gap-2">
                            <button
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                handleContactSeller(product);
                              }}
                              className="flex-1 py-2 bg-green-500/20 text-green-400 rounded-lg text-xs font-medium hover:bg-green-500/30 transition-colors flex items-center justify-center gap-1"
                            >
                              <MessageCircle className="w-3 h-3" />
                              WhatsApp
                            </button>
                            <button
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                handleOrder(product);
                              }}
                              className="flex-1 py-2 bg-orange-500/20 text-orange-400 rounded-lg text-xs font-medium hover:bg-orange-500/30 transition-colors flex items-center justify-center gap-1"
                            >
                              <ShoppingBag className="w-3 h-3" />
                              Commander
                            </button>
                          </div>
                        </div>
                      </Link>
                    );

                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Filters Modal */}
      <MobileFiltersModal
        isOpen={showMobileFilters}
        onClose={() => setShowMobileFilters(false)}
        filters={filters}
        onUpdateFilters={updateFilters}
        onResetFilters={resetFilters}
        onToggleCategory={toggleCategory}
        allCategories={allCategories}
        priceRange={priceRange}
        hasActiveFilters={hasActiveFilters}
        totalResults={totalResults}
      />

      {/* Auth Modal */}
      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialTab={authModalTab}
      />

      {/* Contact Seller Modal */}
      {selectedProduct && (
        <ContactSellerModal
          isOpen={showContactModal}
          onClose={() => {
            setShowContactModal(false);
            setSelectedProduct(null);
          }}
          seller={{
            name: selectedProduct.seller,
            phone: '+2250700000000',
            whatsapp: '+2250700000000',
            location: 'Abidjan, Côte d\'Ivoire',
            rating: 4.8,
            verified: true,
            responseTime: 'Répond en ~15 min'
          }}
          product={{
            name: selectedProduct.name,
            price: selectedProduct.price,
            image: selectedProduct.image
          }}
        />
      )}

      {/* Order Form Modal */}
      <OrderFormModal
        isOpen={showOrderModal}
        onClose={() => {
          setShowOrderModal(false);
          setProductForOrder(null);
        }}
        product={productForOrder}
        onOrderSuccess={(orderId) => {
          toast({
            title: "Commande passée!",
            description: `Votre commande ${orderId.slice(0, 8).toUpperCase()} a été enregistrée`
          });
        }}
      />
    </div>
  );
};

export default Products;
