import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Play, Pause, Video, VideoOff, Mic, MicOff, Package, MessageCircle,
  ShoppingCart, CreditCard, CheckCircle2, XCircle, Loader2, AlertTriangle,
  RefreshCw, ChevronDown, ChevronUp, ArrowLeft, Trash2, Plus, Send,
  Users, Clock, Zap, Settings, Eye, Radio, Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useAgoraStream } from '@/hooks/useAgoraStream';
import { useLiveStream } from '@/hooks/useLiveStream';
import { useOrders } from '@/hooks/useOrders';
import { usePayment, PAYMENT_METHODS } from '@/hooks/usePayment';
import AgoraVideoPlayer from '@/components/AgoraVideoPlayer';
import AuthModal from '@/components/AuthModal';

// Test step status types
type StepStatus = 'pending' | 'running' | 'success' | 'error' | 'warning';

interface TestStep {
  id: string;
  name: string;
  description: string;
  status: StepStatus;
  message?: string;
  duration?: number;
  details?: string[];
}

interface TestLog {
  id: string;
  timestamp: Date;
  type: 'info' | 'success' | 'error' | 'warning';
  message: string;
  details?: any;
}

interface TestProduct {
  id: string;
  name: string;
  price: number;
  image: string;
  isHighlighted: boolean;
}

const LiveTestPage: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, profile } = useAuth();
  
  // Hooks
  const agoraStream = useAgoraStream();
  const liveStream = useLiveStream();
  const orders = useOrders();
  const payment = usePayment();

  // State
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isTestRunning, setIsTestRunning] = useState(false);
  const [currentStreamId, setCurrentStreamId] = useState<string | null>(null);
  const [channelName, setChannelName] = useState(`test-live-${Date.now()}`);
  const [showLogs, setShowLogs] = useState(true);
  const [logs, setLogs] = useState<TestLog[]>([]);
  const [testProducts, setTestProducts] = useState<TestProduct[]>([]);
  const [chatMessages, setChatMessages] = useState<Array<{ id: string; user: string; message: string; time: Date }>>([]);
  const [newMessage, setNewMessage] = useState('');
  const [testOrder, setTestOrder] = useState<any>(null);
  const [testPayment, setTestPayment] = useState<any>(null);
  
  // Video refs
  const localVideoRef = useRef<HTMLDivElement>(null);

  // Test steps
  const [steps, setSteps] = useState<TestStep[]>([
    {
      id: 'agora-init',
      name: '1. Initialisation Agora',
      description: 'Charger le SDK Agora et initialiser le client',

      status: 'pending'
    },
    {
      id: 'agora-join',
      name: '2. Démarrage du Live',
      description: 'Rejoindre le canal en tant que diffuseur et publier les flux audio/vidéo',
      status: 'pending'
    },
    {
      id: 'add-products',
      name: '3. Ajout de Produits',
      description: 'Ajouter des produits au live en temps réel',
      status: 'pending'
    },
    {
      id: 'send-chat',
      name: '4. Envoi de Messages',
      description: 'Envoyer des messages dans le chat du live',
      status: 'pending'
    },
    {
      id: 'place-order',
      name: '5. Passage de Commande',
      description: 'Simuler une commande par un spectateur',
      status: 'pending'
    },
    {
      id: 'confirm-payment',
      name: '6. Confirmation Paiement',
      description: 'Confirmer le paiement de la commande',
      status: 'pending'
    }
  ]);

  // Add log entry
  const addLog = useCallback((type: TestLog['type'], message: string, details?: any) => {
    const log: TestLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      type,
      message,
      details
    };
    setLogs(prev => [log, ...prev]);
  }, []);

  // Update step status
  const updateStep = useCallback((stepId: string, updates: Partial<TestStep>) => {
    setSteps(prev => prev.map(step => 
      step.id === stepId ? { ...step, ...updates } : step
    ));
  }, []);

  // Reset all tests
  const resetTests = useCallback(async () => {
    // Leave Agora if connected
    if (agoraStream.isConnected) {
      await agoraStream.leave();
    }
    
    // Reset state
    setSteps(prev => prev.map(step => ({ ...step, status: 'pending', message: undefined, duration: undefined, details: undefined })));
    setLogs([]);
    setTestProducts([]);
    setChatMessages([]);
    setTestOrder(null);
    setTestPayment(null);
    setCurrentStreamId(null);
    setChannelName(`test-live-${Date.now()}`);
    setIsTestRunning(false);
    
    addLog('info', 'Tests réinitialisés');
  }, [agoraStream, addLog]);

  // Step 1: Initialize Agora
  const runStep1_InitAgora = async (): Promise<boolean> => {
    const startTime = Date.now();
    updateStep('agora-init', { status: 'running', message: 'Chargement du SDK Agora...' });
    addLog('info', 'Démarrage de l\'initialisation Agora...');

    try {
      const success = await agoraStream.initializeClient();
      const duration = Date.now() - startTime;

      if (success) {
        updateStep('agora-init', { 
          status: 'success', 
          message: 'SDK Agora chargé et client initialisé',
          duration,
          details: ['SDK version: 4.20.0', 'Mode: live', 'Codec: VP8']
        });
        addLog('success', `Agora initialisé en ${duration}ms`);
        return true;
      } else {
        throw new Error('Échec de l\'initialisation');
      }
    } catch (error: any) {
      const duration = Date.now() - startTime;
      updateStep('agora-init', { 
        status: 'error', 
        message: error.message || 'Erreur d\'initialisation',
        duration
      });
      addLog('error', `Erreur d'initialisation Agora: ${error.message}`);
      return false;
    }
  };

  // Step 2: Join as Host
  const runStep2_JoinAsHost = async (): Promise<boolean> => {
    const startTime = Date.now();
    updateStep('agora-join', { status: 'running', message: 'Connexion au canal...' });
    addLog('info', `Tentative de connexion au canal: ${channelName}`);

    try {
      const success = await agoraStream.joinAsHost(channelName);
      const duration = Date.now() - startTime;

      if (success) {
        // Create a live stream record
        const streamData = await liveStream.scheduleLive({
          title: `Test Live - ${new Date().toLocaleString('fr-FR')}`,
          description: 'Live de test pour vérification du flux complet',
          category: 'Test'
        });
        
        if (streamData?.id) {
          setCurrentStreamId(streamData.id);
          await liveStream.startLive(streamData.id);
        }

        updateStep('agora-join', { 
          status: 'success', 
          message: 'Connecté en tant que diffuseur',
          duration,
          details: [
            `Canal: ${channelName}`,
            `Vidéo: ${agoraStream.isVideoOff ? 'Désactivée' : 'Activée'}`,
            `Audio: ${agoraStream.isMuted ? 'Muet' : 'Activé'}`,
            `Stream ID: ${streamData?.id || 'N/A'}`
          ]
        });
        addLog('success', `Connecté au canal en ${duration}ms`, { channelName, streamId: streamData?.id });
        return true;
      } else {
        throw new Error('Échec de la connexion');
      }
    } catch (error: any) {
      const duration = Date.now() - startTime;
      updateStep('agora-join', { 
        status: 'error', 
        message: error.message || 'Erreur de connexion',
        duration
      });
      addLog('error', `Erreur de connexion: ${error.message}`);
      return false;
    }
  };

  // Step 3: Add Products
  const runStep3_AddProducts = async (): Promise<boolean> => {
    const startTime = Date.now();
    updateStep('add-products', { status: 'running', message: 'Ajout des produits...' });
    addLog('info', 'Ajout de produits de test au live...');

    try {
      // Simulate adding products
      const mockProducts: TestProduct[] = [
        {
          id: `prod-${Date.now()}-1`,
          name: 'iPhone 15 Pro Max',
          price: 850000,
          image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400',
          isHighlighted: true
        },
        {
          id: `prod-${Date.now()}-2`,
          name: 'Samsung Galaxy S24 Ultra',
          price: 750000,
          image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
          isHighlighted: false
        },
        {
          id: `prod-${Date.now()}-3`,
          name: 'AirPods Pro 2',
          price: 180000,
          image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=400',
          isHighlighted: false
        }
      ];

      // Simulate delay for each product
      for (let i = 0; i < mockProducts.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 300));
        setTestProducts(prev => [...prev, mockProducts[i]]);
        addLog('info', `Produit ajouté: ${mockProducts[i].name}`);
      }

      const duration = Date.now() - startTime;
      updateStep('add-products', { 
        status: 'success', 
        message: `${mockProducts.length} produits ajoutés`,
        duration,
        details: mockProducts.map(p => `${p.name} - ${p.price.toLocaleString()} FCFA`)
      });
      addLog('success', `${mockProducts.length} produits ajoutés en ${duration}ms`);
      return true;
    } catch (error: any) {
      const duration = Date.now() - startTime;
      updateStep('add-products', { 
        status: 'error', 
        message: error.message || 'Erreur d\'ajout de produits',
        duration
      });
      addLog('error', `Erreur d'ajout de produits: ${error.message}`);
      return false;
    }
  };

  // Step 4: Send Chat Messages
  const runStep4_SendChat = async (): Promise<boolean> => {
    const startTime = Date.now();
    updateStep('send-chat', { status: 'running', message: 'Envoi des messages...' });
    addLog('info', 'Envoi de messages de test dans le chat...');

    try {
      const testMessages = [
        { user: 'Marie', message: 'Super live ! Les produits sont magnifiques' },
        { user: 'Jean', message: 'Le iPhone est-il disponible en noir ?' },
        { user: 'Sophie', message: 'Je prends les AirPods !' },
        { user: profile?.full_name || 'Vous', message: 'Merci à tous de nous rejoindre !' }
      ];

      for (const msg of testMessages) {
        await new Promise(resolve => setTimeout(resolve, 400));
        const chatMsg = {
          id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          user: msg.user,
          message: msg.message,
          time: new Date()
        };
        setChatMessages(prev => [...prev, chatMsg]);
        addLog('info', `Message envoyé par ${msg.user}: "${msg.message}"`);
      }

      // Also try to send via the live stream hook
      if (currentStreamId) {
        await liveStream.sendMessage(currentStreamId, 'Message de test automatique');
      }

      const duration = Date.now() - startTime;
      updateStep('send-chat', { 
        status: 'success', 
        message: `${testMessages.length} messages envoyés`,
        duration,
        details: testMessages.map(m => `${m.user}: ${m.message.substring(0, 30)}...`)
      });
      addLog('success', `${testMessages.length} messages envoyés en ${duration}ms`);
      return true;
    } catch (error: any) {
      const duration = Date.now() - startTime;
      updateStep('send-chat', { 
        status: 'error', 
        message: error.message || 'Erreur d\'envoi de messages',
        duration
      });
      addLog('error', `Erreur d'envoi de messages: ${error.message}`);
      return false;
    }
  };

  // Step 5: Place Order
  const runStep5_PlaceOrder = async (): Promise<boolean> => {
    const startTime = Date.now();
    updateStep('place-order', { status: 'running', message: 'Création de la commande...' });
    addLog('info', 'Simulation d\'une commande spectateur...');

    try {
      if (testProducts.length === 0) {
        throw new Error('Aucun produit disponible pour la commande');
      }

      const selectedProduct = testProducts[0];
      const buyerId = user?.id || 'demo-buyer';
      const sellerId = 'demo-seller';

      // Create order items
      const orderItems = [{
        product_id: selectedProduct.id,
        product_name: selectedProduct.name,
        product_image: selectedProduct.image,
        quantity: 1,
        unit_price: selectedProduct.price,
        total_price: selectedProduct.price
      }];

      // Get or create address
      const addresses = await orders.getAddresses(buyerId);
      let addressId = addresses[0]?.id;
      
      if (!addressId) {
        const newAddress = await orders.addAddress(buyerId, {
          name: 'Adresse de test',
          phone: '+225 07 00 00 00 00',
          location: 'Cocody, Abidjan',
          is_default: true
        });
        addressId = newAddress?.id || 'demo-address';
      }

      // Create order
      const order = await orders.createOrder(
        buyerId,
        sellerId,
        orderItems,
        addressId,
        'orange_money',
        'Commande de test depuis le live',
        2500 // Shipping fee
      );

      if (order) {
        setTestOrder(order);
        const duration = Date.now() - startTime;
        updateStep('place-order', { 
          status: 'success', 
          message: `Commande ${order.order_number} créée`,
          duration,
          details: [
            `Numéro: ${order.order_number}`,
            `Produit: ${selectedProduct.name}`,
            `Total: ${order.total.toLocaleString()} FCFA`,
            `Statut: ${orders.getStatusLabel(order.status)}`
          ]
        });
        addLog('success', `Commande créée en ${duration}ms`, { orderId: order.id, orderNumber: order.order_number });
        return true;
      } else {
        throw new Error('Échec de création de la commande');
      }
    } catch (error: any) {
      const duration = Date.now() - startTime;
      updateStep('place-order', { 
        status: 'error', 
        message: error.message || 'Erreur de commande',
        duration
      });
      addLog('error', `Erreur de commande: ${error.message}`);
      return false;
    }
  };

  // Step 6: Confirm Payment
  const runStep6_ConfirmPayment = async (): Promise<boolean> => {
    const startTime = Date.now();
    updateStep('confirm-payment', { status: 'running', message: 'Traitement du paiement...' });
    addLog('info', 'Simulation du paiement...');

    try {
      if (!testOrder) {
        throw new Error('Aucune commande à payer');
      }

      // Process payment
      const paymentResult = await payment.processPayment({
        orderId: testOrder.id,
        amount: testOrder.total,
        currency: 'XOF',
        paymentMethod: 'orange_money',
        phoneNumber: '+225 07 00 00 00 00',
        customerName: profile?.full_name || 'Client Test'
      });

      if (paymentResult.success) {
        setTestPayment(paymentResult);

        // Update order payment status
        await orders.updatePaymentStatus(testOrder.id, 'paid', paymentResult.transactionId);
        await orders.updateOrderStatus(testOrder.id, 'confirmed', 'Paiement confirmé', user?.id || 'system');

        const duration = Date.now() - startTime;
        updateStep('confirm-payment', { 
          status: 'success', 
          message: 'Paiement confirmé',
          duration,
          details: [
            `Transaction: ${paymentResult.transactionId}`,
            `Montant: ${testOrder.total.toLocaleString()} FCFA`,
            `Méthode: Orange Money`,
            `Statut: ${payment.getStatusLabel(paymentResult.status)}`
          ]
        });
        addLog('success', `Paiement confirmé en ${duration}ms`, { transactionId: paymentResult.transactionId });
        return true;
      } else {
        throw new Error(paymentResult.error || 'Échec du paiement');
      }
    } catch (error: any) {
      const duration = Date.now() - startTime;
      updateStep('confirm-payment', { 
        status: 'error', 
        message: error.message || 'Erreur de paiement',
        duration
      });
      addLog('error', `Erreur de paiement: ${error.message}`);
      return false;
    }
  };

  // Run all tests sequentially
  const runAllTests = async () => {
    if (!user) {
      setShowAuthModal(true);
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour exécuter les tests",
        variant: "destructive"
      });
      return;
    }

    setIsTestRunning(true);
    addLog('info', '=== Démarrage des tests complets ===');

    const step1 = await runStep1_InitAgora();
    if (!step1) {
      setIsTestRunning(false);
      return;
    }

    await new Promise(resolve => setTimeout(resolve, 500));

    const step2 = await runStep2_JoinAsHost();
    if (!step2) {
      setIsTestRunning(false);
      return;
    }

    await new Promise(resolve => setTimeout(resolve, 500));

    const step3 = await runStep3_AddProducts();
    if (!step3) {
      setIsTestRunning(false);
      return;
    }

    await new Promise(resolve => setTimeout(resolve, 500));

    const step4 = await runStep4_SendChat();
    if (!step4) {
      setIsTestRunning(false);
      return;
    }

    await new Promise(resolve => setTimeout(resolve, 500));

    const step5 = await runStep5_PlaceOrder();
    if (!step5) {
      setIsTestRunning(false);
      return;
    }

    await new Promise(resolve => setTimeout(resolve, 500));

    const step6 = await runStep6_ConfirmPayment();

    setIsTestRunning(false);
    
    const allSuccess = steps.every(s => s.status === 'success');
    if (allSuccess) {
      addLog('success', '=== Tous les tests ont réussi ! ===');
      toast({
        title: "Tests réussis !",
        description: "Tous les tests du flux live ont été validés avec succès"
      });
    } else {
      addLog('warning', '=== Certains tests ont échoué ===');
    }
  };

  // Send manual chat message
  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    const chatMsg = {
      id: `msg-${Date.now()}`,
      user: profile?.full_name || 'Vous',
      message: newMessage,
      time: new Date()
    };
    setChatMessages(prev => [...prev, chatMsg]);
    addLog('info', `Message manuel envoyé: "${newMessage}"`);
    setNewMessage('');
  };

  // Get status icon
  const getStatusIcon = (status: StepStatus) => {
    switch (status) {
      case 'pending':
        return <div className="w-6 h-6 rounded-full border-2 border-slate-600" />;
      case 'running':
        return <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />;
      case 'success':
        return <CheckCircle2 className="w-6 h-6 text-green-500" />;
      case 'error':
        return <XCircle className="w-6 h-6 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="w-6 h-6 text-yellow-500" />;
    }
  };

  // Get status badge color
  const getStatusBadgeColor = (status: StepStatus) => {
    switch (status) {
      case 'pending': return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
      case 'running': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'success': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'error': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'warning': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    }
  };

  // Calculate test summary
  const testSummary = {
    total: steps.length,
    success: steps.filter(s => s.status === 'success').length,
    error: steps.filter(s => s.status === 'error').length,
    pending: steps.filter(s => s.status === 'pending').length,
    running: steps.filter(s => s.status === 'running').length
  };

  // Play local video when available
  useEffect(() => {
    if (agoraStream.localVideoTrack && localVideoRef.current) {
      agoraStream.localVideoTrack.play(localVideoRef.current);
    }
  }, [agoraStream.localVideoTrack]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/')}
                className="text-slate-400 hover:text-white"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-xl font-bold text-white flex items-center gap-2">
                  <Settings className="w-5 h-5 text-orange-500" />
                  Test du Flux Live Complet
                </h1>
                <p className="text-sm text-slate-400">Vérification de bout en bout du système de live streaming</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Test Summary */}
              <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-slate-800/50 rounded-xl">
                <span className="text-slate-400 text-sm">Tests:</span>
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30">{testSummary.success}</Badge>
                <span className="text-slate-600">/</span>
                <span className="text-white font-medium">{testSummary.total}</span>
              </div>

              <Button
                onClick={resetTests}
                variant="outline"
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
                disabled={isTestRunning}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Réinitialiser
              </Button>

              <Button
                onClick={runAllTests}
                className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white hover:shadow-lg hover:shadow-orange-500/25"
                disabled={isTestRunning}
              >
                {isTestRunning ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Tests en cours...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Lancer tous les tests
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Left Column - Test Steps */}
          <div className="xl:col-span-2 space-y-6">
            {/* Test Steps Card */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-orange-500" />
                  Étapes du Test
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Chaque étape valide une partie du flux live
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {steps.map((step, index) => (
                  <div
                    key={step.id}
                    className={`p-4 rounded-xl border transition-all ${
                      step.status === 'running'
                        ? 'bg-blue-500/10 border-blue-500/30'
                        : step.status === 'success'
                        ? 'bg-green-500/10 border-green-500/30'
                        : step.status === 'error'
                        ? 'bg-red-500/10 border-red-500/30'
                        : 'bg-slate-800/50 border-slate-700'
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 mt-1">
                        {getStatusIcon(step.status)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-4">
                          <h3 className="font-semibold text-white">{step.name}</h3>
                          <div className="flex items-center gap-2">
                            {step.duration && (
                              <span className="text-xs text-slate-500">{step.duration}ms</span>
                            )}
                            <Badge className={getStatusBadgeColor(step.status)}>
                              {step.status === 'pending' && 'En attente'}
                              {step.status === 'running' && 'En cours'}
                              {step.status === 'success' && 'Réussi'}
                              {step.status === 'error' && 'Échec'}
                              {step.status === 'warning' && 'Attention'}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-sm text-slate-400 mt-1">{step.description}</p>
                        {step.message && (
                          <p className={`text-sm mt-2 ${
                            step.status === 'error' ? 'text-red-400' : 
                            step.status === 'success' ? 'text-green-400' : 'text-blue-400'
                          }`}>
                            {step.message}
                          </p>
                        )}
                        {step.details && step.details.length > 0 && (
                          <div className="mt-3 p-3 bg-slate-800/50 rounded-lg">
                            <ul className="text-xs text-slate-400 space-y-1">
                              {step.details.map((detail, i) => (
                                <li key={i} className="flex items-center gap-2">
                                  <span className="w-1 h-1 bg-slate-500 rounded-full" />
                                  {detail}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Live Preview */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Video Preview */}
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-base flex items-center gap-2">
                    <Video className="w-4 h-4 text-orange-500" />
                    Aperçu Vidéo
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-slate-800 rounded-xl overflow-hidden relative">
                    {agoraStream.localVideoTrack ? (
                      <div ref={localVideoRef} className="w-full h-full" />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <VideoOff className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                          <p className="text-slate-500 text-sm">Vidéo non démarrée</p>
                        </div>
                      </div>
                    )}
                    {agoraStream.isConnected && (
                      <div className="absolute top-3 left-3 flex items-center gap-2">
                        <Badge className="bg-red-500 text-white">
                          <Radio className="w-3 h-3 mr-1 animate-pulse" />
                          LIVE
                        </Badge>
                      </div>
                    )}
                  </div>
                  
                  {/* Video Controls */}
                  <div className="flex items-center justify-center gap-2 mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => agoraStream.toggleMute()}
                      disabled={!agoraStream.isConnected}
                      className={`border-slate-700 ${agoraStream.isMuted ? 'text-red-400' : 'text-slate-300'}`}
                    >
                      {agoraStream.isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => agoraStream.toggleVideo()}
                      disabled={!agoraStream.isConnected}
                      className={`border-slate-700 ${agoraStream.isVideoOff ? 'text-red-400' : 'text-slate-300'}`}
                    >
                      {agoraStream.isVideoOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => agoraStream.leave()}
                      disabled={!agoraStream.isConnected}
                      className="border-slate-700 text-red-400 hover:bg-red-500/20"
                    >
                      <Pause className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Chat Preview */}
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-base flex items-center gap-2">
                    <MessageCircle className="w-4 h-4 text-orange-500" />
                    Chat du Live
                    <Badge variant="outline" className="ml-auto text-slate-400 border-slate-600">
                      {chatMessages.length} messages
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-48 pr-4">
                    {chatMessages.length === 0 ? (
                      <div className="flex items-center justify-center h-full">
                        <p className="text-slate-500 text-sm">Aucun message</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {chatMessages.map((msg) => (
                          <div key={msg.id} className="flex gap-2">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center flex-shrink-0">
                              <span className="text-white text-xs font-bold">
                                {msg.user.charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-orange-400 text-sm font-medium">{msg.user}</span>
                                <span className="text-slate-600 text-xs">
                                  {msg.time.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                              <p className="text-slate-300 text-sm">{msg.message}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                  
                  {/* Chat Input */}
                  <div className="flex gap-2 mt-4">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Envoyer un message..."
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                    <Button
                      onClick={handleSendMessage}
                      size="icon"
                      className="bg-orange-500 hover:bg-orange-600"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Products & Order Preview */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Products */}
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-base flex items-center gap-2">
                    <Package className="w-4 h-4 text-orange-500" />
                    Produits du Live
                    <Badge variant="outline" className="ml-auto text-slate-400 border-slate-600">
                      {testProducts.length} produits
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {testProducts.length === 0 ? (
                    <div className="flex items-center justify-center h-32">
                      <p className="text-slate-500 text-sm">Aucun produit ajouté</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {testProducts.map((product) => (
                        <div
                          key={product.id}
                          className={`flex items-center gap-3 p-3 rounded-xl ${
                            product.isHighlighted
                              ? 'bg-orange-500/10 border border-orange-500/30'
                              : 'bg-slate-800/50'
                          }`}
                        >
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-12 h-12 rounded-lg object-cover"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-white text-sm font-medium truncate">{product.name}</h4>
                            <p className="text-orange-400 text-sm font-bold">
                              {product.price.toLocaleString()} FCFA
                            </p>
                          </div>
                          {product.isHighlighted && (
                            <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">
                              Vedette
                            </Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Order & Payment */}
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-base flex items-center gap-2">
                    <ShoppingCart className="w-4 h-4 text-orange-500" />
                    Commande & Paiement
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {!testOrder ? (
                    <div className="flex items-center justify-center h-32">
                      <p className="text-slate-500 text-sm">Aucune commande créée</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Order Info */}
                      <div className="p-3 bg-slate-800/50 rounded-xl">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-slate-400 text-sm">Commande</span>
                          <Badge className={orders.getStatusColor(testOrder.status)}>
                            {orders.getStatusLabel(testOrder.status)}
                          </Badge>
                        </div>
                        <p className="text-white font-mono text-sm">{testOrder.order_number}</p>
                        <p className="text-orange-400 font-bold mt-1">
                          {testOrder.total.toLocaleString()} FCFA
                        </p>
                      </div>

                      {/* Payment Info */}
                      {testPayment && (
                        <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl">
                          <div className="flex items-center gap-2 mb-2">
                            <CreditCard className="w-4 h-4 text-green-400" />
                            <span className="text-green-400 text-sm font-medium">Paiement confirmé</span>
                          </div>
                          <p className="text-slate-300 text-xs">
                            Transaction: {testPayment.transactionId}
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Right Column - Logs */}
          <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800 sticky top-24">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white text-base flex items-center gap-2">
                    <Eye className="w-4 h-4 text-orange-500" />
                    Journal des Tests
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowLogs(!showLogs)}
                    className="text-slate-400 hover:text-white"
                  >
                    {showLogs ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>
                </div>
              </CardHeader>
              {showLogs && (
                <CardContent>
                  <ScrollArea className="h-[500px] pr-4">
                    {logs.length === 0 ? (
                      <div className="flex items-center justify-center h-32">
                        <p className="text-slate-500 text-sm">Aucun log</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {logs.map((log) => (
                          <div
                            key={log.id}
                            className={`p-2 rounded-lg text-xs ${
                              log.type === 'error'
                                ? 'bg-red-500/10 border border-red-500/20'
                                : log.type === 'success'
                                ? 'bg-green-500/10 border border-green-500/20'
                                : log.type === 'warning'
                                ? 'bg-yellow-500/10 border border-yellow-500/20'
                                : 'bg-slate-800/50'
                            }`}
                          >
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-slate-500">
                                {log.timestamp.toLocaleTimeString('fr-FR', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit'
                                })}
                              </span>
                              <Badge
                                className={`text-[10px] px-1.5 py-0 ${
                                  log.type === 'error'
                                    ? 'bg-red-500/20 text-red-400'
                                    : log.type === 'success'
                                    ? 'bg-green-500/20 text-green-400'
                                    : log.type === 'warning'
                                    ? 'bg-yellow-500/20 text-yellow-400'
                                    : 'bg-blue-500/20 text-blue-400'
                                }`}
                              >
                                {log.type.toUpperCase()}
                              </Badge>
                            </div>
                            <p className={`${
                              log.type === 'error'
                                ? 'text-red-300'
                                : log.type === 'success'
                                ? 'text-green-300'
                                : log.type === 'warning'
                                ? 'text-yellow-300'
                                : 'text-slate-300'
                            }`}>
                              {log.message}
                            </p>
                            {log.details && (
                              <pre className="mt-1 text-[10px] text-slate-500 overflow-x-auto">
                                {JSON.stringify(log.details, null, 2)}
                              </pre>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                  
                  <div className="mt-4 pt-4 border-t border-slate-800">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setLogs([])}
                      className="w-full border-slate-700 text-slate-400 hover:text-white"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Effacer les logs
                    </Button>
                  </div>
                </CardContent>
              )}
            </Card>

            {/* Connection Status */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader className="pb-3">
                <CardTitle className="text-white text-base">État de la Connexion</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Agora SDK</span>
                  <Badge className={agoraStream.isConnected ? 'bg-green-500/20 text-green-400' : 'bg-slate-500/20 text-slate-400'}>
                    {agoraStream.isConnected ? 'Connecté' : 'Déconnecté'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Publication</span>
                  <Badge className={agoraStream.isPublishing ? 'bg-green-500/20 text-green-400' : 'bg-slate-500/20 text-slate-400'}>
                    {agoraStream.isPublishing ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Canal</span>
                  <span className="text-white text-sm font-mono">{channelName.substring(0, 15)}...</span>
                </div>
                {agoraStream.streamStats && (
                  <>
                    <Separator className="bg-slate-800" />
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-sm">Résolution</span>
                      <span className="text-white text-sm">{agoraStream.streamStats.resolution}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-sm">FPS</span>
                      <span className="text-white text-sm">{agoraStream.streamStats.frameRate}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-sm">Bitrate</span>
                      <span className="text-white text-sm">{Math.round(agoraStream.streamStats.bitrate / 1000)} kbps</span>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
};

export default LiveTestPage;
