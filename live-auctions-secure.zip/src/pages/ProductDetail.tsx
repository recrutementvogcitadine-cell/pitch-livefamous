import React, { useState, useMemo, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  ChevronRight,
  Star,
  Heart,
  Share2,
  ShoppingBag,
  Truck,
  Shield,
  RefreshCw,
  MessageCircle,
  Phone,
  MapPin,
  Clock,
  Package,
  Eye,
  Users,
  ChevronLeft,
  ZoomIn,
  X,
  Copy,
  Facebook,
  Twitter,
  Check,
  Minus,
  Plus,
  Play,
  Award,
  ThumbsUp,
  ExternalLink
} from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ContactSellerModal from '@/components/ContactSellerModal';
import { ProductReviewsSection } from '@/components/ProductReviewsSection';
import AuthModal from '@/components/AuthModal';
import OrderFormModal from '@/components/OrderFormModal';
import { VerificationBadgeCompact } from '@/components/VerificationBadge';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { formatPrice, products as mockProducts } from '@/data/mockData';
import { toast } from '@/components/ui/use-toast';

// Extended product interface with more details
interface ProductDetail {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  images: string[];
  seller: {
    id: string;
    name: string;
    avatar: string;
    verified: boolean;
    rating: number;
    reviewCount: number;
    followers: number;
    location: string;
    responseTime: string;
    joinedDate: string;
    totalSales: number;
  };
  rating: number;
  reviews: number;
  sold: number;
  category: string;
  subcategory: string;
  description: string;
  features: string[];
  specifications: { label: string; value: string }[];
  inStock: boolean;
  stockCount: number;
  shippingInfo: {
    freeShipping: boolean;
    estimatedDays: string;
    shippingCost?: number;
  };
  returnPolicy: string;
  warranty: string;
  tags: string[];
}

// Extended mock product data
const getProductDetail = (id: string): ProductDetail | null => {
  const productDetails: Record<string, ProductDetail> = {
    '1': {
      id: '1',
      name: 'iPhone 15 Pro Max 256GB - Titane Naturel',
      price: 850000,
      originalPrice: 950000,
      images: [
        'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800',
        'https://images.unsplash.com/photo-1696446701796-da61225697cc?w=800',
        'https://images.unsplash.com/photo-1695048132832-b41495a7e10f?w=800',
        'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=800',
        'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=800'
      ],
      seller: {
        id: 'seller-1',
        name: 'TechStore CI',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200',
        verified: true,
        rating: 4.8,
        reviewCount: 892,
        followers: 15420,
        location: 'Abidjan, Cocody',
        responseTime: '< 1 heure',
        joinedDate: '2024-03-15',
        totalSales: 3240
      },
      rating: 4.8,
      reviews: 234,
      sold: 156,
      category: 'Électronique',
      subcategory: 'Smartphones',
      description: `L'iPhone 15 Pro Max représente le summum de l'innovation Apple. Équipé de la puce A17 Pro révolutionnaire, ce smartphone offre des performances inégalées pour les jeux, la photographie et la productivité.

Son système de caméra pro avec zoom optique 5x capture des détails extraordinaires, même de loin. Le design en titane de qualité aérospatiale le rend à la fois léger et incroyablement résistant.

Avec son écran Super Retina XDR de 6,7 pouces et ProMotion, chaque interaction est fluide et immersive. L'Action Button personnalisable vous permet d'accéder instantanément à vos fonctionnalités préférées.`,
      features: [
        'Puce A17 Pro avec GPU 6 cœurs',
        'Écran Super Retina XDR 6,7" ProMotion',
        'Système photo pro 48MP avec zoom 5x',
        'Design titane de qualité aérospatiale',
        'USB-C avec USB 3',
        'Autonomie jusqu\'à 29h en lecture vidéo',
        'Action Button personnalisable',
        'Ceramic Shield plus résistant'
      ],
      specifications: [
        { label: 'Stockage', value: '256 Go' },
        { label: 'Écran', value: '6,7" Super Retina XDR' },
        { label: 'Processeur', value: 'A17 Pro' },
        { label: 'RAM', value: '8 Go' },
        { label: 'Caméra principale', value: '48 MP' },
        { label: 'Caméra frontale', value: '12 MP TrueDepth' },
        { label: 'Batterie', value: '4422 mAh' },
        { label: 'Système', value: 'iOS 17' },
        { label: 'Connectivité', value: '5G, Wi-Fi 6E, Bluetooth 5.3' },
        { label: 'Résistance', value: 'IP68' }
      ],
      inStock: true,
      stockCount: 12,
      shippingInfo: {
        freeShipping: true,
        estimatedDays: '24-48h'
      },
      returnPolicy: '7 jours pour retour',
      warranty: '1 an garantie Apple',
      tags: ['iPhone', 'Apple', 'Smartphone', '5G', 'Pro Max']
    },
    '2': {
      id: '2',
      name: 'Ensemble Wax Traditionnel - Collection Prestige',
      price: 45000,
      images: [
        'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=800',
        'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800',
        'https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?w=800',
        'https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800'
      ],
      seller: {
        id: 'seller-2',
        name: 'Awa Fashion',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
        verified: true,
        rating: 4.9,
        reviewCount: 1456,
        followers: 28750,
        location: 'Abidjan, Plateau',
        responseTime: '< 30 min',
        joinedDate: '2023-08-20',
        totalSales: 5680
      },
      rating: 4.9,
      reviews: 189,
      sold: 423,
      category: 'Mode',
      subcategory: 'Vêtements traditionnels',
      description: `Découvrez notre ensemble wax traditionnel de la Collection Prestige, une création unique qui célèbre l'élégance et la richesse de la mode africaine.

Confectionné à partir de tissu wax 100% coton de première qualité importé directement du Ghana, cet ensemble comprend une jupe longue évasée et un haut assorti avec des finitions impeccables.

Chaque pièce est cousue à la main par nos artisans locaux avec un souci du détail exceptionnel. Les motifs traditionnels sont soigneusement sélectionnés pour leur symbolisme et leur beauté.`,
      features: [
        'Tissu wax 100% coton premium',
        'Couture artisanale à la main',
        'Motifs traditionnels authentiques',
        'Ensemble complet (haut + jupe)',
        'Doublure intérieure confortable',
        'Fermeture éclair invisible',
        'Tailles disponibles: S à XXL',
        'Lavable en machine'
      ],
      specifications: [
        { label: 'Matière', value: '100% Coton Wax' },
        { label: 'Origine tissu', value: 'Ghana' },
        { label: 'Confection', value: 'Côte d\'Ivoire' },
        { label: 'Tailles', value: 'S, M, L, XL, XXL' },
        { label: 'Couleurs', value: 'Multicolore' },
        { label: 'Entretien', value: 'Lavage 30°C' },
        { label: 'Style', value: 'Traditionnel moderne' }
      ],
      inStock: true,
      stockCount: 28,
      shippingInfo: {
        freeShipping: false,
        estimatedDays: '48-72h',
        shippingCost: 2500
      },
      returnPolicy: '14 jours pour échange',
      warranty: 'Satisfait ou remboursé',
      tags: ['Wax', 'Mode africaine', 'Traditionnel', 'Artisanal']
    },
    '3': {
      id: '3',
      name: 'Collier Perles Africaines - Édition Limitée',
      price: 28000,
      originalPrice: 35000,
      images: [
        'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800',
        'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800',
        'https://images.unsplash.com/photo-1611085583191-a3b181a88401?w=800',
        'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=800'
      ],
      seller: {
        id: 'seller-3',
        name: 'Bijoux d\'Or',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200',
        verified: false,
        rating: 4.7,
        reviewCount: 234,
        followers: 8920,
        location: 'Abidjan, Marcory',
        responseTime: '< 2 heures',
        joinedDate: '2024-01-10',
        totalSales: 1890
      },
      rating: 4.7,
      reviews: 67,
      sold: 89,
      category: 'Bijoux',
      subcategory: 'Colliers',
      description: `Ce magnifique collier en perles africaines est une pièce unique de notre collection Édition Limitée. Fabriqué à la main par des artisans locaux, il incarne l'essence de l'artisanat africain traditionnel.

Les perles sont soigneusement sélectionnées et assemblées pour créer un bijou qui raconte une histoire. Chaque collier est unique, avec des variations subtiles qui en font une pièce véritablement exclusive.

Parfait pour les occasions spéciales ou pour ajouter une touche d'élégance africaine à votre tenue quotidienne.`,
      features: [
        'Perles africaines authentiques',
        'Fabrication artisanale',
        'Édition limitée numérotée',
        'Fermoir en laiton doré',
        'Longueur ajustable',
        'Livré dans un écrin cadeau',
        'Certificat d\'authenticité inclus'
      ],
      specifications: [
        { label: 'Matériaux', value: 'Perles, Laiton doré' },
        { label: 'Longueur', value: '45-50 cm ajustable' },
        { label: 'Poids', value: '85 g' },
        { label: 'Origine', value: 'Côte d\'Ivoire' },
        { label: 'Édition', value: 'Limitée (50 pièces)' }
      ],
      inStock: true,
      stockCount: 8,
      shippingInfo: {
        freeShipping: true,
        estimatedDays: '24-48h'
      },
      returnPolicy: '7 jours pour retour',
      warranty: '6 mois garantie',
      tags: ['Bijoux', 'Perles', 'Artisanal', 'Africain', 'Édition limitée']
    },
    '4': {
      id: '4',
      name: 'Climatiseur Samsung 18000 BTU Inverter',
      price: 420000,
      images: [
        'https://images.unsplash.com/photo-1631545806609-35d4ae440431?w=800',
        'https://images.unsplash.com/photo-1585338107529-13afc5f02586?w=800',
        'https://images.unsplash.com/photo-1625961332771-3f40b0e2bdcf?w=800'
      ],
      seller: {
        id: 'seller-4',
        name: 'Maison Plus',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200',
        verified: true,
        rating: 4.6,
        reviewCount: 567,
        followers: 12340,
        location: 'Abidjan, Yopougon',
        responseTime: '< 1 heure',
        joinedDate: '2023-05-12',
        totalSales: 2890
      },
      rating: 4.6,
      reviews: 156,
      sold: 234,
      category: 'Maison',
      subcategory: 'Électroménager',
      description: `Le climatiseur Samsung 18000 BTU avec technologie Inverter est la solution idéale pour rafraîchir efficacement votre espace tout en économisant de l'énergie.

Grâce à sa technologie Digital Inverter, il ajuste automatiquement sa puissance pour maintenir une température constante tout en réduisant votre consommation électrique jusqu'à 40%.

Son design élégant et discret s'intègre parfaitement dans tout type d'intérieur. Le mode silencieux vous garantit un confort optimal sans bruit gênant.`,
      features: [
        'Technologie Digital Inverter',
        'Économie d\'énergie jusqu\'à 40%',
        'Mode silencieux 19 dB',
        'Filtre anti-bactérien',
        'Télécommande incluse',
        'Fonction déshumidification',
        'Installation incluse sur Abidjan',
        'Classe énergétique A++'
      ],
      specifications: [
        { label: 'Puissance', value: '18000 BTU' },
        { label: 'Surface', value: '25-35 m²' },
        { label: 'Technologie', value: 'Inverter' },
        { label: 'Niveau sonore', value: '19-42 dB' },
        { label: 'Classe énergie', value: 'A++' },
        { label: 'Réfrigérant', value: 'R32 écologique' },
        { label: 'Dimensions', value: '998 x 345 x 210 mm' },
        { label: 'Poids', value: '12,5 kg' }
      ],
      inStock: true,
      stockCount: 5,
      shippingInfo: {
        freeShipping: true,
        estimatedDays: '48-72h'
      },
      returnPolicy: '14 jours pour retour',
      warranty: '3 ans garantie Samsung',
      tags: ['Climatiseur', 'Samsung', 'Inverter', 'Électroménager']
    },
    '5': {
      id: '5',
      name: 'Nike Air Max 270 - Édition Exclusive',
      price: 85000,
      originalPrice: 110000,
      images: [
        'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
        'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800',
        'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=800',
        'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800',
        'https://images.unsplash.com/photo-1584735175315-9d5df23860e6?w=800'
      ],
      seller: {
        id: 'seller-5',
        name: 'SneakerHead ABJ',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200',
        verified: true,
        rating: 4.9,
        reviewCount: 1234,
        followers: 34560,
        location: 'Abidjan, Zone 4',
        responseTime: '< 15 min',
        joinedDate: '2022-11-08',
        totalSales: 8920
      },
      rating: 4.9,
      reviews: 312,
      sold: 567,
      category: 'Chaussures',
      subcategory: 'Sneakers',
      description: `Les Nike Air Max 270 représentent l'évolution ultime du confort et du style. Inspirées des légendaires Air Max 180 et Air Max 93, elles intègrent la plus grande unité Air jamais créée pour un amorti exceptionnel.

Cette édition exclusive présente un coloris unique qui se démarque. La tige en mesh respirant assure une ventilation optimale tandis que les renforts synthétiques offrent un maintien parfait.

Que ce soit pour le sport ou le lifestyle, ces sneakers sont conçues pour ceux qui refusent les compromis entre confort et style.`,
      features: [
        'Unité Air Max 270 visible',
        'Tige mesh respirante',
        'Semelle extérieure en caoutchouc',
        'Renforts synthétiques',
        'Languette rembourrée',
        'Col bas pour plus de mobilité',
        'Design lifestyle premium',
        '100% authentique Nike'
      ],
      specifications: [
        { label: 'Marque', value: 'Nike' },
        { label: 'Modèle', value: 'Air Max 270' },
        { label: 'Pointures', value: '38 à 46' },
        { label: 'Matière tige', value: 'Mesh + Synthétique' },
        { label: 'Semelle', value: 'Caoutchouc + Air Max' },
        { label: 'Couleur', value: 'Rouge/Noir/Blanc' },
        { label: 'Style', value: 'Lifestyle/Running' }
      ],
      inStock: true,
      stockCount: 15,
      shippingInfo: {
        freeShipping: true,
        estimatedDays: '24-48h'
      },
      returnPolicy: '30 jours pour échange',
      warranty: 'Garantie authenticité',
      tags: ['Nike', 'Air Max', 'Sneakers', 'Sport', 'Lifestyle']
    },
    '6': {
      id: '6',
      name: 'Kit Beauté Naturel Bio - Collection Complète',
      price: 32000,
      images: [
        'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800',
        'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=800',
        'https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=800',
        'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800'
      ],
      seller: {
        id: 'seller-6',
        name: 'Beauty Queen',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200',
        verified: true,
        rating: 4.5,
        reviewCount: 456,
        followers: 19870,
        location: 'Abidjan, Riviera',
        responseTime: '< 1 heure',
        joinedDate: '2023-09-01',
        totalSales: 4560
      },
      rating: 4.5,
      reviews: 98,
      sold: 234,
      category: 'Beauté',
      subcategory: 'Soins visage',
      description: `Notre Kit Beauté Naturel Bio est une collection complète de soins pour le visage, formulée avec des ingrédients 100% naturels et biologiques.

Ce kit comprend tout ce dont vous avez besoin pour une routine beauté complète : nettoyant, tonique, sérum, crème hydratante et masque. Tous nos produits sont sans parabènes, sans sulfates et non testés sur les animaux.

Enrichis en huile de karité, aloe vera et vitamine E, ces soins nourrissent et protègent votre peau en profondeur pour un teint éclatant et uniforme.`,
      features: [
        'Ingrédients 100% naturels et bio',
        'Sans parabènes ni sulfates',
        'Non testé sur les animaux',
        'Convient à tous types de peau',
        'Kit complet 5 produits',
        'Enrichi en karité et aloe vera',
        'Packaging éco-responsable',
        'Made in Côte d\'Ivoire'
      ],
      specifications: [
        { label: 'Contenu', value: '5 produits' },
        { label: 'Nettoyant', value: '150 ml' },
        { label: 'Tonique', value: '100 ml' },
        { label: 'Sérum', value: '30 ml' },
        { label: 'Crème', value: '50 ml' },
        { label: 'Masque', value: '75 ml' },
        { label: 'Certification', value: 'Bio & Vegan' }
      ],
      inStock: true,
      stockCount: 42,
      shippingInfo: {
        freeShipping: false,
        estimatedDays: '24-48h',
        shippingCost: 2000
      },
      returnPolicy: '14 jours si non ouvert',
      warranty: 'Satisfait ou remboursé',
      tags: ['Beauté', 'Bio', 'Naturel', 'Soins', 'Visage']
    },
    '7': {
      id: '7',
      name: 'Montre Casio G-Shock GA-2100',
      price: 75000,
      originalPrice: 95000,
      images: [
        'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800',
        'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800',
        'https://images.unsplash.com/photo-1434056886845-dbd39c1cc727?w=800',
        'https://images.unsplash.com/photo-1509048191080-d2984bad6ae5?w=800'
      ],
      seller: {
        id: 'seller-7',
        name: 'Chrono Luxe',
        avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200',
        verified: true,
        rating: 4.8,
        reviewCount: 678,
        followers: 21340,
        location: 'Abidjan, Plateau',
        responseTime: '< 30 min',
        joinedDate: '2023-02-15',
        totalSales: 3450
      },
      rating: 4.8,
      reviews: 201,
      sold: 345,
      category: 'Accessoires',
      subcategory: 'Montres',
      description: `La Casio G-Shock GA-2100, surnommée "CasiOak" pour son design inspiré de la Royal Oak, est devenue une icône de l'horlogerie moderne.

Alliant le style octogonal élégant à la robustesse légendaire des G-Shock, cette montre est parfaite pour ceux qui recherchent l'équilibre entre esthétique et fonctionnalité.

Résistante aux chocs et à l'eau jusqu'à 200 mètres, elle intègre un double affichage analogique-digital, une alarme, un chronomètre et un éclairage LED.`,
      features: [
        'Design octogonal "CasiOak"',
        'Résistance aux chocs',
        'Étanche 200 mètres',
        'Double affichage ana-digi',
        'Éclairage LED',
        'Chronomètre 1/100 sec',
        'Alarme quotidienne',
        'Pile durée 3 ans'
      ],
      specifications: [
        { label: 'Marque', value: 'Casio G-Shock' },
        { label: 'Modèle', value: 'GA-2100-1A1' },
        { label: 'Mouvement', value: 'Quartz' },
        { label: 'Boîtier', value: '45,4 mm' },
        { label: 'Épaisseur', value: '11,8 mm' },
        { label: 'Poids', value: '51 g' },
        { label: 'Bracelet', value: 'Résine' },
        { label: 'Étanchéité', value: '200 m' }
      ],
      inStock: true,
      stockCount: 18,
      shippingInfo: {
        freeShipping: true,
        estimatedDays: '24h'
      },
      returnPolicy: '14 jours pour retour',
      warranty: '2 ans garantie Casio',
      tags: ['Montre', 'Casio', 'G-Shock', 'Sport', 'Accessoires']
    },
    '8': {
      id: '8',
      name: 'Canapé 3 Places Moderne - Design Scandinave',
      price: 280000,
      images: [
        'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800',
        'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?w=800',
        'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?w=800',
        'https://images.unsplash.com/photo-1550254478-ead40cc54513?w=800'
      ],
      seller: {
        id: 'seller-8',
        name: 'Déco Intérieur',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200',
        verified: false,
        rating: 4.4,
        reviewCount: 189,
        followers: 6780,
        location: 'Abidjan, Cocody',
        responseTime: '< 2 heures',
        joinedDate: '2024-02-20',
        totalSales: 890
      },
      rating: 4.4,
      reviews: 45,
      sold: 67,
      category: 'Maison',
      subcategory: 'Mobilier',
      description: `Ce magnifique canapé 3 places au design scandinave apportera une touche d'élégance et de modernité à votre salon.

Fabriqué avec des matériaux de haute qualité, il offre un confort exceptionnel grâce à ses coussins en mousse haute densité et son revêtement en tissu doux et résistant.

Ses pieds en bois massif et ses lignes épurées s'intègrent parfaitement dans tout type d'intérieur, du plus moderne au plus classique.`,
      features: [
        'Design scandinave moderne',
        'Tissu haute qualité',
        'Mousse haute densité',
        'Pieds en bois massif',
        'Coussins déhoussables',
        'Structure solide en bois',
        'Montage facile',
        'Livraison et montage inclus'
      ],
      specifications: [
        { label: 'Dimensions', value: '210 x 85 x 80 cm' },
        { label: 'Assise', value: '180 x 55 cm' },
        { label: 'Hauteur assise', value: '45 cm' },
        { label: 'Matière', value: 'Tissu polyester' },
        { label: 'Structure', value: 'Bois + Métal' },
        { label: 'Pieds', value: 'Chêne massif' },
        { label: 'Poids max', value: '250 kg' },
        { label: 'Couleur', value: 'Gris anthracite' }
      ],
      inStock: true,
      stockCount: 3,
      shippingInfo: {
        freeShipping: true,
        estimatedDays: '5-7 jours'
      },
      returnPolicy: '14 jours pour retour',
      warranty: '2 ans garantie',
      tags: ['Canapé', 'Mobilier', 'Scandinave', 'Salon', 'Design']
    }
  };

  return productDetails[id] || null;
};

// Get related products
const getRelatedProducts = (category: string, currentId: string) => {
  return mockProducts
    .filter(p => p.category === category && p.id !== currentId)
    .slice(0, 4);
};

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useApp();

  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [selectedImage, setSelectedImage] = useState(0);
  const [showImageModal, setShowImageModal] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'description' | 'specifications' | 'shipping'>('description');
  const [headerSearchQuery, setHeaderSearchQuery] = useState('');
  const [isWishlisted, setIsWishlisted] = useState(false);

  useEffect(() => {
    if (id) {
      const productData = getProductDetail(id);
      setProduct(productData);
      setSelectedImage(0);
      setQuantity(1);
      window.scrollTo(0, 0);
    }
  }, [id]);

  useEffect(() => {
    if (id) {
      setIsWishlisted(isInWishlist(id));
    }
  }, [id, isInWishlist]);

  const relatedProducts = useMemo(() => {
    if (!product) return [];
    return getRelatedProducts(product.category, product.id);
  }, [product]);

  if (!product) {
    return (
      <div className="min-h-screen bg-slate-900">
        <Header 
          onAuthClick={() => setShowAuthModal(true)}
          searchQuery={headerSearchQuery}
          onSearchChange={setHeaderSearchQuery}
        />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <Package className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Produit non trouvé</h2>
            <p className="text-slate-400 mb-6">Le produit que vous recherchez n'existe pas ou a été supprimé.</p>
            <button
              onClick={() => navigate('/products')}
              className="px-6 py-3 bg-purple-500 hover:bg-purple-600 text-white font-medium rounded-xl transition-colors"
            >
              Voir tous les produits
            </button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const handleWishlistToggle = () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    if (isWishlisted) {
      removeFromWishlist(product.id);
      setIsWishlisted(false);
      toast({ title: 'Retiré des favoris', description: `${product.name} a été retiré de vos favoris` });
    } else {
      addToWishlist({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.images[0],
        seller: product.seller.name,
        rating: product.rating,
        reviews: product.reviews,
        category: product.category
      });
      setIsWishlisted(true);
      toast({ title: 'Ajouté aux favoris', description: `${product.name} a été ajouté à vos favoris` });
    }
  };

  const handleShare = (platform: string) => {
    const url = window.location.href;
    const text = `Découvrez ${product.name} sur PITCH !`;

    switch (platform) {
      case 'copy':
        navigator.clipboard.writeText(url);
        toast({ title: 'Lien copié !', description: 'Le lien a été copié dans le presse-papier' });
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`, '_blank');
        break;
    }
    setShowShareModal(false);
  };

  const handleBuyNow = () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    setShowOrderModal(true);
  };

  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-slate-900">
      <Header
        onAuthClick={() => setShowAuthModal(true)}
        searchQuery={headerSearchQuery}
        onSearchChange={setHeaderSearchQuery}
      />

      <main className="pt-20 pb-12">
        {/* Breadcrumb */}
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <ol className="flex items-center gap-2 text-sm flex-wrap">
            <li>
              <Link to="/" className="text-slate-400 hover:text-white transition-colors">
                Accueil
              </Link>
            </li>
            <ChevronRight className="w-4 h-4 text-slate-600" />
            <li>
              <Link to="/products" className="text-slate-400 hover:text-white transition-colors">
                Produits
              </Link>
            </li>
            <ChevronRight className="w-4 h-4 text-slate-600" />
            <li>
              <Link 
                to={`/products?category=${encodeURIComponent(product.category)}`} 
                className="text-slate-400 hover:text-white transition-colors"
              >
                {product.category}
              </Link>
            </li>
            <ChevronRight className="w-4 h-4 text-slate-600" />
            <li className="text-purple-400 font-medium truncate max-w-[200px]">
              {product.name}
            </li>
          </ol>
        </nav>

        {/* Product Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Image Gallery */}
            <div className="space-y-4">
              {/* Main Image */}
              <div 
                className="relative aspect-square bg-slate-800 rounded-2xl overflow-hidden cursor-zoom-in group"
                onClick={() => setShowImageModal(true)}
              >
                <img
                  src={product.images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                {discount > 0 && (
                  <div className="absolute top-4 left-4 px-3 py-1.5 bg-red-500 text-white text-sm font-bold rounded-lg">
                    -{discount}%
                  </div>
                )}
                <div className="absolute bottom-4 right-4 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  <ZoomIn className="w-5 h-5" />
                </div>
                {/* Navigation arrows */}
                {product.images.length > 1 && (
                  <>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedImage(prev => prev === 0 ? product.images.length - 1 : prev - 1);
                      }}
                      className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/70"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedImage(prev => prev === product.images.length - 1 ? 0 : prev + 1);
                      }}
                      className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/70"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </>
                )}
              </div>

              {/* Thumbnails */}
              <div className="flex gap-3 overflow-x-auto pb-2">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                      selectedImage === index
                        ? 'border-purple-500 ring-2 ring-purple-500/30'
                        : 'border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              {/* Category & Tags */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-3 py-1 bg-purple-500/20 text-purple-400 text-sm font-medium rounded-full">
                  {product.category}
                </span>
                <span className="px-3 py-1 bg-slate-700 text-slate-300 text-sm rounded-full">
                  {product.subcategory}
                </span>
              </div>

              {/* Title */}
              <h1 className="text-2xl md:text-3xl font-bold text-white leading-tight">
                {product.name}
              </h1>

              {/* Rating & Sales */}
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map(star => (
                    <Star
                      key={star}
                      className={`w-5 h-5 ${star <= Math.round(product.rating) ? 'text-yellow-400' : 'text-slate-600'}`}
                      fill={star <= Math.round(product.rating) ? 'currentColor' : 'none'}
                    />
                  ))}
                  <span className="ml-2 text-white font-medium">{product.rating}</span>
                </div>
                <span className="text-slate-400">({product.reviews} avis)</span>
                <span className="text-slate-400">•</span>
                <span className="text-green-400">{product.sold} vendus</span>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-3">
                <span className="text-3xl md:text-4xl font-bold text-white">
                  {formatPrice(product.price)}
                </span>
                {product.originalPrice && (
                  <>
                    <span className="text-xl text-slate-500 line-through">
                      {formatPrice(product.originalPrice)}
                    </span>
                    <span className="px-2 py-1 bg-red-500/20 text-red-400 text-sm font-medium rounded">
                      Économisez {formatPrice(product.originalPrice - product.price)}
                    </span>
                  </>
                )}
              </div>

              {/* Stock Status */}
              <div className="flex items-center gap-2">
                {product.inStock ? (
                  <>
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                    <span className="text-green-400 font-medium">En stock</span>
                    <span className="text-slate-400">({product.stockCount} disponibles)</span>
                  </>
                ) : (
                  <>
                    <div className="w-3 h-3 bg-red-500 rounded-full" />
                    <span className="text-red-400 font-medium">Rupture de stock</span>
                  </>
                )}
              </div>

              {/* Quantity Selector */}
              {product.inStock && (
                <div className="flex items-center gap-4">
                  <span className="text-slate-400">Quantité:</span>
                  <div className="flex items-center bg-slate-800 border border-slate-700 rounded-xl">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-3 text-slate-400 hover:text-white transition-colors"
                      disabled={quantity <= 1}
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-12 text-center text-white font-medium">{quantity}</span>
                    <button
                      onClick={() => setQuantity(Math.min(product.stockCount, quantity + 1))}
                      className="p-3 text-slate-400 hover:text-white transition-colors"
                      disabled={quantity >= product.stockCount}
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleBuyNow}
                  disabled={!product.inStock}
                  className="flex-1 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-purple-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-5 h-5" />
                  Commander maintenant
                </button>
                <button
                  onClick={handleWishlistToggle}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    isWishlisted
                      ? 'bg-red-500/20 border-red-500 text-red-400'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600 hover:text-white'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
                <button
                  onClick={() => setShowShareModal(true)}
                  className="p-4 bg-slate-800 border-2 border-slate-700 text-slate-400 rounded-xl hover:border-slate-600 hover:text-white transition-all"
                >
                  <Share2 className="w-5 h-5" />
                </button>
              </div>

              {/* Shipping & Policies */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="flex items-center gap-3 p-3 bg-slate-800/50 border border-slate-700 rounded-xl">
                  <div className="w-10 h-10 bg-green-500/20 rounded-full flex items-center justify-center">
                    <Truck className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">
                      {product.shippingInfo.freeShipping ? 'Livraison gratuite' : `Livraison ${formatPrice(product.shippingInfo.shippingCost || 0)}`}
                    </p>
                    <p className="text-slate-400 text-xs">{product.shippingInfo.estimatedDays}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-slate-800/50 border border-slate-700 rounded-xl">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
                    <RefreshCw className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">Retours</p>
                    <p className="text-slate-400 text-xs">{product.returnPolicy}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-slate-800/50 border border-slate-700 rounded-xl">
                  <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center">
                    <Shield className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">Garantie</p>
                    <p className="text-slate-400 text-xs">{product.warranty}</p>
                  </div>
                </div>
              </div>

              {/* Seller Card */}
              <div className="p-4 bg-slate-800/50 border border-slate-700 rounded-2xl">
                <div className="flex items-center justify-between gap-4">
                  <Link 
                    to={`/seller/${product.seller.id}`}
                    className="flex items-center gap-3 group"
                  >
                    <img
                      src={product.seller.avatar}
                      alt={product.seller.name}
                      className="w-14 h-14 rounded-xl object-cover"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-white font-medium group-hover:text-purple-400 transition-colors">
                          {product.seller.name}
                        </h3>
                        {product.seller.verified && <VerificationBadgeCompact status="verified" />}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-sm">
                        <div className="flex items-center gap-1 text-yellow-400">
                          <Star className="w-4 h-4" fill="currentColor" />
                          <span>{product.seller.rating}</span>
                        </div>
                        <span className="text-slate-400">|</span>
                        <span className="text-slate-400">{product.seller.followers.toLocaleString()} abonnés</span>
                      </div>
                      <div className="flex items-center gap-1 mt-1 text-slate-400 text-xs">
                        <MapPin className="w-3 h-3" />
                        {product.seller.location}
                      </div>
                    </div>
                  </Link>
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => setShowContactModal(true)}
                      className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white text-sm font-medium rounded-xl transition-colors flex items-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4" />
                      Contacter
                    </button>
                    <Link
                      to={`/seller/${product.seller.id}`}
                      className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white text-sm font-medium rounded-xl transition-colors flex items-center gap-2"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Voir profil
                    </Link>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-slate-700">
                  <div className="text-center">
                    <p className="text-white font-bold">{product.seller.totalSales.toLocaleString()}</p>
                    <p className="text-slate-400 text-xs">Ventes</p>
                  </div>
                  <div className="text-center">
                    <p className="text-white font-bold">{product.seller.responseTime}</p>
                    <p className="text-slate-400 text-xs">Réponse</p>
                  </div>
                  <div className="text-center">
                    <p className="text-white font-bold">{product.seller.reviewCount}</p>
                    <p className="text-slate-400 text-xs">Avis</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Product Details Tabs */}
          <div className="mt-12">
            <div className="flex items-center gap-2 border-b border-slate-700 overflow-x-auto">
              {[
                { id: 'description', label: 'Description' },
                { id: 'specifications', label: 'Caractéristiques' },
                { id: 'shipping', label: 'Livraison & Retours' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-6 py-4 font-medium transition-all whitespace-nowrap border-b-2 -mb-px ${
                    activeTab === tab.id
                      ? 'text-purple-400 border-purple-500'
                      : 'text-slate-400 border-transparent hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="py-6">
              {activeTab === 'description' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2">
                    <div className="prose prose-invert max-w-none">
                      <p className="text-slate-300 whitespace-pre-line leading-relaxed">
                        {product.description}
                      </p>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-4">Points forts</h3>
                    <ul className="space-y-3">
                      {product.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <div className="w-5 h-5 bg-green-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                            <Check className="w-3 h-3 text-green-400" />
                          </div>
                          <span className="text-slate-300">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {activeTab === 'specifications' && (
                <div className="max-w-2xl">
                  <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
                    {product.specifications.map((spec, index) => (
                      <div
                        key={index}
                        className={`flex items-center justify-between p-4 ${
                          index !== product.specifications.length - 1 ? 'border-b border-slate-700' : ''
                        }`}
                      >
                        <span className="text-slate-400">{spec.label}</span>
                        <span className="text-white font-medium">{spec.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'shipping' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
                  <div className="p-6 bg-slate-800/50 border border-slate-700 rounded-2xl">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                        <Truck className="w-6 h-6 text-green-400" />
                      </div>
                      <h3 className="text-lg font-bold text-white">Livraison</h3>
                    </div>
                    <ul className="space-y-3 text-slate-300">
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-400" />
                        {product.shippingInfo.freeShipping 
                          ? 'Livraison gratuite sur Abidjan'
                          : `Frais de livraison: ${formatPrice(product.shippingInfo.shippingCost || 0)}`
                        }
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-400" />
                        Délai estimé: {product.shippingInfo.estimatedDays}
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-400" />
                        Suivi de commande disponible
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-400" />
                        Paiement à la livraison accepté
                      </li>
                    </ul>
                  </div>
                  <div className="p-6 bg-slate-800/50 border border-slate-700 rounded-2xl">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                        <RefreshCw className="w-6 h-6 text-blue-400" />
                      </div>
                      <h3 className="text-lg font-bold text-white">Retours & Garantie</h3>
                    </div>
                    <ul className="space-y-3 text-slate-300">
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-blue-400" />
                        {product.returnPolicy}
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-blue-400" />
                        {product.warranty}
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-blue-400" />
                        Produit authentique garanti
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-blue-400" />
                        Service client disponible
                      </li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Reviews Section */}
          <div className="mt-12 pt-8 border-t border-slate-700">
            <ProductReviewsSection
              productId={product.id}
              productName={product.name}
              productImage={product.images[0]}
              sellerId={product.seller.id}
            />
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="mt-12 pt-8 border-t border-slate-700">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">Produits similaires</h2>
                <Link
                  to={`/products?category=${encodeURIComponent(product.category)}`}
                  className="text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1"
                >
                  Voir tout
                  <ChevronRight className="w-4 h-4" />
                </Link>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {relatedProducts.map(relatedProduct => (
                  <Link
                    key={relatedProduct.id}
                    to={`/products/${relatedProduct.id}`}
                    className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden hover:border-slate-600 transition-all group"
                  >
                    <div className="relative aspect-square">
                      <img
                        src={relatedProduct.image}
                        alt={relatedProduct.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      {relatedProduct.originalPrice && (
                        <div className="absolute top-2 left-2 px-2 py-1 bg-red-500 text-white text-xs font-bold rounded-lg">
                          -{Math.round((1 - relatedProduct.price / relatedProduct.originalPrice) * 100)}%
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="text-white font-medium line-clamp-2 mb-2 group-hover:text-purple-400 transition-colors">
                        {relatedProduct.name}
                      </h3>
                      <div className="flex items-center gap-1 mb-2">
                        <Star className="w-4 h-4 text-yellow-400" fill="currentColor" />
                        <span className="text-white text-sm">{relatedProduct.rating}</span>
                        <span className="text-slate-500 text-sm">({relatedProduct.reviews})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-white">{formatPrice(relatedProduct.price)}</span>
                        {relatedProduct.originalPrice && (
                          <span className="text-sm text-slate-500 line-through">
                            {formatPrice(relatedProduct.originalPrice)}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </section>
      </main>

      <Footer />

      {/* Image Modal */}
      {showImageModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95">
          <button
            onClick={() => setShowImageModal(false)}
            className="absolute top-4 right-4 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <button
            onClick={() => setSelectedImage(prev => prev === 0 ? product.images.length - 1 : prev - 1)}
            className="absolute left-4 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => setSelectedImage(prev => prev === product.images.length - 1 ? 0 : prev + 1)}
            className="absolute right-4 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <img
            src={product.images[selectedImage]}
            alt={product.name}
            className="max-w-full max-h-[85vh] object-contain"
          />
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {product.images.map((_, index) => (
              <button
                key={index}
                onClick={() => setSelectedImage(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  selectedImage === index ? 'bg-white scale-125' : 'bg-white/40 hover:bg-white/60'
                }`}
              />
            ))}
          </div>
        </div>
      )}

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowShareModal(false)} />
          <div className="relative w-full max-w-sm bg-slate-900 rounded-3xl p-6">
            <button
              onClick={() => setShowShareModal(false)}
              className="absolute top-4 right-4 p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-bold text-white mb-6">Partager ce produit</h2>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleShare('copy')}
                className="flex items-center justify-center gap-2 p-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors"
              >
                <Copy className="w-5 h-5" />
                Copier le lien
              </button>
              <button
                onClick={() => handleShare('whatsapp')}
                className="flex items-center justify-center gap-2 p-4 bg-green-600/20 hover:bg-green-600/30 text-green-400 rounded-xl transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
                WhatsApp
              </button>
              <button
                onClick={() => handleShare('facebook')}
                className="flex items-center justify-center gap-2 p-4 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 rounded-xl transition-colors"
              >
                <Facebook className="w-5 h-5" />
                Facebook
              </button>
              <button
                onClick={() => handleShare('twitter')}
                className="flex items-center justify-center gap-2 p-4 bg-sky-600/20 hover:bg-sky-600/30 text-sky-400 rounded-xl transition-colors"
              >
                <Twitter className="w-5 h-5" />
                Twitter
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Contact Seller Modal */}
      <ContactSellerModal
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
        seller={{
          name: product.seller.name,
          location: product.seller.location,
          rating: product.seller.rating,
          verified: product.seller.verified,
          responseTime: product.seller.responseTime
        }}
        product={{
          name: product.name,
          price: product.price,
          image: product.images[0]
        }}
      />

      {/* Order Modal */}
      {showOrderModal && (
        <OrderFormModal
          isOpen={showOrderModal}
          onClose={() => setShowOrderModal(false)}
          product={{
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.images[0],
            seller: product.seller.name,
            sellerId: product.seller.id
          }}
          quantity={quantity}
        />
      )}

      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
};

export default ProductDetailPage;
