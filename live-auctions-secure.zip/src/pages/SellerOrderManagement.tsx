import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, ShoppingBag, Search, Filter, ChevronDown, ChevronUp, Package,
  Truck, Home, Clock, CheckCircle, X, MapPin, Phone, User, Mail,
  Copy, ExternalLink, MessageSquare, DollarSign, Calendar, Send,
  AlertCircle, RefreshCw, Eye, MoreVertical, Bell, TrendingUp,
  FileText, Printer, Download, ChevronRight, Star, Image as ImageIcon
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders, Order, OrderStats } from '@/hooks/useOrders';
import { useMessaging } from '@/hooks/useMessaging';
import { useNotifications } from '@/hooks/useNotifications';
import { formatPrice } from '@/data/mockData';
import { toast } from '@/components/ui/use-toast';

// Mock orders for demonstration
const mockOrders: Order[] = [
  {
    id: '1',
    order_number: 'ORD-2026-001',
    buyer_id: 'buyer1',
    seller_id: 'seller1',
    status: 'pending',
    subtotal: 850000,
    shipping_fee: 5000,
    total: 855000,
    payment_method: 'cash_on_delivery',
    payment_status: 'pending',
    created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    updated_at: new Date().toISOString(),
    order_items: [
      { id: '1', order_id: '1', product_id: 'p1', product_name: 'iPhone 15 Pro Max', product_image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=100', quantity: 1, unit_price: 850000, total_price: 850000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a1', user_id: 'buyer1', name: 'Aminata Koné', phone: '+225 07 12 34 56 78', location: 'Cocody Riviera 3, Rue des Jardins, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    order_status_history: [
      { id: 'h1', order_id: '1', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString() }
    ]
  },
  {
    id: '2',
    order_number: 'ORD-2026-002',
    buyer_id: 'buyer2',
    seller_id: 'seller1',
    status: 'confirmed',
    subtotal: 1200000,
    shipping_fee: 0,
    total: 1200000,
    payment_method: 'cash_on_delivery',
    payment_status: 'pending',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    updated_at: new Date().toISOString(),
    confirmed_at: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    order_items: [
      { id: '2', order_id: '2', product_id: 'p2', product_name: 'MacBook Air M3', product_image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=100', quantity: 1, unit_price: 1200000, total_price: 1200000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a2', user_id: 'buyer2', name: 'Kouadio Marc', phone: '+225 05 98 76 54 32', location: 'Plateau, Avenue Noguès, Immeuble CCIA, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    order_status_history: [
      { id: 'h2', order_id: '2', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString() },
      { id: 'h3', order_id: '2', status: 'confirmed', notes: 'Commande confirmée par le vendeur', created_at: new Date(Date.now() - 1000 * 60 * 60).toISOString() }
    ]
  },
  {
    id: '3',
    order_number: 'ORD-2026-003',
    buyer_id: 'buyer3',
    seller_id: 'seller1',
    status: 'shipped',
    subtotal: 180000,
    shipping_fee: 3000,
    total: 183000,
    payment_method: 'cash_on_delivery',
    payment_status: 'pending',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    updated_at: new Date().toISOString(),
    confirmed_at: new Date(Date.now() - 1000 * 60 * 60 * 20).toISOString(),
    shipped_at: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    order_items: [
      { id: '3', order_id: '3', product_id: 'p3', product_name: 'AirPods Pro 2', product_image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=100', quantity: 1, unit_price: 180000, total_price: 180000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a3', user_id: 'buyer3', name: 'Fatou Sanogo', phone: '+225 01 23 45 67 89', location: 'Yopougon Maroc, Carrefour Siporex, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    shipping_info: [{ id: 's1', order_id: '3', carrier: 'Chronopost CI', tracking_number: 'CP123456789CI', tracking_url: 'https://chronopost.ci/track', estimated_delivery: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2).toISOString(), created_at: new Date().toISOString(), updated_at: new Date().toISOString() }],
    order_status_history: [
      { id: 'h4', order_id: '3', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString() },
      { id: 'h5', order_id: '3', status: 'confirmed', notes: 'Commande confirmée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 20).toISOString() },
      { id: 'h6', order_id: '3', status: 'shipped', notes: 'Colis expédié via Chronopost CI', created_at: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString() }
    ]
  },
  {
    id: '4',
    order_number: 'ORD-2026-004',
    buyer_id: 'buyer4',
    seller_id: 'seller1',
    status: 'delivered',
    subtotal: 650000,
    shipping_fee: 5000,
    total: 655000,
    payment_method: 'cash_on_delivery',
    payment_status: 'paid',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
    updated_at: new Date().toISOString(),
    confirmed_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3 + 1000 * 60 * 60).toISOString(),
    shipped_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
    delivered_at: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
    order_items: [
      { id: '4', order_id: '4', product_id: 'p4', product_name: 'Samsung Galaxy S24 Ultra', product_image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=100', quantity: 1, unit_price: 650000, total_price: 650000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a4', user_id: 'buyer4', name: 'Ibrahim Touré', phone: '+225 07 87 65 43 21', location: 'Marcory Zone 4, Rue du Commerce, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    shipping_info: [{ id: 's2', order_id: '4', carrier: 'Livraison personnelle', tracking_number: '', estimated_delivery: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(), actual_delivery: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(), created_at: new Date().toISOString(), updated_at: new Date().toISOString() }],
    order_status_history: [
      { id: 'h7', order_id: '4', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString() },
      { id: 'h8', order_id: '4', status: 'confirmed', notes: 'Commande confirmée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3 + 1000 * 60 * 60).toISOString() },
      { id: 'h9', order_id: '4', status: 'shipped', notes: 'En cours de livraison', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString() },
      { id: 'h10', order_id: '4', status: 'delivered', notes: 'Livré et payé', created_at: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString() }
    ]
  },
  {
    id: '5',
    order_number: 'ORD-2026-005',
    buyer_id: 'buyer5',
    seller_id: 'seller1',
    status: 'pending',
    subtotal: 450000,
    shipping_fee: 5000,
    total: 455000,
    payment_method: 'cash_on_delivery',
    payment_status: 'pending',
    created_at: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    updated_at: new Date().toISOString(),
    order_items: [
      { id: '5', order_id: '5', product_id: 'p5', product_name: 'Sony WH-1000XM5', product_image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=100', quantity: 1, unit_price: 250000, total_price: 250000, created_at: new Date().toISOString() },
      { id: '6', order_id: '5', product_id: 'p6', product_name: 'Apple Watch Series 9', product_image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=100', quantity: 1, unit_price: 200000, total_price: 200000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a5', user_id: 'buyer5', name: 'Marie Bamba', phone: '+225 05 11 22 33 44', location: 'Treichville, Avenue 17, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    order_status_history: [
      { id: 'h11', order_id: '5', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 15).toISOString() }
    ]
  }
];

const SellerOrderManagement: React.FC = () => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const {
    loading,
    getSellerOrders,
    getOrderStats,
    updateOrderStatus,
    addShippingInfo,
    getStatusLabel,
    getStatusColor,
    getPaymentStatusLabel,
    getPaymentStatusColor
  } = useOrders();
  const { createConversation } = useMessaging();
  const { notifyOrderUpdate } = useNotifications();

  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [stats, setStats] = useState<OrderStats>({
    total: 5,
    pending: 2,
    confirmed: 1,
    shipped: 1,
    delivered: 1,
    cancelled: 0,
    totalRevenue: 3348000
  });
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showOrderDetail, setShowOrderDetail] = useState(false);
  const [showShippingModal, setShowShippingModal] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageText, setMessageText] = useState('');
  const [shippingForm, setShippingForm] = useState({
    carrier: '',
    trackingNumber: '',
    trackingUrl: '',
    estimatedDelivery: '',
    shippingNotes: ''
  });

  const statusOptions = [
    { value: 'all', label: 'Toutes', count: stats.total, color: 'bg-slate-500' },
    { value: 'pending', label: 'En attente', count: stats.pending, color: 'bg-yellow-500' },
    { value: 'confirmed', label: 'Confirmées', count: stats.confirmed, color: 'bg-blue-500' },
    { value: 'shipped', label: 'Expédiées', count: stats.shipped, color: 'bg-purple-500' },
    { value: 'delivered', label: 'Livrées', count: stats.delivered, color: 'bg-green-500' },
    { value: 'cancelled', label: 'Annulées', count: stats.cancelled, color: 'bg-red-500' }
  ];

  const carriers = [
    'Chronopost CI',
    'DHL Express',
    'Fedex',
    'Jumia Express',
    'Livraison personnelle',
    'Autre'
  ];

  const filteredOrders = orders.filter(order => {
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    const matchesSearch = !searchQuery || 
      order.order_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.delivery_addresses?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.order_items?.some(item => item.product_name.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesStatus && matchesSearch;
  });
  const handleStatusUpdate = async (orderId: string, newStatus: Order['status']) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        const now = new Date().toISOString();
        const updatedOrder = { ...o, status: newStatus, updated_at: now };
        
        if (newStatus === 'confirmed') updatedOrder.confirmed_at = now;
        if (newStatus === 'shipped') updatedOrder.shipped_at = now;
        if (newStatus === 'delivered') {
          updatedOrder.delivered_at = now;
          updatedOrder.payment_status = 'paid';
        }
        
        // Add to history
        const newHistory = {
          id: `h${Date.now()}`,
          order_id: orderId,
          status: newStatus,
          notes: getStatusNotes(newStatus),
          created_at: now
        };
        updatedOrder.order_status_history = [...(o.order_status_history || []), newHistory];
        
        return updatedOrder;
      }
      return o;
    }));

    // Update stats
    setStats(prev => {
      const newStats = { ...prev };
      newStats[order.status as keyof Omit<OrderStats, 'total' | 'totalRevenue'>]--;
      newStats[newStatus as keyof Omit<OrderStats, 'total' | 'totalRevenue'>]++;
      return newStats;
    });

    toast({
      title: "Statut mis à jour",
      description: `La commande est maintenant "${getStatusLabel(newStatus)}"`,
    });

    // Send notification to buyer
    if (order.buyer_id && ['confirmed', 'shipped', 'delivered', 'cancelled'].includes(newStatus)) {
      try {
        await notifyOrderUpdate(
          order.buyer_id,
          order.id,
          newStatus as 'confirmed' | 'shipped' | 'delivered' | 'cancelled',
          {
            orderTotal: order.total,
            sellerName: profile?.full_name || 'Vendeur',
            sellerId: user?.id,
            orderNumber: order.order_number,
            productName: order.order_items?.[0]?.product_name,
            productImage: order.order_items?.[0]?.product_image,
            trackingNumber: order.shipping_info?.[0]?.tracking_number,
            estimatedDelivery: order.shipping_info?.[0]?.estimated_delivery
          }
        );
        console.log('Notification sent to buyer');
      } catch (err) {
        console.error('Failed to send notification:', err);
      }
    }

    if (selectedOrder?.id === orderId) {
      setSelectedOrder(prev => prev ? { ...prev, status: newStatus } : null);
    }
  };


  const getStatusNotes = (status: Order['status']): string => {
    const notes: Record<Order['status'], string> = {
      pending: 'Commande en attente',
      confirmed: 'Commande confirmée par le vendeur',
      shipped: 'Commande expédiée',
      delivered: 'Commande livrée avec succès',
      cancelled: 'Commande annulée'
    };
    return notes[status];
  };

  const handleAddShipping = (orderId: string) => {
    setOrders(prev => prev.map(order => {
      if (order.id === orderId) {
        const shippingInfo = {
          id: `s${Date.now()}`,
          order_id: orderId,
          carrier: shippingForm.carrier,
          tracking_number: shippingForm.trackingNumber,
          tracking_url: shippingForm.trackingUrl,
          estimated_delivery: shippingForm.estimatedDelivery,
          shipping_notes: shippingForm.shippingNotes,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
        return { ...order, shipping_info: [shippingInfo] };
      }
      return order;
    }));

    handleStatusUpdate(orderId, 'shipped');
    setShowShippingModal(false);
    setShippingForm({
      carrier: '',
      trackingNumber: '',
      trackingUrl: '',
      estimatedDelivery: '',
      shippingNotes: ''
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copié!",
      description: "Le texte a été copié dans le presse-papier",
    });
  };

  const handleSendMessage = async () => {
    if (!selectedOrder || !messageText.trim()) return;
    
    // In a real app, this would send via the messaging system
    toast({
      title: "Message envoyé",
      description: `Votre message a été envoyé à ${selectedOrder.delivery_addresses?.name}`,
    });
    setMessageText('');
    setShowMessageModal(false);
  };

  const getTimeAgo = (date: string): string => {
    const now = new Date();
    const then = new Date(date);
    const diffMs = now.getTime() - then.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;
    return then.toLocaleDateString('fr-FR');
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'pending': return <Clock className="w-5 h-5" />;
      case 'confirmed': return <CheckCircle className="w-5 h-5" />;
      case 'shipped': return <Truck className="w-5 h-5" />;
      case 'delivered': return <Home className="w-5 h-5" />;
      case 'cancelled': return <X className="w-5 h-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate(-1)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-white text-xl font-bold">Gestion des Commandes</h1>
                <p className="text-slate-400 text-sm">Gérez vos commandes et communiquez avec vos clients</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button className="relative p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-colors">
                <Bell className="w-5 h-5" />
                {stats.pending > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {stats.pending}
                  </span>
                )}
              </button>
              <button 
                onClick={() => window.location.reload()}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-colors"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-2xl p-4 border border-blue-500/30">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-blue-500/30 flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-blue-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-white">{stats.total}</p>
            <p className="text-blue-300 text-sm">Total commandes</p>
          </div>
          <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 rounded-2xl p-4 border border-yellow-500/30">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-yellow-500/30 flex items-center justify-center">
                <Clock className="w-5 h-5 text-yellow-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-white">{stats.pending}</p>
            <p className="text-yellow-300 text-sm">En attente</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl p-4 border border-purple-500/30">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-purple-500/30 flex items-center justify-center">
                <Truck className="w-5 h-5 text-purple-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-white">{stats.shipped}</p>
            <p className="text-purple-300 text-sm">En transit</p>
          </div>
          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-2xl p-4 border border-green-500/30">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-green-500/30 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-white">{stats.delivered}</p>
            <p className="text-green-300 text-sm">Livrées</p>
          </div>
          <div className="col-span-2 bg-gradient-to-br from-orange-500/20 to-red-500/20 rounded-2xl p-4 border border-orange-500/30">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-orange-500/30 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-orange-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-white">{formatPrice(stats.totalRevenue)}</p>
            <p className="text-orange-300 text-sm">Revenus totaux</p>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="Rechercher par numéro, client ou produit..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
              />
            </div>
            
            {/* Status Filter */}
            <div className="flex gap-2 overflow-x-auto pb-2 lg:pb-0">
              {statusOptions.map(option => (
                <button
                  key={option.value}
                  onClick={() => setStatusFilter(option.value)}
                  className={`px-4 py-2.5 rounded-xl font-medium whitespace-nowrap transition-all flex items-center gap-2 ${
                    statusFilter === option.value
                      ? 'bg-orange-500 text-white'
                      : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${option.color}`}></span>
                  {option.label}
                  <span className={`px-2 py-0.5 rounded-full text-xs ${
                    statusFilter === option.value ? 'bg-white/20' : 'bg-slate-600'
                  }`}>
                    {option.count}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Orders List */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Orders Column */}
          <div className="lg:col-span-2 space-y-4">
            {filteredOrders.length === 0 ? (
              <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
                <ShoppingBag className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <h3 className="text-white text-xl font-semibold mb-2">Aucune commande</h3>
                <p className="text-slate-400">
                  {statusFilter !== 'all' 
                    ? `Aucune commande avec le statut "${statusOptions.find(o => o.value === statusFilter)?.label}"`
                    : 'Vous n\'avez pas encore reçu de commandes'}
                </p>
              </div>
            ) : (
              filteredOrders.map(order => (
                <div 
                  key={order.id} 
                  onClick={() => {
                    setSelectedOrder(order);
                    setShowOrderDetail(true);
                  }}
                  className={`bg-slate-800/50 rounded-2xl border transition-all cursor-pointer hover:border-orange-500/50 ${
                    selectedOrder?.id === order.id ? 'border-orange-500' : 'border-slate-700'
                  }`}
                >
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                          order.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                          order.status === 'confirmed' ? 'bg-blue-500/20 text-blue-400' :
                          order.status === 'shipped' ? 'bg-purple-500/20 text-purple-400' :
                          order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {getStatusIcon(order.status)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-white font-semibold">{order.order_number}</h4>
                            {order.status === 'pending' && (
                              <span className="px-2 py-0.5 bg-yellow-500/20 text-yellow-400 text-xs font-medium rounded-full animate-pulse">
                                Nouveau
                              </span>
                            )}
                          </div>
                          <p className="text-slate-400 text-sm">{getTimeAgo(order.created_at)}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-orange-500 font-bold">{formatPrice(order.total)}</p>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          order.payment_status === 'paid' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {order.payment_status === 'paid' ? 'Payé' : 'À payer'}
                        </span>
                      </div>
                    </div>

                    {/* Customer Info */}
                    <div className="flex items-center gap-3 mb-4 p-3 bg-slate-900/50 rounded-xl">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                        {order.delivery_addresses?.name.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-medium">{order.delivery_addresses?.name}</p>
                        <p className="text-slate-400 text-sm flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {order.delivery_addresses?.phone}
                        </p>
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedOrder(order);
                          setShowMessageModal(true);
                        }}
                        className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
                      >
                        <MessageSquare className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Products */}
                    <div className="flex gap-2 overflow-x-auto pb-2">
                      {order.order_items?.map(item => (
                        <div key={item.id} className="flex-shrink-0 flex items-center gap-2 p-2 bg-slate-900/50 rounded-lg">
                          {item.product_image ? (
                            <img src={item.product_image} alt={item.product_name} className="w-10 h-10 rounded-lg object-cover" />
                          ) : (
                            <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center">
                              <Package className="w-5 h-5 text-slate-500" />
                            </div>
                          )}
                          <div>
                            <p className="text-white text-sm font-medium line-clamp-1 max-w-[120px]">{item.product_name}</p>
                            <p className="text-slate-400 text-xs">x{item.quantity}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Quick Actions */}
                    <div className="flex gap-2 mt-4 pt-4 border-t border-slate-700">
                      {order.status === 'pending' && (
                        <>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleStatusUpdate(order.id, 'confirmed');
                            }}
                            className="flex-1 py-2 bg-blue-500 text-white font-semibold rounded-xl hover:bg-blue-600 transition-all flex items-center justify-center gap-2"
                          >
                            <CheckCircle className="w-4 h-4" />
                            Confirmer
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm('Êtes-vous sûr de vouloir annuler cette commande?')) {
                                handleStatusUpdate(order.id, 'cancelled');
                              }
                            }}
                            className="px-4 py-2 bg-red-500/20 text-red-400 font-semibold rounded-xl hover:bg-red-500/30 transition-all"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </>
                      )}
                      {order.status === 'confirmed' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedOrder(order);
                            setShowShippingModal(true);
                          }}
                          className="flex-1 py-2 bg-purple-500 text-white font-semibold rounded-xl hover:bg-purple-600 transition-all flex items-center justify-center gap-2"
                        >
                          <Truck className="w-4 h-4" />
                          Marquer comme expédié
                        </button>
                      )}
                      {order.status === 'shipped' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStatusUpdate(order.id, 'delivered');
                          }}
                          className="flex-1 py-2 bg-green-500 text-white font-semibold rounded-xl hover:bg-green-600 transition-all flex items-center justify-center gap-2"
                        >
                          <Home className="w-4 h-4" />
                          Marquer comme livré
                        </button>
                      )}
                      {order.status === 'delivered' && (
                        <div className="flex-1 py-2 bg-green-500/20 text-green-400 font-semibold rounded-xl flex items-center justify-center gap-2">
                          <CheckCircle className="w-4 h-4" />
                          Commande terminée
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Order Detail Sidebar */}
          <div className="hidden lg:block">
            {selectedOrder ? (
              <div className="bg-slate-800/50 rounded-2xl border border-slate-700 sticky top-24">
                <div className="p-4 border-b border-slate-700">
                  <div className="flex items-center justify-between">
                    <h3 className="text-white font-semibold">Détails de la commande</h3>
                    <button 
                      onClick={() => setSelectedOrder(null)}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                
                <div className="p-4 space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto">
                  {/* Order Info */}
                  <div className="p-3 bg-slate-900/50 rounded-xl">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-slate-400 text-sm">Numéro</span>
                      <span className="text-white font-mono">{selectedOrder.order_number}</span>
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-slate-400 text-sm">Date</span>
                      <span className="text-white text-sm">
                        {new Date(selectedOrder.created_at).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-sm">Statut</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        selectedOrder.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                        selectedOrder.status === 'confirmed' ? 'bg-blue-500/20 text-blue-400' :
                        selectedOrder.status === 'shipped' ? 'bg-purple-500/20 text-purple-400' :
                        selectedOrder.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        {getStatusLabel(selectedOrder.status)}
                      </span>
                    </div>
                  </div>

                  {/* Customer */}
                  <div>
                    <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-400" />
                      Client
                    </h4>
                    <div className="p-3 bg-slate-900/50 rounded-xl space-y-2">
                      <p className="text-white font-medium">{selectedOrder.delivery_addresses?.name}</p>
                      <div className="flex items-center gap-2 text-slate-300">
                        <Phone className="w-4 h-4 text-slate-400" />
                        <span>{selectedOrder.delivery_addresses?.phone}</span>
                        <button 
                          onClick={() => copyToClipboard(selectedOrder.delivery_addresses!.phone)}
                          className="p-1 hover:bg-slate-700 rounded"
                        >
                          <Copy className="w-3 h-3 text-slate-500" />
                        </button>
                      </div>
                      <button
                        onClick={() => setShowMessageModal(true)}
                        className="w-full mt-2 py-2 bg-slate-700 text-white font-medium rounded-lg hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
                      >
                        <MessageSquare className="w-4 h-4" />
                        Envoyer un message
                      </button>
                    </div>
                  </div>

                  {/* Delivery Address */}
                  <div>
                    <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-slate-400" />
                      Adresse de livraison
                    </h4>
                    <div className="p-3 bg-slate-900/50 rounded-xl">
                      <p className="text-slate-300 text-sm">{selectedOrder.delivery_addresses?.location}</p>
                    </div>
                  </div>

                  {/* Products */}
                  <div>
                    <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                      <Package className="w-4 h-4 text-slate-400" />
                      Articles ({selectedOrder.order_items?.length})
                    </h4>
                    <div className="space-y-2">
                      {selectedOrder.order_items?.map(item => (
                        <div key={item.id} className="flex items-center gap-3 p-2 bg-slate-900/50 rounded-xl">
                          {item.product_image ? (
                            <img src={item.product_image} alt={item.product_name} className="w-12 h-12 rounded-lg object-cover" />
                          ) : (
                            <div className="w-12 h-12 rounded-lg bg-slate-700 flex items-center justify-center">
                              <Package className="w-5 h-5 text-slate-500" />
                            </div>
                          )}
                          <div className="flex-1">
                            <p className="text-white text-sm font-medium">{item.product_name}</p>
                            <p className="text-slate-400 text-xs">{formatPrice(item.unit_price)} x {item.quantity}</p>
                          </div>
                          <p className="text-orange-500 font-semibold text-sm">{formatPrice(item.total_price)}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Total */}
                  <div className="p-3 bg-orange-500/10 rounded-xl border border-orange-500/30">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-400 text-sm">Sous-total</span>
                      <span className="text-white">{formatPrice(selectedOrder.subtotal)}</span>
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-slate-400 text-sm">Livraison</span>
                      <span className="text-white">{formatPrice(selectedOrder.shipping_fee)}</span>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-orange-500/30">
                      <span className="text-white font-semibold">Total</span>
                      <span className="text-orange-500 font-bold text-lg">{formatPrice(selectedOrder.total)}</span>
                    </div>
                    <p className="text-orange-300 text-xs mt-2 text-center">
                      Paiement à la livraison
                    </p>
                  </div>

                  {/* Shipping Info */}
                  {selectedOrder.shipping_info && selectedOrder.shipping_info[0] && (
                    <div>
                      <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                        <Truck className="w-4 h-4 text-slate-400" />
                        Suivi de livraison
                      </h4>
                      <div className="p-3 bg-slate-900/50 rounded-xl space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 text-sm">Transporteur</span>
                          <span className="text-white">{selectedOrder.shipping_info[0].carrier}</span>
                        </div>
                        {selectedOrder.shipping_info[0].tracking_number && (
                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 text-sm">N° de suivi</span>
                            <div className="flex items-center gap-2">
                              <span className="text-white font-mono text-sm">{selectedOrder.shipping_info[0].tracking_number}</span>
                              <button 
                                onClick={() => copyToClipboard(selectedOrder.shipping_info![0].tracking_number!)}
                                className="p-1 hover:bg-slate-700 rounded"
                              >
                                <Copy className="w-3 h-3 text-slate-500" />
                              </button>
                            </div>
                          </div>
                        )}
                        {selectedOrder.shipping_info[0].estimated_delivery && (
                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 text-sm">Livraison estimée</span>
                            <span className="text-white">
                              {new Date(selectedOrder.shipping_info[0].estimated_delivery).toLocaleDateString('fr-FR')}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Order Timeline */}
                  <div>
                    <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-slate-400" />
                      Historique
                    </h4>
                    <div className="space-y-3">
                      {selectedOrder.order_status_history?.slice().reverse().map((history, index) => (
                        <div key={history.id} className="flex gap-3">
                          <div className="flex flex-col items-center">
                            <div className={`w-3 h-3 rounded-full ${
                              index === 0 ? 'bg-orange-500' : 'bg-slate-600'
                            }`}></div>
                            {index < (selectedOrder.order_status_history?.length || 0) - 1 && (
                              <div className="w-0.5 h-full bg-slate-700 my-1"></div>
                            )}
                          </div>
                          <div className="flex-1 pb-3">
                            <p className="text-white text-sm font-medium">{history.notes}</p>
                            <p className="text-slate-500 text-xs">
                              {new Date(history.created_at).toLocaleDateString('fr-FR', {
                                day: 'numeric',
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-8 text-center">
                <Eye className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                <h3 className="text-white font-semibold mb-2">Sélectionnez une commande</h3>
                <p className="text-slate-400 text-sm">Cliquez sur une commande pour voir ses détails</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Shipping Modal */}
      {showShippingModal && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <h3 className="text-white text-xl font-bold">Informations de livraison</h3>
                <button onClick={() => setShowShippingModal(false)} className="text-slate-400 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-white font-medium mb-2">Transporteur *</label>
                <select
                  value={shippingForm.carrier}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, carrier: e.target.value }))}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="">Sélectionner un transporteur</option>
                  {carriers.map(carrier => (
                    <option key={carrier} value={carrier}>{carrier}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">Numéro de suivi</label>
                <input
                  type="text"
                  value={shippingForm.trackingNumber}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, trackingNumber: e.target.value }))}
                  placeholder="Ex: CI1234567890"
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">URL de suivi (optionnel)</label>
                <input
                  type="url"
                  value={shippingForm.trackingUrl}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, trackingUrl: e.target.value }))}
                  placeholder="https://..."
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">Date de livraison estimée</label>
                <input
                  type="date"
                  value={shippingForm.estimatedDelivery}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, estimatedDelivery: e.target.value }))}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-white font-medium mb-2">Notes (optionnel)</label>
                <textarea
                  value={shippingForm.shippingNotes}
                  onChange={(e) => setShippingForm(prev => ({ ...prev, shippingNotes: e.target.value }))}
                  placeholder="Instructions spéciales..."
                  rows={2}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 resize-none"
                />
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowShippingModal(false)}
                className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
              >
                Annuler
              </button>
              <button
                onClick={() => handleAddShipping(selectedOrder.id)}
                disabled={!shippingForm.carrier}
                className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg transition-all disabled:opacity-50 flex items-center gap-2"
              >
                <Truck className="w-5 h-5" />
                Confirmer l'expédition
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Message Modal */}
      {showMessageModal && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                    {selectedOrder.delivery_addresses?.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">{selectedOrder.delivery_addresses?.name}</h3>
                    <p className="text-slate-400 text-sm">Commande {selectedOrder.order_number}</p>
                  </div>
                </div>
                <button onClick={() => setShowMessageModal(false)} className="text-slate-400 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6">
              {/* Quick Messages */}
              <div className="mb-4">
                <p className="text-slate-400 text-sm mb-2">Messages rapides</p>
                <div className="flex flex-wrap gap-2">
                  {[
                    'Votre commande est en préparation',
                    'Votre colis sera expédié aujourd\'hui',
                    'Pouvez-vous confirmer votre adresse?',
                    'Merci pour votre commande!'
                  ].map((msg, i) => (
                    <button
                      key={i}
                      onClick={() => setMessageText(msg)}
                      className="px-3 py-1.5 bg-slate-700 text-slate-300 text-sm rounded-lg hover:bg-slate-600 transition-colors"
                    >
                      {msg}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-white font-medium mb-2">Votre message</label>
                <textarea
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="Écrivez votre message..."
                  rows={4}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 resize-none"
                />
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowMessageModal(false)}
                className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
              >
                Annuler
              </button>
              <button
                onClick={handleSendMessage}
                disabled={!messageText.trim()}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg transition-all disabled:opacity-50 flex items-center gap-2"
              >
                <Send className="w-5 h-5" />
                Envoyer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Order Detail Modal */}
      {showOrderDetail && selectedOrder && (
        <div className="lg:hidden fixed inset-0 z-50 bg-slate-900">
          <div className="h-full flex flex-col">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h3 className="text-white font-semibold">Détails de la commande</h3>
              <button 
                onClick={() => setShowOrderDetail(false)}
                className="p-2 text-slate-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {/* Same content as sidebar */}
              {/* Order Info */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Numéro</span>
                  <span className="text-white font-mono">{selectedOrder.order_number}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Date</span>
                  <span className="text-white text-sm">
                    {new Date(selectedOrder.created_at).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Statut</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    selectedOrder.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                    selectedOrder.status === 'confirmed' ? 'bg-blue-500/20 text-blue-400' :
                    selectedOrder.status === 'shipped' ? 'bg-purple-500/20 text-purple-400' :
                    selectedOrder.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {getStatusLabel(selectedOrder.status)}
                  </span>
                </div>
              </div>

              {/* Customer */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <User className="w-4 h-4 text-slate-400" />
                  Client
                </h4>
                <p className="text-white font-medium mb-2">{selectedOrder.delivery_addresses?.name}</p>
                <div className="flex items-center gap-2 text-slate-300 mb-3">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <span>{selectedOrder.delivery_addresses?.phone}</span>
                  <button 
                    onClick={() => copyToClipboard(selectedOrder.delivery_addresses!.phone)}
                    className="p-1 hover:bg-slate-700 rounded"
                  >
                    <Copy className="w-3 h-3 text-slate-500" />
                  </button>
                </div>
                <button
                  onClick={() => setShowMessageModal(true)}
                  className="w-full py-2 bg-slate-700 text-white font-medium rounded-lg hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  Envoyer un message
                </button>
              </div>

              {/* Delivery Address */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  Adresse de livraison
                </h4>
                <p className="text-slate-300 text-sm">{selectedOrder.delivery_addresses?.location}</p>
              </div>

              {/* Products */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Package className="w-4 h-4 text-slate-400" />
                  Articles ({selectedOrder.order_items?.length})
                </h4>
                <div className="space-y-2">
                  {selectedOrder.order_items?.map(item => (
                    <div key={item.id} className="flex items-center gap-3 p-2 bg-slate-900/50 rounded-xl">
                      {item.product_image ? (
                        <img src={item.product_image} alt={item.product_name} className="w-12 h-12 rounded-lg object-cover" />
                      ) : (
                        <div className="w-12 h-12 rounded-lg bg-slate-700 flex items-center justify-center">
                          <Package className="w-5 h-5 text-slate-500" />
                        </div>
                      )}
                      <div className="flex-1">
                        <p className="text-white text-sm font-medium">{item.product_name}</p>
                        <p className="text-slate-400 text-xs">{formatPrice(item.unit_price)} x {item.quantity}</p>
                      </div>
                      <p className="text-orange-500 font-semibold text-sm">{formatPrice(item.total_price)}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total */}
              <div className="p-3 bg-orange-500/10 rounded-xl border border-orange-500/30">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-400 text-sm">Sous-total</span>
                  <span className="text-white">{formatPrice(selectedOrder.subtotal)}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Livraison</span>
                  <span className="text-white">{formatPrice(selectedOrder.shipping_fee)}</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-orange-500/30">
                  <span className="text-white font-semibold">Total</span>
                  <span className="text-orange-500 font-bold text-lg">{formatPrice(selectedOrder.total)}</span>
                </div>
                <p className="text-orange-300 text-xs mt-2 text-center">
                  Paiement à la livraison
                </p>
              </div>

              {/* Order Timeline */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-400" />
                  Historique
                </h4>
                <div className="space-y-3">
                  {selectedOrder.order_status_history?.slice().reverse().map((history, index) => (
                    <div key={history.id} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <div className={`w-3 h-3 rounded-full ${
                          index === 0 ? 'bg-orange-500' : 'bg-slate-600'
                        }`}></div>
                        {index < (selectedOrder.order_status_history?.length || 0) - 1 && (
                          <div className="w-0.5 h-full bg-slate-700 my-1"></div>
                        )}
                      </div>
                      <div className="flex-1 pb-3">
                        <p className="text-white text-sm font-medium">{history.notes}</p>
                        <p className="text-slate-500 text-xs">
                          {new Date(history.created_at).toLocaleDateString('fr-FR', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 border-t border-slate-700">
              {selectedOrder.status === 'pending' && (
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      handleStatusUpdate(selectedOrder.id, 'confirmed');
                      setShowOrderDetail(false);
                    }}
                    className="flex-1 py-3 bg-blue-500 text-white font-semibold rounded-xl hover:bg-blue-600 transition-all flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-5 h-5" />
                    Confirmer
                  </button>
                  <button
                    onClick={() => {
                      if (confirm('Êtes-vous sûr de vouloir annuler cette commande?')) {
                        handleStatusUpdate(selectedOrder.id, 'cancelled');
                        setShowOrderDetail(false);
                      }
                    }}
                    className="px-4 py-3 bg-red-500/20 text-red-400 font-semibold rounded-xl hover:bg-red-500/30 transition-all"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}
              {selectedOrder.status === 'confirmed' && (
                <button
                  onClick={() => {
                    setShowShippingModal(true);
                  }}
                  className="w-full py-3 bg-purple-500 text-white font-semibold rounded-xl hover:bg-purple-600 transition-all flex items-center justify-center gap-2"
                >
                  <Truck className="w-5 h-5" />
                  Marquer comme expédié
                </button>
              )}
              {selectedOrder.status === 'shipped' && (
                <button
                  onClick={() => {
                    handleStatusUpdate(selectedOrder.id, 'delivered');
                    setShowOrderDetail(false);
                  }}
                  className="w-full py-3 bg-green-500 text-white font-semibold rounded-xl hover:bg-green-600 transition-all flex items-center justify-center gap-2"
                >
                  <Home className="w-5 h-5" />
                  Marquer comme livré
                </button>
              )}
              {selectedOrder.status === 'delivered' && (
                <div className="w-full py-3 bg-green-500/20 text-green-400 font-semibold rounded-xl flex items-center justify-center gap-2">
                  <CheckCircle className="w-5 h-5" />
                  Commande terminée
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SellerOrderManagement;
