import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useAppContext } from '@/contexts/AppContext';
import { useOrders, Order } from '@/hooks/useOrders';
import { useNotifications, NotificationPreferences, FollowedSeller } from '@/hooks/useNotifications';
import { useMessaging, Conversation, Message } from '@/hooks/useMessaging';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import OrderHistorySection from '@/components/OrderHistorySection';
import { NotificationSettings } from '@/components/NotificationSettings';
import { EmailPreferences } from '@/components/EmailPreferences';

import { 
  Camera,
  Edit3, 
  Settings, 
  Package, 
  Heart, 
  MapPin, 
  Calendar, 
  Phone, 
  Mail, 
  Shield, 
  Eye, 
  EyeOff,
  Check,
  X,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  Star,
  Users,
  ShoppingBag,
  Clock,
  Truck,
  CheckCircle,
  AlertCircle,
  Lock,
  Bell,
  Globe,
  Trash2,
  LogOut,
  Store,
  Video,
  BadgeCheck,
  Home,
  Search,
  Filter,
  RefreshCw,
  Copy,
  BellRing,
  BellOff,
  Volume2,
  VolumeX,
  UserPlus,
  UserMinus,
  Tag,
  Play,
  Banknote,
  MessageCircle,
  Send,
  Circle
} from 'lucide-react';
import { formatPrice } from '@/data/mockData';





const mockOrders = [
  {
    id: 'ORD-2026-001',
    items: [
      { name: 'iPhone 15 Pro Max', quantity: 1, price: 850000, image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=100' }
    ],
    total: 850000,
    status: 'delivered',
    date: '2026-01-20',
    seller: 'TechStore CI'
  },
  {
    id: 'ORD-2026-002',
    items: [
      { name: 'Ensemble Wax Traditionnel', quantity: 2, price: 45000, image: 'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=100' },
      { name: 'Collier Perles Africaines', quantity: 1, price: 28000, image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=100' }
    ],
    total: 118000,
    status: 'in_transit',
    date: '2026-01-22',
    seller: 'Awa Fashion'
  },
  {
    id: 'ORD-2026-003',
    items: [
      { name: 'Nike Air Max 270', quantity: 1, price: 85000, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=100' }
    ],
    total: 85000,
    status: 'confirmed',
    date: '2026-01-24',
    seller: 'SneakerHead ABJ'
  },
  {
    id: 'ORD-2026-004',
    items: [
      { name: 'Montre Casio G-Shock', quantity: 1, price: 75000, image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100' }
    ],
    total: 75000,
    status: 'pending',
    date: '2026-01-24',
    seller: 'Chrono Luxe'
  }
];

// Mock followed sellers for display
const mockFollowedSellers = [
  { id: 'seller-1', name: 'TechStore CI', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100', followers: 12500 },
  { id: 'seller-2', name: 'Awa Fashion', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100', followers: 8900 },
  { id: 'seller-3', name: 'SneakerHead ABJ', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', followers: 5600 },
];


const Profile: React.FC = () => {
  const navigate = useNavigate();
  const { user, profile, updateProfile, signOut, loading } = useAuth();

  const { wishlist } = useAppContext();
  const {
    loading: ordersLoading,
    getBuyerOrders,
    getStatusLabel,
    getStatusColor,
    getPaymentStatusLabel,
    getPaymentStatusColor
  } = useOrders();

  const {
    preferences: notifPreferences,
    following,
    fetchPreferences,
    updatePreferences,
    fetchFollowing,
    unfollowSeller,
    toggleSellerNotifications
  } = useNotifications();

  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'settings'>('profile');
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderStats, setOrderStats] = useState({
    pending: 0,
    confirmed: 0,
    shipped: 0,
    delivered: 0
  });
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const [isEditing, setIsEditing] = useState(false);

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  // Form state
  const [formData, setFormData] = useState({
    full_name: '',
    phone: '',
    store_name: '',
    bio: '',
    location: ''
  });

  // Password form state
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  const [passwordErrors, setPasswordErrors] = useState<string[]>([]);
  const [changingPassword, setChangingPassword] = useState(false);

  // Settings state - now using notification preferences from hook
  const [localPrefs, setLocalPrefs] = useState<Partial<NotificationPreferences>>({
    push_notifications: true,
    email_notifications: true,
    live_start_notifications: true,
    replay_notifications: true,
    order_notifications: true,
    promo_notifications: true,
    message_notifications: true,
    product_sale_notifications: true,
    price_drop_notifications: true,
    review_notifications: true,
    weekly_digest: false,
    marketing_emails: false,
    sound_enabled: true
  });

  const [settings, setSettings] = useState({
    language: 'fr',
    currency: 'XOF',
    privateProfile: false
  });

  // Load notification preferences
  useEffect(() => {
    if (user) {
      fetchPreferences(user.id).then(prefs => {
        if (prefs) setLocalPrefs(prefs);
      });
    }
  }, [user, fetchPreferences]);



  // Cover photo state
  const [coverPhoto, setCoverPhoto] = useState('https://images.unsplash.com/photo-1557683316-973673baf926?w=1200');

  // Initialize form data from profile

  // Initialize form data from profile
  useEffect(() => {
    if (profile) {
      setFormData({
        full_name: profile.full_name || '',
        phone: profile.phone || '',
        store_name: profile.store_name || '',
        bio: '',
        location: 'Abidjan, Côte d\'Ivoire'
      });
    }
  }, [profile]);

  // Fetch orders when tab changes or filter changes
  useEffect(() => {
    if (activeTab === 'orders' && user) {
      fetchOrders();
    }
  }, [activeTab, user, orderStatusFilter, currentPage]);

  const fetchOrders = async () => {
    if (!user) return;
    const result = await getBuyerOrders(user.id, orderStatusFilter, currentPage, 10);
    setOrders(result.orders);
    setTotalPages(result.totalPages);
    
    // Calculate stats
    const stats = {
      pending: result.orders.filter(o => o.status === 'pending').length,
      confirmed: result.orders.filter(o => o.status === 'confirmed').length,
      shipped: result.orders.filter(o => o.status === 'shipped').length,
      delivered: result.orders.filter(o => o.status === 'delivered').length
    };
    setOrderStats(stats);
  };


  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveProfile = async () => {
    if (!formData.full_name.trim()) {
      toast({
        title: "Erreur",
        description: "Le nom complet est requis",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      const result = await updateProfile({
        full_name: formData.full_name.trim(),
        phone: formData.phone.trim() || undefined,
        store_name: formData.store_name.trim() || undefined
      });

      if (result.success) {
        setIsEditing(false);
        toast({
          title: "Profil mis à jour",
          description: "Vos informations ont été enregistrées avec succès"
        });
      } else {
        toast({
          title: "Erreur",
          description: result.error || "Impossible de mettre à jour le profil",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner une image",
        variant: "destructive"
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Erreur",
        description: "L'image ne doit pas dépasser 5MB",
        variant: "destructive"
      });
      return;
    }

    // For demo, create a local URL
    const localUrl = URL.createObjectURL(file);
    
    // In production, upload to Supabase Storage
    try {
      setSaving(true);
      
      // Simulate upload delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      await updateProfile({ avatar_url: localUrl });
      
      toast({
        title: "Photo mise à jour",
        description: "Votre photo de profil a été changée"
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour la photo",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner une image",
        variant: "destructive"
      });
      return;
    }

    const localUrl = URL.createObjectURL(file);
    setCoverPhoto(localUrl);
    
    toast({
      title: "Couverture mise à jour",
      description: "Votre photo de couverture a été changée"
    });
  };

  const validatePassword = () => {
    const errors: string[] = [];
    
    if (passwordData.newPassword.length < 8) {
      errors.push("Le mot de passe doit contenir au moins 8 caractères");
    }
    if (!/[A-Z]/.test(passwordData.newPassword)) {
      errors.push("Le mot de passe doit contenir au moins une majuscule");
    }
    if (!/[0-9]/.test(passwordData.newPassword)) {
      errors.push("Le mot de passe doit contenir au moins un chiffre");
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      errors.push("Les mots de passe ne correspondent pas");
    }
    
    setPasswordErrors(errors);
    return errors.length === 0;
  };

  const handleChangePassword = async () => {
    if (!validatePassword()) return;

    setChangingPassword(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: passwordData.newPassword
      });

      if (error) {
        toast({
          title: "Erreur",
          description: error.message,
          variant: "destructive"
        });
      } else {
        toast({
          title: "Mot de passe modifié",
          description: "Votre mot de passe a été changé avec succès"
        });
        setShowPasswordModal(false);
        setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue",
        variant: "destructive"
      });
    } finally {
      setChangingPassword(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const getOrderStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'confirmed': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'in_transit': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'delivered': return 'bg-green-500/20 text-green-400 border-green-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  const getOrderStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'En attente';
      case 'confirmed': return 'Confirmée';
      case 'in_transit': return 'En livraison';
      case 'delivered': return 'Livrée';
      default: return status;
    }
  };


  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'confirmed': return <CheckCircle className="w-4 h-4" />;
      case 'in_transit': return <Truck className="w-4 h-4" />;
      case 'delivered': return <Check className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  const displayName = profile?.full_name || user?.email?.split('@')[0] || 'Utilisateur';
  const memberSince = profile?.created_at ? new Date(profile.created_at).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' }) : 'Janvier 2026';

  // Stats for the profile - use real wishlist count
  const stats = {
    orders: mockOrders.length,
    wishlist: wishlist.length,
    reviews: 8,
    followers: profile?.user_type === 'seller' ? 1247 : 0,
    following: 34,
    likes: profile?.user_type === 'seller' ? 8934 : 156
  };


  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-lg border-b border-slate-800">
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          <button 
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
            <span className="font-medium">Retour</span>
          </button>
          <h1 className="text-white font-semibold">Profil</h1>
          <button 
            onClick={() => setActiveTab('settings')}
            className="p-2 text-slate-400 hover:text-white transition-colors"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Cover Photo - TikTok/Facebook Style */}
      <div className="relative pt-14">
        <div className="h-48 sm:h-64 md:h-80 relative overflow-hidden">
          <img 
            src={coverPhoto}
            alt="Cover"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />
          
          {/* Cover Edit Button */}
          <button 
            onClick={() => coverInputRef.current?.click()}
            className="absolute top-4 right-4 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-colors"
          >
            <Camera className="w-5 h-5" />
          </button>
          <input
            ref={coverInputRef}
            type="file"
            accept="image/*"
            onChange={handleCoverUpload}
            className="hidden"
          />
        </div>

        {/* Profile Section - Overlapping Avatar */}
        <div className="max-w-4xl mx-auto px-4 -mt-20 sm:-mt-24 relative z-10">
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-4 sm:gap-6">
            {/* Avatar */}
            <div className="relative group">
              <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full border-4 border-slate-950 overflow-hidden bg-slate-800 shadow-2xl">
                {profile?.avatar_url ? (
                  <img 
                    src={profile.avatar_url}
                    alt={displayName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center text-white text-4xl sm:text-5xl font-bold">
                    {getInitials(displayName)}
                  </div>
                )}
              </div>
              
              {/* Avatar Edit Button */}
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-2 right-2 p-2.5 bg-orange-500 rounded-full text-white shadow-lg hover:bg-orange-600 transition-colors group-hover:scale-110"
              >
                <Camera className="w-4 h-4" />
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />

              {/* Online Status */}
              <div className="absolute bottom-2 left-2 w-5 h-5 bg-green-500 rounded-full border-4 border-slate-950" />
            </div>

            {/* User Info */}
            <div className="flex-1 text-center sm:text-left pb-2">
              <div className="flex items-center justify-center sm:justify-start gap-2 mb-1">
                <h1 className="text-2xl sm:text-3xl font-bold text-white">{displayName}</h1>
                {profile?.is_verified && (
                  <BadgeCheck className="w-6 h-6 text-blue-500" />
                )}
              </div>
              
              {profile?.user_type === 'seller' && profile?.store_name && (
                <div className="flex items-center justify-center sm:justify-start gap-2 mb-2">
                  <Store className="w-4 h-4 text-purple-400" />
                  <span className="text-purple-400 font-medium">{profile.store_name}</span>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-slate-400 text-sm">
                <span className="flex items-center gap-1">
                  <Mail className="w-4 h-4" />
                  {user?.email}
                </span>
                {profile?.phone && (
                  <span className="flex items-center gap-1">
                    <Phone className="w-4 h-4" />
                    {profile.phone}
                  </span>
                )}
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  Abidjan, CI
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Membre depuis {memberSince}
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <button
                onClick={() => setIsEditing(true)}
                className="px-6 py-2.5 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-full hover:shadow-lg hover:shadow-orange-500/30 transition-all flex items-center gap-2"
              >
                <Edit3 className="w-4 h-4" />
                Modifier
              </button>
              {profile?.user_type === 'seller' && (
                <button className="px-6 py-2.5 bg-slate-800 text-white font-semibold rounded-full border border-slate-700 hover:border-orange-500/50 transition-all flex items-center gap-2">
                  <Video className="w-4 h-4" />
                  Go Live
                </button>
              )}
            </div>
          </div>

          {/* Stats Bar - TikTok Style */}
          <div className="mt-6 py-4 border-y border-slate-800">
            <div className="flex items-center justify-center sm:justify-start gap-8 sm:gap-12">
              {profile?.user_type === 'seller' ? (
                <>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{stats.followers.toLocaleString()}</p>
                    <p className="text-slate-400 text-sm">Abonnés</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{stats.following}</p>
                    <p className="text-slate-400 text-sm">Abonnements</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{stats.likes.toLocaleString()}</p>
                    <p className="text-slate-400 text-sm">J'aime</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{stats.orders}</p>
                    <p className="text-slate-400 text-sm">Commandes</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{stats.wishlist}</p>
                    <p className="text-slate-400 text-sm">Favoris</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{stats.reviews}</p>
                    <p className="text-slate-400 text-sm">Avis</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{stats.likes}</p>
                    <p className="text-slate-400 text-sm">J'aime</p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-4xl mx-auto px-4 mt-6">
        <div className="flex border-b border-slate-800">
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-4 text-center font-medium transition-colors relative ${
              activeTab === 'profile' ? 'text-orange-500' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="flex items-center justify-center gap-2">
              <Edit3 className="w-4 h-4" />
              Profil
            </span>
            {activeTab === 'profile' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex-1 py-4 text-center font-medium transition-colors relative ${
              activeTab === 'orders' ? 'text-orange-500' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="flex items-center justify-center gap-2">
              <Package className="w-4 h-4" />
              Commandes
            </span>
            {activeTab === 'orders' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex-1 py-4 text-center font-medium transition-colors relative ${
              activeTab === 'settings' ? 'text-orange-500' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="flex items-center justify-center gap-2">
              <Settings className="w-4 h-4" />
              Paramètres
            </span>
            {activeTab === 'settings' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500" />
            )}
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="max-w-4xl mx-auto px-4 py-6 pb-20">
        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            {/* Personal Information Card */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-orange-500" />
                  Informations Personnelles
                </h2>
                {!isEditing && (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="text-orange-500 hover:text-orange-400 text-sm font-medium"
                  >
                    Modifier
                  </button>
                )}
              </div>

              <div className="p-4 sm:p-6 space-y-4">
                {isEditing ? (
                  <>
                    <div>
                      <label className="block text-slate-400 text-sm mb-2">Nom complet *</label>
                      <input
                        type="text"
                        name="full_name"
                        value={formData.full_name}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        placeholder="Votre nom complet"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 text-sm mb-2">Téléphone</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        placeholder="+225 XX XX XX XX XX"
                      />
                    </div>

                    {profile?.user_type === 'seller' && (
                      <div>
                        <label className="block text-slate-400 text-sm mb-2">Nom de la boutique</label>
                        <input
                          type="text"
                          name="store_name"
                          value={formData.store_name}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          placeholder="Nom de votre boutique"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-slate-400 text-sm mb-2">Bio</label>
                      <textarea
                        name="bio"
                        value={formData.bio}
                        onChange={handleInputChange}
                        rows={3}
                        className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                        placeholder="Parlez-nous de vous..."
                      />
                    </div>

                    <div className="flex gap-3 pt-2">
                      <button
                        onClick={handleSaveProfile}
                        disabled={saving}
                        className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {saving ? (
                          <>
                            <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                            </svg>
                            Enregistrement...
                          </>
                        ) : (
                          <>
                            <Check className="w-5 h-5" />
                            Enregistrer
                          </>
                        )}
                      </button>
                      <button
                        onClick={() => {
                          setIsEditing(false);
                          setFormData({
                            full_name: profile?.full_name || '',
                            phone: profile?.phone || '',
                            store_name: profile?.store_name || '',
                            bio: '',
                            location: 'Abidjan, Côte d\'Ivoire'
                          });
                        }}
                        className="px-6 py-3 bg-slate-800 text-slate-300 font-semibold rounded-xl border border-slate-700 hover:border-slate-600 transition-all"
                      >
                        Annuler
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between py-3 border-b border-slate-800">
                      <span className="text-slate-400">Nom complet</span>
                      <span className="text-white font-medium">{profile?.full_name || '-'}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-800">
                      <span className="text-slate-400">Email</span>
                      <span className="text-white font-medium">{user?.email}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-800">
                      <span className="text-slate-400">Téléphone</span>
                      <span className="text-white font-medium">{profile?.phone || '-'}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-800">
                      <span className="text-slate-400">Type de compte</span>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        profile?.user_type === 'seller' 
                          ? 'bg-purple-500/20 text-purple-400' 
                          : 'bg-blue-500/20 text-blue-400'
                      }`}>
                        {profile?.user_type === 'seller' ? 'Vendeur' : 'Acheteur'}
                      </span>
                    </div>
                    {profile?.user_type === 'seller' && (
                      <div className="flex items-center justify-between py-3 border-b border-slate-800">
                        <span className="text-slate-400">Boutique</span>
                        <span className="text-white font-medium">{profile?.store_name || '-'}</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between py-3">
                      <span className="text-slate-400">Statut</span>
                      <span className={`flex items-center gap-2 ${profile?.is_verified ? 'text-green-400' : 'text-yellow-400'}`}>
                        {profile?.is_verified ? (
                          <>
                            <BadgeCheck className="w-4 h-4" />
                            Vérifié
                          </>
                        ) : (
                          <>
                            <AlertCircle className="w-4 h-4" />
                            Non vérifié
                          </>
                        )}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Security Card */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-slate-800">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Shield className="w-5 h-5 text-orange-500" />
                  Sécurité
                </h2>
              </div>

              <div className="p-4 sm:p-6">
                <button
                  onClick={() => setShowPasswordModal(true)}
                  className="w-full flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:border-orange-500/50 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                      <Lock className="w-5 h-5 text-orange-500" />
                    </div>
                    <div className="text-left">
                      <p className="text-white font-medium">Changer le mot de passe</p>
                      <p className="text-slate-400 text-sm">Dernière modification: il y a 30 jours</p>
                    </div>
                  </div>
                  <ChevronLeft className="w-5 h-5 text-slate-400 rotate-180 group-hover:text-orange-500 transition-colors" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Orders Tab */}
        {activeTab === 'orders' && (
          <OrderHistorySection />
        )}


        {/* Settings Tab */}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            {/* Notification Preferences */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-slate-800">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Bell className="w-5 h-5 text-orange-500" />
                  Préférences de Notifications
                </h2>
                <p className="text-slate-400 text-sm mt-1">Gérez comment vous recevez les notifications</p>
              </div>

              <div className="p-4 sm:p-6 space-y-5">
                {/* Push Notifications Master Toggle */}
                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                      <BellRing className="w-5 h-5 text-orange-500" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Notifications push</p>
                      <p className="text-slate-400 text-sm">Activer toutes les notifications</p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      const newValue = !localPrefs.push_notifications;
                      setLocalPrefs(p => ({ ...p, push_notifications: newValue }));
                      if (user) updatePreferences(user.id, { push_notifications: newValue });
                    }}
                    className={`w-12 h-6 rounded-full transition-colors ${localPrefs.push_notifications ? 'bg-orange-500' : 'bg-slate-700'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${localPrefs.push_notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
                  </button>
                </div>

                {/* Notification Types */}
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Types de notifications</h3>
                  
                  {/* Live Start Notifications */}
                  <div className="flex items-center justify-between py-3 border-b border-slate-800">
                    <div className="flex items-center gap-3">
                      <Video className="w-5 h-5 text-red-500" />
                      <div>
                        <p className="text-white font-medium">Démarrage de lives</p>
                        <p className="text-slate-400 text-sm">Quand un vendeur suivi démarre un live</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const newValue = !localPrefs.live_start_notifications;
                        setLocalPrefs(p => ({ ...p, live_start_notifications: newValue }));
                        if (user) updatePreferences(user.id, { live_start_notifications: newValue });
                      }}
                      disabled={!localPrefs.push_notifications}
                      className={`w-12 h-6 rounded-full transition-colors ${localPrefs.live_start_notifications && localPrefs.push_notifications ? 'bg-orange-500' : 'bg-slate-700'} ${!localPrefs.push_notifications ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${localPrefs.live_start_notifications && localPrefs.push_notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
                    </button>
                  </div>

                  {/* Replay Notifications */}
                  <div className="flex items-center justify-between py-3 border-b border-slate-800">
                    <div className="flex items-center gap-3">
                      <Play className="w-5 h-5 text-purple-500" />
                      <div>
                        <p className="text-white font-medium">Nouvelles rediffusions</p>
                        <p className="text-slate-400 text-sm">Quand une rediffusion est disponible</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const newValue = !localPrefs.replay_notifications;
                        setLocalPrefs(p => ({ ...p, replay_notifications: newValue }));
                        if (user) updatePreferences(user.id, { replay_notifications: newValue });
                      }}
                      disabled={!localPrefs.push_notifications}
                      className={`w-12 h-6 rounded-full transition-colors ${localPrefs.replay_notifications && localPrefs.push_notifications ? 'bg-orange-500' : 'bg-slate-700'} ${!localPrefs.push_notifications ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${localPrefs.replay_notifications && localPrefs.push_notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
                    </button>
                  </div>

                  {/* Order Notifications */}
                  <div className="flex items-center justify-between py-3 border-b border-slate-800">
                    <div className="flex items-center gap-3">
                      <Package className="w-5 h-5 text-blue-500" />
                      <div>
                        <p className="text-white font-medium">Mises à jour de commandes</p>
                        <p className="text-slate-400 text-sm">Statut de vos commandes</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const newValue = !localPrefs.order_notifications;
                        setLocalPrefs(p => ({ ...p, order_notifications: newValue }));
                        if (user) updatePreferences(user.id, { order_notifications: newValue });
                      }}
                      disabled={!localPrefs.push_notifications}
                      className={`w-12 h-6 rounded-full transition-colors ${localPrefs.order_notifications && localPrefs.push_notifications ? 'bg-orange-500' : 'bg-slate-700'} ${!localPrefs.push_notifications ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${localPrefs.order_notifications && localPrefs.push_notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
                    </button>
                  </div>

                  {/* Promo Notifications */}
                  <div className="flex items-center justify-between py-3 border-b border-slate-800">
                    <div className="flex items-center gap-3">
                      <Tag className="w-5 h-5 text-green-500" />
                      <div>
                        <p className="text-white font-medium">Promotions et offres</p>
                        <p className="text-slate-400 text-sm">Offres spéciales et réductions</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const newValue = !localPrefs.promo_notifications;
                        setLocalPrefs(p => ({ ...p, promo_notifications: newValue }));
                        if (user) updatePreferences(user.id, { promo_notifications: newValue });
                      }}
                      disabled={!localPrefs.push_notifications}
                      className={`w-12 h-6 rounded-full transition-colors ${localPrefs.promo_notifications && localPrefs.push_notifications ? 'bg-orange-500' : 'bg-slate-700'} ${!localPrefs.push_notifications ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${localPrefs.promo_notifications && localPrefs.push_notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
                    </button>
                  </div>

                  {/* Sound Toggle */}
                  <div className="flex items-center justify-between py-3">
                    <div className="flex items-center gap-3">
                      {localPrefs.sound_enabled ? (
                        <Volume2 className="w-5 h-5 text-cyan-500" />
                      ) : (
                        <VolumeX className="w-5 h-5 text-slate-500" />
                      )}
                      <div>
                        <p className="text-white font-medium">Son des notifications</p>
                        <p className="text-slate-400 text-sm">Jouer un son à chaque notification</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const newValue = !localPrefs.sound_enabled;
                        setLocalPrefs(p => ({ ...p, sound_enabled: newValue }));
                        if (user) updatePreferences(user.id, { sound_enabled: newValue });
                      }}
                      disabled={!localPrefs.push_notifications}
                      className={`w-12 h-6 rounded-full transition-colors ${localPrefs.sound_enabled && localPrefs.push_notifications ? 'bg-orange-500' : 'bg-slate-700'} ${!localPrefs.push_notifications ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${localPrefs.sound_enabled && localPrefs.push_notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Followed Sellers */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-slate-800">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-orange-500" />
                  Vendeurs Suivis
                </h2>
                <p className="text-slate-400 text-sm mt-1">Gérez les notifications par vendeur</p>
              </div>

              <div className="p-4 sm:p-6">
                {mockFollowedSellers.length === 0 ? (
                  <div className="text-center py-8">
                    <UserPlus className="w-12 h-12 mx-auto text-slate-600 mb-3" />
                    <p className="text-slate-400">Vous ne suivez aucun vendeur</p>
                    <p className="text-slate-500 text-sm mt-1">Suivez des vendeurs pour recevoir leurs notifications</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {mockFollowedSellers.map((seller) => (
                      <div key={seller.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-xl">
                        <div className="flex items-center gap-3">
                          <img
                            src={seller.avatar}
                            alt={seller.name}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                          <div>
                            <p className="text-white font-medium">{seller.name}</p>
                            <p className="text-slate-400 text-sm">{seller.followers.toLocaleString()} abonnés</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            className="p-2 text-slate-400 hover:text-orange-500 transition-colors"
                            title="Activer/Désactiver les notifications"
                          >
                            <BellRing className="w-5 h-5" />
                          </button>
                          <button
                            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                            title="Ne plus suivre"
                          >
                            <UserMinus className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>


            {/* Email Preferences Section */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-slate-800">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Mail className="w-5 h-5 text-orange-500" />
                  Préférences Email
                </h2>
                <p className="text-slate-400 text-sm mt-1">Gérez les emails que vous recevez</p>
              </div>
              <div className="p-4 sm:p-6">
                <EmailPreferences />
              </div>
            </div>

            {/* Preferences */}

            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-slate-800">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Globe className="w-5 h-5 text-orange-500" />
                  Préférences
                </h2>
              </div>

              <div className="p-4 sm:p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Langue</p>
                    <p className="text-slate-400 text-sm">Langue de l'interface</p>
                  </div>
                  <select 
                    value={settings.language}
                    onChange={(e) => setSettings(s => ({ ...s, language: e.target.value }))}
                    className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="fr">Français</option>
                    <option value="en">English</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Devise</p>
                    <p className="text-slate-400 text-sm">Devise pour les prix</p>
                  </div>
                  <select 
                    value={settings.currency}
                    onChange={(e) => setSettings(s => ({ ...s, currency: e.target.value }))}
                    className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="XOF">FCFA (XOF)</option>
                    <option value="EUR">Euro (EUR)</option>
                    <option value="USD">Dollar (USD)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Profil privé</p>
                    <p className="text-slate-400 text-sm">Masquer votre profil aux autres</p>
                  </div>
                  <button
                    onClick={() => setSettings(s => ({ ...s, privateProfile: !s.privateProfile }))}
                    className={`w-12 h-6 rounded-full transition-colors ${settings.privateProfile ? 'bg-orange-500' : 'bg-slate-700'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${settings.privateProfile ? 'translate-x-6' : 'translate-x-0.5'}`} />
                  </button>
                </div>
              </div>
            </div>

            {/* Danger Zone */}
            <div className="bg-slate-900 rounded-2xl border border-red-500/30 overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-slate-800">
                <h2 className="text-lg font-semibold text-red-400 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  Zone de Danger
                </h2>
              </div>

              <div className="p-4 sm:p-6 space-y-4">
                <button
                  onClick={handleSignOut}
                  className="w-full flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:border-red-500/50 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                      <LogOut className="w-5 h-5 text-red-500" />
                    </div>
                    <div className="text-left">
                      <p className="text-white font-medium">Se déconnecter</p>
                      <p className="text-slate-400 text-sm">Déconnexion de votre compte</p>
                    </div>
                  </div>
                </button>

                <button className="w-full flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:border-red-500/50 transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                      <Trash2 className="w-5 h-5 text-red-500" />
                    </div>
                    <div className="text-left">
                      <p className="text-red-400 font-medium">Supprimer le compte</p>
                      <p className="text-slate-400 text-sm">Cette action est irréversible</p>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-6 border-b border-slate-800 flex items-center justify-between">
              <h3 className="text-xl font-bold text-white">Changer le mot de passe</h3>
              <button
                onClick={() => {
                  setShowPasswordModal(false);
                  setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
                  setPasswordErrors([]);
                }}
                className="p-2 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Current Password */}
              <div>
                <label className="block text-slate-400 text-sm mb-2">Mot de passe actuel</label>
                <div className="relative">
                  <input
                    type={showPasswords.current ? 'text' : 'password'}
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData(p => ({ ...p, currentPassword: e.target.value }))}
                    className="w-full px-4 py-3 pr-12 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords(s => ({ ...s, current: !s.current }))}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPasswords.current ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* New Password */}
              <div>
                <label className="block text-slate-400 text-sm mb-2">Nouveau mot de passe</label>
                <div className="relative">
                  <input
                    type={showPasswords.new ? 'text' : 'password'}
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData(p => ({ ...p, newPassword: e.target.value }))}
                    className="w-full px-4 py-3 pr-12 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords(s => ({ ...s, new: !s.new }))}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPasswords.new ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-slate-400 text-sm mb-2">Confirmer le mot de passe</label>
                <div className="relative">
                  <input
                    type={showPasswords.confirm ? 'text' : 'password'}
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData(p => ({ ...p, confirmPassword: e.target.value }))}
                    className="w-full px-4 py-3 pr-12 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords(s => ({ ...s, confirm: !s.confirm }))}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPasswords.confirm ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Password Requirements */}
              <div className="p-4 bg-slate-800/50 rounded-xl">
                <p className="text-slate-400 text-sm mb-2">Le mot de passe doit contenir:</p>
                <ul className="space-y-1 text-sm">
                  <li className={`flex items-center gap-2 ${passwordData.newPassword.length >= 8 ? 'text-green-400' : 'text-slate-500'}`}>
                    {passwordData.newPassword.length >= 8 ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                    Au moins 8 caractères
                  </li>
                  <li className={`flex items-center gap-2 ${/[A-Z]/.test(passwordData.newPassword) ? 'text-green-400' : 'text-slate-500'}`}>
                    {/[A-Z]/.test(passwordData.newPassword) ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                    Une lettre majuscule
                  </li>
                  <li className={`flex items-center gap-2 ${/[0-9]/.test(passwordData.newPassword) ? 'text-green-400' : 'text-slate-500'}`}>
                    {/[0-9]/.test(passwordData.newPassword) ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                    Un chiffre
                  </li>
                  <li className={`flex items-center gap-2 ${passwordData.newPassword === passwordData.confirmPassword && passwordData.confirmPassword ? 'text-green-400' : 'text-slate-500'}`}>
                    {passwordData.newPassword === passwordData.confirmPassword && passwordData.confirmPassword ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                    Les mots de passe correspondent
                  </li>
                </ul>
              </div>

              {/* Errors */}
              {passwordErrors.length > 0 && (
                <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
                  <ul className="space-y-1 text-red-400 text-sm">
                    {passwordErrors.map((error, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <AlertCircle className="w-4 h-4" />
                        {error}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleChangePassword}
                  disabled={changingPassword || !passwordData.newPassword || !passwordData.confirmPassword}
                  className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {changingPassword ? (
                    <>
                      <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      Modification...
                    </>
                  ) : (
                    <>
                      <Lock className="w-5 h-5" />
                      Changer
                    </>
                  )}
                </button>
                <button
                  onClick={() => {
                    setShowPasswordModal(false);
                    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
                    setPasswordErrors([]);
                  }}
                  className="px-6 py-3 bg-slate-800 text-slate-300 font-semibold rounded-xl border border-slate-700 hover:border-slate-600 transition-all"
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;
