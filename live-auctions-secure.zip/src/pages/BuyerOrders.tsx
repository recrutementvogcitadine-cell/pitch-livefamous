import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, ShoppingBag, Search, Package, Truck, Home, Clock, CheckCircle,
  X, MapPin, Phone, User, Copy, ExternalLink, MessageSquare, Calendar, Send,
  AlertCircle, RefreshCw, Eye, ChevronRight, Star, Filter, ChevronDown,
  Store, CreditCard, FileText, HelpCircle, Ban, Bell, Settings
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders, Order } from '@/hooks/useOrders';
import { formatPrice } from '@/data/mockData';
import { toast } from '@/components/ui/use-toast';
import { OrderNotificationSettings } from '@/components/OrderNotificationSettings';

// Mock buyer orders for demonstration
const mockBuyerOrders: Order[] = [
  {
    id: '1',
    order_number: 'ORD-2026-001',
    buyer_id: 'current_user',
    seller_id: 'seller1',
    status: 'shipped',
    subtotal: 850000,
    shipping_fee: 5000,
    total: 855000,
    payment_method: 'cash_on_delivery',
    payment_status: 'pending',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
    updated_at: new Date().toISOString(),
    confirmed_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 60).toISOString(),
    shipped_at: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
    order_items: [
      { id: '1', order_id: '1', product_id: 'p1', product_name: 'iPhone 15 Pro Max 256GB', product_image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', quantity: 1, unit_price: 850000, total_price: 850000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a1', user_id: 'current_user', name: 'Mon Adresse', phone: '+225 07 12 34 56 78', location: 'Cocody Riviera 3, Rue des Jardins, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    shipping_info: [{ 
      id: 's1', 
      order_id: '1', 
      carrier: 'Chronopost CI', 
      tracking_number: 'CP123456789CI', 
      tracking_url: 'https://chronopost.ci/track', 
      estimated_delivery: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2).toISOString(), 
      created_at: new Date().toISOString(), 
      updated_at: new Date().toISOString() 
    }],
    order_status_history: [
      { id: 'h1', order_id: '1', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString() },
      { id: 'h2', order_id: '1', status: 'confirmed', notes: 'Commande confirmée par le vendeur', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 60).toISOString() },
      { id: 'h3', order_id: '1', status: 'shipped', notes: 'Colis expédié via Chronopost CI', created_at: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString() }
    ]
  },
  {
    id: '2',
    order_number: 'ORD-2026-002',
    buyer_id: 'current_user',
    seller_id: 'seller2',
    status: 'pending',
    subtotal: 180000,
    shipping_fee: 3000,
    total: 183000,
    payment_method: 'cash_on_delivery',
    payment_status: 'pending',
    created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    updated_at: new Date().toISOString(),
    order_items: [
      { id: '2', order_id: '2', product_id: 'p2', product_name: 'AirPods Pro 2ème génération', product_image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=400', quantity: 1, unit_price: 180000, total_price: 180000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a1', user_id: 'current_user', name: 'Mon Adresse', phone: '+225 07 12 34 56 78', location: 'Cocody Riviera 3, Rue des Jardins, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    order_status_history: [
      { id: 'h4', order_id: '2', status: 'pending', notes: 'Commande créée - En attente de confirmation', created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString() }
    ]
  },
  {
    id: '3',
    order_number: 'ORD-2026-003',
    buyer_id: 'current_user',
    seller_id: 'seller1',
    status: 'delivered',
    subtotal: 1200000,
    shipping_fee: 0,
    total: 1200000,
    payment_method: 'cash_on_delivery',
    payment_status: 'paid',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(),
    updated_at: new Date().toISOString(),
    confirmed_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7 + 1000 * 60 * 60 * 2).toISOString(),
    shipped_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(),
    delivered_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
    order_items: [
      { id: '3', order_id: '3', product_id: 'p3', product_name: 'MacBook Air M3 15"', product_image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400', quantity: 1, unit_price: 1200000, total_price: 1200000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a1', user_id: 'current_user', name: 'Mon Adresse', phone: '+225 07 12 34 56 78', location: 'Cocody Riviera 3, Rue des Jardins, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    shipping_info: [{ 
      id: 's2', 
      order_id: '3', 
      carrier: 'Livraison personnelle', 
      tracking_number: '', 
      estimated_delivery: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
      actual_delivery: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
      created_at: new Date().toISOString(), 
      updated_at: new Date().toISOString() 
    }],
    order_status_history: [
      { id: 'h5', order_id: '3', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString() },
      { id: 'h6', order_id: '3', status: 'confirmed', notes: 'Commande confirmée par le vendeur', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7 + 1000 * 60 * 60 * 2).toISOString() },
      { id: 'h7', order_id: '3', status: 'shipped', notes: 'En cours de livraison', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString() },
      { id: 'h8', order_id: '3', status: 'delivered', notes: 'Livré avec succès - Paiement reçu', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString() }
    ]
  },
  {
    id: '4',
    order_number: 'ORD-2026-004',
    buyer_id: 'current_user',
    seller_id: 'seller3',
    status: 'confirmed',
    subtotal: 450000,
    shipping_fee: 5000,
    total: 455000,
    payment_method: 'cash_on_delivery',
    payment_status: 'pending',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    updated_at: new Date().toISOString(),
    confirmed_at: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
    order_items: [
      { id: '4', order_id: '4', product_id: 'p4', product_name: 'Sony WH-1000XM5', product_image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400', quantity: 1, unit_price: 250000, total_price: 250000, created_at: new Date().toISOString() },
      { id: '5', order_id: '4', product_id: 'p5', product_name: 'Apple Watch Series 9', product_image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=400', quantity: 1, unit_price: 200000, total_price: 200000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a1', user_id: 'current_user', name: 'Mon Adresse', phone: '+225 07 12 34 56 78', location: 'Cocody Riviera 3, Rue des Jardins, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    order_status_history: [
      { id: 'h9', order_id: '4', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString() },
      { id: 'h10', order_id: '4', status: 'confirmed', notes: 'Commande confirmée - En préparation', created_at: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString() }
    ]
  },
  {
    id: '5',
    order_number: 'ORD-2026-005',
    buyer_id: 'current_user',
    seller_id: 'seller2',
    status: 'cancelled',
    subtotal: 650000,
    shipping_fee: 5000,
    total: 655000,
    payment_method: 'cash_on_delivery',
    payment_status: 'pending',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(),
    updated_at: new Date().toISOString(),
    cancelled_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 9).toISOString(),
    cancellation_reason: 'Produit non disponible',
    order_items: [
      { id: '6', order_id: '5', product_id: 'p6', product_name: 'Samsung Galaxy S24 Ultra', product_image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400', quantity: 1, unit_price: 650000, total_price: 650000, created_at: new Date().toISOString() }
    ],
    delivery_addresses: { id: 'a1', user_id: 'current_user', name: 'Mon Adresse', phone: '+225 07 12 34 56 78', location: 'Cocody Riviera 3, Rue des Jardins, Abidjan', is_default: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
    order_status_history: [
      { id: 'h11', order_id: '5', status: 'pending', notes: 'Commande créée', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString() },
      { id: 'h12', order_id: '5', status: 'cancelled', notes: 'Annulée par le vendeur - Produit non disponible', created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 9).toISOString() }
    ]
  }
];

// Mock seller data
const mockSellers: Record<string, { name: string; avatar: string; phone: string }> = {
  seller1: { name: 'TechStore Pro', avatar: 'TS', phone: '+225 01 23 45 67 89' },
  seller2: { name: 'Digital World', avatar: 'DW', phone: '+225 05 98 76 54 32' },
  seller3: { name: 'ElectroShop CI', avatar: 'ES', phone: '+225 07 11 22 33 44' }
};

const BuyerOrders: React.FC = () => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { getStatusLabel, getStatusColor } = useOrders();

  const [orders, setOrders] = useState<Order[]>(mockBuyerOrders);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showOrderDetail, setShowOrderDetail] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageText, setMessageText] = useState('');
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showNotificationSettings, setShowNotificationSettings] = useState(false);

  // Calculate stats
  const stats = {
    total: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    confirmed: orders.filter(o => o.status === 'confirmed').length,
    shipped: orders.filter(o => o.status === 'shipped').length,
    delivered: orders.filter(o => o.status === 'delivered').length,
    cancelled: orders.filter(o => o.status === 'cancelled').length
  };

  const statusOptions = [
    { value: 'all', label: 'Toutes', count: stats.total, color: 'bg-slate-500', icon: ShoppingBag },
    { value: 'pending', label: 'En attente', count: stats.pending, color: 'bg-yellow-500', icon: Clock },
    { value: 'confirmed', label: 'Confirmées', count: stats.confirmed, color: 'bg-blue-500', icon: CheckCircle },
    { value: 'shipped', label: 'En transit', count: stats.shipped, color: 'bg-purple-500', icon: Truck },
    { value: 'delivered', label: 'Livrées', count: stats.delivered, color: 'bg-green-500', icon: Home },
    { value: 'cancelled', label: 'Annulées', count: stats.cancelled, color: 'bg-red-500', icon: Ban }
  ];

  const filteredOrders = orders.filter(order => {
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    const matchesSearch = !searchQuery || 
      order.order_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.order_items?.some(item => item.product_name.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  const getTimeAgo = (date: string): string => {
    const now = new Date();
    const then = new Date(date);
    const diffMs = now.getTime() - then.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;
    return then.toLocaleDateString('fr-FR');
  };

  const getEstimatedDelivery = (order: Order): string | null => {
    if (order.shipping_info && order.shipping_info[0]?.estimated_delivery) {
      return new Date(order.shipping_info[0].estimated_delivery).toLocaleDateString('fr-FR', {
        weekday: 'long',
        day: 'numeric',
        month: 'long'
      });
    }
    return null;
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'pending': return <Clock className="w-5 h-5" />;
      case 'confirmed': return <CheckCircle className="w-5 h-5" />;
      case 'shipped': return <Truck className="w-5 h-5" />;
      case 'delivered': return <Home className="w-5 h-5" />;
      case 'cancelled': return <X className="w-5 h-5" />;
    }
  };

  const getStatusStep = (status: Order['status']): number => {
    switch (status) {
      case 'pending': return 1;
      case 'confirmed': return 2;
      case 'shipped': return 3;
      case 'delivered': return 4;
      case 'cancelled': return 0;
      default: return 0;
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copié!",
      description: "Le texte a été copié dans le presse-papier",
    });
  };

  const handleSendMessage = async () => {
    if (!selectedOrder || !messageText.trim()) return;
    
    toast({
      title: "Message envoyé",
      description: `Votre message a été envoyé au vendeur`,
    });
    setMessageText('');
    setShowMessageModal(false);
  };

  const getSeller = (sellerId: string) => mockSellers[sellerId] || { name: 'Vendeur', avatar: 'V', phone: '' };

  // Visual Timeline Component
  const OrderTimeline: React.FC<{ order: Order; compact?: boolean }> = ({ order, compact = false }) => {
    const steps = [
      { status: 'pending', label: 'Commande reçue', icon: ShoppingBag },
      { status: 'confirmed', label: 'Confirmée', icon: CheckCircle },
      { status: 'shipped', label: 'Expédiée', icon: Truck },
      { status: 'delivered', label: 'Livrée', icon: Home }
    ];

    const currentStep = getStatusStep(order.status);
    const isCancelled = order.status === 'cancelled';

    if (isCancelled) {
      return (
        <div className={`flex items-center justify-center ${compact ? 'py-2' : 'py-4'} bg-red-500/10 rounded-xl border border-red-500/30`}>
          <Ban className="w-5 h-5 text-red-400 mr-2" />
          <span className="text-red-400 font-medium">Commande annulée</span>
        </div>
      );
    }

    return (
      <div className={`${compact ? 'py-2' : 'py-4'}`}>
        <div className="flex items-center justify-between relative">
          {/* Progress Line */}
          <div className="absolute top-5 left-0 right-0 h-1 bg-slate-700 mx-8">
            <div 
              className="h-full bg-gradient-to-r from-orange-500 to-pink-500 transition-all duration-500"
              style={{ width: `${((currentStep - 1) / (steps.length - 1)) * 100}%` }}
            />
          </div>

          {steps.map((step, index) => {
            const stepNumber = index + 1;
            const isCompleted = stepNumber < currentStep;
            const isCurrent = stepNumber === currentStep;
            const isPending = stepNumber > currentStep;
            const StepIcon = step.icon;

            return (
              <div key={step.status} className="flex flex-col items-center relative z-10">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  isCompleted ? 'bg-gradient-to-br from-orange-500 to-pink-500 text-white' :
                  isCurrent ? 'bg-gradient-to-br from-orange-500 to-pink-500 text-white ring-4 ring-orange-500/30' :
                  'bg-slate-700 text-slate-500'
                }`}>
                  {isCompleted ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <StepIcon className="w-5 h-5" />
                  )}
                </div>
                {!compact && (
                  <span className={`text-xs mt-2 font-medium ${
                    isCompleted || isCurrent ? 'text-white' : 'text-slate-500'
                  }`}>
                    {step.label}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate(-1)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-white text-xl font-bold">Mes Commandes</h1>
                <p className="text-slate-400 text-sm">Suivez vos achats en temps réel</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setShowNotificationSettings(true)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-colors relative"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setShowHelpModal(true)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-colors"
              >
                <HelpCircle className="w-5 h-5" />
              </button>
              <button 
                onClick={() => window.location.reload()}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-colors"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>



      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3 mb-6">
          {statusOptions.map(option => {
            const Icon = option.icon;
            return (
              <button
                key={option.value}
                onClick={() => setStatusFilter(option.value)}
                className={`p-3 rounded-xl border transition-all ${
                  statusFilter === option.value 
                    ? 'bg-orange-500/20 border-orange-500' 
                    : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                }`}
              >
                <div className={`w-8 h-8 rounded-lg ${option.color}/20 flex items-center justify-center mb-2 mx-auto`}>
                  <Icon className={`w-4 h-4 ${option.color.replace('bg-', 'text-').replace('-500', '-400')}`} />
                </div>
                <p className="text-xl font-bold text-white text-center">{option.count}</p>
                <p className="text-slate-400 text-xs text-center">{option.label}</p>
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher par numéro de commande ou produit..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
            />
          </div>
        </div>

        {/* Orders List */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Orders Column */}
          <div className="lg:col-span-2 space-y-4">
            {filteredOrders.length === 0 ? (
              <div className="bg-slate-800/50 rounded-2xl p-12 border border-slate-700 text-center">
                <ShoppingBag className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <h3 className="text-white text-xl font-semibold mb-2">Aucune commande</h3>
                <p className="text-slate-400 mb-6">
                  {statusFilter !== 'all' 
                    ? `Aucune commande avec le statut "${statusOptions.find(o => o.value === statusFilter)?.label}"`
                    : 'Vous n\'avez pas encore passé de commande'}
                </p>
                <button
                  onClick={() => navigate('/')}
                  className="px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg transition-all"
                >
                  Découvrir les produits
                </button>
              </div>
            ) : (
              filteredOrders.map(order => {
                const seller = getSeller(order.seller_id);
                const estimatedDelivery = getEstimatedDelivery(order);
                
                return (
                  <div 
                    key={order.id} 
                    onClick={() => {
                      setSelectedOrder(order);
                      setShowOrderDetail(true);
                    }}
                    className={`bg-slate-800/50 rounded-2xl border transition-all cursor-pointer hover:border-orange-500/50 ${
                      selectedOrder?.id === order.id ? 'border-orange-500' : 'border-slate-700'
                    }`}
                  >
                    <div className="p-4">
                      {/* Header */}
                      <div className="flex items-start justify-between gap-4 mb-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                            order.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                            order.status === 'confirmed' ? 'bg-blue-500/20 text-blue-400' :
                            order.status === 'shipped' ? 'bg-purple-500/20 text-purple-400' :
                            order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {getStatusIcon(order.status)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-white font-semibold">{order.order_number}</h4>
                            </div>
                            <p className="text-slate-400 text-sm">{getTimeAgo(order.created_at)}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-orange-500 font-bold">{formatPrice(order.total)}</p>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            order.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                            order.status === 'confirmed' ? 'bg-blue-500/20 text-blue-400' :
                            order.status === 'shipped' ? 'bg-purple-500/20 text-purple-400' :
                            order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {getStatusLabel(order.status)}
                          </span>
                        </div>
                      </div>

                      {/* Visual Timeline */}
                      <div className="mb-4">
                        <OrderTimeline order={order} compact />
                      </div>

                      {/* Estimated Delivery */}
                      {order.status === 'shipped' && estimatedDelivery && (
                        <div className="mb-4 p-3 bg-purple-500/10 rounded-xl border border-purple-500/30">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-purple-400" />
                            <span className="text-purple-300 text-sm">Livraison estimée:</span>
                            <span className="text-white font-medium text-sm">{estimatedDelivery}</span>
                          </div>
                        </div>
                      )}

                      {/* Products */}
                      <div className="flex gap-3 overflow-x-auto pb-2 mb-4">
                        {order.order_items?.map(item => (
                          <div key={item.id} className="flex-shrink-0 flex items-center gap-3 p-2 bg-slate-900/50 rounded-xl">
                            {item.product_image ? (
                              <img src={item.product_image} alt={item.product_name} className="w-14 h-14 rounded-lg object-cover" />
                            ) : (
                              <div className="w-14 h-14 rounded-lg bg-slate-700 flex items-center justify-center">
                                <Package className="w-6 h-6 text-slate-500" />
                              </div>
                            )}
                            <div>
                              <p className="text-white text-sm font-medium line-clamp-1 max-w-[150px]">{item.product_name}</p>
                              <p className="text-slate-400 text-xs">Qté: {item.quantity}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Seller Info */}
                      <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">
                            {seller.avatar}
                          </div>
                          <div>
                            <p className="text-white font-medium text-sm">{seller.name}</p>
                            <p className="text-slate-400 text-xs flex items-center gap-1">
                              <Store className="w-3 h-3" />
                              Vendeur
                            </p>
                          </div>
                        </div>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedOrder(order);
                            setShowMessageModal(true);
                          }}
                          className="px-4 py-2 bg-slate-700 text-white text-sm font-medium rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2"
                        >
                          <MessageSquare className="w-4 h-4" />
                          Contacter
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Order Detail Sidebar */}
          <div className="hidden lg:block">
            {selectedOrder ? (
              <div className="bg-slate-800/50 rounded-2xl border border-slate-700 sticky top-24">
                <div className="p-4 border-b border-slate-700">
                  <div className="flex items-center justify-between">
                    <h3 className="text-white font-semibold">Détails de la commande</h3>
                    <button 
                      onClick={() => setSelectedOrder(null)}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                
                <div className="p-4 space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto">
                  {/* Order Info */}
                  <div className="p-3 bg-slate-900/50 rounded-xl">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-slate-400 text-sm">Numéro</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-mono">{selectedOrder.order_number}</span>
                        <button 
                          onClick={() => copyToClipboard(selectedOrder.order_number)}
                          className="p-1 hover:bg-slate-700 rounded"
                        >
                          <Copy className="w-3 h-3 text-slate-500" />
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-slate-400 text-sm">Date</span>
                      <span className="text-white text-sm">
                        {new Date(selectedOrder.created_at).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-sm">Paiement</span>
                      <span className="text-orange-400 text-sm font-medium">À la livraison</span>
                    </div>
                  </div>

                  {/* Visual Timeline */}
                  <div>
                    <h4 className="text-white font-medium mb-3">Suivi de commande</h4>
                    <OrderTimeline order={selectedOrder} />
                  </div>

                  {/* Shipping Info */}
                  {selectedOrder.shipping_info && selectedOrder.shipping_info[0] && (
                    <div className="p-3 bg-purple-500/10 rounded-xl border border-purple-500/30">
                      <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                        <Truck className="w-4 h-4 text-purple-400" />
                        Informations de livraison
                      </h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 text-sm">Transporteur</span>
                          <span className="text-white text-sm">{selectedOrder.shipping_info[0].carrier}</span>
                        </div>
                        {selectedOrder.shipping_info[0].tracking_number && (
                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 text-sm">N° de suivi</span>
                            <div className="flex items-center gap-2">
                              <span className="text-white font-mono text-sm">{selectedOrder.shipping_info[0].tracking_number}</span>
                              <button 
                                onClick={() => copyToClipboard(selectedOrder.shipping_info![0].tracking_number!)}
                                className="p-1 hover:bg-slate-700 rounded"
                              >
                                <Copy className="w-3 h-3 text-slate-500" />
                              </button>
                            </div>
                          </div>
                        )}
                        {selectedOrder.shipping_info[0].estimated_delivery && (
                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 text-sm">Livraison estimée</span>
                            <span className="text-purple-300 font-medium text-sm">
                              {new Date(selectedOrder.shipping_info[0].estimated_delivery).toLocaleDateString('fr-FR', {
                                weekday: 'short',
                                day: 'numeric',
                                month: 'short'
                              })}
                            </span>
                          </div>
                        )}
                        {selectedOrder.shipping_info[0].tracking_url && (
                          <a
                            href={selectedOrder.shipping_info[0].tracking_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-2 w-full py-2 bg-purple-500/20 text-purple-300 font-medium rounded-lg hover:bg-purple-500/30 transition-colors flex items-center justify-center gap-2"
                          >
                            <ExternalLink className="w-4 h-4" />
                            Suivre le colis
                          </a>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Seller */}
                  <div>
                    <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                      <Store className="w-4 h-4 text-slate-400" />
                      Vendeur
                    </h4>
                    <div className="p-3 bg-slate-900/50 rounded-xl">
                      {(() => {
                        const seller = getSeller(selectedOrder.seller_id);
                        return (
                          <>
                            <div className="flex items-center gap-3 mb-3">
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold">
                                {seller.avatar}
                              </div>
                              <div>
                                <p className="text-white font-medium">{seller.name}</p>
                                <p className="text-slate-400 text-xs">{seller.phone}</p>
                              </div>
                            </div>
                            <button
                              onClick={() => setShowMessageModal(true)}
                              className="w-full py-2 bg-slate-700 text-white font-medium rounded-lg hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
                            >
                              <MessageSquare className="w-4 h-4" />
                              Contacter le vendeur
                            </button>
                          </>
                        );
                      })()}
                    </div>
                  </div>

                  {/* Delivery Address */}
                  <div>
                    <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-slate-400" />
                      Adresse de livraison
                    </h4>
                    <div className="p-3 bg-slate-900/50 rounded-xl">
                      <p className="text-white font-medium mb-1">{selectedOrder.delivery_addresses?.name}</p>
                      <p className="text-slate-300 text-sm mb-1">{selectedOrder.delivery_addresses?.phone}</p>
                      <p className="text-slate-400 text-sm">{selectedOrder.delivery_addresses?.location}</p>
                    </div>
                  </div>

                  {/* Products */}
                  <div>
                    <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                      <Package className="w-4 h-4 text-slate-400" />
                      Articles ({selectedOrder.order_items?.length})
                    </h4>
                    <div className="space-y-2">
                      {selectedOrder.order_items?.map(item => (
                        <div key={item.id} className="flex items-center gap-3 p-2 bg-slate-900/50 rounded-xl">
                          {item.product_image ? (
                            <img src={item.product_image} alt={item.product_name} className="w-16 h-16 rounded-lg object-cover" />
                          ) : (
                            <div className="w-16 h-16 rounded-lg bg-slate-700 flex items-center justify-center">
                              <Package className="w-6 h-6 text-slate-500" />
                            </div>
                          )}
                          <div className="flex-1">
                            <p className="text-white text-sm font-medium">{item.product_name}</p>
                            <p className="text-slate-400 text-xs">{formatPrice(item.unit_price)} x {item.quantity}</p>
                          </div>
                          <p className="text-orange-500 font-semibold text-sm">{formatPrice(item.total_price)}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Total */}
                  <div className="p-3 bg-orange-500/10 rounded-xl border border-orange-500/30">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-400 text-sm">Sous-total</span>
                      <span className="text-white">{formatPrice(selectedOrder.subtotal)}</span>
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-slate-400 text-sm">Livraison</span>
                      <span className="text-white">{selectedOrder.shipping_fee === 0 ? 'Gratuit' : formatPrice(selectedOrder.shipping_fee)}</span>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-orange-500/30">
                      <span className="text-white font-semibold">Total à payer</span>
                      <span className="text-orange-500 font-bold text-lg">{formatPrice(selectedOrder.total)}</span>
                    </div>
                  </div>

                  {/* Order History */}
                  <div>
                    <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-slate-400" />
                      Historique
                    </h4>
                    <div className="space-y-3">
                      {selectedOrder.order_status_history?.slice().reverse().map((history, index) => (
                        <div key={history.id} className="flex gap-3">
                          <div className="flex flex-col items-center">
                            <div className={`w-3 h-3 rounded-full ${
                              index === 0 ? 'bg-orange-500' : 'bg-slate-600'
                            }`}></div>
                            {index < (selectedOrder.order_status_history?.length || 0) - 1 && (
                              <div className="w-0.5 h-full bg-slate-700 my-1"></div>
                            )}
                          </div>
                          <div className="flex-1 pb-3">
                            <p className="text-white text-sm font-medium">{history.notes}</p>
                            <p className="text-slate-500 text-xs">
                              {new Date(history.created_at).toLocaleDateString('fr-FR', {
                                day: 'numeric',
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-8 text-center sticky top-24">
                <Eye className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                <h3 className="text-white font-semibold mb-2">Sélectionnez une commande</h3>
                <p className="text-slate-400 text-sm">Cliquez sur une commande pour voir ses détails et suivre sa livraison</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Message Modal */}
      {showMessageModal && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {(() => {
                    const seller = getSeller(selectedOrder.seller_id);
                    return (
                      <>
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold">
                          {seller.avatar}
                        </div>
                        <div>
                          <h3 className="text-white font-semibold">{seller.name}</h3>
                          <p className="text-slate-400 text-sm">Commande {selectedOrder.order_number}</p>
                        </div>
                      </>
                    );
                  })()}
                </div>
                <button onClick={() => setShowMessageModal(false)} className="text-slate-400 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6">
              {/* Quick Messages */}
              <div className="mb-4">
                <p className="text-slate-400 text-sm mb-2">Messages rapides</p>
                <div className="flex flex-wrap gap-2">
                  {[
                    'Quand sera expédiée ma commande?',
                    'Pouvez-vous me donner le numéro de suivi?',
                    'Y a-t-il un problème avec ma commande?',
                    'Merci pour la livraison rapide!'
                  ].map((msg, i) => (
                    <button
                      key={i}
                      onClick={() => setMessageText(msg)}
                      className="px-3 py-1.5 bg-slate-700 text-slate-300 text-sm rounded-lg hover:bg-slate-600 transition-colors"
                    >
                      {msg}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-white font-medium mb-2">Votre message</label>
                <textarea
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="Écrivez votre message au vendeur..."
                  rows={4}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 resize-none"
                />
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowMessageModal(false)}
                className="px-6 py-3 bg-slate-700 text-white font-semibold rounded-xl hover:bg-slate-600 transition-all"
              >
                Annuler
              </button>
              <button
                onClick={handleSendMessage}
                disabled={!messageText.trim()}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg transition-all disabled:opacity-50 flex items-center gap-2"
              >
                <Send className="w-5 h-5" />
                Envoyer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Help Modal */}
      {showHelpModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <h3 className="text-white text-xl font-bold">Aide - Suivi de commande</h3>
                <button onClick={() => setShowHelpModal(false)} className="text-slate-400 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div className="p-4 bg-slate-900/50 rounded-xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                    <Clock className="w-4 h-4 text-yellow-400" />
                  </div>
                  <h4 className="text-white font-medium">En attente</h4>
                </div>
                <p className="text-slate-400 text-sm">Votre commande a été reçue et attend la confirmation du vendeur.</p>
              </div>

              <div className="p-4 bg-slate-900/50 rounded-xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <CheckCircle className="w-4 h-4 text-blue-400" />
                  </div>
                  <h4 className="text-white font-medium">Confirmée</h4>
                </div>
                <p className="text-slate-400 text-sm">Le vendeur a confirmé votre commande et prépare votre colis.</p>
              </div>

              <div className="p-4 bg-slate-900/50 rounded-xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                    <Truck className="w-4 h-4 text-purple-400" />
                  </div>
                  <h4 className="text-white font-medium">En transit</h4>
                </div>
                <p className="text-slate-400 text-sm">Votre colis est en route vers votre adresse de livraison.</p>
              </div>

              <div className="p-4 bg-slate-900/50 rounded-xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center">
                    <Home className="w-4 h-4 text-green-400" />
                  </div>
                  <h4 className="text-white font-medium">Livrée</h4>
                </div>
                <p className="text-slate-400 text-sm">Votre commande a été livrée avec succès. Paiement effectué à la livraison.</p>
              </div>

              <div className="p-4 bg-orange-500/10 rounded-xl border border-orange-500/30">
                <p className="text-orange-300 text-sm">
                  <strong>Note:</strong> Le paiement se fait à la livraison directement au livreur ou au vendeur. Préparez le montant exact si possible.
                </p>
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-700">
              <button
                onClick={() => setShowHelpModal(false)}
                className="w-full py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-lg transition-all"
              >
                J'ai compris
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Order Detail Modal */}
      {showOrderDetail && selectedOrder && (
        <div className="lg:hidden fixed inset-0 z-50 bg-slate-900">
          <div className="h-full flex flex-col">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h3 className="text-white font-semibold">Détails de la commande</h3>
              <button 
                onClick={() => setShowOrderDetail(false)}
                className="p-2 text-slate-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {/* Order Info */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Numéro</span>
                  <span className="text-white font-mono">{selectedOrder.order_number}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Date</span>
                  <span className="text-white text-sm">
                    {new Date(selectedOrder.created_at).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric'
                    })}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Statut</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    selectedOrder.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                    selectedOrder.status === 'confirmed' ? 'bg-blue-500/20 text-blue-400' :
                    selectedOrder.status === 'shipped' ? 'bg-purple-500/20 text-purple-400' :
                    selectedOrder.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {getStatusLabel(selectedOrder.status)}
                  </span>
                </div>
              </div>

              {/* Visual Timeline */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-3">Suivi de commande</h4>
                <OrderTimeline order={selectedOrder} />
              </div>

              {/* Estimated Delivery */}
              {selectedOrder.status === 'shipped' && selectedOrder.shipping_info?.[0]?.estimated_delivery && (
                <div className="p-4 bg-purple-500/10 rounded-xl border border-purple-500/30">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-purple-300 text-sm">Livraison estimée</p>
                      <p className="text-white font-bold">
                        {new Date(selectedOrder.shipping_info[0].estimated_delivery).toLocaleDateString('fr-FR', {
                          weekday: 'long',
                          day: 'numeric',
                          month: 'long'
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Shipping Info */}
              {selectedOrder.shipping_info && selectedOrder.shipping_info[0] && (
                <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                  <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                    <Truck className="w-4 h-4 text-slate-400" />
                    Informations de livraison
                  </h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-sm">Transporteur</span>
                      <span className="text-white text-sm">{selectedOrder.shipping_info[0].carrier}</span>
                    </div>
                    {selectedOrder.shipping_info[0].tracking_number && (
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-sm">N° de suivi</span>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-mono text-sm">{selectedOrder.shipping_info[0].tracking_number}</span>
                          <button 
                            onClick={() => copyToClipboard(selectedOrder.shipping_info![0].tracking_number!)}
                            className="p-1 hover:bg-slate-700 rounded"
                          >
                            <Copy className="w-3 h-3 text-slate-500" />
                          </button>
                        </div>
                      </div>
                    )}
                    {selectedOrder.shipping_info[0].tracking_url && (
                      <a
                        href={selectedOrder.shipping_info[0].tracking_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-2 w-full py-2 bg-purple-500/20 text-purple-300 font-medium rounded-lg hover:bg-purple-500/30 transition-colors flex items-center justify-center gap-2"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Suivre le colis
                      </a>
                    )}
                  </div>
                </div>
              )}

              {/* Seller */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Store className="w-4 h-4 text-slate-400" />
                  Vendeur
                </h4>
                {(() => {
                  const seller = getSeller(selectedOrder.seller_id);
                  return (
                    <>
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold">
                          {seller.avatar}
                        </div>
                        <div>
                          <p className="text-white font-medium">{seller.name}</p>
                          <p className="text-slate-400 text-xs">{seller.phone}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setShowMessageModal(true)}
                        className="w-full py-2 bg-slate-700 text-white font-medium rounded-lg hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
                      >
                        <MessageSquare className="w-4 h-4" />
                        Contacter le vendeur
                      </button>
                    </>
                  );
                })()}
              </div>

              {/* Delivery Address */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  Adresse de livraison
                </h4>
                <p className="text-white font-medium mb-1">{selectedOrder.delivery_addresses?.name}</p>
                <p className="text-slate-300 text-sm mb-1">{selectedOrder.delivery_addresses?.phone}</p>
                <p className="text-slate-400 text-sm">{selectedOrder.delivery_addresses?.location}</p>
              </div>

              {/* Products */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Package className="w-4 h-4 text-slate-400" />
                  Articles ({selectedOrder.order_items?.length})
                </h4>
                <div className="space-y-3">
                  {selectedOrder.order_items?.map(item => (
                    <div key={item.id} className="flex items-center gap-3 p-2 bg-slate-900/50 rounded-xl">
                      {item.product_image ? (
                        <img src={item.product_image} alt={item.product_name} className="w-16 h-16 rounded-lg object-cover" />
                      ) : (
                        <div className="w-16 h-16 rounded-lg bg-slate-700 flex items-center justify-center">
                          <Package className="w-6 h-6 text-slate-500" />
                        </div>
                      )}
                      <div className="flex-1">
                        <p className="text-white text-sm font-medium">{item.product_name}</p>
                        <p className="text-slate-400 text-xs">{formatPrice(item.unit_price)} x {item.quantity}</p>
                      </div>
                      <p className="text-orange-500 font-semibold text-sm">{formatPrice(item.total_price)}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total */}
              <div className="p-4 bg-orange-500/10 rounded-xl border border-orange-500/30">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-400 text-sm">Sous-total</span>
                  <span className="text-white">{formatPrice(selectedOrder.subtotal)}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Livraison</span>
                  <span className="text-white">{selectedOrder.shipping_fee === 0 ? 'Gratuit' : formatPrice(selectedOrder.shipping_fee)}</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-orange-500/30">
                  <span className="text-white font-semibold">Total à payer</span>
                  <span className="text-orange-500 font-bold text-xl">{formatPrice(selectedOrder.total)}</span>
                </div>
                <p className="text-orange-300 text-xs mt-2 text-center">
                  Paiement à la livraison
                </p>
              </div>

              {/* Order History */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-400" />
                  Historique
                </h4>
                <div className="space-y-3">
                  {selectedOrder.order_status_history?.slice().reverse().map((history, index) => (
                    <div key={history.id} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <div className={`w-3 h-3 rounded-full ${
                          index === 0 ? 'bg-orange-500' : 'bg-slate-600'
                        }`}></div>
                        {index < (selectedOrder.order_status_history?.length || 0) - 1 && (
                          <div className="w-0.5 h-full bg-slate-700 my-1"></div>
                        )}
                      </div>
                      <div className="flex-1 pb-3">
                        <p className="text-white text-sm font-medium">{history.notes}</p>
                        <p className="text-slate-500 text-xs">
                          {new Date(history.created_at).toLocaleDateString('fr-FR', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}



      {/* Order Notification Settings Modal */}
      <OrderNotificationSettings 
        isOpen={showNotificationSettings} 
        onClose={() => setShowNotificationSettings(false)} 
      />
    </div>
  );
};

export default BuyerOrders;
