import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import { Product } from '@/data/mockData';

// Demo mode flag
const isDemoMode = !isSupabaseConfigured;

export interface WishlistItem {
  id: string;
  user_id: string;
  product_id: string;
  product_name: string;
  product_price: number;
  product_original_price?: number;
  product_image: string;
  product_seller: string;
  product_rating: number;
  product_reviews: number;
  product_category?: string;
  is_available: boolean;
  created_at: string;
  updated_at: string;
}

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  isDemoMode: boolean;
  // Wishlist
  wishlist: WishlistItem[];
  wishlistLoading: boolean;
  addToWishlist: (product: Product) => Promise<boolean>;
  removeFromWishlist: (productId: string) => Promise<boolean>;
  isInWishlist: (productId: string) => boolean;
  fetchWishlist: () => Promise<void>;
}

const defaultAppContext: AppContextType = {
  sidebarOpen: false,
  toggleSidebar: () => {},
  isDemoMode: true,
  wishlist: [],
  wishlistLoading: false,
  addToWishlist: async () => false,
  removeFromWishlist: async () => false,
  isInWishlist: () => false,
  fetchWishlist: async () => {},
};

const AppContext = createContext<AppContextType>(defaultAppContext);

export const useAppContext = () => useContext(AppContext);
export const useApp = useAppContext; // Alias for convenience


export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [wishlistLoading, setWishlistLoading] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(prev => !prev);
  };

  // Fetch wishlist from database
  const fetchWishlist = useCallback(async () => {
    // In demo mode, use local storage for wishlist
    if (isDemoMode) {
      try {
        const stored = localStorage.getItem('demo_wishlist');
        if (stored) {
          setWishlist(JSON.parse(stored));
        }
      } catch (e) {
        console.warn('Error loading demo wishlist:', e);
      }
      return;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        setWishlist([]);
        return;
      }

      setWishlistLoading(true);
      const { data, error } = await supabase
        .from('wishlists')
        .select('*')
        .eq('user_id', session.user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching wishlist:', error);
        return;
      }

      setWishlist(data || []);
    } catch (err) {
      console.error('Error in fetchWishlist:', err);
    } finally {
      setWishlistLoading(false);
    }
  }, []);

  // Listen for auth changes to fetch/clear wishlist
  useEffect(() => {
    fetchWishlist();

    // Don't set up auth listener in demo mode
    if (isDemoMode) {
      return;
    }

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN') {
        fetchWishlist();
      } else if (event === 'SIGNED_OUT') {
        setWishlist([]);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchWishlist]);

  // Add product to wishlist
  const addToWishlist = async (product: Product): Promise<boolean> => {
    // In demo mode, use local storage
    if (isDemoMode) {
      const newItem: WishlistItem = {
        id: `demo_${Date.now()}`,
        user_id: 'demo_user',
        product_id: product.id,
        product_name: product.name,
        product_price: product.price,
        product_original_price: product.originalPrice || undefined,
        product_image: product.image,
        product_seller: product.seller,
        product_rating: product.rating,
        product_reviews: product.reviews,
        product_category: product.category,
        is_available: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Check if already in wishlist
      if (wishlist.some(item => item.product_id === product.id)) {
        toast({
          title: "Déjà dans les favoris",
          description: "Ce produit est déjà dans votre liste de favoris",
        });
        return false;
      }

      const newWishlist = [newItem, ...wishlist];
      setWishlist(newWishlist);
      localStorage.setItem('demo_wishlist', JSON.stringify(newWishlist));
      
      toast({
        title: "Ajouté aux favoris",
        description: `${product.name} a été ajouté à votre liste de favoris`,
      });
      return true;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        toast({
          title: "Connexion requise",
          description: "Veuillez vous connecter pour ajouter aux favoris",
          variant: "destructive",
        });
        return false;
      }

      const { data, error } = await supabase
        .from('wishlists')
        .insert({
          user_id: session.user.id,
          product_id: product.id,
          product_name: product.name,
          product_price: product.price,
          product_original_price: product.originalPrice || null,
          product_image: product.image,
          product_seller: product.seller,
          product_rating: product.rating,
          product_reviews: product.reviews,
          product_category: product.category,
          is_available: true,
        })
        .select()
        .single();

      if (error) {
        if (error.code === '23505') {
          toast({
            title: "Déjà dans les favoris",
            description: "Ce produit est déjà dans votre liste de favoris",
          });
          return false;
        }
        throw error;
      }

      setWishlist(prev => [data, ...prev]);
      toast({
        title: "Ajouté aux favoris",
        description: `${product.name} a été ajouté à votre liste de favoris`,
      });
      return true;
    } catch (err) {
      console.error('Error adding to wishlist:', err);
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter aux favoris",
        variant: "destructive",
      });
      return false;
    }
  };

  // Remove product from wishlist
  const removeFromWishlist = async (productId: string): Promise<boolean> => {
    // In demo mode, use local storage
    if (isDemoMode) {
      const newWishlist = wishlist.filter(item => item.product_id !== productId);
      setWishlist(newWishlist);
      localStorage.setItem('demo_wishlist', JSON.stringify(newWishlist));
      
      toast({
        title: "Retiré des favoris",
        description: "Le produit a été retiré de votre liste de favoris",
      });
      return true;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        return false;
      }

      const { error } = await supabase
        .from('wishlists')
        .delete()
        .eq('user_id', session.user.id)
        .eq('product_id', productId);

      if (error) {
        throw error;
      }

      setWishlist(prev => prev.filter(item => item.product_id !== productId));
      toast({
        title: "Retiré des favoris",
        description: "Le produit a été retiré de votre liste de favoris",
      });
      return true;
    } catch (err) {
      console.error('Error removing from wishlist:', err);
      toast({
        title: "Erreur",
        description: "Impossible de retirer des favoris",
        variant: "destructive",
      });
      return false;
    }
  };

  // Check if product is in wishlist
  const isInWishlist = (productId: string): boolean => {
    return wishlist.some(item => item.product_id === productId);
  };

  return (
    <AppContext.Provider
      value={{
        sidebarOpen,
        toggleSidebar,
        isDemoMode,
        wishlist,
        wishlistLoading,
        addToWishlist,
        removeFromWishlist,
        isInWishlist,
        fetchWishlist,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
