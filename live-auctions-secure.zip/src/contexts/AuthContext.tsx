import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

// Demo mode flag
const isDemoMode = !isSupabaseConfigured;

interface UserProfile {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  phone?: string;
  user_type: 'buyer' | 'seller' | 'admin';
  store_name?: string;
  avatar_url?: string;
  is_verified: boolean;
  created_at: string;
  updated_at: string;
}

interface AuthUser {
  id: string;
  email: string;
}

interface AuthContextType {
  user: AuthUser | null;
  profile: UserProfile | null;
  loading: boolean;
  isDemoMode: boolean;
  signUp: (email: string, password: string, userData: SignUpData) => Promise<{ success: boolean; error?: string }>;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
  updateProfile: (data: Partial<UserProfile>) => Promise<{ success: boolean; error?: string }>;
  refreshProfile: () => Promise<void>;
}

interface SignUpData {
  full_name: string;
  phone?: string;
  user_type: 'buyer' | 'seller';
  store_name?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Helper function to translate error messages
const translateError = (error: any): string => {
  const message = error?.message || error?.toString() || 'Erreur inconnue';
  
  // Network errors
  if (message.includes('Load failed') || message.includes('Failed to fetch') || message.includes('NetworkError')) {
    return 'Erreur de connexion au serveur. Vérifiez votre connexion internet et réessayez.';
  }
  
  // Auth errors
  if (message.includes('Invalid login credentials')) {
    return 'Email ou mot de passe incorrect';
  }
  if (message.includes('Email not confirmed')) {
    return 'Veuillez confirmer votre email avant de vous connecter';
  }
  if (message.includes('User already registered')) {
    return 'Un compte existe déjà avec cet email';
  }
  if (message.includes('Password should be at least')) {
    return 'Le mot de passe doit contenir au moins 6 caractères';
  }
  if (message.includes('Invalid email')) {
    return 'Adresse email invalide';
  }
  if (message.includes('Signup is disabled')) {
    return 'Les inscriptions sont temporairement désactivées';
  }
  if (message.includes('rate limit') || message.includes('too many requests')) {
    return 'Trop de tentatives. Veuillez patienter quelques minutes.';
  }
  
  // Database errors
  if (message.includes('duplicate key') || message.includes('unique constraint')) {
    return 'Un compte existe déjà avec ces informations';
  }
  if (message.includes('violates row-level security')) {
    return 'Erreur de permission. Veuillez réessayer.';
  }
  
  return message;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Fetch user profile from database
  const fetchProfile = useCallback(async (userId: string, userEmail: string) => {
    if (isDemoMode) {
      return null;
    }
    
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error);
        return null;
      }

      if (data) {
        setProfile(data as UserProfile);
        return data;
      }
      return null;
    } catch (err) {
      console.error('Error in fetchProfile:', err);
      return null;
    }
  }, []);

  // Initialize auth state on mount
  useEffect(() => {
    const initializeAuth = async () => {
      // In demo mode, just set loading to false
      if (isDemoMode) {
        setLoading(false);
        return;
      }

      try {
        // Check for existing session
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.user) {
          setUser({
            id: session.user.id,
            email: session.user.email || ''
          });
          await fetchProfile(session.user.id, session.user.email || '');
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();

    // Don't set up auth listener in demo mode
    if (isDemoMode) {
      return;
    }

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email || ''
        });
        await fetchProfile(session.user.id, session.user.email || '');
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setProfile(null);
      } else if (event === 'TOKEN_REFRESHED' && session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email || ''
        });
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchProfile]);

  // Sign up new user
  const signUp = async (email: string, password: string, userData: SignUpData): Promise<{ success: boolean; error?: string }> => {
    if (isDemoMode) {
      toast({
        title: "Mode Démo",
        description: "L'inscription n'est pas disponible en mode démo. Configurez Supabase pour activer cette fonctionnalité.",
        variant: "destructive"
      });
      return { success: false, error: "Mode démo: L'inscription n'est pas disponible" };
    }

    try {
      setLoading(true);

      // Create auth user with timeout
      const signUpPromise = supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: userData.full_name,
            user_type: userData.user_type
          }
        }
      });

      // Add timeout to detect network issues
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('La connexion a pris trop de temps. Vérifiez votre connexion internet.')), 30000);
      });

      const { data: authData, error: authError } = await Promise.race([signUpPromise, timeoutPromise]) as any;

      if (authError) {
        const translatedError = translateError(authError);
        return { success: false, error: translatedError };
      }

      if (!authData.user) {
        return { success: false, error: 'Erreur lors de la création du compte' };
      }

      // Create user profile in database
      try {
        const { error: profileError } = await supabase
          .from('user_profiles')
          .insert({
            user_id: authData.user.id,
            email: email,
            full_name: userData.full_name,
            phone: userData.phone || null,
            user_type: userData.user_type,
            store_name: userData.store_name || null,
            is_verified: false
          });

        if (profileError) {
          console.error('Profile creation error:', profileError);
          // Don't fail signup if profile creation fails - we can retry later
        }
      } catch (profileErr) {
        console.error('Profile creation exception:', profileErr);
        // Continue anyway - profile can be created later
      }

      // If email confirmation is required
      if (!authData.session) {
        return { 
          success: true, 
          error: 'Vérifiez votre email pour confirmer votre compte' 
        };
      }

      setUser({
        id: authData.user.id,
        email: authData.user.email || ''
      });

      await fetchProfile(authData.user.id, authData.user.email || '');

      toast({
        title: "Inscription réussie!",
        description: "Bienvenue sur PITCH",
      });

      return { success: true };
    } catch (error: any) {
      console.error('Sign up error:', error);
      const translatedError = translateError(error);
      return { success: false, error: translatedError };
    } finally {
      setLoading(false);
    }
  };

  // Sign in existing user
  const signIn = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    if (isDemoMode) {
      toast({
        title: "Mode Démo",
        description: "La connexion n'est pas disponible en mode démo. Configurez Supabase pour activer cette fonctionnalité.",
        variant: "destructive"
      });
      return { success: false, error: "Mode démo: La connexion n'est pas disponible" };
    }

    try {
      setLoading(true);

      // Add timeout to detect network issues
      const signInPromise = supabase.auth.signInWithPassword({
        email,
        password
      });

      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('La connexion a pris trop de temps. Vérifiez votre connexion internet.')), 30000);
      });

      const { data, error } = await Promise.race([signInPromise, timeoutPromise]) as any;

      if (error) {
        const translatedError = translateError(error);
        return { success: false, error: translatedError };
      }

      if (!data.user) {
        return { success: false, error: 'Erreur de connexion' };
      }

      setUser({
        id: data.user.id,
        email: data.user.email || ''
      });

      await fetchProfile(data.user.id, data.user.email || '');

      toast({
        title: "Connexion réussie!",
        description: "Content de vous revoir",
      });

      return { success: true };
    } catch (error: any) {
      console.error('Sign in error:', error);
      const translatedError = translateError(error);
      return { success: false, error: translatedError };
    } finally {
      setLoading(false);
    }
  };

  // Sign out user
  const signOut = async () => {
    try {
      setLoading(true);
      
      if (!isDemoMode) {
        await supabase.auth.signOut();
      }
      
      setUser(null);
      setProfile(null);
      
      toast({
        title: "Déconnexion",
        description: "À bientôt sur PITCH!",
      });

    } catch (error) {
      console.error('Sign out error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Reset password
  const resetPassword = async (email: string): Promise<{ success: boolean; error?: string }> => {
    if (isDemoMode) {
      toast({
        title: "Mode Démo",
        description: "La réinitialisation du mot de passe n'est pas disponible en mode démo.",
        variant: "destructive"
      });
      return { success: false, error: "Mode démo: Fonctionnalité non disponible" };
    }

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`
      });

      if (error) {
        const translatedError = translateError(error);
        return { success: false, error: translatedError };
      }

      return { success: true };
    } catch (error: any) {
      console.error('Reset password error:', error);
      const translatedError = translateError(error);
      return { success: false, error: translatedError };
    }
  };

  // Update user profile
  const updateProfile = async (data: Partial<UserProfile>): Promise<{ success: boolean; error?: string }> => {
    if (isDemoMode) {
      return { success: false, error: "Mode démo: Mise à jour non disponible" };
    }

    if (!user) {
      return { success: false, error: 'Non connecté' };
    }

    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({
          ...data,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id);

      if (error) {
        const translatedError = translateError(error);
        return { success: false, error: translatedError };
      }

      await fetchProfile(user.id, user.email);

      toast({
        title: "Profil mis à jour",
        description: "Vos modifications ont été enregistrées",
      });

      return { success: true };
    } catch (error: any) {
      console.error('Update profile error:', error);
      const translatedError = translateError(error);
      return { success: false, error: translatedError };
    }
  };

  // Refresh profile data
  const refreshProfile = async () => {
    if (user && !isDemoMode) {
      await fetchProfile(user.id, user.email);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        isDemoMode,
        signUp,
        signIn,
        signOut,
        resetPassword,
        updateProfile,
        refreshProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
