import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Supabase configuration - these values are injected by the deployment system
// The deployment system will replace these placeholder values with actual credentials
const SUPABASE_URL = 'https://jzvpudxogjrfqxjkcqtp.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp6dnB1ZHhvZ2pyZnF4amtjcXRwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzc3NjE5NjcsImV4cCI6MjA1MzMzNzk2N30.QSjsEqu1bELWNeGruEBVdmfvMex2GvzPpLNSqXYLxN8';

// Validate configuration
const isValidUrl = (url: string): boolean => {
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
};

const isValidKey = (key: string): boolean => {
  return Boolean(key && key.length > 20 && !key.includes('your-') && !key.includes('__'));
};

// Check if properly configured
const isConfigured = isValidUrl(SUPABASE_URL) && isValidKey(SUPABASE_ANON_KEY);

// Create a mock client for demo mode when Supabase is not configured
const createMockClient = (): SupabaseClient => {
  const mockResponse = {
    data: null,
    error: null
  };

  const mockDataResponse = {
    data: [],
    error: null
  };

  const createMockQueryBuilder = () => {
    const builder: any = {
      select: () => builder,
      insert: () => builder,
      update: () => builder,
      delete: () => builder,
      upsert: () => builder,
      eq: () => builder,
      neq: () => builder,
      gt: () => builder,
      gte: () => builder,
      lt: () => builder,
      lte: () => builder,
      like: () => builder,
      ilike: () => builder,
      is: () => builder,
      in: () => builder,
      contains: () => builder,
      containedBy: () => builder,
      range: () => builder,
      textSearch: () => builder,
      match: () => builder,
      not: () => builder,
      or: () => builder,
      filter: () => builder,
      order: () => builder,
      limit: () => builder,
      offset: () => builder,
      single: () => Promise.resolve(mockResponse),
      maybeSingle: () => Promise.resolve(mockResponse),
      then: (resolve: (value: typeof mockDataResponse) => void) => Promise.resolve(mockDataResponse).then(resolve),
      catch: (reject: (error: any) => void) => Promise.resolve(mockDataResponse).catch(reject),
    };
    return builder;
  };

  const mockAuth = {
    getSession: () => Promise.resolve({ data: { session: null }, error: null }),
    getUser: () => Promise.resolve({ data: { user: null }, error: null }),
    signInWithPassword: () => Promise.resolve({ 
      data: { user: null, session: null }, 
      error: { message: 'Demo mode: Please configure Supabase to enable authentication', code: 'demo_mode' } 
    }),
    signUp: () => Promise.resolve({ 
      data: { user: null, session: null }, 
      error: { message: 'Demo mode: Please configure Supabase to enable authentication', code: 'demo_mode' } 
    }),
    signOut: () => Promise.resolve({ error: null }),
    resetPasswordForEmail: () => Promise.resolve({ data: null, error: null }),
    updateUser: () => Promise.resolve({ data: { user: null }, error: null }),
    onAuthStateChange: (callback: (event: string, session: null) => void) => {
      setTimeout(() => callback('INITIAL_SESSION', null), 0);
      return { 
        data: { 
          subscription: { 
            unsubscribe: () => {} 
          } 
        } 
      };
    },
  };

  const mockStorage = {
    from: () => ({
      upload: () => Promise.resolve({ data: { path: 'demo/file.jpg' }, error: null }),
      download: () => Promise.resolve({ data: new Blob(), error: null }),
      getPublicUrl: (path: string) => ({ data: { publicUrl: `https://placehold.co/400x400?text=${encodeURIComponent(path)}` } }),
      remove: () => Promise.resolve({ data: null, error: null }),
      list: () => Promise.resolve({ data: [], error: null }),
      createSignedUrl: () => Promise.resolve({ data: { signedUrl: '' }, error: null }),
    }),
  };

  const mockFunctions = {
    invoke: (name: string, options?: { body?: any }) => {
      // Return demo data based on function name
      const demoResponses: Record<string, any> = {
        'manage-orders': { orders: [], success: true },
        'manage-messaging': { conversations: [], messages: [], success: true },
        'manage-live-stream': { streams: [], success: true },
        'manage-scheduled-streams': { streams: [], success: true },
        'manage-products': { products: [], success: true },
        'manage-reviews': { reviews: [], success: true },
        'manage-notifications': { notifications: [], success: true },
        'agora-token': { token: 'demo-token', success: true },
      };
      return Promise.resolve({ 
        data: demoResponses[name] || { success: true }, 
        error: null 
      });
    },
  };

  const createMockChannel = () => {
    const channel: any = {
      on: () => channel,
      subscribe: (callback?: (status: string) => void) => {
        if (callback) setTimeout(() => callback('SUBSCRIBED'), 0);
        return channel;
      },
      unsubscribe: () => Promise.resolve('ok'),
      send: () => Promise.resolve('ok'),
    };
    return channel;
  };

  return {
    from: () => createMockQueryBuilder(),
    auth: mockAuth,
    storage: mockStorage,
    functions: mockFunctions,
    channel: () => createMockChannel(),
    removeChannel: () => Promise.resolve('ok'),
    removeAllChannels: () => Promise.resolve([]),
    getChannels: () => [],
    rpc: () => Promise.resolve({ data: null, error: null }),
  } as unknown as SupabaseClient;
};

// Create the Supabase client
let supabase: SupabaseClient;

if (isConfigured) {
  try {
    supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true
      }
    });
  } catch (error) {
    console.warn('Failed to initialize Supabase client:', error);
    supabase = createMockClient();
  }
} else {
  // Running in demo mode
  supabase = createMockClient();
}

// Export configuration status flag
export const isSupabaseConfigured = isConfigured;

export { supabase };
