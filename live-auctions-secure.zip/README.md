# Famous.ai - Live Shopping Platform

A modern live shopping platform built with React, TypeScript, Vite, and Supabase.

## Features

- 🛍️ **Live Shopping** - Real-time live streaming with product showcases
- 🎥 **Video Calls** - Direct video calls between buyers and sellers
- 💬 **Live Chat** - Real-time messaging during streams
- ⭐ **Reviews & Ratings** - Complete product review system with photos
- 🔔 **Notifications** - Push notifications and in-app alerts
- 👤 **User Profiles** - Buyer and seller profiles with verification
- 📦 **Order Management** - Complete order tracking system
- 💳 **Subscriptions** - Premium seller subscription plans

## Tech Stack

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS, shadcn/ui
- **Backend**: Supabase (Database, Auth, Storage, Edge Functions)
- **Live Streaming**: Agora SDK
- **State Management**: React Query, React Context

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn
- Supabase account

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd famous-ai
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env.local
```

4. Edit `.env.local` with your Supabase credentials:
```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

5. Start the development server:
```bash
npm run dev
```

The app will be available at `http://localhost:8080`

## Build for Production

```bash
npm run build
```

Preview the production build:
```bash
npm run preview
```

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Import the project in Vercel
3. Add environment variables in Vercel dashboard:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy!

### Netlify

1. Push your code to GitHub
2. Import the project in Netlify
3. Add environment variables in Netlify dashboard:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy!

### Manual Deployment

1. Build the project: `npm run build`
2. Upload the `dist` folder to your hosting provider
3. Configure your server to serve `index.html` for all routes (SPA)

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `VITE_SUPABASE_URL` | Your Supabase project URL | Yes |
| `VITE_SUPABASE_ANON_KEY` | Your Supabase anonymous key | Yes |

## Supabase Edge Function Secrets

These secrets should be configured in your Supabase dashboard:

| Secret | Description |
|--------|-------------|
| `AGORA_APP_ID` | Agora App ID for live streaming |
| `AGORA_APP_CERTIFICATE` | Agora App Certificate |

## Project Structure

```
src/
├── components/     # Reusable UI components
├── contexts/       # React contexts (Auth, App state)
├── hooks/          # Custom React hooks
├── lib/            # Utilities and Supabase client
├── pages/          # Page components
└── data/           # Mock data for development
```

## Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Security Notes

- Never commit `.env` files with real credentials
- Use `.env.example` as a template
- Set environment variables in your deployment platform's dashboard
- The Supabase anon key is safe to expose (it's designed for client-side use)
- Sensitive operations are protected by Row Level Security (RLS) in Supabase

## License

MIT License - see LICENSE file for details.
