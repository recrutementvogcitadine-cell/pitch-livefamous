# Famous.ai - Plateforme de Live Streaming

Plateforme de live streaming avec chat en temps réel, replays, abonnements créateurs et tableau de bord d'administration.

## Stack Technique

- **Frontend** : React 18 + TypeScript + Vite
- **Styling** : Tailwind CSS + shadcn/ui
- **Backend** : Supabase (Auth, Database, Storage, Realtime, Edge Functions)
- **Déploiement** : Vercel / Netlify / tout hébergeur statique

## Prérequis

- Node.js 18+
- npm ou yarn
- Un projet Supabase configuré

## Configuration de la base de données

> **IMPORTANT** : Avant de lancer l'application, vous devez configurer la base de données Supabase.

### Guide rapide

1. Allez sur [app.supabase.com](https://app.supabase.com) → votre projet → **SQL Editor**
2. Cliquez **"New query"**
3. Copiez-collez **tout** le contenu de `supabase-setup.sql`
4. Cliquez **"Run"** (Ctrl+Enter)
5. Vérifiez : `Success. No rows returned` = tout est bon !

Cela crée automatiquement :
- **13 tables** (creator_profiles, live_streams, payments, etc.)
- **38+ politiques RLS** (sécurité par ligne)
- **3 storage buckets** (avatars, recordings, verification-documents)
- **3 plans d'abonnement** (Starter, Pro, Business en FCFA)
- **Triggers & fonctions** (updated_at automatique, stats créateur)

> 📖 Pour le guide complet avec vérification et résolution de problèmes, voir **[DATABASE-SETUP.md](./DATABASE-SETUP.md)**


## Installation

### 1. Cloner le projet

```bash
git clone <repo-url>
cd famous-ai
```

### 2. Installer les dépendances

```bash
npm install
```

### 3. Configurer les variables d'environnement

Copier le fichier d'exemple et remplir avec vos valeurs :

```bash
cp .env.example .env
```

Éditer `.env` avec vos identifiants Supabase :

```env
VITE_SUPABASE_URL=https://votre-projet.supabase.co
VITE_SUPABASE_ANON_KEY=votre-clé-anon-ici
```

### 4. Lancer en développement

```bash
npm run dev
```

L'application sera accessible sur `http://localhost:5173`

### 5. Build de production

```bash
npm run build
```

Les fichiers de production seront générés dans le dossier `dist/`.

### 6. Prévisualiser le build

```bash
npm run preview
```

## Déploiement

### Vercel

1. Connecter votre repo GitHub à Vercel
2. Configurer les variables d'environnement dans les paramètres du projet :
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
3. Déployer automatiquement à chaque push

### Netlify

1. Connecter votre repo GitHub à Netlify
2. Build command : `npm run build`
3. Publish directory : `dist`
4. Ajouter les variables d'environnement dans Site settings > Environment variables :
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

### Hébergement statique (Apache/Nginx)

1. Exécuter `npm run build`
2. Copier le contenu du dossier `dist/` sur votre serveur
3. Configurer la réécriture d'URL pour le SPA (toutes les routes vers `index.html`)

**Exemple Nginx :**
```nginx
server {
    listen 80;
    server_name votre-domaine.com;
    root /var/www/famous-ai/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

## Structure du Projet

```
src/
├── components/       # Composants React réutilisables
│   ├── ui/           # Composants shadcn/ui
│   └── admin/        # Composants du tableau de bord admin
├── contexts/         # Contextes React (Auth, App state)
├── hooks/            # Hooks personnalisés
├── lib/              # Services et utilitaires
│   ├── supabase.ts   # Client Supabase
│   ├── chatService.ts
│   ├── streamService.ts
│   ├── subscriptionService.ts
│   └── ...
├── pages/            # Pages de l'application
└── data/             # Données statiques
```

## Fonctionnalités

- **Live Streaming** : Diffusion audio/vidéo en direct
- **Chat en temps réel** : Messages instantanés pendant les lives
- **Replays** : Enregistrement et lecture des lives passés
- **Profils créateurs** : Pages de profil personnalisées
- **Abonnements** : Système d'abonnement pour les créateurs
- **Administration** : Tableau de bord de modération et gestion
- **Vérification** : Système de vérification des créateurs
- **Notifications** : Notifications push via Service Worker

## Sécurité

- Les clés API sont stockées dans des variables d'environnement (jamais en dur dans le code)
- Le fichier `.env` est exclu du contrôle de version via `.gitignore`
- Seule la clé `anon` (publique) est utilisée côté client
- Les opérations sensibles sont protégées par les Row Level Security (RLS) de Supabase et les Edge Functions

## Licence

Propriétaire - Tous droits réservés.
