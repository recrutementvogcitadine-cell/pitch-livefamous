-- ==========================================================================
-- FAMOUS.AI — SCRIPT SQL COMPLET SUPABASE (PostgreSQL 15)
-- Idempotent : exécutable plusieurs fois sans erreur
-- v4: Uses gen_random_uuid() instead of uuid_generate_v4() (no extension needed)
-- ==========================================================================

-- 1. EXTENSIONS (pgcrypto provides gen_random_uuid on older PG versions)
CREATE EXTENSION IF NOT EXISTS "pgcrypto";


-- ==========================================================================
-- 2. TABLES
-- ==========================================================================

-- creator_profiles
CREATE TABLE IF NOT EXISTS public.creator_profiles (
  id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                     UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  username                    TEXT NOT NULL UNIQUE,
  display_name                TEXT NOT NULL,
  bio                         TEXT,
  avatar_url                  TEXT,
  whatsapp_number             TEXT,
  is_verified                 BOOLEAN DEFAULT FALSE,
  followers_count             INTEGER DEFAULT 0,
  total_views                 INTEGER DEFAULT 0,
  total_live_duration_seconds INTEGER DEFAULT 0,
  live_count                  INTEGER DEFAULT 0,
  average_viewers             INTEGER DEFAULT 0,
  created_at                  TIMESTAMPTZ DEFAULT NOW(),
  updated_at                  TIMESTAMPTZ DEFAULT NOW()
);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='creator_profiles' AND column_name='total_live_duration_seconds') THEN
    ALTER TABLE public.creator_profiles ADD COLUMN total_live_duration_seconds INTEGER DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='creator_profiles' AND column_name='live_count') THEN
    ALTER TABLE public.creator_profiles ADD COLUMN live_count INTEGER DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='creator_profiles' AND column_name='average_viewers') THEN
    ALTER TABLE public.creator_profiles ADD COLUMN average_viewers INTEGER DEFAULT 0;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_creator_profiles_user_id     ON public.creator_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_creator_profiles_username    ON public.creator_profiles(username);
CREATE INDEX IF NOT EXISTS idx_creator_profiles_is_verified ON public.creator_profiles(is_verified);


-- subscription_plans
CREATE TABLE IF NOT EXISTS public.subscription_plans (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            TEXT NOT NULL,
  description     TEXT,
  price_monthly   NUMERIC(10,2) NOT NULL DEFAULT 0,
  price_yearly    NUMERIC(10,2) NOT NULL DEFAULT 0,
  features        JSONB DEFAULT '[]'::jsonb,
  is_active       BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);


-- creator_subscriptions
CREATE TABLE IF NOT EXISTS public.creator_subscriptions (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id        UUID NOT NULL UNIQUE REFERENCES public.creator_profiles(id) ON DELETE CASCADE,
  plan_id           UUID REFERENCES public.subscription_plans(id) ON DELETE SET NULL,
  billing_cycle     TEXT NOT NULL CHECK (billing_cycle IN ('monthly', 'yearly')),
  status            TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'expired', 'cancelled')),
  started_at        TIMESTAMPTZ,
  expires_at        TIMESTAMPTZ,
  payment_reference TEXT,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_creator_subscriptions_creator_id ON public.creator_subscriptions(creator_id);
CREATE INDEX IF NOT EXISTS idx_creator_subscriptions_status     ON public.creator_subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_creator_subscriptions_plan_id    ON public.creator_subscriptions(plan_id);


-- admin_users (legacy)
CREATE TABLE IF NOT EXISTS public.admin_users (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email       TEXT NOT NULL,
  role        TEXT NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'super_admin')),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_admin_users_user_id ON public.admin_users(user_id);


-- team_members
CREATE TABLE IF NOT EXISTS public.team_members (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email           TEXT NOT NULL,
  display_name    TEXT NOT NULL DEFAULT 'Membre',
  role            TEXT NOT NULL DEFAULT 'read_only' CHECK (role IN ('owner', 'admin', 'moderator', 'read_only')),
  permissions     JSONB NOT NULL DEFAULT '{
    "view_dashboard": true,
    "manage_streams": false,
    "moderate_chat": false,
    "manage_creators": false,
    "manage_subscriptions": false,
    "manage_team": false,
    "view_payments": false,
    "manage_verification": false
  }'::jsonb,
  added_by        UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  is_active       BOOLEAN DEFAULT TRUE,
  last_active_at  TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Migration : ajouter la colonne email si elle n'existe pas (pour les anciennes installations)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'team_members'
      AND column_name = 'email'
  ) THEN
    ALTER TABLE public.team_members ADD COLUMN email TEXT NOT NULL DEFAULT '';
    RAISE NOTICE 'Column email added to team_members';
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_team_members_user_id   ON public.team_members(user_id);


-- support_requests
CREATE TABLE IF NOT EXISTS public.support_requests (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id    UUID NOT NULL REFERENCES public.creator_profiles(id) ON DELETE CASCADE,
  subject       TEXT NOT NULL,
  message       TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
  priority      TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  admin_notes   TEXT,
  resolved_by   UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  resolved_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_support_requests_creator_id ON public.support_requests(creator_id);
CREATE INDEX IF NOT EXISTS idx_support_requests_status     ON public.support_requests(status);
CREATE INDEX IF NOT EXISTS idx_support_requests_priority   ON public.support_requests(priority);


-- live_streams
CREATE TABLE IF NOT EXISTS public.live_streams (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id           UUID NOT NULL REFERENCES public.creator_profiles(id) ON DELETE CASCADE,
  title                TEXT NOT NULL DEFAULT 'Live sans titre',
  description          TEXT,
  thumbnail_url        TEXT,
  is_live              BOOLEAN DEFAULT FALSE,
  is_audio_only        BOOLEAN DEFAULT FALSE,
  viewer_count         INTEGER DEFAULT 0,
  peak_viewers         INTEGER DEFAULT 0,
  started_at           TIMESTAMPTZ DEFAULT NOW(),
  ended_at             TIMESTAMPTZ,
  recording_enabled    BOOLEAN DEFAULT FALSE,
  recording_url        TEXT,
  recording_status     TEXT DEFAULT 'none' CHECK (recording_status IN ('none', 'recording', 'processing', 'uploading', 'completed', 'failed')),
  recording_size_bytes BIGINT,
  duration_seconds     INTEGER DEFAULT 0,
  created_at           TIMESTAMPTZ DEFAULT NOW(),
  updated_at           TIMESTAMPTZ DEFAULT NOW()
);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='live_streams' AND column_name='is_audio_only') THEN
    ALTER TABLE public.live_streams ADD COLUMN is_audio_only BOOLEAN DEFAULT FALSE;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_live_streams_creator_id       ON public.live_streams(creator_id);
CREATE INDEX IF NOT EXISTS idx_live_streams_is_live          ON public.live_streams(is_live);
CREATE INDEX IF NOT EXISTS idx_live_streams_started_at       ON public.live_streams(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_live_streams_recording_status ON public.live_streams(recording_status);


-- live_chat_messages
CREATE TABLE IF NOT EXISTS public.live_chat_messages (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stream_id     UUID NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  user_id       UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name  TEXT NOT NULL,
  avatar_url    TEXT,
  message       TEXT NOT NULL,
  is_deleted    BOOLEAN DEFAULT FALSE,
  deleted_by    UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_live_chat_messages_stream_id  ON public.live_chat_messages(stream_id);
CREATE INDEX IF NOT EXISTS idx_live_chat_messages_user_id    ON public.live_chat_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_live_chat_messages_created_at ON public.live_chat_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_live_chat_messages_is_deleted ON public.live_chat_messages(is_deleted);


-- chat_bans
CREATE TABLE IF NOT EXISTS public.chat_bans (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  stream_id        UUID REFERENCES public.live_streams(id) ON DELETE CASCADE,
  banned_by        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reason           TEXT DEFAULT '',
  banned_user_name TEXT NOT NULL DEFAULT 'Utilisateur',
  banned_by_name   TEXT NOT NULL DEFAULT 'Modérateur',
  expires_at       TIMESTAMPTZ,
  is_active        BOOLEAN DEFAULT TRUE,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_bans_user_id   ON public.chat_bans(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_bans_stream_id ON public.chat_bans(stream_id);
CREATE INDEX IF NOT EXISTS idx_chat_bans_is_active ON public.chat_bans(is_active);


-- moderation_logs
CREATE TABLE IF NOT EXISTS public.moderation_logs (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  moderator_id    UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  moderator_name  TEXT NOT NULL DEFAULT 'Inconnu',
  action_type     TEXT NOT NULL,
  target_type     TEXT NOT NULL,
  target_id       TEXT,
  details         JSONB DEFAULT '{}'::jsonb,
  stream_id       UUID REFERENCES public.live_streams(id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_moderation_logs_moderator_id ON public.moderation_logs(moderator_id);
CREATE INDEX IF NOT EXISTS idx_moderation_logs_action_type  ON public.moderation_logs(action_type);
CREATE INDEX IF NOT EXISTS idx_moderation_logs_created_at   ON public.moderation_logs(created_at DESC);


-- follows
CREATE TABLE IF NOT EXISTS public.follows (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  creator_id  TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(follower_id, creator_id)
);

CREATE INDEX IF NOT EXISTS idx_follows_follower_id ON public.follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_creator_id  ON public.follows(creator_id);


-- verification_requests
CREATE TABLE IF NOT EXISTS public.verification_requests (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id         UUID NOT NULL REFERENCES public.creator_profiles(id) ON DELETE CASCADE,
  status             TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  full_legal_name    TEXT NOT NULL,
  date_of_birth      DATE NOT NULL,
  country            TEXT NOT NULL,
  document_type      TEXT NOT NULL CHECK (document_type IN ('passport', 'national_id', 'drivers_license')),
  document_front_url TEXT NOT NULL,
  document_back_url  TEXT,
  selfie_url         TEXT NOT NULL,
  additional_notes   TEXT,
  rejection_reason   TEXT,
  submitted_at       TIMESTAMPTZ DEFAULT NOW(),
  reviewed_at        TIMESTAMPTZ,
  reviewed_by        UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at         TIMESTAMPTZ DEFAULT NOW(),
  updated_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_verification_requests_creator_id ON public.verification_requests(creator_id);
CREATE INDEX IF NOT EXISTS idx_verification_requests_status     ON public.verification_requests(status);


-- payments
CREATE TABLE IF NOT EXISTS public.payments (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id          UUID NOT NULL REFERENCES public.creator_profiles(id) ON DELETE CASCADE,
  subscription_id     UUID REFERENCES public.creator_subscriptions(id) ON DELETE SET NULL,
  amount              NUMERIC(10,2) NOT NULL,
  currency            TEXT NOT NULL DEFAULT 'XOF',
  payment_method      TEXT NOT NULL DEFAULT 'mobile_money',
  provider            TEXT NOT NULL,
  phone_number        TEXT NOT NULL,
  transaction_id      TEXT NOT NULL UNIQUE,
  external_reference  TEXT,
  status              TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded')),
  status_message      TEXT DEFAULT '',
  metadata            JSONB DEFAULT '{}'::jsonb,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW(),
  completed_at        TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_payments_creator_id     ON public.payments(creator_id);
CREATE INDEX IF NOT EXISTS idx_payments_status         ON public.payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_transaction_id ON public.payments(transaction_id);
CREATE INDEX IF NOT EXISTS idx_payments_provider       ON public.payments(provider);
CREATE INDEX IF NOT EXISTS idx_payments_created_at     ON public.payments(created_at DESC);


-- ==========================================================================
-- 3. FONCTIONS RPC
-- ==========================================================================

-- Anti-spam : compte les messages récents d'un utilisateur dans un stream
CREATE OR REPLACE FUNCTION public.count_recent_messages(
  p_user_id   UUID,
  p_stream_id UUID,
  p_seconds   INTEGER DEFAULT 10
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  msg_count INTEGER;
BEGIN
  SELECT COUNT(*)
  INTO msg_count
  FROM public.live_chat_messages
  WHERE user_id = p_user_id
    AND stream_id = p_stream_id
    AND created_at > NOW() - (p_seconds || ' seconds')::INTERVAL
    AND is_deleted = FALSE;
  RETURN msg_count;
END;
$$;


-- Retourne le user_id du créateur propriétaire d'un stream
CREATE OR REPLACE FUNCTION public.get_stream_creator_id(
  p_stream_id UUID
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_creator_user_id UUID;
BEGIN
  SELECT cp.user_id
  INTO v_creator_user_id
  FROM public.live_streams ls
  JOIN public.creator_profiles cp ON cp.id = ls.creator_id
  WHERE ls.id = p_stream_id;
  RETURN v_creator_user_id;
END;
$$;


-- Trigger helper : met à jour automatiquement updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


-- Recalcule les statistiques d'un créateur après un live
CREATE OR REPLACE FUNCTION public.update_creator_stats(p_creator_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_live_count INTEGER;
  v_total_duration INTEGER;
  v_avg_viewers INTEGER;
  v_total_views INTEGER;
BEGIN
  SELECT
    COUNT(*),
    COALESCE(SUM(duration_seconds), 0),
    COALESCE(AVG(peak_viewers), 0)::INTEGER,
    COALESCE(SUM(peak_viewers), 0)
  INTO v_live_count, v_total_duration, v_avg_viewers, v_total_views
  FROM public.live_streams
  WHERE creator_id = p_creator_id
    AND is_live = FALSE
    AND ended_at IS NOT NULL;

  UPDATE public.creator_profiles
  SET
    live_count = v_live_count,
    total_live_duration_seconds = v_total_duration,
    average_viewers = v_avg_viewers,
    total_views = v_total_views,
    updated_at = NOW()
  WHERE id = p_creator_id;
END;
$$;


-- Trigger function : recalcule les stats quand un live se termine
CREATE OR REPLACE FUNCTION public.trigger_update_creator_stats()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF OLD.is_live = TRUE AND NEW.is_live = FALSE THEN
    PERFORM public.update_creator_stats(NEW.creator_id);
  END IF;
  RETURN NEW;
END;
$$;


-- ==========================================================================
-- 4. TRIGGERS
-- ==========================================================================

-- updated_at automatique sur toutes les tables concernées
DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOR tbl IN
    SELECT unnest(ARRAY[
      'creator_profiles',
      'subscription_plans',
      'creator_subscriptions',
      'team_members',
      'support_requests',
      'live_streams',
      'chat_bans',
      'verification_requests',
      'payments'
    ])
  LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trigger_updated_at ON public.%I;
       CREATE TRIGGER trigger_updated_at
       BEFORE UPDATE ON public.%I
       FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();',
      tbl, tbl
    );
  END LOOP;
END;
$$;

-- Recalcul stats créateur quand un live se termine
DROP TRIGGER IF EXISTS trigger_live_ended_stats ON public.live_streams;
CREATE TRIGGER trigger_live_ended_stats
AFTER UPDATE ON public.live_streams
FOR EACH ROW
WHEN (OLD.is_live IS DISTINCT FROM NEW.is_live)
EXECUTE FUNCTION public.trigger_update_creator_stats();


-- ==========================================================================
-- 5. ROW LEVEL SECURITY — Activation
-- ==========================================================================

ALTER TABLE public.creator_profiles      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_plans    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.team_members          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_requests      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.live_streams          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.live_chat_messages    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_bans             ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moderation_logs       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.verification_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments              ENABLE ROW LEVEL SECURITY;


-- ==========================================================================
-- 6. ROW LEVEL SECURITY — Policies
-- ==========================================================================

-- creator_profiles
DROP POLICY IF EXISTS "Tout le monde peut voir les profils" ON public.creator_profiles;
CREATE POLICY "Tout le monde peut voir les profils"
  ON public.creator_profiles FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Les utilisateurs peuvent creer leur profil" ON public.creator_profiles;
CREATE POLICY "Les utilisateurs peuvent creer leur profil"
  ON public.creator_profiles FOR INSERT
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Les utilisateurs peuvent modifier leur profil" ON public.creator_profiles;
CREATE POLICY "Les utilisateurs peuvent modifier leur profil"
  ON public.creator_profiles FOR UPDATE
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Les utilisateurs peuvent supprimer leur profil" ON public.creator_profiles;
CREATE POLICY "Les utilisateurs peuvent supprimer leur profil"
  ON public.creator_profiles FOR DELETE
  USING (auth.uid() = user_id);


-- subscription_plans
DROP POLICY IF EXISTS "Tout le monde peut voir les plans" ON public.subscription_plans;
CREATE POLICY "Tout le monde peut voir les plans"
  ON public.subscription_plans FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Les admins peuvent gerer les plans" ON public.subscription_plans;
CREATE POLICY "Les admins peuvent gerer les plans"
  ON public.subscription_plans FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid()
      AND is_active = true
      AND role IN ('owner', 'admin')
    )
  );


-- creator_subscriptions
DROP POLICY IF EXISTS "Les createurs voient leur abonnement" ON public.creator_subscriptions;
CREATE POLICY "Les createurs voient leur abonnement"
  ON public.creator_subscriptions FOR SELECT
  USING (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Les createurs peuvent creer un abonnement" ON public.creator_subscriptions;
CREATE POLICY "Les createurs peuvent creer un abonnement"
  ON public.creator_subscriptions FOR INSERT
  WITH CHECK (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Mise a jour abonnement par createur ou admin" ON public.creator_subscriptions;
CREATE POLICY "Mise a jour abonnement par createur ou admin"
  ON public.creator_subscriptions FOR UPDATE
  USING (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true AND role IN ('owner', 'admin')
    )
  );

DROP POLICY IF EXISTS "Suppression abonnement par createur" ON public.creator_subscriptions;
CREATE POLICY "Suppression abonnement par createur"
  ON public.creator_subscriptions FOR DELETE
  USING (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true AND role IN ('owner', 'admin')
    )
  );


-- admin_users
DROP POLICY IF EXISTS "Les admins peuvent voir les admins" ON public.admin_users;
CREATE POLICY "Les admins peuvent voir les admins"
  ON public.admin_users FOR SELECT
  USING (
    auth.uid() = user_id
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true AND role IN ('owner', 'admin')
    )
  );


-- team_members
DROP POLICY IF EXISTS "Les membres actifs voient l equipe" ON public.team_members;
CREATE POLICY "Les membres actifs voient l equipe"
  ON public.team_members FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members tm
      WHERE tm.user_id = auth.uid() AND tm.is_active = true
    )
    OR auth.uid() = user_id
  );

DROP POLICY IF EXISTS "Insertion team members" ON public.team_members;
CREATE POLICY "Insertion team members"
  ON public.team_members FOR INSERT
  WITH CHECK (
    NOT EXISTS (SELECT 1 FROM public.team_members WHERE role = 'owner' AND is_active = true)
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true AND role IN ('owner', 'admin')
    )
  );

DROP POLICY IF EXISTS "Mise a jour team members" ON public.team_members;
CREATE POLICY "Mise a jour team members"
  ON public.team_members FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true AND role IN ('owner', 'admin')
    )
    OR auth.uid() = user_id
  );


-- support_requests
DROP POLICY IF EXISTS "Les createurs voient leurs demandes" ON public.support_requests;
CREATE POLICY "Les createurs voient leurs demandes"
  ON public.support_requests FOR SELECT
  USING (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Les createurs peuvent creer des demandes" ON public.support_requests;
CREATE POLICY "Les createurs peuvent creer des demandes"
  ON public.support_requests FOR INSERT
  WITH CHECK (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Les admins peuvent modifier les demandes" ON public.support_requests;
CREATE POLICY "Les admins peuvent modifier les demandes"
  ON public.support_requests FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true AND role IN ('owner', 'admin', 'moderator')
    )
  );


-- live_streams
DROP POLICY IF EXISTS "Tout le monde peut voir les lives" ON public.live_streams;
CREATE POLICY "Tout le monde peut voir les lives"
  ON public.live_streams FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Les createurs peuvent creer des lives" ON public.live_streams;
CREATE POLICY "Les createurs peuvent creer des lives"
  ON public.live_streams FOR INSERT
  WITH CHECK (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Les createurs et admins peuvent modifier les lives" ON public.live_streams;
CREATE POLICY "Les createurs et admins peuvent modifier les lives"
  ON public.live_streams FOR UPDATE
  USING (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
      AND (role IN ('owner', 'admin') OR (permissions->>'manage_streams')::boolean = true)
    )
  );


-- live_chat_messages
DROP POLICY IF EXISTS "Tout le monde peut voir les messages" ON public.live_chat_messages;
CREATE POLICY "Tout le monde peut voir les messages"
  ON public.live_chat_messages FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Les utilisateurs connectes peuvent envoyer des messages" ON public.live_chat_messages;
CREATE POLICY "Les utilisateurs connectes peuvent envoyer des messages"
  ON public.live_chat_messages FOR INSERT
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Moderation des messages" ON public.live_chat_messages;
CREATE POLICY "Moderation des messages"
  ON public.live_chat_messages FOR UPDATE
  USING (
    auth.uid() = user_id
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
      AND (role IN ('owner', 'admin') OR (permissions->>'moderate_chat')::boolean = true)
    )
  );


-- chat_bans
DROP POLICY IF EXISTS "Les moderateurs voient les bans" ON public.chat_bans;
CREATE POLICY "Les moderateurs voient les bans"
  ON public.chat_bans FOR SELECT
  USING (
    auth.uid() = user_id
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
      AND (role IN ('owner', 'admin') OR (permissions->>'moderate_chat')::boolean = true)
    )
  );

DROP POLICY IF EXISTS "Les moderateurs peuvent bannir" ON public.chat_bans;
CREATE POLICY "Les moderateurs peuvent bannir"
  ON public.chat_bans FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
      AND (role IN ('owner', 'admin') OR (permissions->>'moderate_chat')::boolean = true)
    )
    OR EXISTS (
      SELECT 1 FROM public.creator_profiles WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Les moderateurs peuvent modifier les bans" ON public.chat_bans;
CREATE POLICY "Les moderateurs peuvent modifier les bans"
  ON public.chat_bans FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
      AND (role IN ('owner', 'admin') OR (permissions->>'moderate_chat')::boolean = true)
    )
  );


-- moderation_logs
DROP POLICY IF EXISTS "Les membres de l equipe voient les logs" ON public.moderation_logs;
CREATE POLICY "Les membres de l equipe voient les logs"
  ON public.moderation_logs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Les membres de l equipe peuvent creer des logs" ON public.moderation_logs;
CREATE POLICY "Les membres de l equipe peuvent creer des logs"
  ON public.moderation_logs FOR INSERT
  WITH CHECK (auth.uid() = moderator_id);


-- follows
DROP POLICY IF EXISTS "Tout le monde peut voir les follows" ON public.follows;
CREATE POLICY "Tout le monde peut voir les follows"
  ON public.follows FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Les utilisateurs connectes peuvent suivre" ON public.follows;
CREATE POLICY "Les utilisateurs connectes peuvent suivre"
  ON public.follows FOR INSERT
  WITH CHECK (auth.uid() = follower_id);

DROP POLICY IF EXISTS "Les utilisateurs peuvent se desabonner" ON public.follows;
CREATE POLICY "Les utilisateurs peuvent se desabonner"
  ON public.follows FOR DELETE
  USING (auth.uid() = follower_id);


-- verification_requests
DROP POLICY IF EXISTS "Les createurs voient leurs demandes de verification" ON public.verification_requests;
CREATE POLICY "Les createurs voient leurs demandes de verification"
  ON public.verification_requests FOR SELECT
  USING (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
      AND (role IN ('owner', 'admin') OR (permissions->>'manage_verification')::boolean = true)
    )
  );

DROP POLICY IF EXISTS "Les createurs peuvent soumettre une verification" ON public.verification_requests;
CREATE POLICY "Les createurs peuvent soumettre une verification"
  ON public.verification_requests FOR INSERT
  WITH CHECK (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Les admins peuvent modifier les verifications" ON public.verification_requests;
CREATE POLICY "Les admins peuvent modifier les verifications"
  ON public.verification_requests FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
      AND (role IN ('owner', 'admin') OR (permissions->>'manage_verification')::boolean = true)
    )
  );


-- payments
DROP POLICY IF EXISTS "Les createurs voient leurs paiements" ON public.payments;
CREATE POLICY "Les createurs voient leurs paiements"
  ON public.payments FOR SELECT
  USING (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true
      AND (role IN ('owner', 'admin') OR (permissions->>'view_payments')::boolean = true)
    )
  );

DROP POLICY IF EXISTS "Les paiements sont crees par le systeme" ON public.payments;
CREATE POLICY "Les paiements sont crees par le systeme"
  ON public.payments FOR INSERT
  WITH CHECK (
    creator_id IN (
      SELECT id FROM public.creator_profiles WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Les admins peuvent modifier les paiements" ON public.payments;
CREATE POLICY "Les admins peuvent modifier les paiements"
  ON public.payments FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE user_id = auth.uid() AND is_active = true AND role IN ('owner', 'admin')
    )
  );


-- ==========================================================================
-- 7. REALTIME
-- ==========================================================================

DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_chat_messages;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_streams;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.follows;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END;
$$;


-- ==========================================================================
-- 8. DONNEES INITIALES — Plans d'abonnement (FCFA)
-- ==========================================================================

INSERT INTO public.subscription_plans (name, description, price_monthly, price_yearly, features, is_active)
VALUES
  (
    'Starter',
    'Ideal pour debuter sur la plateforme',
    2990,
    29900,
    '["Lives illimités", "Chat en direct", "Profil personnalisé", "Statistiques de base"]'::jsonb,
    true
  ),
  (
    'Pro',
    'Pour les createurs serieux qui veulent grandir',
    5990,
    59900,
    '["Tout Starter inclus", "Badge vérifié prioritaire", "Enregistrement des lives", "Statistiques avancées", "Support prioritaire", "Personnalisation avancée"]'::jsonb,
    true
  ),
  (
    'Business',
    'Pour les professionnels et les entreprises',
    14990,
    149900,
    '["Tout Pro inclus", "Multi-streaming", "Accès API", "Manager dédié", "Monétisation avancée", "Analytics premium", "Support 24/7", "Marque blanche"]'::jsonb,
    true
  )
ON CONFLICT DO NOTHING;


-- ==========================================================================
-- 9. STORAGE BUCKETS
-- ==========================================================================

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'avatars',
  'avatars',
  true,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'verification-documents',
  'verification-documents',
  false,
  10485760,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'recordings',
  'recordings',
  true,
  524288000,
  ARRAY['video/webm', 'video/mp4', 'video/ogg', 'audio/webm', 'audio/ogg']
)
ON CONFLICT (id) DO NOTHING;


-- ==========================================================================
-- 10. STORAGE POLICIES
-- ==========================================================================

-- avatars
DROP POLICY IF EXISTS "Avatars publics en lecture" ON storage.objects;
CREATE POLICY "Avatars publics en lecture"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'avatars');

DROP POLICY IF EXISTS "Upload avatar par utilisateur connecte" ON storage.objects;
CREATE POLICY "Upload avatar par utilisateur connecte"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'avatars' AND auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Mise a jour avatar par proprietaire" ON storage.objects;
CREATE POLICY "Mise a jour avatar par proprietaire"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'avatars' AND auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Suppression avatar par proprietaire" ON storage.objects;
CREATE POLICY "Suppression avatar par proprietaire"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'avatars' AND auth.role() = 'authenticated');

-- verification-documents
DROP POLICY IF EXISTS "Verification docs lecture par proprietaire et admin" ON storage.objects;
CREATE POLICY "Verification docs lecture par proprietaire et admin"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'verification-documents' AND auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Upload verification docs" ON storage.objects;
CREATE POLICY "Upload verification docs"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'verification-documents' AND auth.role() = 'authenticated');

-- recordings
DROP POLICY IF EXISTS "Recordings publics en lecture" ON storage.objects;
CREATE POLICY "Recordings publics en lecture"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'recordings');

DROP POLICY IF EXISTS "Upload recordings par utilisateur connecte" ON storage.objects;
CREATE POLICY "Upload recordings par utilisateur connecte"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'recordings' AND auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Mise a jour recordings" ON storage.objects;
CREATE POLICY "Mise a jour recordings"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'recordings' AND auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Suppression recordings" ON storage.objects;
CREATE POLICY "Suppression recordings"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'recordings' AND auth.role() = 'authenticated');


-- ==========================================================================
-- FIN DU SCRIPT
-- ==========================================================================
