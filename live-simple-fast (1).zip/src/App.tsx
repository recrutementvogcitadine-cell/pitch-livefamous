
import React, { Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import { AppProvider } from "@/contexts/AppContext";
import ProtectedRoute from "@/components/ProtectedRoute";

// Critical route — loaded eagerly for instant homepage
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";

// Non-critical routes — lazy loaded to reduce initial bundle
const ExplorePage = React.lazy(() => import("./pages/ExplorePage"));
const CreatorProfilePage = React.lazy(() => import("./pages/CreatorProfilePage"));
const AdminDashboard = React.lazy(() => import("./pages/AdminDashboard"));
const AdminActivityLog = React.lazy(() => import("./pages/AdminActivityLog"));
const SettingsPage = React.lazy(() => import("./pages/SettingsPage"));
const PaymentPage = React.lazy(() => import("./pages/PaymentPage"));
const CreatorDashboard = React.lazy(() => import("./pages/CreatorDashboard"));
const SetupPage = React.lazy(() => import("./pages/SetupPage"));
const DiagnosticsPage = React.lazy(() => import("./pages/DiagnosticsPage"));
const EmailTemplatesGuide = React.lazy(() => import("./pages/EmailTemplatesGuide"));
const ProfileEditPage = React.lazy(() => import("./pages/ProfileEditPage"));
const ConnectSyncPage = React.lazy(() => import("./pages/ConnectSyncPage"));

// Lazy load the ConnectionBanner to prevent it from blocking initial render
const ConnectionBanner = React.lazy(() => import("@/components/ConnectionBanner"));

// Page loading fallback
const PageLoader = () => (
  <div className="min-h-screen bg-gray-950 flex items-center justify-center">
    <div className="flex flex-col items-center gap-4">
      <div className="w-10 h-10 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
      <span className="text-gray-400 text-sm">Chargement...</span>
    </div>
  </div>
);

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 30000,
    },
  },
});

const App = () => (
  <ThemeProvider defaultTheme="light">
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Suspense fallback={<PageLoader />}>
              <Routes>
                {/* Public routes */}
                <Route path="/" element={<Index />} />
                <Route path="/explore" element={<ExplorePage />} />
                <Route path="/creator/:username" element={<CreatorProfilePage />} />
                <Route path="/setup" element={<SetupPage />} />
                <Route path="/setup/email-templates" element={<EmailTemplatesGuide />} />
                <Route path="/diagnostics" element={<DiagnosticsPage />} />
                <Route path="/connect-sync" element={<ConnectSyncPage />} />

                {/* Authenticated routes */}
                <Route path="/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
                <Route path="/payment" element={<ProtectedRoute><PaymentPage /></ProtectedRoute>} />
                <Route path="/profile/edit" element={<ProtectedRoute><ProfileEditPage /></ProtectedRoute>} />
                {/* Creator routes — protected, requires authentication */}
                <Route path="/dashboard" element={<ProtectedRoute><CreatorDashboard /></ProtectedRoute>} />

                {/* Admin routes */}
                <Route path="/admin" element={<ProtectedRoute requireAdmin><AdminDashboard /></ProtectedRoute>} />
                <Route path="/admin/activity-log" element={<ProtectedRoute requireAdmin><AdminActivityLog /></ProtectedRoute>} />

                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
            {/* Connection status indicator — lazy loaded, won't block initial render */}
            <Suspense fallback={null}>
              <ConnectionBanner />
            </Suspense>
          </BrowserRouter>
        </AppProvider>
      </TooltipProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
