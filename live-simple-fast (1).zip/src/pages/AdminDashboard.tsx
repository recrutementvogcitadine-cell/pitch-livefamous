import React, { useState, useEffect, useRef, useCallback } from 'react';

import { useNavigate } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { DEFAULT_PERMISSIONS } from '@/lib/teamService';

import {
  Users, CreditCard, BarChart3, MessageSquare, 
  Shield, RefreshCw, CheckCircle, XCircle, Clock, AlertTriangle,
  TrendingUp, Radio, Eye, EyeOff, DollarSign, Plus, Edit, Trash2,
  ChevronDown, Search, Filter, BadgeCheck, FileText, Camera,
  ExternalLink, AlertCircle, UserCheck, Activity, History, Crown,
  Loader2, Lock, Mail, KeyRound, ArrowLeft
} from 'lucide-react';



import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  adminService, 
  CreatorWithSubscription, 
  SupportRequest, 
  PlatformStats 
} from '@/lib/adminService';
import { SubscriptionPlan, subscriptionService } from '@/lib/subscriptionService';
import { 
  VerificationRequest, 
  getAllVerificationRequests, 
  approveVerificationRequest, 
  rejectVerificationRequest,
  revokeVerification,
  getVerificationStats
} from '@/lib/verificationService';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { VerificationBadge, VerificationStatus } from '@/components/VerificationBadge';
import { TeamMember, teamService, ROLE_LABELS } from '@/lib/teamService';
import { activityLogService } from '@/lib/activityLogService';
import TeamTab from '@/components/admin/TeamTab';
import ModerationTab from '@/components/admin/ModerationTab';
import LivesMonitorTab from '@/components/admin/LivesMonitorTab';
import PaymentsAdminTab from '@/components/admin/PaymentsAdminTab';


interface VerificationStats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
}

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentMember, setCurrentMember] = useState<TeamMember | null>(null);
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [sessionExpired, setSessionExpired] = useState(false);

  // Inline login form states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotSuccess, setForgotSuccess] = useState(false);
  const [showPassword, setShowPassword] = useState(false);


  const [activeTab, setActiveTab] = useState('overview');
  
  // Data states
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [creators, setCreators] = useState<CreatorWithSubscription[]>([]);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [supportRequests, setSupportRequests] = useState<SupportRequest[]>([]);
  const [verificationRequests, setVerificationRequests] = useState<VerificationRequest[]>([]);
  const [verificationStats, setVerificationStats] = useState<VerificationStats>({ total: 0, pending: 0, approved: 0, rejected: 0 });
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [subscriptionHistory, setSubscriptionHistory] = useState<any[]>([]);

  // Auto-refresh states
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [secondsAgo, setSecondsAgo] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState(true);
  const [changedKeys, setChangedKeys] = useState<Set<string>>(new Set());
  const prevStatsRef = useRef<PlatformStats | null>(null);
  const prevVerifStatsRef = useRef<VerificationStats | null>(null);
  const refreshIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tickIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);


  // Filter states
  const [creatorSearch, setCreatorSearch] = useState('');
  const [subscriptionFilter, setSubscriptionFilter] = useState('all');
  const [verificationFilter, setVerificationFilter] = useState('all');
  const [supportFilter, setSupportFilter] = useState('all');
  
  // Modal states
  const [editPlanModal, setEditPlanModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null);
  const [subscriptionModal, setSubscriptionModal] = useState(false);
  const [selectedCreator, setSelectedCreator] = useState<CreatorWithSubscription | null>(null);
  const [supportDetailModal, setSupportDetailModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<SupportRequest | null>(null);
  const [verificationDetailModal, setVerificationDetailModal] = useState(false);
  const [selectedVerification, setSelectedVerification] = useState<VerificationRequest | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  // Permission helpers - owner has ALL permissions, same as admin but higher in hierarchy
  const isOwner = currentMember?.role === 'owner';
  const isAdmin = currentMember?.role === 'admin' || isOwner;
  const canManageCreators = isAdmin || currentMember?.permissions?.manage_creators;
  const canManageSubscriptions = isAdmin || currentMember?.permissions?.manage_subscriptions;
  const canManageTeam = isAdmin || currentMember?.permissions?.manage_team;
  const canViewPayments = isAdmin || currentMember?.permissions?.view_payments;
  const canManageVerification = isAdmin || currentMember?.permissions?.manage_verification;
  const canModerateChat = isAdmin || currentMember?.permissions?.moderate_chat;
  const canManageStreams = isAdmin || currentMember?.permissions?.manage_streams;






  useEffect(() => {
    checkAccess();
  }, []);

  const checkAccess = async () => {
    // ---- Guard: Supabase not configured ----
    if (!isSupabaseConfigured) {
      console.warn('[AdminDashboard] Supabase not configured — cannot access admin dashboard');
      setIsAuthorized(false);
      setLoading(false);
      return;
    }

    try {
      // Get user
      let user = null;
      try {
        const { data: { session } } = await supabase.auth.getSession();
        user = session?.user || null;
      } catch {}
      if (!user) {
        try {
          const { data: { user: u } } = await supabase.auth.getUser();
          user = u;
        } catch {}
      }

      if (!user) {
        setIsAuthorized(false);
        setLoading(false);
        return;
      }

      console.log('[AdminDashboard] User found:', user.email);

      // Grant owner access immediately - don't wait for DB
      const fallbackMember: TeamMember = {
        id: 'owner-' + user.id,
        user_id: user.id,
        email: user.email || '',
        display_name: 'Propriétaire',
        role: 'owner',
        permissions: DEFAULT_PERMISSIONS['owner'],
        added_by: null,
        is_active: true,
        last_active_at: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Try to get real member from DB (non-blocking)
      try {
        const { data: member } = await supabase
          .from('team_members')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();
        
        if (member) {
          setCurrentMember(member as TeamMember);
        } else {
          setCurrentMember(fallbackMember);
        }
      } catch {
        setCurrentMember(fallbackMember);
      }

      setIsAuthorized(true);
      setLoading(false);

      // Load data in background - never blocks dashboard rendering
      loadDataSafe();

    } catch (err) {
      console.error('[AdminDashboard] checkAccess error:', err);
      setIsAuthorized(false);
      setLoading(false);
    }
  };


  const loadDataSafe = async () => {
    // Each query is independent and wrapped in its own try/catch
    // None of them affect the loading state - dashboard is already visible

    try {
      const statsData = await adminService.getPlatformStats();
      setStats(statsData);
    } catch { /* silent */ }

    try {
      const creatorsData = await adminService.getAllCreators();
      setCreators(creatorsData);
    } catch { /* silent */ }

    try {
      const plansData = await adminService.getAllPlans();
      setPlans(plansData);
    } catch { /* silent */ }

    try {
      const requestsData = await adminService.getSupportRequests();
      setSupportRequests(requestsData);
    } catch { /* silent */ }

    try {
      const vData = await getAllVerificationRequests();
      setVerificationRequests(vData);
    } catch { /* silent */ }

    try {
      const vStats = await getVerificationStats();
      setVerificationStats(vStats);
    } catch { /* silent */ }

    try {
      const tData = await teamService.getTeamMembers();
      setTeamMembers(tData);
    } catch { /* silent */ }

    try {
      const sData = await teamService.getSubscriptionHistory();
      setSubscriptionHistory(sData);
    } catch { /* silent */ }
  };

  const retryAccess = async () => {
    setLoading(true);
    setSessionExpired(false);
    setIsAuthorized(null);
    setCurrentMember(null);
    await checkAccess();
  };

  // ==================== INLINE ADMIN LOGIN ====================
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    // Client-side validation
    if (!loginEmail.trim()) {
      setLoginError('Veuillez entrer votre adresse email.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(loginEmail.trim())) {
      setLoginError('Veuillez entrer une adresse email valide.');
      return;
    }
    if (!loginPassword) {
      setLoginError('Veuillez entrer votre mot de passe.');
      return;
    }
    if (loginPassword.length < 6) {
      setLoginError('Le mot de passe doit contenir au moins 6 caractères.');
      return;
    }

    setLoginLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginEmail.trim(),
        password: loginPassword,
      });

      if (error) {
        // Map Supabase error messages to French
        const msg = error.message?.toLowerCase() || '';
        if (msg.includes('invalid login credentials') || msg.includes('invalid_credentials')) {
          setLoginError('Email ou mot de passe incorrect. Veuillez vérifier vos identifiants.');
        } else if (msg.includes('email not confirmed')) {
          setLoginError('Votre email n\'a pas encore été confirmé. Vérifiez votre boîte de réception.');
        } else if (msg.includes('too many requests') || msg.includes('rate limit')) {
          setLoginError('Trop de tentatives. Veuillez patienter quelques minutes avant de réessayer.');
        } else if (msg.includes('user not found')) {
          setLoginError('Aucun compte trouvé avec cette adresse email.');
        } else if (msg.includes('network') || msg.includes('fetch')) {
          setLoginError('Erreur de connexion au serveur. Vérifiez votre connexion internet.');
        } else {
          setLoginError(error.message || 'Une erreur est survenue lors de la connexion.');
        }
        setLoginLoading(false);
        return;
      }

      if (data?.user) {
        // Login successful — reset form and re-check access
        setLoginEmail('');
        setLoginPassword('');
        setLoginError('');
        setShowForgotPassword(false);
        setLoading(true);
        setIsAuthorized(null);
        await checkAccess();
      }
    } catch (err: any) {
      setLoginError('Une erreur inattendue est survenue. Veuillez réessayer.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (!forgotEmail.trim()) {
      setLoginError('Veuillez entrer votre adresse email.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(forgotEmail.trim())) {
      setLoginError('Veuillez entrer une adresse email valide.');
      return;
    }

    setForgotLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(forgotEmail.trim(), {
        redirectTo: `${window.location.origin}/admin`,
      });

      if (error) {
        if (error.message?.toLowerCase().includes('rate limit')) {
          setLoginError('Trop de demandes. Veuillez patienter avant de réessayer.');
        } else {
          setLoginError(error.message || 'Erreur lors de l\'envoi du lien de réinitialisation.');
        }
      } else {
        setForgotSuccess(true);
        setLoginError('');
      }
    } catch {
      setLoginError('Une erreur inattendue est survenue.');
    } finally {
      setForgotLoading(false);
    }
  };


  // ==================== AUTO-REFRESH LOGIC ====================

  // Detect which stat keys changed between old and new data
  const detectChanges = useCallback((newStats: PlatformStats | null, newVerifStats: VerificationStats) => {
    const changes = new Set<string>();
    const prev = prevStatsRef.current;
    const prevVerif = prevVerifStatsRef.current;

    if (prev && newStats) {
      if (prev.total_creators !== newStats.total_creators) changes.add('total_creators');
      if (prev.active_subscriptions !== newStats.active_subscriptions) changes.add('active_subscriptions');
      if (prev.live_streams.active_streams !== newStats.live_streams.active_streams) changes.add('active_streams');
      if (prev.live_streams.total_viewers !== newStats.live_streams.total_viewers) changes.add('total_viewers');
      if (prev.total_revenue_monthly !== newStats.total_revenue_monthly) changes.add('revenue');
      if (prev.pending_subscriptions !== newStats.pending_subscriptions) changes.add('pending_subscriptions');
      if (prev.expired_subscriptions !== newStats.expired_subscriptions) changes.add('expired_subscriptions');
      if (prev.live_streams.total_streams !== newStats.live_streams.total_streams) changes.add('total_streams');
      if (prev.live_streams.avg_duration_minutes !== newStats.live_streams.avg_duration_minutes) changes.add('avg_duration');
      if (prev.open_support_requests !== newStats.open_support_requests) changes.add('support_requests');
    }
    if (prevVerif && newVerifStats) {
      if (prevVerif.pending !== newVerifStats.pending) changes.add('verif_pending');
      if (prevVerif.approved !== newVerifStats.approved) changes.add('verif_approved');
      if (prevVerif.rejected !== newVerifStats.rejected) changes.add('verif_rejected');
    }

    return changes;
  }, []);

  // Lightweight refresh: only overview-relevant data (stats + verification stats)
  const refreshOverviewStats = useCallback(async () => {
    if (isRefreshing) return; // prevent overlapping refreshes
    setIsRefreshing(true);

    let newStats: PlatformStats | null = null;
    let newVerifStats: VerificationStats = { total: 0, pending: 0, approved: 0, rejected: 0 };

    // Fetch platform stats (independent, non-blocking)
    try {
      newStats = await adminService.getPlatformStats();
    } catch { /* silent */ }

    // Fetch verification stats (independent, non-blocking)
    try {
      newVerifStats = await getVerificationStats();
    } catch { /* silent */ }

    // Detect changes before updating state
    const changes = detectChanges(newStats, newVerifStats);

    // Update refs for next comparison
    if (newStats) {
      prevStatsRef.current = newStats;
      setStats(newStats);
    }
    prevVerifStatsRef.current = newVerifStats;
    setVerificationStats(newVerifStats);

    // Trigger pulse animation on changed cards
    if (changes.size > 0) {
      setChangedKeys(changes);
      // Clear pulse after animation completes (1.5s)
      setTimeout(() => setChangedKeys(new Set()), 1500);
    }

    setLastUpdated(new Date());
    setSecondsAgo(0);
    setIsRefreshing(false);
  }, [isRefreshing, detectChanges]);

  // Manual refresh handler for the overview refresh button
  const handleManualRefresh = useCallback(() => {
    refreshOverviewStats();
  }, [refreshOverviewStats]);

  // Set initial lastUpdated when stats first load
  useEffect(() => {
    if (stats && !lastUpdated) {
      prevStatsRef.current = stats;
      prevVerifStatsRef.current = verificationStats;
      setLastUpdated(new Date());
    }
  }, [stats]);

  // Polling interval: refresh every 30s when on overview tab and auto-refresh is enabled
  useEffect(() => {
    // Clear any existing interval
    if (refreshIntervalRef.current) {
      clearInterval(refreshIntervalRef.current);
      refreshIntervalRef.current = null;
    }

    if (activeTab === 'overview' && autoRefreshEnabled && isAuthorized) {
      refreshIntervalRef.current = setInterval(() => {
        refreshOverviewStats();
      }, 30000);
    }

    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
        refreshIntervalRef.current = null;
      }
    };
  }, [activeTab, autoRefreshEnabled, isAuthorized, refreshOverviewStats]);

  // Tick interval: update "seconds ago" counter every second
  useEffect(() => {
    if (tickIntervalRef.current) {
      clearInterval(tickIntervalRef.current);
      tickIntervalRef.current = null;
    }

    if (lastUpdated && activeTab === 'overview') {
      tickIntervalRef.current = setInterval(() => {
        setSecondsAgo(Math.floor((Date.now() - lastUpdated.getTime()) / 1000));
      }, 1000);
    }

    return () => {
      if (tickIntervalRef.current) {
        clearInterval(tickIntervalRef.current);
        tickIntervalRef.current = null;
      }
    };
  }, [lastUpdated, activeTab]);

  // Helper: format seconds ago into a human-readable string
  const formatTimeAgo = (secs: number): string => {
    if (secs < 5) return 'à l\'instant';
    if (secs < 60) return `il y a ${secs}s`;
    const mins = Math.floor(secs / 60);
    if (mins < 60) return `il y a ${mins}min`;
    return `il y a ${Math.floor(mins / 60)}h`;
  };

  // Helper: get pulse class for a stat card
  const getPulseClass = (key: string): string => {
    return changedKeys.has(key) ? 'animate-pulse ring-2 ring-purple-400 ring-opacity-75' : '';
  };



  const loadAllData = async (member?: TeamMember) => {
    const m = member || currentMember;
    if (!m) return;
    
    setLoading(true);
    try {
      const promises: Promise<any>[] = [
        adminService.getPlatformStats(),
      ];

      const isOwnerOrAdmin = m.role === 'owner' || m.role === 'admin';

      // Load data based on permissions
      if (isOwnerOrAdmin || m.permissions.manage_creators) {
        promises.push(adminService.getAllCreators());
      } else {
        promises.push(Promise.resolve([]));
      }

      if (isOwnerOrAdmin || m.permissions.manage_subscriptions) {
        promises.push(adminService.getAllPlans());
      } else {
        promises.push(Promise.resolve([]));
      }

      if (isOwnerOrAdmin) {
        promises.push(adminService.getSupportRequests());
      } else {
        promises.push(Promise.resolve([]));
      }

      if (isOwnerOrAdmin || m.permissions.manage_verification) {
        promises.push(getAllVerificationRequests());
        promises.push(getVerificationStats());
      } else {
        promises.push(Promise.resolve([]));
        promises.push(Promise.resolve({ total: 0, pending: 0, approved: 0, rejected: 0 }));
      }

      if (isOwnerOrAdmin || m.permissions.manage_team) {
        promises.push(teamService.getTeamMembers());
      } else {
        promises.push(Promise.resolve([]));
      }

      if (isOwnerOrAdmin || m.permissions.view_payments) {
        promises.push(teamService.getSubscriptionHistory());
      } else {
        promises.push(Promise.resolve([]));
      }


      const [statsData, creatorsData, plansData, requestsData, verificationData, verificationStatsData, teamData, subHistoryData] = await Promise.all(promises);
      
      setStats(statsData);
      setCreators(creatorsData);
      setPlans(plansData);
      setSupportRequests(requestsData);
      setVerificationRequests(verificationData);
      setVerificationStats(verificationStatsData);
      setTeamMembers(teamData);
      setSubscriptionHistory(subHistoryData);
    } catch (err) {
      toast({ title: 'Erreur', description: 'Impossible de charger les données', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  // Filter creators
  const filteredCreators = creators.filter(creator => {
    const matchesSearch = creator.display_name.toLowerCase().includes(creatorSearch.toLowerCase()) ||
                          creator.username.toLowerCase().includes(creatorSearch.toLowerCase());
    const matchesFilter = subscriptionFilter === 'all' || 
                          (subscriptionFilter === 'active' && creator.subscription?.status === 'active') ||
                          (subscriptionFilter === 'pending' && creator.subscription?.status === 'pending') ||
                          (subscriptionFilter === 'expired' && creator.subscription?.status === 'expired') ||
                          (subscriptionFilter === 'none' && !creator.subscription) ||
                          (subscriptionFilter === 'verified' && creator.is_verified) ||
                          (subscriptionFilter === 'unverified' && !creator.is_verified);
    return matchesSearch && matchesFilter;
  });

  const filteredVerifications = verificationRequests.filter(req =>
    verificationFilter === 'all' || req.status === verificationFilter
  );

  const filteredRequests = supportRequests.filter(req => 
    supportFilter === 'all' || req.status === supportFilter
  );

  // Handlers
  const handleActivateSubscription = async (creator: CreatorWithSubscription) => {
    if (!creator.subscription) {
      setSelectedCreator(creator);
      setSubscriptionModal(true);
      return;
    }
    const result = await adminService.activateSubscription(creator.subscription.id, 1);
    if (result.success) {
      await teamService.logAction('activate_subscription', 'subscription', creator.subscription.id, {
        creator_name: creator.display_name,
      });
      // Log to admin activity log
      activityLogService.log({
        actionType: 'activate_subscription',
        actionDescription: `Abonnement activé pour ${creator.display_name} (@${creator.username})`,
        targetType: 'subscription',
        targetId: creator.subscription.id,
        targetLabel: creator.display_name,
        metadata: { creator_id: creator.id, subscription_id: creator.subscription.id },
      });
      toast({ title: 'Succès', description: 'Abonnement activé' });
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleDeactivateSubscription = async (subscriptionId: string) => {
    const result = await adminService.deactivateSubscription(subscriptionId);
    if (result.success) {
      await teamService.logAction('deactivate_subscription', 'subscription', subscriptionId, {});
      activityLogService.log({
        actionType: 'deactivate_subscription',
        actionDescription: `Abonnement désactivé (ID: ${subscriptionId.slice(0, 8)}...)`,
        targetType: 'subscription',
        targetId: subscriptionId,
        metadata: { subscription_id: subscriptionId },
      });
      toast({ title: 'Succès', description: 'Abonnement désactivé' });
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleCreateSubscription = async (creatorId: string, planId: string, months: number) => {
    const result = await adminService.createSubscriptionForCreator(
      creatorId, planId, months >= 12 ? 'yearly' : 'monthly', months
    );
    if (result.success) {
      await teamService.logAction('activate_subscription', 'subscription', creatorId, { planId, months });
      const creator = creators.find(c => c.id === creatorId);
      const plan = plans.find(p => p.id === planId);
      activityLogService.log({
        actionType: 'create_subscription',
        actionDescription: `Abonnement créé pour ${creator?.display_name || creatorId} — Plan: ${plan?.name || planId}, Durée: ${months} mois`,
        targetType: 'subscription',
        targetId: creatorId,
        targetLabel: creator?.display_name || creatorId,
        metadata: { creator_id: creatorId, plan_id: planId, plan_name: plan?.name, months },
      });
      toast({ title: 'Succès', description: 'Abonnement créé' });
      setSubscriptionModal(false);
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleSavePlan = async (plan: Partial<SubscriptionPlan>) => {
    let result;
    if (editingPlan?.id) {
      result = await adminService.updatePlan(editingPlan.id, plan);
    } else {
      result = await adminService.createPlan(plan as Omit<SubscriptionPlan, 'id'>);
    }
    if (result.success) {
      const isUpdate = !!editingPlan?.id;
      activityLogService.log({
        actionType: isUpdate ? 'update_plan' : 'create_plan',
        actionDescription: isUpdate
          ? `Plan "${plan.name || editingPlan?.name}" mis à jour`
          : `Nouveau plan "${plan.name}" créé`,
        targetType: 'plan',
        targetId: editingPlan?.id || undefined,
        targetLabel: plan.name || editingPlan?.name,
        metadata: { plan_data: plan },
      });
      toast({ title: 'Succès', description: editingPlan ? 'Plan mis à jour' : 'Plan créé' });
      setEditPlanModal(false);
      setEditingPlan(null);
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleDeletePlan = async (planId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce plan ?')) return;
    const plan = plans.find(p => p.id === planId);
    const result = await adminService.deletePlan(planId);
    if (result.success) {
      activityLogService.log({
        actionType: 'delete_plan',
        actionDescription: `Plan "${plan?.name || planId}" supprimé`,
        targetType: 'plan',
        targetId: planId,
        targetLabel: plan?.name,
      });
      toast({ title: 'Succès', description: 'Plan supprimé' });
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleUpdateRequest = async (requestId: string, updates: Partial<SupportRequest>) => {
    const result = await adminService.updateSupportRequest(requestId, updates);
    if (result.success) {
      await teamService.logAction('update_support', 'support_request', requestId, { updates });
      const req = supportRequests.find(r => r.id === requestId);
      activityLogService.log({
        actionType: 'update_support',
        actionDescription: `Demande de support "${req?.subject || requestId}" mise à jour — Statut: ${updates.status || 'inchangé'}`,
        targetType: 'support_request',
        targetId: requestId,
        targetLabel: req?.subject,
        metadata: { updates, creator_name: req?.creator?.display_name },
      });
      toast({ title: 'Succès', description: 'Demande mise à jour' });
      setSupportDetailModal(false);
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleApproveVerification = async (requestId: string) => {
    const { data: { user } } = await (await import('@/lib/supabase')).supabase.auth.getUser();
    if (!user) {
      toast({ title: 'Erreur', description: 'Non authentifié', variant: 'destructive' });
      return;
    }
    const request = verificationRequests.find(r => r.id === requestId);
    const result = await approveVerificationRequest(requestId, user.id);
    if (result.success) {
      await teamService.logAction('approve_verification', 'verification', requestId, {});
      activityLogService.log({
        actionType: 'approve_verification',
        actionDescription: `Vérification approuvée pour ${request?.creator_profiles?.display_name || requestId}`,
        targetType: 'verification',
        targetId: requestId,
        targetLabel: request?.creator_profiles?.display_name,
        metadata: { full_legal_name: request?.full_legal_name, country: request?.country },
      });
      toast({ title: 'Succès', description: 'Vérification approuvée' });
      setVerificationDetailModal(false);
      setSelectedVerification(null);
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleRejectVerification = async (requestId: string) => {
    const { data: { user } } = await (await import('@/lib/supabase')).supabase.auth.getUser();
    if (!user) {
      toast({ title: 'Erreur', description: 'Non authentifié', variant: 'destructive' });
      return;
    }
    if (!rejectionReason.trim()) {
      toast({ title: 'Erreur', description: 'Veuillez fournir une raison de rejet', variant: 'destructive' });
      return;
    }
    const request = verificationRequests.find(r => r.id === requestId);
    const result = await rejectVerificationRequest(requestId, user.id, rejectionReason);
    if (result.success) {
      await teamService.logAction('reject_verification', 'verification', requestId, { reason: rejectionReason });
      activityLogService.log({
        actionType: 'reject_verification',
        actionDescription: `Vérification rejetée pour ${request?.creator_profiles?.display_name || requestId} — Raison: ${rejectionReason}`,
        targetType: 'verification',
        targetId: requestId,
        targetLabel: request?.creator_profiles?.display_name,
        metadata: { reason: rejectionReason, full_legal_name: request?.full_legal_name },
      });
      toast({ title: 'Succès', description: 'Vérification rejetée' });
      setVerificationDetailModal(false);
      setSelectedVerification(null);
      setRejectionReason('');
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleRevokeVerification = async (creatorId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir révoquer la vérification ?')) return;
    const creator = creators.find(c => c.id === creatorId);
    const result = await revokeVerification(creatorId);
    if (result.success) {
      activityLogService.log({
        actionType: 'revoke_verification',
        actionDescription: `Vérification révoquée pour ${creator?.display_name || creatorId}`,
        targetType: 'verification',
        targetId: creatorId,
        targetLabel: creator?.display_name,
      });
      toast({ title: 'Succès', description: 'Vérification révoquée' });
      loadAllData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };


  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-purple-600" />
          <p className="mt-2 text-gray-600">Chargement du tableau de bord...</p>
        </div>
      </div>
    );
  }

  // Access denied — contextual messages based on the reason
  if (!isAuthorized || !currentMember) {
    // Determine the specific reason for access denial
    const isNotConfigured = !isSupabaseConfigured;
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-100 via-gray-50 to-purple-50/30 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          {/* Header branding */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-200">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Administration</h1>
            <p className="text-gray-500 text-sm mt-1">Tableau de bord sécurisé</p>
          </div>

          <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
            <CardContent className="pt-6 pb-6">
              {/* Not configured state */}
              {isNotConfigured ? (
                <div className="text-center">
                  <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-amber-100 flex items-center justify-center">
                    <AlertTriangle className="w-7 h-7 text-amber-600" />
                  </div>
                  <h2 className="text-lg font-bold mb-2">Configuration requise</h2>
                  <p className="text-gray-600 text-sm mb-3">
                    La base de données Supabase n'est pas encore configurée.
                  </p>
                  <div className="bg-gray-50 border rounded-xl p-4 mb-5 text-left">
                    <p className="text-sm font-semibold text-gray-700 mb-2">Étapes à suivre :</p>
                    <ol className="text-sm text-gray-600 space-y-1.5 list-decimal list-inside">
                      <li>Créez un projet sur <a href="https://supabase.com" target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:underline font-medium">supabase.com</a></li>
                      <li>Copiez votre URL et clé anon</li>
                      <li>Collez-les dans la page de configuration</li>
                    </ol>
                  </div>
                  <div className="flex gap-3 justify-center">
                    <Button variant="outline" size="sm" onClick={() => navigate('/')}>
                      Retour
                    </Button>
                    <Button size="sm" onClick={() => navigate('/setup')} className="bg-purple-600 hover:bg-purple-700">
                      Configurer Supabase
                    </Button>
                  </div>
                </div>
              ) : showForgotPassword ? (
                /* ==================== FORGOT PASSWORD FORM ==================== */
                <div>
                  <button
                    onClick={() => { setShowForgotPassword(false); setLoginError(''); setForgotSuccess(false); setForgotEmail(''); }}
                    className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 mb-5 transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Retour à la connexion
                  </button>

                  <div className="text-center mb-6">
                    <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-purple-100 flex items-center justify-center">
                      <KeyRound className="w-6 h-6 text-purple-600" />
                    </div>
                    <h2 className="text-lg font-bold text-gray-900">Mot de passe oublié</h2>
                    <p className="text-gray-500 text-sm mt-1">
                      Entrez votre email pour recevoir un lien de réinitialisation.
                    </p>
                  </div>

                  {forgotSuccess ? (
                    <div className="text-center">
                      <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
                        <CheckCircle className="w-7 h-7 text-green-600" />
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-2">Email envoyé</h3>
                      <p className="text-gray-600 text-sm mb-5">
                        Si un compte existe avec l'adresse <strong className="text-gray-800">{forgotEmail}</strong>, vous recevrez un lien de réinitialisation dans quelques instants.
                      </p>
                      <p className="text-gray-400 text-xs mb-4">
                        Vérifiez aussi votre dossier spam.
                      </p>
                      <Button
                        variant="outline"
                        onClick={() => { setShowForgotPassword(false); setForgotSuccess(false); setForgotEmail(''); setLoginError(''); }}
                        className="w-full"
                      >
                        Retour à la connexion
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleForgotPassword} className="space-y-4">
                      {loginError && (
                        <div className="flex items-start gap-2.5 p-3 bg-red-50 border border-red-200 rounded-xl">
                          <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                          <p className="text-red-700 text-sm">{loginError}</p>
                        </div>
                      )}

                      <div>
                        <Label className="text-sm font-medium text-gray-700 mb-1.5 block">Adresse email</Label>
                        <div className="relative">
                          <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                          <Input
                            type="email"
                            value={forgotEmail}
                            onChange={(e) => setForgotEmail(e.target.value)}
                            placeholder="admin@exemple.com"
                            className="pl-10 h-11"
                            required
                            autoComplete="email"
                            autoFocus
                          />
                        </div>
                      </div>

                      <Button
                        type="submit"
                        disabled={forgotLoading}
                        className="w-full h-11 bg-purple-600 hover:bg-purple-700"
                      >
                        {forgotLoading ? (
                          <div className="flex items-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Envoi en cours...
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Mail className="w-4 h-4" />
                            Envoyer le lien
                          </div>
                        )}
                      </Button>
                    </form>
                  )}
                </div>
              ) : (
                /* ==================== LOGIN FORM ==================== */
                <div>
                  {sessionExpired && (
                    <div className="flex items-start gap-2.5 p-3 mb-4 bg-amber-50 border border-amber-200 rounded-xl">
                      <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                      <p className="text-amber-800 text-sm">Votre session a expiré. Veuillez vous reconnecter.</p>
                    </div>
                  )}

                  <div className="text-center mb-6">
                    <h2 className="text-lg font-bold text-gray-900">Connexion administrateur</h2>
                    <p className="text-gray-500 text-sm mt-1">
                      Connectez-vous pour accéder au tableau de bord.
                    </p>
                  </div>

                  {loginError && (
                    <div className="flex items-start gap-2.5 p-3 mb-4 bg-red-50 border border-red-200 rounded-xl">
                      <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                      <p className="text-red-700 text-sm">{loginError}</p>
                    </div>
                  )}

                  <form onSubmit={handleAdminLogin} className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700 mb-1.5 block">Adresse email</Label>
                      <div className="relative">
                        <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <Input
                          type="email"
                          value={loginEmail}
                          onChange={(e) => { setLoginEmail(e.target.value); setLoginError(''); }}
                          placeholder="admin@exemple.com"
                          className="pl-10 h-11"
                          required
                          autoComplete="email"
                          autoFocus
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <Label className="text-sm font-medium text-gray-700">Mot de passe</Label>
                        <button
                          type="button"
                          onClick={() => { setShowForgotPassword(true); setForgotEmail(loginEmail); setLoginError(''); }}
                          className="text-xs text-purple-600 hover:text-purple-700 font-medium transition-colors"
                        >
                          Mot de passe oublié ?
                        </button>
                      </div>
                      <div className="relative">
                        <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <Input
                          type={showPassword ? 'text' : 'password'}
                          value={loginPassword}
                          onChange={(e) => { setLoginPassword(e.target.value); setLoginError(''); }}
                          placeholder="Votre mot de passe"
                          className="pl-10 pr-10 h-11"
                          required
                          minLength={6}
                          autoComplete="current-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                          tabIndex={-1}
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      disabled={loginLoading}
                      className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-md shadow-purple-200/50"
                    >
                      {loginLoading ? (
                        <div className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Connexion en cours...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4" />
                          Se connecter
                        </div>
                      )}
                    </Button>
                  </form>

                  <div className="mt-5 pt-4 border-t text-center">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate('/')}
                      className="text-gray-400 hover:text-gray-600 text-xs"
                    >
                      <ArrowLeft className="w-3.5 h-3.5 mr-1.5" />
                      Retour au site
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Security notice */}
          <p className="text-center text-gray-400 text-xs mt-6 flex items-center justify-center gap-1.5">
            <Lock className="w-3 h-3" />
            Connexion sécurisée via Supabase Auth
          </p>
        </div>
      </div>
    );
  }




  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b shadow-sm">


        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isOwner 
                ? 'bg-gradient-to-br from-amber-500 to-orange-500' 
                : 'bg-gradient-to-br from-purple-600 to-blue-600'
            }`}>
              {isOwner ? <Crown className="w-5 h-5 text-white" /> : <Shield className="w-5 h-5 text-white" />}
            </div>
            <div>
              <h1 className="text-lg font-bold">Tableau de bord</h1>
              <div className="flex items-center gap-2">
                <Badge className={
                  currentMember.role === 'owner' ? 'bg-amber-100 text-amber-800 text-xs flex items-center gap-1' :
                  currentMember.role === 'admin' ? 'bg-purple-100 text-purple-700 text-xs' :
                  currentMember.role === 'moderator' ? 'bg-blue-100 text-blue-700 text-xs' :
                  'bg-gray-100 text-gray-600 text-xs'
                }>
                  {currentMember.role === 'owner' && <Crown className="w-3 h-3" />}
                  {ROLE_LABELS[currentMember.role]}
                </Badge>
                <span className="text-xs text-gray-400">{currentMember.display_name}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => navigate('/admin/activity-log')} className="text-indigo-600 border-indigo-200 hover:bg-indigo-50">
              <History className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Journal d'activité</span>
            </Button>
            <Button variant="outline" size="sm" onClick={() => loadAllData()}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Actualiser
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate('/')}>
              Retour au site
            </Button>
          </div>

        </div>
      </header>


      <main className="max-w-7xl mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 flex-wrap h-auto gap-1 bg-white border p-1">
            {/* Always visible */}
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Vue d'ensemble</span>
            </TabsTrigger>

            {/* Lives monitor - visible to moderators and admins */}
            {(canManageStreams || canModerateChat) && (
              <TabsTrigger value="lives" className="flex items-center gap-2">
                <Radio className="w-4 h-4" />
                <span className="hidden sm:inline">Lives</span>
                {stats && stats.live_streams.active_streams > 0 && (
                  <Badge className="bg-red-500 text-white ml-1 text-xs px-1.5">
                    {stats.live_streams.active_streams}
                  </Badge>
                )}
              </TabsTrigger>
            )}

            {/* Moderation logs */}
            {(canModerateChat || isAdmin) && (
              <TabsTrigger value="moderation" className="flex items-center gap-2">
                <Activity className="w-4 h-4" />
                <span className="hidden sm:inline">Modération</span>
              </TabsTrigger>
            )}

            {/* Creators - admin or manage_creators */}
            {canManageCreators && (
              <TabsTrigger value="creators" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span className="hidden sm:inline">Créateurs</span>
              </TabsTrigger>
            )}

            {/* Verification */}
            {canManageVerification && (
              <TabsTrigger value="verification" className="flex items-center gap-2">
                <BadgeCheck className="w-4 h-4" />
                <span className="hidden sm:inline">Vérification</span>
                {verificationStats.pending > 0 && (
                  <Badge variant="destructive" className="ml-1 text-xs px-1.5">
                    {verificationStats.pending}
                  </Badge>
                )}
              </TabsTrigger>
            )}

            {/* Payments */}
            {canViewPayments && (
              <TabsTrigger value="payments" className="flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                <span className="hidden sm:inline">Paiements</span>
              </TabsTrigger>
            )}


            {/* Plans - admin only */}
            {canManageSubscriptions && (
              <TabsTrigger value="plans" className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                <span className="hidden sm:inline">Plans</span>
              </TabsTrigger>
            )}

            {/* Support - admin only */}
            {isAdmin && (
              <TabsTrigger value="support" className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                <span className="hidden sm:inline">Support</span>
                {stats && stats.open_support_requests > 0 && (
                  <Badge variant="destructive" className="ml-1 text-xs px-1.5">
                    {stats.open_support_requests}
                  </Badge>
                )}
              </TabsTrigger>
            )}

            {/* Team management - admin or manage_team */}
            {canManageTeam && (
              <TabsTrigger value="team" className="flex items-center gap-2">
                <UserCheck className="w-4 h-4" />
                <span className="hidden sm:inline">Équipe</span>
              </TabsTrigger>
            )}
          </TabsList>

          {/* ==================== OVERVIEW TAB ==================== */}
          <TabsContent value="overview">
            {/* Auto-refresh status bar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-5 p-3 bg-white border rounded-lg shadow-sm">
              <div className="flex items-center gap-3">
                {/* Live status dot */}
                <div className="relative flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${autoRefreshEnabled ? 'bg-green-500' : 'bg-gray-300'}`} />
                  {autoRefreshEnabled && (
                    <span className="absolute w-2 h-2 rounded-full bg-green-500 animate-ping" />
                  )}
                  <span className="text-sm font-medium text-gray-700">
                    {autoRefreshEnabled ? 'Actualisation auto' : 'Actualisation auto désactivée'}
                  </span>
                </div>

                {/* Last updated indicator */}
                {lastUpdated && (
                  <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-gray-50 px-2.5 py-1 rounded-full">
                    <Clock className="w-3 h-3" />
                    <span>Mis à jour {formatTimeAgo(secondsAgo)}</span>
                    {isRefreshing && (
                      <Loader2 className="w-3 h-3 animate-spin text-purple-500 ml-1" />
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3">
                {/* Auto-refresh toggle */}
                <div className="flex items-center gap-2">
                  <Switch
                    checked={autoRefreshEnabled}
                    onCheckedChange={setAutoRefreshEnabled}
                    className="data-[state=checked]:bg-purple-600"
                  />
                  <Label className="text-xs text-gray-500 cursor-pointer" onClick={() => setAutoRefreshEnabled(!autoRefreshEnabled)}>
                    30s
                  </Label>
                </div>

                {/* Manual refresh button */}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleManualRefresh}
                  disabled={isRefreshing}
                  className="text-xs h-8"
                >
                  <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                  Rafraîchir
                </Button>
              </div>
            </div>

            {/* Progress bar showing time until next refresh */}
            {autoRefreshEnabled && lastUpdated && (
              <div className="mb-5 h-0.5 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full transition-all duration-1000 ease-linear"
                  style={{ width: `${Math.min((secondsAgo / 30) * 100, 100)}%` }}
                />
              </div>
            )}

            {/* Stat cards with pulse animation */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
              <Card className={`transition-all duration-500 ${getPulseClass('total_creators')}`}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Total Créateurs</p>
                      <p className="text-3xl font-bold">{stats?.total_creators || 0}</p>
                    </div>
                    <Users className="w-10 h-10 text-purple-500 opacity-50" />
                  </div>
                </CardContent>
              </Card>
              <Card className={`transition-all duration-500 ${getPulseClass('active_subscriptions')}`}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Abonnements Actifs</p>
                      <p className="text-3xl font-bold text-green-600">{stats?.active_subscriptions || 0}</p>
                    </div>
                    <CheckCircle className="w-10 h-10 text-green-500 opacity-50" />
                  </div>
                </CardContent>
              </Card>
              <Card className={`transition-all duration-500 ${getPulseClass('verif_approved')}`}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Créateurs Vérifiés</p>
                      <p className="text-3xl font-bold text-blue-600">{verificationStats.approved}</p>
                    </div>
                    <BadgeCheck className="w-10 h-10 text-blue-500 opacity-50" />
                  </div>
                </CardContent>
              </Card>
              <Card className={`transition-all duration-500 ${
                stats?.live_streams.active_streams ? 'border-red-200 bg-red-50/20' : ''
              } ${getPulseClass('active_streams')}`}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Lives Actifs</p>
                      <p className="text-3xl font-bold text-red-600">{stats?.live_streams.active_streams || 0}</p>
                    </div>
                    <div className="relative">
                      <Radio className="w-10 h-10 text-red-500 opacity-50" />
                      {(stats?.live_streams.active_streams || 0) > 0 && (
                        <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
              {canViewPayments && (
                <Card className={`transition-all duration-500 ${getPulseClass('revenue')}`}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-500">Revenus Mensuels</p>
                        <p className="text-3xl font-bold text-blue-600">
                          {adminService.formatCurrency(stats?.total_revenue_monthly || 0)}
                        </p>
                      </div>
                      <DollarSign className="w-10 h-10 text-blue-500 opacity-50" />
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Detail cards with pulse animations on rows */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Abonnements</span>
                    {(changedKeys.has('active_subscriptions') || changedKeys.has('pending_subscriptions') || changedKeys.has('expired_subscriptions')) && (
                      <span className="w-2 h-2 rounded-full bg-purple-500 animate-ping" />
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className={`flex items-center justify-between p-3 bg-green-50 rounded-lg transition-all duration-500 ${getPulseClass('active_subscriptions')}`}>
                      <div className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <span>Actifs</span>
                      </div>
                      <span className="font-bold text-green-600">{stats?.active_subscriptions || 0}</span>
                    </div>
                    <div className={`flex items-center justify-between p-3 bg-yellow-50 rounded-lg transition-all duration-500 ${getPulseClass('pending_subscriptions')}`}>
                      <div className="flex items-center gap-3">
                        <Clock className="w-5 h-5 text-yellow-600" />
                        <span>En attente</span>
                      </div>
                      <span className="font-bold text-yellow-600">{stats?.pending_subscriptions || 0}</span>
                    </div>
                    <div className={`flex items-center justify-between p-3 bg-red-50 rounded-lg transition-all duration-500 ${getPulseClass('expired_subscriptions')}`}>
                      <div className="flex items-center gap-3">
                        <XCircle className="w-5 h-5 text-red-600" />
                        <span>Expirés</span>
                      </div>
                      <span className="font-bold text-red-600">{stats?.expired_subscriptions || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Vérification</span>
                    {(changedKeys.has('verif_pending') || changedKeys.has('verif_approved') || changedKeys.has('verif_rejected')) && (
                      <span className="w-2 h-2 rounded-full bg-purple-500 animate-ping" />
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className={`flex items-center justify-between p-3 bg-yellow-50 rounded-lg transition-all duration-500 ${getPulseClass('verif_pending')}`}>
                      <div className="flex items-center gap-3">
                        <Clock className="w-5 h-5 text-yellow-600" />
                        <span>En attente</span>
                      </div>
                      <span className="font-bold text-yellow-600">{verificationStats.pending}</span>
                    </div>
                    <div className={`flex items-center justify-between p-3 bg-blue-50 rounded-lg transition-all duration-500 ${getPulseClass('verif_approved')}`}>
                      <div className="flex items-center gap-3">
                        <BadgeCheck className="w-5 h-5 text-blue-600" />
                        <span>Approuvés</span>
                      </div>
                      <span className="font-bold text-blue-600">{verificationStats.approved}</span>
                    </div>
                    <div className={`flex items-center justify-between p-3 bg-red-50 rounded-lg transition-all duration-500 ${getPulseClass('verif_rejected')}`}>
                      <div className="flex items-center gap-3">
                        <XCircle className="w-5 h-5 text-red-600" />
                        <span>Rejetés</span>
                      </div>
                      <span className="font-bold text-red-600">{verificationStats.rejected}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Lives</span>
                    {(changedKeys.has('total_streams') || changedKeys.has('total_viewers') || changedKeys.has('avg_duration')) && (
                      <span className="w-2 h-2 rounded-full bg-purple-500 animate-ping" />
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className={`flex items-center justify-between p-3 bg-purple-50 rounded-lg transition-all duration-500 ${getPulseClass('total_streams')}`}>
                      <div className="flex items-center gap-3">
                        <Radio className="w-5 h-5 text-purple-600" />
                        <span>Total Lives</span>
                      </div>
                      <span className="font-bold">{stats?.live_streams.total_streams || 0}</span>
                    </div>
                    <div className={`flex items-center justify-between p-3 bg-blue-50 rounded-lg transition-all duration-500 ${getPulseClass('total_viewers')}`}>
                      <div className="flex items-center gap-3">
                        <Eye className="w-5 h-5 text-blue-600" />
                        <span>Spectateurs actuels</span>
                      </div>
                      <span className="font-bold text-blue-600">{stats?.live_streams.total_viewers || 0}</span>
                    </div>
                    <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg transition-all duration-500 ${getPulseClass('avg_duration')}`}>
                      <div className="flex items-center gap-3">
                        <TrendingUp className="w-5 h-5 text-gray-600" />
                        <span>Durée moyenne</span>
                      </div>
                      <span className="font-bold">{stats?.live_streams.avg_duration_minutes || 0} min</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>


          {/* ==================== LIVES MONITOR TAB ==================== */}
          <TabsContent value="lives">
            <LivesMonitorTab currentMember={currentMember} />
          </TabsContent>

          {/* ==================== MODERATION TAB ==================== */}
          <TabsContent value="moderation">
            <ModerationTab currentMember={currentMember} />
          </TabsContent>

          {/* ==================== CREATORS TAB ==================== */}
          <TabsContent value="creators">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <CardTitle>Gestion des Créateurs</CardTitle>
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                      <Input
                        placeholder="Rechercher..."
                        value={creatorSearch}
                        onChange={(e) => setCreatorSearch(e.target.value)}
                        className="pl-9 w-64"
                      />
                    </div>
                    <Select value={subscriptionFilter} onValueChange={setSubscriptionFilter}>
                      <SelectTrigger className="w-44">
                        <Filter className="w-4 h-4 mr-2" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tous</SelectItem>
                        <SelectItem value="active">Abonnement actif</SelectItem>
                        <SelectItem value="pending">En attente</SelectItem>
                        <SelectItem value="expired">Expiré</SelectItem>
                        <SelectItem value="none">Sans abonnement</SelectItem>
                        <SelectItem value="verified">Vérifiés</SelectItem>
                        <SelectItem value="unverified">Non vérifiés</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Créateur</th>
                        <th className="text-left py-3 px-4">Vérification</th>
                        <th className="text-left py-3 px-4">Abonnement</th>
                        <th className="text-left py-3 px-4">Statut</th>
                        <th className="text-left py-3 px-4">Expiration</th>
                        {canManageSubscriptions && <th className="text-right py-3 px-4">Actions</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredCreators.map((creator) => (
                        <tr key={creator.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <Avatar className="w-10 h-10">
                                <AvatarImage src={creator.avatar_url || ''} />
                                <AvatarFallback>{creator.display_name[0]}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="flex items-center gap-1">
                                  <p className="font-medium">{creator.display_name}</p>
                                  <VerificationBadge isVerified={creator.is_verified || false} size="sm" />
                                </div>
                                <p className="text-sm text-gray-500">@{creator.username}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            {creator.is_verified ? (
                              <div className="flex items-center gap-2">
                                <Badge className="bg-blue-100 text-blue-700">Vérifié</Badge>
                                {canManageVerification && (
                                  <Button size="sm" variant="ghost" className="text-red-500 h-7 px-2"
                                    onClick={() => handleRevokeVerification(creator.id)}>
                                    Révoquer
                                  </Button>
                                )}
                              </div>
                            ) : (
                              <Badge variant="outline">Non vérifié</Badge>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {creator.subscription?.plan ? (
                              <span>{creator.subscription.plan.name}</span>
                            ) : (
                              <span className="text-gray-400">Aucun</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {creator.subscription ? (
                              <Badge className={
                                creator.subscription.status === 'active' ? 'bg-green-100 text-green-700' :
                                creator.subscription.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                                'bg-red-100 text-red-700'
                              }>
                                {subscriptionService.getStatusLabel(creator.subscription.status)}
                              </Badge>
                            ) : (
                              <Badge variant="outline">Non abonné</Badge>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {creator.subscription?.expires_at ? (
                              <span className="text-sm">
                                {new Date(creator.subscription.expires_at).toLocaleDateString('fr-FR')}
                              </span>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </td>
                          {canManageSubscriptions && (
                            <td className="py-3 px-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                {creator.subscription?.status === 'active' ? (
                                  <Button size="sm" variant="outline" className="text-red-600"
                                    onClick={() => handleDeactivateSubscription(creator.subscription!.id)}>
                                    <XCircle className="w-4 h-4 mr-1" />
                                    Désactiver
                                  </Button>
                                ) : (
                                  <Button size="sm" variant="outline" className="text-green-600"
                                    onClick={() => handleActivateSubscription(creator)}>
                                    <CheckCircle className="w-4 h-4 mr-1" />
                                    Activer
                                  </Button>
                                )}
                              </div>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {filteredCreators.length === 0 && (
                    <div className="text-center py-8 text-gray-500">Aucun créateur trouvé</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== VERIFICATION TAB ==================== */}
          <TabsContent value="verification">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Demandes de Vérification</CardTitle>
                    <CardDescription>Examinez les documents et accordez les badges</CardDescription>
                  </div>
                  <Select value={verificationFilter} onValueChange={setVerificationFilter}>
                    <SelectTrigger className="w-40">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes</SelectItem>
                      <SelectItem value="pending">En attente</SelectItem>
                      <SelectItem value="approved">Approuvées</SelectItem>
                      <SelectItem value="rejected">Rejetées</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredVerifications.map((request) => (
                    <div key={request.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                      onClick={() => { setSelectedVerification(request); setVerificationDetailModal(true); }}>
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={request.creator_profiles?.avatar_url || ''} />
                            <AvatarFallback>{request.creator_profiles?.display_name?.[0] || '?'}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium">{request.creator_profiles?.display_name}</h4>
                              <VerificationStatus status={request.status} />
                            </div>
                            <p className="text-sm text-gray-500">{request.full_legal_name} - {request.country}</p>
                            <p className="text-sm text-gray-400 mt-1">
                              Soumis le {new Date(request.submitted_at).toLocaleDateString('fr-FR')}
                            </p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge variant="outline" className="capitalize">
                            {request.document_type === 'passport' ? 'Passeport' :
                             request.document_type === 'national_id' ? "Carte d'identité" : 'Permis'}
                          </Badge>
                          {request.status === 'pending' && (
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline" className="text-green-600"
                                onClick={(e) => { e.stopPropagation(); handleApproveVerification(request.id); }}>
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="outline" className="text-red-600"
                                onClick={(e) => { e.stopPropagation(); setSelectedVerification(request); setVerificationDetailModal(true); }}>
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {filteredVerifications.length === 0 && (
                    <div className="text-center py-8 text-gray-500">Aucune demande de vérification</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== PAYMENTS TAB ==================== */}
          <TabsContent value="payments">
            <PaymentsAdminTab currentMember={currentMember} />
          </TabsContent>


          {/* ==================== PLANS TAB ==================== */}
          <TabsContent value="plans">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Plans d'abonnement</CardTitle>
                  <Button onClick={() => { setEditingPlan(null); setEditPlanModal(true); }}>
                    <Plus className="w-4 h-4 mr-2" />
                    Nouveau Plan
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {plans.map((plan) => (
                    <Card key={plan.id} className={!plan.is_active ? 'opacity-50' : ''}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{plan.name}</CardTitle>
                          {!plan.is_active && <Badge variant="outline">Inactif</Badge>}
                        </div>
                        <CardDescription>{plan.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-500">Mensuel</span>
                            <span className="font-bold text-lg">{subscriptionService.formatPrice(plan.price_monthly)}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-500">Annuel</span>
                            <span className="font-bold text-lg">{subscriptionService.formatPrice(plan.price_yearly)}</span>
                          </div>
                          <div className="pt-3 border-t">
                            <p className="text-sm text-gray-500 mb-2">Fonctionnalités:</p>
                            <ul className="text-sm space-y-1">
                              {plan.features?.map((feature, i) => (
                                <li key={i} className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  {feature}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div className="flex gap-2 pt-3">
                            <Button size="sm" variant="outline" className="flex-1"
                              onClick={() => { setEditingPlan(plan); setEditPlanModal(true); }}>
                              <Edit className="w-4 h-4 mr-1" />
                              Modifier
                            </Button>
                            <Button size="sm" variant="outline" className="text-red-600"
                              onClick={() => handleDeletePlan(plan.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== SUPPORT TAB ==================== */}
          <TabsContent value="support">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Demandes de Support</CardTitle>
                  <Select value={supportFilter} onValueChange={setSupportFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes</SelectItem>
                      <SelectItem value="open">Ouvertes</SelectItem>
                      <SelectItem value="in_progress">En cours</SelectItem>
                      <SelectItem value="resolved">Résolues</SelectItem>
                      <SelectItem value="closed">Fermées</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredRequests.map((request) => (
                    <div key={request.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                      onClick={() => { setSelectedRequest(request); setSupportDetailModal(true); }}>
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={request.creator?.avatar_url || ''} />
                            <AvatarFallback>{request.creator?.display_name?.[0] || '?'}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-medium">{request.subject}</h4>
                            <p className="text-sm text-gray-500">
                              {request.creator?.display_name} - {new Date(request.created_at).toLocaleDateString('fr-FR')}
                            </p>
                            <p className="text-sm text-gray-600 mt-1 line-clamp-2">{request.message}</p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge className={adminService.getStatusColor(request.status)}>
                            {request.status === 'open' ? 'Ouverte' :
                             request.status === 'in_progress' ? 'En cours' :
                             request.status === 'resolved' ? 'Résolue' : 'Fermée'}
                          </Badge>
                          <Badge className={adminService.getPriorityColor(request.priority)}>
                            {request.priority === 'urgent' ? 'Urgent' :
                             request.priority === 'high' ? 'Haute' :
                             request.priority === 'normal' ? 'Normale' : 'Basse'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                  {filteredRequests.length === 0 && (
                    <div className="text-center py-8 text-gray-500">Aucune demande de support</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== TEAM TAB ==================== */}
          <TabsContent value="team">
            <TeamTab
              members={teamMembers}
              currentMember={currentMember}
              onRefresh={() => loadAllData()}
            />
          </TabsContent>
        </Tabs>
      </main>

      {/* ==================== MODALS ==================== */}

      {/* Edit Plan Modal */}
      <Dialog open={editPlanModal} onOpenChange={setEditPlanModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingPlan ? 'Modifier le plan' : 'Nouveau plan'}</DialogTitle>
          </DialogHeader>
          <PlanForm plan={editingPlan} onSave={handleSavePlan} onCancel={() => setEditPlanModal(false)} />
        </DialogContent>
      </Dialog>

      {/* Create Subscription Modal */}
      <Dialog open={subscriptionModal} onOpenChange={setSubscriptionModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Créer un abonnement</DialogTitle>
          </DialogHeader>
          {selectedCreator && (
            <CreateSubscriptionForm
              creator={selectedCreator}
              plans={plans.filter(p => p.is_active)}
              onSave={handleCreateSubscription}
              onCancel={() => setSubscriptionModal(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Support Detail Modal */}
      <Dialog open={supportDetailModal} onOpenChange={setSupportDetailModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Détail de la demande</DialogTitle>
          </DialogHeader>
          {selectedRequest && (
            <SupportRequestDetail
              request={selectedRequest}
              onUpdate={handleUpdateRequest}
              onClose={() => setSupportDetailModal(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Verification Detail Modal */}
      <Dialog open={verificationDetailModal} onOpenChange={setVerificationDetailModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Détail de la demande de vérification</DialogTitle>
          </DialogHeader>
          {selectedVerification && (
            <VerificationRequestDetail
              request={selectedVerification}
              rejectionReason={rejectionReason}
              setRejectionReason={setRejectionReason}
              onApprove={() => handleApproveVerification(selectedVerification.id)}
              onReject={() => handleRejectVerification(selectedVerification.id)}
              onClose={() => { setVerificationDetailModal(false); setRejectionReason(''); }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

// ==================== SUB-COMPONENTS ====================

const PlanForm: React.FC<{
  plan: SubscriptionPlan | null;
  onSave: (plan: Partial<SubscriptionPlan>) => void;
  onCancel: () => void;
}> = ({ plan, onSave, onCancel }) => {
  const [name, setName] = useState(plan?.name || '');
  const [description, setDescription] = useState(plan?.description || '');
  const [priceMonthly, setPriceMonthly] = useState(plan?.price_monthly?.toString() || '');
  const [priceYearly, setPriceYearly] = useState(plan?.price_yearly?.toString() || '');
  const [features, setFeatures] = useState(plan?.features?.join('\n') || '');
  const [isActive, setIsActive] = useState(plan?.is_active ?? true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name, description,
      price_monthly: parseFloat(priceMonthly),
      price_yearly: parseFloat(priceYearly),
      features: features.split('\n').filter(f => f.trim()),
      is_active: isActive
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Nom du plan</Label>
        <Input value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div>
        <Label>Description</Label>
        <Input value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Prix mensuel (EUR)</Label>
          <Input type="number" step="0.01" value={priceMonthly} onChange={(e) => setPriceMonthly(e.target.value)} required />
        </div>
        <div>
          <Label>Prix annuel (EUR)</Label>
          <Input type="number" step="0.01" value={priceYearly} onChange={(e) => setPriceYearly(e.target.value)} required />
        </div>
      </div>
      <div>
        <Label>Fonctionnalités (une par ligne)</Label>
        <Textarea value={features} onChange={(e) => setFeatures(e.target.value)} rows={4} />
      </div>
      <div className="flex items-center gap-2">
        <Switch checked={isActive} onCheckedChange={setIsActive} />
        <Label>Plan actif</Label>
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Annuler</Button>
        <Button type="submit">Enregistrer</Button>
      </DialogFooter>
    </form>
  );
};

const CreateSubscriptionForm: React.FC<{
  creator: CreatorWithSubscription;
  plans: SubscriptionPlan[];
  onSave: (creatorId: string, planId: string, months: number) => void;
  onCancel: () => void;
}> = ({ creator, plans, onSave, onCancel }) => {
  const [planId, setPlanId] = useState(plans[0]?.id || '');
  const [months, setMonths] = useState('1');

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
        <Avatar>
          <AvatarImage src={creator.avatar_url || ''} />
          <AvatarFallback>{creator.display_name[0]}</AvatarFallback>
        </Avatar>
        <div>
          <div className="flex items-center gap-1">
            <p className="font-medium">{creator.display_name}</p>
            <VerificationBadge isVerified={creator.is_verified || false} size="sm" />
          </div>
          <p className="text-sm text-gray-500">@{creator.username}</p>
        </div>
      </div>
      <div>
        <Label>Plan</Label>
        <Select value={planId} onValueChange={setPlanId}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {plans.map((plan) => (
              <SelectItem key={plan.id} value={plan.id}>
                {plan.name} - {subscriptionService.formatPrice(plan.price_monthly)}/mois
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Durée (mois)</Label>
        <Select value={months} onValueChange={setMonths}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1 mois</SelectItem>
            <SelectItem value="3">3 mois</SelectItem>
            <SelectItem value="6">6 mois</SelectItem>
            <SelectItem value="12">12 mois (1 an)</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>Annuler</Button>
        <Button onClick={() => onSave(creator.id, planId, parseInt(months))}>Créer l'abonnement</Button>
      </DialogFooter>
    </div>
  );
};

const SupportRequestDetail: React.FC<{
  request: SupportRequest;
  onUpdate: (id: string, updates: Partial<SupportRequest>) => void;
  onClose: () => void;
}> = ({ request, onUpdate, onClose }) => {
  const [status, setStatus] = useState(request.status);
  const [priority, setPriority] = useState(request.priority);
  const [adminNotes, setAdminNotes] = useState(request.admin_notes || '');

  return (
    <div className="space-y-4">
      <div className="p-3 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-3 mb-2">
          <Avatar>
            <AvatarImage src={request.creator?.avatar_url || ''} />
            <AvatarFallback>{request.creator?.display_name?.[0] || '?'}</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">{request.creator?.display_name}</p>
            <p className="text-sm text-gray-500">{new Date(request.created_at).toLocaleString('fr-FR')}</p>
          </div>
        </div>
        <h4 className="font-medium mt-3">{request.subject}</h4>
        <p className="text-gray-600 mt-1">{request.message}</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Statut</Label>
          <Select value={status} onValueChange={(v: any) => setStatus(v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="open">Ouverte</SelectItem>
              <SelectItem value="in_progress">En cours</SelectItem>
              <SelectItem value="resolved">Résolue</SelectItem>
              <SelectItem value="closed">Fermée</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Priorité</Label>
          <Select value={priority} onValueChange={(v: any) => setPriority(v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Basse</SelectItem>
              <SelectItem value="normal">Normale</SelectItem>
              <SelectItem value="high">Haute</SelectItem>
              <SelectItem value="urgent">Urgente</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label>Notes administrateur</Label>
        <Textarea value={adminNotes} onChange={(e) => setAdminNotes(e.target.value)}
          placeholder="Ajouter des notes internes..." rows={3} />
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onClose}>Fermer</Button>
        <Button onClick={() => onUpdate(request.id, { status, priority, admin_notes: adminNotes })}>
          Mettre à jour
        </Button>
      </DialogFooter>
    </div>
  );
};

const VerificationRequestDetail: React.FC<{
  request: VerificationRequest;
  rejectionReason: string;
  setRejectionReason: (reason: string) => void;
  onApprove: () => void;
  onReject: () => void;
  onClose: () => void;
}> = ({ request, rejectionReason, setRejectionReason, onApprove, onReject, onClose }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
        <Avatar className="w-16 h-16">
          <AvatarImage src={request.creator_profiles?.avatar_url || ''} />
          <AvatarFallback className="text-xl">{request.creator_profiles?.display_name?.[0] || '?'}</AvatarFallback>
        </Avatar>
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-semibold">{request.creator_profiles?.display_name}</h3>
            <VerificationStatus status={request.status} />
          </div>
          <p className="text-gray-500">Soumis le {new Date(request.submitted_at).toLocaleString('fr-FR')}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-gray-500">Nom légal complet</Label>
          <p className="font-medium">{request.full_legal_name}</p>
        </div>
        <div>
          <Label className="text-gray-500">Date de naissance</Label>
          <p className="font-medium">{new Date(request.date_of_birth).toLocaleDateString('fr-FR')}</p>
        </div>
        <div>
          <Label className="text-gray-500">Pays</Label>
          <p className="font-medium">{request.country}</p>
        </div>
        <div>
          <Label className="text-gray-500">Type de document</Label>
          <p className="font-medium capitalize">
            {request.document_type === 'passport' ? 'Passeport' :
             request.document_type === 'national_id' ? "Carte d'identité" : 'Permis de conduire'}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="font-semibold flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Documents soumis
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border rounded-lg p-3">
            <Label className="text-gray-500 mb-2 block">Recto du document</Label>
            <a href={request.document_front_url} target="_blank" rel="noopener noreferrer" className="block">
              <img src={request.document_front_url} alt="Document front"
                className="w-full h-40 object-cover rounded border hover:opacity-80 transition-opacity" />
              <div className="flex items-center gap-1 text-sm text-blue-600 mt-2">
                <ExternalLink className="w-4 h-4" />
                Ouvrir en grand
              </div>
            </a>
          </div>
          {request.document_back_url && (
            <div className="border rounded-lg p-3">
              <Label className="text-gray-500 mb-2 block">Verso du document</Label>
              <a href={request.document_back_url} target="_blank" rel="noopener noreferrer" className="block">
                <img src={request.document_back_url} alt="Document back"
                  className="w-full h-40 object-cover rounded border hover:opacity-80 transition-opacity" />
                <div className="flex items-center gap-1 text-sm text-blue-600 mt-2">
                  <ExternalLink className="w-4 h-4" />
                  Ouvrir en grand
                </div>
              </a>
            </div>
          )}
        </div>
        <div className="border rounded-lg p-3">
          <Label className="text-gray-500 mb-2 flex items-center gap-2">
            <Camera className="w-4 h-4" />
            Selfie avec document
          </Label>
          <a href={request.selfie_url} target="_blank" rel="noopener noreferrer" className="block">
            <img src={request.selfie_url} alt="Selfie with document"
              className="w-full max-w-md h-48 object-cover rounded border hover:opacity-80 transition-opacity" />
            <div className="flex items-center gap-1 text-sm text-blue-600 mt-2">
              <ExternalLink className="w-4 h-4" />
              Ouvrir en grand
            </div>
          </a>
        </div>
      </div>

      {request.additional_notes && (
        <div>
          <Label className="text-gray-500">Notes additionnelles</Label>
          <p className="mt-1 p-3 bg-gray-50 rounded-lg text-sm">{request.additional_notes}</p>
        </div>
      )}

      {request.status === 'rejected' && request.rejection_reason && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Raison du rejet:</strong> {request.rejection_reason}
          </AlertDescription>
        </Alert>
      )}

      {request.reviewed_at && (
        <p className="text-sm text-gray-500">
          Examiné le {new Date(request.reviewed_at).toLocaleString('fr-FR')}
        </p>
      )}

      {request.status === 'pending' && (
        <div className="space-y-4 pt-4 border-t">
          <div>
            <Label>Raison du rejet (si applicable)</Label>
            <Textarea value={rejectionReason} onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Expliquez pourquoi la demande est rejetée..." rows={3} />
          </div>
          <DialogFooter className="flex gap-2">
            <Button variant="outline" onClick={onClose}>Fermer</Button>
            <Button variant="destructive" onClick={onReject} disabled={!rejectionReason.trim()}>
              <XCircle className="w-4 h-4 mr-2" />
              Rejeter
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={onApprove}>
              <CheckCircle className="w-4 h-4 mr-2" />
              Approuver
            </Button>
          </DialogFooter>
        </div>
      )}

      {request.status !== 'pending' && (
        <DialogFooter>
          <Button onClick={onClose}>Fermer</Button>
        </DialogFooter>
      )}
    </div>
  );
};

export default AdminDashboard;
