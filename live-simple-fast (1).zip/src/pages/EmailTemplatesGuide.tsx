import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getEmailTemplatesUrl, getAuthSettingsUrl, getProjectRef } from '@/lib/supabase';
import {
  Mail, ExternalLink, Copy, CheckCircle, ChevronDown, ChevronUp,
  ArrowLeft, ArrowRight, Settings, Shield, Code, FileText,
  Key, Wand2, Lock, Send, Palette, Globe, AlertTriangle, Info,
} from 'lucide-react';

// ============================================================================
// FRENCH EMAIL TEMPLATES
// ============================================================================

const CONFIRMATION_TEMPLATE = `<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body { margin: 0; padding: 0; background-color: #f4f4f7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
    .card { background: #ffffff; border-radius: 12px; padding: 40px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .logo { text-align: center; margin-bottom: 32px; }
    .logo-text { font-size: 28px; font-weight: 700; color: #7c3aed; }
    h1 { color: #1a1a2e; font-size: 22px; margin: 0 0 16px 0; text-align: center; }
    p { color: #4a4a68; font-size: 15px; line-height: 1.6; margin: 0 0 16px 0; }
    .btn { display: inline-block; background: linear-gradient(135deg, #7c3aed, #6d28d9); color: #ffffff !important; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-size: 16px; font-weight: 600; margin: 24px 0; }
    .btn:hover { background: linear-gradient(135deg, #6d28d9, #5b21b6); }
    .footer { text-align: center; margin-top: 32px; color: #9ca3af; font-size: 12px; line-height: 1.5; }
    .divider { border: none; border-top: 1px solid #e5e7eb; margin: 24px 0; }
    .note { background: #f8f7ff; border-left: 3px solid #7c3aed; padding: 12px 16px; border-radius: 0 8px 8px 0; margin: 16px 0; }
    .note p { color: #6d28d9; font-size: 13px; margin: 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="logo">
        <span class="logo-text">Famous.ai</span>
      </div>
      <h1>Confirmez votre adresse email</h1>
      <p>Bonjour,</p>
      <p>Merci de vous \u00eatre inscrit sur <strong>Famous.ai</strong> ! Pour activer votre compte et commencer \u00e0 utiliser la plateforme, veuillez confirmer votre adresse email en cliquant sur le bouton ci-dessous :</p>
      <div style="text-align: center;">
        <a href="{{ .ConfirmationURL }}" class="btn">Confirmer mon email</a>
      </div>
      <div class="note">
        <p>Ce lien est valide pendant 24 heures. Si vous n'avez pas cr\u00e9\u00e9 de compte, vous pouvez ignorer cet email.</p>
      </div>
      <hr class="divider" />
      <p style="font-size: 13px; color: #9ca3af;">Si le bouton ne fonctionne pas, copiez et collez ce lien dans votre navigateur :</p>
      <p style="font-size: 12px; color: #7c3aed; word-break: break-all;">{{ .ConfirmationURL }}</p>
    </div>
    <div class="footer">
      <p>&copy; {{ .SiteURL }} — Famous.ai</p>
      <p>Cet email a \u00e9t\u00e9 envoy\u00e9 automatiquement. Merci de ne pas y r\u00e9pondre.</p>
    </div>
  </div>
</body>
</html>`;

const PASSWORD_RESET_TEMPLATE = `<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body { margin: 0; padding: 0; background-color: #f4f4f7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
    .card { background: #ffffff; border-radius: 12px; padding: 40px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .logo { text-align: center; margin-bottom: 32px; }
    .logo-text { font-size: 28px; font-weight: 700; color: #7c3aed; }
    h1 { color: #1a1a2e; font-size: 22px; margin: 0 0 16px 0; text-align: center; }
    p { color: #4a4a68; font-size: 15px; line-height: 1.6; margin: 0 0 16px 0; }
    .btn { display: inline-block; background: linear-gradient(135deg, #dc2626, #b91c1c); color: #ffffff !important; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-size: 16px; font-weight: 600; margin: 24px 0; }
    .footer { text-align: center; margin-top: 32px; color: #9ca3af; font-size: 12px; line-height: 1.5; }
    .divider { border: none; border-top: 1px solid #e5e7eb; margin: 24px 0; }
    .warning { background: #fef3f2; border-left: 3px solid #dc2626; padding: 12px 16px; border-radius: 0 8px 8px 0; margin: 16px 0; }
    .warning p { color: #991b1b; font-size: 13px; margin: 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="logo">
        <span class="logo-text">Famous.ai</span>
      </div>
      <h1>R\u00e9initialisation de votre mot de passe</h1>
      <p>Bonjour,</p>
      <p>Nous avons re\u00e7u une demande de r\u00e9initialisation du mot de passe associ\u00e9 \u00e0 votre compte <strong>Famous.ai</strong>. Cliquez sur le bouton ci-dessous pour choisir un nouveau mot de passe :</p>
      <div style="text-align: center;">
        <a href="{{ .ConfirmationURL }}" class="btn">R\u00e9initialiser mon mot de passe</a>
      </div>
      <div class="warning">
        <p>Si vous n'avez pas demand\u00e9 cette r\u00e9initialisation, ignorez cet email. Votre mot de passe actuel restera inchang\u00e9.</p>
      </div>
      <hr class="divider" />
      <p style="font-size: 13px; color: #9ca3af;">Ce lien expire dans 1 heure. Si le bouton ne fonctionne pas, copiez ce lien :</p>
      <p style="font-size: 12px; color: #dc2626; word-break: break-all;">{{ .ConfirmationURL }}</p>
    </div>
    <div class="footer">
      <p>&copy; {{ .SiteURL }} — Famous.ai</p>
      <p>Cet email a \u00e9t\u00e9 envoy\u00e9 automatiquement suite \u00e0 une demande de r\u00e9initialisation.</p>
    </div>
  </div>
</body>
</html>`;

const MAGIC_LINK_TEMPLATE = `<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body { margin: 0; padding: 0; background-color: #f4f4f7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
    .card { background: #ffffff; border-radius: 12px; padding: 40px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .logo { text-align: center; margin-bottom: 32px; }
    .logo-text { font-size: 28px; font-weight: 700; color: #7c3aed; }
    h1 { color: #1a1a2e; font-size: 22px; margin: 0 0 16px 0; text-align: center; }
    p { color: #4a4a68; font-size: 15px; line-height: 1.6; margin: 0 0 16px 0; }
    .btn { display: inline-block; background: linear-gradient(135deg, #7c3aed, #2563eb); color: #ffffff !important; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-size: 16px; font-weight: 600; margin: 24px 0; }
    .footer { text-align: center; margin-top: 32px; color: #9ca3af; font-size: 12px; line-height: 1.5; }
    .divider { border: none; border-top: 1px solid #e5e7eb; margin: 24px 0; }
    .note { background: #eff6ff; border-left: 3px solid #2563eb; padding: 12px 16px; border-radius: 0 8px 8px 0; margin: 16px 0; }
    .note p { color: #1e40af; font-size: 13px; margin: 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="logo">
        <span class="logo-text">Famous.ai</span>
      </div>
      <h1>Votre lien de connexion</h1>
      <p>Bonjour,</p>
      <p>Vous avez demand\u00e9 un lien de connexion pour acc\u00e9der \u00e0 votre compte <strong>Famous.ai</strong>. Cliquez sur le bouton ci-dessous pour vous connecter instantan\u00e9ment :</p>
      <div style="text-align: center;">
        <a href="{{ .ConfirmationURL }}" class="btn">Se connecter maintenant</a>
      </div>
      <div class="note">
        <p>Ce lien est \u00e0 usage unique et expire dans 1 heure. Ne le partagez avec personne.</p>
      </div>
      <hr class="divider" />
      <p style="font-size: 13px; color: #9ca3af;">Si le bouton ne fonctionne pas, copiez ce lien :</p>
      <p style="font-size: 12px; color: #2563eb; word-break: break-all;">{{ .ConfirmationURL }}</p>
    </div>
    <div class="footer">
      <p>&copy; {{ .SiteURL }} — Famous.ai</p>
      <p>Si vous n'avez pas demand\u00e9 ce lien, vous pouvez ignorer cet email en toute s\u00e9curit\u00e9.</p>
    </div>
  </div>
</body>
</html>`;

const INVITE_TEMPLATE = `<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body { margin: 0; padding: 0; background-color: #f4f4f7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
    .card { background: #ffffff; border-radius: 12px; padding: 40px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .logo { text-align: center; margin-bottom: 32px; }
    .logo-text { font-size: 28px; font-weight: 700; color: #7c3aed; }
    h1 { color: #1a1a2e; font-size: 22px; margin: 0 0 16px 0; text-align: center; }
    p { color: #4a4a68; font-size: 15px; line-height: 1.6; margin: 0 0 16px 0; }
    .btn { display: inline-block; background: linear-gradient(135deg, #059669, #047857); color: #ffffff !important; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-size: 16px; font-weight: 600; margin: 24px 0; }
    .footer { text-align: center; margin-top: 32px; color: #9ca3af; font-size: 12px; line-height: 1.5; }
    .divider { border: none; border-top: 1px solid #e5e7eb; margin: 24px 0; }
    .highlight { background: #f0fdf4; border-left: 3px solid #059669; padding: 12px 16px; border-radius: 0 8px 8px 0; margin: 16px 0; }
    .highlight p { color: #065f46; font-size: 13px; margin: 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="logo">
        <span class="logo-text">Famous.ai</span>
      </div>
      <h1>Vous \u00eates invit\u00e9 !</h1>
      <p>Bonjour,</p>
      <p>Vous avez \u00e9t\u00e9 invit\u00e9 \u00e0 rejoindre <strong>Famous.ai</strong>. Cliquez sur le bouton ci-dessous pour accepter l'invitation et cr\u00e9er votre compte :</p>
      <div style="text-align: center;">
        <a href="{{ .ConfirmationURL }}" class="btn">Accepter l'invitation</a>
      </div>
      <div class="highlight">
        <p>Cette invitation est valide pendant 7 jours.</p>
      </div>
      <hr class="divider" />
      <p style="font-size: 13px; color: #9ca3af;">Si le bouton ne fonctionne pas, copiez ce lien :</p>
      <p style="font-size: 12px; color: #059669; word-break: break-all;">{{ .ConfirmationURL }}</p>
    </div>
    <div class="footer">
      <p>&copy; {{ .SiteURL }} — Famous.ai</p>
      <p>Si vous n'attendiez pas cette invitation, vous pouvez ignorer cet email.</p>
    </div>
  </div>
</body>
</html>`;

// ============================================================================
// TEMPLATE DATA
// ============================================================================

interface TemplateInfo {
  id: string;
  title: string;
  description: string;
  supabaseField: string;
  subjectFr: string;
  icon: React.ElementType;
  iconColor: string;
  bgColor: string;
  borderColor: string;
  template: string;
  variables: string[];
}

const TEMPLATES: TemplateInfo[] = [
  {
    id: 'confirmation',
    title: 'Email de confirmation',
    description: "Envoyé lorsqu'un utilisateur s'inscrit pour confirmer son adresse email.",
    supabaseField: 'Confirm signup',
    subjectFr: 'Confirmez votre adresse email — Famous.ai',
    icon: CheckCircle,
    iconColor: 'text-green-400',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/30',
    template: CONFIRMATION_TEMPLATE,
    variables: ['{{ .ConfirmationURL }}', '{{ .SiteURL }}', '{{ .Email }}'],
  },
  {
    id: 'reset',
    title: 'Réinitialisation du mot de passe',
    description: "Envoyé lorsqu'un utilisateur demande à réinitialiser son mot de passe.",
    supabaseField: 'Reset password',
    subjectFr: 'Réinitialisez votre mot de passe — Famous.ai',
    icon: Key,
    iconColor: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
    template: PASSWORD_RESET_TEMPLATE,
    variables: ['{{ .ConfirmationURL }}', '{{ .SiteURL }}', '{{ .Email }}'],
  },
  {
    id: 'magic_link',
    title: 'Lien magique (Magic Link)',
    description: "Envoyé lorsqu'un utilisateur demande une connexion sans mot de passe.",
    supabaseField: 'Magic link',
    subjectFr: 'Votre lien de connexion — Famous.ai',
    icon: Wand2,
    iconColor: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/30',
    template: MAGIC_LINK_TEMPLATE,
    variables: ['{{ .ConfirmationURL }}', '{{ .SiteURL }}', '{{ .Email }}'],
  },
  {
    id: 'invite',
    title: "Email d'invitation",
    description: "Envoyé lorsqu'un administrateur invite un utilisateur à rejoindre la plateforme.",
    supabaseField: 'Invite user',
    subjectFr: 'Vous êtes invité à rejoindre Famous.ai',
    icon: Send,
    iconColor: 'text-emerald-400',
    bgColor: 'bg-emerald-500/10',
    borderColor: 'border-emerald-500/30',
    template: INVITE_TEMPLATE,
    variables: ['{{ .ConfirmationURL }}', '{{ .SiteURL }}', '{{ .Email }}'],
  },
];

// ============================================================================
// COPY BUTTON COMPONENT
// ============================================================================

const CopyButton: React.FC<{ text: string; label?: string; className?: string }> = ({ text, label = 'Copier', className = '' }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <button
      onClick={handleCopy}
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
        copied
          ? 'bg-green-500/20 text-green-400 border border-green-500/30'
          : 'bg-gray-700 hover:bg-gray-600 text-gray-300 border border-gray-600'
      } ${className}`}
    >
      {copied ? (
        <>
          <CheckCircle className="w-3.5 h-3.5" />
          Copié !
        </>
      ) : (
        <>
          <Copy className="w-3.5 h-3.5" />
          {label}
        </>
      )}
    </button>
  );
};

// ============================================================================
// TEMPLATE CARD COMPONENT
// ============================================================================

const TemplateCard: React.FC<{ template: TemplateInfo }> = ({ template }) => {
  const [expanded, setExpanded] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const Icon = template.icon;

  return (
    <div className={`rounded-xl border ${template.borderColor} bg-gray-900/60 overflow-hidden transition-all`}>
      {/* Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full px-5 py-4 flex items-center gap-4 hover:bg-gray-800/40 transition-colors text-left"
      >
        <div className={`w-10 h-10 rounded-xl ${template.bgColor} flex items-center justify-center flex-shrink-0`}>
          <Icon className={`w-5 h-5 ${template.iconColor}`} />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-white font-semibold text-sm">{template.title}</h3>
          <p className="text-gray-400 text-xs mt-0.5">{template.description}</p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <span className="hidden sm:inline-block text-gray-500 text-xs font-mono bg-gray-800 px-2 py-1 rounded">
            {template.supabaseField}
          </span>
          {expanded ? (
            <ChevronUp className="w-4 h-4 text-gray-500" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-500" />
          )}
        </div>
      </button>

      {/* Expanded content */}
      {expanded && (
        <div className="border-t border-gray-800 px-5 py-5 space-y-5">
          {/* Subject line */}
          <div>
            <label className="text-gray-400 text-xs font-medium uppercase tracking-wider mb-2 block">
              Objet de l'email (Subject)
            </label>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-gray-800/80 rounded-lg px-4 py-2.5 border border-gray-700">
                <code className="text-amber-300 text-sm">{template.subjectFr}</code>
              </div>
              <CopyButton text={template.subjectFr} label="Copier" />
            </div>
          </div>

          {/* Supabase field name */}
          <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-3 flex items-start gap-2">
            <Info className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
            <p className="text-blue-300/80 text-xs leading-relaxed">
              Dans le Dashboard Supabase, ce template correspond au champ{' '}
              <span className="font-mono font-semibold text-blue-300 bg-blue-500/10 px-1.5 py-0.5 rounded">
                {template.supabaseField}
              </span>
              . Collez le sujet dans le champ <span className="font-semibold text-blue-300">"Subject"</span> et le HTML dans le champ <span className="font-semibold text-blue-300">"Body"</span>.
            </p>
          </div>

          {/* Template variables */}
          <div>
            <label className="text-gray-400 text-xs font-medium uppercase tracking-wider mb-2 block">
              Variables disponibles
            </label>
            <div className="flex flex-wrap gap-2">
              {template.variables.map((v) => (
                <span
                  key={v}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-mono"
                >
                  <Code className="w-3 h-3" />
                  {v}
                </span>
              ))}
            </div>
          </div>

          {/* Template code */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-gray-400 text-xs font-medium uppercase tracking-wider">
                Template HTML
              </label>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowPreview(!showPreview)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    showPreview
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                      : 'bg-gray-700 hover:bg-gray-600 text-gray-400 border border-gray-600'
                  }`}
                >
                  <Palette className="w-3.5 h-3.5" />
                  {showPreview ? 'Code' : 'Aperçu'}
                </button>
                <CopyButton text={template.template} label="Copier le HTML" />
              </div>
            </div>

            {showPreview ? (
              <div className="rounded-xl border border-gray-700 overflow-hidden bg-white">
                <div className="p-1 bg-gray-800 flex items-center gap-2 px-3">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
                  </div>
                  <span className="text-gray-500 text-[10px] font-mono ml-2">Aperçu email</span>
                </div>
                <iframe
                  srcDoc={template.template}
                  className="w-full h-[500px] border-0"
                  title={`Aperçu - ${template.title}`}
                  sandbox="allow-same-origin"
                />
              </div>
            ) : (
              <div className="relative">
                <pre className="bg-gray-950 rounded-xl border border-gray-800 p-4 overflow-x-auto max-h-[400px] overflow-y-auto">
                  <code className="text-gray-300 text-xs leading-relaxed whitespace-pre-wrap break-words">
                    {template.template}
                  </code>
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// MAIN PAGE COMPONENT
// ============================================================================

const EmailTemplatesGuide: React.FC = () => {
  const navigate = useNavigate();
  const emailTemplatesUrl = getEmailTemplatesUrl();
  const authSettingsUrl = getAuthSettingsUrl();
  const projectRef = getProjectRef();
  const [showSmtpGuide, setShowSmtpGuide] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/30 to-slate-900">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 py-8 sm:py-12">
        {/* Back navigation */}
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-8 group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm">Retour</span>
        </button>

        {/* Page header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-600 shadow-lg shadow-purple-500/30 mb-5">
            <Mail className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Configuration des emails
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto leading-relaxed">
            Personnalisez les templates d'emails envoyés par Supabase : confirmation, réinitialisation de mot de passe, lien magique et invitations.
          </p>
        </div>

        {/* ==================== SECTION 1: How to access ==================== */}
        <section className="mb-10">
          <div className="bg-gray-900/80 backdrop-blur-xl rounded-2xl border border-gray-800 overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-800 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                <Settings className="w-4 h-4 text-purple-400" />
              </div>
              <div>
                <h2 className="text-white font-semibold text-lg">Accéder aux templates</h2>
                <p className="text-gray-500 text-sm">Comment trouver la page de configuration dans Supabase</p>
              </div>
            </div>

            <div className="p-6 space-y-5">
              {/* Step-by-step navigation */}
              <div className="space-y-3">
                {[
                  {
                    step: 1,
                    title: 'Ouvrez le Dashboard Supabase',
                    desc: (
                      <>
                        Connectez-vous à{' '}
                        <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 underline">
                          supabase.com/dashboard
                        </a>
                        {' '}et sélectionnez votre projet.
                      </>
                    ),
                  },
                  {
                    step: 2,
                    title: 'Naviguez vers Authentication',
                    desc: (
                      <>
                        Dans le menu latéral gauche, cliquez sur{' '}
                        <span className="font-mono text-purple-300 bg-purple-500/10 px-1.5 py-0.5 rounded">Authentication</span>.
                      </>
                    ),
                  },
                  {
                    step: 3,
                    title: 'Ouvrez Email Templates',
                    desc: (
                      <>
                        Cliquez sur l'onglet{' '}
                        <span className="font-mono text-purple-300 bg-purple-500/10 px-1.5 py-0.5 rounded">Email Templates</span>
                        {' '}dans le sous-menu.
                      </>
                    ),
                  },
                  {
                    step: 4,
                    title: 'Modifiez chaque template',
                    desc: 'Vous verrez une liste de templates. Cliquez sur chacun pour modifier le sujet (Subject) et le corps HTML (Body).',
                  },
                ].map((item) => (
                  <div key={item.step} className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-purple-400 text-xs font-bold">{item.step}</span>
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{item.title}</p>
                      <p className="text-gray-400 text-xs mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Direct link */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <a
                  href={emailTemplatesUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white text-sm font-semibold transition-all shadow-lg shadow-purple-500/20"
                >
                  <ExternalLink className="w-4 h-4" />
                  Ouvrir Email Templates
                </a>
                {projectRef && (
                  <CopyButton
                    text={emailTemplatesUrl}
                    label="Copier le lien"
                    className="justify-center py-3"
                  />
                )}
              </div>

              {projectRef && (
                <div className="bg-gray-800/50 rounded-lg p-2.5 flex items-center gap-2 overflow-hidden">
                  <Globe className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
                  <code className="text-gray-400 text-[11px] font-mono truncate">
                    {emailTemplatesUrl}
                  </code>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* ==================== SECTION 2: Sender name / SMTP ==================== */}
        <section className="mb-10">
          <div className="bg-gray-900/80 backdrop-blur-xl rounded-2xl border border-gray-800 overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-800 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center">
                <Send className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <h2 className="text-white font-semibold text-lg">Nom d'expéditeur et SMTP</h2>
                <p className="text-gray-500 text-sm">Personnalisez le nom et l'adresse de l'expéditeur</p>
              </div>
            </div>

            <div className="p-6 space-y-5">
              <p className="text-gray-300 text-sm leading-relaxed">
                Par défaut, Supabase envoie les emails depuis <span className="font-mono text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded">noreply@mail.app.supabase.io</span>. 
                Pour personnaliser le nom d'expéditeur et utiliser votre propre domaine, vous devez configurer un serveur SMTP personnalisé.
              </p>

              {/* Sender name configuration */}
              <div className="bg-gray-800/50 rounded-xl p-4 space-y-3 border border-gray-700/50">
                <h3 className="text-white font-medium text-sm flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-400" />
                  Modifier le nom d'expéditeur
                </h3>
                <div className="space-y-2">
                  {[
                    {
                      step: 1,
                      text: (
                        <>
                          Allez dans{' '}
                          <span className="font-mono text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded">
                            Project Settings
                          </span>
                          <ArrowRight className="w-3 h-3 inline mx-1 text-gray-500" />
                          <span className="font-mono text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded">
                            Authentication
                          </span>
                        </>
                      ),
                    },
                    {
                      step: 2,
                      text: (
                        <>
                          Faites défiler jusqu'à la section{' '}
                          <span className="font-mono text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded">
                            SMTP Settings
                          </span>
                        </>
                      ),
                    },
                    {
                      step: 3,
                      text: (
                        <>
                          Activez <span className="font-semibold text-amber-300">"Enable Custom SMTP"</span> et remplissez les champs :
                        </>
                      ),
                    },
                  ].map((item) => (
                    <div key={item.step} className="flex items-start gap-2 pl-1">
                      <div className="w-5 h-5 rounded-full bg-amber-500/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-amber-400 text-[10px] font-bold">{item.step}</span>
                      </div>
                      <p className="text-gray-400 text-xs leading-relaxed">{item.text}</p>
                    </div>
                  ))}
                </div>

                {/* SMTP fields example */}
                <div className="bg-gray-900/60 rounded-lg p-3 space-y-2 border border-gray-700/30">
                  {[
                    { label: 'Sender name', value: 'Famous.ai', hint: "Le nom qui apparaît dans la boîte de réception" },
                    { label: 'Sender email', value: 'noreply@votredomaine.com', hint: "L'adresse email de l'expéditeur" },
                    { label: 'Host', value: 'smtp.votrefournisseur.com', hint: 'Serveur SMTP (ex: smtp.resend.com, smtp.sendgrid.net)' },
                    { label: 'Port', value: '587', hint: 'Port SMTP (587 pour TLS, 465 pour SSL)' },
                    { label: 'Username', value: 'apikey', hint: "Nom d'utilisateur SMTP" },
                    { label: 'Password', value: 're_xxxxxxxx...', hint: 'Clé API ou mot de passe SMTP' },
                  ].map((field) => (
                    <div key={field.label} className="flex items-center gap-3">
                      <span className="text-gray-500 text-xs font-mono w-28 flex-shrink-0">{field.label}</span>
                      <code className="text-amber-300/80 text-xs flex-1">{field.value}</code>
                      <span className="text-gray-600 text-[10px] hidden lg:inline">{field.hint}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended SMTP providers */}
              <button
                onClick={() => setShowSmtpGuide(!showSmtpGuide)}
                className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 text-sm font-medium transition-colors"
              >
                {showSmtpGuide ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                Fournisseurs SMTP recommandés
              </button>

              {showSmtpGuide && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    {
                      name: 'Resend',
                      desc: 'Simple, moderne, gratuit jusqu\'à 3 000 emails/mois',
                      url: 'https://resend.com',
                      color: 'border-blue-500/30 bg-blue-500/5',
                    },
                    {
                      name: 'SendGrid',
                      desc: 'Fiable, gratuit jusqu\'à 100 emails/jour',
                      url: 'https://sendgrid.com',
                      color: 'border-cyan-500/30 bg-cyan-500/5',
                    },
                    {
                      name: 'Mailgun',
                      desc: 'Puissant, 5 000 emails gratuits pendant 3 mois',
                      url: 'https://mailgun.com',
                      color: 'border-red-500/30 bg-red-500/5',
                    },
                  ].map((provider) => (
                    <a
                      key={provider.name}
                      href={provider.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`rounded-xl border p-4 ${provider.color} hover:bg-gray-800/40 transition-colors block`}
                    >
                      <h4 className="text-white font-semibold text-sm mb-1">{provider.name}</h4>
                      <p className="text-gray-400 text-xs leading-relaxed">{provider.desc}</p>
                      <span className="text-purple-400 text-xs mt-2 inline-flex items-center gap-1">
                        <ExternalLink className="w-3 h-3" />
                        Visiter
                      </span>
                    </a>
                  ))}
                </div>
              )}

              {/* Direct link to auth settings */}
              <a
                href={authSettingsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/30 text-amber-300 text-sm font-medium transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                Ouvrir Project Settings &gt; Auth
              </a>
            </div>
          </div>
        </section>

        {/* ==================== SECTION 3: Templates ==================== */}
        <section className="mb-10">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Code className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-white font-semibold text-lg">Templates HTML en français</h2>
              <p className="text-gray-500 text-sm">Copiez-collez ces templates dans votre Dashboard Supabase</p>
            </div>
          </div>

          {/* How to use hint */}
          <div className="bg-purple-500/5 border border-purple-500/20 rounded-xl p-4 mb-5 flex items-start gap-3">
            <Info className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
            <div className="text-purple-300/80 text-sm leading-relaxed">
              <p className="font-medium text-purple-300 mb-1">Comment utiliser ces templates :</p>
              <ol className="list-decimal list-inside space-y-1 text-xs">
                <li>Cliquez sur un template ci-dessous pour le développer</li>
                <li>Copiez le <span className="font-semibold text-purple-300">Subject</span> (objet) et collez-le dans le champ "Subject" de Supabase</li>
                <li>Copiez le <span className="font-semibold text-purple-300">HTML</span> et collez-le dans le champ "Body" de Supabase</li>
                <li>Utilisez le bouton <span className="font-semibold text-purple-300">"Aperçu"</span> pour voir le rendu final</li>
                <li>Cliquez sur <span className="font-semibold text-purple-300">"Save"</span> dans Supabase</li>
              </ol>
            </div>
          </div>

          {/* Template cards */}
          <div className="space-y-4">
            {TEMPLATES.map((template) => (
              <TemplateCard key={template.id} template={template} />
            ))}
          </div>
        </section>

        {/* ==================== SECTION 4: Variables reference ==================== */}
        <section className="mb-10">
          <div className="bg-gray-900/80 backdrop-blur-xl rounded-2xl border border-gray-800 overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-800 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center">
                <Code className="w-4 h-4 text-indigo-400" />
              </div>
              <div>
                <h2 className="text-white font-semibold text-lg">Référence des variables</h2>
                <p className="text-gray-500 text-sm">Variables Go Template disponibles dans les emails Supabase</p>
              </div>
            </div>

            <div className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-800">
                      <th className="text-gray-400 text-xs font-medium uppercase tracking-wider pb-3 pr-4">Variable</th>
                      <th className="text-gray-400 text-xs font-medium uppercase tracking-wider pb-3 pr-4">Description</th>
                      <th className="text-gray-400 text-xs font-medium uppercase tracking-wider pb-3">Exemple</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800/50">
                    {[
                      { variable: '{{ .ConfirmationURL }}', desc: "Lien de confirmation/action principal", example: 'https://votreapp.com/auth/confirm?token=...' },
                      { variable: '{{ .SiteURL }}', desc: "URL de votre application (configurée dans Auth Settings)", example: 'https://votreapp.com' },
                      { variable: '{{ .Email }}', desc: "Adresse email de l'utilisateur", example: 'utilisateur@email.com' },
                      { variable: '{{ .Token }}', desc: "Token brut (pour les OTP)", example: 'abc123def456' },
                      { variable: '{{ .TokenHash }}', desc: "Hash du token", example: 'pkce_...' },
                      { variable: '{{ .Data }}', desc: "Métadonnées utilisateur (user_metadata)", example: '{ "name": "Jean" }' },
                    ].map((row) => (
                      <tr key={row.variable}>
                        <td className="py-3 pr-4">
                          <code className="text-purple-300 text-xs font-mono bg-purple-500/10 px-2 py-1 rounded">
                            {row.variable}
                          </code>
                        </td>
                        <td className="py-3 pr-4">
                          <span className="text-gray-300 text-xs">{row.desc}</span>
                        </td>
                        <td className="py-3">
                          <code className="text-gray-500 text-[11px] font-mono">{row.example}</code>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>

        {/* ==================== SECTION 5: Security tips ==================== */}
        <section className="mb-10">
          <div className="bg-gray-900/80 backdrop-blur-xl rounded-2xl border border-amber-500/20 overflow-hidden">
            <div className="px-6 py-5 border-b border-amber-500/10 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center">
                <Shield className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <h2 className="text-white font-semibold text-lg">Bonnes pratiques de sécurité</h2>
                <p className="text-gray-500 text-sm">Recommandations pour vos emails d'authentification</p>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  {
                    icon: Lock,
                    title: 'Gardez la confirmation email activée',
                    desc: "En production, ne désactivez jamais la confirmation email. C'est une protection essentielle contre les comptes frauduleux.",
                    color: 'text-green-400',
                    bg: 'bg-green-500/10',
                  },
                  {
                    icon: Shield,
                    title: 'Utilisez un SMTP personnalisé',
                    desc: "Le SMTP par défaut de Supabase a des limites de débit. Un SMTP dédié améliore la délivrabilité.",
                    color: 'text-blue-400',
                    bg: 'bg-blue-500/10',
                  },
                  {
                    icon: Globe,
                    title: 'Configurez le Site URL',
                    desc: "Dans Auth Settings, définissez le Site URL correct pour que les liens de confirmation pointent vers votre domaine.",
                    color: 'text-purple-400',
                    bg: 'bg-purple-500/10',
                  },
                  {
                    icon: AlertTriangle,
                    title: 'Testez vos templates',
                    desc: "Après modification, créez un compte test pour vérifier que les emails arrivent correctement et que les liens fonctionnent.",
                    color: 'text-amber-400',
                    bg: 'bg-amber-500/10',
                  },
                ].map((tip) => (
                  <div key={tip.title} className={`rounded-xl ${tip.bg} p-4 border border-gray-700/30`}>
                    <div className="flex items-center gap-2 mb-2">
                      <tip.icon className={`w-4 h-4 ${tip.color}`} />
                      <h4 className="text-white text-sm font-medium">{tip.title}</h4>
                    </div>
                    <p className="text-gray-400 text-xs leading-relaxed">{tip.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ==================== FOOTER NAVIGATION ==================== */}
        <div className="flex flex-col sm:flex-row gap-3 justify-between items-center pt-4 border-t border-gray-800">
          <button
            onClick={() => navigate('/setup')}
            className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Retour à la configuration
          </button>

          <div className="flex gap-3">
            <a
              href={emailTemplatesUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white text-sm font-medium transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              Email Templates
            </a>
            <a
              href={authSettingsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 text-gray-300 text-sm font-medium transition-colors"
            >
              <Settings className="w-4 h-4" />
              Auth Settings
            </a>
          </div>
        </div>

        {/* Page footer */}
        <div className="text-center mt-8 pb-4">
          <p className="text-gray-600 text-xs">
            Famous.ai — Guide de configuration des emails
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmailTemplatesGuide;
