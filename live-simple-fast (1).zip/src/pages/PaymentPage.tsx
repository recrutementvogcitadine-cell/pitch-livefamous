import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { subscriptionService, SubscriptionPlan } from '@/lib/subscriptionService';
import { paymentService, PaymentProvider, PaymentInfo, PaymentHistoryItem } from '@/lib/paymentService';

// Provider logo components
const OrangeMoneyLogo: React.FC<{ size?: number }> = ({ size = 40 }) => (
  <div style={{ width: size, height: size }} className="rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-500/20">
    <svg width={size * 0.55} height={size * 0.55} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" fill="white" fillOpacity="0.2" />
      <path d="M12 6C8.69 6 6 8.69 6 12s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm0 10.5c-2.49 0-4.5-2.01-4.5-4.5S9.51 7.5 12 7.5s4.5 2.01 4.5 4.5-2.01 4.5-4.5 4.5z" fill="white" />
      <path d="M12 9v6M9 12h6" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  </div>
);

const MTNMoneyLogo: React.FC<{ size?: number }> = ({ size = 40 }) => (
  <div style={{ width: size, height: size }} className="rounded-xl bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center shadow-lg shadow-yellow-500/20">
    <svg width={size * 0.55} height={size * 0.55} viewBox="0 0 24 24" fill="none">
      <path d="M12 3L4 9v12h16V9l-8-6z" fill="white" fillOpacity="0.3" />
      <path d="M12 3L4 9v12h16V9l-8-6z" stroke="white" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M10 21v-6h4v6" stroke="white" strokeWidth="1.5" strokeLinejoin="round" />
      <circle cx="12" cy="13" r="1.5" fill="white" />
    </svg>
  </div>
);

const WaveLogo: React.FC<{ size?: number }> = ({ size = 40 }) => (
  <div style={{ width: size, height: size }} className="rounded-xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center shadow-lg shadow-cyan-500/20">
    <svg width={size * 0.55} height={size * 0.55} viewBox="0 0 24 24" fill="none">
      <path d="M2 12c2-3 4-5 6-5s4 4 6 4 4-4 6-4" stroke="white" strokeWidth="2" strokeLinecap="round" />
      <path d="M2 17c2-3 4-5 6-5s4 4 6 4 4-4 6-4" stroke="white" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.5" />
      <path d="M2 7c2-3 4-5 6-5s4 4 6 4 4-4 6-4" stroke="white" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.5" />
    </svg>
  </div>
);

type Step = 'select_plan' | 'select_provider' | 'enter_phone' | 'confirm' | 'processing' | 'success' | 'history';

const PaymentPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, creatorProfile, isAuthenticated, refreshSubscription } = useAppContext();

  const [step, setStep] = useState<Step>('select_plan');
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedProvider, setSelectedProvider] = useState<PaymentProvider | null>(null);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentPayment, setCurrentPayment] = useState<PaymentInfo | null>(null);
  const [paymentHistory, setPaymentHistory] = useState<PaymentHistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    loadPlans();
    const planId = searchParams.get('plan');
    const cycle = searchParams.get('cycle');
    if (cycle === 'yearly') setBillingCycle('yearly');
    if (planId) {
      // Will be set after plans load
    }
  }, []);

  useEffect(() => {
    const planId = searchParams.get('plan');
    if (planId && plans.length > 0) {
      const plan = plans.find(p => p.id === planId);
      if (plan) {
        setSelectedPlan(plan);
        setStep('select_provider');
      }
    }
  }, [plans, searchParams]);

  const loadPlans = async () => {
    setIsLoading(true);
    try {
      const plansData = await subscriptionService.getPlans();
      setPlans(plansData);
      if (plansData.length > 0 && !selectedPlan) {
        setSelectedPlan(plansData[0]);
      }
    } catch (err) {
      console.error('Error loading plans:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const loadHistory = async () => {
    const result = await paymentService.getPaymentHistory();
    if (result.success && result.payments) {
      setPaymentHistory(result.payments);
    }
  };

  const getPrice = (plan?: SubscriptionPlan | null) => {
    const p = plan || selectedPlan;
    if (!p) return 0;
    return billingCycle === 'monthly' ? p.price_monthly : p.price_yearly;
  };

  const getSavings = (plan?: SubscriptionPlan | null) => {
    const p = plan || selectedPlan;
    if (!p) return 0;
    const monthlyTotal = p.price_monthly * 12;
    const yearlyTotal = p.price_yearly;
    return Math.round(((monthlyTotal - yearlyTotal) / monthlyTotal) * 100);
  };

  const handleSelectPlan = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
    setStep('select_provider');
    setError(null);
  };

  const handleSelectProvider = (provider: PaymentProvider) => {
    setSelectedProvider(provider);
    setStep('enter_phone');
    setError(null);
    setPhoneError(null);
  };

  const handlePhoneSubmit = () => {
    const validation = paymentService.validatePhoneNumber(phoneNumber);
    if (!validation.valid) {
      setPhoneError(validation.error || 'Numéro invalide');
      return;
    }
    setPhoneError(null);
    setStep('confirm');
  };

  const handleInitiatePayment = async () => {
    if (!selectedPlan || !selectedProvider || !phoneNumber || !creatorProfile) return;

    setIsProcessing(true);
    setError(null);

    try {
      const result = await paymentService.initiatePayment(
        selectedPlan.id,
        billingCycle,
        selectedProvider,
        phoneNumber
      );

      if (!result.success) {
        setError(result.error || 'Erreur lors du paiement');
        setIsProcessing(false);
        return;
      }

      setCurrentPayment(result.payment!);
      setStep('processing');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmPayment = async () => {
    if (!currentPayment) return;

    setIsProcessing(true);
    setError(null);

    try {
      const result = await paymentService.confirmPayment(currentPayment.id);

      if (!result.success) {
        setError(result.error || 'Erreur lors de la confirmation');
        setIsProcessing(false);
        return;
      }

      await refreshSubscription();
      setStep('success');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBack = () => {
    setError(null);
    switch (step) {
      case 'select_provider':
        setStep('select_plan');
        break;
      case 'enter_phone':
        setStep('select_provider');
        break;
      case 'confirm':
        setStep('enter_phone');
        break;
      default:
        break;
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="bg-gray-900 rounded-2xl p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-gray-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-white font-bold text-xl mb-2">Connexion requise</h2>
          <p className="text-gray-400 mb-6">Vous devez être connecté pour effectuer un paiement</p>
          <button
            onClick={() => navigate('/')}
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold px-6 py-3 rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all"
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/90 backdrop-blur-xl border-b border-gray-800/50">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => step === 'select_plan' || step === 'success' || step === 'history' ? navigate('/') : handleBack()}
              className="w-10 h-10 rounded-xl bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h1 className="text-white font-bold text-lg">
                {showHistory ? 'Historique des paiements' : 'Paiement Mobile Money'}
              </h1>
              <p className="text-gray-500 text-sm">
                {showHistory ? 'Consultez vos transactions' : 'Abonnement créateur'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (showHistory) {
                setShowHistory(false);
                setStep('select_plan');
              } else {
                setShowHistory(true);
                loadHistory();
              }
            }}
            className="px-4 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 text-sm font-medium transition-colors flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {showHistory ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              )}
            </svg>
            {showHistory ? 'Payer' : 'Historique'}
          </button>
        </div>

        {/* Progress Steps */}
        {!showHistory && step !== 'success' && (
          <div className="max-w-4xl mx-auto px-4 pb-4">
            <div className="flex items-center gap-2">
              {['select_plan', 'select_provider', 'enter_phone', 'confirm'].map((s, i) => {
                const stepIndex = ['select_plan', 'select_provider', 'enter_phone', 'confirm', 'processing'].indexOf(step);
                const thisIndex = i;
                const isActive = thisIndex <= stepIndex;
                const isCurrent = s === step;
                const labels = ['Forfait', 'Opérateur', 'Numéro', 'Confirmer'];

                return (
                  <React.Fragment key={s}>
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        isCurrent
                          ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white ring-4 ring-purple-500/20'
                          : isActive
                          ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40'
                          : 'bg-gray-800 text-gray-600 border border-gray-700'
                      }`}>
                        {isActive && !isCurrent ? (
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        ) : (
                          i + 1
                        )}
                      </div>
                      <span className={`text-xs font-medium hidden sm:block ${isCurrent ? 'text-white' : isActive ? 'text-gray-400' : 'text-gray-600'}`}>
                        {labels[i]}
                      </span>
                    </div>
                    {i < 3 && (
                      <div className={`flex-1 h-0.5 rounded-full ${isActive && thisIndex < stepIndex ? 'bg-purple-500/50' : 'bg-gray-800'}`} />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Payment History */}
        {showHistory && (
          <div className="space-y-4">
            {paymentHistory.length === 0 ? (
              <div className="bg-gray-900 rounded-2xl p-12 text-center">
                <div className="w-16 h-16 bg-gray-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                </div>
                <h3 className="text-white font-bold text-lg mb-2">Aucune transaction</h3>
                <p className="text-gray-400">Vous n'avez pas encore effectué de paiement</p>
              </div>
            ) : (
              paymentHistory.map((payment) => (
                <div key={payment.id} className="bg-gray-900 rounded-xl p-5 border border-gray-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      {payment.provider === 'orange_money' && <OrangeMoneyLogo size={36} />}
                      {payment.provider === 'mtn_money' && <MTNMoneyLogo size={36} />}
                      {payment.provider === 'wave' && <WaveLogo size={36} />}
                      <div>
                        <p className="text-white font-semibold">
                          {payment.provider === 'orange_money' ? 'Orange Money' :
                           payment.provider === 'mtn_money' ? 'MTN Money' : 'Wave'}
                        </p>
                        <p className="text-gray-500 text-xs">{payment.transaction_id}</p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${paymentService.getStatusBgColor(payment.status)} ${paymentService.getStatusColor(payment.status)}`}>
                      {paymentService.getStatusLabel(payment.status)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-gray-400">{payment.phone_number}</span>
                      <span className="text-gray-600">|</span>
                      <span className="text-gray-400">
                        {new Date(payment.created_at).toLocaleDateString('fr-FR', {
                          day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
                        })}
                      </span>
                    </div>
                    <span className="text-white font-bold">
                      {paymentService.formatAmount(payment.amount, payment.currency)}
                    </span>
                  </div>
                  {payment.metadata?.plan_name && (
                    <div className="mt-3 pt-3 border-t border-gray-800">
                      <span className="text-gray-500 text-xs">Plan: {payment.metadata.plan_name} ({payment.metadata.billing_cycle === 'monthly' ? 'Mensuel' : 'Annuel'})</span>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* Step 1: Select Plan */}
        {!showHistory && step === 'select_plan' && (
          <div>
            {/* Billing Toggle */}
            <div className="flex items-center justify-center gap-3 mb-8">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-6 py-2.5 rounded-xl font-medium transition-all ${
                  billingCycle === 'monthly'
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25'
                    : 'bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                Mensuel
              </button>
              <button
                onClick={() => setBillingCycle('yearly')}
                className={`px-6 py-2.5 rounded-xl font-medium transition-all relative ${
                  billingCycle === 'yearly'
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25'
                    : 'bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                Annuel
                <span className="absolute -top-2 -right-3 bg-green-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">
                  -17%
                </span>
              </button>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-16">
                <div className="w-10 h-10 border-3 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {plans.map((plan, index) => {
                  const isPopular = index === 1;
                  return (
                    <div
                      key={plan.id}
                      className={`relative rounded-2xl p-6 transition-all cursor-pointer group hover:scale-[1.02] ${
                        selectedPlan?.id === plan.id
                          ? 'bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-2 border-purple-500 shadow-xl shadow-purple-500/10'
                          : 'bg-gray-900 border-2 border-gray-800 hover:border-gray-600'
                      }`}
                      onClick={() => setSelectedPlan(plan)}
                    >
                      {isPopular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold px-4 py-1 rounded-full">
                          POPULAIRE
                        </div>
                      )}

                      <div className="mb-4">
                        <h3 className="text-white font-bold text-xl mb-1">{plan.name}</h3>
                        <p className="text-gray-400 text-sm">{plan.description}</p>
                      </div>

                      <div className="mb-6">
                        <div className="flex items-baseline gap-1">
                          <span className="text-white font-extrabold text-3xl">
                            {paymentService.formatAmount(getPrice(plan))}
                          </span>
                        </div>
                        <span className="text-gray-500 text-sm">
                          /{billingCycle === 'monthly' ? 'mois' : 'an'}
                        </span>
                        {billingCycle === 'yearly' && (
                          <p className="text-green-400 text-sm mt-1">
                            Soit {paymentService.formatAmount(Math.round(plan.price_yearly / 12))}/mois
                          </p>
                        )}
                      </div>

                      <ul className="space-y-3 mb-6">
                        {plan.features.map((feature, fi) => (
                          <li key={fi} className="flex items-start gap-2.5 text-gray-300 text-sm">
                            <svg className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            {feature}
                          </li>
                        ))}
                      </ul>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectPlan(plan);
                        }}
                        className={`w-full py-3 rounded-xl font-semibold transition-all ${
                          isPopular || selectedPlan?.id === plan.id
                            ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700 shadow-lg shadow-purple-500/25'
                            : 'bg-gray-800 text-white hover:bg-gray-700'
                        }`}
                      >
                        Choisir ce forfait
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Step 2: Select Provider */}
        {!showHistory && step === 'select_provider' && (
          <div className="max-w-lg mx-auto">
            {/* Selected Plan Summary */}
            {selectedPlan && (
              <div className="bg-gray-900 rounded-xl p-4 mb-8 border border-gray-800">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Forfait sélectionné</p>
                    <p className="text-white font-bold">{selectedPlan.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-bold text-lg">{paymentService.formatAmount(getPrice())}</p>
                    <p className="text-gray-500 text-xs">/{billingCycle === 'monthly' ? 'mois' : 'an'}</p>
                  </div>
                </div>
              </div>
            )}

            <h2 className="text-white font-bold text-xl mb-2">Choisissez votre opérateur</h2>
            <p className="text-gray-400 text-sm mb-6">Sélectionnez votre moyen de paiement Mobile Money</p>

            <div className="space-y-4">
              {/* Orange Money */}
              <button
                onClick={() => handleSelectProvider('orange_money')}
                className={`w-full p-5 rounded-2xl border-2 transition-all text-left flex items-center gap-4 group hover:scale-[1.01] ${
                  selectedProvider === 'orange_money'
                    ? 'border-orange-500 bg-orange-500/10'
                    : 'border-gray-800 bg-gray-900 hover:border-orange-500/50 hover:bg-orange-500/5'
                }`}
              >
                <OrangeMoneyLogo size={48} />
                <div className="flex-1">
                  <p className="text-white font-bold text-lg">Orange Money</p>
                  <p className="text-gray-400 text-sm">Payez avec votre compte Orange Money</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">CI</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">SN</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">ML</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">BF</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">CM</span>
                  </div>
                </div>
                <svg className="w-5 h-5 text-gray-600 group-hover:text-orange-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>

              {/* MTN Money */}
              <button
                onClick={() => handleSelectProvider('mtn_money')}
                className={`w-full p-5 rounded-2xl border-2 transition-all text-left flex items-center gap-4 group hover:scale-[1.01] ${
                  selectedProvider === 'mtn_money'
                    ? 'border-yellow-500 bg-yellow-500/10'
                    : 'border-gray-800 bg-gray-900 hover:border-yellow-500/50 hover:bg-yellow-500/5'
                }`}
              >
                <MTNMoneyLogo size={48} />
                <div className="flex-1">
                  <p className="text-white font-bold text-lg">MTN Mobile Money</p>
                  <p className="text-gray-400 text-sm">Payez avec MTN Mobile Money</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">CI</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">CM</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">GH</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">BJ</span>
                  </div>
                </div>
                <svg className="w-5 h-5 text-gray-600 group-hover:text-yellow-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>

              {/* Wave */}
              <button
                onClick={() => handleSelectProvider('wave')}
                className={`w-full p-5 rounded-2xl border-2 transition-all text-left flex items-center gap-4 group hover:scale-[1.01] ${
                  selectedProvider === 'wave'
                    ? 'border-cyan-500 bg-cyan-500/10'
                    : 'border-gray-800 bg-gray-900 hover:border-cyan-500/50 hover:bg-cyan-500/5'
                }`}
              >
                <WaveLogo size={48} />
                <div className="flex-1">
                  <p className="text-white font-bold text-lg">Wave</p>
                  <p className="text-gray-400 text-sm">Payez avec votre compte Wave</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">SN</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">CI</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">ML</span>
                    <span className="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">BF</span>
                  </div>
                </div>
                <svg className="w-5 h-5 text-gray-600 group-hover:text-cyan-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>

            {/* Security Note */}
            <div className="mt-8 flex items-center gap-3 text-gray-500 text-sm">
              <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
              <p>Paiement 100% sécurisé. Vos données sont protégées.</p>
            </div>
          </div>
        )}

        {/* Step 3: Enter Phone Number */}
        {!showHistory && step === 'enter_phone' && (
          <div className="max-w-lg mx-auto">
            <div className="bg-gray-900 rounded-2xl p-8 border border-gray-800">
              {/* Provider Badge */}
              <div className="flex items-center gap-3 mb-8">
                {selectedProvider === 'orange_money' && <OrangeMoneyLogo size={44} />}
                {selectedProvider === 'mtn_money' && <MTNMoneyLogo size={44} />}
                {selectedProvider === 'wave' && <WaveLogo size={44} />}
                <div>
                  <p className="text-white font-bold">
                    {selectedProvider === 'orange_money' ? 'Orange Money' :
                     selectedProvider === 'mtn_money' ? 'MTN Mobile Money' : 'Wave'}
                  </p>
                  <p className="text-gray-400 text-sm">{paymentService.formatAmount(getPrice())} / {billingCycle === 'monthly' ? 'mois' : 'an'}</p>
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-white font-medium mb-2">Numéro de téléphone</label>
                <p className="text-gray-400 text-sm mb-4">
                  Entrez le numéro associé à votre compte {
                    selectedProvider === 'orange_money' ? 'Orange Money' :
                    selectedProvider === 'mtn_money' ? 'MTN Money' : 'Wave'
                  }
                </p>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                    <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                  </div>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => {
                      setPhoneNumber(e.target.value);
                      setPhoneError(null);
                    }}
                    onKeyDown={(e) => e.key === 'Enter' && handlePhoneSubmit()}
                    placeholder="+225 07 00 00 00 00"
                    className={`w-full bg-gray-800 border rounded-xl pl-12 pr-4 py-4 text-white text-lg placeholder-gray-600 focus:outline-none focus:ring-2 transition-all ${
                      phoneError
                        ? 'border-red-500 focus:ring-red-500'
                        : 'border-gray-700 focus:ring-purple-500'
                    }`}
                    autoFocus
                  />
                </div>
                {phoneError && (
                  <p className="text-red-400 text-sm mt-2 flex items-center gap-1">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {phoneError}
                  </p>
                )}
                <p className="text-gray-600 text-xs mt-3">
                  Exemple: +225 07 00 00 00 00 (Côte d'Ivoire)
                </p>
              </div>

              <button
                onClick={handlePhoneSubmit}
                disabled={!phoneNumber.trim()}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-xl transition-all"
              >
                Continuer
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Confirm Payment */}
        {!showHistory && step === 'confirm' && (
          <div className="max-w-lg mx-auto">
            <div className="bg-gray-900 rounded-2xl overflow-hidden border border-gray-800">
              {/* Header */}
              <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 p-6 border-b border-gray-800">
                <h2 className="text-white font-bold text-xl mb-1">Récapitulatif du paiement</h2>
                <p className="text-gray-400 text-sm">Vérifiez les détails avant de confirmer</p>
              </div>

              <div className="p-6 space-y-5">
                {/* Plan */}
                <div className="flex items-center justify-between py-3 border-b border-gray-800">
                  <div>
                    <p className="text-gray-400 text-sm">Forfait</p>
                    <p className="text-white font-semibold">{selectedPlan?.name}</p>
                  </div>
                  <span className="text-gray-400 text-sm capitalize">
                    {billingCycle === 'monthly' ? 'Mensuel' : 'Annuel'}
                  </span>
                </div>

                {/* Provider */}
                <div className="flex items-center justify-between py-3 border-b border-gray-800">
                  <div>
                    <p className="text-gray-400 text-sm">Opérateur</p>
                    <div className="flex items-center gap-2 mt-1">
                      {selectedProvider === 'orange_money' && <OrangeMoneyLogo size={28} />}
                      {selectedProvider === 'mtn_money' && <MTNMoneyLogo size={28} />}
                      {selectedProvider === 'wave' && <WaveLogo size={28} />}
                      <span className="text-white font-semibold">
                        {selectedProvider === 'orange_money' ? 'Orange Money' :
                         selectedProvider === 'mtn_money' ? 'MTN Mobile Money' : 'Wave'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-center justify-between py-3 border-b border-gray-800">
                  <div>
                    <p className="text-gray-400 text-sm">Numéro</p>
                    <p className="text-white font-semibold">{phoneNumber}</p>
                  </div>
                  <button
                    onClick={() => setStep('enter_phone')}
                    className="text-purple-400 text-sm hover:text-purple-300 transition-colors"
                  >
                    Modifier
                  </button>
                </div>

                {/* Total */}
                <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl p-5 border border-purple-500/20">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300 font-medium">Total à payer</span>
                    <span className="text-white font-extrabold text-2xl">
                      {paymentService.formatAmount(getPrice())}
                    </span>
                  </div>
                </div>

                {error && (
                  <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
                    <p className="text-red-400 text-sm flex items-center gap-2">
                      <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      {error}
                    </p>
                  </div>
                )}

                <button
                  onClick={handleInitiatePayment}
                  disabled={isProcessing}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-3 text-lg"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Traitement en cours...
                    </>
                  ) : (
                    <>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                      Payer {paymentService.formatAmount(getPrice())}
                    </>
                  )}
                </button>

                <p className="text-gray-600 text-xs text-center">
                  En confirmant, vous acceptez nos conditions d'utilisation et notre politique de confidentialité.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Step 5: Processing */}
        {!showHistory && step === 'processing' && (
          <div className="max-w-lg mx-auto">
            <div className="bg-gray-900 rounded-2xl p-8 border border-gray-800 text-center">
              {/* Animated Phone Icon */}
              <div className="relative w-24 h-24 mx-auto mb-6">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl animate-pulse opacity-20" />
                <div className="absolute inset-2 bg-gray-800 rounded-xl flex items-center justify-center">
                  <svg className="w-10 h-10 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                </div>
                {/* Notification dot */}
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center animate-bounce">
                  <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>

              <h2 className="text-white font-bold text-xl mb-3">Confirmez sur votre téléphone</h2>
              <p className="text-gray-400 mb-2">
                Une demande de paiement a été envoyée sur votre{' '}
                <span className="text-white font-medium">
                  {selectedProvider === 'orange_money' ? 'Orange Money' :
                   selectedProvider === 'mtn_money' ? 'MTN Mobile Money' : 'Wave'}
                </span>
              </p>
              <p className="text-gray-500 text-sm mb-8">
                Numéro: <span className="text-gray-300">{phoneNumber}</span>
              </p>

              {/* Instructions */}
              <div className="bg-gray-800/50 rounded-xl p-5 mb-8 text-left">
                <p className="text-gray-300 font-medium mb-3">Instructions :</p>
                <ol className="space-y-3 text-gray-400 text-sm">
                  <li className="flex items-start gap-3">
                    <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">1</span>
                    <span>Ouvrez l'application {selectedProvider === 'orange_money' ? 'Orange Money' : selectedProvider === 'mtn_money' ? 'MTN MoMo' : 'Wave'} sur votre téléphone</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">2</span>
                    <span>Vérifiez la notification de demande de paiement</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">3</span>
                    <span>Entrez votre code PIN pour confirmer le paiement de <span className="text-white font-medium">{paymentService.formatAmount(getPrice())}</span></span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">4</span>
                    <span>Revenez ici et cliquez sur "J'ai confirmé le paiement"</span>
                  </li>
                </ol>
              </div>

              {/* Transaction Info */}
              {currentPayment && (
                <div className="bg-gray-800/30 rounded-xl p-4 mb-6 text-left">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Référence</span>
                    <span className="text-gray-300 font-mono text-xs">{currentPayment.transaction_id}</span>
                  </div>
                </div>
              )}

              {error && (
                <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl mb-6">
                  <p className="text-red-400 text-sm">{error}</p>
                </div>
              )}

              <button
                onClick={handleConfirmPayment}
                disabled={isProcessing}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 mb-3"
              >
                {isProcessing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Vérification en cours...
                  </>
                ) : (
                  <>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    J'ai confirmé le paiement
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  setStep('select_provider');
                  setCurrentPayment(null);
                  setError(null);
                }}
                className="w-full bg-gray-800 hover:bg-gray-700 text-gray-300 font-medium py-3 rounded-xl transition-colors text-sm"
              >
                Annuler et choisir un autre moyen de paiement
              </button>
            </div>
          </div>
        )}

        {/* Step 6: Success */}
        {!showHistory && step === 'success' && (
          <div className="max-w-lg mx-auto">
            <div className="bg-gray-900 rounded-2xl p-8 border border-gray-800 text-center">
              {/* Success Animation */}
              <div className="relative w-24 h-24 mx-auto mb-6">
                <div className="absolute inset-0 bg-green-500 rounded-full opacity-20 animate-ping" />
                <div className="absolute inset-0 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center">
                  <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>

              <h2 className="text-white font-bold text-2xl mb-2">Paiement confirmé !</h2>
              <p className="text-gray-400 mb-8">
                Votre abonnement <span className="text-white font-medium">{selectedPlan?.name}</span> est maintenant actif.
                Vous pouvez commencer à faire des lives !
              </p>

              {currentPayment && (
                <div className="bg-gray-800/50 rounded-xl p-5 mb-8 text-left space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Montant payé</span>
                    <span className="text-white font-bold">{paymentService.formatAmount(getPrice())}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Opérateur</span>
                    <span className="text-white">
                      {selectedProvider === 'orange_money' ? 'Orange Money' :
                       selectedProvider === 'mtn_money' ? 'MTN Money' : 'Wave'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Référence</span>
                    <span className="text-gray-300 font-mono text-xs">{currentPayment.transaction_id}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Statut</span>
                    <span className="text-green-400 font-medium flex items-center gap-1">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Confirmé
                    </span>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                <button
                  onClick={() => navigate('/')}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" />
                  </svg>
                  Commencer un live
                </button>
                <button
                  onClick={() => navigate('/settings')}
                  className="w-full bg-gray-800 hover:bg-gray-700 text-gray-300 font-medium py-3 rounded-xl transition-colors"
                >
                  Voir mon abonnement
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentPage;
