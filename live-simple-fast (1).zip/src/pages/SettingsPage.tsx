import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import ProfileSettings from '@/components/settings/ProfileSettings';
import SubscriptionSettings from '@/components/settings/SubscriptionSettings';
import SecuritySettings from '@/components/settings/SecuritySettings';
import NotificationSettings from '@/components/settings/NotificationSettings';
import DangerZone from '@/components/settings/DangerZone';
import DiagnosticsPanel from '@/components/DiagnosticsPanel';

type SettingsTab = 'profile' | 'subscription' | 'security' | 'notifications' | 'diagnostics' | 'danger';

const tabs: { id: SettingsTab; label: string; icon: React.ReactNode; description: string }[] = [
  {
    id: 'profile',
    label: 'Profil',
    description: 'Informations publiques',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
      </svg>
    ),
  },
  {
    id: 'subscription',
    label: 'Abonnement',
    description: 'Forfait et facturation',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
      </svg>
    ),
  },
  {
    id: 'security',
    label: 'Sécurité',
    description: 'Mot de passe',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
      </svg>
    ),
  },
  {
    id: 'notifications',
    label: 'Notifications',
    description: 'Préférences d\'alertes',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
      </svg>
    ),
  },
  {
    id: 'diagnostics',
    label: 'Diagnostics',
    description: 'Connexion base de données',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
      </svg>
    ),
  },
  {
    id: 'danger',
    label: 'Zone de danger',
    description: 'Suppression du compte',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
      </svg>
    ),
  },
];

const SettingsPage: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, isLoading, creatorProfile } = useAppContext();
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Redirect if not authenticated (but only if Supabase is configured)
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      // Don't redirect — just show a message
    }
  }, [isLoading, isAuthenticated, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-8">
          <div className="w-16 h-16 bg-purple-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <svg className="w-8 h-8 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-white text-xl font-bold mb-3">Connexion requise</h2>
          <p className="text-gray-400 text-sm mb-6">
            Vous devez être connecté pour accéder aux paramètres. Connectez-vous ou créez un compte pour continuer.
          </p>
          <button
            onClick={() => navigate('/')}
            className="bg-purple-600 hover:bg-purple-700 text-white font-medium px-6 py-3 rounded-xl transition-colors"
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }


  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfileSettings />;
      case 'subscription':
        return <SubscriptionSettings />;
      case 'security':
        return <SecuritySettings />;
      case 'notifications':
        return <NotificationSettings />;
      case 'diagnostics':
        return <DiagnosticsPanel />;
      case 'danger':
        return <DangerZone />;
      default:
        return <ProfileSettings />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Top Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-gray-950/95 backdrop-blur-xl border-b border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Back Button + Title */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/')}
                className="w-9 h-9 rounded-xl bg-gray-800/50 hover:bg-gray-800 flex items-center justify-center transition-colors"
              >
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <div>
                <h1 className="text-white font-bold text-lg">Paramètres</h1>
                <p className="text-gray-500 text-xs hidden sm:block">Gérez votre compte et vos préférences</p>
              </div>
            </div>

            {/* User Info */}
            <div className="flex items-center gap-3">
              {creatorProfile && (
                <div className="hidden sm:flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-white text-sm font-medium">{creatorProfile.display_name}</p>
                    <p className="text-gray-500 text-xs">@{creatorProfile.username}</p>
                  </div>
                  <div className="w-9 h-9 rounded-xl overflow-hidden bg-gray-800 border border-gray-700">
                    {creatorProfile.avatar_url ? (
                      <img src={creatorProfile.avatar_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <svg className="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                        </svg>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Mobile menu toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden w-9 h-9 rounded-xl bg-gray-800/50 hover:bg-gray-800 flex items-center justify-center transition-colors"
              >
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="pt-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex gap-8 py-8">
          {/* Sidebar - Desktop */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <nav className="sticky top-24 space-y-1">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${
                    activeTab === tab.id
                      ? 'bg-purple-500/10 text-white border border-purple-500/20'
                      : tab.id === 'danger'
                      ? 'text-gray-400 hover:bg-red-500/5 hover:text-red-400'
                      : tab.id === 'diagnostics'
                      ? 'text-gray-400 hover:bg-cyan-500/5 hover:text-cyan-400'
                      : 'text-gray-400 hover:bg-gray-800/50 hover:text-white'
                  }`}
                >
                  <span className={`flex-shrink-0 ${
                    activeTab === tab.id
                      ? tab.id === 'diagnostics' ? 'text-cyan-400' : 'text-purple-400'
                      : tab.id === 'danger'
                      ? 'text-red-400/60'
                      : tab.id === 'diagnostics'
                      ? 'text-cyan-400/60'
                      : 'text-gray-500'
                  }`}>
                    {tab.icon}
                  </span>
                  <div>
                    <p className={`font-medium text-sm ${
                      tab.id === 'danger' && activeTab !== tab.id ? 'text-red-400/80' : ''
                    }`}>
                      {tab.label}
                    </p>
                    <p className="text-xs text-gray-600 mt-0.5">{tab.description}</p>
                  </div>
                </button>
              ))}
            </nav>
          </aside>

          {/* Mobile Sidebar Overlay */}
          {mobileMenuOpen && (
            <>
              <div
                className="fixed inset-0 bg-black/60 z-40 lg:hidden"
                onClick={() => setMobileMenuOpen(false)}
              />
              <div className="fixed top-16 left-0 bottom-0 w-72 bg-gray-950 border-r border-gray-800 z-50 lg:hidden overflow-y-auto">
                <nav className="p-4 space-y-1">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setActiveTab(tab.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${
                        activeTab === tab.id
                          ? 'bg-purple-500/10 text-white border border-purple-500/20'
                          : tab.id === 'danger'
                          ? 'text-gray-400 hover:bg-red-500/5 hover:text-red-400'
                          : tab.id === 'diagnostics'
                          ? 'text-gray-400 hover:bg-cyan-500/5 hover:text-cyan-400'
                          : 'text-gray-400 hover:bg-gray-800/50 hover:text-white'
                      }`}
                    >
                      <span className={`flex-shrink-0 ${
                        activeTab === tab.id
                          ? tab.id === 'diagnostics' ? 'text-cyan-400' : 'text-purple-400'
                          : tab.id === 'danger'
                          ? 'text-red-400/60'
                          : tab.id === 'diagnostics'
                          ? 'text-cyan-400/60'
                          : 'text-gray-500'
                      }`}>
                        {tab.icon}
                      </span>
                      <div>
                        <p className={`font-medium text-sm ${
                          tab.id === 'danger' && activeTab !== tab.id ? 'text-red-400/80' : ''
                        }`}>
                          {tab.label}
                        </p>
                        <p className="text-xs text-gray-600 mt-0.5">{tab.description}</p>
                      </div>
                    </button>
                  ))}
                </nav>
              </div>
            </>
          )}

          {/* Content Area */}
          <main className="flex-1 min-w-0">
            <div className={`border border-gray-800/50 rounded-2xl p-6 sm:p-8 ${
              activeTab === 'diagnostics' ? 'bg-gray-950/50' : 'bg-gray-900/30'
            }`}>
              {renderContent()}
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
