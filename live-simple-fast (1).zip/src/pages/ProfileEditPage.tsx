import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';

type UsernameStatus = 'idle' | 'checking' | 'available' | 'taken' | 'invalid' | 'same';

const ProfileEditPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, creatorProfile, updateProfile, uploadAvatar, isAuthenticated, isLoading } = useAppContext();

  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Username availability state
  const [usernameStatus, setUsernameStatus] = useState<UsernameStatus>('idle');
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastCheckedRef = useRef<string>('');

  // Pre-populate form fields from existing profile
  useEffect(() => {
    if (creatorProfile) {
      setUsername(creatorProfile.username || '');
      setDisplayName(creatorProfile.display_name || '');
      setBio(creatorProfile.bio || '');
      setWhatsappNumber(creatorProfile.whatsapp_number || '');
      setAvatarUrl(creatorProfile.avatar_url || null);
    }
  }, [creatorProfile]);

  // Redirect unauthenticated users after loading completes
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate('/');
    }
  }, [isLoading, isAuthenticated, navigate]);

  // Debounced username availability check
  const checkUsernameAvailability = useCallback(async (usernameToCheck: string) => {
    // Skip if same as current profile username
    if (creatorProfile?.username && usernameToCheck === creatorProfile.username) {
      setUsernameStatus('same');
      return;
    }

    // Validate format
    if (usernameToCheck.length < 3) {
      setUsernameStatus('invalid');
      return;
    }
    if (!/^[a-zA-Z0-9_]+$/.test(usernameToCheck)) {
      setUsernameStatus('invalid');
      return;
    }

    setUsernameStatus('checking');
    lastCheckedRef.current = usernameToCheck;

    try {
      const { data, error: queryError } = await supabase
        .from('creator_profiles')
        .select('user_id')
        .eq('username', usernameToCheck.toLowerCase())
        .maybeSingle();

      // Only update if this is still the latest check
      if (lastCheckedRef.current !== usernameToCheck) return;

      if (queryError) {
        console.error('Username check error:', queryError);
        setUsernameStatus('idle');
        return;
      }

      if (data) {
        // Username exists — check if it belongs to the current user
        if (user && data.user_id === user.id) {
          setUsernameStatus('same');
        } else {
          setUsernameStatus('taken');
        }
      } else {
        setUsernameStatus('available');
      }
    } catch (err) {
      console.error('Username availability check failed:', err);
      if (lastCheckedRef.current === usernameToCheck) {
        setUsernameStatus('idle');
      }
    }
  }, [creatorProfile?.username, user]);

  // Debounce effect for username changes
  useEffect(() => {
    // Clear any existing timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = null;
    }

    const trimmed = username.trim();

    // If empty, reset to idle
    if (!trimmed) {
      setUsernameStatus('idle');
      return;
    }

    // If same as current profile username, immediately mark as same
    if (creatorProfile?.username && trimmed === creatorProfile.username) {
      setUsernameStatus('same');
      return;
    }

    // If too short or invalid, immediately mark as invalid
    if (trimmed.length < 3 || !/^[a-zA-Z0-9_]+$/.test(trimmed)) {
      setUsernameStatus('invalid');
      return;
    }

    // Set to checking while we wait for debounce
    setUsernameStatus('checking');

    // Debounce the actual API call
    debounceTimerRef.current = setTimeout(() => {
      checkUsernameAvailability(trimmed);
    }, 300);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [username, creatorProfile?.username, checkUsernameAvailability]);

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('L\'image ne doit pas dépasser 5 Mo.');
        return;
      }
      setAvatarFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveAvatar = () => {
    setAvatarFile(null);
    setAvatarPreview(null);
    setAvatarUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!username.trim()) {
      setError('Le nom d\'utilisateur est requis.');
      return;
    }

    if (!displayName.trim()) {
      setError('Le nom d\'affichage est requis.');
      return;
    }

    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      setError('Le nom d\'utilisateur ne peut contenir que des lettres, chiffres et underscores.');
      return;
    }

    if (username.length < 3) {
      setError('Le nom d\'utilisateur doit contenir au moins 3 caractères.');
      return;
    }

    if (usernameStatus === 'taken') {
      setError('Ce nom d\'utilisateur est déjà pris. Veuillez en choisir un autre.');
      return;
    }

    setIsSaving(true);

    try {
      let finalAvatarUrl = avatarUrl;

      // Upload new avatar if one was selected
      if (avatarFile) {
        const uploadResult = await uploadAvatar(avatarFile);
        if (uploadResult.success && uploadResult.url) {
          finalAvatarUrl = uploadResult.url;
        } else {
          setError(uploadResult.error || 'Erreur lors de l\'upload de l\'avatar.');
          setIsSaving(false);
          return;
        }
      }

      const result = await updateProfile({
        username: username.toLowerCase(),
        display_name: displayName,
        bio: bio || null,
        avatar_url: finalAvatarUrl,
        whatsapp_number: whatsappNumber || null,
      });

      if (result.success) {
        setSuccess('Profil mis à jour avec succès !');
        setAvatarFile(null);
        setAvatarPreview(null);
        // Scroll to top to show success message
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setError(result.error || 'Erreur lors de la mise à jour du profil.');
      }
    } catch (err: any) {
      setError(err.message || 'Une erreur inattendue est survenue.');
    } finally {
      setIsSaving(false);
    }
  };

  // Detect if username looks auto-generated (contains timestamp-like suffix)
  const isAutoGenerated = creatorProfile?.username
    ? /^.+_[a-z0-9]{6,}$/.test(creatorProfile.username)
    : false;

  // Determine if submit should be disabled
  const isSubmitDisabled =
    isSaving ||
    !username.trim() ||
    !displayName.trim() ||
    usernameStatus === 'taken' ||
    usernameStatus === 'checking' ||
    usernameStatus === 'invalid';

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated || !creatorProfile) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center text-white p-4">
        <div className="max-w-md w-full bg-gray-900 border border-gray-800 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-purple-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold mb-2">Profil non disponible</h2>
          <p className="text-gray-400 mb-6 text-sm">
            {!isAuthenticated 
              ? 'Vous devez être connecté pour modifier votre profil.'
              : 'Votre profil créateur n\'a pas encore été créé. Cela peut arriver si les tables de la base de données ne sont pas configurées.'}
          </p>
          <div className="flex flex-col gap-3">
            <button
              onClick={() => navigate('/')}
              className="bg-purple-600 hover:bg-purple-700 text-white font-medium px-6 py-2.5 rounded-full transition-colors"
            >
              Retour à l'accueil
            </button>
            <button
              onClick={() => navigate('/setup')}
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              Vérifier la configuration
            </button>
          </div>
        </div>
      </div>
    );
  }


  const displayAvatar = avatarPreview || avatarUrl;

  // Username status indicator component
  const renderUsernameStatus = () => {
    switch (usernameStatus) {
      case 'checking':
        return (
          <div className="flex items-center gap-1.5 mt-1.5">
            <div className="w-3.5 h-3.5 border-2 border-purple-400/30 border-t-purple-400 rounded-full animate-spin" />
            <span className="text-purple-400 text-xs">Vérification...</span>
          </div>
        );
      case 'available':
        return (
          <div className="flex items-center gap-1.5 mt-1.5">
            <svg className="w-4 h-4 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
            </svg>
            <span className="text-green-400 text-xs font-medium">Disponible</span>
          </div>
        );
      case 'taken':
        return (
          <div className="flex items-center gap-1.5 mt-1.5">
            <svg className="w-4 h-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
            <span className="text-red-400 text-xs font-medium">Déjà pris</span>
          </div>
        );
      case 'invalid':
        return (
          <div className="flex items-center gap-1.5 mt-1.5">
            <svg className="w-4 h-4 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-amber-400 text-xs">Min. 3 caractères, lettres, chiffres et _ uniquement</span>
          </div>
        );
      case 'same':
        return (
          <div className="flex items-center gap-1.5 mt-1.5">
            <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            <span className="text-gray-400 text-xs">Votre nom d'utilisateur actuel</span>
          </div>
        );
      default:
        return null;
    }
  };

  // Compute dynamic border color for username input
  const getUsernameInputBorderClass = () => {
    switch (usernameStatus) {
      case 'available':
        return 'border-green-500/50 focus:ring-green-500';
      case 'taken':
        return 'border-red-500/50 focus:ring-red-500';
      case 'invalid':
        return 'border-amber-500/50 focus:ring-amber-500';
      case 'checking':
        return 'border-purple-500/50 focus:ring-purple-500';
      default:
        return 'border-gray-700 focus:ring-purple-500';
    }
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header bar */}
      <div className="sticky top-0 z-30 bg-gray-950/80 backdrop-blur-xl border-b border-gray-800/50">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span className="text-sm">Retour</span>
          </button>
          <h1 className="text-white font-semibold text-lg">Modifier le profil</h1>
          <div className="w-16" /> {/* Spacer for centering */}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Auto-generated username banner */}
        {isAutoGenerated && (
          <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-3">
            <svg className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
            <div>
              <p className="text-amber-300 font-medium text-sm">Nom d'utilisateur auto-généré</p>
              <p className="text-amber-400/70 text-xs mt-1">
                Votre nom d'utilisateur <span className="font-mono bg-amber-500/10 px-1.5 py-0.5 rounded">@{creatorProfile.username}</span> a été créé automatiquement. Personnalisez-le ci-dessous pour qu'il soit plus facile à retenir.
              </p>
            </div>
          </div>
        )}

        {/* Success message */}
        {success && (
          <div className="mb-6 p-4 bg-green-500/10 border border-green-500/20 rounded-xl flex items-center gap-3">
            <svg className="w-5 h-5 text-green-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            <p className="text-green-300 text-sm">{success}</p>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3">
            <svg className="w-5 h-5 text-red-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-red-300 text-sm">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Avatar Section */}
          <div className="bg-gray-900/50 border border-gray-800/50 rounded-2xl p-6">
            <h2 className="text-white font-semibold mb-4 flex items-center gap-2">
              <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Photo de profil
            </h2>

            <div className="flex items-center gap-6">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="relative w-24 h-24 rounded-full overflow-hidden bg-gray-800 hover:bg-gray-700 transition-colors group flex-shrink-0 ring-2 ring-gray-700 ring-offset-2 ring-offset-gray-900"
              >
                {displayAvatar ? (
                  <img src={displayAvatar} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <svg className="w-10 h-10 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                )}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp,image/gif"
                onChange={handleAvatarChange}
                className="hidden"
              />

              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 text-sm font-medium text-purple-400 bg-purple-500/10 border border-purple-500/20 rounded-lg hover:bg-purple-500/20 transition-colors"
                >
                  Changer la photo
                </button>
                {displayAvatar && (
                  <button
                    type="button"
                    onClick={handleRemoveAvatar}
                    className="px-4 py-2 text-sm font-medium text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg hover:bg-red-500/20 transition-colors"
                  >
                    Supprimer
                  </button>
                )}
                <p className="text-gray-500 text-xs">JPG, PNG, WebP ou GIF. Max 5 Mo.</p>
              </div>
            </div>
          </div>

          {/* Identity Section */}
          <div className="bg-gray-900/50 border border-gray-800/50 rounded-2xl p-6 space-y-5">
            <h2 className="text-white font-semibold flex items-center gap-2">
              <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              Identité
            </h2>

            {/* Username */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">
                Nom d'utilisateur <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm">@</span>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => {
                    const sanitized = e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
                    setUsername(sanitized);
                    setError(null);
                    setSuccess(null);
                  }}
                  placeholder="votre_nom"
                  className={`w-full bg-gray-800/50 border rounded-xl pl-9 pr-12 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:border-transparent transition-all ${getUsernameInputBorderClass()}`}
                  maxLength={30}
                />
                {/* Inline status icon inside the input */}
                <div className="absolute right-4 top-1/2 -translate-y-1/2">
                  {usernameStatus === 'checking' && (
                    <div className="w-4 h-4 border-2 border-purple-400/30 border-t-purple-400 rounded-full animate-spin" />
                  )}
                  {usernameStatus === 'available' && (
                    <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                  {usernameStatus === 'taken' && (
                    <svg className="w-5 h-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  )}
                  {usernameStatus === 'invalid' && (
                    <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  )}
                  {usernameStatus === 'same' && (
                    <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
              </div>

              {/* Status text below the input */}
              {renderUsernameStatus()}

              {/* Helper text (only show when no status message) */}
              {usernameStatus === 'idle' && (
                <p className="text-gray-500 text-xs mt-1.5">
                  Lettres minuscules, chiffres et underscores. 3 à 30 caractères.
                  {isAutoGenerated && (
                    <span className="text-amber-400 ml-1">Choisissez un nom personnalisé !</span>
                  )}
                </p>
              )}
            </div>

            {/* Display Name */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">
                Nom d'affichage <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => {
                  setDisplayName(e.target.value);
                  setError(null);
                  setSuccess(null);
                }}
                placeholder="Votre Nom"
                className="w-full bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                maxLength={50}
              />
              <p className="text-gray-500 text-xs mt-1.5">
                Le nom affiché publiquement sur votre profil et vos lives.
              </p>
            </div>
          </div>

          {/* Bio Section */}
          <div className="bg-gray-900/50 border border-gray-800/50 rounded-2xl p-6">
            <h2 className="text-white font-semibold mb-4 flex items-center gap-2">
              <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />
              </svg>
              Bio
            </h2>
            <textarea
              value={bio}
              onChange={(e) => {
                setBio(e.target.value);
                setError(null);
                setSuccess(null);
              }}
              placeholder="Parlez de vous en quelques mots... Que proposez-vous dans vos lives ?"
              rows={4}
              className="w-full bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none transition-all"
              maxLength={200}
            />
            <div className="flex justify-between items-center mt-1.5">
              <p className="text-gray-500 text-xs">Décrivez-vous pour attirer des spectateurs.</p>
              <p className={`text-xs ${bio.length > 180 ? 'text-amber-400' : 'text-gray-500'}`}>
                {bio.length}/200
              </p>
            </div>
          </div>

          {/* WhatsApp Section */}
          <div className="bg-gray-900/50 border border-gray-800/50 rounded-2xl p-6">
            <h2 className="text-white font-semibold mb-1 flex items-center gap-2">
              <svg className="w-5 h-5 text-green-400" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              Numéro WhatsApp
              <span className="text-green-500 text-xs bg-green-500/20 px-2 py-0.5 rounded-full font-normal">recommandé</span>
            </h2>
            <p className="text-gray-500 text-xs mb-4">
              Les spectateurs pourront vous contacter directement pendant vos lives via WhatsApp.
            </p>

            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                <svg className="w-5 h-5 text-green-500" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </div>
              <input
                type="tel"
                value={whatsappNumber}
                onChange={(e) => {
                  setWhatsappNumber(e.target.value);
                  setError(null);
                  setSuccess(null);
                }}
                placeholder="+225 07 00 00 00 00"
                className="w-full bg-gray-800/50 border border-green-500/30 rounded-xl pl-12 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
              />
            </div>
            {whatsappNumber && (
              <div className="mt-2 flex items-center gap-2 text-green-400 text-xs">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Le bouton WhatsApp sera visible sur vos lives
              </div>
            )}
          </div>

          {/* Account Info (read-only) */}
          <div className="bg-gray-900/50 border border-gray-800/50 rounded-2xl p-6">
            <h2 className="text-white font-semibold mb-4 flex items-center gap-2">
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Informations du compte
            </h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-400 text-sm">Email</span>
                <span className="text-gray-300 text-sm font-mono">{user?.email}</span>
              </div>
              <div className="border-t border-gray-800/50" />
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-400 text-sm">Membre depuis</span>
                <span className="text-gray-300 text-sm">
                  {creatorProfile.created_at
                    ? new Date(creatorProfile.created_at).toLocaleDateString('fr-FR', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })
                    : '—'}
                </span>
              </div>
              <div className="border-t border-gray-800/50" />
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-400 text-sm">Vérifié</span>
                <span className={`text-sm font-medium ${creatorProfile.is_verified ? 'text-green-400' : 'text-gray-500'}`}>
                  {creatorProfile.is_verified ? 'Oui' : 'Non'}
                </span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pb-8">
            <button
              type="submit"
              disabled={isSubmitDisabled}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 disabled:cursor-not-allowed text-white font-semibold py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20"
            >
              {isSaving ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Enregistrement...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Enregistrer les modifications
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => navigate(-1)}
              className="px-6 py-3.5 text-gray-400 bg-gray-800/50 border border-gray-700 rounded-xl hover:bg-gray-800 hover:text-white transition-colors font-medium"
            >
              Annuler
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfileEditPage;
