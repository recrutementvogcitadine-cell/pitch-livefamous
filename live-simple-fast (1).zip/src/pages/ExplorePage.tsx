import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import CreatorCard, { CreatorCardData } from '@/components/explore/CreatorCard';
import AuthModal from '@/components/AuthModal';
import { Search, SlidersHorizontal, X, ChevronDown, Users, TrendingUp, Clock, Sparkles } from 'lucide-react';

// ============================================================================
// CATEGORIES
// ============================================================================
const CATEGORIES = [
  { id: 'all', label: 'Tous', icon: Sparkles, color: 'from-purple-500 to-pink-500' },
  { id: 'musique', label: 'Musique', icon: null, color: 'from-red-500 to-pink-500' },
  { id: 'gaming', label: 'Gaming', icon: null, color: 'from-green-500 to-emerald-500' },
  { id: 'cuisine', label: 'Cuisine', icon: null, color: 'from-orange-500 to-yellow-500' },
  { id: 'tech', label: 'Tech', icon: null, color: 'from-blue-500 to-cyan-500' },
  { id: 'comedie', label: 'Comédie', icon: null, color: 'from-yellow-500 to-orange-500' },
  { id: 'mode', label: 'Mode & Beauté', icon: null, color: 'from-pink-500 to-rose-500' },
  { id: 'sport', label: 'Sport', icon: null, color: 'from-emerald-500 to-teal-500' },
  { id: 'education', label: 'Éducation', icon: null, color: 'from-indigo-500 to-purple-500' },
  { id: 'actualites', label: 'Actualités', icon: null, color: 'from-gray-500 to-slate-500' },
  { id: 'lifestyle', label: 'Lifestyle', icon: null, color: 'from-fuchsia-500 to-pink-500' },
  { id: 'business', label: 'Business', icon: null, color: 'from-amber-500 to-orange-500' },
];

const SORT_OPTIONS = [
  { id: 'followers', label: 'Plus d\'abonnés', icon: Users },
  { id: 'views', label: 'Plus de vues', icon: TrendingUp },
  { id: 'recent', label: 'Plus récents', icon: Clock },
  { id: 'active', label: 'Plus actifs', icon: Sparkles },
];

// ============================================================================
// DEMO DATA — shown when DB is not configured or empty
// ============================================================================
const DEMO_CREATORS: CreatorCardData[] = [
  { id: 'd1', username: 'aminata_ci', display_name: 'Aminata', bio: 'Chanteuse et créatrice de contenu musical. Afrobeats & coupé-décalé.', avatar_url: 'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471962230_9ffb24ac.jpg', is_verified: true, followers_count: 12500, total_views: 245000, category: 'musique', live_count: 34 },
  { id: 'd2', username: 'kouame_live', display_name: 'Kouamé Live', bio: 'Musique & divertissement en direct depuis Abidjan.', avatar_url: 'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471963594_5644eaf8.jpg', is_verified: true, followers_count: 8700, total_views: 132000, category: 'musique', live_count: 28 },
  { id: 'd3', username: 'fatou_style', display_name: 'Fatou Style', bio: 'Mode, beauté et tendances africaines. Conseils et tutoriels.', avatar_url: 'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471964934_c0e82b9f.jpg', is_verified: false, followers_count: 5200, total_views: 78000, category: 'mode', live_count: 15 },
  { id: 'd4', username: 'yao_comedy', display_name: 'Yao Comedy', bio: 'Humour ivoirien et sketches en direct. Le rire c\'est la santé !', avatar_url: 'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471969898_3fdcbee1.png', is_verified: true, followers_count: 15800, total_views: 367000, category: 'comedie', live_count: 52 },
  { id: 'd5', username: 'awa_cuisine', display_name: 'Awa Cuisine', bio: 'Recettes africaines traditionnelles et modernes. Alloco, attiéké...', avatar_url: 'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471971304_bb185e18.png', is_verified: false, followers_count: 3400, total_views: 52000, category: 'cuisine', live_count: 12 },
  { id: 'd6', username: 'dj_abidjan', display_name: 'DJ Abidjan', bio: 'Mix & coupé-décalé. Sessions live tous les weekends.', avatar_url: 'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471972611_77eb0e03.png', is_verified: true, followers_count: 21000, total_views: 489000, category: 'musique', live_count: 67 },
  { id: 'd7', username: 'tech_ci', display_name: 'Tech CI', bio: 'Actualités tech et tutoriels pour développeurs en Côte d\'Ivoire.', avatar_url: null, is_verified: false, followers_count: 2800, total_views: 41000, category: 'tech', live_count: 8 },
  { id: 'd8', username: 'coach_ibra', display_name: 'Coach Ibra', bio: 'Coaching sportif et motivation. Transformez votre corps !', avatar_url: null, is_verified: true, followers_count: 9200, total_views: 156000, category: 'sport', live_count: 38 },
  { id: 'd9', username: 'gamer_225', display_name: 'Gamer 225', bio: 'Gaming en live. FIFA, Call of Duty, et plus encore.', avatar_url: null, is_verified: false, followers_count: 6100, total_views: 98000, category: 'gaming', live_count: 45 },
  { id: 'd10', username: 'prof_marie', display_name: 'Prof Marie', bio: 'Cours de maths et sciences en direct. Préparation aux examens.', avatar_url: null, is_verified: true, followers_count: 4500, total_views: 67000, category: 'education', live_count: 22 },
  { id: 'd11', username: 'abidjan_news', display_name: 'Abidjan News', bio: 'L\'actualité ivoirienne en direct. Politique, économie, société.', avatar_url: null, is_verified: true, followers_count: 18500, total_views: 312000, category: 'actualites', live_count: 89 },
  { id: 'd12', username: 'sarah_lifestyle', display_name: 'Sarah Lifestyle', bio: 'Vie quotidienne, voyages et bien-être en Côte d\'Ivoire.', avatar_url: null, is_verified: false, followers_count: 3100, total_views: 45000, category: 'lifestyle', live_count: 11 },
  { id: 'd13', username: 'ceo_konan', display_name: 'CEO Konan', bio: 'Entrepreneuriat et business en Afrique. Conseils pour réussir.', avatar_url: null, is_verified: true, followers_count: 7800, total_views: 134000, category: 'business', live_count: 30 },
  { id: 'd14', username: 'dj_mix_ci', display_name: 'DJ Mix CI', bio: 'Les meilleurs mix afro house et amapiano en live.', avatar_url: null, is_verified: false, followers_count: 4200, total_views: 72000, category: 'musique', live_count: 19 },
  { id: 'd15', username: 'chef_moussa', display_name: 'Chef Moussa', bio: 'Chef cuisinier professionnel. Gastronomie ivoirienne et internationale.', avatar_url: null, is_verified: true, followers_count: 6800, total_views: 115000, category: 'cuisine', live_count: 25 },
  { id: 'd16', username: 'gaming_queen', display_name: 'Gaming Queen', bio: 'Gameuse ivoirienne. Fortnite, Valorant et jeux mobiles.', avatar_url: null, is_verified: false, followers_count: 3900, total_views: 58000, category: 'gaming', live_count: 32 },
];

// ============================================================================
// EXPLORE PAGE COMPONENT
// ============================================================================
const ExplorePage: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, creatorProfile } = useAppContext();

  // State
  const [creators, setCreators] = useState<CreatorCardData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState<string>('followers');
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  // Fetch creators from DB or use demo data
  useEffect(() => {
    const fetchCreators = async () => {
      setLoading(true);

      if (!isSupabaseConfigured) {
        setCreators(DEMO_CREATORS);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('creator_profiles')
          .select('id, user_id, username, display_name, bio, avatar_url, is_verified, followers_count, total_views, created_at')
          .order('followers_count', { ascending: false })
          .limit(100);

        if (!error && data && data.length > 0) {
          setCreators(data.map(d => ({ ...d, category: undefined, live_count: undefined })));
        } else {
          setCreators(DEMO_CREATORS);
        }
      } catch {
        setCreators(DEMO_CREATORS);
      } finally {
        setLoading(false);
      }
    };

    fetchCreators();
  }, []);

  // Filter and sort creators
  const filteredCreators = useMemo(() => {
    let result = [...creators];

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (c) =>
          c.display_name.toLowerCase().includes(q) ||
          c.username.toLowerCase().includes(q) ||
          (c.bio && c.bio.toLowerCase().includes(q))
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      result = result.filter((c) => c.category === selectedCategory);
    }

    // Sort
    switch (sortBy) {
      case 'followers':
        result.sort((a, b) => b.followers_count - a.followers_count);
        break;
      case 'views':
        result.sort((a, b) => b.total_views - a.total_views);
        break;
      case 'recent':
        result.sort((a, b) => {
          const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
          const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
          return dateB - dateA;
        });
        break;
      case 'active':
        result.sort((a, b) => (b.live_count || 0) - (a.live_count || 0));
        break;
    }

    return result;
  }, [creators, searchQuery, selectedCategory, sortBy]);

  const handleFollowChange = useCallback((creatorId: string, isFollowing: boolean) => {
    setCreators((prev) =>
      prev.map((c) =>
        c.id === creatorId
          ? {
              ...c,
              followers_count: isFollowing
                ? c.followers_count + 1
                : Math.max(0, c.followers_count - 1),
            }
          : c
      )
    );
  }, []);

  const clearSearch = () => {
    setSearchQuery('');
  };

  const currentSort = SORT_OPTIONS.find((s) => s.id === sortBy) || SORT_OPTIONS[0];

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-gray-950/80 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo + back */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/')}
                className="flex items-center gap-3 hover:opacity-80 transition-opacity"
              >
                <img
                  src="https://d64gsuwffb70l.cloudfront.net/697513d586d0577d49bce648_1770472366980_d2796087.png"
                  alt="PitchCI"
                  className="h-9 w-9 rounded-xl object-contain shadow-lg"
                />
                <span className="text-white font-bold text-xl tracking-tight hidden sm:inline">PitchCI</span>
              </button>
              <div className="hidden sm:block w-px h-6 bg-gray-800 mx-1" />
              <span className="hidden sm:inline text-gray-400 text-sm font-medium">Explorer</span>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3">
              {isAuthenticated ? (
                <>
                  {creatorProfile && (
                    <button
                      onClick={() => navigate(`/creator/${creatorProfile.username}`)}
                      className="w-9 h-9 rounded-full overflow-hidden border-2 border-white/20 hover:border-purple-500 transition-colors"
                    >
                      {creatorProfile.avatar_url ? (
                        <img src={creatorProfile.avatar_url} alt={creatorProfile.display_name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-gray-700 flex items-center justify-center">
                          <svg className="w-5 h-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                    </button>
                  )}
                </>
              ) : (
                <button
                  onClick={() => setShowAuth(true)}
                  className="bg-gradient-to-r from-orange-500 to-pink-500 text-white text-sm font-semibold px-5 py-2 rounded-full shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 transition-all"
                >
                  Connexion
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="pt-16">
        {/* Hero / Title Section */}
        <section className="relative overflow-hidden">
          {/* Background effects */}
          <div className="absolute inset-0">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl" />
            <div className="absolute top-10 right-1/4 w-80 h-80 bg-orange-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-1/2 w-72 h-72 bg-pink-500/8 rounded-full blur-3xl" />
          </div>

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-8">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-sm text-gray-500 mb-6">
              <button onClick={() => navigate('/')} className="hover:text-white transition-colors">
                Accueil
              </button>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
              <span className="text-gray-300">Explorer</span>
            </div>

            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
              <div>
                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold mb-3">
                  <span className="bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
                    Découvrez les{' '}
                  </span>
                  <span className="bg-gradient-to-r from-orange-400 via-pink-500 to-purple-500 bg-clip-text text-transparent">
                    créateurs
                  </span>
                </h1>
                <p className="text-gray-400 text-lg max-w-xl">
                  Explorez les talents de la communauté PitchCI. Trouvez vos créateurs préférés et suivez-les.
                </p>
              </div>

              {/* Stats summary */}
              <div className="flex items-center gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{creators.length}</div>
                  <div className="text-xs text-gray-500">Créateurs</div>
                </div>
                <div className="w-px h-10 bg-gray-800" />
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{filteredCreators.length}</div>
                  <div className="text-xs text-gray-500">Résultats</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Search + Filters */}
        <section className="sticky top-16 z-40 bg-gray-950/90 backdrop-blur-xl border-b border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col gap-4">
              {/* Search bar + Sort */}
              <div className="flex items-center gap-3">
                {/* Search */}
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Rechercher un créateur par nom ou pseudo..."
                    className="w-full bg-gray-900/80 border border-white/10 rounded-xl pl-12 pr-10 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 transition-all"
                  />
                  {searchQuery && (
                    <button
                      onClick={clearSearch}
                      className="absolute right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-gray-700 hover:bg-gray-600 flex items-center justify-center transition-colors"
                    >
                      <X className="w-3.5 h-3.5 text-gray-300" />
                    </button>
                  )}
                </div>

                {/* Sort dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setShowSortDropdown(!showSortDropdown)}
                    className="flex items-center gap-2 bg-gray-900/80 border border-white/10 rounded-xl px-4 py-3 text-sm text-gray-300 hover:border-white/20 transition-all whitespace-nowrap"
                  >
                    {React.createElement(currentSort.icon, { className: 'w-4 h-4 text-purple-400' })}
                    <span className="hidden sm:inline">{currentSort.label}</span>
                    <ChevronDown className={`w-4 h-4 transition-transform ${showSortDropdown ? 'rotate-180' : ''}`} />
                  </button>

                  {showSortDropdown && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setShowSortDropdown(false)} />
                      <div className="absolute right-0 top-full mt-2 w-52 bg-gray-900 border border-gray-700 rounded-xl shadow-2xl z-50 overflow-hidden">
                        {SORT_OPTIONS.map((option) => (
                          <button
                            key={option.id}
                            onClick={() => {
                              setSortBy(option.id);
                              setShowSortDropdown(false);
                            }}
                            className={`w-full flex items-center gap-3 px-4 py-3 text-sm transition-colors ${
                              sortBy === option.id
                                ? 'bg-purple-500/20 text-purple-300'
                                : 'text-gray-300 hover:bg-gray-800'
                            }`}
                          >
                            {React.createElement(option.icon, { className: 'w-4 h-4' })}
                            {option.label}
                            {sortBy === option.id && (
                              <svg className="w-4 h-4 ml-auto text-purple-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                              </svg>
                            )}
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </div>

                {/* Mobile filter toggle */}
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="lg:hidden flex items-center gap-2 bg-gray-900/80 border border-white/10 rounded-xl px-4 py-3 text-sm text-gray-300 hover:border-white/20 transition-all"
                >
                  <SlidersHorizontal className="w-4 h-4" />
                </button>
              </div>

              {/* Category filters */}
              <div className={`${showFilters ? 'block' : 'hidden'} lg:block`}>
                <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                        selectedCategory === cat.id
                          ? `bg-gradient-to-r ${cat.color} text-white shadow-lg`
                          : 'bg-gray-900/60 text-gray-400 border border-white/5 hover:border-white/10 hover:text-white'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Results Grid */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i} className="bg-gray-900/60 border border-white/5 rounded-2xl overflow-hidden animate-pulse">
                  <div className="h-24 bg-gray-800/50" />
                  <div className="flex justify-center -mt-10">
                    <div className="w-20 h-20 rounded-full bg-gray-800 border-4 border-gray-900" />
                  </div>
                  <div className="px-4 pt-3 pb-4 text-center">
                    <div className="h-4 bg-gray-800 rounded-full w-24 mx-auto mb-2" />
                    <div className="h-3 bg-gray-800/60 rounded-full w-16 mx-auto mb-3" />
                    <div className="h-3 bg-gray-800/40 rounded-full w-32 mx-auto mb-4" />
                    <div className="flex justify-center gap-4 mb-4">
                      <div className="h-4 bg-gray-800/50 rounded w-12" />
                      <div className="h-4 bg-gray-800/50 rounded w-12" />
                    </div>
                    <div className="h-8 bg-gray-800/50 rounded-full w-20 mx-auto" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredCreators.length > 0 ? (
            <>
              {/* Active filters summary */}
              {(searchQuery || selectedCategory !== 'all') && (
                <div className="flex items-center gap-2 mb-6 flex-wrap">
                  <span className="text-gray-500 text-sm">Filtres actifs :</span>
                  {searchQuery && (
                    <span className="inline-flex items-center gap-1.5 bg-purple-500/20 text-purple-300 text-xs font-medium px-3 py-1.5 rounded-full">
                      <Search className="w-3 h-3" />
                      "{searchQuery}"
                      <button onClick={clearSearch} className="ml-1 hover:text-white">
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  )}
                  {selectedCategory !== 'all' && (
                    <span className="inline-flex items-center gap-1.5 bg-pink-500/20 text-pink-300 text-xs font-medium px-3 py-1.5 rounded-full">
                      {CATEGORIES.find((c) => c.id === selectedCategory)?.label}
                      <button onClick={() => setSelectedCategory('all')} className="ml-1 hover:text-white">
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  )}
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('all');
                    }}
                    className="text-gray-500 hover:text-white text-xs underline transition-colors"
                  >
                    Tout effacer
                  </button>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
                {filteredCreators.map((creator) => (
                  <CreatorCard
                    key={creator.id}
                    creator={creator}
                    onFollowChange={handleFollowChange}
                  />
                ))}
              </div>

              {/* Results count */}
              <div className="text-center mt-10 text-gray-500 text-sm">
                {filteredCreators.length} créateur{filteredCreators.length > 1 ? 's' : ''} trouvé{filteredCreators.length > 1 ? 's' : ''}
              </div>
            </>
          ) : (
            /* Empty state */
            <div className="text-center py-20">
              <div className="w-20 h-20 rounded-2xl bg-gray-900/80 border border-white/10 flex items-center justify-center mx-auto mb-6">
                <Search className="w-8 h-8 text-gray-600" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Aucun créateur trouvé</h3>
              <p className="text-gray-400 max-w-md mx-auto mb-6">
                {searchQuery
                  ? `Aucun résultat pour "${searchQuery}". Essayez un autre terme de recherche.`
                  : 'Aucun créateur dans cette catégorie pour le moment.'}
              </p>
              <div className="flex items-center justify-center gap-3">
                {searchQuery && (
                  <button
                    onClick={clearSearch}
                    className="bg-gray-800 hover:bg-gray-700 text-white px-5 py-2.5 rounded-full text-sm font-medium transition-colors"
                  >
                    Effacer la recherche
                  </button>
                )}
                {selectedCategory !== 'all' && (
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className="bg-gray-800 hover:bg-gray-700 text-white px-5 py-2.5 rounded-full text-sm font-medium transition-colors"
                  >
                    Voir tous les créateurs
                  </button>
                )}
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2.5 rounded-full text-sm font-medium transition-colors"
                >
                  Réinitialiser les filtres
                </button>
              </div>
            </div>
          )}
        </section>

        {/* Bottom CTA */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/40 backdrop-blur-xl border border-white/10 rounded-3xl p-8 sm:p-12 text-center">
            <h2 className="text-2xl sm:text-3xl font-bold mb-3">
              Vous êtes créateur ?{' '}
              <span className="bg-gradient-to-r from-orange-400 to-pink-500 bg-clip-text text-transparent">
                Rejoignez PitchCI
              </span>
            </h2>
            <p className="text-gray-400 max-w-lg mx-auto mb-6">
              Créez votre profil, lancez des lives et connectez-vous avec votre audience en Côte d'Ivoire.
            </p>
            <div className="flex items-center justify-center gap-3">
              {isAuthenticated ? (
                <button
                  onClick={() => navigate('/dashboard')}
                  className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-bold px-8 py-3 rounded-full shadow-xl shadow-purple-500/20 hover:shadow-purple-500/40 transition-all hover:scale-105"
                >
                  Mon tableau de bord
                </button>
              ) : (
                <>
                  <button
                    onClick={() => setShowAuth(true)}
                    className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-bold px-8 py-3 rounded-full shadow-xl shadow-purple-500/20 hover:shadow-purple-500/40 transition-all hover:scale-105"
                  >
                    Créer mon compte
                  </button>
                  <button
                    onClick={() => navigate('/')}
                    className="bg-white/5 border border-white/10 text-white font-medium px-6 py-3 rounded-full hover:bg-white/10 transition-all"
                  >
                    En savoir plus
                  </button>
                </>
              )}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-950 border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src="https://d64gsuwffb70l.cloudfront.net/697513d586d0577d49bce648_1770472366980_d2796087.png"
              alt="PitchCI"
              className="h-7 w-7 rounded-lg object-contain"
            />
            <span className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} PitchCI. Tous droits réservés.
            </span>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <button onClick={() => navigate('/')} className="text-gray-500 hover:text-white transition-colors">
              Accueil
            </button>
            <button onClick={() => navigate('/explore')} className="text-gray-400 font-medium">
              Explorer
            </button>
            <button onClick={() => navigate('/payment')} className="text-gray-500 hover:text-white transition-colors">
              Paiements
            </button>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />
    </div>
  );
};

export default ExplorePage;
