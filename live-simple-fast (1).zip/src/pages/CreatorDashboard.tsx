import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { isSupabaseConfigured } from '@/lib/supabase';
import { dashboardService } from '@/lib/dashboardService';
import type { DashboardStats, LiveHistoryItem, DailyGrowthData, FollowerGrowthPoint, RevenueDataPoint } from '@/lib/dashboardService';
import StatCard from '@/components/dashboard/StatCard';
import GrowthChart from '@/components/dashboard/GrowthChart';
import FollowersChart from '@/components/dashboard/FollowersChart';
import RevenueChart from '@/components/dashboard/RevenueChart';
import LiveHistoryTable from '@/components/dashboard/LiveHistoryTable';
import DashboardSectionError from '@/components/dashboard/DashboardSectionError';
import DashboardEmptyState from '@/components/dashboard/DashboardEmptyState';
import { toast } from 'sonner';

// ============================================================================
// Per-section state management
// ============================================================================
type SectionStatus = 'idle' | 'loading' | 'success' | 'error';

interface SectionState<T> {
  data: T;
  status: SectionStatus;
  errorMsg?: string;
}

function defaultSection<T>(defaultData: T): SectionState<T> {
  return { data: defaultData, status: 'idle' };
}

// ============================================================================
// Dashboard Component
// ============================================================================
const CreatorDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, creatorProfile, isLoading: authLoading } = useAppContext();

  // Per-section states
  const [stats, setStats] = useState<SectionState<DashboardStats | null>>(defaultSection(null));
  const [liveHistory, setLiveHistory] = useState<SectionState<LiveHistoryItem[]>>(defaultSection([]));
  const [growthData, setGrowthData] = useState<SectionState<DailyGrowthData[]>>(defaultSection([]));
  const [followerData, setFollowerData] = useState<SectionState<FollowerGrowthPoint[]>>(defaultSection([]));
  const [revenueData, setRevenueData] = useState<SectionState<RevenueDataPoint[]>>(defaultSection([]));

  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [refreshing, setRefreshing] = useState(false);
  const [initialLoadDone, setInitialLoadDone] = useState(false);


  // Track which sections have been retried (for toast dedup)
  const toastShownRef = useRef<Set<string>>(new Set());

  // ---- Individual section loaders ----

  const loadStats = useCallback(async (creatorId: string, silent = false) => {
    if (!silent) setStats(prev => ({ ...prev, status: 'loading' }));
    try {
      const data = await dashboardService.getStats(creatorId);
      setStats({ data, status: 'success' });
      return true;
    } catch (err: any) {
      const msg = err?.message || 'Erreur inconnue';
      console.error('[Dashboard] Stats error:', msg);
      setStats(prev => ({ ...prev, status: 'error', errorMsg: msg }));
      return false;
    }
  }, []);

  const loadHistory = useCallback(async (creatorId: string, silent = false) => {
    if (!silent) setLiveHistory(prev => ({ ...prev, status: 'loading' }));
    try {
      const data = await dashboardService.getLiveHistory(creatorId);
      setLiveHistory({ data, status: 'success' });
      return true;
    } catch (err: any) {
      const msg = err?.message || 'Erreur inconnue';
      console.error('[Dashboard] History error:', msg);
      setLiveHistory(prev => ({ ...prev, status: 'error', errorMsg: msg }));
      return false;
    }
  }, []);

  const loadGrowth = useCallback(async (creatorId: string, silent = false) => {
    if (!silent) setGrowthData(prev => ({ ...prev, status: 'loading' }));
    try {
      const data = await dashboardService.getGrowthData(creatorId);
      setGrowthData({ data, status: 'success' });
      return true;
    } catch (err: any) {
      const msg = err?.message || 'Erreur inconnue';
      console.error('[Dashboard] Growth error:', msg);
      setGrowthData(prev => ({ ...prev, status: 'error', errorMsg: msg }));
      return false;
    }
  }, []);

  const loadFollowers = useCallback(async (creatorId: string, silent = false) => {
    if (!silent) setFollowerData(prev => ({ ...prev, status: 'loading' }));
    try {
      const data = await dashboardService.getFollowerGrowth(creatorId);
      setFollowerData({ data, status: 'success' });
      return true;
    } catch (err: any) {
      const msg = err?.message || 'Erreur inconnue';
      console.error('[Dashboard] Followers error:', msg);
      setFollowerData(prev => ({ ...prev, status: 'error', errorMsg: msg }));
      return false;
    }
  }, []);

  const loadRevenue = useCallback(async (creatorId: string, silent = false) => {
    if (!silent) setRevenueData(prev => ({ ...prev, status: 'loading' }));
    try {
      const data = await dashboardService.getRevenueData(creatorId);
      setRevenueData({ data, status: 'success' });
      return true;
    } catch (err: any) {
      const msg = err?.message || 'Erreur inconnue';
      console.error('[Dashboard] Revenue error:', msg);
      setRevenueData(prev => ({ ...prev, status: 'error', errorMsg: msg }));
      return false;
    }
  }, []);

  // ---- Load all sections independently ----
  const loadAll = useCallback(async (creatorId: string, silent = false) => {
    // Fire all 5 fetches independently — no Promise.all so one failure doesn't block others
    const results = await Promise.allSettled([
      loadStats(creatorId, silent),
      loadHistory(creatorId, silent),
      loadGrowth(creatorId, silent),
      loadFollowers(creatorId, silent),
      loadRevenue(creatorId, silent),
    ]);

    setLastRefresh(new Date());
    setRefreshing(false);
    setInitialLoadDone(true);

    // Count failures and show a single summary toast
    const sectionNames = ['Statistiques', 'Historique', 'Croissance', 'Followers', 'Revenus'];
    const failedSections: string[] = [];

    results.forEach((result, index) => {
      // Promise.allSettled: result is { status: 'fulfilled', value: boolean } or { status: 'rejected' }
      const succeeded = result.status === 'fulfilled' && result.value === true;
      if (!succeeded) {
        failedSections.push(sectionNames[index]);
      }
    });

    if (failedSections.length > 0 && !silent) {
      // Only show toast once per load cycle (not on auto-refresh)
      const toastKey = failedSections.sort().join(',');
      if (!toastShownRef.current.has(toastKey)) {
        toastShownRef.current.add(toastKey);
        // Clear after 30s so it can show again on next manual refresh
        setTimeout(() => toastShownRef.current.delete(toastKey), 30000);

        if (failedSections.length === 5) {
          toast.error('Impossible de charger le tableau de bord', {
            description: 'Toutes les sections ont échoué. Vérifiez votre connexion et la configuration Supabase.',
            duration: 8000,
          });
        } else {
          toast.error(`Erreur de chargement partiel`, {
            description: `Sections en erreur : ${failedSections.join(', ')}. Utilisez le bouton "Réessayer" pour recharger.`,
            duration: 6000,
          });
        }
      }
    }
  }, [loadStats, loadHistory, loadGrowth, loadFollowers, loadRevenue]);

  // ---- Initial load — production mode, requires authentication ----
  useEffect(() => {
    if (authLoading) return;

    if (!isAuthenticated || !creatorProfile) {
      // In production mode, redirect to home if not authenticated
      navigate('/');
      return;
    }

    loadAll(creatorProfile.id);
  }, [authLoading, isAuthenticated, creatorProfile, loadAll, navigate]);


  // ---- Auto-refresh every 2 minutes (silent — no toasts) ----
  useEffect(() => {
    if (!creatorProfile) return;
    const creatorId = creatorProfile.id;

    const interval = setInterval(() => {
      loadAll(creatorId, true);
    }, 120000);

    return () => clearInterval(interval);
  }, [creatorProfile, loadAll]);

  // ---- Manual refresh ----
  const handleRefresh = () => {
    setRefreshing(true);
    toastShownRef.current.clear();
    if (creatorProfile?.id) loadAll(creatorProfile.id);
  };

  // ---- Get the effective creator ID for retries ----
  const getCreatorId = () => creatorProfile?.id || '';


  // ---- Detect empty state (user has no data at all) ----
  const isEmptyDashboard = (): boolean => {
    if (!initialLoadDone) return false;
    // If stats loaded successfully but everything is zero, and history is empty
    if (stats.status === 'success' && stats.data) {
      const s = stats.data;
      const allZero = s.totalViews === 0 && s.liveCount === 0 && s.followersCount === 0 && s.totalRevenue === 0;
      const noHistory = liveHistory.status === 'success' && liveHistory.data.length === 0;
      return allZero && noHistory;
    }
    return false;
  };

  // ---- Detect if ALL sections failed (total failure) ----
  const isAllFailed = (): boolean => {
    if (!initialLoadDone) return false;
    return (
      stats.status === 'error' &&
      liveHistory.status === 'error' &&
      growthData.status === 'error' &&
      followerData.status === 'error' &&
      revenueData.status === 'error'
    );
  };

  // ---- Check if still in initial loading ----
  const isInitialLoading = !initialLoadDone && (
    stats.status === 'idle' || stats.status === 'loading'
  );

  // ============================================================================
  // RENDER: Loading spinner
  // ============================================================================
  if (authLoading || isInitialLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="relative mx-auto h-16 w-16 mb-6">
            <div className="absolute inset-0 rounded-full border-2 border-purple-500/20" />
            <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-purple-500 animate-spin" />
            <div className="absolute inset-3 rounded-full border-2 border-transparent border-t-pink-500 animate-spin" style={{ animationDirection: 'reverse', animationDuration: '0.8s' }} />
          </div>
          <p className="text-white/60 text-sm">Chargement du tableau de bord...</p>
        </div>
      </div>
    );
  }

  // ============================================================================
  // RENDER: Total failure state
  // ============================================================================
  if (isAllFailed()) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
        {/* Header */}
        <DashboardHeader

          creatorProfile={creatorProfile}
          lastRefresh={lastRefresh}
          refreshing={refreshing}
          onRefresh={handleRefresh}
          onBack={() => navigate('/')}
        />

        <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
          <div className="flex flex-col items-center text-center max-w-lg mx-auto">
            <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-red-500/10 border border-red-500/20 mb-6">
              <svg className="h-10 w-10 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">
              Impossible de charger le tableau de bord
            </h2>
            <p className="text-white/50 mb-2">
              Toutes les sections ont échoué. Cela peut être dû à :
            </p>
            <ul className="text-sm text-white/40 mb-8 space-y-1 text-left">
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-0.5">
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </span>
                Un problème de connexion réseau
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-0.5">
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </span>
                Des tables manquantes dans la base de données
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-0.5">
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </span>
                Une configuration Supabase incorrecte
              </li>
            </ul>
            <div className="flex gap-3">
              <button
                onClick={handleRefresh}
                disabled={refreshing}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-3 text-sm font-semibold text-white shadow-lg hover:from-purple-500 hover:to-pink-500 transition-all disabled:opacity-50"
              >
                <svg className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                {refreshing ? 'Chargement...' : 'Réessayer tout'}
              </button>
              <button
                onClick={() => navigate('/setup')}
                className="flex items-center gap-2 rounded-xl bg-white/5 border border-white/10 px-6 py-3 text-sm font-medium text-white/70 hover:bg-white/10 hover:text-white transition-all"
              >
                Vérifier la configuration
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // ============================================================================
  // RENDER: Empty state (user has no data yet)
  // ============================================================================
  if (isEmptyDashboard()) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
        <DashboardHeader
          creatorProfile={creatorProfile}
          lastRefresh={lastRefresh}
          refreshing={refreshing}
          onRefresh={handleRefresh}
          onBack={() => navigate('/')}
        />
        <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
          <DashboardEmptyState />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
      <DashboardHeader
        creatorProfile={creatorProfile}
        lastRefresh={lastRefresh}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        onBack={() => navigate('/')}
      />
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        {stats.status === 'error' ? (
          <div className="mb-8"><DashboardSectionError title="Erreur de chargement des statistiques" message={stats.errorMsg} onRetry={() => loadStats(getCreatorId())} retrying={stats.status === 'loading'} /></div>
        ) : stats.status === 'loading' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">{[...Array(4)].map((_, i) => (<div key={i} className="rounded-2xl border border-white/10 bg-white/[0.02] p-5 animate-pulse"><div className="h-4 w-24 bg-white/10 rounded mb-3" /><div className="h-8 w-20 bg-white/10 rounded mb-2" /><div className="h-3 w-32 bg-white/5 rounded" /></div>))}</div>
        ) : stats.data ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard title="Vues totales" value={dashboardService.formatNumber(stats.data.totalViews)} subtitle={`Pic: ${dashboardService.formatNumber(stats.data.peakViewers)} viewers`} icon={<svg className="h-6 w-6 text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>} gradient="from-blue-600/20 to-cyan-600/10" iconBg="bg-blue-500/20" trend={{ value: 12.5, isPositive: true }} />
            <StatCard title="Durée totale" value={dashboardService.formatDurationLong(stats.data.totalLiveDuration)} subtitle={`${stats.data.liveCount} lives réalisés`} icon={<svg className="h-6 w-6 text-pink-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} gradient="from-pink-600/20 to-rose-600/10" iconBg="bg-pink-500/20" trend={{ value: 8.3, isPositive: true }} />
            <StatCard title="Followers" value={dashboardService.formatNumber(stats.data.followersCount)} subtitle={`Moy. ${dashboardService.formatNumber(stats.data.averageViewers)} viewers/live`} icon={<svg className="h-6 w-6 text-purple-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>} gradient="from-purple-600/20 to-violet-600/10" iconBg="bg-purple-500/20" trend={{ value: 15.2, isPositive: true }} />
            <StatCard title="Revenus" value={dashboardService.formatCurrency(stats.data.totalRevenue)} subtitle={`${dashboardService.formatNumber(stats.data.totalMessages)} messages chat`} icon={<svg className="h-6 w-6 text-emerald-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} gradient="from-emerald-600/20 to-teal-600/10" iconBg="bg-emerald-500/20" trend={{ value: 23.1, isPositive: true }} />
          </div>
        ) : null}
        <div className="mb-8">
          {growthData.status === 'error' ? (<DashboardSectionError title="Erreur — Croissance" message={growthData.errorMsg} onRetry={() => loadGrowth(getCreatorId())} retrying={growthData.status === 'loading'} />) : growthData.data.length > 0 ? (<GrowthChart data={growthData.data} />) : null}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {followerData.status === 'error' ? (<DashboardSectionError title="Erreur — Followers" message={followerData.errorMsg} onRetry={() => loadFollowers(getCreatorId())} retrying={followerData.status === 'loading'} />) : followerData.data.length > 0 ? (<FollowersChart data={followerData.data} />) : (<div className="rounded-2xl border border-white/5 bg-white/[0.02] p-8 flex items-center justify-center"><p className="text-sm text-white/30">Aucune donnée de followers</p></div>)}
          {revenueData.status === 'error' ? (<DashboardSectionError title="Erreur — Revenus" message={revenueData.errorMsg} onRetry={() => loadRevenue(getCreatorId())} retrying={revenueData.status === 'loading'} />) : revenueData.data.length > 0 ? (<RevenueChart data={revenueData.data} />) : (<div className="rounded-2xl border border-white/5 bg-white/[0.02] p-8 flex items-center justify-center"><p className="text-sm text-white/30">Aucune donnée de revenus</p></div>)}
        </div>
        {liveHistory.status === 'error' ? (<DashboardSectionError title="Erreur — Historique" message={liveHistory.errorMsg} onRetry={() => loadHistory(getCreatorId())} retrying={liveHistory.status === 'loading'} />) : (<LiveHistoryTable data={liveHistory.data} />)}
        <div className="h-8" />
      </main>
    </div>
  );
};

/** Dashboard header */
const DashboardHeader: React.FC<{
  creatorProfile: any;
  lastRefresh: Date;
  refreshing: boolean;
  onRefresh: () => void;
  onBack: () => void;
}> = ({ creatorProfile, lastRefresh, refreshing, onRefresh, onBack }) => (
  <header className="sticky top-0 z-30 border-b border-white/5 bg-gray-950/80 backdrop-blur-xl">
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="flex h-16 items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="flex items-center gap-2 text-white/60 hover:text-white transition-colors">
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
          </button>
          <div>
            <h1 className="text-lg font-bold text-white">Tableau de bord</h1>
            <p className="text-xs text-white/40 hidden sm:block">{creatorProfile?.display_name || 'Créateur'} — Statistiques en temps réel</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-[10px] text-white/30">Dernière mise à jour</p>
            <p className="text-xs text-white/50">{lastRefresh.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</p>
          </div>
          <button onClick={onRefresh} disabled={refreshing} className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5 border border-white/10 text-white/60 hover:bg-white/10 hover:text-white transition-all disabled:opacity-50">
            <svg className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
          </button>
        </div>
      </div>
    </div>
  </header>
);

export default CreatorDashboard;

