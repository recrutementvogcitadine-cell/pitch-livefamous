import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { DEFAULT_PERMISSIONS, ROLE_LABELS, TeamMember } from '@/lib/teamService';
import {
  activityLogService,
  ActivityLog,
  ActivityLogFilters,
  PaginatedResult,
  ACTION_TYPE_LABELS,
  ACTION_TYPE_COLORS,
  TARGET_TYPE_LABELS,
} from '@/lib/activityLogService';

import {
  ArrowLeft, Search, Filter, Calendar, RefreshCw, ChevronLeft, ChevronRight,
  Shield, Crown, Activity, Clock, Users, CheckCircle, XCircle, CreditCard,
  BadgeCheck, MessageSquare, UserPlus, UserMinus, Radio, Edit, Trash2,
  Plus, ShieldOff, Ban, UserCheck, FileText, BarChart3, Loader2, X,
  AlertTriangle, Download
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

// Map action types to lucide icons
const getActionIcon = (actionType: string) => {
  const iconMap: Record<string, React.ReactNode> = {
    activate_subscription: <CheckCircle className="w-4 h-4" />,
    deactivate_subscription: <XCircle className="w-4 h-4" />,
    create_subscription: <CreditCard className="w-4 h-4" />,
    approve_verification: <BadgeCheck className="w-4 h-4" />,
    reject_verification: <XCircle className="w-4 h-4" />,
    revoke_verification: <ShieldOff className="w-4 h-4" />,
    update_support: <MessageSquare className="w-4 h-4" />,
    create_plan: <Plus className="w-4 h-4" />,
    update_plan: <Edit className="w-4 h-4" />,
    delete_plan: <Trash2 className="w-4 h-4" />,
    add_team_member: <UserPlus className="w-4 h-4" />,
    remove_team_member: <UserMinus className="w-4 h-4" />,
    update_role: <Shield className="w-4 h-4" />,
    end_stream: <Radio className="w-4 h-4" />,
    ban_user: <Ban className="w-4 h-4" />,
    unban_user: <UserCheck className="w-4 h-4" />,
    delete_message: <MessageSquare className="w-4 h-4" />,
  };
  return iconMap[actionType] || <Activity className="w-4 h-4" />;
};

// Role badge component
const RoleBadge: React.FC<{ role: string | null }> = ({ role }) => {
  if (!role) return null;
  const colorMap: Record<string, string> = {
    owner: 'bg-amber-100 text-amber-800',
    admin: 'bg-purple-100 text-purple-700',
    moderator: 'bg-blue-100 text-blue-700',
    read_only: 'bg-gray-100 text-gray-600',
  };
  return (
    <Badge className={`text-[10px] px-1.5 py-0 ${colorMap[role] || 'bg-gray-100 text-gray-600'}`}>
      {role === 'owner' && <Crown className="w-2.5 h-2.5 mr-0.5" />}
      {ROLE_LABELS[role] || role}
    </Badge>
  );
};

// Format relative time
const formatRelativeTime = (dateStr: string): string => {
  const now = new Date();
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'À l\'instant';
  if (diffMins < 60) return `Il y a ${diffMins}min`;
  if (diffHours < 24) return `Il y a ${diffHours}h`;
  if (diffDays < 7) return `Il y a ${diffDays}j`;
  return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
};

// Format full date/time
const formatFullDateTime = (dateStr: string): string => {
  return new Date(dateStr).toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
};

// Group logs by date
const groupLogsByDate = (logs: ActivityLog[]): Map<string, ActivityLog[]> => {
  const groups = new Map<string, ActivityLog[]>();
  for (const log of logs) {
    const dateKey = new Date(log.created_at).toLocaleDateString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    if (!groups.has(dateKey)) {
      groups.set(dateKey, []);
    }
    groups.get(dateKey)!.push(log);
  }
  return groups;
};

const AdminActivityLog: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  // Auth state
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentMember, setCurrentMember] = useState<TeamMember | null>(null);

  // Data state
  const [result, setResult] = useState<PaginatedResult<ActivityLog>>({
    data: [], total: 0, page: 1, pageSize: 25, totalPages: 0,
  });
  const [stats, setStats] = useState({
    totalLogs: 0, todayLogs: 0, weekLogs: 0,
    topActors: [] as Array<{ name: string; count: number }>,
    topActions: [] as Array<{ type: string; count: number }>,
  });
  const [actors, setActors] = useState<Array<{ actor_id: string; actor_name: string; actor_role: string | null }>>([]);
  const [actionTypes, setActionTypes] = useState<string[]>([]);

  // Filter state
  const [filters, setFilters] = useState<ActivityLogFilters>({});
  const [searchInput, setSearchInput] = useState('');
  const [page, setPage] = useState(1);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedLog, setSelectedLog] = useState<ActivityLog | null>(null);

  // Check access
  useEffect(() => {
    checkAccess();
  }, []);

  const checkAccess = async () => {
    try {
      let user = null;
      try {
        const { data: { session } } = await supabase.auth.getSession();
        user = session?.user || null;
      } catch {}
      if (!user) {
        try {
          const { data: { user: u } } = await supabase.auth.getUser();
          user = u;
        } catch {}
      }

      if (!user) {
        setIsAuthorized(false);
        setLoading(false);
        return;
      }

      // Fallback owner
      const fallbackMember: TeamMember = {
        id: 'owner-' + user.id,
        user_id: user.id,
        email: user.email || '',
        display_name: 'Propriétaire',
        role: 'owner',
        permissions: DEFAULT_PERMISSIONS['owner'],
        added_by: null,
        is_active: true,
        last_active_at: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      try {
        const { data: member } = await supabase
          .from('team_members')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (member) {
          setCurrentMember(member as TeamMember);
        } else {
          setCurrentMember(fallbackMember);
        }
      } catch {
        setCurrentMember(fallbackMember);
      }

      setIsAuthorized(true);
      setLoading(false);
    } catch {
      setIsAuthorized(false);
      setLoading(false);
    }
  };

  // Load logs
  const loadLogs = useCallback(async (p: number = page, f: ActivityLogFilters = filters) => {
    setIsLoadingLogs(true);
    try {
      const data = await activityLogService.getLogs(f, p, 25);
      setResult(data);
    } catch {
      toast({ title: 'Erreur', description: 'Impossible de charger les logs', variant: 'destructive' });
    } finally {
      setIsLoadingLogs(false);
    }
  }, [page, filters, toast]);

  // Load metadata (stats, actors, action types)
  const loadMetadata = useCallback(async () => {
    try {
      const [s, a, t] = await Promise.all([
        activityLogService.getStats(),
        activityLogService.getDistinctActors(),
        activityLogService.getDistinctActionTypes(),
      ]);
      setStats(s);
      setActors(a);
      setActionTypes(t);
    } catch {
      // Silent
    }
  }, []);

  // Initial load
  useEffect(() => {
    if (isAuthorized) {
      loadLogs(1, {});
      loadMetadata();
    }
  }, [isAuthorized]);

  // Reload when filters or page change
  useEffect(() => {
    if (isAuthorized) {
      loadLogs(page, filters);
    }
  }, [page, filters, isAuthorized]);

  // Search debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchInput !== (filters.search || '')) {
        setPage(1);
        setFilters(prev => ({ ...prev, search: searchInput || undefined }));
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const handleFilterChange = (key: keyof ActivityLogFilters, value: string) => {
    setPage(1);
    setFilters(prev => ({
      ...prev,
      [key]: value === 'all' ? undefined : value || undefined,
    }));
  };

  const clearFilters = () => {
    setPage(1);
    setSearchInput('');
    setFilters({});
  };

  const hasActiveFilters = !!(filters.actionType || filters.actorId || filters.dateFrom || filters.dateTo || filters.search);

  const handleExportCSV = () => {
    if (result.data.length === 0) return;

    const headers = ['Date', 'Acteur', 'Rôle', 'Action', 'Description', 'Cible', 'Ressource'];
    const rows = result.data.map(log => [
      formatFullDateTime(log.created_at),
      log.actor_name,
      log.actor_role || '',
      ACTION_TYPE_LABELS[log.action_type] || log.action_type,
      log.action_description,
      TARGET_TYPE_LABELS[log.target_type || ''] || log.target_type || '',
      log.target_label || log.target_id || '',
    ]);

    const csvContent = [headers, ...rows]
      .map(row => row.map(cell => `"${(cell || '').replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `activity-logs-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'Export réussi', description: `${result.data.length} entrées exportées` });
  };

  // Loading
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-purple-600" />
          <p className="mt-2 text-gray-600">Chargement...</p>
        </div>
      </div>
    );
  }

  // Access denied
  if (!isAuthorized || !currentMember) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <Shield className="w-16 h-16 mx-auto text-red-500 mb-4" />
            <h2 className="text-xl font-bold mb-2">Accès refusé</h2>
            <p className="text-gray-600 mb-4">Vous n'avez pas les permissions nécessaires.</p>
            <Button variant="outline" onClick={() => navigate('/admin')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour au tableau de bord
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const groupedLogs = groupLogsByDate(result.data);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate('/admin')} className="mr-1">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold">Journal d'activité</h1>
              <p className="text-xs text-gray-500">Audit des actions administratives</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleExportCSV} disabled={result.data.length === 0}>
              <Download className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Exporter CSV</span>
            </Button>
            <Button variant="outline" size="sm" onClick={() => { loadLogs(page, filters); loadMetadata(); }}>
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoadingLogs ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Actualiser</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Total actions</p>
                  <p className="text-2xl font-bold mt-1">{stats.totalLogs}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-indigo-50 flex items-center justify-center">
                  <Activity className="w-5 h-5 text-indigo-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Aujourd'hui</p>
                  <p className="text-2xl font-bold mt-1 text-blue-600">{stats.todayLogs}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Cette semaine</p>
                  <p className="text-2xl font-bold mt-1 text-purple-600">{stats.weekLogs}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center">
                  <BarChart3 className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Membres actifs</p>
                  <p className="text-2xl font-bold mt-1 text-green-600">{actors.length}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
                  <Users className="w-5 h-5 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-4 pb-4">
            <div className="flex flex-col gap-3">
              {/* Search + Toggle */}
              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Rechercher dans les logs..."
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Button
                  variant={showFilters ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setShowFilters(!showFilters)}
                  className={showFilters ? 'bg-indigo-600 hover:bg-indigo-700' : ''}
                >
                  <Filter className="w-4 h-4 mr-2" />
                  Filtres
                  {hasActiveFilters && (
                    <span className="ml-1.5 w-5 h-5 rounded-full bg-white/20 text-[10px] flex items-center justify-center font-bold">
                      {[filters.actionType, filters.actorId, filters.dateFrom, filters.dateTo].filter(Boolean).length}
                    </span>
                  )}
                </Button>
                {hasActiveFilters && (
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="text-gray-500">
                    <X className="w-4 h-4 mr-1" />
                    Effacer
                  </Button>
                )}
              </div>

              {/* Expanded filters */}
              {showFilters && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-3 border-t">
                  <div>
                    <Label className="text-xs text-gray-500 mb-1 block">Type d'action</Label>
                    <Select
                      value={filters.actionType || 'all'}
                      onValueChange={(v) => handleFilterChange('actionType', v)}
                    >
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder="Toutes les actions" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Toutes les actions</SelectItem>
                        {(actionTypes.length > 0 ? actionTypes : Object.keys(ACTION_TYPE_LABELS)).map(type => (
                          <SelectItem key={type} value={type}>
                            {ACTION_TYPE_LABELS[type] || type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-xs text-gray-500 mb-1 block">Membre de l'équipe</Label>
                    <Select
                      value={filters.actorId || 'all'}
                      onValueChange={(v) => handleFilterChange('actorId', v)}
                    >
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder="Tous les membres" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tous les membres</SelectItem>
                        {actors.map(actor => (
                          <SelectItem key={actor.actor_id} value={actor.actor_id}>
                            {actor.actor_name} {actor.actor_role ? `(${ROLE_LABELS[actor.actor_role] || actor.actor_role})` : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-xs text-gray-500 mb-1 block">Date début</Label>
                    <Input
                      type="date"
                      value={filters.dateFrom || ''}
                      onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                      className="h-9"
                    />
                  </div>

                  <div>
                    <Label className="text-xs text-gray-500 mb-1 block">Date fin</Label>
                    <Input
                      type="date"
                      value={filters.dateTo || ''}
                      onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                      className="h-9"
                    />
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Results info */}
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>
            {result.total > 0 ? (
              <>
                Affichage de{' '}
                <span className="font-medium text-gray-700">
                  {(result.page - 1) * result.pageSize + 1}
                </span>
                {' '}à{' '}
                <span className="font-medium text-gray-700">
                  {Math.min(result.page * result.pageSize, result.total)}
                </span>
                {' '}sur{' '}
                <span className="font-medium text-gray-700">{result.total}</span>
                {' '}entrées
              </>
            ) : (
              'Aucune entrée trouvée'
            )}
          </span>
          {isLoadingLogs && (
            <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />
          )}
        </div>

        {/* Activity Feed */}
        {result.data.length === 0 && !isLoadingLogs ? (
          <Card>
            <CardContent className="py-16 text-center">
              <Activity className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-semibold text-gray-700 mb-2">Aucune activité enregistrée</h3>
              <p className="text-gray-500 max-w-md mx-auto">
                {hasActiveFilters
                  ? 'Aucun résultat ne correspond à vos filtres. Essayez de modifier vos critères de recherche.'
                  : 'Les actions administratives apparaîtront ici au fur et à mesure qu\'elles sont effectuées.'}
              </p>
              {hasActiveFilters && (
                <Button variant="outline" className="mt-4" onClick={clearFilters}>
                  Effacer les filtres
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {Array.from(groupedLogs.entries()).map(([dateLabel, logs]) => (
              <div key={dateLabel}>
                {/* Date header */}
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex items-center gap-2 bg-white border rounded-full px-3 py-1 shadow-sm">
                    <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                    <span className="text-sm font-medium text-gray-700 capitalize">{dateLabel}</span>
                  </div>
                  <div className="flex-1 h-px bg-gray-200" />
                  <span className="text-xs text-gray-400">{logs.length} action{logs.length > 1 ? 's' : ''}</span>
                </div>

                {/* Timeline */}
                <div className="relative ml-4">
                  {/* Vertical line */}
                  <div className="absolute left-4 top-0 bottom-0 w-px bg-gray-200" />

                  <div className="space-y-1">
                    {logs.map((log, idx) => (
                      <div
                        key={log.id}
                        className={`relative flex items-start gap-4 p-3 rounded-lg transition-all cursor-pointer hover:bg-white hover:shadow-sm group ${
                          selectedLog?.id === log.id ? 'bg-white shadow-sm ring-1 ring-indigo-200' : ''
                        }`}
                        onClick={() => setSelectedLog(selectedLog?.id === log.id ? null : log)}
                      >
                        {/* Timeline dot */}
                        <div className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          ACTION_TYPE_COLORS[log.action_type]?.replace('bg-', 'bg-') || 'bg-gray-100 text-gray-600'
                        }`}>
                          {getActionIcon(log.action_type)}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-medium text-sm text-gray-900">{log.actor_name}</span>
                                <RoleBadge role={log.actor_role} />
                              </div>
                              <p className="text-sm text-gray-700 mt-0.5">{log.action_description}</p>

                              {/* Target info */}
                              {(log.target_type || log.target_label) && (
                                <div className="flex items-center gap-2 mt-1">
                                  {log.target_type && (
                                    <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                                      {TARGET_TYPE_LABELS[log.target_type] || log.target_type}
                                    </Badge>
                                  )}
                                  {log.target_label && (
                                    <span className="text-xs text-gray-500 truncate max-w-[200px]">
                                      {log.target_label}
                                    </span>
                                  )}
                                  {log.target_id && !log.target_label && (
                                    <span className="text-xs text-gray-400 font-mono truncate max-w-[120px]">
                                      {log.target_id}
                                    </span>
                                  )}
                                </div>
                              )}

                              {/* Expanded metadata */}
                              {selectedLog?.id === log.id && log.metadata && Object.keys(log.metadata).length > 0 && (
                                <div className="mt-2 p-2 bg-gray-50 rounded border text-xs font-mono text-gray-600 max-h-32 overflow-auto">
                                  <pre className="whitespace-pre-wrap">{JSON.stringify(log.metadata, null, 2)}</pre>
                                </div>
                              )}
                            </div>

                            {/* Timestamp */}
                            <div className="flex flex-col items-end flex-shrink-0">
                              <span className="text-xs text-gray-400 whitespace-nowrap">
                                {formatRelativeTime(log.created_at)}
                              </span>
                              <span className="text-[10px] text-gray-300 whitespace-nowrap mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                {new Date(log.created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {result.totalPages > 1 && (
          <div className="flex items-center justify-between pt-4 pb-8">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => setPage(p => Math.max(1, p - 1))}
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Précédent
            </Button>

            <div className="flex items-center gap-1">
              {generatePageNumbers(page, result.totalPages).map((p, i) => (
                p === '...' ? (
                  <span key={`ellipsis-${i}`} className="px-2 text-gray-400">...</span>
                ) : (
                  <Button
                    key={p}
                    variant={page === p ? 'default' : 'outline'}
                    size="sm"
                    className={`w-9 h-9 p-0 ${page === p ? 'bg-indigo-600 hover:bg-indigo-700' : ''}`}
                    onClick={() => setPage(p as number)}
                  >
                    {p}
                  </Button>
                )
              ))}
            </div>

            <Button
              variant="outline"
              size="sm"
              disabled={page >= result.totalPages}
              onClick={() => setPage(p => Math.min(result.totalPages, p + 1))}
            >
              Suivant
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        )}
      </main>
    </div>
  );
};

// Generate page numbers with ellipsis
function generatePageNumbers(current: number, total: number): (number | string)[] {
  if (total <= 7) {
    return Array.from({ length: total }, (_, i) => i + 1);
  }

  const pages: (number | string)[] = [];

  if (current <= 3) {
    pages.push(1, 2, 3, 4, '...', total);
  } else if (current >= total - 2) {
    pages.push(1, '...', total - 3, total - 2, total - 1, total);
  } else {
    pages.push(1, '...', current - 1, current, current + 1, '...', total);
  }

  return pages;
}

export default AdminActivityLog;
