import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import FollowButton from '@/components/FollowButton';
import AuthModal from '@/components/AuthModal';
import SupportRequestForm from '@/components/SupportRequestForm';
import { VerificationRequestForm } from '@/components/VerificationRequestForm';
import { VerificationBadge, VerificationStatus } from '@/components/VerificationBadge';
import { getCreatorVerificationRequest, VerificationRequest } from '@/lib/verificationService';
import { MessageSquare, BadgeCheck, Shield, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface CreatorData {
  id: string;
  user_id: string;
  username: string;
  display_name: string;
  bio: string | null;
  avatar_url: string | null;
  whatsapp_number: string | null;
  is_verified: boolean;
  followers_count: number;
  total_views: number;
  total_live_duration_seconds: number;
  live_count: number;
  average_viewers: number;
  created_at: string;
}

interface PastLive {
  id: string;
  title: string;
  thumbnail_url: string;
  viewer_count: number;
  peak_viewers: number;
  duration_seconds: number;
  started_at: string;
  ended_at: string;
  total_messages: number;
}

// ============================================================================
// Demo data for when Supabase is not configured or tables don't exist
// ============================================================================
const DEMO_CREATORS: Record<string, CreatorData> = {
  'demo': {
    id: 'demo-id-1',
    user_id: 'demo-user-1',
    username: 'demo',
    display_name: 'Créateur Demo',
    bio: 'Bienvenue sur mon profil PitchCI ! Je fais des lives sur la tech, la musique et le lifestyle. Rejoignez ma communauté !',
    avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face',
    whatsapp_number: null,
    is_verified: true,
    followers_count: 1250,
    total_views: 45200,
    total_live_duration_seconds: 86400,
    live_count: 24,
    average_viewers: 85,
    created_at: '2025-06-15T10:00:00Z',
  },
};

const DEMO_PAST_LIVES: PastLive[] = [
  {
    id: 'demo-live-1',
    title: 'Live Tech: Les nouveautés 2026',
    thumbnail_url: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400&h=225&fit=crop',
    viewer_count: 320,
    peak_viewers: 450,
    duration_seconds: 5400,
    started_at: '2026-02-28T18:00:00Z',
    ended_at: '2026-02-28T19:30:00Z',
    total_messages: 245,
  },
  {
    id: 'demo-live-2',
    title: 'Session musique acoustique',
    thumbnail_url: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400&h=225&fit=crop',
    viewer_count: 180,
    peak_viewers: 220,
    duration_seconds: 3600,
    started_at: '2026-02-25T20:00:00Z',
    ended_at: '2026-02-25T21:00:00Z',
    total_messages: 156,
  },
  {
    id: 'demo-live-3',
    title: 'Q&A avec la communauté',
    thumbnail_url: 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=400&h=225&fit=crop',
    viewer_count: 95,
    peak_viewers: 130,
    duration_seconds: 2700,
    started_at: '2026-02-20T19:00:00Z',
    ended_at: '2026-02-20T19:45:00Z',
    total_messages: 89,
  },
];

const CreatorProfilePage: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const navigate = useNavigate();
  const { user, creatorProfile } = useAppContext();
  
  const [creator, setCreator] = useState<CreatorData | null>(null);
  const [pastLives, setPastLives] = useState<PastLive[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [showSupport, setShowSupport] = useState(false);
  const [showVerificationForm, setShowVerificationForm] = useState(false);
  const [verificationRequest, setVerificationRequest] = useState<VerificationRequest | null>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const isOwnProfile = creatorProfile?.username === username;

  // Fetch verification request for own profile
  useEffect(() => {
    const fetchVerificationStatus = async () => {
      if (isOwnProfile && creatorProfile && !creatorProfile.is_verified) {
        try {
          const request = await getCreatorVerificationRequest(creatorProfile.id);
          setVerificationRequest(request);
        } catch (err) {
          console.warn('[CreatorProfile] Verification status fetch failed:', err);
        }
      }
    };
    fetchVerificationStatus();
  }, [isOwnProfile, creatorProfile]);

  useEffect(() => {
    const fetchCreatorData = async () => {
      // Guard against invalid username params
      if (!username || username === ':username' || username.startsWith(':')) {
        setLoading(false);
        return;
      }
      
      setLoading(true);
      setIsDemoMode(false);
      
      // If Supabase is not configured, use demo data
      if (!isSupabaseConfigured) {
        console.info('[CreatorProfile] Supabase not configured — using demo data');
        const demoCreator = DEMO_CREATORS[username] || {
          ...DEMO_CREATORS['demo'],
          username: username,
          display_name: username.charAt(0).toUpperCase() + username.slice(1),
        };
        setCreator(demoCreator);
        setPastLives(DEMO_PAST_LIVES);
        setIsDemoMode(true);
        setLoading(false);
        return;
      }
      
      try {
        // Fetch creator profile
        const { data: creatorData, error: creatorError } = await supabase
          .from('creator_profiles')
          .select('*')
          .eq('username', username)
          .maybeSingle();

        if (creatorError) {
          console.error('Error fetching creator:', creatorError);
          
          // If table doesn't exist or RLS error, fall back to demo mode
          const errCode = creatorError.code || '';
          const errMsg = (creatorError.message || '').toLowerCase();
          if (
            errCode === '42P01' || // table doesn't exist
            errCode.startsWith('PGRST') || // PostgREST error
            errMsg.includes('does not exist') ||
            errMsg.includes('not found') ||
            errMsg.includes('404')
          ) {
            console.warn('[CreatorProfile] Tables missing — falling back to demo mode');
            const demoCreator = DEMO_CREATORS[username] || {
              ...DEMO_CREATORS['demo'],
              username: username,
              display_name: username.charAt(0).toUpperCase() + username.slice(1),
            };
            setCreator(demoCreator);
            setPastLives(DEMO_PAST_LIVES);
            setIsDemoMode(true);
            setLoading(false);
            return;
          }
          
          setLoading(false);
          return;
        }

        // If no creator found, show not found
        if (!creatorData) {
          setLoading(false);
          return;
        }

        setCreator(creatorData);

        // Fetch past lives
        try {
          const { data: livesData, error: livesError } = await supabase
            .from('live_streams')
            .select('*')
            .eq('creator_id', creatorData.user_id)
            .eq('is_live', false)
            .order('ended_at', { ascending: false })
            .limit(20);

          if (!livesError && livesData) {
            setPastLives(livesData);
          }
        } catch (err) {
          console.warn('[CreatorProfile] Past lives fetch failed:', err);
        }

        // Check if current user follows this creator
        if (user) {
          try {
            const { data: followData } = await supabase
              .from('follows')
              .select('id')
              .eq('follower_id', user.id)
              .eq('creator_id', creatorData.user_id)
              .maybeSingle();

            setIsFollowing(!!followData);
          } catch (err) {
            console.warn('[CreatorProfile] Follow check failed:', err);
          }
        }

      } catch (err) {
        console.error('Error:', err);
        
        // On any unexpected error, try demo mode
        console.warn('[CreatorProfile] Unexpected error — falling back to demo mode');
        const demoCreator = DEMO_CREATORS[username] || {
          ...DEMO_CREATORS['demo'],
          username: username,
          display_name: username.charAt(0).toUpperCase() + username.slice(1),
        };
        setCreator(demoCreator);
        setPastLives(DEMO_PAST_LIVES);
        setIsDemoMode(true);
      } finally {
        setLoading(false);
      }
    };

    fetchCreatorData();
  }, [username, user]);



  const formatDuration = (seconds: number): string => {
    if (!seconds) return '0s';
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}min`;
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${mins}min`;
  };

  const formatCount = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  const openWhatsApp = () => {
    if (!creator?.whatsapp_number) return;
    const message = encodeURIComponent(`Salut ${creator.display_name}! Je viens de voir ton profil sur PitchCI`);
    const cleanNumber = creator.whatsapp_number.replace(/[^0-9+]/g, '');
    window.open(`https://wa.me/${cleanNumber}?text=${message}`, '_blank');
  };

  const handleFollowChange = (following: boolean) => {
    setIsFollowing(following);
    if (creator) {
      setCreator({
        ...creator,
        followers_count: following 
          ? creator.followers_count + 1 
          : Math.max(0, creator.followers_count - 1)
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  if (!creator) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center text-white p-4">
        <svg className="w-20 h-20 text-gray-600 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
        <h2 className="text-xl font-semibold mb-2">Créateur non trouvé</h2>
        <p className="text-gray-400 mb-6">Ce profil n'existe pas ou a été supprimé.</p>
        <button
          onClick={() => navigate('/')}
          className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-full transition-colors"
        >
          Retour à l'accueil
        </button>
      </div>
    );
  }

  const averageLiveDuration = creator.live_count > 0 
    ? Math.floor(creator.total_live_duration_seconds / creator.live_count) 
    : 0;

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Demo Mode Banner */}
      {isDemoMode && (
        <div className="bg-amber-500/10 border-b border-amber-500/20">
          <div className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-3">
            <svg className="w-5 h-5 text-amber-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-amber-300 text-sm">
              <strong>Mode démonstration</strong> — Profil avec données fictives. {!isSupabaseConfigured ? 'Configurez Supabase pour voir les vrais profils.' : 'Les tables de la base de données ne sont pas encore créées.'}
            </p>
            {!isSupabaseConfigured && (
              <button
                onClick={() => navigate('/setup')}
                className="ml-auto text-xs bg-amber-500/20 border border-amber-500/30 text-amber-300 px-3 py-1 rounded-lg hover:bg-amber-500/30 transition-colors flex-shrink-0"
              >
                Configurer
              </button>
            )}
          </div>
        </div>
      )}

      {/* Header with back button */}
      <div className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div>
            <h1 className="font-semibold">{creator.display_name}</h1>
            <p className="text-gray-400 text-sm">@{creator.username}</p>
          </div>
        </div>
      </div>

      {/* Profile Header */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          {/* Avatar */}
          <div className="relative">
            <img
              src={creator.avatar_url || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop'}
              alt={creator.display_name}
              className="w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover border-4 border-purple-500/50"
            />
            {creator.is_verified && (
              <div className="absolute bottom-2 right-2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center border-2 border-black">
                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-col sm:flex-row items-center gap-3 mb-4">
              <h2 className="text-2xl font-bold">{creator.display_name}</h2>
              {creator.is_verified && (
                <span className="bg-blue-500/20 text-blue-400 text-xs px-2 py-1 rounded-full">
                  Vérifié
                </span>
              )}
            </div>

            {creator.bio && (
              <p className="text-gray-300 mb-4 max-w-lg">{creator.bio}</p>
            )}

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3">
              {!isDemoMode && (
                <FollowButton
                  creatorId={creator.user_id}
                  creatorName={creator.display_name}
                  followerCount={creator.followers_count}
                  showCount={false}
                  size="lg"
                  onFollowChange={handleFollowChange}
                />
              )}

              {isDemoMode && (
                <button
                  onClick={() => setShowAuth(true)}
                  className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-5 py-2 rounded-full transition-colors"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Suivre
                </button>
              )}

              {creator.whatsapp_number && (
                <button
                  onClick={openWhatsApp}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-full transition-colors"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  WhatsApp
                </button>
              )}

              <button
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: creator.display_name,
                      text: `Découvrez ${creator.display_name} sur PitchCI!`,
                      url: window.location.href,
                    });
                  } else {
                    navigator.clipboard.writeText(window.location.href);
                  }
                }}
                className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8">
          <div className="bg-gradient-to-br from-purple-900/50 to-purple-800/30 rounded-2xl p-4 text-center border border-purple-700/30">
            <div className="flex items-center justify-center mb-2">
              <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <p className="text-2xl font-bold text-white">{formatCount(creator.followers_count)}</p>
            <p className="text-gray-400 text-sm">Abonnés</p>
          </div>

          <div className="bg-gradient-to-br from-pink-900/50 to-pink-800/30 rounded-2xl p-4 text-center border border-pink-700/30">
            <div className="flex items-center justify-center mb-2">
              <svg className="w-6 h-6 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
            </div>
            <p className="text-2xl font-bold text-white">{formatCount(creator.total_views)}</p>
            <p className="text-gray-400 text-sm">Vues totales</p>
          </div>

          <div className="bg-gradient-to-br from-blue-900/50 to-blue-800/30 rounded-2xl p-4 text-center border border-blue-700/30">
            <div className="flex items-center justify-center mb-2">
              <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-2xl font-bold text-white">{formatDuration(averageLiveDuration)}</p>
            <p className="text-gray-400 text-sm">Durée moyenne</p>
          </div>

          <div className="bg-gradient-to-br from-green-900/50 to-green-800/30 rounded-2xl p-4 text-center border border-green-700/30">
            <div className="flex items-center justify-center mb-2">
              <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-2xl font-bold text-white">{creator.live_count}</p>
            <p className="text-gray-400 text-sm">Lives réalisés</p>
          </div>
        </div>

        {/* Past Lives Section */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
            Lives passés
            {isDemoMode && <span className="text-xs text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">(démo)</span>}
          </h3>

          {pastLives.length === 0 ? (
            <div className="text-center py-12 bg-gray-900/50 rounded-xl">
              <svg className="w-16 h-16 text-gray-700 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              <p className="text-gray-400">Aucun live passé pour le moment</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {pastLives.map((live) => (
                <div
                  key={live.id}
                  className="bg-gray-900 rounded-xl overflow-hidden hover:ring-2 hover:ring-purple-500/50 transition-all cursor-pointer group"
                >
                  <div className="relative aspect-video">
                    <img
                      src={live.thumbnail_url || 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=400&h=225&fit=crop'}
                      alt={live.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                    
                    <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                      <span className="bg-black/60 text-white text-xs px-2 py-1 rounded">
                        {formatDuration(live.duration_seconds)}
                      </span>
                      <span className="bg-black/60 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                        <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                        </svg>
                        {formatCount(live.peak_viewers || live.viewer_count)}
                      </span>
                    </div>
                  </div>
                  <div className="p-3">
                    <h3 className="font-medium text-white line-clamp-2 mb-1">{live.title}</h3>
                    <p className="text-gray-500 text-sm">{formatDate(live.started_at)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>


        {/* Verification Section for own profile */}
        {isOwnProfile && !creator.is_verified && !isDemoMode && (
          <div className="mt-8 p-4 bg-gradient-to-r from-blue-900/30 to-purple-900/30 rounded-xl border border-blue-700/30">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <BadgeCheck className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Obtenez le badge vérifié</h4>
                  <p className="text-sm text-gray-400">
                    Vérifiez votre identité pour gagner la confiance de votre audience
                  </p>
                  {verificationRequest && (
                    <div className="mt-2">
                      <VerificationStatus status={verificationRequest.status} />
                      {verificationRequest.status === 'rejected' && verificationRequest.rejection_reason && (
                        <p className="text-sm text-red-400 mt-1">
                          Raison: {verificationRequest.rejection_reason}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
              {(!verificationRequest || verificationRequest.status === 'rejected') && (
                <Button
                  onClick={() => setShowVerificationForm(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  {verificationRequest?.status === 'rejected' ? 'Soumettre à nouveau' : 'Demander la vérification'}
                </Button>
              )}
            </div>
          </div>
        )}

        {/* Support Button for own profile */}
        {isOwnProfile && !isDemoMode && (
          <div className="mt-8 p-4 bg-gray-900/50 rounded-xl border border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-white">Besoin d'aide ?</h4>
                <p className="text-sm text-gray-400">Contactez notre équipe support</p>
              </div>
              <button
                onClick={() => setShowSupport(true)}
                className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                Contacter le support
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Auth Modal */}
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />
      
      {/* Support Request Modal */}
      <SupportRequestForm isOpen={showSupport} onClose={() => setShowSupport(false)} />

      {/* Verification Request Modal */}
      <Dialog open={showVerificationForm} onOpenChange={setShowVerificationForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 text-white border-gray-700">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BadgeCheck className="w-5 h-5 text-blue-500" />
              Demande de vérification
            </DialogTitle>
          </DialogHeader>
          {creatorProfile && user && (
            <VerificationRequestForm
              creatorId={creatorProfile.id}
              userId={user.id}
              onSuccess={() => {
                setShowVerificationForm(false);
                // Refresh verification status
                getCreatorVerificationRequest(creatorProfile.id).then(setVerificationRequest);
              }}
              onCancel={() => setShowVerificationForm(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CreatorProfilePage;
