import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  supabase,
  isSupabaseConfigured,
  isRuntimeConfigured,
  saveRuntimeCredentials,
  clearRuntimeCredentials,
  getRuntimeCredentials,
  testCredentials,
} from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import { DEFAULT_PERMISSIONS } from '@/lib/teamService';
import { MIGRATION_SQL } from '@/lib/migrationSql';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import EmailNotConfirmedHelper from '@/components/EmailNotConfirmedHelper';
import EdgeFunctionGuide from '@/components/EdgeFunctionGuide';
import DatabaseSetupWizard from '@/components/DatabaseSetupWizard';
import {
  Crown, Shield, CheckCircle, Loader2, AlertTriangle,
  ArrowRight, Lock, Users, Radio, CreditCard, Eye,
  MessageSquare, BadgeCheck, Settings, LogIn, UserPlus,
  Database, Key, Globe, Link2, RefreshCw, Trash2,
  ExternalLink, Zap, Server, ChevronDown, ChevronUp,
  Wrench, Copy, ClipboardCheck,
} from 'lucide-react';



type SetupStep = 'loading' | 'not-configured' | 'not-authenticated' | 'owner-exists' | 'needs-migration' | 'ready' | 'confirming' | 'edge-function-setup' | 'success';
type SetupTab = 'config' | 'database';




const OWNER_PERMISSIONS = DEFAULT_PERMISSIONS.owner;

const PERMISSION_ITEMS = [
  { key: 'view_dashboard', label: 'Voir le tableau de bord', icon: Eye, color: 'text-blue-500' },
  { key: 'manage_streams', label: 'Gérer les lives', icon: Radio, color: 'text-red-500' },
  { key: 'moderate_chat', label: 'Modérer le chat', icon: MessageSquare, color: 'text-green-500' },
  { key: 'manage_creators', label: 'Gérer les créateurs', icon: Users, color: 'text-purple-500' },
  { key: 'manage_subscriptions', label: 'Gérer les abonnements', icon: CreditCard, color: 'text-orange-500' },
  { key: 'manage_team', label: "Gérer l'équipe", icon: Settings, color: 'text-indigo-500' },
  { key: 'view_payments', label: 'Voir les paiements', icon: CreditCard, color: 'text-emerald-500' },
  { key: 'manage_verification', label: 'Gérer les vérifications', icon: BadgeCheck, color: 'text-cyan-500' },
];

/** Detect if an error indicates the database schema is incomplete (missing columns/functions/recursion/null id) */
function isMigrationError(error: any): boolean {
  if (!error) return false;
  const code = error.code || '';
  const msg = (error.message || '').toLowerCase();
  return (
    code === 'PGRST202' || // Function not found
    code === 'PGRST204' || // Column not found in schema cache
    code === '42703' ||     // Column does not exist
    code === '42P01' ||     // Table does not exist
    code === '42P17' ||     // Infinite recursion detected in policy
    code === '23502' ||     // NOT NULL violation (e.g. id column has no default)
    msg.includes('does not exist') ||
    msg.includes('schema cache') ||
    msg.includes('could not find') ||
    msg.includes('infinite recursion') ||
    msg.includes('recursion detected') ||
    msg.includes('null value in column') ||
    msg.includes('not-null constraint')
  );
}



const SetupPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading: authLoading, signIn, signUp } = useAppContext();

  // ---- Tab state (supports ?tab=database URL param) ----
  const activeTab: SetupTab = (searchParams.get('tab') as SetupTab) === 'database' ? 'database' : 'config';
  const setActiveTab = (tab: SetupTab) => {
    setSearchParams(tab === 'config' ? {} : { tab });
  };

  const [step, setStep] = useState<SetupStep>('loading');
  const [displayName, setDisplayName] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const [existingOwnerEmail, setExistingOwnerEmail] = useState('');

  // ---- Migration state ----
  const [migrationSql, setMigrationSql] = useState('');
  const [migrationDiagnostics, setMigrationDiagnostics] = useState<any[]>([]);
  const [isMigrating, setIsMigrating] = useState(false);
  const [sqlCopied, setSqlCopied] = useState(false);
  const [migrationError, setMigrationError] = useState('');

  // ---- Supabase credentials form state ----
  const [sbUrl, setSbUrl] = useState('');
  const [sbAnonKey, setSbAnonKey] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; error?: string } | null>(null);
  const [showAnonKey, setShowAnonKey] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Auth form state (inline)
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authConfirmPassword, setAuthConfirmPassword] = useState('');
  const [authLoading2, setAuthLoading2] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');
  const [showEmailNotConfirmed, setShowEmailNotConfirmed] = useState(false);
  const [emailErrorType, setEmailErrorType] = useState<'email_not_confirmed' | 'email_sending_failed'>('email_not_confirmed');



  // Load existing runtime credentials if any
  useEffect(() => {
    const creds = getRuntimeCredentials();
    if (creds.url) setSbUrl(creds.url);
    if (creds.anonKey) setSbAnonKey(creds.anonKey);
  }, []);

  // ---- Fetch migration SQL from edge function (with hardcoded fallback) ----
  const fetchMigrationInfo = useCallback(async () => {
    setIsMigrating(true);
    setMigrationError('');
    try {
      const { data, error: fnError } = await supabase.functions.invoke('run-migrations', {
        body: { action: 'diagnose' },
      });

      if (fnError) {
        console.warn('[Setup] run-migrations edge function error (using hardcoded SQL):', fnError.message);
        // FALLBACK: Use the hardcoded migration SQL instead of showing an error
        setMigrationSql(MIGRATION_SQL);
        // Don't show the edge function error — the user just needs the SQL
        return;
      }

      // Edge function responded — use its data if available
      if (data?.fix_sql) {
        setMigrationSql(data.fix_sql);
      } else {
        // Edge function responded but no SQL — use hardcoded
        setMigrationSql(MIGRATION_SQL);
      }
      if (data?.diagnostics) {
        setMigrationDiagnostics(data.diagnostics);
      }
      if (data?.needs_fix === false) {
        // Database is actually fine — retry setup
        toast({ title: 'Base de données OK !', description: 'Nouvelle tentative de configuration...' });
        setStep('ready');
        return;
      }
    } catch (err: any) {
      console.warn('[Setup] Migration fetch error (using hardcoded SQL):', err?.message);
      // FALLBACK: Always provide the hardcoded SQL
      setMigrationSql(MIGRATION_SQL);
    } finally {
      setIsMigrating(false);
    }
  }, [toast]);

  // ---- Transition to migration step ----
  const goToMigrationStep = useCallback(async (errorDetails?: string) => {
    setStep('needs-migration');
    // Always pre-load the hardcoded SQL immediately so the user never sees "no SQL"
    if (!migrationSql) {
      setMigrationSql(MIGRATION_SQL);
    }
    setMigrationError(errorDetails || '');
    await fetchMigrationInfo();
  }, [fetchMigrationInfo, migrationSql]);


  // Check the current state
  const checkSetupState = useCallback(async () => {
    if (!isSupabaseConfigured) {
      setStep('not-configured');
      return;
    }
    if (authLoading) return;
    if (!isAuthenticated || !user) {
      setStep('not-authenticated');
      return;
    }

    try {
      // Use SECURITY DEFINER RPC to bypass RLS
      const { data: ownerCheck, error: rpcError } = await supabase.rpc('check_owner_exists');

      if (rpcError) {
        console.warn('[Setup] RPC check_owner_exists error:', rpcError.code, rpcError.message);

        // If the RPC function doesn't exist, we need migration
        if (isMigrationError(rpcError)) {
          await goToMigrationStep(rpcError.message);
          return;
        }

        // Fallback: direct query (may fail due to RLS but try anyway)
        const { data: owners, error: ownersError } = await supabase
          .from('team_members')
          .select('*')
          .eq('role', 'owner');

        if (ownersError && isMigrationError(ownersError)) {
          await goToMigrationStep(ownersError.message);
          return;
        }

        if (owners && owners.length > 0) {
          const currentUserIsOwner = owners.some((o: any) => o.user_id === user.id);
          if (currentUserIsOwner) {
            setStep('success');
            setTimeout(() => navigate('/admin'), 1500);
            return;
          }
          setExistingOwnerEmail((owners[0] as any).email || 'inconnu');
          setStep('owner-exists');
          return;
        }
        setStep('ready');
        setDisplayName(user.email?.split('@')[0] || 'Propriétaire');
        return;
      }

      const result = ownerCheck as any;
      if (result?.exists) {
        if (result.owner_user_id === user.id) {
          setStep('success');
          setTimeout(() => navigate('/admin'), 1500);
          return;
        }
        setExistingOwnerEmail(result.owner_email || result.owner_name || 'inconnu');
        setStep('owner-exists');
        return;
      }

      setStep('ready');
      setDisplayName(user.email?.split('@')[0] || 'Propriétaire');
    } catch (err: any) {
      console.error('[Setup] Error:', err);
      setStep('ready');
      setDisplayName(user.email?.split('@')[0] || 'Propriétaire');
    }
  }, [isAuthenticated, user, authLoading, navigate, goToMigrationStep]);

  useEffect(() => {
    checkSetupState();
  }, [checkSetupState]);

  // ---- Handle Supabase credentials test ----
  const handleTestConnection = async () => {
    if (!sbUrl.trim() || !sbAnonKey.trim()) {
      setTestResult({ success: false, error: 'Veuillez remplir les deux champs.' });
      return;
    }
    setIsTesting(true);
    setTestResult(null);
    try {
      const result = await testCredentials(sbUrl.trim(), sbAnonKey.trim());
      setTestResult(result);
    } catch (err: any) {
      setTestResult({ success: false, error: err?.message || 'Erreur inattendue.' });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSaveCredentials = async () => {
    if (!sbUrl.trim() || !sbAnonKey.trim()) {
      setTestResult({ success: false, error: 'Veuillez remplir les deux champs.' });
      return;
    }
    if (!testResult?.success) {
      setIsTesting(true);
      setTestResult(null);
      try {
        const result = await testCredentials(sbUrl.trim(), sbAnonKey.trim());
        setTestResult(result);
        if (!result.success) { setIsTesting(false); return; }
      } catch (err: any) {
        setTestResult({ success: false, error: err?.message || 'Erreur inattendue.' });
        setIsTesting(false);
        return;
      }
      setIsTesting(false);
    }
    saveRuntimeCredentials(sbUrl.trim(), sbAnonKey.trim());
    toast({ title: 'Clés sauvegardées !', description: 'Rechargement...' });
    setTimeout(() => { window.location.reload(); }, 1000);
  };

  const handleClearCredentials = () => {
    clearRuntimeCredentials();
    setSbUrl(''); setSbAnonKey(''); setTestResult(null);
    toast({ title: 'Clés supprimées', description: 'Rechargement...' });
    setTimeout(() => { window.location.reload(); }, 1000);
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(''); setAuthSuccess(''); setShowEmailNotConfirmed(false);
    if (authMode === 'signup') {
      if (authPassword.length < 6) { setAuthError('Le mot de passe doit contenir au moins 6 caractères.'); return; }
      if (authPassword !== authConfirmPassword) { setAuthError('Les mots de passe ne correspondent pas.'); return; }
    }
    setAuthLoading2(true);
    try {
      const result = authMode === 'signup' ? await signUp(authEmail, authPassword) : await signIn(authEmail, authPassword);
      if (result.success) {
        setAuthSuccess(authMode === 'signup' ? 'Compte créé ! Vérifiez votre email.' : 'Connexion réussie !');
      } else {
        setAuthError(result.error || 'Une erreur est survenue.');
        if (result.errorCode === 'email_not_confirmed' || result.errorCode === 'email_sending_failed') {
          setShowEmailNotConfirmed(true);
          setEmailErrorType(result.errorCode as any);
        }
      }
    } catch { setAuthError('Une erreur inattendue est survenue.'); }
    finally { setAuthLoading2(false); }
  };

  // ---- Copy SQL to clipboard ----
  const handleCopySql = async () => {
    try {
      await navigator.clipboard.writeText(migrationSql);
      setSqlCopied(true);
      toast({ title: 'SQL copié !', description: 'Collez-le dans le SQL Editor de Supabase.' });
      setTimeout(() => setSqlCopied(false), 3000);
    } catch {
      // Fallback for older browsers
      const textarea = document.createElement('textarea');
      textarea.value = migrationSql;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setSqlCopied(true);
      toast({ title: 'SQL copié !' });
      setTimeout(() => setSqlCopied(false), 3000);
    }
  };

  // ---- Retry after migration ----
  const handleRetryAfterMigration = async () => {
    setIsMigrating(true);
    setMigrationError('');
    try {
      // Try the edge function first for diagnostics
      let edgeFunctionWorked = false;
      try {
        const { data, error: fnError } = await supabase.functions.invoke('run-migrations', {
          body: { action: 'diagnose' },
        });

        if (!fnError && data) {
          edgeFunctionWorked = true;
          if (data.needs_fix === false) {
            toast({ title: 'Migration réussie !', description: 'La base de données est maintenant correcte.' });
            setStep('loading');
            setTimeout(() => checkSetupState(), 500);
            return;
          } else {
            setMigrationError('La migration n\'a pas encore été appliquée. Veuillez exécuter le SQL dans le SQL Editor de Supabase, puis réessayer.');
            if (data.diagnostics) {
              setMigrationDiagnostics(data.diagnostics);
            }
            return;
          }
        }
      } catch {
        // Edge function failed — try direct database check below
      }

      // FALLBACK: If edge function didn't work, check the database directly
      if (!edgeFunctionWorked) {
        console.warn('[Setup] Edge function unavailable, checking database directly...');

        // Try calling the RPC function — if it works, migration was applied
        const { data: ownerCheck, error: rpcError } = await supabase.rpc('check_owner_exists');

        if (!rpcError) {
          // RPC function exists — migration was applied!
          toast({ title: 'Migration réussie !', description: 'La base de données est maintenant correcte.' });
          setStep('loading');
          setTimeout(() => checkSetupState(), 500);
          return;
        }

        if (isMigrationError(rpcError)) {
          setMigrationError('La migration n\'a pas encore été appliquée. Veuillez exécuter le SQL dans le SQL Editor de Supabase, puis réessayer.');
          return;
        }

        // Try a direct table query as last resort
        const { error: tableError } = await supabase
          .from('team_members')
          .select('user_id, email, role')
          .limit(1);

        if (!tableError) {
          // Table exists with correct columns — migration was applied!
          toast({ title: 'Migration réussie !', description: 'La base de données est maintenant correcte.' });
          setStep('loading');
          setTimeout(() => checkSetupState(), 500);
          return;
        }

        if (isMigrationError(tableError)) {
          setMigrationError('La migration n\'a pas encore été appliquée. Veuillez exécuter le SQL dans le SQL Editor de Supabase, puis réessayer.');
        } else {
          // Some other error — might be RLS, which means the table exists
          toast({ title: 'Migration détectée !', description: 'Nouvelle tentative de configuration...' });
          setStep('loading');
          setTimeout(() => checkSetupState(), 500);
        }
      }
    } catch (err: any) {
      setMigrationError(err?.message || 'Erreur lors de la vérification.');
    } finally {
      setIsMigrating(false);
    }
  };


  // Handle owner registration — uses SECURITY DEFINER RPC to bypass RLS/constraint issues
  const handleRegisterAsOwner = async () => {
    if (!user) return;
    if (!displayName.trim()) { setError('Veuillez entrer un nom d\'affichage.'); return; }

    setIsProcessing(true);
    setError('');

    try {
      // Use the SECURITY DEFINER RPC function that handles everything atomically
      const { data: rpcResult, error: rpcError } = await supabase.rpc('setup_platform_owner', {
        p_user_id: user.id,
        p_email: user.email,
        p_display_name: displayName.trim(),
      });

      if (rpcError) {
        console.error('[Setup] RPC error:', JSON.stringify(rpcError));

        // Check if this is a migration issue
        if (isMigrationError(rpcError)) {
          setIsProcessing(false);
          await goToMigrationStep(rpcError.message);
          return;
        }

        // Fallback: try direct insert/update approach
        await fallbackRegisterOwner();
        return;
      }

      console.log('[Setup] RPC result:', JSON.stringify(rpcResult));

      const result = rpcResult as any;

      const isSuccess =
        result?.success === true ||
        !!result?.team_id ||
        !!result?.member_id ||
        !!result?.id;

      const isOwnerExists =
        result?.success === false && (result?.message === 'owner_exists' || result?.owner_exists);

      if (isOwnerExists) {
        setExistingOwnerEmail(result.owner_email || 'inconnu');
        setStep('owner-exists');
      } else if (isSuccess) {
        toast({ title: 'Configuration terminée !', description: 'Vous êtes maintenant le propriétaire.' });
        if (result?.message === 'already_owner' || result?.already_owner) {
          setStep('success');
          setTimeout(() => navigate('/admin'), 1500);
        } else {
          setStep('edge-function-setup');
        }
      } else {
        if (result && typeof result === 'object' && Object.keys(result).length > 0) {
          console.warn('[Setup] RPC returned unrecognized shape, treating as success:', result);
          toast({ title: 'Configuration terminée !', description: 'Vous êtes maintenant le propriétaire.' });
          setStep('edge-function-setup');
        } else {
          const errorMsg = result?.message || result?.error || 'Erreur lors de l\'enregistrement.';
          console.error('[Setup] RPC returned failure:', result);
          setError(typeof errorMsg === 'string' ? errorMsg : JSON.stringify(errorMsg));
        }
      }

    } catch (err: any) {
      console.error('[Setup] Unexpected error:', err);
      await fallbackRegisterOwner();
    } finally {
      setIsProcessing(false);
    }
  };


  // Fallback if RPC is not available — handles missing columns gracefully
  const fallbackRegisterOwner = async () => {
    if (!user) return;
    try {
      // Try selecting with wildcard to avoid column-not-found errors
      const { data: existingTeamMember, error: selectError } = await supabase
        .from('team_members').select('*').eq('user_id', user.id).maybeSingle();

      // If the table or columns don't exist, go to migration step
      if (selectError && isMigrationError(selectError)) {
        await goToMigrationStep(selectError.message);
        return;
      }

      if (existingTeamMember) {
        const { error: updateError } = await supabase.from('team_members')
          .update({
            role: 'owner',
            permissions: OWNER_PERMISSIONS,
            updated_at: new Date().toISOString(),
            // Only include email/display_name if the columns exist (they should after migration)
            ...(user.email ? { email: user.email } : {}),
            ...(displayName.trim() ? { display_name: displayName.trim() } : {}),
          })
          .eq('user_id', user.id);

        if (updateError) {
          if (isMigrationError(updateError)) {
            await goToMigrationStep(updateError.message);
            return;
          }
          setError(`Erreur: ${updateError.message}`);
          return;
        }
      } else {
        // CRITICAL: Explicitly provide `id` to prevent 23502 (null id) errors
        // when the table's id column has no DEFAULT gen_random_uuid()

        const insertData: any = {
          id: crypto.randomUUID(),
          user_id: user.id,
          role: 'owner',
          permissions: OWNER_PERMISSIONS,
          is_active: true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        // Add optional columns
        if (user.email) insertData.email = user.email;
        if (displayName.trim()) insertData.display_name = displayName.trim();

        const { error: insertError } = await supabase.from('team_members').insert(insertData);

        if (insertError) {
          if (isMigrationError(insertError)) {
            await goToMigrationStep(insertError.message);
            return;
          }
          setError(`Erreur: ${insertError.message}`);
          return;
        }

      }

      // admin_users (non-critical) — also provide explicit id
      try {
        const { data: ea } = await supabase.from('admin_users').select('*').eq('user_id', user.id).maybeSingle();
        if (!ea) {
          await supabase.from('admin_users').insert({
            id: crypto.randomUUID(),
            user_id: user.id,
            ...(user.email ? { email: user.email } : {}),
            role: 'super_admin',
          });
        }
      } catch { /* non-critical */ }


      toast({ title: 'Configuration terminée !', description: 'Vous êtes maintenant le propriétaire.' });
      setStep('edge-function-setup');
    } catch (err: any) {
      setError(`Erreur inattendue : ${err?.message || 'Veuillez réessayer.'}`);
    }
  };





  // Determine if we need a wider container
  const needsWideContainer = activeTab === 'database' || step === 'edge-function-setup' || step === 'needs-migration';

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className={`min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex ${
      needsWideContainer ? 'items-start py-8' : 'items-center'
    } justify-center p-4`}>

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-3xl" />
      </div>

      <div className={`relative w-full ${needsWideContainer ? 'max-w-3xl' : 'max-w-lg'} z-10 transition-all duration-300`}>

        {/* Logo / Branding */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 shadow-lg shadow-amber-500/30 mb-4">
            <Crown className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Configuration initiale</h1>
          <p className="text-gray-400">Configurez votre plateforme en quelques secondes</p>
        </div>

        {/* ==================== TAB BAR ==================== */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex bg-gray-800/80 backdrop-blur-sm rounded-xl p-1 border border-gray-700/50">
            <button
              onClick={() => setActiveTab('config')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'config'
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg shadow-purple-500/20'
                  : 'text-gray-400 hover:text-gray-300 hover:bg-gray-700/50'
              }`}
            >
              <Wrench className="w-4 h-4" />
              Configuration
            </button>
            <button
              onClick={() => setActiveTab('database')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'database'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-500/20'
                  : 'text-gray-400 hover:text-gray-300 hover:bg-gray-700/50'
              }`}
            >
              <Database className="w-4 h-4" />
              Base de données
            </button>
          </div>
        </div>

        {/* ==================== DATABASE TAB ==================== */}
        {activeTab === 'database' && (
          <DatabaseSetupWizard />
        )}

        {/* ==================== CONFIG TAB ==================== */}
        {activeTab === 'config' && (
          <>
            {/* ==================== LOADING ==================== */}
            {step === 'loading' && (
              <Card className="border-gray-800 bg-gray-900/80 backdrop-blur-xl">
                <CardContent className="pt-8 pb-8">
                  <div className="flex flex-col items-center gap-4">
                    <Loader2 className="w-10 h-10 text-purple-400 animate-spin" />
                    <p className="text-gray-300">Vérification de l'état de la plateforme...</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* ==================== NOT CONFIGURED — CREDENTIALS FORM ==================== */}
            {step === 'not-configured' && (
              <Card className="border-purple-500/30 bg-gray-900/80 backdrop-blur-xl shadow-2xl shadow-purple-500/10">
                <CardHeader className="text-center pb-4">
                  <div className="mx-auto w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center mb-3 shadow-lg shadow-purple-500/20">
                    <Database className="w-7 h-7 text-white" />
                  </div>
                  <CardTitle className="text-white text-xl">Connecter Supabase</CardTitle>
                  <CardDescription className="text-gray-400">
                    Collez vos clés Supabase ci-dessous pour connecter votre base de données.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-5">
                  {/* Where to find keys hint */}
                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <ExternalLink className="w-4 h-4 text-blue-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-blue-300 text-sm font-medium mb-1">Où trouver vos clés ?</p>
                        <ol className="text-blue-300/80 text-xs space-y-1 list-decimal list-inside">
                          <li>Connectez-vous à <span className="font-mono text-blue-300">supabase.com</span></li>
                          <li>Ouvrez votre projet</li>
                          <li>Allez dans <span className="font-semibold text-blue-300">Settings &gt; API</span></li>
                          <li>Copiez <span className="font-semibold text-blue-300">Project URL</span> et <span className="font-semibold text-blue-300">anon public key</span></li>
                        </ol>
                      </div>
                    </div>
                  </div>

                  {/* URL Field */}
                  <div className="space-y-2">
                    <Label className="text-gray-300 flex items-center gap-2">
                      <Globe className="w-4 h-4 text-purple-400" />
                      Project URL
                    </Label>
                    <div className="relative">
                      <Input
                        type="url"
                        value={sbUrl}
                        onChange={(e) => { setSbUrl(e.target.value); setTestResult(null); }}
                        placeholder="https://abcdefgh.supabase.co"
                        className="bg-gray-800/80 border-gray-700 text-white placeholder-gray-500 font-mono text-sm pr-10 focus:border-purple-500 focus:ring-purple-500/20"
                        spellCheck={false}
                        autoComplete="off"
                      />
                      {sbUrl && (
                        <button type="button" onClick={() => { setSbUrl(''); setTestResult(null); }} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    {sbUrl && !sbUrl.includes('.supabase.co') && (
                      <p className="text-amber-400 text-xs flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        L'URL doit contenir .supabase.co
                      </p>
                    )}
                  </div>

                  {/* Anon Key Field */}
                  <div className="space-y-2">
                    <Label className="text-gray-300 flex items-center gap-2">
                      <Key className="w-4 h-4 text-amber-400" />
                      Anon Key <span className="text-gray-500 text-xs font-normal">(clé publique)</span>
                    </Label>
                    <div className="relative">
                      <Input
                        type={showAnonKey ? 'text' : 'password'}
                        value={sbAnonKey}
                        onChange={(e) => { setSbAnonKey(e.target.value); setTestResult(null); }}
                        placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                        className="bg-gray-800/80 border-gray-700 text-white placeholder-gray-500 font-mono text-sm pr-20 focus:border-purple-500 focus:ring-purple-500/20"
                        spellCheck={false}
                        autoComplete="off"
                      />
                      <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                        <button type="button" onClick={() => setShowAnonKey(!showAnonKey)} className="text-gray-500 hover:text-gray-300 transition-colors p-1" title={showAnonKey ? 'Masquer' : 'Afficher'}>
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {sbAnonKey && (
                          <button type="button" onClick={() => { setSbAnonKey(''); setTestResult(null); }} className="text-gray-500 hover:text-gray-300 transition-colors p-1">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                    {sbAnonKey && sbAnonKey.length > 0 && sbAnonKey.length < 30 && (
                      <p className="text-amber-400 text-xs flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        La clé semble trop courte
                      </p>
                    )}
                    <p className="text-gray-600 text-xs">
                      <Lock className="w-3 h-3 inline mr-1" />
                      Utilisez la clé <span className="font-semibold">anon</span> (publique), pas la clé service_role.
                    </p>
                  </div>

                  {/* Test Result */}
                  {testResult && (
                    <Alert className={testResult.success ? 'border-green-500/30 bg-green-500/10' : 'border-red-500/30 bg-red-500/10'}>
                      {testResult.success ? <CheckCircle className="h-4 w-4 text-green-400" /> : <AlertTriangle className="h-4 w-4 text-red-400" />}
                      <AlertDescription className={testResult.success ? 'text-green-300' : 'text-red-300'}>
                        {testResult.success ? 'Connexion réussie ! Le serveur Supabase répond correctement.' : testResult.error || 'Échec de la connexion.'}
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-3 pt-1">
                    <Button variant="outline" className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white" onClick={handleTestConnection} disabled={isTesting || !sbUrl.trim() || !sbAnonKey.trim()}>
                      {isTesting ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Test...</> : <><Zap className="w-4 h-4 mr-2" />Tester</>}
                    </Button>
                    <Button className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold shadow-lg shadow-purple-500/20" onClick={handleSaveCredentials} disabled={isTesting || !sbUrl.trim() || !sbAnonKey.trim()}>
                      {isTesting ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Connexion...</> : <><Link2 className="w-4 h-4 mr-2" />Connecter</>}
                    </Button>
                  </div>

                  {isRuntimeConfigured && (
                    <Button variant="ghost" className="w-full text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={handleClearCredentials}>
                      <Trash2 className="w-4 h-4 mr-2" />Supprimer les clés sauvegardées
                    </Button>
                  )}

                  {/* Advanced .env instructions */}
                  <div className="border-t border-gray-800 pt-4">
                    <button type="button" onClick={() => setShowAdvanced(!showAdvanced)} className="flex items-center gap-2 text-gray-500 hover:text-gray-400 text-xs w-full transition-colors">
                      {showAdvanced ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      <Server className="w-3.5 h-3.5" />
                      Configuration alternative via fichier .env
                    </button>
                    {showAdvanced && (
                      <div className="mt-3 bg-gray-800/50 rounded-xl p-4 space-y-3">
                        <p className="text-gray-400 text-xs">Vous pouvez aussi configurer via le fichier <code className="bg-gray-700 px-1.5 py-0.5 rounded text-amber-300">.env</code> :</p>
                        <ol className="text-gray-400 text-xs space-y-2 list-decimal list-inside">
                          <li>Copiez <code className="bg-gray-700 px-1.5 py-0.5 rounded text-amber-300">.env.example</code> en <code className="bg-gray-700 px-1.5 py-0.5 rounded text-amber-300">.env</code></li>
                          <li>Ajoutez vos clés</li>
                          <li>Exécutez <code className="bg-gray-700 px-1.5 py-0.5 rounded text-amber-300">database-setup.sql</code> dans le SQL Editor</li>
                          <li>Redémarrez avec <code className="bg-gray-700 px-1.5 py-0.5 rounded text-amber-300">npm run dev</code></li>
                        </ol>
                      </div>
                    )}
                  </div>

                  <Button variant="ghost" className="w-full text-gray-500 hover:text-gray-300" onClick={() => navigate('/')}>
                    Retour à l'accueil
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* ==================== NOT AUTHENTICATED ==================== */}
            {step === 'not-authenticated' && (
              <Card className="border-gray-800 bg-gray-900/80 backdrop-blur-xl">
                <CardHeader className="text-center">
                  <div className="mx-auto w-14 h-14 rounded-full bg-purple-500/10 flex items-center justify-center mb-3">
                    <Lock className="w-7 h-7 text-purple-400" />
                  </div>
                  <CardTitle className="text-white text-xl">Authentification requise</CardTitle>
                  <CardDescription className="text-gray-400">Connectez-vous ou créez un compte pour configurer la plateforme.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-center mb-4">
                    <Badge className="bg-green-500/10 text-green-400 border-green-500/30">
                      <CheckCircle className="w-3 h-3 mr-1" />Supabase connecté
                      {isRuntimeConfigured && <span className="ml-1 text-green-500/60">(runtime)</span>}
                    </Badge>
                  </div>

                  {authSuccess && (
                    <Alert className="mb-4 border-green-500/30 bg-green-500/10"><CheckCircle className="h-4 w-4 text-green-400" /><AlertDescription className="text-green-300">{authSuccess}</AlertDescription></Alert>
                  )}
                  {authError && !showEmailNotConfirmed && (
                    <Alert className="mb-4 border-red-500/30 bg-red-500/10" variant="destructive"><AlertTriangle className="h-4 w-4" /><AlertDescription>{authError}</AlertDescription></Alert>
                  )}
                  {showEmailNotConfirmed && authEmail && (
                    <div className="mb-4"><EmailNotConfirmedHelper email={authEmail} errorType={emailErrorType} onDismiss={() => setShowEmailNotConfirmed(false)} /></div>
                  )}

                  <div className="flex mb-6 bg-gray-800 rounded-lg p-1">
                    <button onClick={() => { setAuthMode('login'); setAuthError(''); setAuthSuccess(''); }} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md text-sm font-medium transition-all ${authMode === 'login' ? 'bg-purple-600 text-white shadow-md' : 'text-gray-400 hover:text-gray-300'}`}>
                      <LogIn className="w-4 h-4" />Connexion
                    </button>
                    <button onClick={() => { setAuthMode('signup'); setAuthError(''); setAuthSuccess(''); }} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md text-sm font-medium transition-all ${authMode === 'signup' ? 'bg-purple-600 text-white shadow-md' : 'text-gray-400 hover:text-gray-300'}`}>
                      <UserPlus className="w-4 h-4" />Inscription
                    </button>
                  </div>

                  <form onSubmit={handleAuth} className="space-y-4">
                    <div>
                      <Label className="text-gray-300">Email</Label>
                      <Input type="email" value={authEmail} onChange={(e) => setAuthEmail(e.target.value)} placeholder="votre@email.com" className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 mt-1.5" required autoComplete="email" />
                    </div>
                    <div>
                      <Label className="text-gray-300">Mot de passe</Label>
                      <Input type="password" value={authPassword} onChange={(e) => setAuthPassword(e.target.value)} placeholder="••••••••" className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 mt-1.5" required minLength={6} autoComplete={authMode === 'signup' ? 'new-password' : 'current-password'} />
                      {authMode === 'signup' && <p className="text-gray-500 text-xs mt-1">Minimum 6 caractères</p>}
                    </div>
                    {authMode === 'signup' && (
                      <div>
                        <Label className="text-gray-300">Confirmer le mot de passe</Label>
                        <Input type="password" value={authConfirmPassword} onChange={(e) => setAuthConfirmPassword(e.target.value)} placeholder="••••••••" className={`bg-gray-800 border-gray-700 text-white placeholder-gray-500 mt-1.5 ${authConfirmPassword && authConfirmPassword !== authPassword ? 'border-red-500/50' : ''}`} required minLength={6} autoComplete="new-password" />
                        {authConfirmPassword && authConfirmPassword !== authPassword && <p className="text-red-400 text-xs mt-1">Les mots de passe ne correspondent pas</p>}
                      </div>
                    )}
                    <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700 text-white" disabled={authLoading2 || (authMode === 'signup' && authPassword !== authConfirmPassword && authConfirmPassword.length > 0)}>
                      {authLoading2 ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />{authMode === 'signup' ? 'Création...' : 'Connexion...'}</> : authMode === 'signup' ? "Créer un compte" : 'Se connecter'}
                    </Button>
                  </form>

                  <div className="mt-4 flex gap-2">
                    <Button variant="ghost" className="flex-1 text-gray-400 hover:text-gray-300" onClick={() => navigate('/')}>Accueil</Button>
                    {isRuntimeConfigured && (
                      <Button variant="ghost" className="flex-1 text-amber-400 hover:text-amber-300 hover:bg-amber-500/10" onClick={() => { clearRuntimeCredentials(); window.location.reload(); }}>
                        <RefreshCw className="w-4 h-4 mr-1" />Changer les clés
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* ==================== OWNER ALREADY EXISTS ==================== */}
            {step === 'owner-exists' && (
              <Card className="border-amber-500/30 bg-gray-900/80 backdrop-blur-xl">
                <CardHeader className="text-center">
                  <div className="mx-auto w-14 h-14 rounded-full bg-amber-500/10 flex items-center justify-center mb-3"><Shield className="w-7 h-7 text-amber-400" /></div>
                  <CardTitle className="text-white text-xl">Plateforme déjà configurée</CardTitle>
                  <CardDescription className="text-gray-400">Un propriétaire est déjà enregistré pour cette plateforme.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-gray-800/50 rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0"><Crown className="w-5 h-5 text-amber-400" /></div>
                    <div><p className="text-white font-medium">Propriétaire actuel</p><p className="text-gray-400 text-sm">{existingOwnerEmail}</p></div>
                  </div>
                  {user && (
                    <div className="bg-gray-800/50 rounded-xl p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0"><Users className="w-5 h-5 text-purple-400" /></div>
                      <div><p className="text-white font-medium">Votre compte</p><p className="text-gray-400 text-sm">{user.email}</p></div>
                    </div>
                  )}
                  <p className="text-gray-500 text-sm text-center">Contactez le propriétaire pour obtenir un accès administrateur.</p>
                  <div className="flex gap-3">
                    <Button variant="outline" className="flex-1" onClick={() => navigate('/')}>Accueil</Button>
                    <Button className="flex-1 bg-purple-600 hover:bg-purple-700" onClick={() => navigate('/admin')}>Tableau de bord<ArrowRight className="w-4 h-4 ml-2" /></Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* ==================== NEEDS MIGRATION ==================== */}
            {step === 'needs-migration' && (
              <Card className="border-orange-500/30 bg-gray-900/80 backdrop-blur-xl shadow-2xl shadow-orange-500/10">
                <CardHeader className="text-center pb-4">
                  <div className="mx-auto w-14 h-14 rounded-full bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center mb-3 shadow-lg shadow-orange-500/20">
                    <Database className="w-7 h-7 text-white" />
                  </div>
                  <CardTitle className="text-white text-xl">Migration de base de données requise</CardTitle>
                  <CardDescription className="text-gray-400">
                    Votre base de données a besoin d'une mise à jour pour fonctionner correctement. Suivez les étapes ci-dessous.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-5">
                  {/* Error detail */}
                  {migrationError && (
                    <Alert className="border-orange-500/30 bg-orange-500/10">
                      <AlertTriangle className="h-4 w-4 text-orange-400" />
                      <AlertDescription className="text-orange-300 text-sm">{migrationError}</AlertDescription>
                    </Alert>
                  )}

                  {/* Diagnostics summary */}
                  {migrationDiagnostics.length > 0 && (
                    <div className="bg-gray-800/50 rounded-xl p-4 space-y-2">
                      <p className="text-gray-300 text-sm font-medium mb-2">Diagnostic :</p>
                      {migrationDiagnostics.map((d, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs">
                          <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                            d.status === 'exists' || d.status === 'ok' ? 'bg-green-400' :
                            d.status === 'missing' || d.status === 'needs_fix' ? 'bg-red-400' :
                            d.status === 'warning' ? 'bg-amber-400' : 'bg-gray-400'
                          }`} />
                          <span className="text-gray-400">{d.check}</span>
                          <span className={`ml-auto font-mono ${
                            d.status === 'exists' || d.status === 'ok' ? 'text-green-400' :
                            d.status === 'missing' || d.status === 'needs_fix' ? 'text-red-400' :
                            'text-amber-400'
                          }`}>{d.status}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Instructions */}
                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <ExternalLink className="w-4 h-4 text-blue-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-blue-300 text-sm font-medium mb-2">Comment appliquer la migration :</p>
                        <ol className="text-blue-300/80 text-xs space-y-1.5 list-decimal list-inside">
                          <li>Cliquez sur <span className="font-semibold text-blue-300">"Copier le SQL"</span> ci-dessous</li>
                          <li>Ouvrez votre <span className="font-semibold text-blue-300">Supabase Dashboard</span></li>
                          <li>Allez dans <span className="font-semibold text-blue-300">SQL Editor</span> (menu de gauche)</li>
                          <li>Cliquez <span className="font-semibold text-blue-300">"New Query"</span></li>
                          <li>Collez le SQL et cliquez <span className="font-semibold text-blue-300">"Run"</span></li>
                          <li>Revenez ici et cliquez <span className="font-semibold text-blue-300">"Vérifier et continuer"</span></li>
                        </ol>
                      </div>
                    </div>
                  </div>

                  {/* SQL Preview + Copy */}
                  {isMigrating ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 text-orange-400 animate-spin" />
                      <span className="text-gray-400 ml-3">Chargement du script de migration...</span>
                    </div>
                  ) : migrationSql ? (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-gray-300 text-sm font-medium">Script SQL de migration :</p>
                        <Badge className="bg-gray-700 text-gray-400 border-gray-600 text-[10px]">
                          {migrationSql.split('\n').length} lignes
                        </Badge>
                      </div>
                      <div className="relative">
                        <pre className="bg-gray-950 border border-gray-700 rounded-xl p-4 text-xs text-green-400 font-mono overflow-auto max-h-48 whitespace-pre-wrap leading-relaxed">
                          {migrationSql.substring(0, 2000)}{migrationSql.length > 2000 ? '\n\n-- ... (tronqué pour l\'affichage, le SQL complet sera copié)' : ''}
                        </pre>
                      </div>
                      <Button
                        className={`w-full font-semibold shadow-lg transition-all ${
                          sqlCopied
                            ? 'bg-green-600 hover:bg-green-700 text-white shadow-green-500/20'
                            : 'bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-orange-500/20'
                        }`}
                        onClick={handleCopySql}
                      >
                        {sqlCopied ? (
                          <><ClipboardCheck className="w-4 h-4 mr-2" />SQL copié !</>
                        ) : (
                          <><Copy className="w-4 h-4 mr-2" />Copier le SQL</>
                        )}
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-gray-500 text-sm">Impossible de générer le script de migration.</p>
                      <p className="text-gray-600 text-xs mt-1">Vérifiez que la Edge Function "run-migrations" est déployée.</p>
                    </div>
                  )}

                  {/* Retry button */}
                  <div className="flex gap-3 pt-2">
                    <Button
                      variant="outline"
                      className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800"
                      onClick={() => {
                        setStep('ready');
                        setDisplayName(user?.email?.split('@')[0] || 'Propriétaire');
                      }}
                    >
                      Retour
                    </Button>
                    <Button
                      className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold shadow-lg shadow-purple-500/20"
                      onClick={handleRetryAfterMigration}
                      disabled={isMigrating}
                    >
                      {isMigrating ? (
                        <><Loader2 className="w-4 h-4 animate-spin mr-2" />Vérification...</>
                      ) : (
                        <><RefreshCw className="w-4 h-4 mr-2" />Vérifier et continuer</>
                      )}
                    </Button>
                  </div>

                  <p className="text-gray-600 text-xs text-center">
                    Après avoir exécuté le SQL dans Supabase, cliquez sur "Vérifier et continuer".
                  </p>
                </CardContent>
              </Card>
            )}

            {/* ==================== READY TO SETUP ==================== */}
            {step === 'ready' && (
              <Card className="border-gray-800 bg-gray-900/80 backdrop-blur-xl">
                <CardHeader className="text-center">
                  <div className="mx-auto w-14 h-14 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center mb-3 shadow-lg shadow-amber-500/20"><Crown className="w-7 h-7 text-white" /></div>
                  <CardTitle className="text-white text-xl">Devenir propriétaire</CardTitle>
                  <CardDescription className="text-gray-400">Aucun propriétaire n'est enregistré. Configurez votre compte comme administrateur principal.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-center">
                    <Badge className="bg-green-500/10 text-green-400 border-green-500/30"><CheckCircle className="w-3 h-3 mr-1" />Supabase connecté</Badge>
                  </div>
                  <div className="bg-gray-800/50 rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0"><Users className="w-5 h-5 text-purple-400" /></div>
                    <div className="flex-1 min-w-0"><p className="text-gray-400 text-xs">Connecté en tant que</p><p className="text-white font-medium truncate">{user?.email}</p></div>
                    <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/30"><Crown className="w-3 h-3 mr-1" />Owner</Badge>
                  </div>
                  <div>
                    <Label className="text-gray-300">Nom d'affichage</Label>
                    <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Votre nom" className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 mt-1.5" maxLength={50} />
                    <p className="text-gray-500 text-xs mt-1">Ce nom sera visible dans le tableau de bord admin.</p>
                  </div>
                  <div>
                    <p className="text-gray-300 text-sm font-medium mb-3">Permissions accordées :</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {PERMISSION_ITEMS.map((perm) => (
                        <div key={perm.key} className="flex items-center gap-2.5 bg-gray-800/40 rounded-lg px-3 py-2.5">
                          <perm.icon className={`w-4 h-4 ${perm.color} flex-shrink-0`} />
                          <span className="text-gray-300 text-sm">{perm.label}</span>
                          <CheckCircle className="w-3.5 h-3.5 text-green-400 ml-auto flex-shrink-0" />
                        </div>
                      ))}
                    </div>
                  </div>
                  {error && (
                    <Alert className="border-red-500/30 bg-red-500/10" variant="destructive"><AlertTriangle className="h-4 w-4" /><AlertDescription>{error}</AlertDescription></Alert>
                  )}
                  <div className="flex gap-3 pt-2">
                    <Button variant="outline" className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800" onClick={() => navigate('/')} disabled={isProcessing}>Annuler</Button>
                    <Button className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-semibold shadow-lg shadow-amber-500/20" onClick={handleRegisterAsOwner} disabled={isProcessing || !displayName.trim()}>
                      {isProcessing ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Configuration...</> : <><Crown className="w-4 h-4 mr-2" />Confirmer</>}
                    </Button>
                  </div>
                  <p className="text-gray-600 text-xs text-center leading-relaxed"><Lock className="w-3 h-3 inline mr-1" />Cette action est irréversible.</p>
                </CardContent>
              </Card>
            )}

            {/* ==================== CONFIRMING ==================== */}
            {step === 'confirming' && (
              <Card className="border-gray-800 bg-gray-900/80 backdrop-blur-xl">
                <CardContent className="pt-8 pb-8">
                  <div className="flex flex-col items-center gap-4"><Loader2 className="w-10 h-10 text-amber-400 animate-spin" /><p className="text-gray-300">Configuration en cours...</p></div>
                </CardContent>
              </Card>
            )}

            {/* ==================== SUCCESS ==================== */}
            {step === 'success' && (
              <Card className="border-green-500/30 bg-gray-900/80 backdrop-blur-xl">
                <CardContent className="pt-8 pb-8">
                  <div className="flex flex-col items-center gap-4 text-center">
                    <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center"><CheckCircle className="w-8 h-8 text-green-400" /></div>
                    <div><h3 className="text-xl font-bold text-white mb-2">Configuration terminée !</h3><p className="text-gray-400">Vous êtes maintenant le propriétaire de la plateforme.</p></div>
                    <div className="flex items-center gap-2 bg-gray-800/50 rounded-xl px-4 py-3">
                      <Crown className="w-5 h-5 text-amber-400" /><span className="text-white font-medium">{displayName || user?.email}</span>
                      <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/30 ml-2">Owner</Badge>
                    </div>
                    <p className="text-gray-500 text-sm">Redirection vers le tableau de bord...</p>
                    <Loader2 className="w-5 h-5 text-purple-400 animate-spin" />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* ==================== EDGE FUNCTION SETUP ==================== */}
            {step === 'edge-function-setup' && (
              <div className="space-y-4">
                <Card className="border-green-500/30 bg-gray-900/80 backdrop-blur-xl">
                  <CardContent className="py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center flex-shrink-0"><CheckCircle className="w-5 h-5 text-green-400" /></div>
                      <div className="flex-1 min-w-0">
                        <p className="text-green-300 font-semibold text-sm">Propriétaire enregistré avec succès !</p>
                        <p className="text-gray-400 text-xs"><Crown className="w-3 h-3 inline mr-1 text-amber-400" />{displayName || user?.email}<Badge className="bg-amber-500/10 text-amber-400 border-amber-500/30 ml-2 text-[9px]">Owner</Badge></p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <div className="flex items-center justify-center gap-2 py-1">
                  <div className="flex items-center gap-1.5"><div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center"><CheckCircle className="w-3.5 h-3.5 text-green-400" /></div><span className="text-green-400 text-xs font-medium">Compte</span></div>
                  <div className="w-8 h-px bg-gray-700" />
                  <div className="flex items-center gap-1.5"><div className="w-6 h-6 rounded-full bg-purple-500/30 flex items-center justify-center ring-2 ring-purple-500/30"><span className="text-purple-300 text-[10px] font-bold">2</span></div><span className="text-purple-300 text-xs font-medium">Edge Functions</span></div>
                  <div className="w-8 h-px bg-gray-700" />
                  <div className="flex items-center gap-1.5"><div className="w-6 h-6 rounded-full bg-gray-700/50 flex items-center justify-center"><span className="text-gray-500 text-[10px] font-bold">3</span></div><span className="text-gray-500 text-xs font-medium">Dashboard</span></div>
                </div>
                <EdgeFunctionGuide onContinue={() => navigate('/admin')} showContinue={true} continueLabel="Continuer vers le tableau de bord" />
              </div>
            )}
          </>
        )}

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-gray-600 text-xs">Famous.ai — Configuration de la plateforme</p>
        </div>
      </div>
    </div>
  );
};

export default SetupPage;
