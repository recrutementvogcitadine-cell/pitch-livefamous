import React, { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  supabase,
  isSupabaseConfigured,
  getConfigDiagnostics,
  getProjectRef,
  getEdgeFunctionSecretsUrl,
  getReplicationSettingsUrl,
  getEdgeFunctionsUrl,
} from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';

import {
  Database, CheckCircle, Loader2, AlertTriangle, RefreshCw,
  Shield, Zap, HardDrive, Radio, ExternalLink, ArrowRight,
  ChevronDown, ChevronUp, Globe, Key, Server, Eye, Copy,
  Link2, Settings, Info, X, Check, Wrench, Play, Sparkles,
  Download, Terminal,
} from 'lucide-react';


// ============================================================================
// TYPES
// ============================================================================

type ServiceStatus = 'idle' | 'checking' | 'ok' | 'warning' | 'error';

interface ServiceCheck {
  id: string;
  label: string;
  description: string;
  status: ServiceStatus;
  message: string;
  details?: string;
  duration?: number;
  fixable?: boolean;       // Can this check be auto-fixed?
  tableName?: string;      // Table name for auto-fix
  isFixing?: boolean;      // Currently being fixed?
  fixResult?: 'success' | 'error' | null;
  fixMessage?: string;
}

interface ServiceCategory {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  gradient: string;
  shadowColor: string;
  checks: ServiceCheck[];
  overallStatus: ServiceStatus;
  fixUrl?: string;
  fixLabel?: string;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const EXPECTED_TABLES = [
  'creator_profiles', 'live_streams', 'live_chat_messages', 'follows',
  'payments', 'subscription_plans', 'creator_subscriptions',
  'team_members', 'admin_users', 'support_requests',
  'verification_requests', 'chat_bans', 'moderation_logs',
];

const EXPECTED_BUCKETS = ['avatars', 'streams', 'recordings'];

// ============================================================================
// HELPERS
// ============================================================================

function getOverall(checks: ServiceCheck[]): ServiceStatus {
  if (checks.some(c => c.status === 'checking')) return 'checking';
  if (checks.every(c => c.status === 'idle')) return 'idle';
  if (checks.some(c => c.status === 'error')) return 'error';
  if (checks.some(c => c.status === 'warning')) return 'warning';
  if (checks.every(c => c.status === 'ok')) return 'ok';
  return 'idle';
}

const statusColors: Record<ServiceStatus, { text: string; bg: string; border: string; dot: string }> = {
  idle: { text: 'text-gray-400', bg: 'bg-gray-800/50', border: 'border-gray-700/50', dot: 'bg-gray-500' },
  checking: { text: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/30', dot: 'bg-blue-500 animate-pulse' },
  ok: { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', dot: 'bg-emerald-500' },
  warning: { text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30', dot: 'bg-amber-500' },
  error: { text: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/30', dot: 'bg-red-500' },
};

const statusLabels: Record<ServiceStatus, string> = {
  idle: 'En attente',
  checking: 'Vérification...',
  ok: 'Connecté',
  warning: 'Attention',
  error: 'Erreur',
};

// ============================================================================
// COMPONENT
// ============================================================================

const ConnectSyncPage: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAppContext();
  const [isRunning, setIsRunning] = useState(false);
  const [lastRun, setLastRun] = useState<Date | null>(null);
  const [expandedServices, setExpandedServices] = useState<Set<string>>(new Set());
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const projectRef = getProjectRef();

  // Auto-fix state
  const [bootstrapReady, setBootstrapReady] = useState<boolean | null>(null);
  const [bootstrapSql, setBootstrapSql] = useState<string | null>(null);
  const [isFixingAll, setIsFixingAll] = useState(false);
  const [fixAllResult, setFixAllResult] = useState<{ success: boolean; message: string; created: string[]; failed: any[] } | null>(null);
  const [showBootstrapGuide, setShowBootstrapGuide] = useState(false);

  // ---- Service categories state ----
  const [categories, setCategories] = useState<ServiceCategory[]>(() => buildInitialCategories());

  function buildInitialCategories(): ServiceCategory[] {
    const sqlEditorUrl = projectRef
      ? `https://supabase.com/dashboard/project/${projectRef}/sql/new`
      : 'https://supabase.com/dashboard';

    return [
      {
        id: 'connection',
        label: 'Connexion Supabase',
        description: 'URL, clé API et service d\'authentification',
        icon: <Globe className="w-5 h-5 text-white" />,
        gradient: 'from-blue-500 to-cyan-500',
        shadowColor: 'shadow-blue-500/25',
        checks: [
          { id: 'config', label: 'Configuration', description: 'Variables VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY', status: 'idle', message: '' },
          { id: 'ping', label: 'Ping serveur', description: 'Connexion HTTP au serveur', status: 'idle', message: '' },
          { id: 'auth', label: 'Service Auth', description: 'Service d\'authentification', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
        fixUrl: '/setup',
        fixLabel: 'Configurer',
      },
      {
        id: 'tables',
        label: 'Tables de données',
        description: `${EXPECTED_TABLES.length} tables requises`,
        icon: <Database className="w-5 h-5 text-white" />,
        gradient: 'from-purple-500 to-pink-500',
        shadowColor: 'shadow-purple-500/25',
        checks: EXPECTED_TABLES.map(t => ({
          id: `table_${t}`, label: t, description: `Table ${t}`, status: 'idle' as ServiceStatus, message: '',
          fixable: true, tableName: t,
        })),
        overallStatus: 'idle',
        fixUrl: '/setup?tab=database',
        fixLabel: 'Créer les tables',
      },
      {
        id: 'rls',
        label: 'Row Level Security',
        description: 'Politiques de sécurité des données',
        icon: <Shield className="w-5 h-5 text-white" />,
        gradient: 'from-amber-500 to-orange-500',
        shadowColor: 'shadow-amber-500/25',
        checks: [
          { id: 'rls_enabled', label: 'RLS activé', description: 'Vérification de l\'activation RLS', status: 'idle', message: '' },
          { id: 'rls_policies', label: 'Politiques', description: 'Politiques sur les tables critiques', status: 'idle', message: '' },
          { id: 'rls_anon', label: 'Protection anonyme', description: 'Écriture anonyme bloquée', status: 'idle', message: '' },
          { id: 'rls_read', label: 'Lecture publique', description: 'Profils lisibles publiquement', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
        fixUrl: sqlEditorUrl,
        fixLabel: 'SQL Editor',
      },
      {
        id: 'storage',
        label: 'Storage Buckets',
        description: `${EXPECTED_BUCKETS.length} buckets requis`,
        icon: <HardDrive className="w-5 h-5 text-white" />,
        gradient: 'from-green-500 to-emerald-500',
        shadowColor: 'shadow-green-500/25',
        checks: EXPECTED_BUCKETS.map(b => ({
          id: `bucket_${b}`, label: b, description: `Bucket "${b}"`, status: 'idle' as ServiceStatus, message: '',
        })),
        overallStatus: 'idle',
        fixUrl: projectRef ? `https://supabase.com/dashboard/project/${projectRef}/storage/buckets` : undefined,
        fixLabel: 'Storage',
      },
      {
        id: 'realtime',
        label: 'Temps réel',
        description: 'WebSocket et réplication Realtime',
        icon: <Zap className="w-5 h-5 text-white" />,
        gradient: 'from-yellow-500 to-amber-500',
        shadowColor: 'shadow-yellow-500/25',
        checks: [
          { id: 'rt_ws', label: 'WebSocket', description: 'Connexion WebSocket', status: 'idle', message: '' },
          { id: 'rt_sub', label: 'Souscription', description: 'Souscription à un canal', status: 'idle', message: '' },
          { id: 'rt_tables', label: 'Tables Realtime', description: 'Tables dans la publication', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
        fixUrl: getReplicationSettingsUrl(),
        fixLabel: 'Réplication',
      },
      {
        id: 'edge_functions',
        label: 'Edge Functions',
        description: 'Fonctions serveur Supabase',
        icon: <Server className="w-5 h-5 text-white" />,
        gradient: 'from-indigo-500 to-violet-500',
        shadowColor: 'shadow-indigo-500/25',
        checks: [
          { id: 'ef_manage_live', label: 'manage-live', description: 'Gestion des lives', status: 'idle', message: '' },
          { id: 'ef_agora_token', label: 'generate-agora-token', description: 'Tokens Agora RTC', status: 'idle', message: '' },
          { id: 'ef_subscription', label: 'manage-subscription', description: 'Gestion abonnements', status: 'idle', message: '' },
          { id: 'ef_payment', label: 'process-payment', description: 'Traitement paiements', status: 'idle', message: '' },
          { id: 'ef_migrations', label: 'run-migrations', description: 'Auto-fix tables', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
        fixUrl: getEdgeFunctionsUrl(),
        fixLabel: 'Edge Functions',
      },
      {
        id: 'agora',
        label: 'Agora Live Streaming',
        description: 'Configuration vidéo temps réel',
        icon: <Radio className="w-5 h-5 text-white" />,
        gradient: 'from-red-500 to-rose-500',
        shadowColor: 'shadow-red-500/25',
        checks: [
          { id: 'agora_app_id', label: 'AGORA_APP_ID', description: 'Secret App ID configuré', status: 'idle', message: '' },
          { id: 'agora_cert', label: 'AGORA_APP_CERTIFICATE', description: 'Secret Certificate configuré', status: 'idle', message: '' },
          { id: 'agora_status', label: 'Statut streaming', description: 'Service de streaming disponible', status: 'idle', message: '' },
          { id: 'agora_column', label: 'Colonne channel_name', description: 'Colonne dans live_streams', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
        fixUrl: getEdgeFunctionSecretsUrl(),
        fixLabel: 'Secrets',
      },
    ];
  }

  // ---- Update helpers ----
  const updateCheck = useCallback((catId: string, checkId: string, update: Partial<ServiceCheck>) => {
    setCategories(prev => prev.map(cat => {
      if (cat.id !== catId) return cat;
      const checks = cat.checks.map(c => c.id === checkId ? { ...c, ...update } : c);
      return { ...cat, checks, overallStatus: getOverall(checks) };
    }));
  }, []);

  const setAllChecking = useCallback((catId: string) => {
    setCategories(prev => prev.map(cat => {
      if (cat.id !== catId) return cat;
      const checks = cat.checks.map(c => ({ ...c, status: 'checking' as ServiceStatus, message: 'Vérification...' }));
      return { ...cat, checks, overallStatus: 'checking' };
    }));
  }, []);

  // ============================================================================
  // TEST RUNNERS
  // ============================================================================

  const runConnectionTests = async () => {
    setAllChecking('connection');
    const diag = getConfigDiagnostics();

    if (diag.isConfigured) {
      updateCheck('connection', 'config', { status: 'ok', message: `Source: ${diag.source} | Clé: ${diag.keyLength} chars` });
    } else {
      updateCheck('connection', 'config', { status: 'error', message: 'Variables manquantes ou invalides' });
      updateCheck('connection', 'ping', { status: 'error', message: 'Config manquante' });
      updateCheck('connection', 'auth', { status: 'error', message: 'Config manquante' });
      return;
    }

    const ps = performance.now();
    try {
      const { error } = await supabase.from('creator_profiles').select('id', { count: 'exact', head: true });
      const d = Math.round(performance.now() - ps);
      if (error && error.code !== '42P01' && error.code !== '42501' && !error.code?.startsWith('PGRST')) {
        updateCheck('connection', 'ping', { status: 'warning', message: `Réponse: ${error.message}`, duration: d });
      } else {
        updateCheck('connection', 'ping', { status: 'ok', message: `Serveur accessible (${d}ms)`, duration: d });
      }
    } catch (err: any) {
      updateCheck('connection', 'ping', { status: 'error', message: err?.message || 'Erreur réseau', duration: Math.round(performance.now() - ps) });
    }

    const as = performance.now();
    try {
      const { data, error } = await supabase.auth.getSession();
      const d = Math.round(performance.now() - as);
      if (error) {
        updateCheck('connection', 'auth', { status: 'warning', message: `Auth accessible: ${error.message}`, duration: d });
      } else {
        const info = data.session ? `Session: ${data.session.user.email}` : 'Aucune session';
        updateCheck('connection', 'auth', { status: 'ok', message: `Auth opérationnel — ${info}`, duration: d });
      }
    } catch (err: any) {
      updateCheck('connection', 'auth', { status: 'error', message: err?.message || 'Auth inaccessible', duration: Math.round(performance.now() - as) });
    }
  };

  const runTableTests = async () => {
    setAllChecking('tables');
    for (const table of EXPECTED_TABLES) {
      const s = performance.now();
      try {
        const { error, count } = await supabase.from(table).select('*', { count: 'exact', head: true });
        const d = Math.round(performance.now() - s);
        if (error) {
          const msg = (error.message || '').toLowerCase();
          const code = error.code || '';
          if (code === '42P01' || msg.includes('does not exist') || msg.includes('not found') || msg.includes('schema cache') || msg.includes('404')) {
            updateCheck('tables', `table_${table}`, { status: 'error', message: 'Table manquante', duration: d, fixable: true, tableName: table });
          } else if (code === '42501' || code.startsWith('PGRST')) {
            updateCheck('tables', `table_${table}`, { status: 'ok', message: 'Existe (accès RLS)', duration: d, fixable: false, tableName: table });
          } else {
            updateCheck('tables', `table_${table}`, { status: 'warning', message: error.message, duration: d, fixable: false, tableName: table });
          }
        } else {
          updateCheck('tables', `table_${table}`, { status: 'ok', message: `${count ?? 0} ligne(s)`, duration: d, fixable: false, tableName: table });
        }
      } catch (err: any) {
        updateCheck('tables', `table_${table}`, { status: 'error', message: err?.message || 'Erreur', duration: Math.round(performance.now() - s), fixable: true, tableName: table });
      }
    }
  };

  const runRLSTests = async () => {
    setAllChecking('rls');
    try {
      const { data, error } = await supabase.from('team_members').select('*').limit(1);
      if (error) {
        if (error.code === '42P01') updateCheck('rls', 'rls_enabled', { status: 'error', message: 'Table team_members manquante' });
        else if (error.code === '42501') updateCheck('rls', 'rls_enabled', { status: 'ok', message: 'RLS activé — accès restreint' });
        else updateCheck('rls', 'rls_enabled', { status: 'warning', message: error.message });
      } else {
        const { data: session } = await supabase.auth.getSession();
        if (!session.session && data && data.length > 0) {
          updateCheck('rls', 'rls_enabled', { status: 'error', message: 'Données accessibles sans auth — RLS désactivé!' });
        } else {
          updateCheck('rls', 'rls_enabled', { status: 'ok', message: 'RLS actif' });
        }
      }
    } catch (err: any) {
      updateCheck('rls', 'rls_enabled', { status: 'error', message: err?.message || 'Erreur' });
    }

    try {
      const tables = ['creator_profiles', 'payments', 'verification_requests'];
      let hasErrors = false;
      for (const t of tables) {
        const { error } = await supabase.from(t).select('id', { count: 'exact', head: true });
        if (error && error.code === '42P01') hasErrors = true;
      }
      updateCheck('rls', 'rls_policies', { status: hasErrors ? 'error' : 'ok', message: hasErrors ? 'Tables manquantes' : 'Politiques détectées' });
    } catch (err: any) {
      updateCheck('rls', 'rls_policies', { status: 'error', message: err?.message || 'Erreur' });
    }

    try {
      const { error } = await supabase.from('creator_profiles').insert({ user_id: '00000000-0000-0000-0000-000000000000', username: '__sync_test__', display_name: 'Test' });
      if (error) {
        updateCheck('rls', 'rls_anon', { status: 'ok', message: 'Écriture anonyme bloquée' });
      } else {
        await supabase.from('creator_profiles').delete().eq('username', '__sync_test__');
        updateCheck('rls', 'rls_anon', { status: 'error', message: 'Écriture anonyme NON bloquée!' });
      }
    } catch {
      updateCheck('rls', 'rls_anon', { status: 'warning', message: 'Test non concluant' });
    }

    try {
      const { data, error } = await supabase.from('creator_profiles').select('id, username').limit(3);
      if (error) {
        if (error.code === '42P01') updateCheck('rls', 'rls_read', { status: 'error', message: 'Table manquante' });
        else updateCheck('rls', 'rls_read', { status: 'warning', message: 'Lecture restreinte' });
      } else {
        updateCheck('rls', 'rls_read', { status: 'ok', message: `${data?.length ?? 0} profil(s) lisibles` });
      }
    } catch (err: any) {
      updateCheck('rls', 'rls_read', { status: 'error', message: err?.message || 'Erreur' });
    }
  };

  const runStorageTests = async () => {
    setAllChecking('storage');
    for (const bucket of EXPECTED_BUCKETS) {
      const s = performance.now();
      try {
        const { data, error } = await supabase.storage.from(bucket).list('', { limit: 1 });
        const d = Math.round(performance.now() - s);
        if (error) {
          const msg = typeof error === 'object' && 'message' in error ? (error as any).message : String(error);
          if (msg.includes('not found') || msg.includes('Bucket not found')) {
            updateCheck('storage', `bucket_${bucket}`, { status: 'error', message: 'Bucket inexistant', duration: d });
          } else {
            updateCheck('storage', `bucket_${bucket}`, { status: 'warning', message: `Erreur d'accès`, duration: d });
          }
        } else {
          updateCheck('storage', `bucket_${bucket}`, { status: 'ok', message: `Accessible (${data?.length ?? 0} fichier(s))`, duration: d });
        }
      } catch (err: any) {
        updateCheck('storage', `bucket_${bucket}`, { status: 'error', message: err?.message || 'Erreur', duration: Math.round(performance.now() - s) });
      }
    }
  };

  const runRealtimeTests = async () => {
    setAllChecking('realtime');
    try {
      const channel = supabase.channel('sync-test-' + Date.now());
      const result = await new Promise<{ ok: boolean; msg: string }>((resolve) => {
        const timeout = setTimeout(() => resolve({ ok: false, msg: 'Timeout (5s)' }), 5000);
        channel.subscribe((status) => {
          clearTimeout(timeout);
          if (status === 'SUBSCRIBED') resolve({ ok: true, msg: 'Connexion établie' });
          else resolve({ ok: false, msg: `Statut: ${status}` });
        });
      });
      updateCheck('realtime', 'rt_ws', { status: result.ok ? 'ok' : 'error', message: result.msg });
      updateCheck('realtime', 'rt_sub', { status: result.ok ? 'ok' : 'warning', message: result.ok ? 'Souscription réussie' : 'Non testée' });
      await supabase.removeChannel(channel);
    } catch (err: any) {
      updateCheck('realtime', 'rt_ws', { status: 'error', message: err?.message || 'Erreur WebSocket' });
      updateCheck('realtime', 'rt_sub', { status: 'error', message: 'Non testée' });
    }

    const RT_TABLES = ['live_chat_messages', 'live_streams', 'follows'];
    let allOk = true;
    const results: string[] = [];
    for (const table of RT_TABLES) {
      try {
        const ch = supabase.channel(`rt-sync-${table}-${Date.now()}`);
        const r = await new Promise<boolean>((resolve) => {
          const t = setTimeout(() => resolve(false), 4000);
          ch.on('postgres_changes', { event: '*', schema: 'public', table }, () => {}).subscribe((status) => {
            clearTimeout(t);
            resolve(status === 'SUBSCRIBED');
          });
        });
        results.push(`${table}: ${r ? 'OK' : 'FAIL'}`);
        if (!r) allOk = false;
        try { await supabase.removeChannel(ch); } catch {}
      } catch {
        results.push(`${table}: ERREUR`);
        allOk = false;
      }
    }
    updateCheck('realtime', 'rt_tables', {
      status: allOk ? 'ok' : 'warning',
      message: allOk ? '3/3 tables dans la publication' : 'Tables manquantes',
      details: results.join('\n'),
    });
  };

  const runEdgeFunctionTests = async () => {
    setAllChecking('edge_functions');
    const functions = [
      { id: 'ef_manage_live', name: 'manage-live' },
      { id: 'ef_agora_token', name: 'generate-agora-token' },
      { id: 'ef_subscription', name: 'manage-subscription' },
      { id: 'ef_payment', name: 'process-payment' },
      { id: 'ef_migrations', name: 'run-migrations' },
    ];

    for (const fn of functions) {
      const s = performance.now();
      try {
        const { data, error } = await supabase.functions.invoke(fn.name, {
          body: { action: 'health_check' },
        });
        const d = Math.round(performance.now() - s);
        if (error) {
          const msg = (error.message || '').toLowerCase();
          if (msg.includes('not found') || msg.includes('404')) {
            updateCheck('edge_functions', fn.id, { status: 'error', message: 'Non déployée', duration: d });
          } else {
            updateCheck('edge_functions', fn.id, { status: 'warning', message: `Erreur: ${error.message}`, duration: d });
          }
        } else if (data) {
          const version = data.version || '';
          const canAutoFix = data.can_auto_fix;
          let extra = '';
          if (fn.name === 'run-migrations') {
            extra = canAutoFix ? ' | Auto-fix: actif' : ' | Auto-fix: bootstrap requis';
            setBootstrapReady(canAutoFix ?? null);
          }
          updateCheck('edge_functions', fn.id, { status: 'ok', message: `Opérationnelle${version ? ` v${version}` : ''} (${d}ms)${extra}`, duration: d });
        } else {
          updateCheck('edge_functions', fn.id, { status: 'ok', message: `Accessible (${d}ms)`, duration: d });
        }
      } catch (err: any) {
        updateCheck('edge_functions', fn.id, { status: 'error', message: err?.message || 'Inaccessible', duration: Math.round(performance.now() - s) });
      }
    }
  };

  const runAgoraTests = async () => {
    setAllChecking('agora');
    let healthData: any = null;
    try {
      const { data, error } = await supabase.functions.invoke('manage-live', { body: { action: 'health_check' } });
      if (!error && data) healthData = data;
    } catch {}

    if (healthData) {
      const appIdOk = healthData.agora_app_id_configured;
      const appIdLen = healthData.agora_app_id_length || 0;
      updateCheck('agora', 'agora_app_id', {
        status: appIdOk ? 'ok' : 'error',
        message: appIdOk ? `Configuré (${appIdLen} chars)` : 'NON CONFIGURÉ',
        details: appIdOk ? undefined : `Le secret AGORA_APP_ID n'est pas dans les variables d'environnement.\n\n1. Allez sur console.agora.io > Votre projet\n2. Copiez l'App ID\n3. Dashboard Supabase > Edge Functions > Secrets\n4. Ajoutez AGORA_APP_ID`,
      });

      const certOk = healthData.agora_certificate_configured;
      const certLen = healthData.agora_certificate_length || 0;
      updateCheck('agora', 'agora_cert', {
        status: certOk ? 'ok' : 'error',
        message: certOk ? `Configuré (${certLen} chars)` : 'NON CONFIGURÉ',
        details: certOk ? undefined : `Le secret AGORA_APP_CERTIFICATE n'est pas configuré.\n\n1. console.agora.io > Votre projet > Primary Certificate\n2. Dashboard Supabase > Edge Functions > Secrets\n3. Ajoutez AGORA_APP_CERTIFICATE`,
      });

      const agoraReady = appIdOk && certOk;
      updateCheck('agora', 'agora_status', {
        status: agoraReady ? 'ok' : 'error',
        message: agoraReady ? 'Streaming disponible' : 'Streaming indisponible — secrets manquants',
      });
    } else {
      updateCheck('agora', 'agora_app_id', { status: 'error', message: 'Edge Function inaccessible' });
      updateCheck('agora', 'agora_cert', { status: 'error', message: 'Edge Function inaccessible' });
      updateCheck('agora', 'agora_status', { status: 'error', message: 'Impossible de vérifier' });
    }

    try {
      const { error } = await supabase.from('live_streams').select('channel_name').limit(1);
      if (error) {
        if (error.message?.includes('channel_name') || error.code === '42703') {
          updateCheck('agora', 'agora_column', { status: 'warning', message: 'Colonne manquante (fallback actif)', details: 'ALTER TABLE public.live_streams ADD COLUMN IF NOT EXISTS channel_name TEXT;' });
        } else {
          updateCheck('agora', 'agora_column', { status: 'warning', message: error.message });
        }
      } else {
        updateCheck('agora', 'agora_column', { status: 'ok', message: 'Présente' });
      }
    } catch (err: any) {
      updateCheck('agora', 'agora_column', { status: 'error', message: err?.message || 'Erreur' });
    }
  };

  // ============================================================================
  // AUTO-FIX FUNCTIONS
  // ============================================================================

  const checkBootstrapStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('run-migrations', {
        body: { action: 'check_bootstrap' },
      });
      if (!error && data) {
        setBootstrapReady(data.bootstrap_ready ?? false);
        if (!data.bootstrap_ready && data.bootstrap_sql) {
          setBootstrapSql(data.bootstrap_sql);
        }
      }
    } catch {
      setBootstrapReady(false);
    }
  };

  const fixSingleTable = async (tableName: string) => {
    // Set fixing state
    updateCheck('tables', `table_${tableName}`, { isFixing: true, fixResult: null, fixMessage: undefined });

    try {
      const { data, error } = await supabase.functions.invoke('run-migrations', {
        body: { action: 'create_table', table: tableName },
      });

      if (error) {
        updateCheck('tables', `table_${tableName}`, {
          isFixing: false,
          fixResult: 'error',
          fixMessage: error.message || 'Erreur lors de la création',
        });
        return false;
      }

      if (data?.needs_bootstrap) {
        setBootstrapReady(false);
        setBootstrapSql(data.bootstrap_sql);
        setShowBootstrapGuide(true);
        updateCheck('tables', `table_${tableName}`, {
          isFixing: false,
          fixResult: 'error',
          fixMessage: 'Bootstrap requis — voir le guide ci-dessous',
        });
        return false;
      }

      if (data?.success || data?.already_exists) {
        // Re-check the table
        const s = performance.now();
        try {
          const { error: checkErr, count } = await supabase.from(tableName).select('*', { count: 'exact', head: true });
          const d = Math.round(performance.now() - s);
          if (checkErr) {
            const code = checkErr.code || '';
            if (code === '42P01') {
              updateCheck('tables', `table_${tableName}`, {
                status: 'error', message: 'Toujours manquante après fix', duration: d,
                isFixing: false, fixResult: 'error', fixMessage: 'La table n\'a pas été créée',
                fixable: true, tableName,
              });
              return false;
            } else {
              updateCheck('tables', `table_${tableName}`, {
                status: 'ok', message: 'Créée (accès RLS)', duration: d,
                isFixing: false, fixResult: 'success', fixMessage: 'Table créée avec succès!',
                fixable: false, tableName,
              });
              return true;
            }
          } else {
            updateCheck('tables', `table_${tableName}`, {
              status: 'ok', message: `${count ?? 0} ligne(s)`, duration: d,
              isFixing: false, fixResult: 'success', fixMessage: data?.already_exists ? 'Table existait déjà' : 'Table créée avec succès!',
              fixable: false, tableName,
            });
            return true;
          }
        } catch {
          updateCheck('tables', `table_${tableName}`, {
            isFixing: false, fixResult: 'success', fixMessage: 'SQL exécuté',
          });
          return true;
        }
      } else {
        updateCheck('tables', `table_${tableName}`, {
          isFixing: false,
          fixResult: 'error',
          fixMessage: data?.error || data?.message || 'Erreur inconnue',
          details: data?.table_sql ? `-- SQL pour ${tableName}:\n${data.table_sql}` : undefined,
        });
        return false;
      }
    } catch (err: any) {
      updateCheck('tables', `table_${tableName}`, {
        isFixing: false,
        fixResult: 'error',
        fixMessage: err?.message || 'Erreur réseau',
      });
      return false;
    }
  };

  const fixAllMissingTables = async () => {
    setIsFixingAll(true);
    setFixAllResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('run-migrations', {
        body: { action: 'create_all_tables' },
      });

      if (error) {
        setFixAllResult({ success: false, message: error.message || 'Erreur', created: [], failed: [] });
        setIsFixingAll(false);
        return;
      }

      if (data?.needs_bootstrap) {
        setBootstrapReady(false);
        setBootstrapSql(data.bootstrap_sql);
        setShowBootstrapGuide(true);
        setFixAllResult({ success: false, message: 'Bootstrap requis — voir le guide ci-dessous', created: [], failed: [] });
        setIsFixingAll(false);
        return;
      }

      setFixAllResult({
        success: data?.success ?? false,
        message: data?.message || 'Terminé',
        created: data?.created || [],
        failed: data?.failed || [],
      });

      // Re-run table checks
      await runTableTests();
    } catch (err: any) {
      setFixAllResult({ success: false, message: err?.message || 'Erreur réseau', created: [], failed: [] });
    }

    setIsFixingAll(false);
  };

  // ============================================================================
  // RUN ALL
  // ============================================================================

  const runAllSync = async () => {
    if (isRunning) return;
    setIsRunning(true);
    setCategories(buildInitialCategories());
    setExpandedServices(new Set());
    setFixAllResult(null);

    if (!isSupabaseConfigured) {
      setCategories(prev => prev.map(cat => ({
        ...cat,
        overallStatus: 'error' as ServiceStatus,
        checks: cat.checks.map(c => ({ ...c, status: 'error' as ServiceStatus, message: 'Supabase non configuré' })),
      })));
      setIsRunning(false);
      setLastRun(new Date());
      return;
    }

    await runConnectionTests();
    await runTableTests();
    await runRLSTests();
    await runStorageTests();
    await runRealtimeTests();
    await runEdgeFunctionTests();
    await runAgoraTests();
    await checkBootstrapStatus();

    setLastRun(new Date());
    setIsRunning(false);
  };

  useEffect(() => {
    if (isSupabaseConfigured) {
      const timer = setTimeout(runAllSync, 500);
      return () => clearTimeout(timer);
    }
  }, []); // eslint-disable-line

  // ---- Stats ----
  const allChecks = categories.flatMap(c => c.checks);
  const totalChecks = allChecks.length;
  const okChecks = allChecks.filter(c => c.status === 'ok').length;
  const errorChecks = allChecks.filter(c => c.status === 'error').length;
  const warningChecks = allChecks.filter(c => c.status === 'warning').length;
  const progress = totalChecks > 0 ? Math.round((okChecks / totalChecks) * 100) : 0;
  const hasRun = allChecks.some(c => c.status !== 'idle');

  const overallStatus: ServiceStatus = !hasRun ? 'idle'
    : isRunning ? 'checking'
    : errorChecks > 0 ? 'error'
    : warningChecks > 0 ? 'warning'
    : 'ok';

  // Count missing tables specifically
  const tablesCat = categories.find(c => c.id === 'tables');
  const missingTableChecks = tablesCat?.checks.filter(c => c.status === 'error' && c.fixable) || [];
  const hasMissingTables = missingTableChecks.length > 0;

  const toggleService = (id: string) => {
    setExpandedServices(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleCopy = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedText(id);
      setTimeout(() => setCopiedText(null), 2000);
    } catch {}
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-gray-900 to-slate-950">
      {/* Background effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-purple-500/5 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-cyan-500/3 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 py-8">
        {/* ==================== HEADER ==================== */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
                <Link2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Connecter & Synchroniser</h1>
                <p className="text-gray-400 text-sm">Connexion, tables, RLS, stockage, temps réel, Edge Functions et Agora</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
              onClick={() => navigate('/setup')}
            >
              <Settings className="w-4 h-4 mr-2" />
              Setup
            </Button>
            <Button
              onClick={runAllSync}
              disabled={isRunning}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold shadow-lg shadow-blue-500/25 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRunning ? 'animate-spin' : ''}`} />
              {isRunning ? 'Synchronisation...' : 'Synchroniser tout'}
            </Button>
          </div>
        </div>

        {/* ==================== AUTO-FIX BANNER ==================== */}
        {hasRun && !isRunning && hasMissingTables && (
          <Card className="mb-6 border-purple-500/30 bg-gradient-to-r from-purple-500/10 to-pink-500/10 backdrop-blur-sm overflow-hidden">
            <CardContent className="p-5">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/25">
                    <Wrench className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      Auto-Fix disponible
                    </h3>
                    <p className="text-gray-400 text-sm">
                      {missingTableChecks.length} table(s) manquante(s) détectée(s).
                      {bootstrapReady === true && ' Cliquez pour les créer automatiquement.'}
                      {bootstrapReady === false && ' Bootstrap requis avant l\'auto-fix.'}
                      {bootstrapReady === null && ' Vérification en cours...'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {bootstrapReady === false && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-amber-500/30 text-amber-300 hover:bg-amber-500/20"
                      onClick={() => setShowBootstrapGuide(true)}
                    >
                      <Terminal className="w-4 h-4 mr-2" />
                      Bootstrap
                    </Button>
                  )}
                  <Button
                    onClick={fixAllMissingTables}
                    disabled={isFixingAll || bootstrapReady === false}
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white font-semibold shadow-lg shadow-purple-500/25 disabled:opacity-50"
                  >
                    {isFixingAll ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Wrench className="w-4 h-4 mr-2" />
                    )}
                    {isFixingAll ? 'Création en cours...' : `Corriger toutes les tables (${missingTableChecks.length})`}
                  </Button>
                </div>
              </div>

              {/* Fix All Result */}
              {fixAllResult && (
                <div className={`mt-4 p-3 rounded-lg border ${
                  fixAllResult.success
                    ? 'bg-emerald-500/10 border-emerald-500/30'
                    : 'bg-red-500/10 border-red-500/30'
                }`}>
                  <div className="flex items-start gap-2">
                    {fixAllResult.success ? (
                      <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <p className={`text-sm font-medium ${fixAllResult.success ? 'text-emerald-300' : 'text-red-300'}`}>
                        {fixAllResult.message}
                      </p>
                      {fixAllResult.created.length > 0 && (
                        <p className="text-xs text-emerald-400/80 mt-1">
                          Créées: {fixAllResult.created.join(', ')}
                        </p>
                      )}
                      {fixAllResult.failed.length > 0 && (
                        <p className="text-xs text-red-400/80 mt-1">
                          Échouées: {fixAllResult.failed.map((f: any) => `${f.table} (${f.error})`).join(', ')}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* ==================== BOOTSTRAP GUIDE ==================== */}
        {showBootstrapGuide && bootstrapReady === false && (
          <Card className="mb-6 border-amber-500/30 bg-amber-500/5 backdrop-blur-sm">
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center flex-shrink-0 shadow-lg shadow-amber-500/25">
                  <Terminal className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-amber-300 font-semibold">Bootstrap requis</h3>
                    <button onClick={() => setShowBootstrapGuide(false)} className="text-gray-500 hover:text-white">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Pour activer l'auto-fix, vous devez d'abord créer la fonction <code className="text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded">exec_migration_sql</code> dans votre base de données.
                    Cette opération est nécessaire une seule fois.
                  </p>
                  <div className="bg-gray-950/80 rounded-xl p-4 space-y-2 text-xs font-mono text-gray-300 border border-gray-800/50">
                    <p className="text-amber-400 font-semibold">Étapes :</p>
                    <p>1. Ouvrez le <a href={projectRef ? `https://supabase.com/dashboard/project/${projectRef}/sql/new` : 'https://supabase.com/dashboard'} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">SQL Editor de Supabase</a></p>
                    <p>2. Collez le SQL ci-dessous et exécutez-le</p>
                    <p>3. Revenez ici et relancez la synchronisation</p>
                  </div>
                  {bootstrapSql && (
                    <div className="relative group">
                      <pre className="bg-gray-950/80 rounded-xl p-4 text-xs font-mono text-gray-400 whitespace-pre-wrap border border-gray-800/50 max-h-48 overflow-y-auto">
                        {bootstrapSql}
                      </pre>
                      <button
                        onClick={() => handleCopy(bootstrapSql, 'bootstrap_sql')}
                        className="absolute top-2 right-2 p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-500 hover:text-white transition-all"
                      >
                        {copiedText === 'bootstrap_sql' ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  )}
                  <div className="flex gap-2">
                    <a
                      href={projectRef ? `https://supabase.com/dashboard/project/${projectRef}/sql/new` : 'https://supabase.com/dashboard'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-300 text-sm font-medium transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                      SQL Editor
                    </a>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-gray-700 text-gray-300 hover:bg-gray-800"
                      onClick={async () => {
                        await checkBootstrapStatus();
                        if (bootstrapReady) setShowBootstrapGuide(false);
                      }}
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Vérifier
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* ==================== OVERVIEW CARDS ==================== */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <Card className="border-gray-800 bg-gray-900/60 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <p className="text-3xl font-bold text-white">{totalChecks}</p>
              <p className="text-gray-500 text-xs mt-1">Tests totaux</p>
            </CardContent>
          </Card>
          <Card className="border-emerald-500/20 bg-emerald-500/5 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <p className="text-3xl font-bold text-emerald-400">{okChecks}</p>
              <p className="text-gray-500 text-xs mt-1">Réussis</p>
            </CardContent>
          </Card>
          <Card className="border-amber-500/20 bg-amber-500/5 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <p className="text-3xl font-bold text-amber-400">{warningChecks}</p>
              <p className="text-gray-500 text-xs mt-1">Avertissements</p>
            </CardContent>
          </Card>
          <Card className="border-red-500/20 bg-red-500/5 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <p className="text-3xl font-bold text-red-400">{errorChecks}</p>
              <p className="text-gray-500 text-xs mt-1">Erreurs</p>
            </CardContent>
          </Card>
        </div>

        {/* ==================== PROGRESS BAR ==================== */}
        {hasRun && (
          <Card className={`border ${statusColors[overallStatus].border} ${statusColors[overallStatus].bg} backdrop-blur-sm mb-6`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${statusColors[overallStatus].dot}`} />
                  <span className={`font-semibold text-sm ${statusColors[overallStatus].text}`}>
                    {overallStatus === 'ok' && 'Tous les services sont connectés'}
                    {overallStatus === 'checking' && 'Synchronisation en cours...'}
                    {overallStatus === 'warning' && `${warningChecks} avertissement(s)`}
                    {overallStatus === 'error' && `${errorChecks} erreur(s) détectée(s)`}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-gray-400 text-sm font-mono">{progress}%</span>
                  {lastRun && (
                    <span className="text-gray-600 text-xs">
                      {lastRun.toLocaleTimeString('fr-FR')}
                    </span>
                  )}
                </div>
              </div>
              <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                <div className="h-full flex transition-all duration-700">
                  <div className="bg-emerald-500 transition-all duration-500" style={{ width: `${(okChecks / totalChecks) * 100}%` }} />
                  <div className="bg-amber-500 transition-all duration-500" style={{ width: `${(warningChecks / totalChecks) * 100}%` }} />
                  <div className="bg-red-500 transition-all duration-500" style={{ width: `${(errorChecks / totalChecks) * 100}%` }} />
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* ==================== NOT CONFIGURED BANNER ==================== */}
        {!isSupabaseConfigured && (
          <Alert className="mb-6 border-blue-500/30 bg-blue-500/10">
            <Info className="h-4 w-4 text-blue-400" />
            <AlertDescription className="text-blue-300">
              Supabase n'est pas configuré. <button onClick={() => navigate('/setup')} className="underline font-semibold hover:text-blue-200">Allez dans /setup</button> pour connecter votre projet.
            </AlertDescription>
          </Alert>
        )}

        {/* ==================== SERVICE CATEGORIES ==================== */}
        <div className="space-y-3">
          {categories.map((cat) => {
            const isExpanded = expandedServices.has(cat.id);
            const sc = statusColors[cat.overallStatus];
            const okCount = cat.checks.filter(c => c.status === 'ok').length;
            const totalCount = cat.checks.length;
            const catMissingTables = cat.id === 'tables' ? cat.checks.filter(c => c.status === 'error' && c.fixable) : [];

            return (
              <Card key={cat.id} className={`border transition-all backdrop-blur-sm overflow-hidden ${sc.border} ${
                cat.overallStatus === 'idle' ? 'bg-gray-900/40' : sc.bg
              }`}>
                {/* Category Header */}
                <button
                  onClick={() => toggleService(cat.id)}
                  className="w-full flex items-center gap-4 p-4 text-left hover:bg-white/[0.02] transition-colors"
                >
                  <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${cat.gradient} flex items-center justify-center flex-shrink-0 shadow-lg ${cat.shadowColor}`}>
                    {cat.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-white font-semibold text-sm">{cat.label}</h3>
                      {cat.overallStatus !== 'idle' && (
                        <Badge className={`text-[10px] ${
                          cat.overallStatus === 'ok' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                          cat.overallStatus === 'error' ? 'bg-red-500/10 text-red-400 border-red-500/30' :
                          cat.overallStatus === 'warning' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' :
                          'bg-blue-500/10 text-blue-400 border-blue-500/30'
                        }`}>
                          {cat.overallStatus === 'checking' && <Loader2 className="w-3 h-3 mr-1 animate-spin" />}
                          {cat.overallStatus === 'ok' && <CheckCircle className="w-3 h-3 mr-1" />}
                          {cat.overallStatus === 'error' && <X className="w-3 h-3 mr-1" />}
                          {cat.overallStatus === 'warning' && <AlertTriangle className="w-3 h-3 mr-1" />}
                          {statusLabels[cat.overallStatus]}
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-500 text-xs mt-0.5">{cat.description}</p>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    {cat.overallStatus !== 'idle' && (
                      <span className={`text-xs font-mono ${sc.text}`}>
                        {okCount}/{totalCount}
                      </span>
                    )}
                    {/* Auto-fix button in tables category header */}
                    {cat.id === 'tables' && catMissingTables.length > 0 && (
                      <div
                        onClick={(e) => { e.stopPropagation(); fixAllMissingTables(); }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                          isFixingAll || bootstrapReady === false
                            ? 'bg-gray-700/50 text-gray-500 cursor-not-allowed'
                            : 'bg-purple-500/20 hover:bg-purple-500/30 text-purple-300'
                        }`}
                      >
                        {isFixingAll ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Wrench className="w-3 h-3" />
                        )}
                        {isFixingAll ? 'Correction...' : `Auto-Fix (${catMissingTables.length})`}
                      </div>
                    )}
                    {cat.overallStatus === 'error' && cat.id !== 'tables' && cat.fixUrl && (
                      <a
                        href={cat.fixUrl.startsWith('/') ? undefined : cat.fixUrl}
                        onClick={(e) => {
                          if (cat.fixUrl?.startsWith('/')) {
                            e.preventDefault();
                            e.stopPropagation();
                            navigate(cat.fixUrl!);
                          } else {
                            e.stopPropagation();
                          }
                        }}
                        target={cat.fixUrl?.startsWith('/') ? undefined : '_blank'}
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 text-xs font-medium transition-colors flex items-center gap-1.5"
                      >
                        <Settings className="w-3 h-3" />
                        {cat.fixLabel}
                      </a>
                    )}
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
                  </div>
                </button>

                {/* Expanded Checks */}
                {isExpanded && (
                  <div className="border-t border-gray-800/50">
                    {cat.checks.map((check) => {
                      const csc = statusColors[check.status];
                      return (
                        <div key={check.id}>
                          <div className={`flex items-center gap-3 px-5 py-2.5 border-b border-gray-800/30 last:border-b-0 transition-colors ${
                            check.status === 'error' ? 'bg-red-500/5' :
                            check.status === 'ok' ? 'bg-emerald-500/5' :
                            check.status === 'warning' ? 'bg-amber-500/5' : ''
                          }`}>
                            <div className="flex-shrink-0">
                              {check.status === 'idle' && <div className="w-5 h-5 rounded-full border-2 border-gray-700" />}
                              {check.status === 'checking' && <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />}
                              {check.status === 'ok' && <CheckCircle className="w-5 h-5 text-emerald-400" />}
                              {check.status === 'error' && <X className="w-5 h-5 text-red-400" />}
                              {check.status === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-400" />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <span className="text-white font-mono text-xs">{check.label}</span>
                              {check.message && (
                                <p className={`text-xs mt-0.5 ${csc.text}`}>{check.message}</p>
                              )}
                              {/* Fix result message */}
                              {check.fixResult && (
                                <p className={`text-xs mt-0.5 font-medium ${
                                  check.fixResult === 'success' ? 'text-emerald-400' : 'text-red-400'
                                }`}>
                                  {check.fixResult === 'success' ? <Check className="w-3 h-3 inline mr-1" /> : <AlertTriangle className="w-3 h-3 inline mr-1" />}
                                  {check.fixMessage}
                                </p>
                              )}
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              {check.duration !== undefined && (
                                <span className="text-gray-600 text-xs font-mono">{check.duration}ms</span>
                              )}
                              {/* Individual Create Table button */}
                              {check.status === 'error' && check.fixable && check.tableName && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    fixSingleTable(check.tableName!);
                                  }}
                                  disabled={check.isFixing || bootstrapReady === false}
                                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all flex items-center gap-1.5 ${
                                    check.isFixing
                                      ? 'bg-blue-500/20 text-blue-300 cursor-wait'
                                      : bootstrapReady === false
                                      ? 'bg-gray-700/50 text-gray-500 cursor-not-allowed'
                                      : 'bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 hover:text-purple-200'
                                  }`}
                                >
                                  {check.isFixing ? (
                                    <Loader2 className="w-3 h-3 animate-spin" />
                                  ) : (
                                    <Play className="w-3 h-3" />
                                  )}
                                  {check.isFixing ? 'Création...' : 'Créer la table'}
                                </button>
                              )}
                            </div>
                          </div>
                          {check.details && (
                            <div className="px-5 pb-2">
                              <div className="bg-gray-950/80 rounded-lg p-3 text-xs font-mono text-gray-400 whitespace-pre-wrap border border-gray-800/50 relative group">
                                {check.details}
                                <button
                                  onClick={() => handleCopy(check.details!, check.id)}
                                  className="absolute top-2 right-2 p-1.5 rounded-md bg-gray-800 hover:bg-gray-700 text-gray-500 hover:text-white transition-all opacity-0 group-hover:opacity-100"
                                >
                                  {copiedText === check.id ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        {/* ==================== AGORA SETUP GUIDE (when errors) ==================== */}
        {hasRun && categories.find(c => c.id === 'agora')?.overallStatus === 'error' && (
          <Card className="mt-6 border-red-500/30 bg-red-500/5 backdrop-blur-sm">
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500 to-rose-500 flex items-center justify-center flex-shrink-0 shadow-lg shadow-red-500/25">
                  <Radio className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 space-y-3">
                  <h3 className="text-red-300 font-semibold">Configuration Agora requise</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Les secrets <code className="text-red-300 bg-red-500/20 px-1.5 py-0.5 rounded">AGORA_APP_ID</code> et{' '}
                    <code className="text-red-300 bg-red-500/20 px-1.5 py-0.5 rounded">AGORA_APP_CERTIFICATE</code> doivent être configurés pour activer le streaming en temps réel.
                  </p>
                  <div className="bg-gray-900/80 rounded-xl p-4 space-y-2 text-xs font-mono text-gray-300 border border-gray-800/50">
                    <p className="text-amber-400 font-semibold">Étapes :</p>
                    <p>1. <a href="https://console.agora.io" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">console.agora.io</a> &gt; Votre projet</p>
                    <p>2. Copiez l'<span className="text-emerald-400">App ID</span> et le <span className="text-emerald-400">Primary Certificate</span></p>
                    <p>3. <a href={getEdgeFunctionSecretsUrl()} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">Dashboard Supabase</a> &gt; Edge Functions &gt; Secrets</p>
                    <p>4. Ajoutez <span className="text-purple-300">AGORA_APP_ID</span> et <span className="text-purple-300">AGORA_APP_CERTIFICATE</span></p>
                    <p>5. Relancez la synchronisation</p>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href="https://console.agora.io"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-300 text-sm font-medium transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Console Agora
                    </a>
                    <a
                      href={getEdgeFunctionSecretsUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/30 text-purple-300 text-sm font-medium transition-colors"
                    >
                      <Key className="w-4 h-4" />
                      Edge Function Secrets
                    </a>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* ==================== ALL OK BANNER ==================== */}
        {hasRun && !isRunning && overallStatus === 'ok' && (
          <Card className="mt-6 border-emerald-500/30 bg-emerald-500/5 backdrop-blur-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center shadow-lg shadow-emerald-500/25">
                  <CheckCircle className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-emerald-300 font-bold text-lg">Tout est synchronisé !</h3>
                  <p className="text-gray-400 text-sm">
                    Les 7 services Supabase sont connectés et opérationnels. Votre plateforme est prête.
                  </p>
                </div>
                <Button
                  onClick={() => navigate('/')}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  Accueil
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* ==================== QUICK LINKS ==================== */}
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => navigate('/setup')}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-gray-900/60 border border-gray-800/50 hover:bg-gray-800/60 hover:border-gray-700 transition-all text-left"
          >
            <Globe className="w-5 h-5 text-blue-400 flex-shrink-0" />
            <div>
              <p className="text-white text-xs font-medium">Configuration</p>
              <p className="text-gray-600 text-[10px]">Clés Supabase</p>
            </div>
          </button>
          <button
            onClick={() => navigate('/setup?tab=database')}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-gray-900/60 border border-gray-800/50 hover:bg-gray-800/60 hover:border-gray-700 transition-all text-left"
          >
            <Database className="w-5 h-5 text-purple-400 flex-shrink-0" />
            <div>
              <p className="text-white text-xs font-medium">Base de données</p>
              <p className="text-gray-600 text-[10px]">Tables & SQL</p>
            </div>
          </button>
          <button
            onClick={() => navigate('/diagnostics')}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-gray-900/60 border border-gray-800/50 hover:bg-gray-800/60 hover:border-gray-700 transition-all text-left"
          >
            <Eye className="w-5 h-5 text-cyan-400 flex-shrink-0" />
            <div>
              <p className="text-white text-xs font-medium">Diagnostics</p>
              <p className="text-gray-600 text-[10px]">Tests détaillés</p>
            </div>
          </button>
          {projectRef ? (
            <a
              href={`https://supabase.com/dashboard/project/${projectRef}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2.5 p-3 rounded-xl bg-gray-900/60 border border-gray-800/50 hover:bg-gray-800/60 hover:border-gray-700 transition-all text-left"
            >
              <ExternalLink className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              <div>
                <p className="text-white text-xs font-medium">Dashboard</p>
                <p className="text-gray-600 text-[10px]">Supabase</p>
              </div>
            </a>
          ) : (
            <a
              href="https://supabase.com/dashboard"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2.5 p-3 rounded-xl bg-gray-900/60 border border-gray-800/50 hover:bg-gray-800/60 hover:border-gray-700 transition-all text-left"
            >
              <ExternalLink className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              <div>
                <p className="text-white text-xs font-medium">Dashboard</p>
                <p className="text-gray-600 text-[10px]">Supabase</p>
              </div>
            </a>
          )}
        </div>

        {/* ==================== CONFIG INFO ==================== */}
        <div className="mt-6 rounded-xl border border-gray-800/50 bg-gray-900/30 p-4">
          <div className="flex items-start gap-3">
            <Info className="w-4 h-4 text-gray-500 flex-shrink-0 mt-0.5" />
            <div className="text-xs text-gray-500 space-y-1">
              <p className="text-gray-400 font-medium">Informations</p>
              <p>Supabase: <span className={isSupabaseConfigured ? 'text-emerald-400' : 'text-red-400'}>{isSupabaseConfigured ? 'Configuré' : 'Non configuré'}</span></p>
              <p>Source: <span className="text-gray-400 font-mono">{getConfigDiagnostics().source}</span></p>
              <p>URL: <span className="text-gray-400 font-mono">{getConfigDiagnostics().url}</span></p>
              <p>Auto-Fix: <span className={bootstrapReady ? 'text-emerald-400' : bootstrapReady === false ? 'text-amber-400' : 'text-gray-400'}>
                {bootstrapReady ? 'Activé (exec_migration_sql)' : bootstrapReady === false ? 'Bootstrap requis' : 'Non vérifié'}
              </span></p>
              {isAuthenticated && user && (
                <p>Utilisateur: <span className="text-gray-400">{user.email}</span></p>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 pb-4">
          <p className="text-gray-700 text-xs">Famous.ai — Connecter & Synchroniser Supabase</p>
        </div>
      </div>
    </div>
  );
};

export default ConnectSyncPage;
