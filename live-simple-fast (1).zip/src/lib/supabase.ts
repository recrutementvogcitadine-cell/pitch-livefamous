import { createClient, SupabaseClient } from '@supabase/supabase-js';

// ============================================================================
// SUPABASE CLIENT CONFIGURATION — PRODUCTION MODE
// Supports both .env variables AND runtime localStorage credentials
// ============================================================================

// ---- localStorage keys for runtime configuration ----
const LS_KEY_URL = 'famous_supabase_url';
const LS_KEY_ANON = 'famous_supabase_anon_key';

// ---- Read from localStorage (runtime config from Setup UI) ----
function getLocalStorageValue(key: string): string {
  try {
    return localStorage.getItem(key) || '';
  } catch {
    return '';
  }
}

// ---- Resolve credentials: localStorage first, then env vars ----
const runtimeUrl = getLocalStorageValue(LS_KEY_URL);
const runtimeKey = getLocalStorageValue(LS_KEY_ANON);

const envUrl =
  import.meta.env.VITE_SUPABASE_URL ||
  import.meta.env.SUPABASE_URL ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_URL ||
  import.meta.env.REACT_APP_SUPABASE_URL ||
  '';

const envKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  import.meta.env.SUPABASE_ANON_KEY ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  import.meta.env.REACT_APP_SUPABASE_ANON_KEY ||
  '';

// Runtime (localStorage) takes priority over env vars
const supabaseUrl = runtimeUrl || envUrl;
const supabaseKey = runtimeKey || envKey;

// Robust detection: check if we have REAL credentials
const hasRealUrl = !!(supabaseUrl && supabaseUrl.includes('.supabase.co') && !supabaseUrl.includes('placeholder') && !supabaseUrl.includes('your-project'));
const hasRealKey = !!(supabaseKey && supabaseKey.length > 30 && !supabaseKey.includes('placeholder') && !supabaseKey.includes('your-anon'));

// IMPORTANT: Always consider configured if we have a real-looking URL
export const isSupabaseConfigured = hasRealUrl && hasRealKey;

// Whether credentials came from localStorage (runtime setup)
export const isRuntimeConfigured = !!(runtimeUrl && runtimeKey);

// ============================================================================
// RUNTIME CREDENTIAL MANAGEMENT — Save/Clear/Test from the Setup UI
// ============================================================================

/**
 * Save Supabase credentials to localStorage and reload the page.
 * This allows users to configure Supabase from the Setup UI without editing .env files.
 */
export function saveRuntimeCredentials(url: string, anonKey: string): void {
  try {
    localStorage.setItem(LS_KEY_URL, url.trim());
    localStorage.setItem(LS_KEY_ANON, anonKey.trim());
  } catch (err) {
    console.error('[Supabase] Failed to save runtime credentials:', err);
  }
}

/**
 * Clear runtime credentials from localStorage.
 */
export function clearRuntimeCredentials(): void {
  try {
    localStorage.removeItem(LS_KEY_URL);
    localStorage.removeItem(LS_KEY_ANON);
  } catch {
    // ignore
  }
}

/**
 * Get current runtime credentials (for display in the UI).
 */
export function getRuntimeCredentials(): { url: string; anonKey: string } {
  return {
    url: getLocalStorageValue(LS_KEY_URL),
    anonKey: getLocalStorageValue(LS_KEY_ANON),
  };
}

/**
 * Test a connection with given credentials WITHOUT saving them.
 * Creates a temporary client and tries a simple query.
 */
export async function testCredentials(url: string, anonKey: string): Promise<{ success: boolean; error?: string }> {
  if (!url || !url.includes('.supabase.co')) {
    return { success: false, error: "L'URL doit être une URL Supabase valide (ex: https://xxx.supabase.co)" };
  }
  if (!anonKey || anonKey.length < 30) {
    return { success: false, error: 'La clé anon semble invalide (trop courte).' };
  }

  try {
    const testClient = createClient(url.trim(), anonKey.trim(), {
      auth: { autoRefreshToken: false, persistSession: false },
      global: {
        fetch: async (input, init) => {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 10000);
          try {
            const response = await globalThis.fetch(input, { ...init, signal: controller.signal });
            clearTimeout(timeoutId);
            return response;
          } catch (err: any) {
            clearTimeout(timeoutId);
            throw err;
          }
        },
      },
    });

    // Try to query something simple — even a 404 table error means the connection works
    const { error } = await testClient.from('creator_profiles').select('id', { count: 'exact', head: true });

    if (error) {
      // These errors mean the server responded (connection works!)
      if (error.code === '42P01') return { success: true }; // Table doesn't exist
      if (error.code === '42501') return { success: true }; // Permission denied (RLS)
      if (error.code?.startsWith('PGRST')) return { success: true }; // PostgREST error
      if (error.message?.includes('JWT')) {
        return { success: false, error: 'Clé API invalide. Vérifiez que vous utilisez la clé "anon" (publique).' };
      }
      // Any other error from the server still means connection works
      return { success: true };
    }

    return { success: true };
  } catch (err: any) {
    const msg = err?.message || '';
    if (msg.includes('AbortError') || msg.includes('timeout')) {
      return { success: false, error: 'Le serveur ne répond pas. Vérifiez l\'URL du projet.' };
    }
    if (msg.includes('fetch') || msg.includes('network') || msg.includes('Failed')) {
      return { success: false, error: 'Impossible de joindre le serveur. Vérifiez l\'URL et votre connexion internet.' };
    }
    return { success: false, error: `Erreur de connexion : ${msg}` };
  }
}

// ============================================================================
// SAFE FETCH WRAPPER — handles non-JSON errors gracefully
// IMPORTANT: When the caller provides its own AbortSignal (e.g. Supabase GoTrue
// navigator lock), we must let AbortErrors propagate so the library's internal
// error handling works correctly. We only convert to 503 for OUR OWN timeouts.
// ============================================================================
const safeFetch: typeof globalThis.fetch = async (input, init) => {
  // Determine if the caller provided their own abort signal
  const callerSignal = init?.signal ?? null;
  const hasCallerSignal = !!callerSignal;

  // If the caller's signal is already aborted, throw immediately
  // (don't even attempt the fetch — this is what the caller expects)
  if (callerSignal?.aborted) {
    throw callerSignal.reason ?? new DOMException('signal is aborted without reason', 'AbortError');
  }

  // Create our own timeout controller (safety net for slow connections)
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000);

  // Compose signals: if the caller has one, use it; otherwise use ours.
  // We avoid AbortSignal.any() for broader browser compat.
  // If the caller provides a signal, we listen for its abort to also abort ours,
  // and vice versa — but we track WHO caused the abort.
  let abortedByTimeout = false;
  let effectiveSignal: AbortSignal;

  if (hasCallerSignal) {
    // Use the caller's signal directly — they own the lifecycle.
    // Also set up our own timeout to abort if the request is too slow.
    effectiveSignal = callerSignal;

    // If our timeout fires, abort via the caller's mechanism isn't possible,
    // so we just let the caller's signal win. The 30s timeout is a last resort.
    const timeoutFallback = setTimeout(() => {
      abortedByTimeout = true;
      controller.abort();
    }, 30000);

    // Clean up the fallback timeout when the caller's signal aborts
    callerSignal.addEventListener('abort', () => {
      clearTimeout(timeoutFallback);
    }, { once: true });
  } else {
    // No caller signal — use our own timeout controller
    effectiveSignal = controller.signal;
    abortedByTimeout = true; // If this fires, it's always our timeout
  }

  try {
    const mergedInit = {
      ...init,
      signal: effectiveSignal,
    };

    const response = await globalThis.fetch(input, mergedInit);
    clearTimeout(timeoutId);

    // ---- Handle non-OK responses (4xx, 5xx) ----
    if (!response.ok) {
      const cloned = response.clone();
      let bodyText = '';
      try {
        bodyText = await cloned.text();
      } catch {
        bodyText = `HTTP ${response.status} ${response.statusText}`;
      }

      try {
        JSON.parse(bodyText);
        return response;
      } catch {
        const errorJson = JSON.stringify({
          error: bodyText || `HTTP ${response.status}`,
          message: bodyText || `Erreur serveur (${response.status})`,
          statusCode: response.status,
        });

        return new Response(errorJson, {
          status: response.status,
          statusText: response.statusText,
          headers: new Headers({ 'content-type': 'application/json' }),
        });
      }
    }

    // ---- Handle OK responses that may have wrong content-type ----
    const contentType = response.headers.get('content-type') || '';
    const url = typeof input === 'string' ? input : (input as Request).url || '';
    const isEdgeFunctionCall = url.includes('/functions/v1/');
    const isRestApiCall = url.includes('/rest/v1/');

    // FIX: Catch REST API responses that return HTML instead of JSON
    // This happens when a proxy/CDN/load-balancer returns an HTML error page with 200 OK
    if ((isRestApiCall || isEdgeFunctionCall) && contentType.includes('text/html')) {
      let bodyText = '';
      try {
        bodyText = await response.text();
      } catch {
        bodyText = 'Unexpected HTML response';
      }

      // Try to parse as JSON anyway (some servers send JSON with wrong content-type)
      try {
        JSON.parse(bodyText);
        return new Response(bodyText, {
          status: response.status,
          statusText: response.statusText,
          headers: new Headers({ 'content-type': 'application/json' }),
        });
      } catch {
        // It's truly HTML — wrap it as a JSON error
        const errorJson = JSON.stringify({
          error: 'Server returned HTML instead of JSON',
          message: 'Le serveur a renvoyé une réponse inattendue (HTML au lieu de JSON). Vérifiez votre connexion et la configuration Supabase.',
          statusCode: 502,
          _htmlPreview: bodyText.substring(0, 200),
        });

        return new Response(errorJson, {
          status: 502,
          statusText: 'Bad Gateway',
          headers: new Headers({ 'content-type': 'application/json' }),
        });
      }
    }

    // Handle edge function non-JSON responses (existing logic)
    if (isEdgeFunctionCall && !contentType.includes('application/json')) {
      let bodyText = '';
      try {
        bodyText = await response.text();
      } catch {
        bodyText = 'Unknown response';
      }

      try {
        JSON.parse(bodyText);
        return new Response(bodyText, {
          status: response.status,
          statusText: response.statusText,
          headers: new Headers({ 'content-type': 'application/json' }),
        });
      } catch {
        const errorJson = JSON.stringify({
          error: bodyText || 'Edge function returned non-JSON response',
          message: bodyText || 'Erreur de la fonction serveur',
          statusCode: response.status,
          success: false,
        });

        return new Response(errorJson, {
          status: 502,
          statusText: 'Bad Gateway',
          headers: new Headers({ 'content-type': 'application/json' }),
        });
      }
    }

    return response;

  } catch (err: any) {
    clearTimeout(timeoutId);

    // CRITICAL: If the caller provided their own signal and it was aborted,
    // re-throw the error so the Supabase GoTrue library can handle it
    // (e.g., navigator lock timeout). Do NOT swallow it into a 503 Response.
    if (hasCallerSignal && err?.name === 'AbortError') {
      throw err;
    }

    // Our own timeout or a genuine network error — convert to a safe 503 Response
    const isTimeout = err?.name === 'AbortError' && abortedByTimeout;
    const errorJson = JSON.stringify({
      error: isTimeout ? 'Request timeout' : (err?.message || 'Network error'),
      message: isTimeout
        ? 'Le serveur ne répond pas. Vérifiez votre connexion et vos paramètres Supabase.'
        : 'Impossible de joindre le serveur. Vérifiez votre connexion.',
      statusCode: 0,
    });

    return new Response(errorJson, {
      status: 503,
      statusText: 'Service Unavailable',
      headers: new Headers({ 'content-type': 'application/json' }),
    });
  }
};

// ============================================================================
// CREATE SUPABASE CLIENT
// ============================================================================
const finalUrl = supabaseUrl || 'https://placeholder.supabase.co';
const finalKey = supabaseKey || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.placeholder';

export const supabase: SupabaseClient = createClient(finalUrl, finalKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    // Use a unique storage key to avoid lock contention with other Supabase apps
    storageKey: 'pitchci-auth-token',
    // Increase the lock timeout to avoid premature AbortError on slow connections
    // flowType 'implicit' avoids PKCE lock contention
    flowType: 'implicit',
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
  global: {
    fetch: safeFetch,
    headers: {
      'x-client-info': 'pitchci-web/2.0',
    },
  },
});


// ============================================================================
// CONNECTION TEST — actually tests the connection
// ============================================================================
export const testConnection = async (): Promise<{ success: boolean; error?: string; tablesExist?: boolean }> => {
  if (!isSupabaseConfigured) {
    return {
      success: false,
      error: 'Variables d\'environnement Supabase manquantes ou invalides. Vérifiez VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY dans votre fichier .env',
    };
  }

  try {
    const { error } = await supabase.from('creator_profiles').select('id', { count: 'exact', head: true });
    if (error) {
      // Table doesn't exist (PostgreSQL native error)
      if (error.code === '42P01') return { success: true, tablesExist: false };
      // Permission denied — table exists but RLS blocks access
      if (error.code === '42501') return { success: true, tablesExist: true };
      // PostgREST errors (PGRST200-series) — server responded, connection works
      if (error.code?.startsWith('PGRST')) return { success: true, tablesExist: false };

      // ================================================================
      // FIX: Handle 404 responses where the error code is lost (HEAD requests)
      // When PostgREST returns 404 for a missing table via HEAD request,
      // the safeFetch wrapper creates a generic error with code=undefined
      // and message containing "404". The server DID respond, so connection works.
      // ================================================================
      const errMsg = (error.message || '').toLowerCase();
      const errStatus = (error as any)?.statusCode || (error as any)?.status;

      // Check for 404 in message or status — means table not found, but server is reachable
      if (errStatus === 404 || errMsg.includes('404') || errMsg.includes('not found')) {
        return { success: true, tablesExist: false };
      }

      // Check for other server responses that indicate the connection works
      if (errMsg.includes('schema cache') || errMsg.includes('does not exist') || errMsg.includes('relation')) {
        return { success: true, tablesExist: false };
      }

      // Any other error with a defined code means server responded
      if (error.code) {
        return { success: true, tablesExist: undefined };
      }

      // If the error message suggests a server response (not a network error), treat as success
      if (errMsg.includes('erreur serveur') || errMsg.includes('server error') || errMsg.includes('http')) {
        return { success: true, tablesExist: false };
      }

      return { success: false, error: `Erreur serveur : ${error.message} (code: ${error.code})` };
    }
    return { success: true, tablesExist: true };
  } catch (err: any) {
    return {
      success: false,
      error: `Impossible de joindre le serveur : ${err?.message || 'Erreur réseau'}`,
    };
  }
};

/**
 * Check if the required database tables exist.
 * Returns true if at least the core table (creator_profiles) exists.
 */
export const checkTablesExist = async (): Promise<boolean> => {
  if (!isSupabaseConfigured) return false;
  try {
    const { error } = await supabase.from('creator_profiles').select('id').limit(1);
    if (!error) return true;
    // If the error indicates the table exists but is empty or has RLS, it still exists
    if (error.code === '42501') return true; // Permission denied = table exists
    // Table not found errors
    if (error.code === '42P01') return false;
    if (error.code?.startsWith('PGRST')) return false;
    const errMsg = (error.message || '').toLowerCase();
    if (errMsg.includes('404') || errMsg.includes('not found') || errMsg.includes('schema cache') || errMsg.includes('does not exist')) {
      return false;
    }
    // Unknown error — assume tables might exist
    return true;
  } catch {
    return false;
  }
};

// Diagnostic helper
export const getConfigDiagnostics = () => ({
  isConfigured: isSupabaseConfigured,
  isRuntimeConfigured,
  url: supabaseUrl ? `${supabaseUrl.substring(0, 50)}...` : '(vide)',
  keyLength: supabaseKey ? supabaseKey.length : 0,
  urlEmpty: !supabaseUrl,
  keyEmpty: !supabaseKey,
  hasRealUrl,
  hasRealKey,
  source: runtimeUrl ? 'localStorage' : (envUrl ? '.env' : 'none'),
});

/**
 * Extract the Supabase project reference from the configured URL.
 * URL format: https://<project-ref>.supabase.co
 * Returns the project ref string, or null if not parseable.
 */
export function getProjectRef(): string | null {
  const url = supabaseUrl;
  if (!url) return null;
  try {
    const hostname = new URL(url).hostname; // e.g. "abcdefgh.supabase.co"
    const parts = hostname.split('.');
    if (parts.length >= 3 && parts[1] === 'supabase') {
      return parts[0];
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * Get the Supabase Dashboard URL for the Authentication Providers page.
 * This is used to guide users to disable email confirmation.
 */
export function getAuthProvidersUrl(): string {
  const ref = getProjectRef();
  if (ref) {
    return `https://supabase.com/dashboard/project/${ref}/auth/providers`;
  }
  return 'https://supabase.com/dashboard';
}

/**
 * Get the Supabase Dashboard URL for the Email Templates configuration page.
 * Dashboard > Authentication > Email Templates
 */
export function getEmailTemplatesUrl(): string {
  const ref = getProjectRef();
  if (ref) {
    return `https://supabase.com/dashboard/project/${ref}/auth/templates`;
  }
  return 'https://supabase.com/dashboard';
}

/**
 * Get the Supabase Dashboard URL for the SMTP / Auth settings page.
 * Dashboard > Project Settings > Auth
 */
export function getAuthSettingsUrl(): string {
  const ref = getProjectRef();
  if (ref) {
    return `https://supabase.com/dashboard/project/${ref}/settings/auth`;
  }
  return 'https://supabase.com/dashboard';
}

/**
 * Get the Supabase Dashboard URL for the Edge Function Secrets page.
 * Dashboard > Project Settings > Edge Functions
 */
export function getEdgeFunctionSecretsUrl(): string {
  const ref = getProjectRef();
  if (ref) {
    return `https://supabase.com/dashboard/project/${ref}/settings/functions`;
  }
  return 'https://supabase.com/dashboard';
}

/**
 * Get the Supabase Dashboard URL for the Edge Functions list page.
 * Dashboard > Edge Functions
 */
export function getEdgeFunctionsUrl(): string {
  const ref = getProjectRef();
  if (ref) {
    return `https://supabase.com/dashboard/project/${ref}/functions`;
  }
  return 'https://supabase.com/dashboard';
}

/**
 * Get the Supabase Dashboard URL for the Database Replication settings page.
 * Dashboard > Database > Replication
 * This is where you enable Realtime for specific tables.
 */
export function getReplicationSettingsUrl(): string {
  const ref = getProjectRef();
  if (ref) {
    return `https://supabase.com/dashboard/project/${ref}/database/replication`;
  }
  return 'https://supabase.com/dashboard';
}





// ============================================================================
// STARTUP LOG — deferred connection test to avoid racing with auth init
// ============================================================================
if (isSupabaseConfigured) {
  const source = runtimeUrl ? 'Runtime (localStorage)' : '.env';
  console.info(
    `%c[PitchCI] Supabase connecté — Source: ${source}`,
    'color: #22c55e; font-weight: bold; font-size: 14px;'
  );

  // IMPORTANT: Defer the connection test by 3 seconds to let auth initialization
  // (getSession + onAuthStateChange) complete first. This prevents navigator lock
  // contention that causes "signal is aborted without reason" AbortErrors.
  setTimeout(() => {
    testConnection().then(result => {
      if (result.success) {
        if (result.tablesExist === false) {
          console.warn(
            '%c[PitchCI] Connexion OK mais tables manquantes — Exécutez le script supabase-setup.sql dans le SQL Editor de Supabase.\n' +
            'Allez sur /setup?tab=database pour plus de détails.',
            'color: #f59e0b; font-weight: bold;'
          );
        } else {
          console.info('%c[PitchCI] Connexion vérifiée', 'color: #22c55e; font-weight: bold;');
        }
      } else {
        console.error('%c[PitchCI] Échec connexion:', 'color: #ef4444; font-weight: bold;', result.error);
      }
    }).catch(() => {
      // Silently ignore — connection test is informational only
    });
  }, 3000);

} else {
  console.warn(
    '%c[PitchCI] Supabase NON CONFIGURÉ — L\'application fonctionne en mode démo.\n' +
    'Pour connecter votre base de données :\n' +
    '1. Allez sur /setup et entrez vos clés Supabase\n' +
    '2. Ou copiez .env.example en .env et ajoutez vos clés\n' +
    '3. Redémarrez le serveur (npm run dev)',
    'color: #f59e0b; font-weight: bold; font-size: 12px;'
  );
}

// ============================================================================
// GLOBAL ABORT ERROR SUPPRESSION
// Supabase GoTrue's navigator lock mechanism can throw AbortErrors that
// propagate as unhandled promise rejections. These are harmless (the library
// retries internally) but pollute the console. Suppress them globally.
// ============================================================================
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    const error = event.reason;
    if (
      error?.name === 'AbortError' ||
      (error?.message && typeof error.message === 'string' && error.message.includes('signal is aborted'))
    ) {
      // Suppress the unhandled rejection — GoTrue handles this internally
      event.preventDefault();
      console.debug('[PitchCI] Suppressed harmless AbortError from auth lock:', error.message);
    }
  });
}
