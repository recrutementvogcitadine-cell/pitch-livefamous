/**
 * edgeFunctions.ts
 *
 * Centralized service for calling Supabase Edge Functions.
 * Handles: Agora token generation, live stream management, subscription management.
 *
 * All edge functions run with the service_role key server-side,
 * so they can bypass RLS when needed. The frontend sends the user's
 * JWT automatically via supabase.functions.invoke().
 */

import { supabase, isSupabaseConfigured } from './supabase';

// ============================================================================
// Edge Function Names — configurable via env vars
// ============================================================================
const EDGE_FN = {
  AGORA_TOKEN: import.meta.env.VITE_EDGE_FN_AGORA_TOKEN || 'generate-agora-token',
  MANAGE_LIVE: import.meta.env.VITE_EDGE_FN_MANAGE_LIVE || 'manage-live',
  PROCESS_PAYMENT: import.meta.env.VITE_EDGE_FN_PROCESS_PAYMENT || 'process-payment',
  MANAGE_SUBSCRIPTION: import.meta.env.VITE_EDGE_FN_MANAGE_SUBSCRIPTION || 'manage-subscription',
};

// ============================================================================
// Error Handling Helpers
// ============================================================================

interface EdgeFunctionResult<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  code?: string;
}

function extractErrorMessage(err: any, fallback: string): string {
  if (!err) return fallback;
  if (typeof err === 'string') return err;
  if (typeof err.message === 'string' && err.message.trim()) return err.message;
  if (typeof err.error === 'string' && err.error.trim()) return err.error;
  if (typeof err.msg === 'string' && err.msg.trim()) return err.msg;
  if (typeof err.error_description === 'string') return err.error_description;
  return fallback;
}

function translateEdgeFunctionError(msg: string, functionName: string): string {
  const lower = msg.toLowerCase();

  // Network / proxy errors
  if (lower.includes('functionsrelay') || lower.includes('functionshttp') || lower.includes('upstream') || lower.includes('bad gateway') || lower.includes('502') || lower.includes('503')) {
    return `La fonction "${functionName}" n'est pas disponible. Vérifiez qu'elle est déployée sur Supabase.`;
  }

  // JSON parse errors
  if (lower.includes('unexpected token') || lower.includes('is not valid json') || lower.includes('json')) {
    return `Erreur de communication avec la fonction "${functionName}". Réponse invalide du serveur.`;
  }

  // Auth errors
  if (lower.includes('jwt') || lower.includes('token') || lower.includes('unauthorized') || lower.includes('401')) {
    return 'Votre session a expiré. Veuillez vous reconnecter.';
  }

  // RLS / permission errors
  if (lower.includes('permission denied') || lower.includes('rls') || lower.includes('row-level security') || lower.includes('403')) {
    return 'Vous n\'avez pas les permissions nécessaires pour cette opération.';
  }

  // Not found
  if (lower.includes('not found') || lower.includes('404')) {
    return `La fonction "${functionName}" est introuvable. Vérifiez qu'elle est déployée.`;
  }

  // Timeout
  if (lower.includes('timeout') || lower.includes('aborted') || lower.includes('signal')) {
    return 'Le serveur met trop de temps à répondre. Veuillez réessayer.';
  }

  return msg || `Erreur lors de l'appel à "${functionName}"`;
}

/**
 * Generic edge function caller with standardized error handling.
 */
async function callEdgeFunction<T = any>(
  functionName: string,
  body: Record<string, any>,
  options?: { timeout?: number }
): Promise<EdgeFunctionResult<T>> {
  if (!isSupabaseConfigured) {
    return {
      success: false,
      error: 'Supabase n\'est pas configuré. Allez dans /setup pour connecter votre projet.',
      code: 'NOT_CONFIGURED',
    };
  }

  try {
    const { data, error } = await supabase.functions.invoke(functionName, {
      body,
    });

    if (error) {
      const msg = extractErrorMessage(error, `Erreur de la fonction ${functionName}`);
      return {
        success: false,
        error: translateEdgeFunctionError(msg, functionName),
        code: (error as any)?.code || 'EDGE_FUNCTION_ERROR',
      };
    }

    if (!data) {
      return {
        success: false,
        error: `Aucune réponse de la fonction "${functionName}".`,
        code: 'NO_RESPONSE',
      };
    }

    // Handle edge function returning its own error
    if (data.error) {
      const msg = extractErrorMessage(data.error, '');
      return {
        success: false,
        error: translateEdgeFunctionError(msg || data.error, functionName),
        code: data.code || 'FUNCTION_ERROR',
        data: data as T, // Include full response so callers can read extra fields like agora_warning
      };
    }

    return { success: true, data: data as T };
  } catch (err: any) {
    const msg = extractErrorMessage(err, `Erreur lors de l'appel à "${functionName}"`);
    return {
      success: false,
      error: translateEdgeFunctionError(msg, functionName),
      code: 'EXCEPTION',
    };
  }
}


// ============================================================================
// AGORA TOKEN — Génération de token pour les lives
// ============================================================================

export interface AgoraTokenRequest {
  channel_name: string;
  uid?: number;
  role?: 'publisher' | 'subscriber';
  expiry_seconds?: number;
}

export interface AgoraTokenResponse {
  token: string;
  channel: string;
  uid: number;
  app_id: string;
  expiry: number;
}

export const agoraService = {
  /**
   * Generate an Agora RTC token for joining a live stream channel.
   * The edge function validates the user's JWT and checks permissions.
   */
  async generateToken(params: AgoraTokenRequest): Promise<EdgeFunctionResult<AgoraTokenResponse>> {
    return callEdgeFunction<AgoraTokenResponse>(EDGE_FN.AGORA_TOKEN, {
      channel_name: params.channel_name,
      uid: params.uid || 0,
      role: params.role || 'subscriber',
      expiry_seconds: params.expiry_seconds || 3600,
    });
  },

  /**
   * Generate a publisher token (for the stream creator).
   */
  async generatePublisherToken(channelName: string): Promise<EdgeFunctionResult<AgoraTokenResponse>> {
    return this.generateToken({
      channel_name: channelName,
      role: 'publisher',
      expiry_seconds: 7200, // 2 hours
    });
  },

  /**
   * Generate a subscriber token (for viewers).
   */
  async generateSubscriberToken(channelName: string): Promise<EdgeFunctionResult<AgoraTokenResponse>> {
    return this.generateToken({
      channel_name: channelName,
      role: 'subscriber',
    });
  },
};


// ============================================================================
// LIVE MANAGEMENT — Gestion des lives via Edge Function
// ============================================================================

export interface StartLiveRequest {
  title: string;
  is_audio_only?: boolean;
  recording_enabled?: boolean;
}

export interface StartLiveResponse {
  stream_id: string;
  channel_name: string;
  agora_token: string;
  agora_app_id: string;
  uid: number;
  agora_configured?: boolean;
  agora_warning?: string;
}

export interface EndLiveRequest {
  stream_id: string;
}

export interface EndLiveResponse {
  stream_id: string;
  duration_seconds: number;
  peak_viewers: number;
  recording_url?: string;
}

export interface JoinLiveResponse {
  token: string;
  channel: string;
  uid: number;
  app_id: string;
  expiry: number;
  role: string;
  stream?: any;
}

export interface AgoraStatusResponse {
  agora_configured: boolean;
  agora_missing?: string;
  streaming_available: boolean;
  message: string;
  app_id?: string;
}

export const liveManagementService = {
  /**
   * Start a live stream via edge function.
   * Creates the stream record, generates Agora credentials, and returns everything needed.
   */
  async startLive(params: StartLiveRequest): Promise<EdgeFunctionResult<StartLiveResponse>> {
    return callEdgeFunction<StartLiveResponse>(EDGE_FN.MANAGE_LIVE, {
      action: 'start',
      title: params.title,
      is_audio_only: params.is_audio_only || false,
      recording_enabled: params.recording_enabled ?? true,
    });
  },

  /**
   * End a live stream via edge function.
   * Updates the stream record, calculates duration, and triggers recording upload if enabled.
   */
  async endLive(params: EndLiveRequest): Promise<EdgeFunctionResult<EndLiveResponse>> {
    return callEdgeFunction<EndLiveResponse>(EDGE_FN.MANAGE_LIVE, {
      action: 'end',
      stream_id: params.stream_id,
    });
  },

  /**
   * Join a live stream as a viewer via edge function.
   * Generates a subscriber token and increments viewer count.
   */
  async joinLive(params: { stream_id?: string; channel_name?: string }): Promise<EdgeFunctionResult<JoinLiveResponse>> {
    return callEdgeFunction<JoinLiveResponse>(EDGE_FN.MANAGE_LIVE, {
      action: 'join',
      stream_id: params.stream_id,
      channel_name: params.channel_name,
    });
  },

  /**
   * Leave a live stream (decrement viewer count).
   */
  async leaveLive(streamId: string): Promise<EdgeFunctionResult> {
    return callEdgeFunction(EDGE_FN.MANAGE_LIVE, {
      action: 'leave',
      stream_id: streamId,
    });
  },

  /**
   * Refresh an Agora token for an active channel.
   */
  async refreshToken(channelName: string, role: 'publisher' | 'subscriber' = 'subscriber'): Promise<EdgeFunctionResult<AgoraTokenResponse>> {
    return callEdgeFunction<AgoraTokenResponse>(EDGE_FN.MANAGE_LIVE, {
      action: 'refresh_token',
      channel_name: channelName,
      role,
    });
  },

  /**
   * Update stream metadata (title, viewer count, etc.)
   */
  async updateStream(streamId: string, updates: Record<string, any>): Promise<EdgeFunctionResult> {
    return callEdgeFunction(EDGE_FN.MANAGE_LIVE, {
      action: 'update',
      stream_id: streamId,
      ...updates,
    });
  },

  /**
   * Get stream info via edge function (bypasses RLS for public display).
   */
  async getStreamInfo(streamId: string): Promise<EdgeFunctionResult> {
    return callEdgeFunction(EDGE_FN.MANAGE_LIVE, {
      action: 'get_info',
      stream_id: streamId,
    });
  },

  /**
   * Check if Agora streaming service is configured and available.
   * No auth required — can be called before login.
   */
  async checkAgoraStatus(): Promise<EdgeFunctionResult<AgoraStatusResponse>> {
    return callEdgeFunction<AgoraStatusResponse>(EDGE_FN.MANAGE_LIVE, {
      action: 'agora_status',
    });
  },
};



// ============================================================================
// SUBSCRIPTION MANAGEMENT — Gestion des abonnements via Edge Function
// ============================================================================

export interface CreateSubscriptionRequest {
  plan_id: string;
  billing_cycle: 'monthly' | 'yearly';
}

export interface SubscriptionResponse {
  subscription_id: string;
  status: string;
  plan_name: string;
  expires_at: string;
}

export const subscriptionManagementService = {
  /**
   * Create or update a subscription via edge function.
   * The edge function handles payment verification and activation.
   */
  async createSubscription(params: CreateSubscriptionRequest): Promise<EdgeFunctionResult<SubscriptionResponse>> {
    return callEdgeFunction<SubscriptionResponse>(EDGE_FN.MANAGE_SUBSCRIPTION, {
      action: 'create',
      plan_id: params.plan_id,
      billing_cycle: params.billing_cycle,
    });
  },

  /**
   * Cancel a subscription via edge function.
   */
  async cancelSubscription(subscriptionId: string): Promise<EdgeFunctionResult> {
    return callEdgeFunction(EDGE_FN.MANAGE_SUBSCRIPTION, {
      action: 'cancel',
      subscription_id: subscriptionId,
    });
  },

  /**
   * Check subscription status via edge function.
   */
  async checkStatus(subscriptionId: string): Promise<EdgeFunctionResult<SubscriptionResponse>> {
    return callEdgeFunction<SubscriptionResponse>(EDGE_FN.MANAGE_SUBSCRIPTION, {
      action: 'check_status',
      subscription_id: subscriptionId,
    });
  },

  /**
   * Get available plans via edge function (bypasses RLS).
   */
  async getPlans(): Promise<EdgeFunctionResult<any[]>> {
    return callEdgeFunction(EDGE_FN.MANAGE_SUBSCRIPTION, {
      action: 'get_plans',
    });
  },
};

// ============================================================================
// HEALTH CHECK — Verify edge functions are deployed and accessible
// ============================================================================

export async function checkEdgeFunctionHealth(functionName?: string): Promise<{
  available: boolean;
  functions: Record<string, { available: boolean; error?: string }>;
}> {
  const functionsToCheck = functionName
    ? { [functionName]: functionName }
    : EDGE_FN;

  const results: Record<string, { available: boolean; error?: string }> = {};
  let anyAvailable = false;

  const checks = Object.entries(functionsToCheck).map(async ([key, name]) => {
    try {
      const { error } = await supabase.functions.invoke(name, {
        body: { action: 'health_check' },
      });

      if (error) {
        const msg = extractErrorMessage(error, '');
        const lower = msg.toLowerCase();
        // If we get a "bad action" or "invalid action" error, the function IS deployed
        if (lower.includes('invalid') || lower.includes('unknown') || lower.includes('action')) {
          results[key] = { available: true };
          anyAvailable = true;
        } else {
          results[key] = { available: false, error: msg };
        }
      } else {
        results[key] = { available: true };
        anyAvailable = true;
      }
    } catch (err: any) {
      results[key] = { available: false, error: extractErrorMessage(err, 'Unreachable') };
    }
  });

  await Promise.allSettled(checks);

  return { available: anyAvailable, functions: results };
}
// Export edge function names for diagnostics
export function getEdgeFunctionNames(): Record<string, string> {
  return { ...EDGE_FN };
}

// ============================================================================
// AGORA APP ID — Public helper (re-exported from agoraClient for convenience)
// ============================================================================

/**
 * Get the Agora App ID from env. This is PUBLIC and safe for frontend use.
 * The App Certificate is NEVER exposed — it stays in Edge Function secrets.
 */
export function getAgoraAppId(): string {
  return import.meta.env.VITE_AGORA_APP_ID || '';
}
