import { supabase } from './supabase';
import {
  isRlsDenied,
  logRlsError,
  getRlsErrorMessage,
} from './rlsErrorHandler';

export type PaymentProvider = 'orange_money' | 'mtn_money' | 'wave';

export interface PaymentInfo {
  id: string;
  transaction_id: string;
  amount: number;
  currency: string;
  provider: string;
  phone_number: string;
  status: string;
  status_message?: string;
  created_at?: string;
  completed_at?: string;
  message?: string;
}

export interface PaymentHistoryItem {
  id: string;
  creator_id: string;
  subscription_id: string;
  amount: number;
  currency: string;
  payment_method: string;
  provider: string;
  phone_number: string;
  transaction_id: string;
  external_reference: string | null;
  status: string;
  status_message: string;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
}

export const paymentProviders: Record<PaymentProvider, {
  name: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: string;
  description: string;
  countries: string[];
}> = {
  orange_money: {
    name: 'Orange Money',
    color: '#FF6600',
    bgColor: 'bg-orange-500/10',
    borderColor: 'border-orange-500/30',
    icon: 'orange',
    description: 'Payez avec votre compte Orange Money',
    countries: ['CI', 'SN', 'ML', 'BF', 'CM', 'GN']
  },
  mtn_money: {
    name: 'MTN Mobile Money',
    color: '#FFCC00',
    bgColor: 'bg-yellow-500/10',
    borderColor: 'border-yellow-500/30',
    icon: 'mtn',
    description: 'Payez avec MTN Mobile Money',
    countries: ['CI', 'CM', 'GH', 'BJ', 'CG']
  },
  wave: {
    name: 'Wave',
    color: '#1DC3E1',
    bgColor: 'bg-cyan-500/10',
    borderColor: 'border-cyan-500/30',
    icon: 'wave',
    description: 'Payez avec votre compte Wave',
    countries: ['SN', 'CI', 'ML', 'BF']
  }
};

// Helper: safely extract error message from any thrown value
function extractErrorMessage(err: any, fallback: string): string {
  if (!err) return fallback;
  if (typeof err === 'string') return err;
  if (typeof err.message === 'string') return err.message;
  if (typeof err.error === 'string') return err.error;
  if (typeof err.msg === 'string') return err.msg;
  return fallback;
}

// Helper: translate upstream/proxy errors
function translateServiceError(msg: string, fallback: string): string {
  const lower = msg.toLowerCase();
  if (lower.includes('upstream') || lower.includes('functionshttp') || lower.includes('functionsrelay') || lower.includes('bad gateway') || lower.includes('502') || lower.includes('503')) {
    return 'Le service de paiement n\'est pas disponible actuellement. Veuillez réessayer plus tard.';
  }
  if (lower.includes('unexpected token') || lower.includes('is not valid json')) {
    return 'Erreur de communication avec le serveur de paiement. Veuillez réessayer.';
  }
  // Check for RLS/permission errors from edge functions
  if (lower.includes('permission denied') || lower.includes('rls') || lower.includes('row-level security')) {
    return 'Vous n\'avez pas les permissions nécessaires pour effectuer cette opération.';
  }
  return msg || fallback;
}

export const paymentService = {
  async initiatePayment(
    planId: string,
    billingCycle: 'monthly' | 'yearly',
    provider: PaymentProvider,
    phoneNumber: string
  ): Promise<{ success: boolean; payment?: PaymentInfo; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('process-payment', {
        body: {
          action: 'initiate_payment',
          plan_id: planId,
          billing_cycle: billingCycle,
          provider,
          phone_number: phoneNumber
        }
      });

      if (error) throw error;
      if (!data) return { success: false, error: 'Aucune réponse du serveur de paiement.' };
      if (data.error) return { success: false, error: translateServiceError(extractErrorMessage(data.error, ''), 'Erreur lors de l\'initiation du paiement') };

      return { success: true, payment: data.payment };
    } catch (err: any) {
      return { success: false, error: translateServiceError(extractErrorMessage(err, ''), 'Erreur lors de l\'initiation du paiement') };
    }
  },

  async confirmPayment(
    paymentId: string
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('process-payment', {
        body: {
          action: 'confirm_payment',
          payment_id: paymentId
        }
      });

      if (error) throw error;
      if (!data) return { success: false, error: 'Aucune réponse du serveur.' };
      if (data.error) return { success: false, error: translateServiceError(extractErrorMessage(data.error, ''), 'Erreur lors de la confirmation du paiement') };

      return { success: true, message: data.message };
    } catch (err: any) {
      return { success: false, error: translateServiceError(extractErrorMessage(err, ''), 'Erreur lors de la confirmation du paiement') };
    }
  },

  async checkPaymentStatus(
    paymentId: string
  ): Promise<{ success: boolean; payment?: PaymentInfo; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('process-payment', {
        body: {
          action: 'check_status',
          payment_id: paymentId
        }
      });

      if (error) throw error;
      if (!data) return { success: false, error: 'Aucune réponse du serveur.' };
      if (data.error) return { success: false, error: translateServiceError(extractErrorMessage(data.error, ''), 'Erreur lors de la vérification du statut') };

      return { success: true, payment: data.payment };
    } catch (err: any) {
      return { success: false, error: translateServiceError(extractErrorMessage(err, ''), 'Erreur lors de la vérification du statut') };
    }
  },

  /**
   * Get payment history — RLS-restricted to owner only.
   * Uses edge function which runs with service role key.
   */
  async getPaymentHistory(): Promise<{ success: boolean; payments?: PaymentHistoryItem[]; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('process-payment', {
        body: {
          action: 'get_history'
        }
      });

      if (error) throw error;
      if (!data) return { success: true, payments: [] };
      if (data.error) return { success: false, error: translateServiceError(extractErrorMessage(data.error, ''), 'Erreur lors du chargement de l\'historique') };

      return { success: true, payments: data.payments || [] };
    } catch (err: any) {
      return { success: false, error: translateServiceError(extractErrorMessage(err, ''), 'Erreur lors du chargement de l\'historique') };
    }
  },

  formatAmount(amount: number, currency: string = 'XOF'): string {
    if (currency === 'XOF' || currency === 'XAF') {
      return new Intl.NumberFormat('fr-FR', {
        style: 'decimal',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(amount) + ' FCFA';
    }
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency
    }).format(amount);
  },

  getProviderInfo(provider: PaymentProvider) {
    return paymentProviders[provider] || null;
  },

  validatePhoneNumber(phone: string): { valid: boolean; formatted: string; error?: string } {
    const cleaned = phone.replace(/[\s\-\(\)]/g, '');
    
    if (!cleaned) {
      return { valid: false, formatted: '', error: 'Numéro de téléphone requis' };
    }

    const withoutPlus = cleaned.replace(/^\+/, '');
    
    if (withoutPlus.length < 8) {
      return { valid: false, formatted: cleaned, error: 'Numéro trop court (minimum 8 chiffres)' };
    }

    if (withoutPlus.length > 15) {
      return { valid: false, formatted: cleaned, error: 'Numéro trop long (maximum 15 chiffres)' };
    }

    if (!/^\+?\d+$/.test(cleaned)) {
      return { valid: false, formatted: cleaned, error: 'Le numéro ne doit contenir que des chiffres' };
    }

    return { valid: true, formatted: cleaned };
  },

  getStatusLabel(status: string): string {
    const labels: Record<string, string> = {
      pending: 'En attente',
      processing: 'En cours',
      completed: 'Confirmé',
      failed: 'Échoué',
      cancelled: 'Annulé',
      refunded: 'Remboursé'
    };
    return labels[status] || status;
  },

  getStatusColor(status: string): string {
    const colors: Record<string, string> = {
      pending: 'text-yellow-400',
      processing: 'text-blue-400',
      completed: 'text-green-400',
      failed: 'text-red-400',
      cancelled: 'text-gray-400',
      refunded: 'text-purple-400'
    };
    return colors[status] || 'text-gray-400';
  },

  getStatusBgColor(status: string): string {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-500/10 border-yellow-500/30',
      processing: 'bg-blue-500/10 border-blue-500/30',
      completed: 'bg-green-500/10 border-green-500/30',
      failed: 'bg-red-500/10 border-red-500/30',
      cancelled: 'bg-gray-500/10 border-gray-500/30',
      refunded: 'bg-purple-500/10 border-purple-500/30'
    };
    return colors[status] || 'bg-gray-500/10 border-gray-500/30';
  }
};
