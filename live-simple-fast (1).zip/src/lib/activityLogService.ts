import { supabase } from './supabase';
import {
  isRlsDenied,
  isNonCriticalError,
  logRlsError,
} from './rlsErrorHandler';

export interface ActivityLog {
  id: string;
  actor_id: string;
  actor_name: string;
  actor_email: string | null;
  actor_role: string | null;
  action_type: string;
  action_description: string;
  target_type: string | null;
  target_id: string | null;
  target_label: string | null;
  metadata: Record<string, any>;
  ip_address: string | null;
  created_at: string;
}

export interface ActivityLogFilters {
  actionType?: string;
  actorId?: string;
  dateFrom?: string;
  dateTo?: string;
  search?: string;
}

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// Human-readable labels for action types
export const ACTION_TYPE_LABELS: Record<string, string> = {
  activate_subscription: 'Abonnement activé',
  deactivate_subscription: 'Abonnement désactivé',
  create_subscription: 'Abonnement créé',
  approve_verification: 'Vérification approuvée',
  reject_verification: 'Vérification rejetée',
  revoke_verification: 'Vérification révoquée',
  update_support: 'Support mis à jour',
  create_plan: 'Plan créé',
  update_plan: 'Plan modifié',
  delete_plan: 'Plan supprimé',
  add_team_member: 'Membre ajouté',
  remove_team_member: 'Membre retiré',
  update_role: 'Rôle modifié',
  end_stream: 'Live terminé',
  ban_user: 'Utilisateur banni',
  unban_user: 'Utilisateur débanni',
  delete_message: 'Message supprimé',
};

// Target type labels
export const TARGET_TYPE_LABELS: Record<string, string> = {
  subscription: 'Abonnement',
  verification: 'Vérification',
  support_request: 'Demande support',
  plan: 'Plan',
  team_member: "Membre d'équipe",
  stream: 'Live',
  user: 'Utilisateur',
  message: 'Message',
};

// Color mapping for action types (for badges)
export const ACTION_TYPE_COLORS: Record<string, string> = {
  activate_subscription: 'bg-green-100 text-green-700',
  deactivate_subscription: 'bg-red-100 text-red-700',
  create_subscription: 'bg-blue-100 text-blue-700',
  approve_verification: 'bg-emerald-100 text-emerald-700',
  reject_verification: 'bg-orange-100 text-orange-700',
  revoke_verification: 'bg-red-100 text-red-700',
  update_support: 'bg-blue-100 text-blue-700',
  create_plan: 'bg-purple-100 text-purple-700',
  update_plan: 'bg-purple-100 text-purple-700',
  delete_plan: 'bg-red-100 text-red-700',
  add_team_member: 'bg-indigo-100 text-indigo-700',
  remove_team_member: 'bg-red-100 text-red-700',
  update_role: 'bg-amber-100 text-amber-700',
  end_stream: 'bg-gray-100 text-gray-700',
  ban_user: 'bg-red-100 text-red-700',
  unban_user: 'bg-green-100 text-green-700',
  delete_message: 'bg-gray-100 text-gray-700',
};

// Icon hints for action types
export const ACTION_TYPE_ICONS: Record<string, string> = {
  activate_subscription: 'check-circle',
  deactivate_subscription: 'x-circle',
  create_subscription: 'credit-card',
  approve_verification: 'badge-check',
  reject_verification: 'x-circle',
  revoke_verification: 'shield-off',
  update_support: 'message-square',
  create_plan: 'plus',
  update_plan: 'edit',
  delete_plan: 'trash-2',
  add_team_member: 'user-plus',
  remove_team_member: 'user-minus',
  update_role: 'user-cog',
  end_stream: 'radio',
  ban_user: 'ban',
  unban_user: 'user-check',
  delete_message: 'message-square',
};

export const activityLogService = {
  /**
   * Log an admin activity — RLS-restricted to admin-only insert.
   */
  async log(params: {
    actionType: string;
    actionDescription: string;
    targetType?: string;
    targetId?: string;
    targetLabel?: string;
    metadata?: Record<string, any>;
  }): Promise<void> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Try to get team member info for richer logging
      let actorName = user.email || 'Inconnu';
      let actorRole: string | null = null;
      let actorEmail = user.email || null;

      try {
        // Use wildcard select to avoid column-not-found errors on incomplete schemas
        const { data: member, error: memberErr } = await supabase
          .from('team_members')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();


        if (memberErr && isRlsDenied(memberErr)) {
          logRlsError('activityLogService', 'log/team_members', memberErr);
        } else if (member) {
          actorName = member.display_name || actorName;
          actorRole = member.role;
          actorEmail = member.email || actorEmail;
        }
      } catch {
        // Silent - use fallback values
      }

      const { error } = await supabase.from('admin_activity_logs').insert({
        actor_id: user.id,
        actor_name: actorName,
        actor_email: actorEmail,
        actor_role: actorRole,
        action_type: params.actionType,
        action_description: params.actionDescription,
        target_type: params.targetType || null,
        target_id: params.targetId || null,
        target_label: params.targetLabel || null,
        metadata: params.metadata || {},
      });

      if (error && isRlsDenied(error)) {
        logRlsError('activityLogService', 'log/insert', error);
      }
    } catch {
      // Silent fail for logging - never block the main action
    }
  },

  /**
   * Fetch activity logs — RLS-restricted to admin-only read.
   */
  async getLogs(
    filters: ActivityLogFilters = {},
    page: number = 1,
    pageSize: number = 25
  ): Promise<PaginatedResult<ActivityLog>> {
    const emptyResult: PaginatedResult<ActivityLog> = {
      data: [],
      total: 0,
      page: 1,
      pageSize,
      totalPages: 0,
    };

    try {
      // Build count query
      let countQuery = supabase
        .from('admin_activity_logs')
        .select('id', { count: 'exact', head: true });

      // Build data query
      let dataQuery = supabase
        .from('admin_activity_logs')
        .select('*')
        .order('created_at', { ascending: false });

      // Apply filters to both queries
      if (filters.actionType && filters.actionType !== 'all') {
        countQuery = countQuery.eq('action_type', filters.actionType);
        dataQuery = dataQuery.eq('action_type', filters.actionType);
      }

      if (filters.actorId && filters.actorId !== 'all') {
        countQuery = countQuery.eq('actor_id', filters.actorId);
        dataQuery = dataQuery.eq('actor_id', filters.actorId);
      }

      if (filters.dateFrom) {
        const fromDate = new Date(filters.dateFrom);
        fromDate.setHours(0, 0, 0, 0);
        countQuery = countQuery.gte('created_at', fromDate.toISOString());
        dataQuery = dataQuery.gte('created_at', fromDate.toISOString());
      }

      if (filters.dateTo) {
        const toDate = new Date(filters.dateTo);
        toDate.setHours(23, 59, 59, 999);
        countQuery = countQuery.lte('created_at', toDate.toISOString());
        dataQuery = dataQuery.lte('created_at', toDate.toISOString());
      }

      if (filters.search) {
        const searchTerm = `%${filters.search}%`;
        countQuery = countQuery.or(`action_description.ilike.${searchTerm},actor_name.ilike.${searchTerm},target_label.ilike.${searchTerm}`);
        dataQuery = dataQuery.or(`action_description.ilike.${searchTerm},actor_name.ilike.${searchTerm},target_label.ilike.${searchTerm}`);
      }

      // Pagination
      const from = (page - 1) * pageSize;
      const to = from + pageSize - 1;
      dataQuery = dataQuery.range(from, to);

      // Execute both queries
      const [countResult, dataResult] = await Promise.all([
        countQuery,
        dataQuery,
      ]);

      // Handle RLS denied on either query
      if (countResult.error && isRlsDenied(countResult.error)) {
        logRlsError('activityLogService', 'getLogs/count', countResult.error);
        return emptyResult;
      }
      if (dataResult.error && isRlsDenied(dataResult.error)) {
        logRlsError('activityLogService', 'getLogs/data', dataResult.error);
        return emptyResult;
      }

      const total = countResult.count || 0;
      const data = (dataResult.data || []) as ActivityLog[];

      return {
        data,
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize),
      };
    } catch {
      return emptyResult;
    }
  },

  /**
   * Get distinct actors — RLS-restricted to admin-only read.
   */
  async getDistinctActors(): Promise<Array<{ actor_id: string; actor_name: string; actor_role: string | null }>> {
    try {
      const { data, error } = await supabase
        .from('admin_activity_logs')
        .select('actor_id, actor_name, actor_role')
        .order('actor_name');

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('activityLogService', 'getDistinctActors', error);
          return [];
        }
        throw error;
      }

      // Deduplicate by actor_id
      const seen = new Map<string, { actor_id: string; actor_name: string; actor_role: string | null }>();
      for (const row of data || []) {
        if (!seen.has(row.actor_id)) {
          seen.set(row.actor_id, {
            actor_id: row.actor_id,
            actor_name: row.actor_name,
            actor_role: row.actor_role,
          });
        }
      }

      return Array.from(seen.values());
    } catch {
      return [];
    }
  },

  /**
   * Get distinct action types — RLS-restricted to admin-only read.
   */
  async getDistinctActionTypes(): Promise<string[]> {
    try {
      const { data, error } = await supabase
        .from('admin_activity_logs')
        .select('action_type')
        .order('action_type');

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('activityLogService', 'getDistinctActionTypes', error);
          return [];
        }
        throw error;
      }

      const types = new Set<string>();
      for (const row of data || []) {
        types.add(row.action_type);
      }

      return Array.from(types);
    } catch {
      return [];
    }
  },

  /**
   * Get activity summary stats — RLS-restricted to admin-only read.
   */
  async getStats(): Promise<{
    totalLogs: number;
    todayLogs: number;
    weekLogs: number;
    topActors: Array<{ name: string; count: number }>;
    topActions: Array<{ type: string; count: number }>;
  }> {
    const emptyStats = {
      totalLogs: 0,
      todayLogs: 0,
      weekLogs: 0,
      topActors: [] as Array<{ name: string; count: number }>,
      topActions: [] as Array<{ type: string; count: number }>,
    };

    try {
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
      const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();

      const [totalResult, todayResult, weekResult, allLogsResult] = await Promise.all([
        supabase.from('admin_activity_logs').select('id', { count: 'exact', head: true }),
        supabase.from('admin_activity_logs').select('id', { count: 'exact', head: true }).gte('created_at', todayStart),
        supabase.from('admin_activity_logs').select('id', { count: 'exact', head: true }).gte('created_at', weekStart),
        supabase.from('admin_activity_logs').select('actor_name, action_type').limit(1000),
      ]);

      // Check for RLS denied on any query
      for (const result of [totalResult, todayResult, weekResult, allLogsResult]) {
        if (result.error && isRlsDenied(result.error)) {
          logRlsError('activityLogService', 'getStats', result.error);
          return emptyStats;
        }
      }

      // Calculate top actors and actions from recent logs
      const actorCounts = new Map<string, number>();
      const actionCounts = new Map<string, number>();

      for (const log of allLogsResult.data || []) {
        actorCounts.set(log.actor_name, (actorCounts.get(log.actor_name) || 0) + 1);
        actionCounts.set(log.action_type, (actionCounts.get(log.action_type) || 0) + 1);
      }

      const topActors = Array.from(actorCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([name, count]) => ({ name, count }));

      const topActions = Array.from(actionCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([type, count]) => ({ type, count }));

      return {
        totalLogs: totalResult.count || 0,
        todayLogs: todayResult.count || 0,
        weekLogs: weekResult.count || 0,
        topActors,
        topActions,
      };
    } catch {
      return emptyStats;
    }
  },
};
