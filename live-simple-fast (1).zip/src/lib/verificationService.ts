import { supabase } from './supabase';
import {
  isRlsDenied,
  isNonCriticalError,
  logRlsError,
  getRlsErrorMessage,
} from './rlsErrorHandler';

export interface VerificationRequest {
  id: string;
  creator_id: string;
  status: 'pending' | 'approved' | 'rejected';
  full_legal_name: string;
  date_of_birth: string;
  country: string;
  document_type: 'passport' | 'national_id' | 'drivers_license';
  document_front_url: string;
  document_back_url?: string;
  selfie_url: string;
  additional_notes?: string;
  rejection_reason?: string;
  submitted_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
  created_at: string;
  updated_at: string;
  creator_profiles?: {
    id: string;
    display_name: string;
    avatar_url: string;
    user_id: string;
    is_verified: boolean;
  };
}

export interface VerificationSubmission {
  full_legal_name: string;
  date_of_birth: string;
  country: string;
  document_type: 'passport' | 'national_id' | 'drivers_license';
  document_front: File;
  document_back?: File;
  selfie: File;
  additional_notes?: string;
}

// Upload a verification document to storage
export async function uploadVerificationDocument(
  userId: string,
  file: File,
  documentType: string
): Promise<string | null> {
  const fileExt = file.name.split('.').pop();
  const fileName = `${userId}/${documentType}_${Date.now()}.${fileExt}`;

  const { error } = await supabase.storage
    .from('verification-documents')
    .upload(fileName, file, {
      cacheControl: '3600',
      upsert: false
    });

  if (error) {
    console.error('Error uploading document:', error);
    return null;
  }

  const { data: signedData } = await supabase.storage
    .from('verification-documents')
    .createSignedUrl(fileName, 31536000);

  return signedData?.signedUrl || null;
}

/**
 * Submit a verification request — RLS-restricted to owner-only insert.
 */
export async function submitVerificationRequest(
  creatorId: string,
  userId: string,
  submission: VerificationSubmission
): Promise<{ success: boolean; error?: string }> {
  try {
    // Check if there's already a pending request
    const { data: existingRequest, error: checkErr } = await supabase
      .from('verification_requests')
      .select('id, status')
      .eq('creator_id', creatorId)
      .eq('status', 'pending')
      .single();

    if (checkErr && isRlsDenied(checkErr)) {
      logRlsError('verificationService', 'submitVerificationRequest/check', checkErr);
      return { success: false, error: getRlsErrorMessage(checkErr, 'verification') };
    }

    if (existingRequest) {
      return { success: false, error: 'You already have a pending verification request' };
    }

    // Upload documents
    const documentFrontUrl = await uploadVerificationDocument(
      userId,
      submission.document_front,
      'document_front'
    );

    if (!documentFrontUrl) {
      return { success: false, error: 'Failed to upload front of document' };
    }

    let documentBackUrl: string | undefined;
    if (submission.document_back) {
      documentBackUrl = await uploadVerificationDocument(
        userId,
        submission.document_back,
        'document_back'
      ) || undefined;
    }

    const selfieUrl = await uploadVerificationDocument(
      userId,
      submission.selfie,
      'selfie'
    );

    if (!selfieUrl) {
      return { success: false, error: 'Failed to upload selfie' };
    }

    // Create verification request
    const { error } = await supabase
      .from('verification_requests')
      .insert({
        creator_id: creatorId,
        full_legal_name: submission.full_legal_name,
        date_of_birth: submission.date_of_birth,
        country: submission.country,
        document_type: submission.document_type,
        document_front_url: documentFrontUrl,
        document_back_url: documentBackUrl,
        selfie_url: selfieUrl,
        additional_notes: submission.additional_notes,
        status: 'pending'
      });

    if (error) {
      if (isRlsDenied(error)) {
        logRlsError('verificationService', 'submitVerificationRequest/insert', error);
        return { success: false, error: getRlsErrorMessage(error, 'verification') };
      }
      console.error('Error creating verification request:', error);
      return { success: false, error: 'Failed to submit verification request' };
    }

    return { success: true };
  } catch (error) {
    console.error('Error in submitVerificationRequest:', error);
    return { success: false, error: 'An unexpected error occurred' };
  }
}

/**
 * Get verification request for a creator — RLS-restricted to owner-only read.
 */
export async function getCreatorVerificationRequest(
  creatorId: string
): Promise<VerificationRequest | null> {
  const { data, error } = await supabase
    .from('verification_requests')
    .select('*')
    .eq('creator_id', creatorId)
    .order('created_at', { ascending: false })
    .limit(1)
    .single();

  if (error) {
    if (isRlsDenied(error)) {
      logRlsError('verificationService', 'getCreatorVerificationRequest', error, { creatorId });
      return null;
    }
    if (error.code !== 'PGRST116') { // Not "no rows" error
      console.error('Error fetching verification request:', error);
    }
    return null;
  }

  return data;
}

/**
 * Get all verification requests (admin) — RLS-restricted to admin-only read.
 * Uses verification_requests_admin view with fallback.
 */
export async function getAllVerificationRequests(
  status?: 'pending' | 'approved' | 'rejected'
): Promise<VerificationRequest[]> {
  let query = supabase
    .from('verification_requests_admin')
    .select('*')
    .order('submitted_at', { ascending: false });

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;

  if (error) {
    if (isRlsDenied(error)) {
      logRlsError('verificationService', 'getAllVerificationRequests/admin_view', error);
      return [];
    }

    // Fallback to original table with nested join if the admin view doesn't exist
    console.warn('[verificationService] verification_requests_admin view failed, falling back to base table:', error.message);
    let fallbackQuery = supabase
      .from('verification_requests')
      .select(`
        *,
        creator_profiles (
          id,
          display_name,
          avatar_url,
          user_id,
          is_verified
        )
      `)
      .order('submitted_at', { ascending: false });

    if (status) {
      fallbackQuery = fallbackQuery.eq('status', status);
    }

    const { data: fallbackData, error: fallbackError } = await fallbackQuery;
    if (fallbackError) {
      if (isRlsDenied(fallbackError)) {
        logRlsError('verificationService', 'getAllVerificationRequests/fallback', fallbackError);
        return [];
      }
      console.error('Error fetching verification requests (fallback):', fallbackError);
      return [];
    }
    return fallbackData || [];
  }

  // Map flat fields from the admin view back to the expected nested structure
  const mapped = (data || []).map((row: any) => {
    if (row.creator_profiles) return row;

    const {
      display_name,
      avatar_url,
      user_id,
      is_verified,
      creator_profile_id,
      ...rest
    } = row;

    return {
      ...rest,
      creator_profiles: {
        id: creator_profile_id || rest.creator_id,
        display_name: display_name || null,
        avatar_url: avatar_url || null,
        user_id: user_id || null,
        is_verified: is_verified ?? false,
      },
    } as VerificationRequest;
  });

  return mapped;
}


/**
 * Approve verification request (admin) — RLS-restricted.
 */
export async function approveVerificationRequest(
  requestId: string,
  adminId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { data: request, error: fetchError } = await supabase
      .from('verification_requests')
      .select('creator_id')
      .eq('id', requestId)
      .single();

    if (fetchError) {
      if (isRlsDenied(fetchError)) {
        return { success: false, error: getRlsErrorMessage(fetchError, 'admin') };
      }
      return { success: false, error: 'Verification request not found' };
    }
    if (!request) {
      return { success: false, error: 'Verification request not found' };
    }

    const { error: updateError } = await supabase
      .from('verification_requests')
      .update({
        status: 'approved',
        reviewed_at: new Date().toISOString(),
        reviewed_by: adminId,
        updated_at: new Date().toISOString()
      })
      .eq('id', requestId);

    if (updateError) {
      if (isRlsDenied(updateError)) {
        return { success: false, error: getRlsErrorMessage(updateError, 'admin') };
      }
      return { success: false, error: 'Failed to update verification request' };
    }

    const { error: profileError } = await supabase
      .from('creator_profiles')
      .update({ is_verified: true })
      .eq('id', request.creator_id);

    if (profileError) {
      if (isRlsDenied(profileError)) {
        logRlsError('verificationService', 'approveVerificationRequest/profile', profileError);
      }
      console.error('Error updating creator profile:', profileError);
      return { success: false, error: 'Failed to update creator verification status' };
    }

    return { success: true };
  } catch (error) {
    console.error('Error in approveVerificationRequest:', error);
    return { success: false, error: 'An unexpected error occurred' };
  }
}

/**
 * Reject verification request (admin) — RLS-restricted.
 */
export async function rejectVerificationRequest(
  requestId: string,
  adminId: string,
  rejectionReason: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('verification_requests')
      .update({
        status: 'rejected',
        rejection_reason: rejectionReason,
        reviewed_at: new Date().toISOString(),
        reviewed_by: adminId,
        updated_at: new Date().toISOString()
      })
      .eq('id', requestId);

    if (error) {
      if (isRlsDenied(error)) {
        return { success: false, error: getRlsErrorMessage(error, 'admin') };
      }
      return { success: false, error: 'Failed to reject verification request' };
    }

    return { success: true };
  } catch (error) {
    console.error('Error in rejectVerificationRequest:', error);
    return { success: false, error: 'An unexpected error occurred' };
  }
}

/**
 * Revoke verification (admin) — RLS-restricted.
 */
export async function revokeVerification(
  creatorId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('creator_profiles')
      .update({ is_verified: false })
      .eq('id', creatorId);

    if (error) {
      if (isRlsDenied(error)) {
        return { success: false, error: getRlsErrorMessage(error, 'admin') };
      }
      return { success: false, error: 'Failed to revoke verification' };
    }

    return { success: true };
  } catch (error) {
    console.error('Error in revokeVerification:', error);
    return { success: false, error: 'An unexpected error occurred' };
  }
}

/**
 * Get verification statistics (admin) — RLS-restricted.
 */
export async function getVerificationStats(): Promise<{
  total: number;
  pending: number;
  approved: number;
  rejected: number;
}> {
  const emptyStats = { total: 0, pending: 0, approved: 0, rejected: 0 };

  const { data, error } = await supabase
    .from('verification_requests')
    .select('status');

  if (error) {
    if (isRlsDenied(error)) {
      logRlsError('verificationService', 'getVerificationStats', error);
      return emptyStats;
    }
    console.error('Error fetching verification stats:', error);
    return emptyStats;
  }

  const stats = {
    total: data?.length || 0,
    pending: data?.filter(r => r.status === 'pending').length || 0,
    approved: data?.filter(r => r.status === 'approved').length || 0,
    rejected: data?.filter(r => r.status === 'rejected').length || 0
  };

  return stats;
}
