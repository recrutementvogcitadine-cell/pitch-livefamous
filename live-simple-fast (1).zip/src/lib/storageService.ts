/**
 * storageService.ts
 *
 * Centralized Supabase Storage service for file uploads.
 * Handles: VOD bucket, avatars, recordings, verification documents.
 * Includes progress tracking, file validation, and signed URL generation.
 */

import { supabase, isSupabaseConfigured } from './supabase';

// ============================================================================
// Bucket Names — configurable via env vars
// ============================================================================
const BUCKETS = {
  VOD: import.meta.env.VITE_STORAGE_BUCKET_VOD || 'VOD',
  AVATARS: import.meta.env.VITE_STORAGE_BUCKET_AVATARS || 'avatars',
  RECORDINGS: import.meta.env.VITE_STORAGE_BUCKET_RECORDINGS || 'recordings',
  VERIFICATION: import.meta.env.VITE_STORAGE_BUCKET_VERIFICATION || 'verification-documents',
};

// ============================================================================
// Types
// ============================================================================

export interface UploadResult {
  success: boolean;
  url?: string;
  path?: string;
  size?: number;
  error?: string;
}

export interface UploadOptions {
  /** Override the file name (default: auto-generated) */
  fileName?: string;
  /** Content type override */
  contentType?: string;
  /** Whether to overwrite existing file */
  upsert?: boolean;
  /** Cache control header */
  cacheControl?: string;
  /** Progress callback (0-100) */
  onProgress?: (percent: number) => void;
}

// ============================================================================
// File Validation
// ============================================================================

const VIDEO_MIME_TYPES = new Set([
  'video/mp4',
  'video/webm',
  'video/ogg',
  'video/quicktime',
  'video/x-msvideo',
  'video/x-matroska',
]);

const IMAGE_MIME_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp',
  'image/svg+xml',
]);

const DOCUMENT_MIME_TYPES = new Set([
  ...IMAGE_MIME_TYPES,
  'application/pdf',
]);

// Max file sizes in bytes
const MAX_SIZES = {
  VOD: 2 * 1024 * 1024 * 1024,         // 2 GB
  AVATAR: 5 * 1024 * 1024,               // 5 MB
  RECORDING: 2 * 1024 * 1024 * 1024,     // 2 GB
  VERIFICATION: 10 * 1024 * 1024,         // 10 MB
};

function validateFile(
  file: File,
  allowedTypes: Set<string>,
  maxSize: number,
  context: string
): string | null {
  if (!file) return 'Aucun fichier sélectionné.';
  if (!allowedTypes.has(file.type)) {
    const allowed = Array.from(allowedTypes).join(', ');
    return `Type de fichier non supporté (${file.type}). Types acceptés : ${allowed}`;
  }
  if (file.size > maxSize) {
    const maxMB = Math.round(maxSize / (1024 * 1024));
    const fileMB = (file.size / (1024 * 1024)).toFixed(1);
    return `Fichier trop volumineux (${fileMB} MB). Taille maximale : ${maxMB} MB pour ${context}.`;
  }
  return null;
}

// ============================================================================
// Core Upload Function
// ============================================================================

async function uploadFile(
  bucket: string,
  path: string,
  file: File | Blob,
  options: UploadOptions = {}
): Promise<UploadResult> {
  if (!isSupabaseConfigured) {
    return { success: false, error: 'Supabase n\'est pas configuré.' };
  }

  try {
    // Simulate progress for UX (Supabase JS client doesn't support real progress)
    if (options.onProgress) {
      options.onProgress(10);
    }

    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(path, file, {
        contentType: options.contentType || (file instanceof File ? file.type : undefined),
        upsert: options.upsert ?? true,
        cacheControl: options.cacheControl || '3600',
      });

    if (options.onProgress) {
      options.onProgress(80);
    }

    if (error) {
      console.error(`[storageService] Upload error (${bucket}/${path}):`, error);

      // Handle specific storage errors
      const msg = (error.message || '').toLowerCase();
      if (msg.includes('bucket') && msg.includes('not found')) {
        return { success: false, error: `Le bucket "${bucket}" n'existe pas. Créez-le dans Supabase Dashboard > Storage.` };
      }
      if (msg.includes('payload too large') || msg.includes('too large') || msg.includes('413')) {
        return { success: false, error: 'Fichier trop volumineux pour le serveur. Réduisez la taille du fichier.' };
      }
      if (msg.includes('permission') || msg.includes('policy') || msg.includes('rls') || msg.includes('403')) {
        return { success: false, error: 'Permission refusée. Vérifiez les politiques du bucket Storage.' };
      }
      if (msg.includes('duplicate') || msg.includes('already exists')) {
        return { success: false, error: 'Un fichier avec ce nom existe déjà.' };
      }

      return { success: false, error: `Erreur d'upload : ${error.message}` };
    }

    // Get public URL
    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(path);

    if (options.onProgress) {
      options.onProgress(100);
    }

    return {
      success: true,
      url: urlData.publicUrl,
      path: data?.path || path,
      size: file instanceof File ? file.size : (file as Blob).size,
    };
  } catch (err: any) {
    console.error(`[storageService] Upload exception (${bucket}/${path}):`, err);
    return { success: false, error: err?.message || 'Erreur inattendue lors de l\'upload.' };
  }
}

// ============================================================================
// Signed URL Generation (for private buckets)
// ============================================================================

async function getSignedUrl(bucket: string, path: string, expiresIn: number = 3600): Promise<string | null> {
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(path, expiresIn);

    if (error) {
      console.error(`[storageService] Signed URL error (${bucket}/${path}):`, error);
      return null;
    }

    return data?.signedUrl || null;
  } catch (err: any) {
    console.error(`[storageService] Signed URL exception:`, err);
    return null;
  }
}

// ============================================================================
// VOD Service — Upload vidéos pour replay
// ============================================================================

export const vodService = {
  /**
   * Upload a video file to the VOD bucket.
   */
  async uploadVideo(
    userId: string,
    file: File,
    options?: UploadOptions & { streamId?: string }
  ): Promise<UploadResult> {
    const validationError = validateFile(file, VIDEO_MIME_TYPES, MAX_SIZES.VOD, 'vidéos VOD');
    if (validationError) return { success: false, error: validationError };

    const ext = file.name.split('.').pop() || 'mp4';
    const streamId = options?.streamId || Date.now().toString(36);
    const path = `${userId}/${streamId}/video.${ext}`;

    return uploadFile(BUCKETS.VOD, path, file, options);
  },

  /**
   * Upload a thumbnail for a VOD.
   */
  async uploadThumbnail(
    userId: string,
    streamId: string,
    file: File,
    options?: UploadOptions
  ): Promise<UploadResult> {
    const validationError = validateFile(file, IMAGE_MIME_TYPES, MAX_SIZES.AVATAR, 'miniatures');
    if (validationError) return { success: false, error: validationError };

    const ext = file.name.split('.').pop() || 'jpg';
    const path = `${userId}/${streamId}/thumbnail.${ext}`;

    return uploadFile(BUCKETS.VOD, path, file, { ...options, upsert: true });
  },

  /**
   * Upload a recording blob (from MediaRecorder).
   */
  async uploadRecordingBlob(
    userId: string,
    streamId: string,
    blob: Blob,
    options?: UploadOptions
  ): Promise<UploadResult> {
    const ext = blob.type.includes('mp4') ? 'mp4' : 'webm';
    const path = `${userId}/${streamId}/recording.${ext}`;

    return uploadFile(BUCKETS.VOD, path, blob, {
      ...options,
      contentType: blob.type,
      upsert: true,
    });
  },

  /**
   * Delete a VOD and its thumbnail.
   */
  async deleteVod(userId: string, streamId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: files } = await supabase.storage
        .from(BUCKETS.VOD)
        .list(`${userId}/${streamId}`);

      if (files && files.length > 0) {
        const paths = files.map(f => `${userId}/${streamId}/${f.name}`);
        const { error } = await supabase.storage.from(BUCKETS.VOD).remove(paths);
        if (error) return { success: false, error: error.message };
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Erreur lors de la suppression.' };
    }
  },

  /**
   * Get signed URL for a private VOD.
   */
  async getSignedUrl(path: string, expiresIn?: number): Promise<string | null> {
    return getSignedUrl(BUCKETS.VOD, path, expiresIn);
  },

  /**
   * List all VODs for a user.
   */
  async listUserVods(userId: string): Promise<{ name: string; id: string }[]> {
    try {
      const { data, error } = await supabase.storage
        .from(BUCKETS.VOD)
        .list(userId, { sortBy: { column: 'created_at', order: 'desc' } });

      if (error || !data) return [];
      return data.filter(f => f.id).map(f => ({ name: f.name, id: f.id! }));
    } catch {
      return [];
    }
  },
};

// ============================================================================
// Avatar Service
// ============================================================================

export const avatarService = {
  async upload(userId: string, file: File, options?: UploadOptions): Promise<UploadResult> {
    const validationError = validateFile(file, IMAGE_MIME_TYPES, MAX_SIZES.AVATAR, 'avatars');
    if (validationError) return { success: false, error: validationError };

    const ext = file.name.split('.').pop() || 'jpg';
    const path = `${userId}-${Date.now()}.${ext}`;

    return uploadFile(BUCKETS.AVATARS, path, file, { ...options, upsert: true });
  },
};

// ============================================================================
// Verification Document Service
// ============================================================================

export const verificationDocService = {
  async upload(
    userId: string,
    file: File,
    documentType: string,
    options?: UploadOptions
  ): Promise<UploadResult> {
    const validationError = validateFile(file, DOCUMENT_MIME_TYPES, MAX_SIZES.VERIFICATION, 'documents de vérification');
    if (validationError) return { success: false, error: validationError };

    const ext = file.name.split('.').pop() || 'jpg';
    const path = `${userId}/${documentType}_${Date.now()}.${ext}`;

    const result = await uploadFile(BUCKETS.VERIFICATION, path, file, options);

    // For verification docs, return signed URL instead of public URL
    if (result.success && result.path) {
      const signedUrl = await getSignedUrl(BUCKETS.VERIFICATION, result.path, 31536000); // 1 year
      if (signedUrl) {
        result.url = signedUrl;
      }
    }

    return result;
  },
};

// ============================================================================
// Storage Health Check
// ============================================================================

export async function checkStorageBuckets(): Promise<Record<string, { exists: boolean; error?: string }>> {
  const results: Record<string, { exists: boolean; error?: string }> = {};

  for (const [key, bucketName] of Object.entries(BUCKETS)) {
    try {
      const { data, error } = await supabase.storage.from(bucketName).list('', { limit: 1 });

      if (error) {
        const msg = (error.message || '').toLowerCase();
        if (msg.includes('bucket') && msg.includes('not found')) {
          results[key] = { exists: false, error: `Bucket "${bucketName}" introuvable` };
        } else if (msg.includes('permission') || msg.includes('policy')) {
          // Bucket exists but we don't have list permission — that's OK
          results[key] = { exists: true };
        } else {
          results[key] = { exists: false, error: error.message };
        }
      } else {
        results[key] = { exists: true };
      }
    } catch (err: any) {
      results[key] = { exists: false, error: err?.message || 'Erreur de connexion' };
    }
  }

  return results;
}

// Export bucket names for diagnostics
export function getBucketNames(): Record<string, string> {
  return { ...BUCKETS };
}
