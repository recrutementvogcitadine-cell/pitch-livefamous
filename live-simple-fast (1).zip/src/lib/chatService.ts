import { supabase } from './supabase';
import {
  isRlsDenied,
  isNonCriticalError,
  logRlsError,
  getRlsErrorMessage,
  fetchPublicUserInfo,
} from './rlsErrorHandler';

export interface ChatMessage {
  id: string;
  stream_id: string;
  user_id: string;
  display_name: string;
  avatar_url: string | null;
  message: string;
  is_deleted: boolean;
  deleted_by: string | null;
  created_at: string;
}

export interface ChatBan {
  id: string;
  user_id: string;
  stream_id: string | null;
  banned_by: string;
  reason: string;
  banned_user_name: string;
  banned_by_name: string;
  expires_at: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Client-side rate limit tracking
const rateLimitMap = new Map<string, number[]>();

const RATE_LIMIT_WINDOW_MS = 10000; // 10 seconds
const RATE_LIMIT_MAX_MESSAGES = 5; // max 5 messages per window
const MESSAGE_MAX_LENGTH = 500;
const MESSAGE_MIN_LENGTH = 1;

function checkClientRateLimit(userId: string): { allowed: boolean; waitSeconds: number } {
  const now = Date.now();
  const key = userId;
  const timestamps = rateLimitMap.get(key) || [];
  
  // Remove timestamps outside the window
  const recentTimestamps = timestamps.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
  rateLimitMap.set(key, recentTimestamps);
  
  if (recentTimestamps.length >= RATE_LIMIT_MAX_MESSAGES) {
    const oldestInWindow = recentTimestamps[0];
    const waitMs = RATE_LIMIT_WINDOW_MS - (now - oldestInWindow);
    return { allowed: false, waitSeconds: Math.ceil(waitMs / 1000) };
  }
  
  return { allowed: true, waitSeconds: 0 };
}

function recordMessageSent(userId: string) {
  const key = userId;
  const timestamps = rateLimitMap.get(key) || [];
  timestamps.push(Date.now());
  rateLimitMap.set(key, timestamps);
}

export const chatService = {
  async fetchMessages(streamId: string): Promise<{ data: ChatMessage[] | null; error: string | null }> {
    try {
      const { data, error } = await supabase
        .from('live_chat_messages')
        .select('*')
        .eq('stream_id', streamId)
        .eq('is_deleted', false)
        .order('created_at', { ascending: true })
        .limit(200);

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('chatService', 'fetchMessages', error, { streamId });
          return { data: null, error: getRlsErrorMessage(error, 'default') };
        }
        return { data: null, error: error.message };
      }

      return { data: data as ChatMessage[], error: null };
    } catch (err: any) {
      return { data: null, error: err.message };
    }
  },

  /**
   * Enrich chat messages with up-to-date display info from public_utilisateurs view.
   * This is useful when display_name or avatar_url may have changed since the message was sent.
   */
  async enrichMessagesWithUserInfo(messages: ChatMessage[]): Promise<ChatMessage[]> {
    if (!messages || messages.length === 0) return messages;

    const userIds = [...new Set(messages.map(m => m.user_id))];
    const userInfoMap = await fetchPublicUserInfo(userIds);

    return messages.map(msg => {
      const info = userInfoMap.get(msg.user_id);
      if (info) {
        return {
          ...msg,
          display_name: info.display_name || msg.display_name,
          avatar_url: info.avatar_url || msg.avatar_url,
        };
      }
      return msg;
    });
  },

  /**
   * Check ban status — RLS-restricted to admin-only read.
   * Gracefully returns not-banned if RLS denies access.
   */
  async checkBanStatus(
    streamId: string,
    userId: string
  ): Promise<{ isBanned: boolean; ban: ChatBan | null }> {
    try {
      const { data, error } = await supabase
        .from('chat_bans')
        .select('*')
        .eq('user_id', userId)
        .eq('is_active', true)
        .or(`stream_id.eq.${streamId},stream_id.is.null`)
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('chatService', 'checkBanStatus', error, { streamId, userId });
          // If we can't check ban status due to RLS, assume not banned
          // The server-side RLS will still enforce the ban on message insertion
          return { isBanned: false, ban: null };
        }
        return { isBanned: false, ban: null };
      }

      if (data && data.length > 0) {
        const ban = data[0] as ChatBan;
        if (ban.expires_at && new Date(ban.expires_at) < new Date()) {
          try {
            await supabase
              .from('chat_bans')
              .update({ is_active: false, updated_at: new Date().toISOString() })
              .eq('id', ban.id);
          } catch {
            // Ignore — RLS may block the update
          }
          return { isBanned: false, ban: null };
        }
        return { isBanned: true, ban };
      }

      return { isBanned: false, ban: null };
    } catch {
      return { isBanned: false, ban: null };
    }
  },

  /**
   * Ban user — RLS-restricted to admin/moderator only.
   */
  async banUser(
    streamId: string | null,
    userId: string,
    bannedBy: string,
    reason: string,
    bannedUserName: string,
    bannedByName: string,
    expiresAt?: string | null
  ): Promise<{ success: boolean; error?: string; ban?: ChatBan }> {
    try {
      const { data, error } = await supabase
        .from('chat_bans')
        .insert({
          user_id: userId,
          stream_id: streamId,
          banned_by: bannedBy,
          reason: reason || '',
          banned_user_name: bannedUserName,
          banned_by_name: bannedByName,
          expires_at: expiresAt || null,
          is_active: true,
        })
        .select()
        .single();

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('chatService', 'banUser', error);
          return { success: false, error: getRlsErrorMessage(error, 'chat_bans') };
        }
        return { success: false, error: error.message };
      }

      return { success: true, ban: data as ChatBan };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async unbanUser(banId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('chat_bans')
        .update({ is_active: false, updated_at: new Date().toISOString() })
        .eq('id', banId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'chat_bans') };
        }
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async getBannedUsers(streamId?: string): Promise<ChatBan[]> {
    try {
      let query = supabase
        .from('chat_bans')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (streamId) {
        query = query.or(`stream_id.eq.${streamId},stream_id.is.null`);
      }

      const { data, error } = await query;

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('chatService', 'getBannedUsers', error);
          return [];
        }
        return [];
      }

      const now = new Date();
      const activeBans: ChatBan[] = [];
      for (const ban of (data || []) as ChatBan[]) {
        if (ban.expires_at && new Date(ban.expires_at) < now) {
          supabase
            .from('chat_bans')
            .update({ is_active: false, updated_at: now.toISOString() })
            .eq('id', ban.id)
            .then(() => {});
        } else {
          activeBans.push(ban);
        }
      }

      return activeBans;
    } catch {
      return [];
    }
  },

  async getAllBans(options?: { activeOnly?: boolean; limit?: number }): Promise<ChatBan[]> {
    try {
      let query = supabase
        .from('chat_bans')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(options?.limit || 100);

      if (options?.activeOnly) {
        query = query.eq('is_active', true);
      }

      const { data, error } = await query;

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('chatService', 'getAllBans', error);
          return [];
        }
        return [];
      }

      return (data || []) as ChatBan[];
    } catch {
      return [];
    }
  },

  async sendMessage(
    streamId: string,
    userId: string,
    displayName: string,
    avatarUrl: string | null,
    messageText: string
  ): Promise<{ success: boolean; error?: string; waitSeconds?: number; isBanned?: boolean }> {
    const trimmed = messageText.trim();
    if (trimmed.length < MESSAGE_MIN_LENGTH) {
      return { success: false, error: 'Le message est vide' };
    }
    if (trimmed.length > MESSAGE_MAX_LENGTH) {
      return { success: false, error: `Le message est trop long (max ${MESSAGE_MAX_LENGTH} caractères)` };
    }

    const banCheck = await this.checkBanStatus(streamId, userId);
    if (banCheck.isBanned) {
      const ban = banCheck.ban;
      let banMsg = 'Vous êtes banni de ce chat.';
      if (ban?.reason) {
        banMsg += ` Raison : ${ban.reason}`;
      }
      if (ban?.expires_at) {
        const expiresDate = new Date(ban.expires_at);
        banMsg += ` (expire le ${expiresDate.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })})`;
      }
      return { success: false, error: banMsg, isBanned: true };
    }

    const rateCheck = checkClientRateLimit(userId);
    if (!rateCheck.allowed) {
      return { 
        success: false, 
        error: `Trop de messages. Attendez ${rateCheck.waitSeconds}s`,
        waitSeconds: rateCheck.waitSeconds 
      };
    }

    try {
      const { data: countData, error: countError } = await supabase
        .rpc('count_recent_messages', { 
          p_user_id: userId, 
          p_stream_id: streamId, 
          p_seconds: 10 
        });

      if (!countError && countData !== null && countData >= RATE_LIMIT_MAX_MESSAGES) {
        return { 
          success: false, 
          error: 'Trop de messages. Veuillez patienter quelques secondes.',
          waitSeconds: 5 
        };
      }
    } catch {
      // If RPC fails, continue with client-side check only
    }

    try {
      const { error } = await supabase
        .from('live_chat_messages')
        .insert({
          stream_id: streamId,
          user_id: userId,
          display_name: displayName,
          avatar_url: avatarUrl,
          message: trimmed,
        });

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('chatService', 'sendMessage', error);
          return { success: false, error: 'Vous n\'avez pas la permission d\'envoyer des messages.' };
        }
        return { success: false, error: error.message };
      }

      recordMessageSent(userId);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async deleteMessage(
    messageId: string,
    deletedByUserId: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('live_chat_messages')
        .update({ 
          is_deleted: true, 
          deleted_by: deletedByUserId 
        })
        .eq('id', messageId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'moderation') };
        }
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async isStreamCreator(streamId: string, userId: string): Promise<boolean> {
    try {
      const { data, error } = await supabase
        .rpc('get_stream_creator_id', { p_stream_id: streamId });

      if (error) {
        if (isNonCriticalError(error)) {
          logRlsError('chatService', 'isStreamCreator', error);
        }
        return false;
      }

      return data === userId;
    } catch {
      return false;
    }
  },

  subscribeToMessages(
    streamId: string,
    onNewMessage: (msg: ChatMessage) => void,
    onMessageDeleted: (msgId: string) => void
  ): () => void {
    const channel = supabase
      .channel(`live-chat:${streamId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'live_chat_messages',
          filter: `stream_id=eq.${streamId}`,
        },
        (payload) => {
          const newMsg = payload.new as ChatMessage;
          if (!newMsg.is_deleted) {
            onNewMessage(newMsg);
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'live_chat_messages',
          filter: `stream_id=eq.${streamId}`,
        },
        (payload) => {
          const updated = payload.new as ChatMessage;
          if (updated.is_deleted) {
            onMessageDeleted(updated.id);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};
