import { supabase } from './supabase';
import {
  isRlsDenied,
  isNonCriticalError,
  logRlsError,
  getRlsErrorMessage,
} from './rlsErrorHandler';

export interface Recording {
  id: string;
  title: string;
  thumbnail_url: string;
  recording_url: string;
  duration_seconds: number;
  recording_size_bytes: number;
  viewer_count: number;
  peak_viewers: number;
  started_at: string;
  ended_at: string;
  recording_status: 'none' | 'recording' | 'processing' | 'uploading' | 'completed' | 'failed';
}

export interface RecordingUploadProgress {
  streamId: string;
  progress: number;
  status: 'uploading' | 'processing' | 'completed' | 'failed';
  error?: string;
}

export const recordingService = {
  // Get all recordings for a creator
  async getCreatorRecordings(creatorUserId: string): Promise<Recording[]> {
    const { data, error } = await supabase
      .from('live_streams')
      .select('*')
      .eq('creator_id', creatorUserId)
      .eq('is_live', false)
      .eq('recording_status', 'completed')
      .not('recording_url', 'is', null)
      .order('ended_at', { ascending: false });

    if (error) {
      if (isRlsDenied(error)) {
        logRlsError('recordingService', 'getCreatorRecordings', error, { creatorUserId });
        return [];
      }
      console.error('Error fetching recordings:', error);
      return [];
    }

    return data || [];
  },

  // Get all recordings including in-progress ones
  async getAllCreatorRecordings(creatorUserId: string): Promise<Recording[]> {
    const { data, error } = await supabase
      .from('live_streams')
      .select('*')
      .eq('creator_id', creatorUserId)
      .eq('recording_enabled', true)
      .order('started_at', { ascending: false });

    if (error) {
      if (isRlsDenied(error)) {
        logRlsError('recordingService', 'getAllCreatorRecordings', error, { creatorUserId });
        return [];
      }
      console.error('Error fetching recordings:', error);
      return [];
    }

    return data || [];
  },

  // Get a single recording by ID
  async getRecording(streamId: string): Promise<Recording | null> {
    const { data, error } = await supabase
      .from('live_streams')
      .select('*')
      .eq('id', streamId)
      .single();

    if (error) {
      if (isRlsDenied(error)) {
        logRlsError('recordingService', 'getRecording', error, { streamId });
        return null;
      }
      console.error('Error fetching recording:', error);
      return null;
    }

    return data;
  },

  // Update recording status
  async updateRecordingStatus(
    streamId: string, 
    status: Recording['recording_status'],
    additionalData?: Partial<Recording>
  ): Promise<boolean> {
    const updateData: any = { recording_status: status, ...additionalData };

    const { error } = await supabase
      .from('live_streams')
      .update(updateData)
      .eq('id', streamId);

    if (error) {
      if (isRlsDenied(error)) {
        logRlsError('recordingService', 'updateRecordingStatus', error, { streamId, status });
        return false;
      }
      console.error('Error updating recording status:', error);
      return false;
    }

    return true;
  },

  // Upload recording to storage
  async uploadRecording(
    streamId: string, 
    blob: Blob,
    onProgress?: (progress: number) => void
  ): Promise<{ url: string; size: number } | null> {
    try {
      const extension = blob.type.includes('mp4') ? 'mp4' : 'webm';
      const fileName = `${streamId}/recording.${extension}`;

      // Update status to uploading
      await this.updateRecordingStatus(streamId, 'uploading');

      const { data, error } = await supabase.storage
        .from('recordings')
        .upload(fileName, blob, {
          contentType: blob.type,
          upsert: true
        });

      if (error) {
        throw error;
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('recordings')
        .getPublicUrl(fileName);

      // Update database with recording info
      await this.updateRecordingStatus(streamId, 'completed', {
        recording_url: urlData.publicUrl,
        recording_size_bytes: blob.size
      });

      return {
        url: urlData.publicUrl,
        size: blob.size
      };
    } catch (error) {
      console.error('Error uploading recording:', error);
      await this.updateRecordingStatus(streamId, 'failed');
      return null;
    }
  },

  // Format file size for display
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  },

  // Format duration for display
  formatDuration(seconds: number): string {
    if (!seconds || seconds < 0) return '0s';
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return secs > 0 ? `${mins}min ${secs}s` : `${mins}min`;
    }
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    return mins > 0 ? `${hours}h ${mins}min` : `${hours}h`;
  },

  // Format duration as HH:MM:SS
  formatDurationLong(seconds: number): string {
    if (!seconds || seconds < 0) return '00:00';
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  },

  // Delete a recording
  async deleteRecording(streamId: string): Promise<boolean> {
    try {
      // Get recording info first
      const recording = await this.getRecording(streamId);
      
      if (recording?.recording_url) {
        const urlParts = recording.recording_url.split('/');
        const fileName = urlParts.slice(-2).join('/');

        const { error: storageError } = await supabase.storage
          .from('recordings')
          .remove([fileName]);

        if (storageError) {
          console.error('Error deleting recording file:', storageError);
        }
      }

      // Also try to delete any chunks
      const { data: chunks } = await supabase.storage
        .from('recordings')
        .list(streamId);

      if (chunks && chunks.length > 0) {
        const chunkPaths = chunks.map(chunk => `${streamId}/${chunk.name}`);
        await supabase.storage.from('recordings').remove(chunkPaths);
      }

      // Update the database to remove recording info
      const { error: dbError } = await supabase
        .from('live_streams')
        .update({
          recording_url: null,
          recording_status: 'none',
          recording_size_bytes: null
        })
        .eq('id', streamId);

      if (dbError) {
        if (isRlsDenied(dbError)) {
          logRlsError('recordingService', 'deleteRecording', dbError, { streamId });
          return false;
        }
        console.error('Error updating stream record:', dbError);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error deleting recording:', error);
      return false;
    }
  },

  // Get recording status text
  getStatusText(status: string): string {
    switch (status) {
      case 'recording':
        return 'Enregistrement en cours';
      case 'uploading':
        return 'Upload en cours';
      case 'processing':
        return 'Traitement en cours';
      case 'completed':
        return 'Disponible';
      case 'failed':
        return 'Échec';
      default:
        return 'Non enregistré';
    }
  },

  // Get status color class
  getStatusColor(status: string): string {
    switch (status) {
      case 'recording':
        return 'text-red-500';
      case 'uploading':
        return 'text-blue-500';
      case 'processing':
        return 'text-yellow-500';
      case 'completed':
        return 'text-green-500';
      case 'failed':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  },

  // Get status badge class
  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'recording':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'uploading':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'processing':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'completed':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'failed':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  },

  // Check if browser supports recording
  isRecordingSupported(): boolean {
    return typeof MediaRecorder !== 'undefined' && 
           typeof navigator.mediaDevices !== 'undefined' &&
           typeof navigator.mediaDevices.getUserMedia === 'function';
  },

  // Get supported MIME types
  getSupportedMimeTypes(): string[] {
    const types = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm;codecs=vp9',
      'video/webm;codecs=vp8',
      'video/webm',
      'video/mp4;codecs=h264,aac',
      'video/mp4'
    ];

    return types.filter(type => MediaRecorder.isTypeSupported(type));
  },

  // Estimate recording size based on duration and quality
  estimateRecordingSize(durationSeconds: number, videoBitrate: number = 2500000, audioBitrate: number = 128000): number {
    const totalBitrate = videoBitrate + audioBitrate;
    const bytesPerSecond = totalBitrate / 8;
    return Math.floor(bytesPerSecond * durationSeconds);
  }
};
