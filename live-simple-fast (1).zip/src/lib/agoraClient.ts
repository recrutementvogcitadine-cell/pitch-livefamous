/**
 * agoraClient.ts
 *
 * Client-side Agora RTC integration for PitchCI.
 *
 * ARCHITECTURE DE SÉCURITÉ :
 * ─────────────────────────
 * ┌─────────────────────────────────────────────────────────────┐
 * │  FRONTEND (ce fichier)                                     │
 * │  • App ID (VITE_AGORA_APP_ID) — PUBLIC, safe côté client   │
 * │  • Token — obtenu via Edge Function (jamais généré ici)     │
 * │  • Rejoint les canaux Agora avec le token signé             │
 * │                                                             │
 * │  ⚠️  AUCUN App Certificate ici — c'est un SECRET serveur   │
 * └─────────────────┬───────────────────────────────────────────┘
 *                   │ supabase.functions.invoke('generate-agora-token')
 *                   ▼
 * ┌─────────────────────────────────────────────────────────────┐
 * │  SUPABASE EDGE FUNCTION (serveur)                          │
 * │  • App Certificate (AGORA_APP_CERTIFICATE) — SECRET        │
 * │  • Valide le JWT utilisateur                                │
 * │  • Génère le token RTC signé avec agora-access-token        │
 * │  • Retourne : { token, channel, uid, app_id, expiry }      │
 * └─────────────────────────────────────────────────────────────┘
 *
 * FLUX :
 * 1. Frontend demande un token à l'Edge Function (avec JWT auth)
 * 2. Edge Function valide l'utilisateur, génère le token avec le Certificate
 * 3. Frontend reçoit le token signé + App ID
 * 4. Frontend utilise le SDK Agora pour rejoindre le canal avec ce token
 */

import AgoraRTC, {
  type IAgoraRTCClient,
  type IMicrophoneAudioTrack,
  type ICameraVideoTrack,
  type IAgoraRTCRemoteUser,
  type IRemoteVideoTrack,
  type IRemoteAudioTrack,
} from 'agora-rtc-sdk-ng';

import { agoraService, liveManagementService } from './edgeFunctions';
import type { AgoraTokenResponse } from './edgeFunctions';

// ============================================================================
// AGORA APP ID — Now resolved from edge function, not env var
// ============================================================================

/** Cached App ID from the last edge function response */
let _cachedAppId = '';

export function getAgoraAppId(): string {
  return _cachedAppId || import.meta.env.VITE_AGORA_APP_ID || '';
}

/**
 * Check if Agora is configured. Uses cached App ID from edge function
 * or falls back to VITE_AGORA_APP_ID env var.
 * For definitive check, use liveManagementService.checkAgoraStatus().
 */
export function isAgoraConfigured(): boolean {
  const appId = getAgoraAppId();
  return !!(appId && appId.length > 10 && !appId.includes('your-agora'));
}

// ============================================================================
// SDK Configuration
// ============================================================================

// Disable Agora SDK console logs in production
if (import.meta.env.PROD) {
  AgoraRTC.setLogLevel(3); // ERROR only
} else {
  AgoraRTC.setLogLevel(1); // INFO
}

// ============================================================================
// TYPES
// ============================================================================

export interface AgoraChannelInfo {
  channelName: string;
  token: string;
  uid: number;
  appId: string;
  expiry: number;
  role: 'publisher' | 'subscriber';
}

export interface AgoraClientState {
  isJoined: boolean;
  isPublishing: boolean;
  channelName: string | null;
  uid: number | null;
  role: 'publisher' | 'subscriber' | null;
  remoteUsers: Map<number, IAgoraRTCRemoteUser>;
  localAudioTrack: IMicrophoneAudioTrack | null;
  localVideoTrack: ICameraVideoTrack | null;
}

type StateChangeCallback = (state: AgoraClientState) => void;
type RemoteUserCallback = (user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => void;
type ErrorCallback = (error: string) => void;

// ============================================================================
// AGORA CLIENT — Main class for managing RTC connections
// ============================================================================

class AgoraClientManager {
  private client: IAgoraRTCClient | null = null;
  private state: AgoraClientState = {
    isJoined: false,
    isPublishing: false,
    channelName: null,
    uid: null,
    role: null,
    remoteUsers: new Map(),
    localAudioTrack: null,
    localVideoTrack: null,
  };

  private onStateChange: StateChangeCallback | null = null;
  private onRemoteUserJoined: RemoteUserCallback | null = null;
  private onRemoteUserLeft: ((uid: number) => void) | null = null;
  private onError: ErrorCallback | null = null;

  // Token refresh timer
  private tokenRefreshTimer: ReturnType<typeof setTimeout> | null = null;

  /**
   * Set event callbacks.
   */
  setCallbacks(callbacks: {
    onStateChange?: StateChangeCallback;
    onRemoteUserJoined?: RemoteUserCallback;
    onRemoteUserLeft?: (uid: number) => void;
    onError?: ErrorCallback;
  }) {
    this.onStateChange = callbacks.onStateChange || null;
    this.onRemoteUserJoined = callbacks.onRemoteUserJoined || null;
    this.onRemoteUserLeft = callbacks.onRemoteUserLeft || null;
    this.onError = callbacks.onError || null;
  }

  private emitState() {
    this.onStateChange?.({ ...this.state });
  }

  private emitError(msg: string) {
    console.error('[AgoraClient]', msg);
    this.onError?.(msg);
  }

  /**
   * Get the current state (read-only snapshot).
   */
  getState(): Readonly<AgoraClientState> {
    return { ...this.state };
  }

  /**
   * Get the underlying IAgoraRTCClient (for advanced usage).
   */
  getRTCClient(): IAgoraRTCClient | null {
    return this.client;
  }

  // ============================================================================
  // TOKEN ACQUISITION — Always from Edge Function, never local
  // ============================================================================

  /**
   * Request a publisher token from the Supabase Edge Function.
   * The Edge Function validates the JWT and generates the token server-side.
   */
  async requestPublisherToken(channelName: string): Promise<AgoraChannelInfo> {
    const result = await agoraService.generatePublisherToken(channelName);
    if (!result.success || !result.data) {
      throw new Error(result.error || 'Impossible d\'obtenir un token publisher');
    }
    return this.mapTokenResponse(result.data, 'publisher');
  }

  /**
   * Request a subscriber token from the Supabase Edge Function.
   * The Edge Function validates the JWT and generates the token server-side.
   */
  async requestSubscriberToken(channelName: string): Promise<AgoraChannelInfo> {
    const result = await agoraService.generateSubscriberToken(channelName);
    if (!result.success || !result.data) {
      throw new Error(result.error || 'Impossible d\'obtenir un token subscriber');
    }
    return this.mapTokenResponse(result.data, 'subscriber');
  }

  private mapTokenResponse(data: AgoraTokenResponse, role: 'publisher' | 'subscriber'): AgoraChannelInfo {
    return {
      channelName: data.channel,
      token: data.token,
      uid: data.uid,
      appId: data.app_id,
      expiry: data.expiry,
      role,
    };
  }

  // ============================================================================
  // JOIN AS PUBLISHER — Creator streaming with mic + camera via Agora SDK
  // ============================================================================

  /**
   * Join a channel as a PUBLISHER (creator streaming).
   *
   * Uses AgoraRTC.createMicrophoneAudioTrack() and AgoraRTC.createCameraVideoTrack()
   * for optimal quality and echo cancellation, instead of raw getUserMedia.
   *
   * Flow:
   * 1. Requests a publisher token from the Edge Function
   * 2. Creates an Agora RTC client in 'live' mode as 'host'
   * 3. Joins the channel with the server-signed token
   * 4. Creates mic/camera tracks via Agora SDK
   */
  async joinAsPublisher(

    channelName: string,
    options: {
      isAudioOnly?: boolean;
      existingMediaStream?: MediaStream;
      /** Pre-generated token from manage-live edge function */
      preGeneratedToken?: string;
      /** Pre-provided App ID from manage-live edge function */
      preGeneratedAppId?: string;
      /** Pre-provided UID */
      preGeneratedUid?: number;
    } = {}
  ): Promise<AgoraChannelInfo> {
    const { isAudioOnly = false, existingMediaStream, preGeneratedToken, preGeneratedAppId, preGeneratedUid } = options;

    try {
      let channelInfo: AgoraChannelInfo;

      // Use pre-generated token from manage-live if available (avoids double edge function call)
      if (preGeneratedToken && preGeneratedAppId) {
        channelInfo = {
          channelName,
          token: preGeneratedToken,
          uid: preGeneratedUid ?? 0,
          appId: preGeneratedAppId,
          expiry: Math.floor(Date.now() / 1000) + 7200,
          role: 'publisher',
        };
      } else {
        // Fallback: request token from Edge Function
        channelInfo = await this.requestPublisherToken(channelName);
      }

      // Create RTC client in 'live' mode
      this.client = AgoraRTC.createClient({ mode: 'live', codec: 'vp8' });
      this.client.setClientRole('host');

      // Set up event listeners BEFORE joining
      this.setupEventListeners();

      // Join the channel with the token
      const uid = await this.client.join(
        channelInfo.appId,
        channelInfo.channelName,
        channelInfo.token,
        channelInfo.uid || null
      );

      this.state.isJoined = true;
      this.state.channelName = channelInfo.channelName;
      this.state.uid = uid as number;
      this.state.role = 'publisher';

      if (existingMediaStream) {
        const audioTrack = existingMediaStream.getAudioTracks()[0];
        if (audioTrack) {
          this.state.localAudioTrack = AgoraRTC.createCustomAudioTrack({
            mediaStreamTrack: audioTrack,
          }) as unknown as IMicrophoneAudioTrack;
        }

        if (!isAudioOnly) {
          const videoTrack = existingMediaStream.getVideoTracks()[0];
          if (videoTrack) {
            this.state.localVideoTrack = AgoraRTC.createCustomVideoTrack({
              mediaStreamTrack: videoTrack,
            }) as unknown as ICameraVideoTrack;
          }
        }
      } else {
        try {
          this.state.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack({
            AEC: true,
            ANS: true,
            AGC: true,
          });
        } catch (err: any) {
          console.warn('[AgoraClient] Microphone creation failed:', err.message);
          this.emitError('Impossible d\'accéder au microphone');
        }

        if (!isAudioOnly) {
          try {
            this.state.localVideoTrack = await AgoraRTC.createCameraVideoTrack({
              encoderConfig: {
                width: 1280,
                height: 720,
                frameRate: 30,
                bitrateMax: 2500,
              },
              facingMode: 'user',
            });
          } catch (err: any) {
            console.warn('[AgoraClient] Camera creation failed:', err.message);
            this.emitError('Impossible d\'accéder à la caméra — mode audio uniquement');
          }
        }
      }

      const tracksToPublish: Array<IMicrophoneAudioTrack | ICameraVideoTrack> = [];
      if (this.state.localAudioTrack) tracksToPublish.push(this.state.localAudioTrack);
      if (this.state.localVideoTrack) tracksToPublish.push(this.state.localVideoTrack);

      if (tracksToPublish.length > 0) {
        await this.client.publish(tracksToPublish);
        this.state.isPublishing = true;
        console.info(`[AgoraClient] Published ${tracksToPublish.length} track(s)`);
      }

      this.scheduleTokenRefresh(channelInfo);

      this.emitState();
      console.info(`[AgoraClient] Joined as publisher — channel: ${channelInfo.channelName}, uid: ${uid}`);

      return { ...channelInfo, uid: uid as number };
    } catch (err: any) {
      this.emitError(`Erreur lors de la connexion publisher : ${err.message}`);
      throw err;
    }
  }


  // ============================================================================
  // JOIN AS SUBSCRIBER — Viewer watching a live stream
  // ============================================================================

  /**
   * Join a channel as a SUBSCRIBER (viewer watching).
   *
   * Flow:
   * 1. Requests a subscriber token from the Edge Function
   * 2. Creates an Agora RTC client in 'live' mode as 'audience'
   * 3. Joins the channel with the server-signed token
   * 4. Automatically subscribes to remote tracks via event listeners
   */
  async joinAsSubscriber(channelName: string): Promise<AgoraChannelInfo> {
    try {
      // Request token from Edge Function (server-side generation)
      const channelInfo = await this.requestSubscriberToken(channelName);

      // Create RTC client in 'live' mode as audience
      this.client = AgoraRTC.createClient({ mode: 'live', codec: 'vp8' });
      this.client.setClientRole('audience');

      // Set up event listeners BEFORE joining
      this.setupEventListeners();

      // Join the channel with the server-generated token
      const uid = await this.client.join(
        channelInfo.appId,
        channelInfo.channelName,
        channelInfo.token,
        channelInfo.uid || null
      );

      this.state.isJoined = true;
      this.state.channelName = channelInfo.channelName;
      this.state.uid = uid as number;
      this.state.role = 'subscriber';

      // Schedule token refresh before expiry
      this.scheduleTokenRefresh(channelInfo);

      this.emitState();
      console.info(`[AgoraClient] Joined as subscriber — channel: ${channelInfo.channelName}, uid: ${uid}`);

      return { ...channelInfo, uid: uid as number };
    } catch (err: any) {
      this.emitError(`Erreur lors de la connexion subscriber : ${err.message}`);
      throw err;
    }
  }

  // ============================================================================
  // LEAVE — Disconnect and clean up
  // ============================================================================

  /**
   * Leave the current channel and clean up all resources.
   */
  async leave(): Promise<void> {
    try {
      // Clear token refresh timer
      if (this.tokenRefreshTimer) {
        clearTimeout(this.tokenRefreshTimer);
        this.tokenRefreshTimer = null;
      }

      // Close and release local tracks
      if (this.state.localAudioTrack) {
        this.state.localAudioTrack.close();
        this.state.localAudioTrack = null;
      }
      if (this.state.localVideoTrack) {
        this.state.localVideoTrack.close();
        this.state.localVideoTrack = null;
      }

      // Leave the channel
      if (this.client) {
        await this.client.leave();
        this.client = null;
      }

      // Reset state
      this.state = {
        isJoined: false,
        isPublishing: false,
        channelName: null,
        uid: null,
        role: null,
        remoteUsers: new Map(),
        localAudioTrack: null,
        localVideoTrack: null,
      };

      this.emitState();
      console.info('[AgoraClient] Left channel and cleaned up');
    } catch (err: any) {
      console.warn('[AgoraClient] Error during leave:', err.message);
    }
  }

  // ============================================================================
  // LOCAL TRACK HELPERS — For preview and mute/unmute
  // ============================================================================

  /**
   * Play the local video track in a container element (for preview).
   */
  playLocalVideo(container: HTMLElement | string): void {
    if (this.state.localVideoTrack) {
      this.state.localVideoTrack.play(container);
    }
  }

  /**
   * Mute/unmute the local audio track.
   */
  async setAudioMuted(muted: boolean): Promise<void> {
    if (this.state.localAudioTrack) {
      await this.state.localAudioTrack.setMuted(muted);
    }
  }

  /**
   * Mute/unmute the local video track.
   */
  async setVideoMuted(muted: boolean): Promise<void> {
    if (this.state.localVideoTrack) {
      await this.state.localVideoTrack.setMuted(muted);
    }
  }

  /**
   * Get the MediaStream from local tracks (for local recording).
   */
  getLocalMediaStream(): MediaStream | null {
    const tracks: MediaStreamTrack[] = [];

    if (this.state.localAudioTrack) {
      const audioTrack = this.state.localAudioTrack.getMediaStreamTrack();
      if (audioTrack) tracks.push(audioTrack);
    }
    if (this.state.localVideoTrack) {
      const videoTrack = this.state.localVideoTrack.getMediaStreamTrack();
      if (videoTrack) tracks.push(videoTrack);
    }

    return tracks.length > 0 ? new MediaStream(tracks) : null;
  }

  // ============================================================================
  // TOKEN REFRESH — Automatically renew before expiry
  // ============================================================================

  private scheduleTokenRefresh(channelInfo: AgoraChannelInfo) {
    if (this.tokenRefreshTimer) {
      clearTimeout(this.tokenRefreshTimer);
    }

    // Refresh 2 minutes before expiry (or at 80% of the token lifetime)
    const now = Math.floor(Date.now() / 1000);
    const expiresIn = channelInfo.expiry - now;
    const refreshIn = Math.max(60, expiresIn - 120); // At least 60s, or 2min before expiry

    this.tokenRefreshTimer = setTimeout(async () => {
      if (!this.state.isJoined || !this.state.channelName || !this.client) return;

      try {
        console.info('[AgoraClient] Renouvellement du token...');
        const role = this.state.role || 'subscriber';
        const result = role === 'publisher'
          ? await agoraService.generatePublisherToken(this.state.channelName)
          : await agoraService.generateSubscriberToken(this.state.channelName);

        if (result.success && result.data) {
          await this.client.renewToken(result.data.token);
          console.info('[AgoraClient] Token renouvelé avec succès');

          // Schedule next refresh
          this.scheduleTokenRefresh(this.mapTokenResponse(result.data, role));
        } else {
          this.emitError('Échec du renouvellement du token. La connexion pourrait être interrompue.');
        }
      } catch (err: any) {
        this.emitError(`Erreur de renouvellement du token : ${err.message}`);
      }
    }, refreshIn * 1000);

    console.info(`[AgoraClient] Token refresh programmé dans ${Math.round(refreshIn / 60)}min`);
  }

  // ============================================================================
  // EVENT LISTENERS — Handle remote users and connection events
  // ============================================================================

  private setupEventListeners() {
    if (!this.client) return;

    // When a remote user publishes a track, subscribe to it
    this.client.on('user-published', async (user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
      if (!this.client) return;
      try {
        await this.client.subscribe(user, mediaType);
        this.state.remoteUsers.set(user.uid as number, user);
        this.onRemoteUserJoined?.(user, mediaType);
        this.emitState();
        console.info(`[AgoraClient] Subscribed to remote user ${user.uid} — ${mediaType}`);
      } catch (err: any) {
        console.warn(`[AgoraClient] Failed to subscribe to user ${user.uid}:`, err.message);
      }
    });

    this.client.on('user-unpublished', (user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
      console.info(`[AgoraClient] Remote user ${user.uid} unpublished ${mediaType}`);
      // Re-emit state so UI can update
      this.emitState();
    });

    this.client.on('user-left', (user: IAgoraRTCRemoteUser) => {
      this.state.remoteUsers.delete(user.uid as number);
      this.onRemoteUserLeft?.(user.uid as number);
      this.emitState();
      console.info(`[AgoraClient] Remote user ${user.uid} left`);
    });

    this.client.on('token-privilege-will-expire', async () => {
      console.warn('[AgoraClient] Token va expirer — renouvellement en cours...');
      if (this.state.channelName && this.client) {
        const role = this.state.role || 'subscriber';
        try {
          const result = role === 'publisher'
            ? await agoraService.generatePublisherToken(this.state.channelName)
            : await agoraService.generateSubscriberToken(this.state.channelName);

          if (result.success && result.data && this.client) {
            await this.client.renewToken(result.data.token);
            console.info('[AgoraClient] Token renouvelé (privilege-will-expire)');
          }
        } catch (err: any) {
          this.emitError(`Renouvellement token échoué : ${err.message}`);
        }
      }
    });

    this.client.on('token-privilege-did-expire', () => {
      this.emitError('Le token Agora a expiré. Veuillez rafraîchir la page.');
    });

    this.client.on('connection-state-change', (curState: string, prevState: string) => {
      console.info(`[AgoraClient] Connection: ${prevState} → ${curState}`);
      if (curState === 'DISCONNECTED' && this.state.isJoined) {
        this.emitError('Connexion au serveur de streaming perdue.');
      }
    });

    this.client.on('exception', (event: { code: string; msg: string }) => {
      console.warn('[AgoraClient] Exception:', event.code, event.msg);
    });
  }

  // ============================================================================
  // HELPERS
  // ============================================================================

  /**
   * Check if the Agora SDK is available (always true since it's a direct import).
   */
  async isSDKAvailable(): Promise<boolean> {
    return true;
  }

  /**
   * Get diagnostic info about the Agora configuration.
   */
  getDiagnostics(): {
    appIdConfigured: boolean;
    appIdSource: string;
    sdkLoaded: boolean;
    sdkError: string | null;
    isJoined: boolean;
    channelName: string | null;
    role: string | null;
  } {
    const appId = getAgoraAppId();
    return {
      appIdConfigured: isAgoraConfigured(),
      appIdSource: appId ? `${appId.substring(0, 8)}...` : '(non configuré)',
      sdkLoaded: true,
      sdkError: null,
      isJoined: this.state.isJoined,
      channelName: this.state.channelName,
      role: this.state.role,
    };
  }
}

// ============================================================================
// SINGLETON EXPORT
// ============================================================================

/**
 * Singleton Agora client instance.
 * Use this throughout the app to manage a single RTC connection.
 */
export const agoraClient = new AgoraClientManager();

// ============================================================================
// Re-export Agora types for components
// ============================================================================
export type { IAgoraRTCRemoteUser, IRemoteVideoTrack, IRemoteAudioTrack };

// ============================================================================
// CONVENIENCE FUNCTIONS — For components that don't need the full client
// ============================================================================

/**
 * Start a live stream: calls the Edge Function to create the stream record
 * and get Agora credentials, then joins the channel as publisher.
 *
 * This is the recommended way to start a live — it handles:
 * 1. Edge Function call (manage-live → start)
 * 2. Agora channel join as publisher with createMicrophoneAndCameraTracks
 * 3. Token refresh scheduling
 *
 * Returns the stream ID, channel info, and a MediaStream for local recording.
 */
export async function startLiveStream(params: {
  title: string;
  isAudioOnly?: boolean;
  recordingEnabled?: boolean;
  /** Optional existing MediaStream from preview — if provided, Agora wraps these tracks */
  mediaStream?: MediaStream | null;
}): Promise<{
  streamId: string;
  channelInfo: AgoraChannelInfo;
  /** MediaStream from Agora tracks — use this for local recording */
  recordingStream: MediaStream | null;
}> {
  // 1. Call Edge Function to create stream + get Agora credentials
  const result = await liveManagementService.startLive({
    title: params.title,
    is_audio_only: params.isAudioOnly,
    recording_enabled: params.recordingEnabled,
  });

  if (!result.success || !result.data) {
    throw new Error(result.error || 'Impossible de démarrer le live');
  }

  const { stream_id, channel_name, agora_token, agora_app_id, uid } = result.data;

  // 2. Join Agora channel as publisher
  let channelInfo: AgoraChannelInfo = {
    channelName: channel_name,
    token: agora_token,
    uid: uid,
    appId: agora_app_id,
    expiry: Math.floor(Date.now() / 1000) + 7200,
    role: 'publisher',
  };

  try {
    if (agora_token && agora_app_id) {
      // Cache the App ID from the edge function response
      _cachedAppId = agora_app_id;
      // Pass pre-generated credentials to avoid a second edge function call
      channelInfo = await agoraClient.joinAsPublisher(channel_name, {
        isAudioOnly: params.isAudioOnly,
        existingMediaStream: params.mediaStream || undefined,
        preGeneratedToken: agora_token,
        preGeneratedAppId: agora_app_id,
        preGeneratedUid: uid,
      });
    } else {
      console.info('[AgoraClient] Pas de credentials Agora — mode enregistrement local uniquement');
    }
  } catch (err: any) {
    // Don't fail the whole live start if Agora join fails
    // The stream is already created in the DB, recording can still work
    console.warn('[AgoraClient] Agora join failed, continuing without RTC:', err.message);
  }


  // 3. Get a MediaStream from the Agora tracks for local recording
  const recordingStream = agoraClient.getLocalMediaStream();

  return { streamId: stream_id, channelInfo, recordingStream };
}

/**
 * End a live stream: leaves the Agora channel and calls the Edge Function
 * to update the stream record.
 */
export async function endLiveStream(streamId: string): Promise<{
  durationSeconds: number;
  peakViewers: number;
  recordingUrl?: string;
}> {
  // 1. Leave Agora channel (closes tracks)
  await agoraClient.leave();

  // 2. Call Edge Function to end the stream
  const result = await liveManagementService.endLive({ stream_id: streamId });

  if (!result.success || !result.data) {
    throw new Error(result.error || 'Erreur lors de la fin du live');
  }

  return {
    durationSeconds: result.data.duration_seconds,
    peakViewers: result.data.peak_viewers,
    recordingUrl: result.data.recording_url,
  };
}

/**
 * Join a live stream as a viewer: requests a subscriber token from the
 * Edge Function and joins the Agora channel.
 */
export async function joinLiveAsViewer(channelName: string): Promise<AgoraChannelInfo | null> {
  try {
    return await agoraClient.joinAsSubscriber(channelName);
  } catch (err: any) {
    console.warn('[AgoraClient] Failed to join as viewer:', err.message);
    return null;
  }
}

/**
 * Leave a live stream as a viewer.
 */
export async function leaveLiveAsViewer(): Promise<void> {
  await agoraClient.leave();
}
