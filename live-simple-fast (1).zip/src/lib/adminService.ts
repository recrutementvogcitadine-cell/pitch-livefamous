import { supabase } from './supabase';
import { CreatorProfile } from '@/contexts/AppContext';
import { SubscriptionPlan, CreatorSubscription } from './subscriptionService';
import {
  isRlsDenied,
  isTableNotFound,
  isNonCriticalError,
  logRlsError,
  getRlsErrorMessage,
  queryPublicView,
  fetchPublicCreatorInfo,
} from './rlsErrorHandler';

export interface AdminUser {
  id: string;
  user_id: string;
  email: string;
  role: 'admin' | 'super_admin';
  created_at: string;
}

export interface SupportRequest {
  id: string;
  creator_id: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  admin_notes: string | null;
  resolved_by: string | null;
  resolved_at: string | null;
  created_at: string;
  updated_at: string;
  creator?: CreatorProfile;
}


export interface CreatorWithSubscription extends CreatorProfile {
  subscription?: CreatorSubscription;
  is_verified?: boolean;
}


export interface LiveStreamStats {
  total_streams: number;
  active_streams: number;
  total_viewers: number;
  avg_duration_minutes: number;
}

export interface PlatformStats {
  total_creators: number;
  active_subscriptions: number;
  pending_subscriptions: number;
  expired_subscriptions: number;
  total_revenue_monthly: number;
  total_revenue_yearly: number;
  open_support_requests: number;
  live_streams: LiveStreamStats;
}

export const adminService = {
  async isAdmin(): Promise<boolean> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      
      let finalUser = user;
      if (!finalUser) {
        try {
          const { data: { user: networkUser } } = await supabase.auth.getUser();
          finalUser = networkUser;
        } catch {
          // getUser failed silently
        }
      }
      
      if (!finalUser) return false;

      return true;
    } catch {
      return false;
    }
  },


  /**
   * Get admin user — RLS-restricted to admin-only read.
   * Returns null gracefully if RLS denies access.
   */
  async getAdminUser(): Promise<AdminUser | null> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      const { data, error } = await supabase
        .from('admin_users')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) {
        const code = error.code;
        if (isRlsDenied(error)) {
          logRlsError('adminService', 'getAdminUser', error);
          return null; // Not an admin — RLS correctly denies
        }
        if (code === '42703' || code === '42P17' || code === 'PGRST204') {
          console.warn('[adminService] admin_users query not available (code:', code, ') — skipping');
        }
        return null;
      }
      return data;
    } catch {
      return null;
    }
  },


  // ============================================================================
  // getAllCreators — Uses public_creators view for display info, with fallback
  // ============================================================================
  async getAllCreators(): Promise<CreatorWithSubscription[]> {
    try {
      // Use public view for creator display info, fallback to base table
      const { data: creators, error, source } = await queryPublicView(
        'public_creators',
        'creator_profiles',
        '*',
      );

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('adminService', 'getAllCreators', error);
          return [];
        }
        console.warn('[adminService] getAllCreators error:', error.message);
        return [];
      }

      if (!creators || creators.length === 0) return [];

      if (source !== 'none') {
        console.log(`[adminService] getAllCreators loaded from ${source}`);
      }

      // Fetch all subscriptions — admin-only or team member access
      let allSubscriptions: any[] = [];
      try {
        const { data: subs, error: subsErr } = await supabase
          .from('creator_subscriptions')
          .select('*');

        if (subsErr) {
          if (isRlsDenied(subsErr)) {
            logRlsError('adminService', 'getAllCreators/subscriptions', subsErr);
            // Continue without subscription data
          } else if (!isTableNotFound(subsErr)) {
            console.warn('[adminService] Could not fetch subscriptions:', subsErr.message);
          }
        } else {
          allSubscriptions = subs || [];
        }
      } catch {
        console.warn('[adminService] Could not fetch subscriptions');
      }

      // Fetch all plans
      let allPlans: any[] = [];
      try {
        const { data: plans, error: plansErr } = await supabase
          .from('subscription_plans_api')
          .select('*');
        
        if (plansErr || !plans) {
          const { data: plansFb } = await supabase
            .from('subscription_plans')
            .select('*');
          allPlans = plansFb || [];
        } else {
          allPlans = plans;
        }
      } catch {
        console.warn('[adminService] Could not fetch plans');
      }

      // Build maps
      const plansMap = new Map<string, any>();
      for (const plan of allPlans) {
        plansMap.set(plan.id, plan);
      }

      const subsMap = new Map<string, any>();
      for (const sub of allSubscriptions) {
        if (sub.plan_id && plansMap.has(sub.plan_id)) {
          sub.plan = plansMap.get(sub.plan_id);
        }
        subsMap.set(sub.creator_id, sub);
      }

      // Combine creators with their subscriptions
      const creatorsWithSubs: CreatorWithSubscription[] = [];
      for (const creator of creators) {
        creatorsWithSubs.push({
          ...creator,
          subscription: subsMap.get(creator.id) || undefined,
        });
      }

      return creatorsWithSubs;
    } catch (err: any) {
      console.warn('[adminService] getAllCreators exception:', err?.message);
      return [];
    }
  },

  async activateSubscription(
    subscriptionId: string,
    durationMonths: number = 1
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const startedAt = new Date();
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + durationMonths);

      const { error } = await supabase
        .from('creator_subscriptions')
        .update({
          status: 'active',
          started_at: startedAt.toISOString(),
          expires_at: expiresAt.toISOString(),
          payment_reference: `ADMIN_ACTIVATED_${Date.now()}`,
          updated_at: new Date().toISOString()
        })
        .eq('id', subscriptionId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'admin') };
        }
        throw error;
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async deactivateSubscription(
    subscriptionId: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('creator_subscriptions')
        .update({
          status: 'cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('id', subscriptionId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'admin') };
        }
        throw error;
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async createSubscriptionForCreator(
    creatorId: string,
    planId: string,
    billingCycle: 'monthly' | 'yearly',
    durationMonths: number
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const startedAt = new Date();
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + durationMonths);

      const subData = {
        plan_id: planId,
        billing_cycle: billingCycle,
        status: 'active',
        started_at: startedAt.toISOString(),
        expires_at: expiresAt.toISOString(),
        payment_reference: `ADMIN_CREATED_${Date.now()}`
      };

      const { data: existing } = await supabase
        .from('creator_subscriptions')
        .select('id')
        .eq('creator_id', creatorId)
        .maybeSingle();

      if (existing) {
        const { error } = await supabase
          .from('creator_subscriptions')
          .update({ ...subData, updated_at: new Date().toISOString() })
          .eq('creator_id', creatorId);
        if (error) {
          if (isRlsDenied(error)) {
            return { success: false, error: getRlsErrorMessage(error, 'admin') };
          }
          throw error;
        }
      } else {
        const { error } = await supabase
          .from('creator_subscriptions')
          .insert({ creator_id: creatorId, ...subData });
        if (error) {
          if (isRlsDenied(error)) {
            return { success: false, error: getRlsErrorMessage(error, 'admin') };
          }
          throw error;
        }
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },


  // ============================================================================
  // getAllPlans — try subscription_plans_api view first, fall back to subscription_plans
  // ============================================================================
  async getAllPlans(): Promise<SubscriptionPlan[]> {
    try {
      const { data, error } = await supabase
        .from('subscription_plans_api')
        .select('*')
        .order('price_monthly', { ascending: true });

      if (!error && data) return data;

      if (error) {
        if (isNonCriticalError(error)) {
          logRlsError('adminService', 'getAllPlans/view', error);
        }
      }

      // Fallback to base table
      console.warn('[adminService] subscription_plans_api not available, using subscription_plans');
      const { data: fbData, error: fbError } = await supabase
        .from('subscription_plans')
        .select('*')
        .order('price_monthly', { ascending: true });

      if (fbError) {
        if (isRlsDenied(fbError)) {
          logRlsError('adminService', 'getAllPlans/table', fbError);
          return [];
        }
        throw fbError;
      }
      return fbData || [];
    } catch {
      return [];
    }
  },

  async createPlan(plan: Omit<SubscriptionPlan, 'id'>): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('subscription_plans')
        .insert(plan);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'admin') };
        }
        throw error;
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async updatePlan(
    planId: string,
    updates: Partial<SubscriptionPlan>
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('subscription_plans')
        .update(updates)
        .eq('id', planId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'admin') };
        }
        throw error;
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async deletePlan(planId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('subscription_plans')
        .delete()
        .eq('id', planId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'admin') };
        }
        throw error;
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  /**
   * Get support requests — RLS-restricted to owner or team members.
   */
  async getSupportRequests(status?: string): Promise<SupportRequest[]> {
    try {
      let query = supabase
        .from('support_requests')
        .select(`
          *,
          creator:creator_profiles(*)
        `)
        .order('created_at', { ascending: false });

      if (status && status !== 'all') {
        query = query.eq('status', status);
      }

      const { data, error } = await query;
      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('adminService', 'getSupportRequests', error);
          return [];
        }
        console.warn('[adminService] getSupportRequests error:', error.message);
        // Fallback: query without join
        const { data: fbData, error: fbError } = await supabase
          .from('support_requests')
          .select('*')
          .order('created_at', { ascending: false });

        if (fbError && isRlsDenied(fbError)) {
          logRlsError('adminService', 'getSupportRequests/fallback', fbError);
          return [];
        }
        return (fbData || []) as SupportRequest[];
      }
      return data || [];
    } catch {
      return [];
    }
  },

  async updateSupportRequest(
    requestId: string,
    updates: Partial<SupportRequest>
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const updateData: any = {
        ...updates,
        updated_at: new Date().toISOString()
      };

      if (updates.status === 'resolved') {
        const admin = await this.getAdminUser();
        updateData.resolved_by = admin?.id;
        updateData.resolved_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('support_requests')
        .update(updateData)
        .eq('id', requestId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'admin') };
        }
        throw error;
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  // ============================================================================
  // getPlatformStats — with RLS-aware error handling
  // ============================================================================
  async getPlatformStats(): Promise<PlatformStats> {
    try {
      // Total creators (public read)
      const { count: totalCreators } = await supabase
        .from('creator_profiles')
        .select('*', { count: 'exact', head: true });

      // Subscriptions — RLS restricted
      let subscriptions: any[] = [];
      try {
        const { data: apiSubs, error: apiErr } = await supabase
          .from('creator_subscriptions_api')
          .select('status, billing_cycle, price_monthly, price_yearly, currency');

        if (!apiErr && apiSubs) {
          subscriptions = apiSubs;
        } else {
          if (apiErr && isRlsDenied(apiErr)) {
            logRlsError('adminService', 'getPlatformStats/subscriptions_api', apiErr);
          }

          // Fallback: query base table + plans separately
          const { data: baseSubs, error: baseSubsErr } = await supabase
            .from('creator_subscriptions')
            .select('status, billing_cycle, plan_id');

          if (baseSubsErr) {
            if (isRlsDenied(baseSubsErr)) {
              logRlsError('adminService', 'getPlatformStats/creator_subscriptions', baseSubsErr);
            }
          } else {
            const { data: plans } = await supabase
              .from('subscription_plans')
              .select('id, price_monthly, price_yearly');

            const plansMap = new Map<string, any>();
            for (const p of plans || []) {
              plansMap.set(p.id, p);
            }

            subscriptions = (baseSubs || []).map(sub => {
              const plan = plansMap.get(sub.plan_id);
              return {
                ...sub,
                price_monthly: plan?.price_monthly || 0,
                price_yearly: plan?.price_yearly || 0,
              };
            });
          }
        }
      } catch {
        console.warn('[adminService] Could not fetch subscriptions for stats');
      }

      let activeSubscriptions = 0;
      let pendingSubscriptions = 0;
      let expiredSubscriptions = 0;
      let totalRevenueMonthly = 0;
      let totalRevenueYearly = 0;

      for (const sub of subscriptions) {
        if (sub.status === 'active') {
          activeSubscriptions++;
          if (sub.billing_cycle === 'monthly') {
            totalRevenueMonthly += Number(sub.price_monthly) || 0;
          } else if (sub.billing_cycle === 'yearly') {
            totalRevenueYearly += Number(sub.price_yearly) || 0;
          }
        } else if (sub.status === 'pending') {
          pendingSubscriptions++;
        } else if (sub.status === 'expired') {
          expiredSubscriptions++;
        }
      }

      // Support requests — RLS restricted
      let openRequests = 0;
      try {
        const { count, error: supportErr } = await supabase
          .from('support_requests')
          .select('*', { count: 'exact', head: true })
          .in('status', ['open', 'in_progress']);

        if (supportErr) {
          if (isNonCriticalError(supportErr)) {
            logRlsError('adminService', 'getPlatformStats/support_requests', supportErr);
          }
        } else {
          openRequests = count || 0;
        }
      } catch {
        // Table might not exist
      }

      // Live streams (public read)
      let totalStreams = 0;
      let activeStreams = 0;
      let totalViewers = 0;
      let avgDurationMinutes = 0;

      try {
        const { data: streams, error: streamsErr } = await supabase
          .from('live_streams')
          .select('is_live, viewer_count, started_at, ended_at');

        if (streamsErr) {
          if (isNonCriticalError(streamsErr)) {
            logRlsError('adminService', 'getPlatformStats/live_streams', streamsErr);
          }
        } else {
          totalStreams = streams?.length || 0;
          let totalDuration = 0;
          let completedStreams = 0;

          for (const stream of streams || []) {
            if (stream.is_live === true) {
              activeStreams++;
              totalViewers += stream.viewer_count || 0;
            }
            if (stream.started_at && stream.ended_at) {
              completedStreams++;
              const duration = new Date(stream.ended_at).getTime() - new Date(stream.started_at).getTime();
              totalDuration += duration;
            }
          }

          avgDurationMinutes = completedStreams > 0 
            ? Math.round(totalDuration / completedStreams / 60000) 
            : 0;
        }
      } catch {
        // Table might not exist
      }

      return {
        total_creators: totalCreators || 0,
        active_subscriptions: activeSubscriptions,
        pending_subscriptions: pendingSubscriptions,
        expired_subscriptions: expiredSubscriptions,
        total_revenue_monthly: totalRevenueMonthly,
        total_revenue_yearly: totalRevenueYearly,
        open_support_requests: openRequests,
        live_streams: {
          total_streams: totalStreams,
          active_streams: activeStreams,
          total_viewers: totalViewers,
          avg_duration_minutes: avgDurationMinutes
        }
      };
    } catch {
      return {
        total_creators: 0,
        active_subscriptions: 0,
        pending_subscriptions: 0,
        expired_subscriptions: 0,
        total_revenue_monthly: 0,
        total_revenue_yearly: 0,
        open_support_requests: 0,
        live_streams: {
          total_streams: 0,
          active_streams: 0,
          total_viewers: 0,
          avg_duration_minutes: 0
        }
      };
    }
  },

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  },

  getPriorityColor(priority: string): string {
    const colors: Record<string, string> = {
      low: 'bg-gray-100 text-gray-700',
      normal: 'bg-blue-100 text-blue-700',
      high: 'bg-orange-100 text-orange-700',
      urgent: 'bg-red-100 text-red-700'
    };
    return colors[priority] || colors.normal;
  },

  getStatusColor(status: string): string {
    const colors: Record<string, string> = {
      open: 'bg-yellow-100 text-yellow-700',
      in_progress: 'bg-blue-100 text-blue-700',
      resolved: 'bg-green-100 text-green-700',
      closed: 'bg-gray-100 text-gray-700'
    };
    return colors[status] || colors.open;
  }
};
