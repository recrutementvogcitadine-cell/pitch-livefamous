import { supabase, isSupabaseConfigured } from './supabase';
import {
  isRlsDenied,
  isTableNotFound,
  isNonCriticalError,
  logRlsError,
  getRlsErrorMessage,
} from './rlsErrorHandler';


export interface DashboardStats {
  totalViews: number;
  totalLiveDuration: number;
  followersCount: number;
  totalRevenue: number;
  liveCount: number;
  averageViewers: number;
  totalMessages: number;
  peakViewers: number;
}

export interface LiveHistoryItem {
  id: string;
  title: string;
  started_at: string;
  ended_at: string | null;
  duration_seconds: number;
  viewer_count: number;
  peak_viewers: number;
  is_live: boolean;
  is_audio_only: boolean;
  chat_messages_count: number;
}

export interface DailyGrowthData {
  date: string;
  label: string;
  followers: number;
  views: number;
  revenue: number;
  lives: number;
}

export interface FollowerGrowthPoint {
  date: string;
  label: string;
  count: number;
  cumulative: number;
}

export interface RevenueDataPoint {
  date: string;
  label: string;
  amount: number;
  cumulative: number;
}

function emptyStats(): DashboardStats {
  return {
    totalViews: 0,
    totalLiveDuration: 0,
    followersCount: 0,
    totalRevenue: 0,
    liveCount: 0,
    averageViewers: 0,
    totalMessages: 0,
    peakViewers: 0,
  };
}

function generateDateRange(days: number): { date: Date; dateStr: string; label: string }[] {
  const result: { date: Date; dateStr: string; label: string }[] = [];
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    result.push({
      date,
      dateStr: date.toISOString().split('T')[0],
      label: date.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' }),
    });
  }
  return result;
}

function emptyGrowthData(): DailyGrowthData[] {
  return generateDateRange(30).map(d => ({
    date: d.dateStr,
    label: d.label,
    followers: 0,
    views: 0,
    revenue: 0,
    lives: 0,
  }));
}

function emptyFollowerGrowth(): FollowerGrowthPoint[] {
  return generateDateRange(30).map(d => ({
    date: d.dateStr,
    label: d.label,
    count: 0,
    cumulative: 0,
  }));
}

function emptyRevenueData(): RevenueDataPoint[] {
  return generateDateRange(30).map(d => ({
    date: d.dateStr,
    label: d.label,
    amount: 0,
    cumulative: 0,
  }));
}



// ============================================================================
// Dashboard Service
// ============================================================================
export const dashboardService = {
  /**
   * Get dashboard stats. THROWS on error so the caller can show error state.
   * Requires Supabase to be configured (production mode).
   */
  async getStats(creatorId: string): Promise<DashboardStats> {
    if (!isSupabaseConfigured) throw new Error('Base de données non configurée. Allez dans /setup pour configurer Supabase.');
    if (!creatorId) return emptyStats();

    // Fetch creator profile stats (public read — no RLS issue)
    const profileResult = await supabase
      .from('creator_profiles')
      .select('total_views, total_live_duration_seconds, followers_count, live_count, average_viewers')
      .eq('id', creatorId)
      .maybeSingle();

    if (profileResult.error) {
      const code = profileResult.error.code || '';
      if (code !== '42P01' && code !== 'PGRST116') {
        // If RLS denied on creator_profiles, log but don't throw
        if (isRlsDenied(profileResult.error)) {
          logRlsError('dashboardService', 'getStats/creator_profiles', profileResult.error);
        } else {
          throw new Error(`Statistiques: ${profileResult.error.message} (${code})`);
        }
      }
    }
    const profile = profileResult.data;

    // Fetch total revenue — RLS-restricted to owner only
    let totalRevenue = 0;
    try {
      const { data: payments, error } = await supabase
        .from('payments')
        .select('amount')
        .eq('creator_id', creatorId)
        .eq('status', 'completed');

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('dashboardService', 'getStats/payments', error, { creatorId });
          // Revenue stays 0 — user may not have access
        } else if (!isTableNotFound(error)) {
          console.warn('[dashboardService] payments query error:', error.message);
        }
      } else if (payments) {
        totalRevenue = payments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      }
    } catch {
      // payments table might not exist — non-critical
    }

    // Fetch streams for peak viewers and chat count — public read
    let totalMessages = 0;
    let peakViewers = 0;
    try {
      const { data: streams, error } = await supabase
        .from('live_streams')
        .select('id, peak_viewers')
        .eq('creator_id', creatorId);

      if (error) {
        if (isNonCriticalError(error)) {
          logRlsError('dashboardService', 'getStats/live_streams', error);
        }
      } else if (streams && streams.length > 0) {
        peakViewers = Math.max(...streams.map(s => s.peak_viewers || 0));

        // Batch chat count
        try {
          const streamIds = streams.map(s => s.id);
          const { count, error: chatError } = await supabase
            .from('live_chat_messages')
            .select('*', { count: 'exact', head: true })
            .in('stream_id', streamIds);

          if (chatError) {
            if (isNonCriticalError(chatError)) {
              logRlsError('dashboardService', 'getStats/chat_messages', chatError);
            }
          } else {
            totalMessages = count || 0;
          }
        } catch {
          // chat table might not exist
        }
      }
    } catch {
      // live_streams table might not exist
    }

    return {
      totalViews: profile?.total_views || 0,
      totalLiveDuration: profile?.total_live_duration_seconds || 0,
      followersCount: profile?.followers_count || 0,
      totalRevenue,
      liveCount: profile?.live_count || 0,
      averageViewers: profile?.average_viewers || 0,
      totalMessages,
      peakViewers,
    };
  },

  /**
   * Get live history. THROWS on real errors.
   */
  async getLiveHistory(creatorId: string): Promise<LiveHistoryItem[]> {
    if (!isSupabaseConfigured) throw new Error('Base de données non configurée.');
    if (!creatorId) return [];



    const { data: streams, error } = await supabase
      .from('live_streams')
      .select('id, title, started_at, ended_at, duration_seconds, viewer_count, peak_viewers, is_live, is_audio_only')
      .eq('creator_id', creatorId)
      .order('started_at', { ascending: false })
      .limit(50);

    if (error) {
      if (isTableNotFound(error)) return [];
      if (isRlsDenied(error)) {
        logRlsError('dashboardService', 'getLiveHistory', error, { creatorId });
        return [];
      }
      throw new Error(`Historique: ${error.message} (${error.code})`);
    }
    if (!streams || streams.length === 0) return [];

    // Fetch chat message counts in parallel
    const streamIds = streams.map(s => s.id);
    let chatCounts: Record<string, number> = {};
    
    try {
      const countPromises = streamIds.map(async (sid) => {
        try {
          const { count, error: countErr } = await supabase
            .from('live_chat_messages')
            .select('*', { count: 'exact', head: true })
            .eq('stream_id', sid);

          if (countErr && isNonCriticalError(countErr)) return { sid, count: 0 };
          return { sid, count: count || 0 };
        } catch {
          return { sid, count: 0 };
        }
      });
      
      const countResults = await Promise.allSettled(countPromises);
      countResults.forEach(r => {
        if (r.status === 'fulfilled') {
          chatCounts[r.value.sid] = r.value.count;
        }
      });
    } catch {
      // Chat table might not exist — all counts stay 0
    }

    const results: LiveHistoryItem[] = [];
    for (const stream of streams) {
      results.push({
        ...stream,
        chat_messages_count: chatCounts[stream.id] || 0,
      });
    }

    return results;
  },

  /**
   * Get growth data. THROWS on real errors.
   */
  async getGrowthData(creatorId: string): Promise<DailyGrowthData[]> {
    if (!isSupabaseConfigured) throw new Error('Base de données non configurée.');
    if (!creatorId) return emptyGrowthData();



    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const startDate = thirtyDaysAgo.toISOString();

    // Fire all 3 queries in parallel — each one is independent
    const [followsResult, streamsResult, paymentsResult] = await Promise.allSettled([
      supabase
        .from('follows')
        .select('created_at')
        .eq('creator_id', creatorId)
        .gte('created_at', startDate),
      supabase
        .from('live_streams')
        .select('started_at, peak_viewers, duration_seconds')
        .eq('creator_id', creatorId)
        .gte('started_at', startDate),
      supabase
        .from('payments')
        .select('amount, created_at')
        .eq('creator_id', creatorId)
        .eq('status', 'completed')
        .gte('created_at', startDate),
    ]);

    // Extract data, handling RLS denials gracefully
    const follows = followsResult.status === 'fulfilled' && !followsResult.value.error
      ? followsResult.value.data || []
      : (() => {
          if (followsResult.status === 'fulfilled' && followsResult.value.error) {
            if (isNonCriticalError(followsResult.value.error)) {
              logRlsError('dashboardService', 'getGrowthData/follows', followsResult.value.error);
            }
          }
          return [];
        })();

    const streams = streamsResult.status === 'fulfilled' && !streamsResult.value.error
      ? streamsResult.value.data || []
      : (() => {
          if (streamsResult.status === 'fulfilled' && streamsResult.value.error) {
            if (isNonCriticalError(streamsResult.value.error)) {
              logRlsError('dashboardService', 'getGrowthData/streams', streamsResult.value.error);
            }
          }
          return [];
        })();

    const payments = paymentsResult.status === 'fulfilled' && !paymentsResult.value.error
      ? paymentsResult.value.data || []
      : (() => {
          if (paymentsResult.status === 'fulfilled' && paymentsResult.value.error) {
            if (isNonCriticalError(paymentsResult.value.error)) {
              logRlsError('dashboardService', 'getGrowthData/payments', paymentsResult.value.error);
            }
          }
          return [];
        })();

    // Check if ALL three failed with non-RLS errors — that's a real error
    const allFailed = followsResult.status === 'rejected' && streamsResult.status === 'rejected' && paymentsResult.status === 'rejected';
    if (allFailed) {
      throw new Error('Impossible de charger les données de croissance');
    }

    // Build daily data
    const dateRange = generateDateRange(30);
    return dateRange.map(d => {
      const dayFollows = follows.filter((f: any) => f.created_at?.startsWith(d.dateStr)).length;
      const dayStreams = streams.filter((s: any) => s.started_at?.startsWith(d.dateStr));
      const dayViews = dayStreams.reduce((sum: number, s: any) => sum + (s.peak_viewers || 0), 0);
      const dayLives = dayStreams.length;
      const dayRevenue = payments
        .filter((p: any) => p.created_at?.startsWith(d.dateStr))
        .reduce((sum: number, p: any) => sum + Number(p.amount || 0), 0);

      return {
        date: d.dateStr,
        label: d.label,
        followers: dayFollows,
        views: dayViews,
        revenue: dayRevenue,
        lives: dayLives,
      };
    });
  },

  /**
   * Get follower growth. THROWS on real errors.
   */
  async getFollowerGrowth(creatorId: string): Promise<FollowerGrowthPoint[]> {
    if (!isSupabaseConfigured) throw new Error('Base de données non configurée.');
    if (!creatorId) return emptyFollowerGrowth();



    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const [prevResult, recentResult] = await Promise.allSettled([
      supabase
        .from('follows')
        .select('*', { count: 'exact', head: true })
        .eq('creator_id', creatorId)
        .lt('created_at', thirtyDaysAgo.toISOString()),
      supabase
        .from('follows')
        .select('created_at')
        .eq('creator_id', creatorId)
        .gte('created_at', thirtyDaysAgo.toISOString())
        .order('created_at', { ascending: true }),
    ]);

    // If both failed, throw only for non-RLS errors
    if (prevResult.status === 'rejected' && recentResult.status === 'rejected') {
      throw new Error('Impossible de charger les données de followers');
    }

    // Handle table-not-found or RLS denied gracefully
    const prevError = prevResult.status === 'fulfilled' ? prevResult.value.error : null;
    const recentError = recentResult.status === 'fulfilled' ? recentResult.value.error : null;

    if (prevError && isNonCriticalError(prevError)) {
      logRlsError('dashboardService', 'getFollowerGrowth/prev', prevError);
      return emptyFollowerGrowth();
    }
    if (recentError && isNonCriticalError(recentError)) {
      logRlsError('dashboardService', 'getFollowerGrowth/recent', recentError);
      return emptyFollowerGrowth();
    }

    const previousCount = prevResult.status === 'fulfilled' && !prevResult.value.error
      ? (prevResult.value.count || 0)
      : 0;
    const recentFollows = recentResult.status === 'fulfilled' && !recentResult.value.error
      ? (recentResult.value.data || [])
      : [];

    let cumulative = previousCount;
    const dateRange = generateDateRange(30);

    return dateRange.map(d => {
      const dayCount = recentFollows.filter((f: any) => f.created_at?.startsWith(d.dateStr)).length;
      cumulative += dayCount;
      return {
        date: d.dateStr,
        label: d.label,
        count: dayCount,
        cumulative,
      };
    });
  },

  /**
   * Get revenue data. THROWS on real errors.
   * Payments table is RLS-restricted to owner only.
   */
  async getRevenueData(creatorId: string): Promise<RevenueDataPoint[]> {
    if (!isSupabaseConfigured) throw new Error('Base de données non configurée.');
    if (!creatorId) return emptyRevenueData();



    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const { data: payments, error } = await supabase
      .from('payments')
      .select('amount, created_at')
      .eq('creator_id', creatorId)
      .eq('status', 'completed')
      .gte('created_at', thirtyDaysAgo.toISOString())
      .order('created_at', { ascending: true });

    if (error) {
      if (isTableNotFound(error)) return emptyRevenueData();
      if (isRlsDenied(error)) {
        logRlsError('dashboardService', 'getRevenueData', error, { creatorId });
        // Return empty — user doesn't have access to this creator's payments
        return emptyRevenueData();
      }
      throw new Error(`Revenus: ${error.message} (${error.code})`);
    }

    let cumulative = 0;
    const dateRange = generateDateRange(30);

    return dateRange.map(d => {
      const dayAmount = (payments || [])
        .filter((p: any) => p.created_at?.startsWith(d.dateStr))
        .reduce((sum: number, p: any) => sum + Number(p.amount || 0), 0);
      cumulative += dayAmount;
      return {
        date: d.dateStr,
        label: d.label,
        amount: dayAmount,
        cumulative,
      };
    });
  },

  // ============================================================================
  // Formatting utilities
  // ============================================================================

  formatDuration(seconds: number): string {
    if (!seconds || seconds < 0) return '0s';
    if (seconds < 60) return `${seconds}s`;
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  },

  formatDurationLong(seconds: number): string {
    if (!seconds || seconds < 0) return '0 min';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}min`;
    return `${minutes} min`;
  },

  formatNumber(num: number): string {
    if (num == null || isNaN(num)) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toLocaleString('fr-FR');
  },

  formatCurrency(amount: number): string {
    if (amount == null || isNaN(amount)) return '0 FCFA';
    return new Intl.NumberFormat('fr-FR', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount) + ' FCFA';
  },
};
