// Minimal notification service - not used in simplified app
export const notificationService = {
  async requestPermission(): Promise<boolean> {
    return false;
  },
};
