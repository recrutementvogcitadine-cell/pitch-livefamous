import { supabase } from './supabase';
import { activityLogService } from './activityLogService';
import {
  isRlsDenied,
  isNonCriticalError,
  isPolicyRecursionError,
  logRlsError,
  getRlsErrorMessage,
} from './rlsErrorHandler';

export interface TeamMember {
  id: string;
  user_id: string;
  email: string;
  display_name: string;
  role: 'owner' | 'admin' | 'moderator' | 'read_only';
  permissions: TeamPermissions;
  added_by: string | null;
  is_active: boolean;
  last_active_at: string | null;
  created_at: string;
  updated_at: string;
}



export interface TeamPermissions {
  view_dashboard: boolean;
  manage_streams: boolean;
  moderate_chat: boolean;
  manage_creators: boolean;
  manage_subscriptions: boolean;
  manage_team: boolean;
  view_payments: boolean;
  manage_verification: boolean;
}

export interface ModerationLog {
  id: string;
  moderator_id: string;
  moderator_name: string;
  action_type: string;
  target_type: string;
  target_id: string | null;
  details: Record<string, any>;
  stream_id: string | null;
  created_at: string;
}

export const DEFAULT_PERMISSIONS: Record<string, TeamPermissions> = {
  owner: {
    view_dashboard: true,
    manage_streams: true,
    moderate_chat: true,
    manage_creators: true,
    manage_subscriptions: true,
    manage_team: true,
    view_payments: true,
    manage_verification: true,
  },
  admin: {
    view_dashboard: true,
    manage_streams: true,
    moderate_chat: true,
    manage_creators: true,
    manage_subscriptions: true,
    manage_team: true,
    view_payments: true,
    manage_verification: true,
  },
  moderator: {
    view_dashboard: true,
    manage_streams: true,
    moderate_chat: true,
    manage_creators: false,
    manage_subscriptions: false,
    manage_team: false,
    view_payments: false,
    manage_verification: false,
  },
  read_only: {
    view_dashboard: true,
    manage_streams: false,
    moderate_chat: false,
    manage_creators: false,
    manage_subscriptions: false,
    manage_team: false,
    view_payments: false,
    manage_verification: false,
  },
};

export const PERMISSION_LABELS: Record<keyof TeamPermissions, string> = {
  view_dashboard: 'Voir le tableau de bord',
  manage_streams: 'Gérer les lives',
  moderate_chat: 'Modérer le chat',
  manage_creators: 'Gérer les créateurs',
  manage_subscriptions: 'Gérer les abonnements',
  manage_team: "Gérer l'équipe",
  view_payments: 'Voir les paiements',
  manage_verification: 'Gérer les vérifications',
};

export const ROLE_LABELS: Record<string, string> = {
  owner: 'Propriétaire',
  admin: 'Administrateur',
  moderator: 'Modérateur',
  read_only: 'Lecture seule',
};

export const ROLE_HIERARCHY: Record<string, number> = {
  owner: 100,
  admin: 80,
  moderator: 40,
  read_only: 10,
};

export const ACTION_TYPE_LABELS: Record<string, string> = {
  delete_message: 'Message supprimé',
  ban_user: 'Utilisateur banni',
  unban_user: 'Utilisateur débanni',
  end_stream: 'Live terminé',
  approve_verification: 'Vérification approuvée',
  reject_verification: 'Vérification rejetée',
  activate_subscription: 'Abonnement activé',
  deactivate_subscription: 'Abonnement désactivé',
  update_support: 'Support mis à jour',
  add_team_member: 'Membre ajouté',
  remove_team_member: 'Membre retiré',
  update_role: 'Rôle modifié',
  other: 'Autre action',
};

export const TARGET_TYPE_LABELS: Record<string, string> = {
  message: 'Message',
  user: 'Utilisateur',
  stream: 'Live',
  subscription: 'Abonnement',
  verification: 'Vérification',
  support_request: 'Demande support',
  team_member: "Membre d'équipe",
  other: 'Autre',
};

export function canManageRole(actorRole: string, targetRole: string): boolean {
  return (ROLE_HIERARCHY[actorRole] || 0) > (ROLE_HIERARCHY[targetRole] || 0);
}

export function isOwnerRole(role: string): boolean {
  return role === 'owner';
}

export const teamService = {
  /**
   * Get current team member — RLS-restricted to admin or own member.
   * Handles missing columns gracefully by using wildcard selects.
   */
  async getCurrentMember(): Promise<TeamMember | null> {

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        return null;
      }

      // 1. Check if user already exists in team_members (use * to avoid column errors)
      const { data: existingMember, error: memberError } = await supabase
        .from('team_members')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!memberError && existingMember) {
        return existingMember as TeamMember;
      }

      // Handle infinite recursion in RLS policy (42P17) — return virtual owner
      if (memberError && isPolicyRecursionError(memberError)) {
        console.warn('[teamService] Infinite recursion in team_members policy (42P17) — returning virtual owner. Run the migration SQL to fix this.');
        return {
          id: 'virtual-owner',
          user_id: user.id,
          email: user.email || 'owner@app.local',
          display_name: 'Propriétaire',
          role: 'owner',
          permissions: DEFAULT_PERMISSIONS.owner,
          added_by: null,
          is_active: true,
          last_active_at: null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
      }

      // Handle RLS denied — user is not a team member
      if (memberError && isRlsDenied(memberError)) {
        logRlsError('teamService', 'getCurrentMember', memberError);
        // Fall through to check admin_users
      }

      // Handle schema errors (missing columns/table) — don't try to insert
      if (memberError && (memberError.code === '42703' || memberError.code === '42P01' || memberError.code === 'PGRST204')) {
        console.warn('[teamService] team_members schema incomplete:', memberError.code, memberError.message);
        // Fall through to admin_users check
      }

      // 2. Check if ANY owner exists (use * to avoid column errors)
      const { data: owners, error: ownersError } = await supabase
        .from('team_members')
        .select('*')
        .eq('role', 'owner');

      // Handle infinite recursion on owner check too
      if (ownersError && isPolicyRecursionError(ownersError)) {
        console.warn('[teamService] Infinite recursion on owner check — returning virtual owner');
        return {
          id: 'virtual-owner',
          user_id: user.id,
          email: user.email || 'owner@app.local',
          display_name: 'Propriétaire',
          role: 'owner',
          permissions: DEFAULT_PERMISSIONS.owner,
          added_by: null,
          is_active: true,
          last_active_at: null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
      }

      // If the table/columns don't exist, skip the insert attempt
      if (ownersError && (ownersError.code === '42703' || ownersError.code === '42P01' || ownersError.code === 'PGRST204')) {
        console.warn('[teamService] team_members schema incomplete for owner check:', ownersError.code);
        // Fall through to admin_users
      } else {

        const hasOwner = owners && owners.length > 0;

        if (!hasOwner) {
          const ownerPermissions = DEFAULT_PERMISSIONS.owner;
          const userEmail = user.email || 'owner@app.local';

          // Try to insert — but handle schema errors gracefully
          // CRITICAL: Provide explicit id to prevent 23502 (null id) errors
          const { data: newOwner, error: insertError } = await supabase
            .from('team_members')
            .insert({
              id: crypto.randomUUID(),
              user_id: user.id,
              email: userEmail,
              display_name: 'Propriétaire',
              role: 'owner',
              permissions: ownerPermissions,
              is_active: true,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            })
            .select()
            .single();


          if (!insertError && newOwner) {
            return newOwner as TeamMember;
          }

          if (insertError) {
            // Schema error — columns missing, return virtual owner
            if (insertError.code === '42703' || insertError.code === 'PGRST204') {
              console.warn('[teamService] Cannot insert into team_members (schema incomplete):', insertError.message);
              return {
                id: 'virtual-owner',
                user_id: user.id,
                email: userEmail,
                display_name: 'Propriétaire',
                role: 'owner',
                permissions: DEFAULT_PERMISSIONS.owner,
                added_by: null,
                is_active: true,
                last_active_at: null,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
              };
            }

            if (isRlsDenied(insertError)) {
              logRlsError('teamService', 'getCurrentMember/insert', insertError);
            }

            // If duplicate (race condition), try to fetch the existing row
            if (insertError.code === '23505') {
              const { data: existingAfterConflict } = await supabase
                .from('team_members')
                .select('*')
                .eq('user_id', user.id)
                .maybeSingle();
              if (existingAfterConflict) {
                return existingAfterConflict as TeamMember;
              }
            }
          }

          // Ultimate fallback: return a virtual owner object
          return {
            id: 'virtual-owner',
            user_id: user.id,
            email: userEmail,
            display_name: 'Propriétaire',
            role: 'owner',
            permissions: DEFAULT_PERMISSIONS.owner,
            added_by: null,
            is_active: true,
            last_active_at: null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          };
        }
      }



      // 5. Fallback: check admin_users table for legacy compatibility
      try {
        const { data: adminData, error: adminErr } = await supabase
          .from('admin_users')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();

        if (adminErr) {
          const code = adminErr.code;
          if (isRlsDenied(adminErr)) {
            logRlsError('teamService', 'getCurrentMember/admin_users', adminErr);
          } else if (code === '42703' || code === '42P17' || code === 'PGRST204') {
            console.warn('[teamService] admin_users query not available (code:', code, ') — skipping');
          }
        } else if (adminData) {
          const adminRole = (adminData.role || '').toLowerCase();
          const mappedRole: 'owner' | 'admin' = adminRole === 'super_admin' ? 'owner' : 'admin';
          const mappedDisplayName = mappedRole === 'owner' ? 'Propriétaire' : 'Admin';

          return {
            id: adminData.id,
            user_id: adminData.user_id,
            email: adminData.email,
            display_name: mappedDisplayName,
            role: mappedRole,
            permissions: DEFAULT_PERMISSIONS[mappedRole],
            added_by: null,
            is_active: true,
            last_active_at: null,
            created_at: adminData.created_at,
            updated_at: adminData.created_at,
          };
        }
      } catch {
        // admin_users table may not exist or have different schema — non-critical
      }


      return null;
    } catch {
      return null;
    }
  },


  async hasPermission(permission: keyof TeamPermissions): Promise<boolean> {
    const member = await this.getCurrentMember();
    if (!member) return false;
    if (member.role === 'owner' || member.role === 'admin') return true;
    return member.permissions[permission] || false;
  },

  async getTeamMembers(): Promise<TeamMember[]> {
    try {
      const { data, error } = await supabase
        .from('team_members')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('teamService', 'getTeamMembers', error);
          return [];
        }
        throw error;
      }
      return (data || []) as TeamMember[];
    } catch {
      return [];
    }
  },

  async addTeamMember(
    email: string,
    displayName: string,
    role: 'admin' | 'moderator' | 'read_only',
    permissions?: Partial<TeamPermissions>
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      if (!currentUser) return { success: false, error: 'Non authentifié' };

      const caller = await this.getCurrentMember();
      if (!caller) return { success: false, error: 'Non autorisé' };
      
      if (role === 'admin' && caller.role !== 'owner') {
        return { success: false, error: 'Seul le propriétaire peut ajouter des administrateurs' };
      }
      
      if (caller.role !== 'owner' && caller.role !== 'admin' && !caller.permissions.manage_team) {
        return { success: false, error: "Vous n'avez pas la permission de gérer l'équipe" };
      }

      const finalPermissions = {
        ...DEFAULT_PERMISSIONS[role],
        ...(permissions || {}),
      };

      const { error: insertError } = await supabase
        .from('team_members')
        .insert({
          id: crypto.randomUUID(),
          user_id: currentUser.id,
          email,
          display_name: displayName,
          role,
          permissions: finalPermissions,
          is_active: true,
        });


      if (insertError) {
        if (isRlsDenied(insertError)) {
          return { success: false, error: getRlsErrorMessage(insertError, 'team') };
        }
        if (insertError.code === '23505') {
          return { success: false, error: 'Ce membre existe déjà dans l\'équipe' };
        }
        throw insertError;
      }

      await this.logAction('add_team_member', 'team_member', email, {
        role,
        display_name: displayName,
      });

      activityLogService.log({
        actionType: 'add_team_member',
        actionDescription: `Nouveau membre ajouté: ${displayName} (${email}) — Rôle: ${ROLE_LABELS[role] || role}`,
        targetType: 'team_member',
        targetId: email,
        targetLabel: displayName,
        metadata: { email, role, display_name: displayName },
      });

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async updateTeamMember(
    memberId: string,
    updates: {
      role?: 'owner' | 'admin' | 'moderator' | 'read_only';
      permissions?: Partial<TeamPermissions>;
      display_name?: string;
    }
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: targetMember, error: fetchErr } = await supabase
        .from('team_members')
        .select('*')
        .eq('id', memberId)
        .single();

      if (fetchErr) {
        if (isRlsDenied(fetchErr)) {
          return { success: false, error: getRlsErrorMessage(fetchErr, 'team') };
        }
      }

      if (!targetMember) return { success: false, error: 'Membre introuvable' };

      const caller = await this.getCurrentMember();
      if (!caller) return { success: false, error: 'Non autorisé' };

      if (targetMember.role === 'owner') {
        if (updates.role && updates.role !== 'owner') {
          return { success: false, error: 'Le rôle du propriétaire ne peut pas être modifié' };
        }
        if (caller.user_id !== targetMember.user_id) {
          return { success: false, error: 'Seul le propriétaire peut modifier son propre profil' };
        }
      }

      if (targetMember.role === 'admin' && caller.role !== 'owner') {
        return { success: false, error: 'Seul le propriétaire peut modifier les administrateurs' };
      }

      if (updates.role === 'owner') {
        return { success: false, error: 'Le rôle propriétaire ne peut pas être attribué' };
      }

      const updateData: any = { updated_at: new Date().toISOString() };

      if (updates.role) {
        updateData.role = updates.role;
        updateData.permissions = {
          ...DEFAULT_PERMISSIONS[updates.role],
          ...(updates.permissions || {}),
        };
      } else if (updates.permissions) {
        const { data: current } = await supabase
          .from('team_members')
          .select('permissions')
          .eq('id', memberId)
          .single();

        updateData.permissions = {
          ...(current?.permissions || {}),
          ...updates.permissions,
        };
      }

      if (updates.display_name) updateData.display_name = updates.display_name;

      const { error } = await supabase
        .from('team_members')
        .update(updateData)
        .eq('id', memberId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'team') };
        }
        throw error;
      }

      await this.logAction('update_role', 'team_member', memberId, {
        updates,
      });

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },


  async removeTeamMember(memberId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: targetMember, error: fetchErr } = await supabase
        .from('team_members')
        .select('role')
        .eq('id', memberId)
        .single();

      if (fetchErr && isRlsDenied(fetchErr)) {
        return { success: false, error: getRlsErrorMessage(fetchErr, 'team') };
      }

      if (targetMember?.role === 'owner') {
        return { success: false, error: 'Le propriétaire ne peut pas être retiré' };
      }

      const caller = await this.getCurrentMember();
      if (!caller) return { success: false, error: 'Non autorisé' };

      if (targetMember?.role === 'admin' && caller.role !== 'owner') {
        return { success: false, error: 'Seul le propriétaire peut retirer un administrateur' };
      }

      const { error } = await supabase
        .from('team_members')
        .delete()
        .eq('id', memberId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'team') };
        }
        throw error;
      }

      await this.logAction('remove_team_member', 'team_member', memberId, {});

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  /**
   * Log moderation action — RLS-restricted to admin/moderator insert.
   */
  async logAction(
    actionType: string,
    targetType: string,
    targetId: string | null,
    details: Record<string, any>,
    streamId?: string
  ): Promise<void> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const member = await this.getCurrentMember();
      const moderatorName = member?.display_name || user.email || 'Inconnu';

      const { error } = await supabase.from('moderation_logs').insert({
        moderator_id: user.id,
        moderator_name: moderatorName,
        action_type: actionType,
        target_type: targetType,
        target_id: targetId,
        details,
        stream_id: streamId || null,
      });

      if (error && isRlsDenied(error)) {
        logRlsError('teamService', 'logAction', error);
      }
    } catch {
      // Silent fail for logging
    }
  },

  async getModerationLogs(options?: {
    limit?: number;
    actionType?: string;
    moderatorId?: string;
    streamId?: string;
  }): Promise<ModerationLog[]> {
    try {
      let query = supabase
        .from('moderation_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(options?.limit || 100);

      if (options?.actionType && options.actionType !== 'all') {
        query = query.eq('action_type', options.actionType);
      }
      if (options?.moderatorId && options.moderatorId !== 'all') {
        query = query.eq('moderator_id', options.moderatorId);
      }
      if (options?.streamId) {
        query = query.eq('stream_id', options.streamId);
      }

      const { data, error } = await query;
      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('teamService', 'getModerationLogs', error);
          return [];
        }
        throw error;
      }
      return (data || []) as ModerationLog[];
    } catch {
      return [];
    }
  },

  async getLiveStreams(): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('live_streams')
        .select(`
          *,
          creator:creator_profiles(id, display_name, username, avatar_url, is_verified, user_id)
        `)
        .order('started_at', { ascending: false })
        .limit(50);

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('teamService', 'getLiveStreams', error);
          // Fallback without join
          const { data: streamsOnly } = await supabase
            .from('live_streams')
            .select('*')
            .order('started_at', { ascending: false })
            .limit(50);
          return streamsOnly || [];
        }
        throw error;
      }
      return data || [];
    } catch {
      return [];
    }
  },

  async endStream(streamId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('live_streams')
        .update({
          is_live: false,
          ended_at: new Date().toISOString(),
        })
        .eq('id', streamId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'moderation') };
        }
        throw error;
      }

      await this.logAction('end_stream', 'stream', streamId, {
        reason: 'Terminated by moderator',
      });

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },


  async getCreatorStatuses(): Promise<Array<{
    id: string;
    display_name: string;
    username: string;
    avatar_url: string | null;
    is_verified: boolean;
    is_online: boolean;
    current_stream_id: string | null;
    viewer_count: number;
    last_stream_at: string | null;
  }>> {
    try {
      // Use public read for creator profiles
      const { data: creators, error: creatorsError } = await supabase
        .from('creator_profiles')
        .select('id, display_name, username, avatar_url, is_verified, user_id')
        .order('display_name');

      if (creatorsError) {
        if (isNonCriticalError(creatorsError)) {
          logRlsError('teamService', 'getCreatorStatuses/creators', creatorsError);
          return [];
        }
        throw creatorsError;
      }

      const { data: activeStreams, error: streamsError } = await supabase
        .from('live_streams')
        .select('id, creator_id, viewer_count, started_at')
        .eq('is_live', true);

      if (streamsError) {
        if (isNonCriticalError(streamsError)) {
          logRlsError('teamService', 'getCreatorStatuses/streams', streamsError);
        }
      }

      const activeStreamMap = new Map<string, any>();
      for (const stream of activeStreams || []) {
        activeStreamMap.set(stream.creator_id, stream);
      }

      return (creators || []).map(creator => {
        const activeStream = activeStreamMap.get(creator.id);
        return {
          id: creator.id,
          display_name: creator.display_name,
          username: creator.username,
          avatar_url: creator.avatar_url,
          is_verified: creator.is_verified,
          is_online: !!activeStream,
          current_stream_id: activeStream?.id || null,
          viewer_count: activeStream?.viewer_count || 0,
          last_stream_at: activeStream?.started_at || null,
        };
      });
    } catch {
      return [];
    }
  },

  async updateActivity(): Promise<void> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('team_members')
        .update({ last_active_at: new Date().toISOString() })
        .eq('user_id', user.id);

      if (error && isRlsDenied(error)) {
        logRlsError('teamService', 'updateActivity', error);
      }
    } catch {
      // Silent fail
    }
  },

  async getSubscriptionHistory(): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('creator_subscriptions')
        .select(`
          *,
          creator:creator_profiles(id, display_name, username, avatar_url),
          plan:subscription_plans_api(name, price_monthly, price_yearly)
        `)
        .order('updated_at', { ascending: false })
        .limit(50);

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('teamService', 'getSubscriptionHistory', error);
          return [];
        }
        throw error;
      }
      return data || [];
    } catch {
      return [];
    }
  },
};
