/**
 * Hardcoded migration SQL for the Famous.ai platform.
 * This is embedded in the frontend so the setup flow never depends on the edge function.
 * The SQL is idempotent — safe to run multiple times.
 *
 * KEY FIXES (v5):
 * - Uses gen_random_uuid() instead of uuid_generate_v4() (built into PG 13+, no extension needed)
 * - Uses SECURITY DEFINER helper functions to prevent infinite recursion (42P17)
 * - Explicitly sets DEFAULT on id column to fix NOT NULL violations (23502)
 * - Adds `utilisateurs` table (required by AppContext for user sync)
 * - Adds `ensure_user_admin_setup` RPC (required by AppContext for admin setup)
 * - Adds `subscription_plans_api` view (used by subscriptionService)
 */
export const MIGRATION_SQL = `-- ============================================
-- Famous.ai Database Migration Script (v5 — utilisateurs + ensure_user_admin_setup)
-- Copy ALL of this and paste into:
-- Supabase Dashboard > SQL Editor > New Query > Run
-- ============================================

-- 1. Enable extensions (pgcrypto provides gen_random_uuid on older PG)
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- 1b. Create utilisateurs table (user profile sync from auth.users)
-- ============================================
CREATE TABLE IF NOT EXISTS public.utilisateurs (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_user_id  UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email         TEXT,
  display_name  TEXT,
  avatar_url    TEXT,
  phone         TEXT,
  role          TEXT NOT NULL DEFAULT 'user',
  is_active     BOOLEAN NOT NULL DEFAULT true,
  last_seen_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_utilisateurs_auth_user_id ON public.utilisateurs(auth_user_id);
ALTER TABLE public.utilisateurs ENABLE ROW LEVEL SECURITY;

-- RLS: users can read all, but only update their own row
DROP POLICY IF EXISTS "utilisateurs_select" ON public.utilisateurs;
CREATE POLICY "utilisateurs_select"
  ON public.utilisateurs FOR SELECT USING (true);

DROP POLICY IF EXISTS "utilisateurs_insert" ON public.utilisateurs;
CREATE POLICY "utilisateurs_insert"
  ON public.utilisateurs FOR INSERT WITH CHECK (auth.uid() = auth_user_id);

DROP POLICY IF EXISTS "utilisateurs_update" ON public.utilisateurs;
CREATE POLICY "utilisateurs_update"
  ON public.utilisateurs FOR UPDATE USING (auth.uid() = auth_user_id);

-- 2. Create team_members table (safe if already exists)
CREATE TABLE IF NOT EXISTS public.team_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL DEFAULT '',
  display_name TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'read_only' CHECK (role IN ('owner','admin','moderator','read_only')),
  permissions JSONB NOT NULL DEFAULT '{}',
  added_by UUID REFERENCES auth.users(id),
  is_active BOOLEAN NOT NULL DEFAULT true,
  last_active_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. CRITICAL FIX: Ensure id column has a DEFAULT even if table already existed
-- This fixes error 23502 (NOT NULL violation) when id has no default
ALTER TABLE public.team_members ALTER COLUMN id SET DEFAULT gen_random_uuid();

-- 3b. Fix any existing rows with null id
UPDATE public.team_members SET id = gen_random_uuid() WHERE id IS NULL;

-- 4. Add missing columns (safe to run even if they already exist)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='email') THEN
    ALTER TABLE public.team_members ADD COLUMN email TEXT NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='display_name') THEN
    ALTER TABLE public.team_members ADD COLUMN display_name TEXT NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='role') THEN
    ALTER TABLE public.team_members ADD COLUMN role TEXT NOT NULL DEFAULT 'read_only';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='permissions') THEN
    ALTER TABLE public.team_members ADD COLUMN permissions JSONB NOT NULL DEFAULT '{}'::jsonb;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='added_by') THEN
    ALTER TABLE public.team_members ADD COLUMN added_by UUID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='is_active') THEN
    ALTER TABLE public.team_members ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT true;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='last_active_at') THEN
    ALTER TABLE public.team_members ADD COLUMN last_active_at TIMESTAMPTZ;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='created_at') THEN
    ALTER TABLE public.team_members ADD COLUMN created_at TIMESTAMPTZ NOT NULL DEFAULT now();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='team_members' AND column_name='updated_at') THEN
    ALTER TABLE public.team_members ADD COLUMN updated_at TIMESTAMPTZ NOT NULL DEFAULT now();
  END IF;
END $$;

-- 5. Create index
CREATE INDEX IF NOT EXISTS idx_team_members_user_id ON public.team_members(user_id);

-- 6. Enable RLS
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

-- 7. Create admin_users table
CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'admin',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- 8. Create moderation_logs table
CREATE TABLE IF NOT EXISTS public.moderation_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  moderator_id UUID NOT NULL REFERENCES auth.users(id),
  moderator_name TEXT NOT NULL DEFAULT '',
  action_type TEXT NOT NULL,
  target_type TEXT NOT NULL DEFAULT 'other',
  target_id TEXT,
  details JSONB NOT NULL DEFAULT '{}',
  stream_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.moderation_logs ENABLE ROW LEVEL SECURITY;

-- ============================================
-- 9. SECURITY DEFINER helper functions
-- These bypass RLS and prevent infinite recursion (error 42P17)
-- ============================================

CREATE OR REPLACE FUNCTION public.is_team_member(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.team_members
    WHERE user_id = p_user_id AND is_active = true
  );
$$;

CREATE OR REPLACE FUNCTION public.is_team_admin(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.team_members
    WHERE user_id = p_user_id AND is_active = true AND role IN ('owner', 'admin')
  );
$$;

CREATE OR REPLACE FUNCTION public.is_team_moderator_or_above(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.team_members
    WHERE user_id = p_user_id AND is_active = true AND role IN ('owner', 'admin', 'moderator')
  );
$$;

CREATE OR REPLACE FUNCTION public.has_team_permission(p_user_id UUID, p_permission TEXT)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.team_members
    WHERE user_id = p_user_id AND is_active = true
    AND (role IN ('owner', 'admin') OR (permissions->>p_permission)::boolean = true)
  );
$$;

CREATE OR REPLACE FUNCTION public.team_owner_exists()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.team_members
    WHERE role = 'owner' AND is_active = true
  );
$$;

GRANT EXECUTE ON FUNCTION public.is_team_member(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_team_admin(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_team_moderator_or_above(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_team_permission(UUID, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.team_owner_exists() TO anon, authenticated;

-- ============================================
-- 10. DROP ALL old RLS policies (both old French names and new English names)
-- ============================================

DROP POLICY IF EXISTS "team_members_select" ON public.team_members;
DROP POLICY IF EXISTS "team_members_insert" ON public.team_members;
DROP POLICY IF EXISTS "team_members_update" ON public.team_members;
DROP POLICY IF EXISTS "team_members_delete" ON public.team_members;
DROP POLICY IF EXISTS "Les membres actifs voient l equipe" ON public.team_members;
DROP POLICY IF EXISTS "Insertion team members" ON public.team_members;
DROP POLICY IF EXISTS "Mise a jour team members" ON public.team_members;
DROP POLICY IF EXISTS "Suppression team members" ON public.team_members;
DROP POLICY IF EXISTS "team_members_select_policy" ON public.team_members;
DROP POLICY IF EXISTS "team_members_insert_policy" ON public.team_members;
DROP POLICY IF EXISTS "team_members_update_policy" ON public.team_members;
DROP POLICY IF EXISTS "team_members_delete_policy" ON public.team_members;

-- 11. Create NEW RLS policies using SECURITY DEFINER helper functions (NO recursion)

CREATE POLICY "team_members_select"
  ON public.team_members FOR SELECT
  USING (
    auth.uid() = user_id
    OR public.is_team_member(auth.uid())
  );

CREATE POLICY "team_members_insert"
  ON public.team_members FOR INSERT
  WITH CHECK (
    NOT public.team_owner_exists()
    OR public.is_team_admin(auth.uid())
  );

CREATE POLICY "team_members_update"
  ON public.team_members FOR UPDATE
  USING (
    public.is_team_admin(auth.uid())
  );

CREATE POLICY "team_members_delete"
  ON public.team_members FOR DELETE
  USING (
    public.is_team_admin(auth.uid())
  );

-- ============================================
-- 12. RLS Policies for admin_users
-- ============================================

DROP POLICY IF EXISTS "admin_users_select" ON public.admin_users;
DROP POLICY IF EXISTS "admin_users_insert" ON public.admin_users;
DROP POLICY IF EXISTS "admin_users_update" ON public.admin_users;

CREATE POLICY "admin_users_select"
  ON public.admin_users FOR SELECT
  USING (auth.uid() = user_id OR public.is_team_member(auth.uid()));

CREATE POLICY "admin_users_insert"
  ON public.admin_users FOR INSERT
  WITH CHECK (
    NOT EXISTS (SELECT 1 FROM public.admin_users)
    OR public.is_team_admin(auth.uid())
  );

CREATE POLICY "admin_users_update"
  ON public.admin_users FOR UPDATE
  USING (public.is_team_admin(auth.uid()));

-- ============================================
-- 13. RLS Policies for moderation_logs
-- ============================================

DROP POLICY IF EXISTS "moderation_logs_select" ON public.moderation_logs;
DROP POLICY IF EXISTS "moderation_logs_insert" ON public.moderation_logs;
DROP POLICY IF EXISTS "Les membres de l equipe voient les logs" ON public.moderation_logs;
DROP POLICY IF EXISTS "Les membres de l equipe peuvent creer des logs" ON public.moderation_logs;

CREATE POLICY "moderation_logs_select"
  ON public.moderation_logs FOR SELECT
  USING (public.is_team_member(auth.uid()));

CREATE POLICY "moderation_logs_insert"
  ON public.moderation_logs FOR INSERT
  WITH CHECK (public.is_team_member(auth.uid()));

-- ============================================
-- 14. check_owner_exists function
-- ============================================

CREATE OR REPLACE FUNCTION public.check_owner_exists()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  owner_record RECORD;
BEGIN
  SELECT user_id, email, display_name, role
  INTO owner_record
  FROM public.team_members
  WHERE role = 'owner' AND is_active = true
  LIMIT 1;
  
  IF owner_record IS NULL THEN
    RETURN jsonb_build_object('exists', false);
  ELSE
    RETURN jsonb_build_object(
      'exists', true,
      'owner_user_id', owner_record.user_id,
      'owner_email', owner_record.email,
      'owner_name', owner_record.display_name
    );
  END IF;
END;
$$;

-- ============================================
-- 15. setup_platform_owner function
-- CRITICAL: Uses gen_random_uuid() to avoid uuid_generate_v4 errors
-- ============================================

CREATE OR REPLACE FUNCTION public.setup_platform_owner(
  p_user_id UUID,
  p_email TEXT,
  p_display_name TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_owner RECORD;
  existing_member RECORD;
  new_team_id UUID;
  owner_permissions JSONB;
BEGIN
  owner_permissions := jsonb_build_object(
    'view_dashboard', true,
    'manage_streams', true,
    'moderate_chat', true,
    'manage_creators', true,
    'manage_subscriptions', true,
    'manage_team', true,
    'view_payments', true,
    'manage_verification', true
  );

  SELECT user_id, email, display_name
  INTO existing_owner
  FROM public.team_members
  WHERE role = 'owner' AND is_active = true
  LIMIT 1;

  IF existing_owner IS NOT NULL THEN
    IF existing_owner.user_id = p_user_id THEN
      RETURN jsonb_build_object('success', true, 'message', 'already_owner', 'already_owner', true);
    END IF;
    RETURN jsonb_build_object('success', false, 'message', 'owner_exists', 'owner_exists', true, 'owner_email', existing_owner.email);
  END IF;

  SELECT id INTO existing_member FROM public.team_members WHERE user_id = p_user_id LIMIT 1;

  IF existing_member IS NOT NULL THEN
    UPDATE public.team_members
    SET role = 'owner', email = COALESCE(p_email, ''), display_name = COALESCE(p_display_name, ''),
        permissions = owner_permissions, is_active = true, updated_at = now()
    WHERE user_id = p_user_id
    RETURNING id INTO new_team_id;
  ELSE
    -- CRITICAL: Uses gen_random_uuid() (built-in PG 13+) instead of uuid_generate_v4()
    INSERT INTO public.team_members (id, user_id, email, display_name, role, permissions, is_active, created_at, updated_at)
    VALUES (gen_random_uuid(), p_user_id, COALESCE(p_email, ''), COALESCE(p_display_name, ''), 'owner', owner_permissions, true, now(), now())
    RETURNING id INTO new_team_id;
  END IF;

  -- Also add to admin_users (non-critical)
  BEGIN
    INSERT INTO public.admin_users (id, user_id, email, role, created_at)
    VALUES (gen_random_uuid(), p_user_id, COALESCE(p_email, ''), 'super_admin', now())
    ON CONFLICT (user_id) DO UPDATE SET role = 'super_admin', email = COALESCE(p_email, '');
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END;

  RETURN jsonb_build_object('success', true, 'team_id', new_team_id, 'message', 'owner_created');
END;
$$;

-- ============================================
-- 15b. ensure_user_admin_setup function
-- ALIAS for setup_platform_owner — called by AppContext.tsx
-- ============================================

CREATE OR REPLACE FUNCTION public.ensure_user_admin_setup(
  p_user_id UUID,
  p_email TEXT,
  p_display_name TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delegate to setup_platform_owner
  RETURN public.setup_platform_owner(p_user_id, p_email, p_display_name);
END;
$$;

-- ============================================
-- 16. apply_migration_fixes function (self-repair helper)
-- ============================================

CREATE OR REPLACE FUNCTION public.apply_migration_fixes()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Fix id column default
  ALTER TABLE public.team_members ALTER COLUMN id SET DEFAULT gen_random_uuid();
  -- Fix null ids
  UPDATE public.team_members SET id = gen_random_uuid() WHERE id IS NULL;
  RETURN jsonb_build_object('success', true, 'message', 'fixes_applied');
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('success', false, 'error', SQLERRM);
END;
$$;

-- 17. Grant permissions
GRANT EXECUTE ON FUNCTION public.check_owner_exists() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.setup_platform_owner(UUID, TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.ensure_user_admin_setup(UUID, TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.apply_migration_fixes() TO anon, authenticated;

-- ============================================
-- 18. subscription_plans_api view (public read access)
-- ============================================
CREATE OR REPLACE VIEW public.subscription_plans_api AS
  SELECT id, name, description, price_monthly, price_yearly, features, is_active, created_at, updated_at
  FROM public.subscription_plans
  WHERE is_active = true;

-- Grant read access on the view
GRANT SELECT ON public.subscription_plans_api TO anon, authenticated;

-- Done!
SELECT 'Migration v5 completed — utilisateurs table + ensure_user_admin_setup + subscription_plans_api view!' AS result;`;

