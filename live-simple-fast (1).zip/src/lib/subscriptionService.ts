import { supabase } from './supabase';
import {
  isRlsDenied,
  isTableNotFound,
  isNonCriticalError,
  logRlsError,
  getRlsErrorMessage,
} from './rlsErrorHandler';

export interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price_monthly: number;
  price_yearly: number;
  features: string[];
  is_active: boolean;
}

export interface CreatorSubscription {
  id: string;
  creator_id: string;
  plan_id: string;
  billing_cycle: 'monthly' | 'yearly';
  status: 'pending' | 'active' | 'expired' | 'cancelled';
  started_at: string | null;
  expires_at: string | null;
  payment_reference: string | null;
  created_at: string;
  plan?: SubscriptionPlan;
}

// Helper: query plans from view first, fallback to base table
async function queryPlans(filter?: { column: string; value: any }): Promise<{ data: any[] | null; error: any }> {
  // Try view first (public read)
  let query = supabase.from('subscription_plans_api').select('*');
  if (filter) query = query.eq(filter.column, filter.value);
  const { data, error } = await query;

  if (!error && data) return { data, error: null };

  // If view doesn't exist or RLS blocks, fallback to base table
  if (error) {
    if (isNonCriticalError(error)) {
      logRlsError('subscriptionService', 'queryPlans/view', error);
    }
  }

  // Fallback to base table
  let fbQuery = supabase.from('subscription_plans').select('*');
  if (filter) fbQuery = fbQuery.eq(filter.column, filter.value);
  const fb = await fbQuery;

  if (fb.error && isNonCriticalError(fb.error)) {
    logRlsError('subscriptionService', 'queryPlans/table', fb.error);
  }

  return { data: fb.data, error: fb.error };
}

export const subscriptionService = {
  async getPlans(): Promise<SubscriptionPlan[]> {
    try {
      const { data, error } = await queryPlans({ column: 'is_active', value: true });
      if (error) {
        if (isRlsDenied(error)) {
          console.warn('[subscriptionService] RLS denied on plans — returning empty');
          return [];
        }
        console.warn('[subscriptionService] getPlans error:', error.message);
        return [];
      }
      return data || [];
    } catch {
      return [];
    }
  },

  /**
   * Get creator subscription — RLS-restricted to owner only.
   * Returns null gracefully if RLS denies access.
   */
  async getCreatorSubscription(creatorId: string): Promise<CreatorSubscription | null> {
    if (!creatorId) return null;

    try {
      const { data, error } = await supabase
        .from('creator_subscriptions')
        .select('*')
        .eq('creator_id', creatorId)
        .maybeSingle();

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('subscriptionService', 'getCreatorSubscription', error, { creatorId });
          return null; // User doesn't own this subscription
        }
        if (isTableNotFound(error)) return null;
        console.warn('[subscriptionService] getCreatorSubscription error:', error.message);
        return null;
      }

      if (data && data.plan_id) {
        try {
          const { data: plans } = await queryPlans({ column: 'id', value: data.plan_id });
          if (plans && plans.length > 0) {
            data.plan = plans[0];
          }
        } catch {
          // Plan fetch failed — not critical
        }
      }

      return data;
    } catch {
      return null;
    }
  },

  async hasActiveSubscription(creatorId: string): Promise<boolean> {
    if (!creatorId) return false;
    const subscription = await this.getCreatorSubscription(creatorId);
    
    if (!subscription) return false;
    if (subscription.status !== 'active') return false;
    
    if (subscription.expires_at) {
      const expiresAt = new Date(subscription.expires_at);
      if (expiresAt < new Date()) {
        try {
          const { error } = await supabase
            .from('creator_subscriptions')
            .update({ status: 'expired' })
            .eq('id', subscription.id);

          if (error && isRlsDenied(error)) {
            logRlsError('subscriptionService', 'hasActiveSubscription/expire', error);
          }
        } catch { /* ignore */ }
        return false;
      }
    }
    
    return true;
  },

  /**
   * Create subscription — RLS requires authenticated owner.
   */
  async createSubscription(
    creatorId: string,
    planId: string,
    billingCycle: 'monthly' | 'yearly'
  ): Promise<{ success: boolean; subscription?: CreatorSubscription; error?: string }> {
    try {
      const existing = await this.getCreatorSubscription(creatorId);
      
      if (existing && existing.status === 'active') {
        return { success: false, error: 'Vous avez déjà un abonnement actif' };
      }

      if (existing) {
        const { data, error } = await supabase
          .from('creator_subscriptions')
          .update({
            plan_id: planId,
            billing_cycle: billingCycle,
            status: 'pending',
            updated_at: new Date().toISOString()
          })
          .eq('id', existing.id)
          .select()
          .single();

        if (error) {
          if (isRlsDenied(error)) {
            return { success: false, error: getRlsErrorMessage(error, 'subscriptions') };
          }
          throw error;
        }
        return { success: true, subscription: data };
      }

      const { data, error } = await supabase
        .from('creator_subscriptions')
        .insert({
          creator_id: creatorId,
          plan_id: planId,
          billing_cycle: billingCycle,
          status: 'pending'
        })
        .select()
        .single();

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'subscriptions') };
        }
        throw error;
      }
      return { success: true, subscription: data };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async activateSubscription(
    subscriptionId: string,
    paymentReference: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: subscription, error: fetchError } = await supabase
        .from('creator_subscriptions')
        .select('billing_cycle')
        .eq('id', subscriptionId)
        .single();

      if (fetchError) {
        if (isRlsDenied(fetchError)) {
          return { success: false, error: getRlsErrorMessage(fetchError, 'subscriptions') };
        }
        throw fetchError;
      }

      const startedAt = new Date();
      let expiresAt = new Date();

      if (subscription.billing_cycle === 'monthly') {
        expiresAt.setMonth(expiresAt.getMonth() + 1);
      } else {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1);
      }

      const { error } = await supabase
        .from('creator_subscriptions')
        .update({
          status: 'active',
          started_at: startedAt.toISOString(),
          expires_at: expiresAt.toISOString(),
          payment_reference: paymentReference,
          updated_at: new Date().toISOString()
        })
        .eq('id', subscriptionId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'subscriptions') };
        }
        throw error;
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async cancelSubscription(subscriptionId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('creator_subscriptions')
        .update({
          status: 'cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('id', subscriptionId);

      if (error) {
        if (isRlsDenied(error)) {
          return { success: false, error: getRlsErrorMessage(error, 'subscriptions') };
        }
        throw error;
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  formatPrice(price: number): string {
    return new Intl.NumberFormat('fr-FR', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price) + ' FCFA';
  },

  getDaysRemaining(expiresAt: string | null): number {
    if (!expiresAt) return 0;
    const expires = new Date(expiresAt);
    const now = new Date();
    const diff = expires.getTime() - now.getTime();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  },

  getStatusLabel(status: string): string {
    const labels: Record<string, string> = {
      pending: 'En attente de paiement',
      active: 'Actif',
      expired: 'Expiré',
      cancelled: 'Annulé'
    };
    return labels[status] || status;
  },

  getStatusColor(status: string): string {
    const colors: Record<string, string> = {
      pending: 'text-yellow-500',
      active: 'text-green-500',
      expired: 'text-red-500',
      cancelled: 'text-gray-500'
    };
    return colors[status] || 'text-gray-500';
  }
};
