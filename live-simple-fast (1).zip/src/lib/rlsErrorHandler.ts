/**
 * rlsErrorHandler.ts
 * 
 * Centralized error handling for RLS-restricted Supabase queries.
 * Uses RPC functions (get_public_utilisateurs, get_public_creators,
 * get_public_user_by_ids, get_public_creator_by_ids) as secure
 * SECURITY DEFINER alternatives to public views.
 */

import { supabase } from './supabase';

// ============================================================================
// RLS Error Detection
// ============================================================================
const RLS_DENIED_CODES = new Set([
  '42501',     // PostgreSQL: insufficient_privilege
  'PGRST301',  // PostgREST: JWT expired or RLS denied
  'PGRST204',  // PostgREST: Column/relation not accessible
]);

const TABLE_NOT_FOUND_CODES = new Set([
  '42P01',     // PostgreSQL: undefined_table
  'PGRST116',  // PostgREST: no rows found (single)
]);

const POLICY_RECURSION_CODES = new Set([
  '42P17',     // PostgreSQL: infinite recursion detected in policy
]);

export interface SupabaseError {
  message: string;
  code?: string;
  details?: string;
  hint?: string;
  status?: number;
  statusCode?: number;
}

export function isRlsDenied(error: SupabaseError | null | undefined): boolean {
  if (!error) return false;
  if (error.code && RLS_DENIED_CODES.has(error.code)) return true;
  // Also treat infinite recursion as an RLS-related error (broken policy)
  if (error.code && POLICY_RECURSION_CODES.has(error.code)) return true;
  const status = error.status || error.statusCode || 0;
  if (status === 403) return true;
  const msg = (error.message || '').toLowerCase();
  return (
    msg.includes('permission denied') ||
    msg.includes('insufficient_privilege') ||
    msg.includes('new row violates row-level security') ||
    msg.includes('row-level security') ||
    msg.includes('infinite recursion') ||
    msg.includes('recursion detected') ||
    msg.includes('rls') ||
    msg.includes('policy')
  );
}

/** Detect if the error is specifically an infinite recursion in RLS policy (42P17) */
export function isPolicyRecursionError(error: SupabaseError | null | undefined): boolean {
  if (!error) return false;
  if (error.code && POLICY_RECURSION_CODES.has(error.code)) return true;
  const msg = (error.message || '').toLowerCase();
  return msg.includes('infinite recursion') || msg.includes('recursion detected');
}


export function isTableNotFound(error: SupabaseError | null | undefined): boolean {
  if (!error) return false;
  if (error.code && TABLE_NOT_FOUND_CODES.has(error.code)) return true;
  const msg = (error.message || '').toLowerCase();
  return (
    msg.includes('does not exist') ||
    (msg.includes('relation') && msg.includes('not')) ||
    msg.includes('not found')
  );
}

export function isNonCriticalError(error: SupabaseError | null | undefined): boolean {
  return isRlsDenied(error) || isTableNotFound(error);
}

// ============================================================================
// Error Logging
// ============================================================================

export function logRlsError(
  service: string,
  operation: string,
  error: SupabaseError,
  context?: Record<string, any>
): void {
  const isRls = isRlsDenied(error);
  const prefix = isRls ? 'RLS denied' : 'Query error';
  console.warn(
    `[${service}] ${prefix} on ${operation}: ${error.message} (code: ${error.code || 'unknown'})`,
    context ? context : ''
  );
}

// ============================================================================
// User-Friendly Error Messages
// ============================================================================

const RLS_ERROR_MESSAGES: Record<string, string> = {
  payments: 'Vous ne pouvez consulter que vos propres paiements.',
  notifications: 'Vous ne pouvez consulter que vos propres notifications.',
  subscriptions: 'Vous ne pouvez consulter que vos propres abonnements.',
  admin: 'Accès réservé aux administrateurs.',
  team: 'Accès réservé aux membres de l\'équipe.',
  support: 'Vous ne pouvez consulter que vos propres demandes de support.',
  verification: 'Vous ne pouvez consulter que vos propres demandes de vérification.',
  moderation: 'Accès réservé aux modérateurs.',
  chat_bans: 'Accès réservé aux modérateurs.',
  activity_logs: 'Accès réservé aux administrateurs.',
  default: 'Vous n\'avez pas les permissions nécessaires pour accéder à ces données.',
};

export function getRlsErrorMessage(error: SupabaseError, context?: string): string {
  if (!isRlsDenied(error)) {
    return error.message || 'Une erreur est survenue.';
  }
  if (context && RLS_ERROR_MESSAGES[context]) {
    return RLS_ERROR_MESSAGES[context];
  }
  return RLS_ERROR_MESSAGES.default;
}

// ============================================================================
// Safe Query Wrapper
// ============================================================================

export interface SafeQueryResult<T> {
  data: T | null;
  error: SupabaseError | null;
  isRlsDenied: boolean;
  isTableMissing: boolean;
}

export function handleQueryResult<T>(
  result: { data: T | null; error: any },
  service: string,
  operation: string
): SafeQueryResult<T> {
  const { data, error } = result;
  if (!error) {
    return { data, error: null, isRlsDenied: false, isTableMissing: false };
  }
  const rlsDenied = isRlsDenied(error);
  const tableMissing = isTableNotFound(error);
  if (rlsDenied || tableMissing) {
    logRlsError(service, operation, error);
  }
  return { data: null, error, isRlsDenied: rlsDenied, isTableMissing: tableMissing };
}

// ============================================================================
// Public View Query via RPC Functions
// ============================================================================

/**
 * Query a public view via RPC function first, then fall back to the base table.
 * Maps known view names to their corresponding RPC functions.
 */
export async function queryPublicView<T = any>(
  viewName: string,
  tableName: string,
  selectCols: string,
  filters?: Array<{ column: string; operator: string; value: any }>
): Promise<{ data: T[] | null; error: any; source: 'rpc' | 'table' | 'none' }> {

  // Map view names to RPC function names
  const rpcMap: Record<string, string> = {
    'public_utilisateurs': 'get_public_utilisateurs',
    'public_creators': 'get_public_creators',
  };

  // Column name mapping: RPC output columns have out_ prefix
  const outPrefixMap: Record<string, Record<string, string>> = {
    'get_public_utilisateurs': {
      'out_auth_user_id': 'auth_user_id',
      'out_display_name': 'display_name',
      'out_avatar_url': 'avatar_url',
    },
    'get_public_creators': {
      'out_id': 'id',
      'out_username': 'username',
      'out_display_name': 'display_name',
      'out_avatar_url': 'avatar_url',
      'out_is_verified': 'is_verified',
      'out_followers_count': 'followers_count',
    },
  };

  const rpcName = rpcMap[viewName];

  // Try RPC function first
  if (rpcName) {
    try {
      const { data, error } = await supabase.rpc(rpcName);

      if (!error && data) {
        // Remap out_ prefixed columns to clean names
        const colMap = outPrefixMap[rpcName] || {};
        let rows = (data as any[]).map((row: any) => {
          const clean: any = {};
          for (const [key, val] of Object.entries(row)) {
            clean[colMap[key] || key] = val;
          }
          return clean;
        });

        // Apply client-side filters (RPC returns all rows)
        if (filters) {
          for (const f of filters) {
            if (f.operator === 'eq') {
              rows = rows.filter(r => r[f.column] === f.value);
            } else if (f.operator === 'in' && Array.isArray(f.value)) {
              const valSet = new Set(f.value);
              rows = rows.filter(r => valSet.has(r[f.column]));
            } else if (f.operator === 'neq') {
              rows = rows.filter(r => r[f.column] !== f.value);
            }
          }
        }

        return { data: rows as T[], error: null, source: 'rpc' };
      }

      if (error) {
        console.warn(`[queryPublicView] RPC "${rpcName}" error: ${error.message}, trying fallback table "${tableName}"`);
      }
    } catch (err: any) {
      console.warn(`[queryPublicView] RPC "${rpcName}" exception: ${err?.message}`);
    }
  }

  // Fallback to base table
  try {
    let query = supabase.from(tableName).select(selectCols);
    if (filters) {
      for (const f of filters) {
        if (f.operator === 'eq') query = query.eq(f.column, f.value);
        else if (f.operator === 'in') query = query.in(f.column, f.value);
        else if (f.operator === 'neq') query = query.neq(f.column, f.value);
      }
    }
    const { data, error } = await query;

    if (!error && data) {
      return { data: data as T[], error: null, source: 'table' };
    }

    if (error) {
      logRlsError('queryPublicView', `${viewName}/${tableName}`, error);
      return { data: null, error, source: 'none' };
    }
  } catch (err: any) {
    console.warn(`[queryPublicView] Table "${tableName}" exception: ${err?.message}`);
  }

  return { data: null, error: { message: 'Both RPC and table queries failed', code: 'QUERY_FAILED' }, source: 'none' };
}

// ============================================================================
// Public User Info (via RPC: get_public_user_by_ids)
// ============================================================================

/**
 * Fetch public user display info using the SECURITY DEFINER RPC function.
 * Falls back to direct table query if RPC is unavailable.
 */
export async function fetchPublicUserInfo(
  userIds: string[]
): Promise<Map<string, { id: string; display_name: string | null; avatar_url: string | null }>> {
  const map = new Map<string, { id: string; display_name: string | null; avatar_url: string | null }>();
  if (!userIds || userIds.length === 0) return map;

  const uniqueIds = [...new Set(userIds)];

  // Try RPC batch lookup first
  try {
    const { data, error } = await supabase.rpc('get_public_user_by_ids', { user_ids: uniqueIds });

    if (!error && data) {
      for (const row of data as any[]) {
        const uid = row.out_auth_user_id || row.auth_user_id;
        map.set(uid, {
          id: uid,
          display_name: row.out_display_name || row.display_name || null,
          avatar_url: row.out_avatar_url || row.avatar_url || null,
        });
      }
      return map;
    }

    if (error) {
      console.warn(`[fetchPublicUserInfo] RPC error: ${error.message}, falling back to table`);
    }
  } catch (err: any) {
    console.warn(`[fetchPublicUserInfo] RPC exception: ${err?.message}`);
  }

  // Fallback: direct table query (works if utilisateurs has public read policy)
  try {
    const { data, error } = await supabase
      .from('utilisateurs')
      .select('auth_user_id, display_name, avatar_url')
      .in('auth_user_id', uniqueIds);

    if (!error && data) {
      for (const row of data as any[]) {
        map.set(row.auth_user_id, {
          id: row.auth_user_id,
          display_name: row.display_name || null,
          avatar_url: row.avatar_url || null,
        });
      }
    }
  } catch {
    // Silent fallback — map will be empty
  }

  return map;
}

// ============================================================================
// Public Creator Info (via RPC: get_public_creator_by_ids)
// ============================================================================

/**
 * Fetch public creator display info using the SECURITY DEFINER RPC function.
 * Falls back to direct table query if RPC is unavailable.
 */
export async function fetchPublicCreatorInfo(
  creatorIds: string[]
): Promise<Map<string, {
  id: string;
  username: string;
  display_name: string;
  avatar_url: string | null;
  is_verified: boolean;
  followers_count: number;
}>> {
  const map = new Map();
  if (!creatorIds || creatorIds.length === 0) return map;

  const uniqueIds = [...new Set(creatorIds)];

  // Try RPC batch lookup first
  try {
    const { data, error } = await supabase.rpc('get_public_creator_by_ids', { creator_ids: uniqueIds });

    if (!error && data) {
      for (const row of data as any[]) {
        const cid = row.out_id || row.id;
        map.set(cid, {
          id: cid,
          username: row.out_username || row.username || '',
          display_name: row.out_display_name || row.display_name || '',
          avatar_url: row.out_avatar_url || row.avatar_url || null,
          is_verified: row.out_is_verified ?? row.is_verified ?? false,
          followers_count: row.out_followers_count ?? row.followers_count ?? 0,
        });
      }
      return map;
    }

    if (error) {
      console.warn(`[fetchPublicCreatorInfo] RPC error: ${error.message}, falling back to table`);
    }
  } catch (err: any) {
    console.warn(`[fetchPublicCreatorInfo] RPC exception: ${err?.message}`);
  }

  // Fallback: direct table query (creator_profiles has public read)
  try {
    const { data, error } = await supabase
      .from('creator_profiles')
      .select('id, username, display_name, avatar_url, is_verified, followers_count')
      .in('id', uniqueIds);

    if (!error && data) {
      for (const row of data as any[]) {
        map.set(row.id, {
          id: row.id,
          username: row.username || '',
          display_name: row.display_name || '',
          avatar_url: row.avatar_url || null,
          is_verified: row.is_verified || false,
          followers_count: row.followers_count || 0,
        });
      }
    }
  } catch {
    // Silent fallback
  }

  return map;
}
