import { supabase } from './supabase';
import {
  isRlsDenied,
  isNonCriticalError,
  logRlsError,
  queryPublicView,
} from './rlsErrorHandler';

export interface Stream {
  id: string;
  title: string;
  creator_id: string;
  creator_name?: string;
  creator_avatar?: string;
  viewer_count: number;
  peak_viewers: number;
  thumbnail_url?: string;
  is_live: boolean;
  is_audio_only: boolean;
  started_at: string;
  ended_at?: string;
  recording_enabled: boolean;
  recording_url?: string;
  recording_status: string;
  duration_seconds: number;
}

export interface StreamWithCreator extends Stream {
  creator_profiles?: {
    id: string;
    username: string;
    display_name: string;
    avatar_url: string | null;
    is_verified: boolean;
    followers_count: number;
  };
}

// Helper: safely extract error message from any thrown value
function extractErrorMessage(err: any): string {
  if (!err) return 'Erreur inconnue';
  if (typeof err === 'string') return err;
  if (typeof err.message === 'string') return err.message;
  if (typeof err.error === 'string') return err.error;
  if (typeof err.msg === 'string') return err.msg;
  try { return JSON.stringify(err); } catch { return 'Erreur serveur'; }
}

export const streamService = {
  /**
   * Start a new live stream using direct DB insert.
   */
  async startStream(
    creatorId: string,
    title: string,
    isAudioOnly: boolean = false
  ): Promise<{ success: boolean; stream?: Stream; error?: string }> {
    try {
      // First, end any existing live streams for this creator
      await supabase
        .from('live_streams')
        .update({
          is_live: false,
          ended_at: new Date().toISOString(),
        })
        .eq('creator_id', creatorId)
        .eq('is_live', true);

      // Create new stream
      const { data, error } = await supabase
        .from('live_streams')
        .insert({
          creator_id: creatorId,
          title: title.trim() || 'Live sans titre',
          is_live: true,
          is_audio_only: isAudioOnly,
          viewer_count: 0,
          peak_viewers: 0,
          started_at: new Date().toISOString(),
          recording_enabled: true,
          recording_status: 'none',
          duration_seconds: 0,
        })
        .select()
        .single();

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('streamService', 'startStream', error, { creatorId });
          return { success: false, error: 'Vous n\'avez pas la permission de créer un live.' };
        }
        console.error('[streamService] Error creating stream:', error);
        return { success: false, error: `Erreur lors de la création du live : ${error.message}` };
      }

      if (!data) {
        return { success: false, error: 'Aucune donnée retournée lors de la création du live.' };
      }

      return { success: true, stream: data as Stream };
    } catch (err: any) {
      console.error('[streamService] Exception starting stream:', err);
      return { success: false, error: extractErrorMessage(err) };
    }
  },

  /**
   * End a live stream using direct DB update.
   */
  async endStream(streamId: string): Promise<{ success: boolean; error?: string }> {
    try {
      // Get stream info to calculate duration
      const { data: streamData, error: fetchErr } = await supabase
        .from('live_streams')
        .select('started_at, viewer_count, peak_viewers')
        .eq('id', streamId)
        .single();

      if (fetchErr && isRlsDenied(fetchErr)) {
        logRlsError('streamService', 'endStream/fetch', fetchErr);
        return { success: false, error: 'Vous n\'avez pas la permission de terminer ce live.' };
      }

      let durationSeconds = 0;
      if (streamData?.started_at) {
        durationSeconds = Math.floor(
          (Date.now() - new Date(streamData.started_at).getTime()) / 1000
        );
      }

      const { error } = await supabase
        .from('live_streams')
        .update({
          is_live: false,
          ended_at: new Date().toISOString(),
          duration_seconds: durationSeconds,
        })
        .eq('id', streamId);

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('streamService', 'endStream/update', error);
          return { success: false, error: 'Vous n\'avez pas la permission de terminer ce live.' };
        }
        console.error('[streamService] Error ending stream:', error);
        return { success: false, error: `Erreur lors de la fin du live : ${error.message}` };
      }

      return { success: true };
    } catch (err: any) {
      console.error('[streamService] Exception ending stream:', err);
      return { success: false, error: extractErrorMessage(err) };
    }
  },

  /**
   * Join a stream (increment viewer count).
   * Uses public_creators view for creator info when available.
   */
  async joinStream(streamId: string): Promise<{ success: boolean; stream?: StreamWithCreator; error?: string }> {
    try {
      // Get stream with creator info — try join first, fallback to separate queries
      const { data, error } = await supabase
        .from('live_streams')
        .select(`
          *,
          creator_profiles (
            id, username, display_name, avatar_url, is_verified, followers_count
          )
        `)
        .eq('id', streamId)
        .single();

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('streamService', 'joinStream', error, { streamId });
          return { success: false, error: 'Ce live n\'est pas accessible.' };
        }
        return { success: false, error: error.message };
      }

      if (!data) {
        return { success: false, error: 'Stream introuvable.' };
      }

      // Increment viewer count
      const newViewerCount = (data.viewer_count || 0) + 1;
      const newPeakViewers = Math.max(data.peak_viewers || 0, newViewerCount);

      await supabase
        .from('live_streams')
        .update({
          viewer_count: newViewerCount,
          peak_viewers: newPeakViewers,
        })
        .eq('id', streamId);

      return { success: true, stream: { ...data, viewer_count: newViewerCount } as StreamWithCreator };
    } catch (err: any) {
      return { success: false, error: extractErrorMessage(err) };
    }
  },

  /**
   * Leave a stream (decrement viewer count).
   */
  async leaveStream(streamId: string): Promise<void> {
    try {
      const { data } = await supabase
        .from('live_streams')
        .select('viewer_count')
        .eq('id', streamId)
        .single();

      if (data) {
        const newCount = Math.max(0, (data.viewer_count || 1) - 1);
        await supabase
          .from('live_streams')
          .update({ viewer_count: newCount })
          .eq('id', streamId);
      }
    } catch {
      // Silently fail — not critical
    }
  },

  /**
   * Get all live streams — public read.
   * Uses public_creators view for creator display info when available.
   */
  async getLiveStreams(): Promise<{ success: boolean; streams: StreamWithCreator[]; error?: string }> {
    try {
      // Try standard join first (creator_profiles has public read)
      const { data, error } = await supabase
        .from('live_streams')
        .select(`
          *,
          creator_profiles (
            id, username, display_name, avatar_url, is_verified, followers_count
          )
        `)
        .eq('is_live', true)
        .order('viewer_count', { ascending: false });

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('streamService', 'getLiveStreams', error);
          // Fallback: try without join
          const { data: streamsOnly, error: streamsErr } = await supabase
            .from('live_streams')
            .select('*')
            .eq('is_live', true)
            .order('viewer_count', { ascending: false });

          if (streamsErr) {
            return { success: false, streams: [], error: streamsErr.message };
          }

          return { success: true, streams: (streamsOnly || []) as StreamWithCreator[] };
        }
        return { success: false, streams: [], error: error.message };
      }

      return { success: true, streams: (data || []) as StreamWithCreator[] };
    } catch (err: any) {
      return { success: false, streams: [], error: extractErrorMessage(err) };
    }
  },

  /**
   * Get replays (ended streams with recordings) — public read.
   */
  async getReplays(limit: number = 20): Promise<{ success: boolean; streams: StreamWithCreator[]; error?: string }> {
    try {
      const { data, error } = await supabase
        .from('live_streams')
        .select(`
          *,
          creator_profiles (
            id, username, display_name, avatar_url, is_verified, followers_count
          )
        `)
        .eq('is_live', false)
        .in('recording_status', ['completed', 'uploading', 'processing'])
        .order('ended_at', { ascending: false })
        .limit(limit);

      if (error) {
        if (isRlsDenied(error)) {
          logRlsError('streamService', 'getReplays', error);
          // Fallback: try without join
          const { data: streamsOnly } = await supabase
            .from('live_streams')
            .select('*')
            .eq('is_live', false)
            .in('recording_status', ['completed', 'uploading', 'processing'])
            .order('ended_at', { ascending: false })
            .limit(limit);

          return { success: true, streams: (streamsOnly || []) as StreamWithCreator[] };
        }
        return { success: false, streams: [], error: error.message };
      }

      return { success: true, streams: (data || []) as StreamWithCreator[] };
    } catch (err: any) {
      return { success: false, streams: [], error: extractErrorMessage(err) };
    }
  },

  /**
   * Subscribe to live stream changes in real-time.
   */
  subscribeToLiveStreams(
    onStreamStarted: (stream: Stream) => void,
    onStreamEnded: (streamId: string) => void,
    onStreamUpdated: (stream: Stream) => void
  ): () => void {
    const channel = supabase
      .channel('live-streams-global')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'live_streams',
        },
        (payload) => {
          const stream = payload.new as Stream;
          if (stream.is_live) {
            onStreamStarted(stream);
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'live_streams',
        },
        (payload) => {
          const stream = payload.new as Stream;
          const oldStream = payload.old as Partial<Stream>;

          if (oldStream.is_live === true && stream.is_live === false) {
            onStreamEnded(stream.id);
          } else {
            onStreamUpdated(stream);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};
