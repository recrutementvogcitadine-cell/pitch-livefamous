import { useState, useRef, useCallback } from 'react';

export interface RecordingState {
  isRecording: boolean;
  isPaused: boolean;
  duration: number;
  error: string | null;
  blob: Blob | null;
  mimeType: string;
}

interface UseMediaRecorderOptions {
  timeslice?: number; // ms between ondataavailable events
  videoBitsPerSecond?: number;
  audioBitsPerSecond?: number;
  onDataAvailable?: (chunk: Blob) => void;
  onStop?: (blob: Blob) => void;
  onError?: (error: string) => void;
}

export function useMediaRecorder(options: UseMediaRecorderOptions = {}) {
  const {
    timeslice = 1000,
    videoBitsPerSecond = 2500000,
    audioBitsPerSecond = 128000,
    onDataAvailable,
    onStop,
    onError,
  } = options;

  const [state, setState] = useState<RecordingState>({
    isRecording: false,
    isPaused: false,
    duration: 0,
    error: null,
    blob: null,
    mimeType: '',
  });

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const durationTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef<number>(0);

  const getSupportedMimeType = useCallback((audioOnly: boolean = false): string => {
    if (audioOnly) {
      const audioTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/ogg',
        'audio/mp4',
      ];
      for (const type of audioTypes) {
        if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(type)) {
          return type;
        }
      }
      return 'audio/webm';
    }

    const types = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm;codecs=vp9',
      'video/webm;codecs=vp8',
      'video/webm',
      'video/mp4;codecs=h264,aac',
      'video/mp4',
    ];

    for (const type of types) {
      if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(type)) {
        return type;
      }
    }
    return 'video/webm';
  }, []);

  const startRecording = useCallback((stream: MediaStream, audioOnly: boolean = false) => {
    try {
      if (!stream || stream.getTracks().length === 0) {
        const errMsg = 'No media stream available for recording';
        setState(prev => ({ ...prev, error: errMsg }));
        onError?.(errMsg);
        return false;
      }

      // Reset state
      chunksRef.current = [];
      const mimeType = getSupportedMimeType(audioOnly);

      console.log('[MediaRecorder] Starting recording with mimeType:', mimeType, 'audioOnly:', audioOnly);

      const recorderOptions: MediaRecorderOptions = { mimeType };
      if (audioOnly) {
        recorderOptions.audioBitsPerSecond = audioBitsPerSecond;
      } else {
        recorderOptions.videoBitsPerSecond = videoBitsPerSecond;
        recorderOptions.audioBitsPerSecond = audioBitsPerSecond;
      }

      const recorder = new MediaRecorder(stream, recorderOptions);

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          chunksRef.current.push(event.data);
          onDataAvailable?.(event.data);
        }
      };

      recorder.onstop = () => {
        console.log('[MediaRecorder] Recording stopped, chunks:', chunksRef.current.length);
        const finalBlob = new Blob(chunksRef.current, { type: mimeType });
        console.log('[MediaRecorder] Final blob size:', (finalBlob.size / 1024 / 1024).toFixed(2), 'MB');

        // Stop duration timer
        if (durationTimerRef.current) {
          clearInterval(durationTimerRef.current);
          durationTimerRef.current = null;
        }

        const finalDuration = Math.floor((Date.now() - startTimeRef.current) / 1000);

        setState(prev => ({
          ...prev,
          isRecording: false,
          isPaused: false,
          blob: finalBlob,
          duration: finalDuration,
        }));

        onStop?.(finalBlob);
      };

      recorder.onerror = (event: any) => {
        const errMsg = event.error?.message || 'Recording error occurred';
        console.error('[MediaRecorder] Error:', errMsg);
        setState(prev => ({ ...prev, error: errMsg, isRecording: false }));
        onError?.(errMsg);
      };

      mediaRecorderRef.current = recorder;
      recorder.start(timeslice);
      startTimeRef.current = Date.now();

      // Start duration timer
      durationTimerRef.current = setInterval(() => {
        setState(prev => ({
          ...prev,
          duration: Math.floor((Date.now() - startTimeRef.current) / 1000),
        }));
      }, 1000);

      setState({
        isRecording: true,
        isPaused: false,
        duration: 0,
        error: null,
        blob: null,
        mimeType,
      });

      console.log('[MediaRecorder] Recording started successfully');
      return true;
    } catch (err: any) {
      const errMsg = err.message || 'Failed to start recording';
      console.error('[MediaRecorder] Start error:', errMsg);
      setState(prev => ({ ...prev, error: errMsg }));
      onError?.(errMsg);
      return false;
    }
  }, [getSupportedMimeType, timeslice, videoBitsPerSecond, audioBitsPerSecond, onDataAvailable, onStop, onError]);

  const stopRecording = useCallback(() => {
    console.log('[MediaRecorder] Stopping recording...');
    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
    }
    if (durationTimerRef.current) {
      clearInterval(durationTimerRef.current);
      durationTimerRef.current = null;
    }
  }, []);

  const pauseRecording = useCallback(() => {
    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state === 'recording') {
      recorder.pause();
      setState(prev => ({ ...prev, isPaused: true }));
    }
  }, []);

  const resumeRecording = useCallback(() => {
    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state === 'paused') {
      recorder.resume();
      setState(prev => ({ ...prev, isPaused: false }));
    }
  }, []);

  const getRecordingBlob = useCallback((): Blob | null => {
    if (state.blob) return state.blob;
    if (chunksRef.current.length > 0) {
      return new Blob(chunksRef.current, { type: state.mimeType || 'video/webm' });
    }
    return null;
  }, [state.blob, state.mimeType]);

  const cleanup = useCallback(() => {
    stopRecording();
    chunksRef.current = [];
    mediaRecorderRef.current = null;
    setState({
      isRecording: false,
      isPaused: false,
      duration: 0,
      error: null,
      blob: null,
      mimeType: '',
    });
  }, [stopRecording]);

  return {
    ...state,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    getRecordingBlob,
    cleanup,
  };
}
