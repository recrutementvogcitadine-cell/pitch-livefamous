import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { RealtimeChannel } from '@supabase/supabase-js';

export interface PresenceUser {
  userId: string;
  displayName: string;
  avatarUrl?: string | null;
  joinedAt: string;
}

interface UseStreamPresenceOptions {
  /** The stream ID to track presence for */
  streamId: string;
  /** Current user ID (if authenticated). Null = anonymous viewer */
  userId?: string | null;
  /** Display name for presence */
  displayName?: string;
  /** Avatar URL for presence */
  avatarUrl?: string | null;
  /** Whether this user is the stream creator (used for DB sync leadership) */
  isCreator?: boolean;
  /** Whether to enable presence tracking (default: true) */
  enabled?: boolean;
}

interface UseStreamPresenceReturn {
  /** Current number of viewers (from Presence state) */
  viewerCount: number;
  /** Whether the Presence channel is connected */
  isConnected: boolean;
  /** List of present users */
  viewers: PresenceUser[];
  /** Any error that occurred */
  error: string | null;
}

// Debounce helper
function debounce<T extends (...args: any[]) => void>(fn: T, ms: number): T & { cancel: () => void } {
  let timeoutId: ReturnType<typeof setTimeout> | null = null;
  const debounced = (...args: any[]) => {
    if (timeoutId) clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), ms);
  };
  debounced.cancel = () => {
    if (timeoutId) clearTimeout(timeoutId);
  };
  return debounced as T & { cancel: () => void };
}

/**
 * useStreamPresence — Real-time viewer count via Supabase Realtime Presence.
 *
 * When a user opens a live stream, this hook:
 * 1. Joins a Presence channel scoped to the stream ID
 * 2. Tracks all users joining/leaving in real-time
 * 3. Computes the viewer count from the Presence state
 * 4. Syncs the count back to the `live_streams` table (debounced, leader-elected)
 * 5. Cleans up (leaves channel) on unmount
 */
export function useStreamPresence({
  streamId,
  userId,
  displayName = 'Spectateur',
  avatarUrl = null,
  isCreator = false,
  enabled = true,
}: UseStreamPresenceOptions): UseStreamPresenceReturn {
  const [viewerCount, setViewerCount] = useState(0);
  const [isConnected, setIsConnected] = useState(false);
  const [viewers, setViewers] = useState<PresenceUser[]>([]);
  const [error, setError] = useState<string | null>(null);

  const channelRef = useRef<RealtimeChannel | null>(null);
  const syncDbRef = useRef<ReturnType<typeof debounce> | null>(null);
  const isMountedRef = useRef(true);

  // Generate a stable anonymous ID for users without auth
  const presenceKeyRef = useRef(
    userId || `anon-${Math.random().toString(36).substring(2, 10)}-${Date.now()}`
  );

  // Update the presence key if userId changes
  useEffect(() => {
    if (userId) {
      presenceKeyRef.current = userId;
    }
  }, [userId]);

  /**
   * Sync the viewer count to the live_streams table.
   * Only the "leader" client performs the write to avoid N concurrent updates.
   * Leader = the stream creator if present, otherwise the user with the
   * alphabetically smallest presenceKey.
   */
  const syncCountToDb = useCallback(
    async (count: number, presentUsers: PresenceUser[]) => {
      if (!streamId || presentUsers.length === 0) return;

      // Determine if this client should be the leader
      const myKey = presenceKeyRef.current;
      const isLeader =
        isCreator ||
        presentUsers
          .map((u) => u.userId)
          .sort()[0] === myKey;

      if (!isLeader) return;

      try {
        // Get current peak_viewers to potentially update it
        const { data: currentStream } = await supabase
          .from('live_streams')
          .select('peak_viewers')
          .eq('id', streamId)
          .single();

        const currentPeak = currentStream?.peak_viewers ?? 0;
        const newPeak = Math.max(currentPeak, count);

        await supabase
          .from('live_streams')
          .update({
            viewer_count: count,
            peak_viewers: newPeak,
          })
          .eq('id', streamId)
          .eq('is_live', true); // Only update if still live
      } catch (err) {
        console.warn('[useStreamPresence] Failed to sync count to DB:', err);
      }
    },
    [streamId, isCreator]
  );

  /**
   * Extract unique viewers from the Presence state object.
   * Supabase Presence state is: { [key: string]: PresencePayload[] }
   * Each key can have multiple presences (e.g. multiple tabs).
   * We deduplicate by userId.
   */
  const extractViewers = useCallback(
    (presenceState: Record<string, any[]>): PresenceUser[] => {
      const seen = new Set<string>();
      const result: PresenceUser[] = [];

      for (const key of Object.keys(presenceState)) {
        const presences = presenceState[key];
        if (!Array.isArray(presences)) continue;

        for (const p of presences) {
          const uid = p.userId || key;
          if (!seen.has(uid)) {
            seen.add(uid);
            result.push({
              userId: uid,
              displayName: p.displayName || 'Spectateur',
              avatarUrl: p.avatarUrl || null,
              joinedAt: p.joinedAt || new Date().toISOString(),
            });
          }
        }
      }

      return result;
    },
    []
  );

  useEffect(() => {
    isMountedRef.current = true;

    if (!enabled || !streamId) {
      return;
    }

    // Create a debounced DB sync function (3 second debounce)
    const debouncedSync = debounce(
      (count: number, users: PresenceUser[]) => {
        if (isMountedRef.current) {
          syncCountToDb(count, users);
        }
      },
      3000
    );
    syncDbRef.current = debouncedSync;

    // Create the Presence channel
    const channelName = `stream-presence:${streamId}`;
    const channel = supabase.channel(channelName, {
      config: {
        presence: {
          key: presenceKeyRef.current,
        },
      },
    });

    channelRef.current = channel;

    // Handle presence sync events
    channel.on('presence', { event: 'sync' }, () => {
      if (!isMountedRef.current) return;

      const state = channel.presenceState();
      const currentViewers = extractViewers(state);
      const count = currentViewers.length;

      setViewers(currentViewers);
      setViewerCount(count);

      // Debounced sync to DB
      debouncedSync(count, currentViewers);
    });

    channel.on('presence', { event: 'join' }, ({ newPresences }) => {
      if (!isMountedRef.current) return;
      console.info(
        `[Presence] ${newPresences?.length || 0} user(s) joined stream ${streamId}`
      );
    });

    channel.on('presence', { event: 'leave' }, ({ leftPresences }) => {
      if (!isMountedRef.current) return;
      console.info(
        `[Presence] ${leftPresences?.length || 0} user(s) left stream ${streamId}`
      );
    });

    // Subscribe to the channel and track presence
    channel
      .subscribe(async (status) => {
        if (!isMountedRef.current) return;

        if (status === 'SUBSCRIBED') {
          setIsConnected(true);
          setError(null);

          // Track this user's presence
          const trackResult = await channel.track({
            userId: presenceKeyRef.current,
            displayName,
            avatarUrl,
            joinedAt: new Date().toISOString(),
            isCreator,
          });

          if (trackResult !== 'ok') {
            console.warn('[useStreamPresence] Failed to track presence:', trackResult);
          }
        } else if (status === 'CHANNEL_ERROR') {
          setError('Erreur de connexion au canal de présence');
          setIsConnected(false);
        } else if (status === 'TIMED_OUT') {
          setError('Connexion au canal expirée');
          setIsConnected(false);
        } else if (status === 'CLOSED') {
          setIsConnected(false);
        }
      });

    // Cleanup on unmount
    return () => {
      isMountedRef.current = false;

      // Cancel any pending DB sync
      debouncedSync.cancel();

      // Untrack and remove channel
      if (channelRef.current) {
        channelRef.current.untrack().then(() => {
          if (channelRef.current) {
            supabase.removeChannel(channelRef.current);
            channelRef.current = null;
          }
        }).catch(() => {
          // If untrack fails, still remove the channel
          if (channelRef.current) {
            supabase.removeChannel(channelRef.current);
            channelRef.current = null;
          }
        });
      }

      // Perform a final sync to decrement the count in DB
      // We do this outside the debounce to ensure it happens immediately
      syncCountToDb(Math.max(0, viewerCount - 1), viewers.filter(
        (v) => v.userId !== presenceKeyRef.current
      )).catch(() => {
        // Silently fail — not critical
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [streamId, enabled, syncCountToDb, extractViewers]);

  // Update tracked presence data if display name or avatar changes
  useEffect(() => {
    if (!channelRef.current || !isConnected) return;

    channelRef.current.track({
      userId: presenceKeyRef.current,
      displayName,
      avatarUrl,
      joinedAt: new Date().toISOString(),
      isCreator,
    }).catch(() => {
      // Silently fail
    });
  }, [displayName, avatarUrl, isCreator, isConnected]);

  return {
    viewerCount,
    isConnected,
    viewers,
    error,
  };
}
