
import { createRoot } from 'react-dom/client';
import ErrorBoundary from './components/ErrorBoundary';
import App from './App.tsx';
import './index.css';

// Global error handler — prevents blank page from uncaught errors
window.addEventListener('error', (event) => {
  // Log but don't crash the app for non-critical errors
  console.error('[PitchCI] Global error:', event.error?.message || event.message);
});

// Handle chunk loading failures (common after deployments)
window.addEventListener('error', (event) => {
  if (
    event.message?.includes('Loading chunk') ||
    event.message?.includes('Failed to fetch dynamically imported module') ||
    event.message?.includes('Importing a module script failed')
  ) {
    console.warn('[PitchCI] Chunk loading failed — reloading page...');
    // Only auto-reload once to avoid infinite loops
    const lastReload = sessionStorage.getItem('pitchci_chunk_reload');
    const now = Date.now();
    if (!lastReload || now - parseInt(lastReload) > 30000) {
      sessionStorage.setItem('pitchci_chunk_reload', now.toString());
      window.location.reload();
    }
  }
}, true);

const rootElement = document.getElementById('root');

if (rootElement) {
  try {
    const root = createRoot(rootElement);
    root.render(
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    );
  } catch (err) {
    console.error('[PitchCI] Failed to render app:', err);
    // Show a basic fallback if React completely fails to mount
    rootElement.innerHTML = `
      <div style="min-height:100vh;background:#030712;display:flex;align-items:center;justify-content:center;padding:20px;font-family:sans-serif;">
        <div style="text-align:center;max-width:400px;">
          <div style="width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,#f97316,#ec4899,#9333ea);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
            <svg width="32" height="32" fill="white" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"/></svg>
          </div>
          <h1 style="color:white;font-size:24px;margin:0 0 8px;">PitchCI</h1>
          <p style="color:#9ca3af;font-size:14px;margin:0 0 24px;">
            L'application n'a pas pu se charger. Veuillez recharger la page.
          </p>
          <button onclick="window.location.reload()" style="background:linear-gradient(135deg,#f97316,#ec4899,#9333ea);color:white;border:none;padding:12px 32px;border-radius:12px;font-size:14px;font-weight:600;cursor:pointer;">
            Recharger
          </button>
        </div>
      </div>
    `;
  }
} else {
  console.error('[PitchCI] Root element #root not found in DOM');
}
