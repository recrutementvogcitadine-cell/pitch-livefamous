import React, { useState } from 'react';

interface NotificationPref {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

const NotificationSettings: React.FC = () => {
  const [prefs, setPrefs] = useState<NotificationPref[]>([
    {
      id: 'live_start',
      label: 'Début de live',
      description: 'Recevoir une notification quand un créateur que vous suivez démarre un live',
      enabled: true,
    },
    {
      id: 'new_follower',
      label: 'Nouveaux abonnés',
      description: 'Être notifié quand quelqu\'un commence à vous suivre',
      enabled: true,
    },
    {
      id: 'chat_messages',
      label: 'Messages du chat',
      description: 'Recevoir des notifications pour les messages importants dans le chat',
      enabled: false,
    },
    {
      id: 'subscription_reminder',
      label: 'Rappels d\'abonnement',
      description: 'Être alerté avant l\'expiration de votre abonnement',
      enabled: true,
    },
    {
      id: 'promotions',
      label: 'Promotions et offres',
      description: 'Recevoir des offres spéciales et des promotions',
      enabled: false,
    },
    {
      id: 'platform_updates',
      label: 'Mises à jour de la plateforme',
      description: 'Être informé des nouvelles fonctionnalités et améliorations',
      enabled: true,
    },
  ]);

  const [pushEnabled, setPushEnabled] = useState(false);
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const togglePref = (id: string) => {
    setPrefs(prev => prev.map(p => p.id === id ? { ...p, enabled: !p.enabled } : p));
  };

  const handleRequestPush = async () => {
    try {
      if ('Notification' in window) {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          setPushEnabled(true);
          setMessage({ type: 'success', text: 'Notifications push activées avec succès' });
        } else {
          setMessage({ type: 'error', text: 'Les notifications push ont été refusées. Vérifiez les paramètres de votre navigateur.' });
        }
      } else {
        setMessage({ type: 'error', text: 'Votre navigateur ne supporte pas les notifications push' });
      }
    } catch {
      setMessage({ type: 'error', text: 'Erreur lors de l\'activation des notifications push' });
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage(null);

    // Simulate saving preferences
    await new Promise(resolve => setTimeout(resolve, 800));

    setMessage({ type: 'success', text: 'Préférences de notification mises à jour' });
    setIsSaving(false);
  };

  const ToggleSwitch = ({ enabled, onToggle }: { enabled: boolean; onToggle: () => void }) => (
    <button
      onClick={onToggle}
      className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ${
        enabled ? 'bg-purple-600' : 'bg-gray-700'
      }`}
    >
      <div
        className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-md transition-transform ${
          enabled ? 'translate-x-6' : 'translate-x-0.5'
        }`}
      />
    </button>
  );

  return (
    <div className="space-y-8">
      {/* Section Header */}
      <div>
        <h2 className="text-2xl font-bold text-white">Notifications</h2>
        <p className="text-gray-400 mt-1">Configurez comment et quand vous souhaitez être notifié</p>
      </div>

      {/* Notification Channels */}
      <div className="bg-gray-800/30 border border-gray-700/50 rounded-2xl p-6">
        <h3 className="text-white font-semibold mb-4">Canaux de notification</h3>
        <div className="space-y-4">
          {/* Push Notifications */}
          <div className="flex items-center justify-between p-4 bg-gray-900/50 rounded-xl">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
              </div>
              <div>
                <p className="text-white font-medium">Notifications push</p>
                <p className="text-gray-500 text-sm">Recevez des alertes directement dans votre navigateur</p>
              </div>
            </div>
            {pushEnabled ? (
              <ToggleSwitch enabled={pushEnabled} onToggle={() => setPushEnabled(false)} />
            ) : (
              <button
                onClick={handleRequestPush}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors"
              >
                Activer
              </button>
            )}
          </div>

          {/* Email Notifications */}
          <div className="flex items-center justify-between p-4 bg-gray-900/50 rounded-xl">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <div>
                <p className="text-white font-medium">Notifications par email</p>
                <p className="text-gray-500 text-sm">Recevez un résumé par email</p>
              </div>
            </div>
            <ToggleSwitch enabled={emailEnabled} onToggle={() => setEmailEnabled(!emailEnabled)} />
          </div>
        </div>
      </div>

      {/* Notification Preferences */}
      <div className="bg-gray-800/30 border border-gray-700/50 rounded-2xl p-6">
        <h3 className="text-white font-semibold mb-4">Types de notifications</h3>
        <div className="divide-y divide-gray-800">
          {prefs.map((pref) => (
            <div key={pref.id} className="flex items-center justify-between py-4 first:pt-0 last:pb-0">
              <div className="pr-4">
                <p className="text-white font-medium text-sm">{pref.label}</p>
                <p className="text-gray-500 text-sm mt-0.5">{pref.description}</p>
              </div>
              <ToggleSwitch enabled={pref.enabled} onToggle={() => togglePref(pref.id)} />
            </div>
          ))}
        </div>
      </div>

      {/* Message */}
      {message && (
        <div className={`p-4 rounded-xl border ${
          message.type === 'success'
            ? 'bg-green-500/10 border-green-500/30 text-green-400'
            : 'bg-red-500/10 border-red-500/30 text-red-400'
        }`}>
          <div className="flex items-center gap-2">
            {message.type === 'success' ? (
              <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            )}
            <p className="text-sm">{message.text}</p>
          </div>
        </div>
      )}

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold rounded-xl transition-all flex items-center gap-2"
        >
          {isSaving ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Enregistrement...
            </>
          ) : (
            <>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Enregistrer les préférences
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default NotificationSettings;
