import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { subscriptionService, CreatorSubscription } from '@/lib/subscriptionService';
import { paymentService, PaymentHistoryItem } from '@/lib/paymentService';

const SubscriptionSettings: React.FC = () => {
  const navigate = useNavigate();
  const { creatorProfile, hasActiveSubscription, refreshSubscription } = useAppContext();
  const [subscription, setSubscription] = useState<CreatorSubscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isCancelling, setIsCancelling] = useState(false);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [recentPayments, setRecentPayments] = useState<PaymentHistoryItem[]>([]);

  useEffect(() => {
    loadSubscription();
  }, [creatorProfile]);

  const loadSubscription = async () => {
    if (!creatorProfile) {
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    try {
      const [sub, historyResult] = await Promise.all([
        subscriptionService.getCreatorSubscription(creatorProfile.id),
        paymentService.getPaymentHistory()
      ]);
      setSubscription(sub);
      if (historyResult.success && historyResult.payments) {
        setRecentPayments(historyResult.payments.slice(0, 5));
      }
    } catch {
      // Failed silently
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = async () => {
    if (!subscription) return;

    setIsCancelling(true);
    setMessage(null);

    try {
      const result = await subscriptionService.cancelSubscription(subscription.id);
      if (result.success) {
        setMessage({ type: 'success', text: 'Votre abonnement a été annulé. Vous conservez l\'accès jusqu\'à la fin de la période en cours.' });
        setShowCancelConfirm(false);
        await loadSubscription();
        await refreshSubscription();
      } else {
        setMessage({ type: 'error', text: result.error || 'Erreur lors de l\'annulation' });
      }
    } catch {
      setMessage({ type: 'error', text: 'Une erreur inattendue est survenue' });
    } finally {
      setIsCancelling(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-8 h-8 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
      </div>
    );
  }

  const daysRemaining = subscription?.expires_at
    ? subscriptionService.getDaysRemaining(subscription.expires_at)
    : 0;

  const progressPercent = subscription?.expires_at && subscription?.started_at
    ? (() => {
        const start = new Date(subscription.started_at).getTime();
        const end = new Date(subscription.expires_at).getTime();
        const now = Date.now();
        const total = end - start;
        const elapsed = now - start;
        return Math.min(100, Math.max(0, (elapsed / total) * 100));
      })()
    : 0;

  return (
    <div className="space-y-8">
      {/* Section Header */}
      <div>
        <h2 className="text-2xl font-bold text-white">Abonnement</h2>
        <p className="text-gray-400 mt-1">Gérez votre forfait et votre facturation</p>
      </div>

      {/* Current Plan Card */}
      {subscription && subscription.status === 'active' ? (
        <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl p-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <div>
                <h3 className="text-white font-bold text-xl">{subscription.plan?.name || 'Créateur Pro'}</h3>
                <p className="text-gray-400 text-sm">
                  Facturation {subscription.billing_cycle === 'monthly' ? 'mensuelle' : 'annuelle'}
                </p>
              </div>
            </div>
            <span className="px-3 py-1 bg-green-500/20 text-green-400 text-sm font-medium rounded-full border border-green-500/30">
              Actif
            </span>
          </div>

          {/* Subscription Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <div className="bg-black/20 rounded-xl p-4">
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-1">Prix</p>
              <p className="text-white font-bold text-lg">
                {subscription.plan
                  ? subscriptionService.formatPrice(
                      subscription.billing_cycle === 'monthly'
                        ? subscription.plan.price_monthly
                        : subscription.plan.price_yearly
                    )
                  : '-'}
                <span className="text-gray-400 text-sm font-normal">
                  /{subscription.billing_cycle === 'monthly' ? 'mois' : 'an'}
                </span>
              </p>
            </div>
            <div className="bg-black/20 rounded-xl p-4">
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-1">Date de début</p>
              <p className="text-white font-bold text-lg">
                {subscription.started_at
                  ? new Date(subscription.started_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })
                  : '-'}
              </p>
            </div>
            <div className="bg-black/20 rounded-xl p-4">
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-1">Expiration</p>
              <p className={`font-bold text-lg ${daysRemaining <= 7 ? 'text-yellow-400' : 'text-white'}`}>
                {subscription.expires_at
                  ? new Date(subscription.expires_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })
                  : '-'}
              </p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">Période en cours</span>
              <span className={`font-medium ${daysRemaining <= 7 ? 'text-yellow-400' : 'text-green-400'}`}>
                {daysRemaining} jour{daysRemaining > 1 ? 's' : ''} restant{daysRemaining > 1 ? 's' : ''}
              </span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${
                  daysRemaining <= 7
                    ? 'bg-gradient-to-r from-yellow-500 to-orange-500'
                    : 'bg-gradient-to-r from-purple-500 to-pink-500'
                }`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Features */}
          {subscription.plan?.features && subscription.plan.features.length > 0 && (
            <div className="mb-6">
              <p className="text-gray-400 text-sm font-medium mb-3">Fonctionnalités incluses</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {subscription.plan.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2 text-white text-sm">
                    <svg className="w-4 h-4 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    {feature}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cancel Button */}
          {!showCancelConfirm ? (
            <button
              onClick={() => setShowCancelConfirm(true)}
              className="text-gray-400 hover:text-red-400 text-sm font-medium transition-colors"
            >
              Annuler mon abonnement
            </button>
          ) : (
            <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <svg className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <div className="flex-1">
                  <p className="text-white font-medium">Confirmer l'annulation</p>
                  <p className="text-gray-400 text-sm mt-1">
                    Votre abonnement restera actif jusqu'au {subscription.expires_at
                      ? new Date(subscription.expires_at).toLocaleDateString('fr-FR')
                      : 'la fin de la période'
                    }. Vous ne pourrez plus démarrer de lives après cette date.
                  </p>
                  <div className="flex gap-3 mt-4">
                    <button
                      onClick={handleCancel}
                      disabled={isCancelling}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-700 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2"
                    >
                      {isCancelling ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : null}
                      {isCancelling ? 'Annulation...' : 'Oui, annuler'}
                    </button>
                    <button
                      onClick={() => setShowCancelConfirm(false)}
                      className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 text-sm font-medium rounded-lg transition-colors"
                    >
                      Non, garder
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* No Active Subscription */
        <div className="bg-gray-800/30 border border-gray-700/50 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-gray-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
          </div>
          <h3 className="text-white font-bold text-lg mb-2">Aucun abonnement actif</h3>
          <p className="text-gray-400 text-sm mb-6 max-w-md mx-auto">
            {subscription?.status === 'cancelled'
              ? 'Votre abonnement a été annulé. Souscrivez à nouveau pour accéder aux fonctionnalités premium.'
              : subscription?.status === 'expired'
              ? 'Votre abonnement a expiré. Renouvelez-le pour continuer à profiter des fonctionnalités premium.'
              : 'Souscrivez à un abonnement pour démarrer des lives et accéder à toutes les fonctionnalités.'}
          </p>
          {subscription && (
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-gray-800 rounded-full text-sm mb-6">
              <span className={subscriptionService.getStatusColor(subscription.status)}>
                {subscriptionService.getStatusLabel(subscription.status)}
              </span>
            </div>
          )}

          {/* Mobile Money Payment Methods */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="8" fill="white" fillOpacity="0.3" />
                <path d="M12 9v6M9 12h6" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </div>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 5L6 9v10h12V9l-6-4z" fill="white" fillOpacity="0.4" stroke="white" strokeWidth="1.5" />
              </svg>
            </div>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M4 12c2-3 4-4 6-4s4 3 6 3 4-3 6-3" stroke="white" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>
          </div>

          <div>
            <button
              onClick={() => navigate('/payment')}
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold rounded-xl transition-all"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
              Payer avec Mobile Money
            </button>
          </div>
        </div>
      )}

      {/* Recent Payments */}
      {recentPayments.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-bold text-lg">Derniers paiements</h3>
            <button
              onClick={() => navigate('/payment')}
              className="text-purple-400 text-sm hover:text-purple-300 transition-colors"
            >
              Voir tout
            </button>
          </div>
          <div className="space-y-3">
            {recentPayments.map((payment) => (
              <div key={payment.id} className="bg-gray-800/50 rounded-xl p-4 border border-gray-700/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {payment.provider === 'orange_money' && (
                    <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="8" fill="white" fillOpacity="0.3" />
                        <path d="M12 9v6M9 12h6" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
                      </svg>
                    </div>
                  )}
                  {payment.provider === 'mtn_money' && (
                    <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <path d="M12 5L6 9v10h12V9l-6-4z" fill="white" fillOpacity="0.4" stroke="white" strokeWidth="1.5" />
                      </svg>
                    </div>
                  )}
                  {payment.provider === 'wave' && (
                    <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <path d="M4 12c2-3 4-4 6-4s4 3 6 3 4-3 6-3" stroke="white" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                    </div>
                  )}
                  <div>
                    <p className="text-white text-sm font-medium">
                      {payment.provider === 'orange_money' ? 'Orange Money' :
                       payment.provider === 'mtn_money' ? 'MTN Money' : 'Wave'}
                    </p>
                    <p className="text-gray-500 text-xs">
                      {new Date(payment.created_at).toLocaleDateString('fr-FR', {
                        day: 'numeric', month: 'short', year: 'numeric'
                      })}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-white font-semibold text-sm">
                    {paymentService.formatAmount(payment.amount, payment.currency)}
                  </p>
                  <p className={`text-xs font-medium ${paymentService.getStatusColor(payment.status)}`}>
                    {paymentService.getStatusLabel(payment.status)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Message */}
      {message && (
        <div className={`p-4 rounded-xl border ${
          message.type === 'success'
            ? 'bg-green-500/10 border-green-500/30 text-green-400'
            : 'bg-red-500/10 border-red-500/30 text-red-400'
        }`}>
          <div className="flex items-center gap-2">
            {message.type === 'success' ? (
              <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            )}
            <p className="text-sm">{message.text}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionSettings;
