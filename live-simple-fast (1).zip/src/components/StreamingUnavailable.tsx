import React from 'react';

interface StreamingUnavailableProps {
  /** The specific error or reason streaming is unavailable */
  reason?: string;
  /** Error code from the edge function */
  errorCode?: string;
  /** Whether this is for a viewer or creator context */
  context?: 'viewer' | 'creator';
  /** Callback to retry the connection */
  onRetry?: () => void;
  /** Callback to dismiss/close */
  onClose?: () => void;
  /** Whether a retry is in progress */
  isRetrying?: boolean;
  /** Optional className for the container */
  className?: string;
}

/**
 * Fallback UI component displayed when the Agora streaming service is unavailable.
 * Shows a helpful, non-crashing message with actionable guidance.
 */
const StreamingUnavailable: React.FC<StreamingUnavailableProps> = ({
  reason,
  errorCode,
  context = 'viewer',
  onRetry,
  onClose,
  isRetrying = false,
  className = '',
}) => {
  const isAgoraNotConfigured = errorCode === 'AGORA_NOT_CONFIGURED';
  const isInvalidCredentials = errorCode === 'AGORA_INVALID_CREDENTIALS';
  const isNetworkError = errorCode === 'EXCEPTION' || errorCode === 'EDGE_FUNCTION_ERROR';
  const isAuthError = errorCode === 'AUTH_REQUIRED' || errorCode === 'AUTH_INVALID';

  const getIcon = () => {
    if (isAgoraNotConfigured || isInvalidCredentials) {
      return (
        <svg className="w-8 h-8 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      );
    }
    if (isNetworkError) {
      return (
        <svg className="w-8 h-8 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M18.364 5.636a9 9 0 010 12.728m0 0l-2.829-2.829m2.829 2.829L21 21M15.536 8.464a5 5 0 010 7.072m0 0l-2.829-2.829m-4.243 2.829a5 5 0 01-1.414-7.072m-2.829 2.829L3 3m2.829 2.829l2.829 2.829m0 0a3 3 0 014.243 0" />
        </svg>
      );
    }
    return (
      <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
        <line x1="3" y1="3" x2="21" y2="21" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" />
      </svg>
    );
  };

  const getTitle = () => {
    if (isAgoraNotConfigured) return 'Service de streaming non configuré';
    if (isInvalidCredentials) return 'Identifiants de streaming invalides';
    if (isNetworkError) return 'Service de streaming indisponible';
    if (isAuthError) return 'Authentification requise';
    return 'Streaming en temps réel indisponible';
  };

  const getMessage = () => {
    if (reason) return reason;
    if (isAgoraNotConfigured) {
      return context === 'creator'
        ? 'Les secrets AGORA_APP_ID et AGORA_APP_CERTIFICATE doivent être configurés dans les paramètres Edge Function de Supabase pour activer le streaming en temps réel. Votre live sera créé en mode enregistrement local uniquement.'
        : 'Le streaming en temps réel n\'est pas encore configuré sur cette plateforme. Vous pouvez toujours voir les replays des lives enregistrés.';
    }
    if (isInvalidCredentials) {
      return 'Les identifiants Agora configurés semblent invalides. Vérifiez que les valeurs AGORA_APP_ID et AGORA_APP_CERTIFICATE correspondent à celles de votre console Agora.';
    }
    if (isNetworkError) {
      return 'Impossible de se connecter au service de streaming. Vérifiez votre connexion internet et réessayez.';
    }
    if (isAuthError) {
      return 'Votre session a expiré. Veuillez vous reconnecter pour accéder au streaming.';
    }
    return 'Le streaming en temps réel n\'est pas disponible pour le moment. Veuillez réessayer plus tard.';
  };

  const getSetupSteps = () => {
    if (!isAgoraNotConfigured && !isInvalidCredentials) return null;
    
    return (
      <div className="mt-4 bg-gray-800/50 rounded-lg p-3 text-left">
        <p className="text-gray-300 text-xs font-semibold mb-2">Pour configurer le streaming :</p>
        <ol className="text-gray-400 text-xs space-y-1.5 list-decimal list-inside">
          <li>Créez un compte sur <a href="https://console.agora.io" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 underline">console.agora.io</a></li>
          <li>Créez un projet et copiez l'App ID et l'App Certificate</li>
          <li>Dans votre Dashboard Supabase, allez dans Edge Functions &gt; Secrets</li>
          <li>Ajoutez <code className="bg-gray-700 px-1 py-0.5 rounded text-purple-300">AGORA_APP_ID</code> et <code className="bg-gray-700 px-1 py-0.5 rounded text-purple-300">AGORA_APP_CERTIFICATE</code></li>
        </ol>
      </div>
    );
  };

  const borderColor = isAgoraNotConfigured || isInvalidCredentials
    ? 'border-amber-500/30'
    : isNetworkError
    ? 'border-red-500/30'
    : 'border-gray-700';

  const bgColor = isAgoraNotConfigured || isInvalidCredentials
    ? 'bg-amber-500/5'
    : isNetworkError
    ? 'bg-red-500/5'
    : 'bg-gray-800/50';

  return (
    <div className={`rounded-xl border ${borderColor} ${bgColor} p-5 text-center ${className}`}>
      <div className="flex justify-center mb-3">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
          isAgoraNotConfigured || isInvalidCredentials
            ? 'bg-amber-500/10'
            : isNetworkError
            ? 'bg-red-500/10'
            : 'bg-gray-700/50'
        }`}>
          {getIcon()}
        </div>
      </div>

      <h3 className="text-white font-semibold text-base mb-2">{getTitle()}</h3>
      <p className="text-gray-400 text-sm leading-relaxed max-w-md mx-auto">{getMessage()}</p>

      {getSetupSteps()}

      {errorCode && (
        <p className="text-gray-600 text-xs mt-3 font-mono">
          Code: {errorCode}
        </p>
      )}

      <div className="flex items-center justify-center gap-3 mt-4">
        {onRetry && (
          <button
            onClick={onRetry}
            disabled={isRetrying}
            className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 text-white font-medium px-5 py-2 rounded-lg text-sm transition-colors flex items-center gap-2"
          >
            {isRetrying ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Connexion...
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Réessayer
              </>
            )}
          </button>
        )}
        {onClose && (
          <button
            onClick={onClose}
            className="bg-gray-800 hover:bg-gray-700 text-gray-300 font-medium px-5 py-2 rounded-lg text-sm transition-colors"
          >
            Fermer
          </button>
        )}
      </div>
    </div>
  );
};

export default StreamingUnavailable;
