import React from 'react';

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    this.setState({ errorInfo });
    console.error('[ErrorBoundary] Caught error:', error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  handleClearAndReload = () => {
    try {
      // Clear potentially corrupted auth data
      localStorage.removeItem('pitchci-auth-token');
      localStorage.removeItem('famous_supabase_url');
      localStorage.removeItem('famous_supabase_anon_key');
      sessionStorage.clear();
    } catch {
      // ignore
    }
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      const errorMessage = this.state.error?.message || 'Une erreur inconnue est survenue';
      const isChunkError = errorMessage.includes('Loading chunk') || 
                           errorMessage.includes('Failed to fetch dynamically imported module') ||
                           errorMessage.includes('Importing a module script failed');

      return (
        <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
          <div className="max-w-lg w-full">
            {/* Logo */}
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 via-pink-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto shadow-xl shadow-purple-500/20 mb-4">
                <svg className="w-9 h-9 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" />
                </svg>
              </div>
              <h1 className="text-white font-bold text-2xl">PitchCI</h1>
            </div>

            {/* Error Card */}
            <div className="bg-gray-900/80 border border-gray-800 rounded-2xl p-6 sm:p-8 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-white font-semibold text-lg">
                    {isChunkError ? 'Mise à jour disponible' : 'Oups ! Une erreur est survenue'}
                  </h2>
                  <p className="text-gray-500 text-sm">
                    {isChunkError
                      ? 'Une nouvelle version est disponible. Rechargez la page.'
                      : "L'application a rencontré un problème inattendu."
                    }
                  </p>
                </div>
              </div>

              {/* Error details (collapsed) */}
              {!isChunkError && (
                <details className="mb-6">
                  <summary className="text-gray-500 text-xs cursor-pointer hover:text-gray-400 transition-colors">
                    Détails techniques
                  </summary>
                  <div className="mt-2 bg-gray-950 rounded-xl p-3 border border-gray-800">
                    <pre className="text-red-400/80 text-xs font-mono whitespace-pre-wrap break-words max-h-32 overflow-y-auto">
                      {errorMessage}
                    </pre>
                    {this.state.errorInfo?.componentStack && (
                      <pre className="text-gray-600 text-xs font-mono whitespace-pre-wrap break-words mt-2 max-h-24 overflow-y-auto">
                        {this.state.errorInfo.componentStack.substring(0, 500)}
                      </pre>
                    )}
                  </div>
                </details>
              )}

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={this.handleReload}
                  className="flex-1 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-semibold py-3 px-6 rounded-xl shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Recharger la page
                </button>
                <button
                  onClick={this.handleGoHome}
                  className="flex-1 bg-gray-800 hover:bg-gray-700 text-gray-300 font-medium py-3 px-6 rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                  </svg>
                  Accueil
                </button>
              </div>

              {/* Reset option */}
              {!isChunkError && (
                <div className="mt-4 pt-4 border-t border-gray-800">
                  <button
                    onClick={this.handleClearAndReload}
                    className="text-gray-600 hover:text-gray-400 text-xs transition-colors w-full text-center"
                  >
                    Réinitialiser le cache et recharger
                  </button>
                </div>
              )}
            </div>

            {/* Help text */}
            <p className="text-gray-700 text-xs text-center mt-4">
              Si le problème persiste, contactez le support à support@pitchci.com
            </p>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
