/**
 * ProtectedRoute.tsx
 *
 * Route guard component that protects pages based on authentication
 * and role requirements. Redirects unauthenticated users to home
 * and unauthorized users to an appropriate page.
 *
 * Usage in App.tsx:
 *   <Route path="/dashboard" element={<ProtectedRoute><CreatorDashboard /></ProtectedRoute>} />
 *   <Route path="/admin" element={<ProtectedRoute requireAdmin><AdminDashboard /></ProtectedRoute>} />
 *   <Route path="/settings" element={<ProtectedRoute requireAuth><SettingsPage /></ProtectedRoute>} />
 */

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { isSupabaseConfigured } from '@/lib/supabase';

interface ProtectedRouteProps {
  children: React.ReactNode;
  /** Require authentication (default: true) */
  requireAuth?: boolean;
  /** Require admin role */
  requireAdmin?: boolean;
  /** Require a creator profile */
  requireCreator?: boolean;
  /** Require an active subscription */
  requireSubscription?: boolean;
  /** Custom fallback component instead of redirect */
  fallback?: React.ReactNode;
  /** Custom redirect path (default: /) */
  redirectTo?: string;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requireAuth = true,
  requireAdmin = false,
  requireCreator = false,
  requireSubscription = false,
  fallback,
  redirectTo = '/',
}) => {
  const navigate = useNavigate();
  const {
    isAuthenticated,
    isLoading,
    isSupabaseReady,
    isAdmin,
    creatorProfile,
    hasActiveSubscription,
  } = useAppContext();

  const [shouldRender, setShouldRender] = useState(false);
  const [accessDenied, setAccessDenied] = useState(false);
  const [deniedReason, setDeniedReason] = useState('');

  useEffect(() => {
    // Wait for auth to finish loading
    if (isLoading) return;

    // If Supabase is not configured, redirect to setup page
    if (!isSupabaseConfigured) {
      navigate('/setup', { replace: true });
      return;
    }


    // Check authentication
    if (requireAuth && !isAuthenticated) {
      if (fallback) {
        setAccessDenied(true);
        setDeniedReason('Vous devez être connecté pour accéder à cette page.');
      } else {
        navigate(redirectTo, { replace: true });
      }
      return;
    }

    // Check admin role
    if (requireAdmin && !isAdmin) {
      if (fallback) {
        setAccessDenied(true);
        setDeniedReason('Accès réservé aux administrateurs.');
      } else {
        navigate(redirectTo, { replace: true });
      }
      return;
    }

    // Check creator profile
    if (requireCreator && !creatorProfile) {
      if (fallback) {
        setAccessDenied(true);
        setDeniedReason('Vous devez avoir un profil créateur pour accéder à cette page.');
      } else {
        navigate('/profile/edit', { replace: true });
      }
      return;
    }

    // Check subscription
    if (requireSubscription && !hasActiveSubscription) {
      if (fallback) {
        setAccessDenied(true);
        setDeniedReason('Un abonnement actif est requis pour accéder à cette fonctionnalité.');
      } else {
        navigate('/payment', { replace: true });
      }
      return;
    }

    // All checks passed
    setShouldRender(true);
    setAccessDenied(false);
  }, [
    isLoading,
    isAuthenticated,
    isAdmin,
    creatorProfile,
    hasActiveSubscription,
    requireAuth,
    requireAdmin,
    requireCreator,
    requireSubscription,
    navigate,
    redirectTo,
    fallback,
  ]);

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400 text-sm">Chargement...</p>
        </div>
      </div>
    );
  }

  // Access denied with custom fallback
  if (accessDenied && fallback) {
    return <>{fallback}</>;
  }

  // Access denied — show inline message
  if (accessDenied) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-gray-900 border border-gray-800 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-white text-xl font-bold mb-2">Accès refusé</h2>
          <p className="text-gray-400 mb-6">{deniedReason}</p>
          <button
            onClick={() => navigate(redirectTo)}
            className="bg-purple-600 hover:bg-purple-700 text-white font-medium px-6 py-2.5 rounded-full transition-colors"
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  // Render children
  if (shouldRender) {
    return <>{children}</>;
  }

  // Default: show nothing while redirecting
  return null;
};

export default ProtectedRoute;
