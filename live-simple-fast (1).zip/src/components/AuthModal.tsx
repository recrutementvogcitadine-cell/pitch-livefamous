import React, { useState, useRef } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { isSupabaseConfigured } from '@/lib/supabase';
import EmailNotConfirmedHelper from '@/components/EmailNotConfirmedHelper';
import type { EmailErrorType } from '@/components/EmailNotConfirmedHelper';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { signIn, signUp } = useAppContext();
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [showEmailHelper, setShowEmailHelper] = useState(false);
  const [emailErrorType, setEmailErrorType] = useState<EmailErrorType>('email_not_confirmed');
  // Ref-based guard to prevent rapid double-submissions even if React state hasn't updated yet
  const submittingRef = useRef(false);

  if (!isOpen) return null;

  const resetForm = () => {
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setError('');
    setSuccessMessage('');
    setShowEmailHelper(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Double-click guard: prevent submission if already in progress
    if (submittingRef.current || isLoading) {
      return;
    }

    setError('');
    setSuccessMessage('');
    setShowEmailHelper(false);

    if (isSignUp) {
      if (password.length < 6) {
        setError('Le mot de passe doit contenir au moins 6 caractères.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Les mots de passe ne correspondent pas.');
        return;
      }
    }

    setIsLoading(true);
    submittingRef.current = true;

    try {
      const result = isSignUp
        ? await signUp(email, password)
        : await signIn(email, password);

      if (result.success) {
        if (isSignUp) {
          setSuccessMessage(
            'Compte créé avec succès ! Vérifiez votre boîte email pour confirmer votre inscription.'
          );
          setTimeout(() => {
            onClose();
            resetForm();
          }, 3000);
        } else {
          onClose();
          resetForm();
        }
      } else {
        const errorMsg = result.error;
        if (!errorMsg || errorMsg === '{}' || errorMsg === '""' || errorMsg.trim() === '') {
          setError('Email ou mot de passe incorrect. Veuillez réessayer.');
        } else {
          setError(errorMsg);
        }
        // Detect email-related errors
        if (result.errorCode === 'email_not_confirmed' || result.errorCode === 'email_sending_failed') {
          setShowEmailHelper(true);
          setEmailErrorType(result.errorCode as EmailErrorType);
        }
      }
    } catch {
      setError('Une erreur inattendue est survenue. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
      submittingRef.current = false;
    }
  };


  const toggleMode = () => {
    setIsSignUp(!isSignUp);
    setError('');
    setSuccessMessage('');
    setShowEmailHelper(false);
    setConfirmPassword('');
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-gray-900 rounded-2xl w-full max-w-md p-6 space-y-5 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">
            {isSignUp ? 'Créer un compte' : 'Connexion'}
          </h2>
          <button
            onClick={() => { onClose(); resetForm(); }}
            className="w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
          >
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Warning if Supabase not configured */}
        {!isSupabaseConfigured && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <svg className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
              <div className="flex-1">
                <p className="text-amber-300 text-sm font-medium mb-1">Serveur non configuré</p>
                <p className="text-amber-300/70 text-xs leading-relaxed">
                  L'authentification nécessite une connexion Supabase. Configurez vos variables d'environnement.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Success Message */}
        {successMessage && (
          <div className="bg-green-500/10 border border-green-500/40 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <svg className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="text-green-300 text-sm leading-relaxed">{successMessage}</p>
            </div>
          </div>
        )}

        {/* Email Not Confirmed / Sending Failed Helper */}
        {showEmailHelper && email && (
          <EmailNotConfirmedHelper
            email={email}
            errorType={emailErrorType}
            onDismiss={() => setShowEmailHelper(false)}
          />
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Error Message (only show if NOT showing the email helper) */}
          {error && !showEmailHelper && (
            <div className="bg-red-500/10 border border-red-500/40 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <svg className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-red-300 text-sm leading-relaxed">{error}</p>
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm text-gray-400 mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="votre@email.com"
              className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              required
              autoComplete="email"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-2">Mot de passe</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              required
              minLength={6}
              autoComplete={isSignUp ? 'new-password' : 'current-password'}
            />
            {isSignUp && (
              <p className="text-gray-500 text-xs mt-1.5">Minimum 6 caractères</p>
            )}
          </div>

          {isSignUp && (
            <div>
              <label className="block text-sm text-gray-400 mb-2">Confirmer le mot de passe</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className={`w-full bg-gray-800 border rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all ${
                  confirmPassword && confirmPassword !== password
                    ? 'border-red-500/50'
                    : 'border-gray-700'
                }`}
                required
                minLength={6}
                autoComplete="new-password"
              />
              {confirmPassword && confirmPassword !== password && (
                <p className="text-red-400 text-xs mt-1.5">Les mots de passe ne correspondent pas</p>
              )}
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading || (isSignUp && password !== confirmPassword && confirmPassword.length > 0)}
            className="w-full bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-semibold py-3.5 rounded-xl transition-colors"
          >
            {isLoading ? (
              <div className="flex items-center justify-center gap-2">
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>{isSignUp ? 'Création...' : 'Connexion...'}</span>
              </div>
            ) : isSignUp ? (
              "S'inscrire"
            ) : (
              'Se connecter'
            )}
          </button>
        </form>

        {/* Toggle */}
        <p className="text-center text-gray-400 text-sm">
          {isSignUp ? 'Déjà un compte ?' : 'Pas encore de compte ?'}{' '}
          <button
            onClick={toggleMode}
            className="text-purple-400 hover:text-purple-300 font-medium transition-colors"
          >
            {isSignUp ? 'Se connecter' : "S'inscrire"}
          </button>
        </p>
      </div>
    </div>
  );
};

export default AuthModal;
