import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import { isValidUUID } from '@/lib/utils';

interface FollowButtonProps {
  creatorId: string;
  creatorName?: string;
  followerCount?: number;
  showCount?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'icon';
  onFollowChange?: (isFollowing: boolean) => void;
}

const FollowButton: React.FC<FollowButtonProps> = ({
  creatorId,
  creatorName,
  followerCount = 0,
  showCount = false,
  size = 'md',
  onFollowChange,
}) => {
  const { user, isAuthenticated } = useAppContext();
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [count, setCount] = useState(followerCount);
  
  // Check if this is a real creator (valid UUID) or demo data
  const isRealCreator = isValidUUID(creatorId);

  // Check if user is following this creator
  useEffect(() => {
    const checkFollowStatus = async () => {
      if (!user || !creatorId || !isRealCreator) return;

      try {
        const { data, error } = await supabase
          .from('follows')
          .select('id')
          .eq('follower_id', user.id)
          .eq('creator_id', creatorId)
          .maybeSingle();


        if (!error && data) {
          setIsFollowing(true);
        } else {
          setIsFollowing(false);
        }
      } catch (err) {
        console.error('Error checking follow status:', err);
      }
    };

    checkFollowStatus();
  }, [user, creatorId, isRealCreator]);

  // Update count when prop changes
  useEffect(() => {
    setCount(followerCount);
  }, [followerCount]);

  const handleFollow = async (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering parent click handlers

    if (!isAuthenticated) {
      // Trigger auth modal
      const event = new CustomEvent('triggerAuthModal');
      window.dispatchEvent(event);
      return;
    }

    if (!user || !creatorId) return;

    // For demo creators, just toggle state locally
    if (!isRealCreator) {
      setIsFollowing(!isFollowing);
      setCount(prev => isFollowing ? Math.max(0, prev - 1) : prev + 1);
      onFollowChange?.(!isFollowing);
      return;
    }

    setLoading(true);

    try {
      if (isFollowing) {
        // Unfollow
        const { error } = await supabase
          .from('follows')
          .delete()
          .eq('follower_id', user.id)
          .eq('creator_id', creatorId);

        if (error) throw error;

        setIsFollowing(false);
        setCount(prev => Math.max(0, prev - 1));
        onFollowChange?.(false);
      } else {
        // Follow
        const { error } = await supabase
          .from('follows')
          .insert({
            follower_id: user.id,
            creator_id: creatorId,
          });

        if (error) throw error;

        setIsFollowing(true);
        setCount(prev => prev + 1);
        onFollowChange?.(true);
      }
    } catch (err) {
      console.error('Error toggling follow:', err);
    } finally {
      setLoading(false);
    }
  };

  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1.5 text-sm',
    lg: 'px-4 py-2 text-base',
    icon: 'w-6 h-6 p-0',
  };

  const formatCount = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  // Icon-only button for TikTok-style feed
  if (size === 'icon') {
    return (
      <button
        onClick={handleFollow}
        disabled={loading}
        className={`
          w-6 h-6 rounded-full flex items-center justify-center transition-all
          ${isFollowing
            ? 'bg-gray-600 text-white'
            : 'bg-red-500 text-white hover:bg-red-600'
          }
          ${loading ? 'opacity-50 cursor-not-allowed' : ''}
        `}
        title={isFollowing ? 'Unfollow' : 'Follow'}
      >
        {loading ? (
          <svg className="animate-spin h-3 w-3" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
        ) : isFollowing ? (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        ) : (
          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={3}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
          </svg>
        )}
      </button>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={handleFollow}
        disabled={loading}
        className={`
          ${sizeClasses[size]}
          font-medium rounded-full transition-all
          ${isFollowing
            ? 'bg-gray-700 text-white hover:bg-gray-600 border border-gray-600'
            : 'bg-purple-600 text-white hover:bg-purple-700'
          }
          ${loading ? 'opacity-50 cursor-not-allowed' : ''}
          flex items-center gap-1.5
        `}
      >
        {loading ? (
          <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
        ) : isFollowing ? (
          <>
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            <span>Suivi</span>
          </>
        ) : (
          <>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            <span>Suivre</span>
          </>
        )}
      </button>

      {showCount && (
        <span className="text-gray-400 text-sm">
          {formatCount(count)} {count === 1 ? 'abonné' : 'abonnés'}
        </span>
      )}
    </div>
  );
};

export default FollowButton;
