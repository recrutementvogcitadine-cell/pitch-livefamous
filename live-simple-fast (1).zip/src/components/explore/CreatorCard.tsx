import React from 'react';
import { useNavigate } from 'react-router-dom';
import FollowButton from '@/components/FollowButton';
import { VerificationBadge } from '@/components/VerificationBadge';

export interface CreatorCardData {
  id: string;
  user_id?: string;
  username: string;
  display_name: string;
  bio: string | null;
  avatar_url: string | null;
  is_verified: boolean;
  followers_count: number;
  total_views: number;
  category?: string;
  created_at?: string;
  live_count?: number;
}

interface CreatorCardProps {
  creator: CreatorCardData;
  onFollowChange?: (creatorId: string, isFollowing: boolean) => void;
}

const FALLBACK_AVATARS = [
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471962230_9ffb24ac.jpg',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471963594_5644eaf8.jpg',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471964934_c0e82b9f.jpg',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471969898_3fdcbee1.png',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471971304_bb185e18.png',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471972611_77eb0e03.png',
];

function getAvatarFallback(id: string): string {
  const hash = id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return FALLBACK_AVATARS[hash % FALLBACK_AVATARS.length];
}

function formatCount(num: number): string {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
}

const CreatorCard: React.FC<CreatorCardProps> = ({ creator, onFollowChange }) => {
  const navigate = useNavigate();

  const handleCardClick = () => {
    navigate(`/creator/${creator.username}`);
  };

  const handleFollowChange = (isFollowing: boolean) => {
    onFollowChange?.(creator.id, isFollowing);
  };

  return (
    <div
      className="group relative bg-gray-900/60 border border-white/5 rounded-2xl overflow-hidden hover:border-purple-500/30 hover:bg-gray-900/80 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/5 cursor-pointer"
      onClick={handleCardClick}
    >
      {/* Cover gradient */}
      <div className="h-24 bg-gradient-to-br from-purple-600/30 via-pink-500/20 to-orange-500/30 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDE4YzAtOS45NC04LjA2LTE4LTE4LTE4UzAgOC4wNiAwIDE4IDE4IDM2IDE4IDM2IDM2IDI3Ljk0IDM2IDE4Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-50" />
        
        {/* Category badge */}
        {creator.category && (
          <span className="absolute top-3 right-3 bg-black/40 backdrop-blur-sm text-white/80 text-[10px] font-medium px-2.5 py-1 rounded-full capitalize">
            {creator.category}
          </span>
        )}
      </div>

      {/* Avatar */}
      <div className="flex justify-center -mt-12 relative z-10">
        <div className="relative">
          <div className="w-20 h-20 rounded-full overflow-hidden border-4 border-gray-900 group-hover:border-purple-500/50 transition-colors shadow-xl">
            <img
              src={creator.avatar_url || getAvatarFallback(creator.id)}
              alt={creator.display_name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              onError={(e) => {
                (e.target as HTMLImageElement).src = getAvatarFallback(creator.id);
              }}
            />
          </div>
          {creator.is_verified && (
            <div className="absolute -bottom-0.5 -right-0.5">
              <VerificationBadge isVerified={true} size="md" showTooltip={false} />
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="px-4 pt-3 pb-4 text-center">
        {/* Name + verification */}
        <div className="flex items-center justify-center gap-1 mb-0.5">
          <h3 className="text-white font-semibold text-sm truncate max-w-[140px]">
            {creator.display_name}
          </h3>
        </div>
        <p className="text-gray-500 text-xs mb-3">@{creator.username}</p>

        {/* Bio */}
        {creator.bio && (
          <p className="text-gray-400 text-xs line-clamp-2 mb-3 leading-relaxed min-h-[2rem]">
            {creator.bio}
          </p>
        )}

        {/* Stats */}
        <div className="flex items-center justify-center gap-4 mb-4">
          <div className="text-center">
            <div className="flex items-center gap-1 text-white font-semibold text-sm">
              <svg className="w-3.5 h-3.5 text-purple-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
              </svg>
              {formatCount(creator.followers_count)}
            </div>
            <p className="text-gray-600 text-[10px] mt-0.5">Abonnés</p>
          </div>
          <div className="w-px h-6 bg-gray-800" />
          <div className="text-center">
            <div className="flex items-center gap-1 text-white font-semibold text-sm">
              <svg className="w-3.5 h-3.5 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              {formatCount(creator.total_views)}
            </div>
            <p className="text-gray-600 text-[10px] mt-0.5">Vues</p>
          </div>
        </div>

        {/* Follow Button */}
        <div onClick={(e) => e.stopPropagation()}>
          <FollowButton
            creatorId={creator.user_id || creator.id}
            creatorName={creator.display_name}
            followerCount={creator.followers_count}
            showCount={false}
            size="sm"
            onFollowChange={handleFollowChange}
          />
        </div>
      </div>
    </div>
  );
};

export default CreatorCard;
