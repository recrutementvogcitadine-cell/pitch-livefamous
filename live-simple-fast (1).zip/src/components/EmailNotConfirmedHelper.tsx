
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, getAuthProvidersUrl, getAuthSettingsUrl, getProjectRef, getEdgeFunctionSecretsUrl, getEdgeFunctionsUrl } from '@/lib/supabase';
import {
  Mail, ExternalLink, AlertTriangle, CheckCircle, Loader2,
  Settings, ArrowRight, RefreshCw, Shield, Copy, ChevronDown, ChevronUp,
  FileText, AlertCircle, Lock, Zap, Eye, EyeOff, UserCheck, Server,
} from 'lucide-react';



export type EmailErrorType = 'email_not_confirmed' | 'email_sending_failed';

interface EmailNotConfirmedHelperProps {
  email: string;
  errorType?: EmailErrorType;
  onDismiss?: () => void;
}

const EmailNotConfirmedHelper: React.FC<EmailNotConfirmedHelperProps> = ({
  email,
  errorType = 'email_not_confirmed',
  onDismiss,
}) => {
  const navigate = useNavigate();
  const [isResending, setIsResending] = useState(false);
  const [resendResult, setResendResult] = useState<{ success: boolean; message: string } | null>(null);
  const [showDisableGuide, setShowDisableGuide] = useState(false);
  const [showSmtpGuide, setShowSmtpGuide] = useState(false);

  // Manual confirmation state
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);
  const [confirmResult, setConfirmResult] = useState<{ success: boolean; message: string; alreadyConfirmed?: boolean } | null>(null);

  const authProvidersUrl = getAuthProvidersUrl();
  const authSettingsUrl = getAuthSettingsUrl();
  const projectRef = getProjectRef();

  const isSendingError = errorType === 'email_sending_failed';

  // ============================================================================
  // MANUAL EMAIL CONFIRMATION — calls the confirm-user-email edge function
  // ============================================================================
  const handleManualConfirmation = async () => {
    if (!email || !confirmPassword) return;

    setIsConfirming(true);
    setConfirmResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('confirm-user-email', {
        body: {
          email: email.trim(),
          password: confirmPassword,
        },
      });

      if (error) {
        // Edge function invocation error — detect specific failure types
        let errorMessage = 'Erreur lors de la confirmation. Veuillez réessayer.';
        
        if (typeof error === 'object' && error !== null) {
          const errObj = error as any;
          const errMsg = (errObj.message || errObj.error || '').toLowerCase();
          
          // Edge function not deployed or not found
          if (errMsg.includes('not found') || errMsg.includes('404') || errMsg.includes('function not found') || errMsg.includes('relay error')) {
            errorMessage = "La fonction de confirmation n'est pas déployée sur votre projet Supabase. Veuillez déployer la fonction 'confirm-user-email' ou utiliser l'option 2 (désactiver la confirmation email) ci-dessous.";
          }
          // Missing secrets / service_role key
          else if (errMsg.includes('service_role') || errMsg.includes('secret') || errMsg.includes('unauthorized') || errMsg.includes('401')) {
            errorMessage = "La clé service_role n'est pas configurée. Les secrets SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont normalement disponibles automatiquement dans les Edge Functions. Si l'erreur persiste, vérifiez la configuration de votre fonction.";
          }
          // Network / timeout errors
          else if (errMsg.includes('timeout') || errMsg.includes('network') || errMsg.includes('fetch') || errMsg.includes('503')) {
            errorMessage = "Le serveur ne répond pas. Vérifiez votre connexion internet et réessayez.";
          }
          // Boot error (function code error)
          else if (errMsg.includes('boot') || errMsg.includes('500') || errMsg.includes('internal')) {
            errorMessage = "Erreur interne de la fonction serveur. Vérifiez les logs de la fonction dans le Dashboard Supabase > Edge Functions.";
          }
          // Generic error with message
          else if (errObj.message && errObj.message.trim()) {
            errorMessage = errObj.message;
          }
        }

        setConfirmResult({
          success: false,
          message: errorMessage,
        });
        return;
      }

      if (data?.success) {
        setConfirmResult({
          success: true,
          message: data.message || 'Email confirmé avec succès ! Vous pouvez maintenant vous connecter.',
          alreadyConfirmed: data.already_confirmed || false,
        });
        setConfirmPassword('');
      } else {
        // Function returned but with an error in the response body
        let errorMessage = data?.error || 'Erreur lors de la confirmation. Veuillez réessayer.';
        
        // Check for specific error patterns in the response
        const errLower = (errorMessage || '').toLowerCase();
        if (errLower.includes('service_role') || errLower.includes('not configured')) {
          errorMessage = "La clé service_role n'est pas disponible. Vérifiez que la fonction Edge est correctement déployée sur votre projet Supabase.";
        }
        
        setConfirmResult({
          success: false,
          message: errorMessage,
        });
      }
    } catch (err: any) {
      console.error('[ManualConfirm] Error:', err);
      const errMsg = (err?.message || '').toLowerCase();
      let errorMessage = 'Erreur inattendue. Veuillez réessayer.';
      
      if (errMsg.includes('not found') || errMsg.includes('404')) {
        errorMessage = "La fonction 'confirm-user-email' n'est pas déployée. Utilisez l'option 2 (désactiver la confirmation email) comme alternative.";
      } else if (errMsg.includes('network') || errMsg.includes('fetch') || errMsg.includes('failed')) {
        errorMessage = "Erreur réseau. Vérifiez votre connexion internet et réessayez.";
      } else if (err?.message) {
        errorMessage = err.message;
      }
      
      setConfirmResult({
        success: false,
        message: errorMessage,
      });
    } finally {
      setIsConfirming(false);
    }
  };


  const handleResendConfirmation = async () => {
    if (!email) return;

    setIsResending(true);
    setResendResult(null);

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email,
      });

      if (error) {
        if (error.message?.toLowerCase().includes('rate') || error.message?.toLowerCase().includes('security')) {
          setResendResult({
            success: false,
            message: 'Trop de tentatives. Veuillez patienter quelques minutes avant de réessayer.',
          });
        } else if (error.message?.toLowerCase().includes('sending') || error.message?.toLowerCase().includes('smtp')) {
          setResendResult({
            success: false,
            message: "Le service d'email a échoué à nouveau. Utilisez la confirmation manuelle ou désactivez la confirmation email (voir ci-dessus).",
          });
        } else {
          setResendResult({
            success: false,
            message: error.message || 'Erreur lors du renvoi. Veuillez réessayer.',
          });
        }
      } else {
        setResendResult({
          success: true,
          message: `Email de confirmation renvoyé à ${email}. Vérifiez votre boîte de réception et vos spams.`,
        });
      }
    } catch (err: any) {
      setResendResult({
        success: false,
        message: err?.message || 'Erreur inattendue. Veuillez réessayer.',
      });
    } finally {
      setIsResending(false);
    }
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url).catch(() => {
      window.open(url, '_blank');
    });
  };

  // ============================================================================
  // HEADER — different for each error type
  // ============================================================================
  const headerConfig = isSendingError
    ? {
        icon: <AlertCircle className="w-4 h-4 text-red-400" />,
        bgClass: 'bg-red-500/10 border-red-500/20',
        iconBgClass: 'bg-red-500/20',
        titleClass: 'text-red-300',
        subtitleClass: 'text-red-300/70',
        borderClass: 'border-red-500/30',
        gradientClass: 'from-red-500/5 to-orange-500/5',
        title: "Erreur d'envoi de l'email de confirmation",
        subtitle: "Le service d'email intégré de Supabase n'a pas pu envoyer l'email",
      }
    : {
        icon: <Mail className="w-4 h-4 text-amber-400" />,
        bgClass: 'bg-amber-500/10 border-amber-500/20',
        iconBgClass: 'bg-amber-500/20',
        titleClass: 'text-amber-300',
        subtitleClass: 'text-amber-300/70',
        borderClass: 'border-amber-500/30',
        gradientClass: 'from-amber-500/5 to-orange-500/5',
        title: 'Email non confirmé',
        subtitle: 'Votre compte nécessite une confirmation par email',
      };

  // ============================================================================
  // MANUAL CONFIRMATION SECTION (shared between both error types)
  // ============================================================================
  const renderManualConfirmation = (optionNumber: number, isHighlighted: boolean) => (
    <div className={`bg-gray-800/50 rounded-xl p-4 space-y-3 border ${
      isHighlighted
        ? 'border-emerald-500/30 ring-1 ring-emerald-500/10'
        : 'border-gray-700/50'
    }`}>
      <div className="flex items-center gap-2">
        <div className={`w-6 h-6 rounded-full ${
          isHighlighted ? 'bg-emerald-500/20' : 'bg-cyan-500/20'
        } flex items-center justify-center flex-shrink-0`}>
          <span className={`${
            isHighlighted ? 'text-emerald-400' : 'text-cyan-400'
          } text-xs font-bold`}>{optionNumber}</span>
        </div>
        <h5 className="text-white font-medium text-sm">Confirmer mon email maintenant</h5>
        {isHighlighted && (
          <span className="text-emerald-400 text-xs ml-auto font-medium bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 flex items-center gap-1">
            <Zap className="w-3 h-3" />
            Solution immédiate
          </span>
        )}
      </div>

      <p className="text-gray-400 text-xs leading-relaxed pl-8">
        Confirmez votre email directement sans attendre l'email de confirmation.
        Entrez votre mot de passe pour vérifier votre identité, puis votre email sera confirmé automatiquement.
      </p>

      {/* Security note */}
      <div className="ml-8 bg-blue-500/5 border border-blue-500/15 rounded-lg p-2.5 flex items-start gap-2">
        <Shield className="w-3.5 h-3.5 text-blue-400 flex-shrink-0 mt-0.5" />
        <p className="text-blue-300/70 text-[11px] leading-relaxed">
          <span className="font-medium text-blue-300">Sécurisé :</span> Votre mot de passe est vérifié côté serveur pour confirmer votre identité. Seul le propriétaire du compte peut confirmer son email.
        </p>
      </div>

      {/* Success result */}
      {confirmResult?.success && (
        <div className="ml-8 rounded-lg p-3 bg-green-500/10 border border-green-500/20 space-y-2">
          <div className="flex items-start gap-2">
            <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-green-300 text-sm font-medium">{confirmResult.message}</p>
              {!confirmResult.alreadyConfirmed && (
                <p className="text-green-300/70 text-xs mt-1">
                  Fermez cette fenêtre et reconnectez-vous avec votre email et mot de passe.
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 pt-1">
            <UserCheck className="w-4 h-4 text-green-400" />
            <span className="text-green-300/80 text-xs font-mono">{email}</span>
          </div>
        </div>
      )}

      {/* Error result */}
      {confirmResult && !confirmResult.success && (
        <div className="ml-8 rounded-lg p-3 bg-red-500/10 border border-red-500/20 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
          <p className="text-red-300 text-xs leading-relaxed">{confirmResult.message}</p>
        </div>
      )}

      {/* Password input + confirm button (hide after success) */}
      {!confirmResult?.success && (
        <div className="ml-8 space-y-3">
          {/* Email display */}
          <div className="bg-gray-900/60 rounded-lg p-2.5 flex items-center gap-2">
            <Mail className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
            <span className="text-gray-400 text-xs">Email :</span>
            <span className="text-gray-300 text-xs font-mono">{email}</span>
          </div>

          {/* Password field */}
          <div className="space-y-1.5">
            <label className="text-gray-400 text-xs font-medium flex items-center gap-1.5">
              <Lock className="w-3 h-3" />
              Mot de passe de votre compte
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => {
                  setConfirmPassword(e.target.value);
                  setConfirmResult(null);
                }}
                placeholder="Entrez votre mot de passe"
                className="w-full bg-gray-900/80 border border-gray-700/50 rounded-lg px-3 py-2.5 text-white text-sm placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500/40 transition-all pr-10"
                autoComplete="current-password"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && confirmPassword.length >= 6) {
                    e.preventDefault();
                    handleManualConfirmation();
                  }
                }}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {confirmPassword.length > 0 && confirmPassword.length < 6 && (
              <p className="text-amber-400/70 text-[11px] flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Le mot de passe doit contenir au moins 6 caractères
              </p>
            )}
          </div>

          {/* Confirm button */}
          <button
            onClick={handleManualConfirmation}
            disabled={isConfirming || confirmPassword.length < 6}
            className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all shadow-lg ${
              isHighlighted
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-emerald-500/20 text-white disabled:from-gray-700 disabled:to-gray-700 disabled:shadow-none'
                : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 shadow-cyan-500/20 text-white disabled:from-gray-700 disabled:to-gray-700 disabled:shadow-none'
            } disabled:cursor-not-allowed disabled:text-gray-400`}
          >
            {isConfirming ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Vérification en cours...
              </>
            ) : (
              <>
                <UserCheck className="w-4 h-4" />
                Confirmer mon email
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className={`rounded-xl border ${headerConfig.borderClass} bg-gradient-to-br ${headerConfig.gradientClass} overflow-hidden`}>
      {/* Header */}
      <div className={`px-4 py-3 ${headerConfig.bgClass} border-b flex items-center gap-3`}>
        <div className={`w-8 h-8 rounded-lg ${headerConfig.iconBgClass} flex items-center justify-center flex-shrink-0`}>
          {headerConfig.icon}
        </div>
        <div className="flex-1 min-w-0">
          <h4 className={`${headerConfig.titleClass} font-semibold text-sm`}>{headerConfig.title}</h4>
          <p className={`${headerConfig.subtitleClass} text-xs`}>{headerConfig.subtitle}</p>
        </div>
        {onDismiss && (
          <button
            onClick={onDismiss}
            className="text-gray-400/50 hover:text-gray-300 transition-colors p-1"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      <div className="p-4 space-y-4">
        {/* Explanation for sending error */}
        {isSendingError && (
          <div className="bg-red-500/5 border border-red-500/15 rounded-lg p-3 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
            <div className="text-red-300/80 text-xs leading-relaxed space-y-1">
              <p>
                <span className="font-semibold text-red-300">Pourquoi cette erreur ?</span> Le service d'email intégré de Supabase a des limites de débit strictes (environ 4 emails/heure) et peut échouer. Cela arrive fréquemment lors de la première configuration.
              </p>
              <p>
                <span className="font-semibold text-red-300">Votre compte a été créé</span> mais l'email de confirmation n'a pas pu être envoyé. Choisissez une solution ci-dessous pour continuer.
              </p>
            </div>
          </div>
        )}

        {/* Options intro */}
        <p className="text-gray-300 text-sm leading-relaxed">
          {isSendingError
            ? 'Choisissez la solution la plus adaptée à votre situation :'
            : 'Vous avez plusieurs options pour résoudre ce problème :'}
        </p>

        {/* ==================== SENDING ERROR OPTIONS ==================== */}
        {isSendingError ? (
          <>
            {/* ---- SENDING ERROR: Option 1 = Manual email confirmation (HIGHLIGHTED) ---- */}
            {renderManualConfirmation(1, true)}

            {/* ---- SENDING ERROR: Option 2 = Disable email confirmation ---- */}
            <div className="bg-gray-800/50 rounded-xl p-4 space-y-3 border border-gray-700/50">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-amber-400 text-xs font-bold">2</span>
                </div>
                <h5 className="text-white font-medium text-sm">Désactiver la confirmation email</h5>
                <span className="text-gray-500 text-xs ml-auto">(via Dashboard)</span>
              </div>

              <p className="text-gray-400 text-xs leading-relaxed pl-8">
                Désactivez la vérification d'email dans Supabase pour pouvoir vous connecter immédiatement.
                C'est une alternative si la confirmation manuelle ne fonctionne pas.
              </p>

              {/* Toggle guide */}
              <div className="pl-8">
                <button
                  onClick={() => setShowDisableGuide(!showDisableGuide)}
                  className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 text-sm font-medium transition-colors"
                >
                  {showDisableGuide ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  {showDisableGuide ? 'Masquer le guide' : 'Voir le guide étape par étape'}
                </button>
              </div>

              {showDisableGuide && (
                <div className="ml-8 space-y-3">
                  <div className="bg-gray-900/60 rounded-lg p-4 space-y-3 border border-gray-700/30">
                    {[
                      {
                        step: 1,
                        title: 'Ouvrez le Dashboard Supabase',
                        desc: (
                          <span>
                            Connectez-vous à{' '}
                            <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 underline">
                              supabase.com/dashboard
                            </a>
                          </span>
                        ),
                      },
                      {
                        step: 2,
                        title: 'Allez dans Authentication > Providers',
                        desc: (
                          <span>
                            Menu latéral : <span className="font-mono text-gray-400">Authentication</span>
                            <ArrowRight className="w-3 h-3 inline mx-1" />
                            <span className="font-mono text-gray-400">Providers</span>
                          </span>
                        ),
                      },
                      {
                        step: 3,
                        title: 'Cliquez sur "Email"',
                        desc: "Dans la section des fournisseurs d'authentification",
                      },
                      {
                        step: 4,
                        title: 'Désactivez "Confirm email"',
                        desc: (
                          <span>
                            Décochez l'option{' '}
                            <span className="font-mono text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded">Confirm email</span>
                            {' '}puis cliquez sur <span className="font-semibold text-gray-400">Save</span>
                          </span>
                        ),
                      },
                      {
                        step: 5,
                        title: 'Réessayez de vous connecter',
                        desc: 'Revenez ici et essayez de vous connecter à nouveau',
                      },
                    ].map((item) => (
                      <div key={item.step} className="flex items-start gap-3">
                        <div className={`w-5 h-5 rounded-full ${item.step === 4 ? 'bg-amber-500/20' : item.step === 5 ? 'bg-green-500/20' : 'bg-purple-500/20'} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                          <span className={`${item.step === 4 ? 'text-amber-400' : item.step === 5 ? 'text-green-400' : 'text-purple-400'} text-[10px] font-bold`}>{item.step}</span>
                        </div>
                        <div>
                          <p className="text-gray-300 text-xs font-medium">{item.title}</p>
                          <p className="text-gray-500 text-xs">{typeof item.desc === 'string' ? item.desc : item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Direct link button */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <a
                      href={authProvidersUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white text-sm font-medium transition-all shadow-lg shadow-amber-500/20"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Ouvrir Authentication &gt; Providers
                    </a>
                    <button
                      onClick={() => handleCopyUrl(authProvidersUrl)}
                      className="inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-gray-700 hover:bg-gray-600 text-gray-300 text-sm transition-colors"
                      title="Copier le lien"
                    >
                      <Copy className="w-4 h-4" />
                      Copier le lien
                    </button>
                  </div>

                  {/* URL preview */}
                  {projectRef && (
                    <div className="bg-gray-900/80 rounded-lg p-2.5 flex items-center gap-2 overflow-hidden">
                      <Settings className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
                      <code className="text-gray-400 text-[10px] font-mono truncate">{authProvidersUrl}</code>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* ---- SENDING ERROR: Option 3 = Configure SMTP ---- */}
            <div className="bg-gray-800/50 rounded-xl p-4 space-y-3 border border-gray-700/50">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-400 text-xs font-bold">3</span>
                </div>
                <h5 className="text-white font-medium text-sm">Configurer un SMTP personnalisé</h5>
                <span className="text-gray-500 text-xs ml-auto">(production)</span>
              </div>

              <p className="text-gray-400 text-xs leading-relaxed pl-8">
                Pour la production, configurez un serveur SMTP dédié (Resend, SendGrid, Mailgun...) 
                pour envoyer des emails de manière fiable sans les limites du service intégré de Supabase.
              </p>

              {/* Toggle SMTP guide */}
              <div className="pl-8">
                <button
                  onClick={() => setShowSmtpGuide(!showSmtpGuide)}
                  className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 text-sm font-medium transition-colors"
                >
                  {showSmtpGuide ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  {showSmtpGuide ? 'Masquer les détails' : 'Voir comment configurer SMTP'}
                </button>
              </div>

              {showSmtpGuide && (
                <div className="ml-8 space-y-3">
                  <div className="bg-gray-900/60 rounded-lg p-4 space-y-3 border border-gray-700/30">
                    {[
                      {
                        step: 1,
                        text: (
                          <span>
                            Allez dans{' '}
                            <span className="font-mono text-blue-300 bg-blue-500/10 px-1.5 py-0.5 rounded">Project Settings</span>
                            <ArrowRight className="w-3 h-3 inline mx-1 text-gray-500" />
                            <span className="font-mono text-blue-300 bg-blue-500/10 px-1.5 py-0.5 rounded">Authentication</span>
                          </span>
                        ),
                      },
                      {
                        step: 2,
                        text: (
                          <span>
                            Faites défiler jusqu'à{' '}
                            <span className="font-mono text-blue-300 bg-blue-500/10 px-1.5 py-0.5 rounded">SMTP Settings</span>
                          </span>
                        ),
                      },
                      {
                        step: 3,
                        text: (
                          <span>
                            Activez <span className="font-semibold text-blue-300">"Enable Custom SMTP"</span> et remplissez les champs avec les informations de votre fournisseur
                          </span>
                        ),
                      },
                    ].map((item) => (
                      <div key={item.step} className="flex items-start gap-2 pl-1">
                        <div className="w-5 h-5 rounded-full bg-blue-500/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-blue-400 text-[10px] font-bold">{item.step}</span>
                        </div>
                        <p className="text-gray-400 text-xs leading-relaxed">{item.text}</p>
                      </div>
                    ))}
                  </div>

                  {/* Recommended providers */}
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { name: 'Resend', desc: 'Gratuit 3K/mois', url: 'https://resend.com', color: 'border-blue-500/20' },
                      { name: 'SendGrid', desc: 'Gratuit 100/jour', url: 'https://sendgrid.com', color: 'border-cyan-500/20' },
                      { name: 'Mailgun', desc: '5K gratuits', url: 'https://mailgun.com', color: 'border-red-500/20' },
                    ].map((p) => (
                      <a
                        key={p.name}
                        href={p.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`rounded-lg border ${p.color} bg-gray-900/40 p-2.5 hover:bg-gray-800/40 transition-colors block text-center`}
                      >
                        <p className="text-white text-xs font-semibold">{p.name}</p>
                        <p className="text-gray-500 text-[10px]">{p.desc}</p>
                      </a>
                    ))}
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <a
                      href={authSettingsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 text-blue-300 text-sm font-medium transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Ouvrir SMTP Settings
                    </a>
                  </div>
                </div>
              )}
            </div>

            {/* ---- SENDING ERROR: Option 4 = Retry resend ---- */}
            <div className="bg-gray-800/50 rounded-xl p-4 space-y-3 border border-gray-700/50">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-gray-600/30 flex items-center justify-center flex-shrink-0">
                  <span className="text-gray-400 text-xs font-bold">4</span>
                </div>
                <h5 className="text-white font-medium text-sm">Réessayer l'envoi</h5>
                <span className="text-gray-500 text-xs ml-auto">(peut échouer à nouveau)</span>
              </div>

              <p className="text-gray-400 text-xs leading-relaxed pl-8">
                Si l'erreur était temporaire, vous pouvez tenter de renvoyer l'email.
                Attention : le service intégré de Supabase a des limites strictes.
              </p>

              {/* Resend result */}
              {resendResult && (
                <div className={`ml-8 rounded-lg p-3 flex items-start gap-2 ${
                  resendResult.success
                    ? 'bg-green-500/10 border border-green-500/20'
                    : 'bg-red-500/10 border border-red-500/20'
                }`}>
                  {resendResult.success ? (
                    <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                  )}
                  <p className={`text-xs leading-relaxed ${resendResult.success ? 'text-green-300' : 'text-red-300'}`}>
                    {resendResult.message}
                  </p>
                </div>
              )}

              <div className="pl-8">
                <button
                  onClick={handleResendConfirmation}
                  disabled={isResending}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:cursor-not-allowed text-gray-300 text-sm font-medium transition-colors"
                >
                  {isResending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Envoi en cours...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4" />
                      Tenter de renvoyer l'email
                    </>
                  )}
                </button>
              </div>

              {email && (
                <p className="text-gray-500 text-xs mt-1 flex items-center gap-1 pl-8">
                  <Mail className="w-3 h-3" />
                  Sera envoyé à : <span className="text-gray-400 font-mono">{email}</span>
                </p>
              )}
            </div>
          </>
        ) : (
          <>
            {/* ==================== NOT CONFIRMED: Option 1 = Resend email ==================== */}
            <div className="bg-gray-800/50 rounded-xl p-4 space-y-3 border border-gray-700/50">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-400 text-xs font-bold">1</span>
                </div>
                <h5 className="text-white font-medium text-sm">Confirmer votre email</h5>
                <span className="text-gray-500 text-xs ml-auto">(recommandé)</span>
              </div>

              <p className="text-gray-400 text-xs leading-relaxed pl-8">
                Vérifiez votre boîte de réception (et les spams) pour l'email de confirmation.
                Si vous ne l'avez pas reçu, cliquez ci-dessous pour le renvoyer.
              </p>

              {/* Resend result */}
              {resendResult && (
                <div className={`ml-8 rounded-lg p-3 flex items-start gap-2 ${
                  resendResult.success
                    ? 'bg-green-500/10 border border-green-500/20'
                    : 'bg-red-500/10 border border-red-500/20'
                }`}>
                  {resendResult.success ? (
                    <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                  )}
                  <p className={`text-xs leading-relaxed ${resendResult.success ? 'text-green-300' : 'text-red-300'}`}>
                    {resendResult.message}
                  </p>
                </div>
              )}

              <div className="pl-8 flex flex-wrap items-center gap-2">
                <button
                  onClick={handleResendConfirmation}
                  disabled={isResending}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors shadow-lg shadow-blue-500/20"
                >
                  {isResending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Envoi en cours...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4" />
                      Renvoyer l'email de confirmation
                    </>
                  )}
                </button>
              </div>

              {email && (
                <p className="text-gray-500 text-xs mt-2 flex items-center gap-1 pl-8">
                  <Mail className="w-3 h-3" />
                  Sera envoyé à : <span className="text-gray-400 font-mono">{email}</span>
                </p>
              )}

              {/* Link to email templates guide */}
              <div className="pl-8 pt-1">
                <button
                  onClick={() => navigate('/setup/email-templates')}
                  className="inline-flex items-center gap-1.5 text-purple-400 hover:text-purple-300 text-xs font-medium transition-colors group"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span className="underline underline-offset-2 decoration-purple-400/40 group-hover:decoration-purple-300">
                    Personnaliser les templates d'emails
                  </span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>

            {/* ==================== NOT CONFIRMED: Option 2 = Manual confirmation ==================== */}
            {renderManualConfirmation(2, false)}

            {/* ==================== NOT CONFIRMED: Option 3 = Disable email confirmation ==================== */}
            <div className="bg-gray-800/50 rounded-xl p-4 space-y-3 border border-gray-700/50">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-amber-400 text-xs font-bold">3</span>
                </div>
                <h5 className="text-white font-medium text-sm">Désactiver la confirmation email</h5>
                <span className="text-gray-500 text-xs ml-auto">(développement)</span>
              </div>

              <p className="text-gray-400 text-xs leading-relaxed pl-8">
                Pour un environnement de développement ou de test, vous pouvez désactiver
                la vérification d'email dans les paramètres Supabase.
              </p>

              {/* Toggle detailed guide */}
              <div className="pl-8">
                <button
                  onClick={() => setShowDisableGuide(!showDisableGuide)}
                  className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 text-sm font-medium transition-colors"
                >
                  {showDisableGuide ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                  {showDisableGuide ? 'Masquer le guide' : 'Voir le guide étape par étape'}
                </button>
              </div>

              {showDisableGuide && (
                <div className="ml-8 space-y-3">
                  <div className="bg-gray-900/60 rounded-lg p-4 space-y-3 border border-gray-700/30">
                    {[
                      {
                        step: 1,
                        title: 'Ouvrez le Dashboard Supabase',
                        desc: (
                          <span>
                            Connectez-vous à{' '}
                            <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 underline">
                              supabase.com/dashboard
                            </a>
                          </span>
                        ),
                      },
                      {
                        step: 2,
                        title: 'Allez dans Authentication > Providers',
                        desc: (
                          <span>
                            Menu latéral : <span className="font-mono text-gray-400">Authentication</span>
                            <ArrowRight className="w-3 h-3 inline mx-1" />
                            <span className="font-mono text-gray-400">Providers</span>
                          </span>
                        ),
                      },
                      {
                        step: 3,
                        title: 'Cliquez sur "Email"',
                        desc: "Dans la section des fournisseurs d'authentification",
                      },
                      {
                        step: 4,
                        title: 'Désactivez "Confirm email"',
                        desc: (
                          <span>
                            Décochez l'option{' '}
                            <span className="font-mono text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded">Confirm email</span>
                            {' '}puis cliquez sur <span className="font-semibold text-gray-400">Save</span>
                          </span>
                        ),
                      },
                      {
                        step: 5,
                        title: 'Réessayez de vous connecter',
                        desc: 'Revenez ici et essayez de vous connecter à nouveau',
                      },
                    ].map((item) => (
                      <div key={item.step} className="flex items-start gap-3">
                        <div className={`w-5 h-5 rounded-full ${item.step === 4 ? 'bg-amber-500/20' : item.step === 5 ? 'bg-green-500/20' : 'bg-purple-500/20'} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                          <span className={`${item.step === 4 ? 'text-amber-400' : item.step === 5 ? 'text-green-400' : 'text-purple-400'} text-[10px] font-bold`}>{item.step}</span>
                        </div>
                        <div>
                          <p className="text-gray-300 text-xs font-medium">{item.title}</p>
                          <p className="text-gray-500 text-xs">{typeof item.desc === 'string' ? item.desc : item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Direct link button */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <a
                      href={authProvidersUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white text-sm font-medium transition-all shadow-lg shadow-amber-500/20"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Ouvrir Authentication &gt; Providers
                    </a>
                    <button
                      onClick={() => handleCopyUrl(authProvidersUrl)}
                      className="inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-gray-700 hover:bg-gray-600 text-gray-300 text-sm transition-colors"
                      title="Copier le lien"
                    >
                      <Copy className="w-4 h-4" />
                      Copier le lien
                    </button>
                  </div>

                  {/* URL preview */}
                  {projectRef && (
                    <div className="bg-gray-900/80 rounded-lg p-2.5 flex items-center gap-2 overflow-hidden">
                      <Settings className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
                      <code className="text-gray-400 text-[10px] font-mono truncate">{authProvidersUrl}</code>
                    </div>
                  )}

                  {/* Security warning */}
                  <div className="bg-red-500/5 border border-red-500/20 rounded-lg p-3 flex items-start gap-2">
                    <Shield className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                    <p className="text-red-300/80 text-xs leading-relaxed">
                      <span className="font-semibold text-red-300">Attention :</span>{' '}
                      Désactiver la confirmation email est recommandé uniquement pour le développement.
                      En production, gardez-la activée pour la sécurité de vos utilisateurs.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </>
        )}

        {/* ==================== Security warning for sending error ==================== */}
        {isSendingError && (
          <div className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-3 flex items-start gap-2">
            <Shield className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <p className="text-amber-300/80 text-xs leading-relaxed">
              <span className="font-semibold text-amber-300">Note :</span>{' '}
              Désactiver la confirmation email est recommandé uniquement pour le développement.
              En production, configurez un SMTP personnalisé pour des emails fiables.
            </p>
          </div>
        )}

        {/* ==================== LINK TO EMAIL TEMPLATES GUIDE ==================== */}
        <div className="bg-purple-500/5 border border-purple-500/20 rounded-xl p-4 flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
            <FileText className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex-1 min-w-0">
            <h5 className="text-purple-300 font-medium text-sm mb-1">Personnaliser les emails</h5>
            <p className="text-purple-300/60 text-xs leading-relaxed mb-2">
              {isSendingError
                ? "Configurez un SMTP personnalisé et personnalisez les templates d'emails de confirmation, réinitialisation de mot de passe et lien magique avec des modèles en français."
                : "Vous pouvez personnaliser les templates d'emails de confirmation, réinitialisation de mot de passe et lien magique avec des modèles en français."}
            </p>
            <button
              onClick={() => navigate('/setup/email-templates')}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 text-purple-300 text-xs font-medium transition-colors group"
            >
              <Mail className="w-3.5 h-3.5" />
              Guide de configuration des emails
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailNotConfirmedHelper;
