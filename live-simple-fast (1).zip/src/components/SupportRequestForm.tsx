import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import { MessageSquare, Send, AlertCircle } from 'lucide-react';

interface SupportRequestFormProps {
  isOpen: boolean;
  onClose: () => void;
}

const SupportRequestForm: React.FC<SupportRequestFormProps> = ({ isOpen, onClose }) => {
  const { creatorProfile } = useAppContext();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<'low' | 'normal' | 'high' | 'urgent'>('normal');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!creatorProfile) {
      toast({
        title: 'Erreur',
        description: 'Vous devez avoir un profil créateur pour soumettre une demande',
        variant: 'destructive'
      });
      return;
    }

    if (!subject.trim() || !message.trim()) {
      toast({
        title: 'Erreur',
        description: 'Veuillez remplir tous les champs',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('support_requests')
        .insert({
          creator_id: creatorProfile.id,
          subject: subject.trim(),
          message: message.trim(),
          priority,
          status: 'open'
        });

      if (error) throw error;

      toast({
        title: 'Demande envoyée',
        description: 'Notre équipe vous répondra dans les plus brefs délais'
      });

      setSubject('');
      setMessage('');
      setPriority('normal');
      onClose();
    } catch (err: any) {
      toast({
        title: 'Erreur',
        description: err.message || 'Impossible d\'envoyer la demande',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-purple-600" />
            Contacter le support
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="subject">Sujet</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Décrivez brièvement votre problème"
              required
            />
          </div>

          <div>
            <Label htmlFor="priority">Priorité</Label>
            <Select value={priority} onValueChange={(v: any) => setPriority(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Basse - Question générale</SelectItem>
                <SelectItem value="normal">Normale - Problème mineur</SelectItem>
                <SelectItem value="high">Haute - Problème important</SelectItem>
                <SelectItem value="urgent">Urgente - Bloquant</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Décrivez votre problème en détail..."
              rows={5}
              required
            />
          </div>

          <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg text-sm text-blue-700">
            <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <p>Notre équipe répond généralement sous 24-48h ouvrées.</p>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? (
                'Envoi...'
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Envoyer
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default SupportRequestForm;
