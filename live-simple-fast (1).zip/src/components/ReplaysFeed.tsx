import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import Header from './Header';
import ReplayCard, { ReplayData } from './ReplayCard';
import ReplayPlayer from './ReplayPlayer';
import AuthModal from './AuthModal';
import CreatorProfileForm from './CreatorProfileForm';
import StartLiveModal from './StartLiveModal';
import SubscriptionModal from './SubscriptionModal';

type SortOption = 'recent' | 'popular' | 'longest';

const ReplaysFeed: React.FC = () => {
  const { isAuthenticated, creatorProfile, user } = useAppContext();
  const [replays, setReplays] = useState<ReplayData[]>([]);
  const [isLoadingReplays, setIsLoadingReplays] = useState(true);
  const [selectedReplay, setSelectedReplay] = useState<ReplayData | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('recent');
  const [showAuth, setShowAuth] = useState(false);
  const [showProfileForm, setShowProfileForm] = useState(false);
  const [showStartLive, setShowStartLive] = useState(false);
  const [showSubscription, setShowSubscription] = useState(false);

  // Listen for test guide triggers
  useEffect(() => {
    const handleTriggerAuth = () => setShowAuth(true);
    const handleTriggerProfile = () => setShowProfileForm(true);
    const handleTriggerSubscription = () => setShowSubscription(true);
    const handleTriggerStartLive = () => setShowStartLive(true);

    window.addEventListener('triggerAuthModal', handleTriggerAuth);
    window.addEventListener('openAuthModal', handleTriggerAuth);
    window.addEventListener('triggerProfileForm', handleTriggerProfile);
    window.addEventListener('triggerSubscription', handleTriggerSubscription);
    window.addEventListener('triggerStartLive', handleTriggerStartLive);

    return () => {
      window.removeEventListener('triggerAuthModal', handleTriggerAuth);
      window.removeEventListener('openAuthModal', handleTriggerAuth);
      window.removeEventListener('triggerProfileForm', handleTriggerProfile);
      window.removeEventListener('triggerSubscription', handleTriggerSubscription);
      window.removeEventListener('triggerStartLive', handleTriggerStartLive);
    };
  }, []);

  useEffect(() => {
    fetchReplays();
  }, []);

  const fetchReplays = async () => {
    setIsLoadingReplays(true);



    try {
      // Fetch completed recordings
      const { data: streamsData, error: streamsError } = await supabase
        .from('live_streams')
        .select('id, title, thumbnail_url, recording_url, duration_seconds, recording_size_bytes, viewer_count, peak_viewers, started_at, ended_at, recording_status, creator_id, is_audio_only')
        .eq('is_live', false)
        .in('recording_status', ['completed', 'uploading', 'processing'])
        .order('ended_at', { ascending: false })
        .limit(50);


      if (streamsError) {
        setIsLoadingReplays(false);
        return;
      }



      if (streamsData && streamsData.length > 0) {
        // Get unique creator IDs
        const creatorIds = [...new Set(streamsData.map(s => s.creator_id).filter(Boolean))];

        // Fetch creator data
        let creatorsMap: Record<string, any> = {};
        if (creatorIds.length > 0) {
          const { data: creatorsData, error: creatorsError } = await supabase
            .from('creator_profiles')
            .select('id, user_id, display_name, username, avatar_url, whatsapp_number')
            .in('user_id', creatorIds);

          if (!creatorsError && creatorsData) {
            creatorsMap = creatorsData.reduce((acc, creator) => {
              acc[creator.user_id] = creator;
              return acc;
            }, {} as Record<string, any>);
          } else if (creatorsError) {

            // Try matching by id instead of user_id
            const { data: fallbackData } = await supabase
              .from('creator_profiles')
              .select('id, user_id, display_name, username, avatar_url, whatsapp_number')
              .in('id', creatorIds);
            
            if (fallbackData) {
              creatorsMap = fallbackData.reduce((acc, creator) => {
                acc[creator.id] = creator;
                return acc;
              }, {} as Record<string, any>);
            }
          }
        }

        const formattedReplays: ReplayData[] = streamsData.map((stream: any) => {
          const creator = creatorsMap[stream.creator_id] || {};
          return {
            id: stream.id,
            title: stream.title || 'Live sans titre',
            thumbnail_url: stream.thumbnail_url || '',
            recording_url: stream.recording_url || '',
            duration_seconds: stream.duration_seconds || 0,
            recording_size_bytes: stream.recording_size_bytes || 0,
            viewer_count: stream.viewer_count || 0,
            peak_viewers: stream.peak_viewers || stream.viewer_count || 0,
            started_at: stream.started_at || '',
            ended_at: stream.ended_at || stream.started_at || '',
            recording_status: stream.recording_status || 'completed',
            creator_id: stream.creator_id || '',
            is_audio_only: stream.is_audio_only || false,
            creatorName: creator.display_name || 'Creator',
            creatorUsername: creator.username || '',
            creatorAvatar: creator.avatar_url || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop',
            whatsappNumber: creator.whatsapp_number || '',
          };
        });



        setReplays(formattedReplays);
      } else {
        setReplays([]);
      }
    } catch {
      // Failed to fetch replays

      setIsLoadingReplays(false);
    }
  };

  const filteredAndSortedReplays = useMemo(() => {
    let filtered = replays;

    // Apply search
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(r =>
        r.title.toLowerCase().includes(query) ||
        (r.creatorName && r.creatorName.toLowerCase().includes(query)) ||
        (r.creatorUsername && r.creatorUsername.toLowerCase().includes(query))
      );
    }

    // Apply sort
    const sorted = [...filtered];
    switch (sortBy) {
      case 'recent':
        sorted.sort((a, b) => new Date(b.ended_at).getTime() - new Date(a.ended_at).getTime());
        break;
      case 'popular':
        sorted.sort((a, b) => (b.peak_viewers || b.viewer_count) - (a.peak_viewers || a.viewer_count));
        break;
      case 'longest':
        sorted.sort((a, b) => b.duration_seconds - a.duration_seconds);
        break;
    }

    return sorted;
  }, [replays, searchQuery, sortBy]);

  const handleStartLive = () => {
    if (!isAuthenticated) {
      setShowAuth(true);
      return;
    }
    if (!creatorProfile) {
      setShowProfileForm(true);
      return;
    }
    setShowStartLive(true);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col pt-16">
      <Header
        onAuthClick={() => setShowAuth(true)}
        onStartLive={handleStartLive}
      />

      {/* Replays Header */}
      <div className="border-b border-gray-800 px-4 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center">
              <svg className="w-5 h-5 text-purple-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">Replays</h2>
              <p className="text-gray-400 text-sm">
                {replays.length} enregistrement{replays.length !== 1 ? 's' : ''} disponible{replays.length !== 1 ? 's' : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Search */}
            <div className="relative flex-1 sm:flex-none">
              <svg className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher un replay..."
                className="w-full sm:w-64 bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 cursor-pointer"
            >
              <option value="recent">Plus récents</option>
              <option value="popular">Plus populaires</option>
              <option value="longest">Plus longs</option>
            </select>

            {/* Refresh */}
            <button
              onClick={fetchReplays}
              className="w-9 h-9 bg-gray-800 border border-gray-700 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors"
              title="Rafraîchir"
            >
              <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {isLoadingReplays ? (
          <div className="flex flex-col items-center justify-center h-64 gap-3">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500" />
            <p className="text-gray-500 text-sm">Chargement des replays...</p>
          </div>
        ) : filteredAndSortedReplays.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center min-h-[400px]">
            <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mb-4">
              <svg className="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </div>
            {searchQuery ? (
              <>
                <h2 className="text-white text-xl font-semibold mb-2">Aucun résultat</h2>
                <p className="text-gray-400 mb-6">Aucun replay ne correspond à "{searchQuery}"</p>
                <button
                  onClick={() => setSearchQuery('')}
                  className="bg-purple-600 hover:bg-purple-700 text-white font-medium px-6 py-3 rounded-xl transition-colors"
                >
                  Effacer la recherche
                </button>
              </>
            ) : (
              <>
                <h2 className="text-white text-xl font-semibold mb-2">Aucun replay disponible</h2>
                <p className="text-gray-400 mb-6">
                  Les enregistrements de lives apparaîtront ici. Démarrez un live pour créer votre premier replay!
                </p>
                <button
                  onClick={handleStartLive}
                  className="bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white font-medium px-6 py-3 rounded-full transition-all flex items-center gap-2"
                >
                  <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                  Démarrer un Live
                </button>
              </>
            )}
          </div>
        ) : (
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredAndSortedReplays.map((replay) => (
              <ReplayCard
                key={replay.id}
                replay={replay}
                onClick={() => setSelectedReplay(replay)}
              />
            ))}
          </div>
        )}
      </main>

      {/* Replay Player */}
      {selectedReplay && (
        <ReplayPlayer
          replay={selectedReplay}
          onClose={() => setSelectedReplay(null)}
        />
      )}

      {/* Modals */}
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />
      <CreatorProfileForm
        isOpen={showProfileForm || (isAuthenticated && !creatorProfile && showAuth === false)}
        onClose={() => setShowProfileForm(false)}
      />
      <StartLiveModal
        isOpen={showStartLive}
        onClose={() => setShowStartLive(false)}
        onStarted={() => {}}

      />
      <SubscriptionModal
        isOpen={showSubscription}
        onClose={() => setShowSubscription(false)}
      />
    </div>
  );
};

export default ReplaysFeed;
