/**
 * ConnectionBanner.tsx
 *
 * Displays a non-intrusive banner showing the Supabase connection status.
 * Shows: connection state, auth state, user role, and RLS test results.
 * Only visible when there's a problem or in development mode.
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { isSupabaseConfigured, testConnection, getConfigDiagnostics } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';

type ConnectionState = 'checking' | 'connected' | 'degraded' | 'disconnected' | 'unconfigured';

interface ConnectionInfo {
  state: ConnectionState;
  message: string;
  tablesExist: boolean | undefined;
  authState: 'authenticated' | 'anonymous' | 'loading';
  role: string;
}

const ConnectionBanner: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, isLoading, isAdmin, creatorProfile, utilisateur } = useAppContext();
  const [info, setInfo] = useState<ConnectionInfo>({
    state: 'checking',
    message: 'Vérification de la connexion...',
    tablesExist: undefined,
    authState: 'loading',
    role: 'inconnu',
  });
  const [dismissed, setDismissed] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const checkConnection = useCallback(async () => {
    if (!isSupabaseConfigured) {
      setInfo({
        state: 'unconfigured',
        message: 'Supabase non configuré — Mode démo actif',
        tablesExist: undefined,
        authState: isLoading ? 'loading' : 'anonymous',
        role: 'démo',
      });
      return;
    }

    setInfo(prev => ({ ...prev, state: 'checking', message: 'Vérification...' }));

    try {
      const result = await testConnection();

      // Determine role
      let role = 'spectateur';
      if (isAdmin) role = 'administrateur';
      else if (creatorProfile) role = 'créateur';
      else if (isAuthenticated) role = 'utilisateur';
      else role = 'anonyme';

      if (result.success) {
        if (result.tablesExist === false) {
          setInfo({
            state: 'degraded',
            message: 'Connecté — Tables manquantes',
            tablesExist: false,
            authState: isAuthenticated ? 'authenticated' : 'anonymous',
            role,
          });
        } else {
          setInfo({
            state: 'connected',
            message: 'Connecté à Supabase',
            tablesExist: result.tablesExist,
            authState: isAuthenticated ? 'authenticated' : 'anonymous',
            role,
          });
        }
      } else {
        setInfo({
          state: 'disconnected',
          message: result.error || 'Connexion échouée',
          tablesExist: undefined,
          authState: isAuthenticated ? 'authenticated' : 'anonymous',
          role,
        });
      }
    } catch (err: any) {
      setInfo({
        state: 'disconnected',
        message: err?.message || 'Erreur de connexion',
        tablesExist: undefined,
        authState: 'anonymous',
        role: 'inconnu',
      });
    }
  }, [isAuthenticated, isAdmin, creatorProfile, isLoading]);

  useEffect(() => {
    // Delay initial check to let auth initialize
    const timer = setTimeout(checkConnection, 2000);
    return () => clearTimeout(timer);
  }, [checkConnection]);

  // Re-check when auth state changes
  useEffect(() => {
    if (!isLoading) {
      checkConnection();
    }
  }, [isAuthenticated, isAdmin, isLoading, checkConnection]);

  // Don't show if dismissed or if everything is fine
  if (dismissed) return null;
  if (info.state === 'connected' && info.tablesExist !== false) return null;
  if (info.state === 'checking') return null;

  const stateConfig: Record<ConnectionState, { bg: string; border: string; icon: string; textColor: string }> = {
    checking: { bg: 'bg-gray-900/90', border: 'border-gray-700', icon: 'animate-spin', textColor: 'text-gray-300' },
    connected: { bg: 'bg-green-900/90', border: 'border-green-700', icon: '', textColor: 'text-green-300' },
    degraded: { bg: 'bg-yellow-900/90', border: 'border-yellow-700', icon: '', textColor: 'text-yellow-300' },
    disconnected: { bg: 'bg-red-900/90', border: 'border-red-700', icon: '', textColor: 'text-red-300' },
    unconfigured: { bg: 'bg-blue-900/90', border: 'border-blue-700', icon: '', textColor: 'text-blue-300' },
  };

  const config = stateConfig[info.state];
  const diagnostics = getConfigDiagnostics();

  return (
    <div className={`fixed bottom-4 right-4 z-50 max-w-sm ${config.bg} ${config.border} border rounded-xl shadow-2xl backdrop-blur-sm`}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          {/* Status dot */}
          <div className={`w-2.5 h-2.5 rounded-full ${
            info.state === 'connected' ? 'bg-green-400' :
            info.state === 'degraded' ? 'bg-yellow-400' :
            info.state === 'disconnected' ? 'bg-red-400' :
            info.state === 'unconfigured' ? 'bg-blue-400' :
            'bg-gray-400 animate-pulse'
          }`} />
          <span className={`text-sm font-medium ${config.textColor}`}>
            {info.message}
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setExpanded(!expanded)}
            className="p-1 text-gray-400 hover:text-white transition-colors"
            title="Détails"
          >
            <svg className={`w-4 h-4 transition-transform ${expanded ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="p-1 text-gray-400 hover:text-white transition-colors"
            title="Fermer"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>

      {/* Expanded details */}
      {expanded && (
        <div className="px-4 pb-3 space-y-2 border-t border-white/10 pt-3">
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
            <span className="text-gray-500">Auth</span>
            <span className={info.authState === 'authenticated' ? 'text-green-400' : 'text-gray-400'}>
              {info.authState === 'authenticated' ? 'Connecté' : info.authState === 'loading' ? 'Chargement...' : 'Anonyme'}
            </span>

            <span className="text-gray-500">Rôle</span>
            <span className="text-gray-300 capitalize">{info.role}</span>

            <span className="text-gray-500">Tables</span>
            <span className={info.tablesExist ? 'text-green-400' : info.tablesExist === false ? 'text-yellow-400' : 'text-gray-400'}>
              {info.tablesExist ? 'OK' : info.tablesExist === false ? 'Manquantes' : 'Inconnu'}
            </span>

            <span className="text-gray-500">Source</span>
            <span className="text-gray-300">{diagnostics.source}</span>

            {utilisateur && (
              <>
                <span className="text-gray-500">Utilisateur</span>
                <span className="text-gray-300 truncate">{utilisateur.display_name || utilisateur.email}</span>
              </>
            )}

            {creatorProfile && (
              <>
                <span className="text-gray-500">Profil</span>
                <span className="text-gray-300 truncate">@{creatorProfile.username}</span>
              </>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex gap-2 pt-2">
            {info.state === 'unconfigured' && (
              <button
                onClick={() => navigate('/connect-sync')}
                className="flex-1 text-xs bg-blue-600 hover:bg-blue-700 text-white py-1.5 px-3 rounded-lg transition-colors"
              >
                Connecter & Synchroniser
              </button>
            )}
            {info.state === 'degraded' && info.tablesExist === false && (
              <button
                onClick={() => navigate('/connect-sync')}
                className="flex-1 text-xs bg-yellow-600 hover:bg-yellow-700 text-white py-1.5 px-3 rounded-lg transition-colors"
              >
                Synchroniser
              </button>
            )}
            {info.state === 'disconnected' && (
              <button
                onClick={() => navigate('/connect-sync')}
                className="flex-1 text-xs bg-red-600 hover:bg-red-700 text-white py-1.5 px-3 rounded-lg transition-colors"
              >
                Diagnostiquer
              </button>
            )}
            <button
              onClick={checkConnection}
              className="text-xs bg-white/10 hover:bg-white/20 text-gray-300 py-1.5 px-3 rounded-lg transition-colors"
            >
              Retester
            </button>
          </div>

        </div>
      )}
    </div>
  );
};

export default ConnectionBanner;
