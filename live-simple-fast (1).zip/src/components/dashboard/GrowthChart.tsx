import React, { useState } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import type { DailyGrowthData } from '@/lib/dashboardService';
import { dashboardService } from '@/lib/dashboardService';

interface GrowthChartProps {
  data: DailyGrowthData[];
}

type MetricKey = 'followers' | 'views' | 'revenue' | 'lives';

const metrics: { key: MetricKey; label: string; color: string; gradientId: string }[] = [
  { key: 'followers', label: 'Followers', color: '#a78bfa', gradientId: 'colorFollowers' },
  { key: 'views', label: 'Vues', color: '#38bdf8', gradientId: 'colorViews' },
  { key: 'revenue', label: 'Revenus', color: '#34d399', gradientId: 'colorRevenue' },
  { key: 'lives', label: 'Lives', color: '#fb923c', gradientId: 'colorLives' },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload || !payload.length) return null;

  return (
    <div className="rounded-xl border border-white/10 bg-gray-900/95 backdrop-blur-sm px-4 py-3 shadow-xl">
      <p className="text-xs font-medium text-white/60 mb-2">{label}</p>
      {payload.map((entry: any, index: number) => {
        const metric = metrics.find(m => m.key === entry.dataKey);
        let formattedValue = entry.value;
        if (entry.dataKey === 'revenue') {
          formattedValue = dashboardService.formatCurrency(entry.value);
        } else {
          formattedValue = dashboardService.formatNumber(entry.value);
        }
        return (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-white/70">{metric?.label}:</span>
            <span className="font-semibold text-white">{formattedValue}</span>
          </div>
        );
      })}
    </div>
  );
};

const GrowthChart: React.FC<GrowthChartProps> = ({ data }) => {
  const [activeMetrics, setActiveMetrics] = useState<MetricKey[]>(['followers', 'views']);

  const toggleMetric = (key: MetricKey) => {
    setActiveMetrics(prev => {
      if (prev.includes(key)) {
        if (prev.length === 1) return prev;
        return prev.filter(m => m !== key);
      }
      return [...prev, key];
    });
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-gray-900/50 backdrop-blur-sm p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-bold text-white">Croissance sur 30 jours</h3>
          <p className="text-sm text-white/50 mt-0.5">Évolution de vos métriques clés</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {metrics.map(metric => (
            <button
              key={metric.key}
              onClick={() => toggleMetric(metric.key)}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                activeMetrics.includes(metric.key)
                  ? 'bg-white/10 text-white border border-white/20'
                  : 'bg-white/5 text-white/40 border border-transparent hover:bg-white/10 hover:text-white/60'
              }`}
            >
              <div
                className="h-2 w-2 rounded-full"
                style={{
                  backgroundColor: activeMetrics.includes(metric.key) ? metric.color : 'rgba(255,255,255,0.2)',
                }}
              />
              {metric.label}
            </button>
          ))}
        </div>
      </div>

      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              {metrics.map(metric => (
                <linearGradient key={metric.gradientId} id={metric.gradientId} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={metric.color} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={metric.color} stopOpacity={0} />
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
            <XAxis
              dataKey="label"
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }}
              axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
              tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            {metrics.map(metric =>
              activeMetrics.includes(metric.key) ? (
                <Area
                  key={metric.key}
                  type="monotone"
                  dataKey={metric.key}
                  stroke={metric.color}
                  strokeWidth={2}
                  fill={`url(#${metric.gradientId})`}
                  dot={false}
                  activeDot={{ r: 4, strokeWidth: 2, stroke: metric.color, fill: '#1f2937' }}
                />
              ) : null
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default GrowthChart;
