import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Line,
  ComposedChart,
} from 'recharts';
import type { RevenueDataPoint } from '@/lib/dashboardService';
import { dashboardService } from '@/lib/dashboardService';

interface RevenueChartProps {
  data: RevenueDataPoint[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload || !payload.length) return null;

  return (
    <div className="rounded-xl border border-white/10 bg-gray-900/95 backdrop-blur-sm px-4 py-3 shadow-xl">
      <p className="text-xs font-medium text-white/60 mb-2">{label}</p>
      {payload.map((entry: any, index: number) => (
        <div key={index} className="flex items-center gap-2 text-sm">
          <div className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-white/70">
            {entry.dataKey === 'cumulative' ? 'Cumulé' : 'Jour'}:
          </span>
          <span className="font-semibold text-white">
            {dashboardService.formatCurrency(entry.value)}
          </span>
        </div>
      ))}
    </div>
  );
};

const RevenueChart: React.FC<RevenueChartProps> = ({ data }) => {
  const totalRevenue = data.reduce((sum, d) => sum + d.amount, 0);
  const avgDaily = totalRevenue / 30;
  const bestDay = data.reduce((max, d) => d.amount > max.amount ? d : max, data[0]);

  return (
    <div className="rounded-2xl border border-white/10 bg-gray-900/50 backdrop-blur-sm p-6">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-bold text-white">Revenus</h3>
          <p className="text-sm text-white/50 mt-0.5">30 derniers jours</p>
        </div>
        <div className="flex gap-6">
          <div className="text-right">
            <p className="text-xs text-white/50">Total</p>
            <p className="text-lg font-bold text-emerald-400">{dashboardService.formatCurrency(totalRevenue)}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-white/50">Moy./jour</p>
            <p className="text-lg font-bold text-white">{dashboardService.formatCurrency(Math.round(avgDaily))}</p>
          </div>
        </div>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 5, right: 5, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="revenueBarGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#34d399" stopOpacity={0.8} />
                <stop offset="100%" stopColor="#34d399" stopOpacity={0.2} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
            <XAxis
              dataKey="label"
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }}
              axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
              tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              yAxisId="daily"
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              yAxisId="cumulative"
              orientation="right"
              tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar
              yAxisId="daily"
              dataKey="amount"
              fill="url(#revenueBarGradient)"
              radius={[3, 3, 0, 0]}
              name="Jour"
            />
            <Line
              yAxisId="cumulative"
              type="monotone"
              dataKey="cumulative"
              stroke="#fbbf24"
              strokeWidth={2}
              dot={false}
              name="Cumulé"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Best day info */}
      {bestDay && bestDay.amount > 0 && (
        <div className="mt-4 pt-4 border-t border-white/5 flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/10">
            <svg className="h-4 w-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <div>
            <p className="text-xs text-white/50">Meilleur jour</p>
            <p className="text-sm font-semibold text-white">
              {bestDay.label} — {dashboardService.formatCurrency(bestDay.amount)}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default RevenueChart;
