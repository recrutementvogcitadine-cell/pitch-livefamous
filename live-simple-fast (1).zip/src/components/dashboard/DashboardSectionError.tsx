import React from 'react';

interface DashboardSectionErrorProps {
  title: string;
  message?: string;
  onRetry: () => void;
  retrying?: boolean;
  compact?: boolean;
}

const DashboardSectionError: React.FC<DashboardSectionErrorProps> = ({
  title,
  message,
  onRetry,
  retrying = false,
  compact = false,
}) => {
  if (compact) {
    return (
      <div className="flex items-center justify-between rounded-2xl border border-red-500/20 bg-red-500/5 p-4">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl bg-red-500/10">
            <svg className="h-5 w-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-red-300 truncate">{title}</p>
            {message && (
              <p className="text-xs text-red-400/60 mt-0.5 truncate">{message}</p>
            )}
          </div>
        </div>
        <button
          onClick={onRetry}
          disabled={retrying}
          className="flex-shrink-0 ml-3 flex items-center gap-1.5 rounded-lg bg-red-500/10 border border-red-500/20 px-3 py-1.5 text-xs font-medium text-red-300 hover:bg-red-500/20 hover:text-red-200 transition-all disabled:opacity-50"
        >
          <svg className={`h-3.5 w-3.5 ${retrying ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          {retrying ? 'Chargement...' : 'Réessayer'}
        </button>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-8">
      <div className="flex flex-col items-center text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-red-500/10 mb-4">
          <svg className="h-7 w-7 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
        </div>
        <h4 className="text-base font-semibold text-red-300 mb-1">{title}</h4>
        <p className="text-sm text-red-400/60 mb-5 max-w-sm">
          {message || 'Une erreur est survenue lors du chargement de cette section. Veuillez réessayer.'}
        </p>
        <button
          onClick={onRetry}
          disabled={retrying}
          className="flex items-center gap-2 rounded-xl bg-red-500/10 border border-red-500/20 px-5 py-2.5 text-sm font-medium text-red-300 hover:bg-red-500/20 hover:text-red-200 transition-all disabled:opacity-50"
        >
          <svg className={`h-4 w-4 ${retrying ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          {retrying ? 'Chargement en cours...' : 'Réessayer'}
        </button>
      </div>
    </div>
  );
};

export default DashboardSectionError;
