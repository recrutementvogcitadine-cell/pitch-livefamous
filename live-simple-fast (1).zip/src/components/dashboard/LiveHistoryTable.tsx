import React, { useState } from 'react';
import type { LiveHistoryItem } from '@/lib/dashboardService';
import { dashboardService } from '@/lib/dashboardService';

interface LiveHistoryTableProps {
  data: LiveHistoryItem[];
}

type SortKey = 'started_at' | 'duration_seconds' | 'peak_viewers' | 'chat_messages_count';
type SortDir = 'asc' | 'desc';

const LiveHistoryTable: React.FC<LiveHistoryTableProps> = ({ data }) => {
  const [sortKey, setSortKey] = useState<SortKey>('started_at');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [page, setPage] = useState(0);
  const perPage = 8;

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('desc');
    }
    setPage(0);
  };

  const sorted = [...data].sort((a, b) => {
    let aVal: number, bVal: number;
    if (sortKey === 'started_at') {
      aVal = new Date(a.started_at).getTime();
      bVal = new Date(b.started_at).getTime();
    } else {
      aVal = a[sortKey];
      bVal = b[sortKey];
    }
    return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
  });

  const totalPages = Math.ceil(sorted.length / perPage);
  const paginated = sorted.slice(page * perPage, (page + 1) * perPage);

  const SortIcon = ({ column }: { column: SortKey }) => {
    if (sortKey !== column) {
      return (
        <svg className="h-3.5 w-3.5 text-white/20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
        </svg>
      );
    }
    return (
      <svg className="h-3.5 w-3.5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d={sortDir === 'desc' ? 'M19 9l-7 7-7-7' : 'M5 15l7-7 7 7'}
        />
      </svg>
    );
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-gray-900/50 backdrop-blur-sm overflow-hidden">
      <div className="p-6 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-white">Historique des lives</h3>
            <p className="text-sm text-white/50 mt-0.5">{data.length} lives au total</p>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-pink-500/10">
            <svg className="h-5 w-5 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </div>
        </div>
      </div>

      {data.length === 0 ? (
        <div className="px-6 pb-8 text-center">
          <div className="flex h-16 w-16 mx-auto items-center justify-center rounded-2xl bg-white/5 mb-4">
            <svg className="h-8 w-8 text-white/20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </div>
          <p className="text-white/40 text-sm">Aucun live pour le moment</p>
          <p className="text-white/25 text-xs mt-1">Lancez votre premier live pour voir les statistiques ici</p>
        </div>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-t border-b border-white/5">
                  <th className="px-6 py-3 text-left text-xs font-semibold text-white/50 uppercase tracking-wider">
                    Live
                  </th>
                  <th
                    className="px-4 py-3 text-left text-xs font-semibold text-white/50 uppercase tracking-wider cursor-pointer hover:text-white/70 transition-colors"
                    onClick={() => handleSort('started_at')}
                  >
                    <div className="flex items-center gap-1">
                      Date
                      <SortIcon column="started_at" />
                    </div>
                  </th>
                  <th
                    className="px-4 py-3 text-right text-xs font-semibold text-white/50 uppercase tracking-wider cursor-pointer hover:text-white/70 transition-colors"
                    onClick={() => handleSort('duration_seconds')}
                  >
                    <div className="flex items-center justify-end gap-1">
                      Durée
                      <SortIcon column="duration_seconds" />
                    </div>
                  </th>
                  <th
                    className="px-4 py-3 text-right text-xs font-semibold text-white/50 uppercase tracking-wider cursor-pointer hover:text-white/70 transition-colors"
                    onClick={() => handleSort('peak_viewers')}
                  >
                    <div className="flex items-center justify-end gap-1">
                      Viewers
                      <SortIcon column="peak_viewers" />
                    </div>
                  </th>
                  <th
                    className="px-4 py-3 text-right text-xs font-semibold text-white/50 uppercase tracking-wider cursor-pointer hover:text-white/70 transition-colors"
                    onClick={() => handleSort('chat_messages_count')}
                  >
                    <div className="flex items-center justify-end gap-1">
                      Messages
                      <SortIcon column="chat_messages_count" />
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {paginated.map((live) => (
                  <tr key={live.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${live.is_live ? 'bg-red-500/20' : 'bg-white/5'}`}>
                          {live.is_audio_only ? (
                            <svg className="h-4 w-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                            </svg>
                          ) : (
                            <svg className={`h-4 w-4 ${live.is_live ? 'text-red-400' : 'text-white/40'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                            </svg>
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-white truncate max-w-[200px]">{live.title}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            {live.is_live && (
                              <span className="inline-flex items-center gap-1 rounded-full bg-red-500/20 px-2 py-0.5 text-[10px] font-bold text-red-400 uppercase">
                                <span className="h-1.5 w-1.5 rounded-full bg-red-400 animate-pulse" />
                                En direct
                              </span>
                            )}
                            {live.is_audio_only && (
                              <span className="text-[10px] text-purple-400/70 font-medium">Audio</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <p className="text-sm text-white/70">{formatDate(live.started_at)}</p>
                      <p className="text-xs text-white/40">{formatTime(live.started_at)}</p>
                    </td>
                    <td className="px-4 py-4 text-right">
                      <span className="text-sm font-medium text-white/80">
                        {dashboardService.formatDuration(live.duration_seconds)}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-right">
                      <div>
                        <span className="text-sm font-medium text-white/80">
                          {dashboardService.formatNumber(live.peak_viewers)}
                        </span>
                        <p className="text-[10px] text-white/40">pic</p>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-right">
                      <span className="text-sm font-medium text-white/80">
                        {dashboardService.formatNumber(live.chat_messages_count)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-6 py-4 border-t border-white/5">
              <p className="text-xs text-white/40">
                Page {page + 1} sur {totalPages}
              </p>
              <div className="flex gap-1">
                <button
                  onClick={() => setPage(Math.max(0, page - 1))}
                  disabled={page === 0}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-white/60 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                >
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                  let pageNum: number;
                  if (totalPages <= 5) {
                    pageNum = i;
                  } else if (page < 3) {
                    pageNum = i;
                  } else if (page > totalPages - 4) {
                    pageNum = totalPages - 5 + i;
                  } else {
                    pageNum = page - 2 + i;
                  }
                  return (
                    <button
                      key={pageNum}
                      onClick={() => setPage(pageNum)}
                      className={`flex h-8 w-8 items-center justify-center rounded-lg text-xs font-medium transition-colors ${
                        page === pageNum
                          ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                          : 'bg-white/5 text-white/60 hover:bg-white/10'
                      }`}
                    >
                      {pageNum + 1}
                    </button>
                  );
                })}
                <button
                  onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                  disabled={page === totalPages - 1}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-white/60 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                >
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default LiveHistoryTable;
