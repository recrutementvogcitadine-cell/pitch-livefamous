import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import type { FollowerGrowthPoint } from '@/lib/dashboardService';
import { dashboardService } from '@/lib/dashboardService';

interface FollowersChartProps {
  data: FollowerGrowthPoint[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload || !payload.length) return null;

  return (
    <div className="rounded-xl border border-white/10 bg-gray-900/95 backdrop-blur-sm px-4 py-3 shadow-xl">
      <p className="text-xs font-medium text-white/60 mb-2">{label}</p>
      {payload.map((entry: any, index: number) => (
        <div key={index} className="flex items-center gap-2 text-sm">
          <div className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-white/70">
            {entry.dataKey === 'cumulative' ? 'Total' : 'Nouveaux'}:
          </span>
          <span className="font-semibold text-white">
            {dashboardService.formatNumber(entry.value)}
          </span>
        </div>
      ))}
    </div>
  );
};

const FollowersChart: React.FC<FollowersChartProps> = ({ data }) => {
  const totalNew = data.reduce((sum, d) => sum + d.count, 0);
  const currentTotal = data.length > 0 ? data[data.length - 1].cumulative : 0;

  return (
    <div className="rounded-2xl border border-white/10 bg-gray-900/50 backdrop-blur-sm p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-white">Évolution des followers</h3>
          <p className="text-sm text-white/50 mt-0.5">30 derniers jours</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-white">{dashboardService.formatNumber(currentTotal)}</p>
          <p className="text-xs text-emerald-400 font-medium">
            +{dashboardService.formatNumber(totalNew)} ce mois
          </p>
        </div>
      </div>

      <div className="h-56">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="followersGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#a78bfa" stopOpacity={0.4} />
                <stop offset="95%" stopColor="#a78bfa" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
            <XAxis
              dataKey="label"
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }}
              axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
              tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="cumulative"
              stroke="#a78bfa"
              strokeWidth={2.5}
              fill="url(#followersGradient)"
              dot={false}
              activeDot={{ r: 5, strokeWidth: 2, stroke: '#a78bfa', fill: '#1f2937' }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Daily new followers bar chart */}
      <div className="mt-4 pt-4 border-t border-white/5">
        <p className="text-xs font-medium text-white/50 mb-3">Nouveaux followers par jour</p>
        <div className="h-24">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <XAxis dataKey="label" hide />
              <YAxis hide />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="count"
                fill="#a78bfa"
                radius={[2, 2, 0, 0]}
                opacity={0.6}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default FollowersChart;
