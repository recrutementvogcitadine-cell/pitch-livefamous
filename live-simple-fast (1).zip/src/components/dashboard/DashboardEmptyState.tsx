import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import StartLiveModal from '@/components/StartLiveModal';

const DashboardEmptyState: React.FC = () => {
  const navigate = useNavigate();
  const [showStartLive, setShowStartLive] = useState(false);

  const tips = [
    {
      icon: (
        <svg className="h-6 w-6 text-purple-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
        </svg>
      ),
      title: 'Lancez votre premier live',
      description: 'Partagez votre contenu en direct avec votre communauté. Vidéo ou audio, c\'est vous qui choisissez.',
      gradient: 'from-purple-600/20 to-violet-600/10',
      iconBg: 'bg-purple-500/20',
    },
    {
      icon: (
        <svg className="h-6 w-6 text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
      title: 'Développez votre audience',
      description: 'Plus vous faites de lives, plus vous gagnez en visibilité. Vos statistiques apparaîtront ici.',
      gradient: 'from-blue-600/20 to-cyan-600/10',
      iconBg: 'bg-blue-500/20',
    },
    {
      icon: (
        <svg className="h-6 w-6 text-emerald-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      title: 'Monétisez votre contenu',
      description: 'Recevez des dons et des abonnements de vos fans. Suivez vos revenus en temps réel.',
      gradient: 'from-emerald-600/20 to-teal-600/10',
      iconBg: 'bg-emerald-500/20',
    },
  ];

  return (
    <div className="py-8">
      {/* Hero empty state */}
      <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-purple-900/30 via-gray-900/50 to-pink-900/20 p-8 sm:p-12 mb-8">
        {/* Background decoration */}
        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-purple-500/10 blur-3xl" />
        <div className="absolute -left-10 -bottom-10 h-48 w-48 rounded-full bg-pink-500/10 blur-3xl" />

        <div className="relative flex flex-col items-center text-center max-w-2xl mx-auto">
          {/* Animated icon */}
          <div className="relative mb-6">
            <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-white/10">
              <svg className="h-10 w-10 text-purple-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <div className="absolute -right-1 -top-1 h-5 w-5 rounded-full bg-purple-500/30 border-2 border-gray-900 flex items-center justify-center">
              <svg className="h-3 w-3 text-purple-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
              </svg>
            </div>
          </div>

          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">
            Bienvenue sur votre tableau de bord
          </h2>
          <p className="text-white/50 text-base sm:text-lg mb-8 max-w-lg">
            Vous n'avez pas encore de données à afficher. Lancez votre premier live pour commencer à voir vos statistiques ici.
          </p>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => setShowStartLive(true)}
              className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:from-purple-500 hover:to-pink-500 transition-all"
            >
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              Lancer mon premier live
            </button>
            <button
              onClick={() => navigate('/')}
              className="flex items-center justify-center gap-2 rounded-xl bg-white/5 border border-white/10 px-6 py-3 text-sm font-medium text-white/70 hover:bg-white/10 hover:text-white transition-all"
            >
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
              </svg>
              Explorer les lives
            </button>
          </div>
        </div>
      </div>

      {/* Tips grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {tips.map((tip, index) => (
          <div
            key={index}
            className={`relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br ${tip.gradient} p-6`}
          >
            <div className="absolute -right-4 -top-4 h-20 w-20 rounded-full bg-white/5" />
            <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${tip.iconBg} mb-4`}>
              {tip.icon}
            </div>
            <h3 className="text-sm font-bold text-white mb-1.5">{tip.title}</h3>
            <p className="text-xs text-white/50 leading-relaxed">{tip.description}</p>
          </div>
        ))}
      </div>

      {/* Quick stats placeholder */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-6 text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <svg className="h-5 w-5 text-white/20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
          </svg>
          <p className="text-sm font-medium text-white/30">Vos graphiques apparaîtront ici</p>
        </div>
        <p className="text-xs text-white/20">
          Statistiques de croissance, followers, revenus et historique des lives
        </p>
      </div>

      {/* Start Live Modal */}
      <StartLiveModal
        isOpen={showStartLive}
        onClose={() => setShowStartLive(false)}
      />
    </div>
  );
};

export default DashboardEmptyState;
