import React, { useState } from 'react';
import {
  Users, Plus, Shield, Eye, Edit, Trash2, UserCheck,
  Crown, Lock, ChevronUp, ChevronDown, ArrowUpDown,
  Zap, Info,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import {
  TeamMember,
  TeamPermissions,
  teamService,
  DEFAULT_PERMISSIONS,
  PERMISSION_LABELS,
  ROLE_LABELS,
  canManageRole,
  isOwnerRole,
} from '@/lib/teamService';
import RoleChangeConfirmDialog from './RoleChangeConfirmDialog';

interface TeamTabProps {
  members: TeamMember[];
  currentMember: TeamMember | null;
  onRefresh: () => void;
}

const ROLE_COLORS: Record<string, string> = {
  owner: 'bg-amber-100 text-amber-800 border-amber-300',
  admin: 'bg-purple-100 text-purple-700 border-purple-200',
  moderator: 'bg-blue-100 text-blue-700 border-blue-200',
  read_only: 'bg-gray-100 text-gray-600 border-gray-200',
};

const ROLE_BG: Record<string, string> = {
  owner: 'bg-gradient-to-br from-amber-500 to-orange-500',
  admin: 'bg-gradient-to-br from-purple-500 to-indigo-500',
  moderator: 'bg-gradient-to-br from-blue-500 to-cyan-500',
  read_only: 'bg-gradient-to-br from-gray-400 to-gray-500',
};

const ROLE_ICONS: Record<string, React.ReactNode> = {
  owner: <Crown className="w-4 h-4" />,
  admin: <Shield className="w-4 h-4" />,
  moderator: <UserCheck className="w-4 h-4" />,
  read_only: <Eye className="w-4 h-4" />,
};

// Ordered from lowest to highest (excluding owner)
const ROLE_LADDER: Array<'read_only' | 'moderator' | 'admin'> = [
  'read_only',
  'moderator',
  'admin',
];

const TeamTab: React.FC<TeamTabProps> = ({ members, currentMember, onRefresh }) => {
  const { toast } = useToast();
  const [addModal, setAddModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  // Role change confirmation dialog state
  const [roleChangeTarget, setRoleChangeTarget] = useState<TeamMember | null>(null);
  const [roleChangeNewRole, setRoleChangeNewRole] = useState<'admin' | 'moderator' | 'read_only'>('moderator');
  const [roleChangeDialogOpen, setRoleChangeDialogOpen] = useState(false);
  const [roleChangeLoading, setRoleChangeLoading] = useState(false);

  // Add member form state
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'admin' | 'moderator' | 'read_only'>('moderator');
  const [newPermissions, setNewPermissions] = useState<TeamPermissions>(DEFAULT_PERMISSIONS.moderator);
  const [addLoading, setAddLoading] = useState(false);

  // Edit member state
  const [editRole, setEditRole] = useState<'admin' | 'moderator' | 'read_only'>('moderator');
  const [editPermissions, setEditPermissions] = useState<TeamPermissions>(DEFAULT_PERMISSIONS.moderator);
  const [editName, setEditName] = useState('');
  const [editLoading, setEditLoading] = useState(false);

  const isOwner = currentMember?.role === 'owner';
  const isAdmin = currentMember?.role === 'admin';
  const canManageTeam = isOwner || isAdmin || currentMember?.permissions?.manage_team;
  // Since removed members are now deleted (not deactivated), all returned members are active
  const activeMembers = members;


  // Get assignable roles based on current user's role
  const getAssignableRoles = (): Array<'admin' | 'moderator' | 'read_only'> => {
    if (isOwner) return ['admin', 'moderator', 'read_only'];
    if (isAdmin) return ['moderator', 'read_only'];
    return ['read_only'];
  };

  const assignableRoles = getAssignableRoles();

  // --- Role change helpers ---
  const getNextPromotion = (role: string): 'admin' | 'moderator' | 'read_only' | null => {
    const idx = ROLE_LADDER.indexOf(role as any);
    if (idx === -1 || idx >= ROLE_LADDER.length - 1) return null;
    const nextRole = ROLE_LADDER[idx + 1];
    if (!assignableRoles.includes(nextRole)) return null;
    return nextRole;
  };

  const getNextDemotion = (role: string): 'admin' | 'moderator' | 'read_only' | null => {
    const idx = ROLE_LADDER.indexOf(role as any);
    if (idx <= 0) return null;
    const prevRole = ROLE_LADDER[idx - 1];
    return prevRole;
  };

  const initiateRoleChange = (member: TeamMember, newRole: 'admin' | 'moderator' | 'read_only') => {
    setRoleChangeTarget(member);
    setRoleChangeNewRole(newRole);
    setRoleChangeDialogOpen(true);
  };

  const confirmRoleChange = async () => {
    if (!roleChangeTarget) return;
    setRoleChangeLoading(true);

    const result = await teamService.updateTeamMember(roleChangeTarget.id, {
      role: roleChangeNewRole,
      permissions: DEFAULT_PERMISSIONS[roleChangeNewRole],
    });

    setRoleChangeLoading(false);

    if (result.success) {
      toast({
        title: 'Rôle modifié',
        description: `${roleChangeTarget.display_name} est maintenant ${ROLE_LABELS[roleChangeNewRole]}`,
      });
      setRoleChangeDialogOpen(false);
      setRoleChangeTarget(null);
      onRefresh();
    } else {
      toast({
        title: 'Erreur',
        description: result.error || 'Impossible de modifier le rôle',
        variant: 'destructive',
      });
    }
  };

  // --- Existing handlers ---
  const handleRoleSelectChange = (role: 'admin' | 'moderator' | 'read_only', isEdit = false) => {
    const perms = { ...DEFAULT_PERMISSIONS[role] };
    if (isEdit) {
      setEditRole(role);
      setEditPermissions(perms);
    } else {
      setNewRole(role);
      setNewPermissions(perms);
    }
  };

  const handleAddMember = async () => {
    if (!newEmail.trim() || !newName.trim()) {
      toast({ title: 'Erreur', description: 'Veuillez remplir tous les champs', variant: 'destructive' });
      return;
    }
    setAddLoading(true);
    const result = await teamService.addTeamMember(newEmail.trim(), newName.trim(), newRole, newPermissions);
    setAddLoading(false);

    if (result.success) {
      toast({ title: 'Succès', description: `${newName} ajouté comme ${ROLE_LABELS[newRole]}` });
      setAddModal(false);
      setNewEmail('');
      setNewName('');
      setNewRole('moderator');
      setNewPermissions(DEFAULT_PERMISSIONS.moderator);
      onRefresh();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleEditMember = (member: TeamMember) => {
    setSelectedMember(member);
    setEditRole(member.role === 'owner' ? 'admin' : member.role as any);
    setEditPermissions(member.permissions);
    setEditName(member.display_name);
    setEditModal(true);
  };

  const handleSaveEdit = async () => {
    if (!selectedMember) return;
    setEditLoading(true);
    const result = await teamService.updateTeamMember(selectedMember.id, {
      role: editRole,
      permissions: editPermissions,
      display_name: editName,
    });
    setEditLoading(false);

    if (result.success) {
      toast({ title: 'Succès', description: 'Membre mis à jour' });
      setEditModal(false);
      setSelectedMember(null);
      onRefresh();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const handleRemoveMember = async (member: TeamMember) => {
    if (member.user_id === currentMember?.user_id) {
      toast({ title: 'Erreur', description: 'Vous ne pouvez pas vous retirer vous-même', variant: 'destructive' });
      return;
    }
    if (isOwnerRole(member.role)) {
      toast({ title: 'Erreur', description: 'Le propriétaire ne peut pas être retiré', variant: 'destructive' });
      return;
    }
    if (!confirm(`Retirer ${member.display_name} de l'équipe ?`)) return;

    const result = await teamService.removeTeamMember(member.id);
    if (result.success) {
      toast({ title: 'Succès', description: `${member.display_name} a été retiré` });
      onRefresh();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };




  const canEditMember = (member: TeamMember): boolean => {
    if (!currentMember) return false;
    if (isOwnerRole(member.role)) return false;
    if (member.user_id === currentMember.user_id) return false;
    return canManageRole(currentMember.role, member.role);
  };

  const canRemoveMember = (member: TeamMember): boolean => {
    if (!currentMember) return false;
    if (isOwnerRole(member.role)) return false;
    if (member.user_id === currentMember.user_id) return false;
    return canManageRole(currentMember.role, member.role);
  };

  const canChangeRoleOf = (member: TeamMember): boolean => {
    if (!currentMember) return false;
    if (isOwnerRole(member.role)) return false;
    if (member.user_id === currentMember.user_id) return false;
    return canManageRole(currentMember.role, member.role);
  };

  const PermissionsEditor = ({
    permissions,
    onChange,
    disabled = false,
  }: {
    permissions: TeamPermissions;
    onChange: (p: TeamPermissions) => void;
    disabled?: boolean;
  }) => (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
      {(Object.keys(PERMISSION_LABELS) as Array<keyof TeamPermissions>).map((key) => (
        <div key={key} className="flex items-center justify-between p-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
          <Label className="text-sm cursor-pointer">{PERMISSION_LABELS[key]}</Label>
          <Switch
            checked={permissions[key]}
            onCheckedChange={(checked) => onChange({ ...permissions, [key]: checked })}
            disabled={disabled}
          />
        </div>
      ))}
    </div>
  );

  // --- Permission summary for member cards ---
  const PermissionPills: React.FC<{ permissions: TeamPermissions; role: string }> = ({ permissions, role }) => {
    if (role === 'owner') {
      return (
        <span className="text-xs text-amber-600 font-medium">Toutes les permissions</span>
      );
    }
    const activePerms = (Object.keys(PERMISSION_LABELS) as Array<keyof TeamPermissions>)
      .filter(k => permissions[k]);
    const totalPerms = Object.keys(PERMISSION_LABELS).length;

    return (
      <div className="flex items-center gap-1.5 flex-wrap">
        <span className="text-xs text-gray-500">
          {activePerms.length}/{totalPerms} permissions
        </span>
        <div className="flex gap-0.5">
          {Array.from({ length: totalPerms }).map((_, i) => (
            <div
              key={i}
              className={`w-1.5 h-1.5 rounded-full ${
                i < activePerms.length ? 'bg-green-400' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>
      </div>
    );
  };

  return (
    <TooltipProvider>
      <div className="space-y-6">
        {/* Summary cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-amber-200 bg-amber-50/30">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-amber-700">Propriétaire</p>
                  <p className="text-3xl font-bold text-amber-600">
                    {activeMembers.filter(m => m.role === 'owner').length}
                  </p>
                </div>
                <Crown className="w-10 h-10 text-amber-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Administrateurs</p>
                  <p className="text-3xl font-bold text-purple-600">
                    {activeMembers.filter(m => m.role === 'admin').length}
                  </p>
                </div>
                <Shield className="w-10 h-10 text-purple-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Modérateurs</p>
                  <p className="text-3xl font-bold text-blue-600">
                    {activeMembers.filter(m => m.role === 'moderator').length}
                  </p>
                </div>
                <UserCheck className="w-10 h-10 text-blue-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Lecture seule</p>
                  <p className="text-3xl font-bold text-gray-600">
                    {activeMembers.filter(m => m.role === 'read_only').length}
                  </p>
                </div>
                <Eye className="w-10 h-10 text-gray-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active members with role management */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Gestion des rôles
                </CardTitle>
                <CardDescription>
                  {activeMembers.length} membre{activeMembers.length > 1 ? 's' : ''} actif{activeMembers.length > 1 ? 's' : ''}
                  {isOwner && ' — Cliquez sur les flèches pour promouvoir ou rétrograder'}
                </CardDescription>
              </div>
              {canManageTeam && (
                <Button onClick={() => setAddModal(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activeMembers.map((member) => {
                const promotion = getNextPromotion(member.role);
                const demotion = getNextDemotion(member.role);
                const canChange = canChangeRoleOf(member);
                const isSelf = member.user_id === currentMember?.user_id;
                const isOwnerMember = isOwnerRole(member.role);

                return (
                  <div
                    key={member.id}
                    className={`group relative flex items-center justify-between p-4 border rounded-xl transition-all duration-200 hover:shadow-md ${
                      isOwnerMember
                        ? 'border-amber-200 bg-gradient-to-r from-amber-50/40 to-orange-50/30'
                        : 'hover:bg-gray-50/80'
                    }`}
                  >
                    {/* Left: Avatar + Info */}
                    <div className="flex items-center gap-4 min-w-0 flex-1">
                      <div className="relative">
                        <Avatar className="w-12 h-12 ring-2 ring-white shadow-sm">
                          <AvatarFallback className={`font-bold text-white ${ROLE_BG[member.role]}`}>
                            {member.display_name[0]?.toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        {/* Role icon overlay */}
                        <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white shadow-sm ${ROLE_BG[member.role]}`}>
                          {React.cloneElement(ROLE_ICONS[member.role] as React.ReactElement, {
                            className: 'w-3 h-3',
                          })}
                        </div>
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-semibold truncate">{member.display_name}</h4>
                          {isSelf && (
                            <Badge variant="outline" className="text-xs border-blue-200 text-blue-600 bg-blue-50">Vous</Badge>
                          )}
                          {isOwnerMember && (
                            <Lock className="w-3.5 h-3.5 text-amber-500" title="Compte protégé" />
                          )}
                        </div>
                        <p className="text-sm text-gray-500 truncate">{member.email}</p>
                        <div className="mt-1">
                          <PermissionPills permissions={member.permissions} role={member.role} />
                        </div>
                      </div>
                    </div>

                    {/* Center: Role badge + quick role selector */}
                    <div className="flex items-center gap-3 mx-4">
                      {/* Quick role change buttons (promote/demote) */}
                      {canChange && !isOwnerMember && (
                        <div className="flex flex-col gap-1">
                          {/* Promote button */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                size="sm"
                                variant="ghost"
                                className={`h-7 w-7 p-0 rounded-full transition-all ${
                                  promotion
                                    ? 'hover:bg-green-100 hover:text-green-700 text-gray-400'
                                    : 'text-gray-200 cursor-not-allowed'
                                }`}
                                disabled={!promotion}
                                onClick={() => promotion && initiateRoleChange(member, promotion)}
                              >
                                <ChevronUp className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent side="left">
                              {promotion ? (
                                <span>Promouvoir en {ROLE_LABELS[promotion]}</span>
                              ) : (
                                <span>Rôle maximum atteint</span>
                              )}
                            </TooltipContent>
                          </Tooltip>

                          {/* Demote button */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                size="sm"
                                variant="ghost"
                                className={`h-7 w-7 p-0 rounded-full transition-all ${
                                  demotion
                                    ? 'hover:bg-orange-100 hover:text-orange-700 text-gray-400'
                                    : 'text-gray-200 cursor-not-allowed'
                                }`}
                                disabled={!demotion}
                                onClick={() => demotion && initiateRoleChange(member, demotion)}
                              >
                                <ChevronDown className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent side="left">
                              {demotion ? (
                                <span>Rétrograder en {ROLE_LABELS[demotion]}</span>
                              ) : (
                                <span>Rôle minimum atteint</span>
                              )}
                            </TooltipContent>
                          </Tooltip>
                        </div>
                      )}

                      {/* Current role badge */}
                      <Badge className={`${ROLE_COLORS[member.role]} flex items-center gap-1.5 px-3 py-1`}>
                        {ROLE_ICONS[member.role]}
                        {ROLE_LABELS[member.role]}
                      </Badge>

                      {/* Direct role selector dropdown (for owner) */}
                      {canChange && !isOwnerMember && isOwner && (
                        <Select
                          value={member.role}
                          onValueChange={(val: string) => {
                            const newR = val as 'admin' | 'moderator' | 'read_only';
                            if (newR !== member.role) {
                              initiateRoleChange(member, newR);
                            }
                          }}
                        >
                          <SelectTrigger className="w-9 h-9 p-0 border-dashed border-gray-300 hover:border-gray-400 [&>svg]:hidden flex items-center justify-center">
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
                              </TooltipTrigger>
                              <TooltipContent>Changer le rôle directement</TooltipContent>
                            </Tooltip>
                          </SelectTrigger>
                          <SelectContent>
                            {assignableRoles.map(role => (
                              <SelectItem key={role} value={role} disabled={role === member.role}>
                                <div className="flex items-center gap-2">
                                  {ROLE_ICONS[role]}
                                  <span>{ROLE_LABELS[role]}</span>
                                  {role === member.role && (
                                    <Badge variant="outline" className="text-[10px] ml-1">Actuel</Badge>
                                  )}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </div>

                    {/* Right: Action buttons */}
                    <div className="flex items-center gap-1">
                      {canEditMember(member) && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0"
                              onClick={() => handleEditMember(member)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Modifier les détails</TooltipContent>
                        </Tooltip>
                      )}
                      {canRemoveMember(member) && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                              onClick={() => handleRemoveMember(member)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Retirer de l'équipe</TooltipContent>
                        </Tooltip>
                      )}
                    </div>
                  </div>
                );
              })}
              {activeMembers.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  Aucun membre dans l'équipe
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Role hierarchy info */}
        <Card className="border-blue-100 bg-blue-50/30">
          <CardContent className="pt-6">
            <h4 className="font-semibold text-blue-800 mb-3 flex items-center gap-2">
              <Info className="w-4 h-4" />
              Hiérarchie des rôles et permissions
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              {(['owner', 'admin', 'moderator', 'read_only'] as const).map((role) => {
                const perms = DEFAULT_PERMISSIONS[role];
                const activeCount = (Object.keys(perms) as Array<keyof TeamPermissions>).filter(k => perms[k]).length;
                const totalCount = Object.keys(PERMISSION_LABELS).length;

                return (
                  <div key={role} className="p-3 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-shadow">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-white ${ROLE_BG[role]}`}>
                        {React.cloneElement(ROLE_ICONS[role] as React.ReactElement, {
                          className: 'w-3.5 h-3.5',
                        })}
                      </div>
                      <span className="font-semibold text-sm">{ROLE_LABELS[role]}</span>
                    </div>
                    <div className="flex items-center gap-1 mb-2">
                      <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            role === 'owner' ? 'bg-amber-400' :
                            role === 'admin' ? 'bg-purple-400' :
                            role === 'moderator' ? 'bg-blue-400' :
                            'bg-gray-300'
                          }`}
                          style={{ width: `${(activeCount / totalCount) * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 ml-1">{activeCount}/{totalCount}</span>
                    </div>
                    <div className="space-y-1">
                      {(Object.keys(PERMISSION_LABELS) as Array<keyof TeamPermissions>).map((key) => (
                        <div key={key} className="flex items-center gap-1.5">
                          <div className={`w-2 h-2 rounded-full ${perms[key] ? 'bg-green-400' : 'bg-gray-200'}`} />
                          <span className={`text-[11px] ${perms[key] ? 'text-gray-700' : 'text-gray-400'}`}>
                            {PERMISSION_LABELS[key]}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
            {isOwner && (
              <div className="mt-3 flex items-start gap-2 p-2.5 bg-amber-50 border border-amber-200 rounded-lg">
                <Zap className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-amber-700">
                  <strong>Astuce :</strong> Utilisez les flèches haut/bas sur chaque membre pour le promouvoir ou le rétrograder rapidement.
                  Vous pouvez aussi utiliser le sélecteur direct pour choisir un rôle spécifique.
                  Chaque changement affichera un résumé des permissions avant confirmation.
                </p>
              </div>
            )}
          </CardContent>
        </Card>




        {/* Role Change Confirmation Dialog */}
        <RoleChangeConfirmDialog
          open={roleChangeDialogOpen}
          onOpenChange={setRoleChangeDialogOpen}
          member={roleChangeTarget}
          newRole={roleChangeNewRole}
          loading={roleChangeLoading}
          onConfirm={confirmRoleChange}
        />

        {/* Add Member Modal */}
        <Dialog open={addModal} onOpenChange={setAddModal}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Ajouter un membre</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Nom d'affichage</Label>
                <Input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Ex: Jean Dupont"
                />
              </div>
              <div>
                <Label>Email</Label>
                <Input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="email@exemple.com"
                />
              </div>
              <div>
                <Label>Rôle</Label>
                <Select value={newRole} onValueChange={(v: any) => handleRoleSelectChange(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {assignableRoles.map(role => (
                      <SelectItem key={role} value={role}>
                        <div className="flex items-center gap-2">
                          {ROLE_ICONS[role]}
                          {ROLE_LABELS[role]}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!isOwner && newRole === 'admin' && (
                  <p className="text-xs text-amber-600 mt-1">
                    Seul le propriétaire peut ajouter des administrateurs.
                  </p>
                )}
              </div>
              <div>
                <Label className="text-sm font-medium">Permissions</Label>
                <PermissionsEditor
                  permissions={newPermissions}
                  onChange={setNewPermissions}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddModal(false)}>Annuler</Button>
              <Button onClick={handleAddMember} disabled={addLoading}>
                {addLoading ? 'Ajout...' : 'Ajouter'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Member Modal */}
        <Dialog open={editModal} onOpenChange={setEditModal}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Modifier {selectedMember?.display_name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Nom d'affichage</Label>
                <Input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                />
              </div>
              <div>
                <Label>Rôle</Label>
                <Select value={editRole} onValueChange={(v: any) => handleRoleSelectChange(v, true)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {assignableRoles.map(role => (
                      <SelectItem key={role} value={role}>
                        <div className="flex items-center gap-2">
                          {ROLE_ICONS[role]}
                          {ROLE_LABELS[role]}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium">Permissions</Label>
                <PermissionsEditor
                  permissions={editPermissions}
                  onChange={setEditPermissions}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditModal(false)}>Annuler</Button>
              <Button onClick={handleSaveEdit} disabled={editLoading}>
                {editLoading ? 'Enregistrement...' : 'Enregistrer'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  );
};

export default TeamTab;
