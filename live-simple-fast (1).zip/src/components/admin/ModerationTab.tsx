import React, { useState, useEffect } from 'react';
import {
  Shield, Filter, Clock, MessageSquare, Users,
  Radio, CreditCard, BadgeCheck, UserMinus, UserPlus,
  AlertTriangle, RefreshCw, ChevronRight, Ban, UserX, CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  ModerationLog,
  TeamMember,
  teamService,
  ACTION_TYPE_LABELS,
  TARGET_TYPE_LABELS,
} from '@/lib/teamService';
import { chatService, ChatBan } from '@/lib/chatService';

interface ModerationTabProps {
  currentMember: TeamMember | null;
}

const ACTION_ICONS: Record<string, React.ReactNode> = {
  delete_message: <MessageSquare className="w-4 h-4 text-red-500" />,
  ban_user: <UserMinus className="w-4 h-4 text-red-600" />,
  unban_user: <UserPlus className="w-4 h-4 text-green-600" />,
  end_stream: <Radio className="w-4 h-4 text-orange-500" />,
  approve_verification: <BadgeCheck className="w-4 h-4 text-green-600" />,
  reject_verification: <BadgeCheck className="w-4 h-4 text-red-500" />,
  activate_subscription: <CreditCard className="w-4 h-4 text-green-600" />,
  deactivate_subscription: <CreditCard className="w-4 h-4 text-red-500" />,
  update_support: <MessageSquare className="w-4 h-4 text-blue-500" />,
  add_team_member: <UserPlus className="w-4 h-4 text-purple-600" />,
  remove_team_member: <UserMinus className="w-4 h-4 text-red-600" />,
  update_role: <Shield className="w-4 h-4 text-blue-600" />,
  other: <AlertTriangle className="w-4 h-4 text-gray-500" />,
};

const ACTION_COLORS: Record<string, string> = {
  delete_message: 'bg-red-50 border-red-200',
  ban_user: 'bg-red-50 border-red-200',
  unban_user: 'bg-green-50 border-green-200',
  end_stream: 'bg-orange-50 border-orange-200',
  approve_verification: 'bg-green-50 border-green-200',
  reject_verification: 'bg-red-50 border-red-200',
  activate_subscription: 'bg-green-50 border-green-200',
  deactivate_subscription: 'bg-red-50 border-red-200',
  update_support: 'bg-blue-50 border-blue-200',
  add_team_member: 'bg-purple-50 border-purple-200',
  remove_team_member: 'bg-red-50 border-red-200',
  update_role: 'bg-blue-50 border-blue-200',
  other: 'bg-gray-50 border-gray-200',
};

const ModerationTab: React.FC<ModerationTabProps> = ({ currentMember }) => {
  const [logs, setLogs] = useState<ModerationLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionFilter, setActionFilter] = useState('all');
  const [expandedLog, setExpandedLog] = useState<string | null>(null);

  // Banned users state
  const [bans, setBans] = useState<ChatBan[]>([]);
  const [bansLoading, setBansLoading] = useState(true);
  const [banFilter, setBanFilter] = useState<'active' | 'all'>('active');
  const [unbanningId, setUnbanningId] = useState<string | null>(null);
  const [unbanSuccess, setUnbanSuccess] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState('logs');

  useEffect(() => {
    loadLogs();
  }, [actionFilter]);

  useEffect(() => {
    loadBans();
  }, [banFilter]);

  // Clear unban success after 3s
  useEffect(() => {
    if (unbanSuccess) {
      const timer = setTimeout(() => setUnbanSuccess(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [unbanSuccess]);

  const loadLogs = async () => {
    setLoading(true);
    const data = await teamService.getModerationLogs({
      limit: 200,
      actionType: actionFilter,
    });
    setLogs(data);
    setLoading(false);
  };

  const loadBans = async () => {
    setBansLoading(true);
    const data = await chatService.getAllBans({
      activeOnly: banFilter === 'active',
      limit: 200,
    });
    setBans(data);
    setBansLoading(false);
  };

  const handleUnban = async (ban: ChatBan) => {
    setUnbanningId(ban.id);
    const result = await chatService.unbanUser(ban.id);
    if (result.success) {
      // Log the unban action
      await teamService.logAction('unban_user', 'user', ban.user_id, {
        banned_user_name: ban.banned_user_name,
        original_reason: ban.reason,
        original_ban_date: ban.created_at,
      }, ban.stream_id || undefined);

      setUnbanSuccess(`${ban.banned_user_name || 'Utilisateur'} a été débanni`);
      // Refresh the list
      await loadBans();
    }
    setUnbanningId(null);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return "À l'instant";
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatFullDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getDetailsSummary = (log: ModerationLog): string => {
    const d = log.details;
    if (!d || Object.keys(d).length === 0) return '';

    switch (log.action_type) {
      case 'delete_message':
        return d.message_preview ? `"${d.message_preview}"` : '';
      case 'ban_user':
        return d.banned_user_name ? `${d.banned_user_name}${d.reason ? ` — ${d.reason}` : ''}` : '';
      case 'unban_user':
        return d.banned_user_name || '';
      case 'add_team_member':
        return d.display_name ? `${d.display_name} (${d.role || ''})` : '';
      case 'remove_team_member':
        return d.display_name || '';
      case 'update_role':
        return d.updates?.role ? `Nouveau rôle : ${d.updates.role}` : '';
      case 'end_stream':
        return d.reason || '';
      default:
        return '';
    }
  };

  // Group logs by date
  const groupedLogs = logs.reduce<Record<string, ModerationLog[]>>((groups, log) => {
    const date = new Date(log.created_at).toLocaleDateString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    if (!groups[date]) groups[date] = [];
    groups[date].push(log);
    return groups;
  }, {});

  // Stats
  const todayLogs = logs.filter(l => {
    const logDate = new Date(l.created_at);
    const today = new Date();
    return logDate.toDateString() === today.toDateString();
  });

  const activeBansCount = bans.filter(b => b.is_active).length;

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Actions aujourd'hui</p>
                <p className="text-3xl font-bold">{todayLogs.length}</p>
              </div>
              <Clock className="w-8 h-8 text-blue-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Messages supprimés</p>
                <p className="text-3xl font-bold text-red-600">
                  {todayLogs.filter(l => l.action_type === 'delete_message').length}
                </p>
              </div>
              <MessageSquare className="w-8 h-8 text-red-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Utilisateurs bannis</p>
                <p className="text-3xl font-bold text-orange-600">{activeBansCount}</p>
              </div>
              <Ban className="w-8 h-8 text-orange-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Lives terminés</p>
                <p className="text-3xl font-bold text-purple-600">
                  {todayLogs.filter(l => l.action_type === 'end_stream').length}
                </p>
              </div>
              <Radio className="w-8 h-8 text-purple-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total actions</p>
                <p className="text-3xl font-bold text-gray-600">{logs.length}</p>
              </div>
              <Shield className="w-8 h-8 text-gray-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sub-tabs: Logs / Banned Users */}
      <Tabs value={activeSubTab} onValueChange={setActiveSubTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="logs" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Journal de modération
          </TabsTrigger>
          <TabsTrigger value="bans" className="flex items-center gap-2">
            <Ban className="w-4 h-4" />
            Utilisateurs bannis
            {activeBansCount > 0 && (
              <span className="ml-1 bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full font-bold">
                {activeBansCount}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* Moderation Logs Tab */}
        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Journal de modération
                  </CardTitle>
                  <CardDescription>Historique de toutes les actions des modérateurs</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select value={actionFilter} onValueChange={setActionFilter}>
                    <SelectTrigger className="w-52">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les actions</SelectItem>
                      <SelectItem value="delete_message">Messages supprimés</SelectItem>
                      <SelectItem value="end_stream">Lives terminés</SelectItem>
                      <SelectItem value="ban_user">Bannissements</SelectItem>
                      <SelectItem value="unban_user">Débannissements</SelectItem>
                      <SelectItem value="approve_verification">Vérifications approuvées</SelectItem>
                      <SelectItem value="reject_verification">Vérifications rejetées</SelectItem>
                      <SelectItem value="activate_subscription">Abonnements activés</SelectItem>
                      <SelectItem value="deactivate_subscription">Abonnements désactivés</SelectItem>
                      <SelectItem value="add_team_member">Membres ajoutés</SelectItem>
                      <SelectItem value="remove_team_member">Membres retirés</SelectItem>
                      <SelectItem value="update_role">Rôles modifiés</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm" onClick={loadLogs}>
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <RefreshCw className="w-6 h-6 animate-spin text-gray-400" />
                </div>
              ) : logs.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Shield className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>Aucune action de modération enregistrée</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {Object.entries(groupedLogs).map(([date, dateLogs]) => (
                    <div key={date}>
                      <h3 className="text-sm font-medium text-gray-500 mb-3 capitalize">{date}</h3>
                      <div className="space-y-2">
                        {dateLogs.map((log) => {
                          const summary = getDetailsSummary(log);
                          const isExpanded = expandedLog === log.id;

                          return (
                            <div
                              key={log.id}
                              className={`p-3 border rounded-lg transition-colors cursor-pointer ${ACTION_COLORS[log.action_type] || 'bg-gray-50 border-gray-200'}`}
                              onClick={() => setExpandedLog(isExpanded ? null : log.id)}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm">
                                    {ACTION_ICONS[log.action_type] || ACTION_ICONS.other}
                                  </div>
                                  <div>
                                    <div className="flex items-center gap-2">
                                      <span className="font-medium text-sm">
                                        {ACTION_TYPE_LABELS[log.action_type] || log.action_type}
                                      </span>
                                      <Badge variant="outline" className="text-xs">
                                        {TARGET_TYPE_LABELS[log.target_type] || log.target_type}
                                      </Badge>
                                    </div>
                                    <div className="flex items-center gap-2 mt-0.5">
                                      <span className="text-xs text-gray-500">par {log.moderator_name}</span>
                                      {summary && (
                                        <span className="text-xs text-gray-400">— {summary}</span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-gray-400">{formatDate(log.created_at)}</span>
                                  <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                                </div>
                              </div>

                              {isExpanded && log.details && Object.keys(log.details).length > 0 && (
                                <div className="mt-3 pt-3 border-t border-gray-200/50">
                                  <pre className="text-xs text-gray-600 bg-white/50 p-2 rounded overflow-x-auto">
                                    {JSON.stringify(log.details, null, 2)}
                                  </pre>
                                  {log.target_id && (
                                    <p className="text-xs text-gray-400 mt-2">
                                      ID cible : {log.target_id}
                                    </p>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Banned Users Tab */}
        <TabsContent value="bans">
          {/* Unban success notification */}
          {unbanSuccess && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <span className="text-sm text-green-700 font-medium">{unbanSuccess}</span>
            </div>
          )}

          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Ban className="w-5 h-5 text-red-500" />
                    Utilisateurs bannis
                  </CardTitle>
                  <CardDescription>
                    Gérez les bannissements du chat. Vous pouvez lever un ban à tout moment.
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select value={banFilter} onValueChange={(v) => setBanFilter(v as 'active' | 'all')}>
                    <SelectTrigger className="w-44">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Bans actifs</SelectItem>
                      <SelectItem value="all">Tous les bans</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm" onClick={loadBans}>
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {bansLoading ? (
                <div className="flex items-center justify-center py-12">
                  <RefreshCw className="w-6 h-6 animate-spin text-gray-400" />
                </div>
              ) : bans.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <UserX className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p className="font-medium">Aucun utilisateur banni</p>
                  <p className="text-sm mt-1">
                    {banFilter === 'active'
                      ? "Il n'y a aucun bannissement actif pour le moment."
                      : "Aucun bannissement n'a été enregistré."}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {bans.map((ban) => {
                    const isExpired = ban.expires_at && new Date(ban.expires_at) < new Date();
                    const isActive = ban.is_active && !isExpired;

                    return (
                      <div
                        key={ban.id}
                        className={`p-4 border rounded-lg transition-colors ${
                          isActive
                            ? 'bg-red-50 border-red-200'
                            : 'bg-gray-50 border-gray-200 opacity-70'
                        }`}
                      >
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                          {/* Ban info */}
                          <div className="flex items-start gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                              isActive ? 'bg-red-100' : 'bg-gray-200'
                            }`}>
                              <UserX className={`w-5 h-5 ${isActive ? 'text-red-600' : 'text-gray-500'}`} />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-semibold text-sm">
                                  {ban.banned_user_name || 'Utilisateur inconnu'}
                                </span>
                                {isActive ? (
                                  <Badge variant="destructive" className="text-xs">
                                    Banni
                                  </Badge>
                                ) : isExpired ? (
                                  <Badge variant="outline" className="text-xs text-amber-600 border-amber-300">
                                    Expiré
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="text-xs text-green-600 border-green-300">
                                    Levé
                                  </Badge>
                                )}
                              </div>

                              {/* Reason */}
                              {ban.reason && (
                                <p className="text-sm text-gray-600 mt-1">
                                  <span className="font-medium">Raison :</span> {ban.reason}
                                </p>
                              )}

                              {/* Meta info */}
                              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1.5 text-xs text-gray-500">
                                <span className="flex items-center gap-1">
                                  <Shield className="w-3 h-3" />
                                  par {ban.banned_by_name || 'Modérateur'}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {formatFullDate(ban.created_at)}
                                </span>
                                {ban.expires_at ? (
                                  <span className={`flex items-center gap-1 ${
                                    isExpired ? 'text-amber-500' : 'text-red-500'
                                  }`}>
                                    <Clock className="w-3 h-3" />
                                    {isExpired ? 'Expiré le' : 'Expire le'} {formatFullDate(ban.expires_at)}
                                  </span>
                                ) : (
                                  <span className="flex items-center gap-1 text-red-500 font-medium">
                                    <Ban className="w-3 h-3" />
                                    Permanent
                                  </span>
                                )}
                                {ban.stream_id && (
                                  <span className="flex items-center gap-1">
                                    <Radio className="w-3 h-3" />
                                    Stream: {ban.stream_id.slice(0, 8)}...
                                  </span>
                                )}
                              </div>

                              {/* User ID */}
                              <p className="text-[11px] text-gray-400 mt-1 font-mono">
                                ID: {ban.user_id}
                              </p>
                            </div>
                          </div>

                          {/* Unban button */}
                          {isActive && (
                            <div className="flex-shrink-0">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleUnban(ban)}
                                disabled={unbanningId === ban.id}
                                className="border-green-300 text-green-700 hover:bg-green-50 hover:text-green-800 hover:border-green-400"
                              >
                                {unbanningId === ban.id ? (
                                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                ) : (
                                  <CheckCircle className="w-4 h-4 mr-2" />
                                )}
                                Lever le ban
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ModerationTab;
