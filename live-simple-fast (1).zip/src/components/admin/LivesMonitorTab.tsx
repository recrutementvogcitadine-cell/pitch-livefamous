import React, { useState, useEffect } from 'react';
import {
  Radio, Eye, Clock, Users, StopCircle, RefreshCw,
  Search, Wifi, WifiOff, TrendingUp, AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { VerificationBadge } from '@/components/VerificationBadge';
import { useToast } from '@/hooks/use-toast';
import { TeamMember, teamService } from '@/lib/teamService';

interface LivesMonitorTabProps {
  currentMember: TeamMember | null;
}

interface StreamData {
  id: string;
  title: string;
  is_live: boolean;
  viewer_count: number;
  started_at: string;
  ended_at: string | null;
  creator: {
    id: string;
    display_name: string;
    username: string;
    avatar_url: string | null;
    is_verified: boolean;
    user_id: string;
  } | null;
}


interface CreatorStatus {
  id: string;
  display_name: string;
  username: string;
  avatar_url: string | null;
  is_verified: boolean;
  is_online: boolean;
  current_stream_id: string | null;
  viewer_count: number;
  last_stream_at: string | null;
}

const LivesMonitorTab: React.FC<LivesMonitorTabProps> = ({ currentMember }) => {
  const { toast } = useToast();
  const [streams, setStreams] = useState<StreamData[]>([]);
  const [creatorStatuses, setCreatorStatuses] = useState<CreatorStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [creatorSearch, setCreatorSearch] = useState('');
  const [showCreators, setShowCreators] = useState(true);

  const canManageStreams = currentMember?.role === 'admin' || currentMember?.permissions?.manage_streams;

  useEffect(() => {
    loadData();
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [streamsData, statusesData] = await Promise.all([
      teamService.getLiveStreams(),
      teamService.getCreatorStatuses(),
    ]);
    setStreams(streamsData);
    setCreatorStatuses(statusesData);
    setLoading(false);
  };

  const handleEndStream = async (streamId: string, creatorName: string) => {
    if (!confirm(`Terminer le live de ${creatorName} ?`)) return;

    const result = await teamService.endStream(streamId);
    if (result.success) {
      toast({ title: 'Succès', description: 'Live terminé avec succès' });
      loadData();
    } else {
      toast({ title: 'Erreur', description: result.error, variant: 'destructive' });
    }
  };

  const formatDuration = (startedAt: string, endedAt?: string | null) => {
    const start = new Date(startedAt);
    const end = endedAt ? new Date(endedAt) : new Date();
    const diffMs = end.getTime() - start.getTime();
    const hours = Math.floor(diffMs / 3600000);
    const mins = Math.floor((diffMs % 3600000) / 60000);
    if (hours > 0) return `${hours}h ${mins}min`;
    return `${mins}min`;
  };

  const formatTime = (dateStr: string) => {
    return new Date(dateStr).toLocaleString('fr-FR', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  // Filter streams
  const filteredStreams = streams.filter(stream => {
    const streamStatus = stream.is_live ? 'live' : 'ended';
    const matchesStatus = statusFilter === 'all' || streamStatus === statusFilter;
    const matchesSearch = !searchQuery ||
      stream.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stream.creator?.display_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stream.creator?.username?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const activeStreams = streams.filter(s => s.is_live === true);
  const endedStreams = streams.filter(s => s.is_live === false);
  const totalViewers = activeStreams.reduce((sum, s) => sum + (s.viewer_count || 0), 0);


  // Filter creators
  const filteredCreators = creatorStatuses.filter(c =>
    !creatorSearch ||
    c.display_name.toLowerCase().includes(creatorSearch.toLowerCase()) ||
    c.username.toLowerCase().includes(creatorSearch.toLowerCase())
  );

  const onlineCreators = creatorStatuses.filter(c => c.is_online);

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-red-200 bg-red-50/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Lives en cours</p>
                <p className="text-3xl font-bold text-red-600">{activeStreams.length}</p>
              </div>
              <div className="relative">
                <Radio className="w-10 h-10 text-red-400 opacity-50" />
                {activeStreams.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Spectateurs total</p>
                <p className="text-3xl font-bold text-blue-600">{totalViewers}</p>
              </div>
              <Eye className="w-10 h-10 text-blue-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Lives terminés</p>
                <p className="text-3xl font-bold text-gray-600">{endedStreams.length}</p>
              </div>
              <Clock className="w-10 h-10 text-gray-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Créateurs en ligne</p>
                <p className="text-3xl font-bold text-green-600">{onlineCreators.length}</p>
              </div>
              <Wifi className="w-10 h-10 text-green-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Live Streams List */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Radio className="w-5 h-5" />
                Streams
              </CardTitle>
              <CardDescription>Surveillance en temps réel des lives</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Rechercher..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-56"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous</SelectItem>
                  <SelectItem value="live">En cours</SelectItem>
                  <SelectItem value="ended">Terminés</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm" onClick={loadData}>
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <RefreshCw className="w-6 h-6 animate-spin text-gray-400" />
            </div>
          ) : filteredStreams.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Radio className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>Aucun stream trouvé</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredStreams.map((stream) => (
                <div
                  key={stream.id}
                  className={`p-4 border rounded-lg transition-colors ${
                    stream.is_live
                      ? 'border-red-200 bg-red-50/30 hover:bg-red-50/50'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={stream.creator?.avatar_url || ''} />
                        <AvatarFallback>
                          {stream.creator?.display_name?.[0] || '?'}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">{stream.title || 'Sans titre'}</h4>
                          {stream.is_live && (
                            <Badge className="bg-red-500 text-white animate-pulse">
                              EN DIRECT
                            </Badge>
                          )}
                          {!stream.is_live && (
                            <Badge variant="outline" className="text-gray-500">
                              Terminé
                            </Badge>
                          )}
                        </div>

                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-sm text-gray-600">
                            {stream.creator?.display_name}
                          </span>
                          {stream.creator?.is_verified && (
                            <VerificationBadge isVerified={true} size="sm" />
                          )}
                          <span className="text-sm text-gray-400">
                            @{stream.creator?.username}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      {/* Viewer count */}
                      <div className="text-center">
                        <div className="flex items-center gap-1.5 text-blue-600">
                          <Eye className="w-4 h-4" />
                          <span className="font-bold">{stream.viewer_count || 0}</span>
                        </div>
                        <p className="text-xs text-gray-400">spectateurs</p>
                      </div>

                      {/* Duration */}
                      <div className="text-center">
                        <div className="flex items-center gap-1.5 text-gray-600">
                          <Clock className="w-4 h-4" />
                          <span className="font-medium text-sm">
                            {formatDuration(stream.started_at, stream.ended_at)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-400">
                          {formatTime(stream.started_at)}
                        </p>
                      </div>
                      {/* Actions */}
                      {stream.is_live && canManageStreams && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-red-600 border-red-300 hover:bg-red-50"
                          onClick={() => handleEndStream(stream.id, stream.creator?.display_name || 'Inconnu')}
                        >
                          <StopCircle className="w-4 h-4 mr-1" />
                          Terminer
                        </Button>
                      )}

                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Creator Status */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Statut des créateurs
              </CardTitle>
              <CardDescription>
                {onlineCreators.length} en ligne sur {creatorStatuses.length} créateurs
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Rechercher un créateur..."
                  value={creatorSearch}
                  onChange={(e) => setCreatorSearch(e.target.value)}
                  className="pl-9 w-56"
                />
              </div>
              <Button
                variant={showCreators ? 'default' : 'outline'}
                size="sm"
                onClick={() => setShowCreators(!showCreators)}
              >
                {showCreators ? 'Masquer' : 'Afficher'}
              </Button>
            </div>
          </div>
        </CardHeader>
        {showCreators && (
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {/* Online creators first */}
              {filteredCreators
                .sort((a, b) => {
                  if (a.is_online && !b.is_online) return -1;
                  if (!a.is_online && b.is_online) return 1;
                  return a.display_name.localeCompare(b.display_name);
                })
                .map((creator) => (
                  <div
                    key={creator.id}
                    className={`flex items-center gap-3 p-3 border rounded-lg transition-colors ${
                      creator.is_online
                        ? 'border-green-200 bg-green-50/30'
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className="relative">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={creator.avatar_url || ''} />
                        <AvatarFallback>{creator.display_name[0]}</AvatarFallback>
                      </Avatar>
                      <span
                        className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white ${
                          creator.is_online ? 'bg-green-500' : 'bg-gray-300'
                        }`}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1">
                        <p className="font-medium text-sm truncate">{creator.display_name}</p>
                        {creator.is_verified && <VerificationBadge isVerified={true} size="sm" />}
                      </div>
                      <p className="text-xs text-gray-400">@{creator.username}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      {creator.is_online ? (
                        <div className="flex items-center gap-1 text-green-600">
                          <Wifi className="w-3.5 h-3.5" />
                          <span className="text-xs font-medium">{creator.viewer_count}</span>
                        </div>
                      ) : (
                        <WifiOff className="w-3.5 h-3.5 text-gray-300" />
                      )}
                    </div>
                  </div>
                ))}
              {filteredCreators.length === 0 && (
                <div className="col-span-full text-center py-8 text-gray-500">
                  Aucun créateur trouvé
                </div>
              )}
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
};

export default LivesMonitorTab;
