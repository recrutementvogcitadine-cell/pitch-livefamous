import React, { useMemo } from 'react';
import {
  Crown, Shield, UserCheck, Eye, ArrowRight,
  ChevronUp, ChevronDown, Minus, Plus, AlertTriangle, Lock,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  TeamMember,
  TeamPermissions,
  DEFAULT_PERMISSIONS,
  PERMISSION_LABELS,
  ROLE_LABELS,
} from '@/lib/teamService';

interface RoleChangeConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member: TeamMember | null;
  newRole: 'admin' | 'moderator' | 'read_only';
  loading: boolean;
  onConfirm: () => void;
}

const ROLE_COLORS: Record<string, string> = {
  owner: 'bg-amber-100 text-amber-800 border-amber-300',
  admin: 'bg-purple-100 text-purple-700 border-purple-200',
  moderator: 'bg-blue-100 text-blue-700 border-blue-200',
  read_only: 'bg-gray-100 text-gray-600 border-gray-200',
};

const ROLE_BG: Record<string, string> = {
  owner: 'bg-gradient-to-br from-amber-500 to-orange-500',
  admin: 'bg-gradient-to-br from-purple-500 to-indigo-500',
  moderator: 'bg-gradient-to-br from-blue-500 to-cyan-500',
  read_only: 'bg-gradient-to-br from-gray-400 to-gray-500',
};

const ROLE_ICONS: Record<string, React.ReactNode> = {
  owner: <Crown className="w-4 h-4" />,
  admin: <Shield className="w-4 h-4" />,
  moderator: <UserCheck className="w-4 h-4" />,
  read_only: <Eye className="w-4 h-4" />,
};

const ROLE_ORDER = ['read_only', 'moderator', 'admin', 'owner'];

type PermDiff = {
  key: keyof TeamPermissions;
  label: string;
  oldValue: boolean;
  newValue: boolean;
  status: 'gained' | 'lost' | 'unchanged';
};

const RoleChangeConfirmDialog: React.FC<RoleChangeConfirmDialogProps> = ({
  open,
  onOpenChange,
  member,
  newRole,
  loading,
  onConfirm,
}) => {
  const currentRole = member?.role || 'read_only';
  const isPromotion = ROLE_ORDER.indexOf(newRole) > ROLE_ORDER.indexOf(currentRole);
  const isDemotion = ROLE_ORDER.indexOf(newRole) < ROLE_ORDER.indexOf(currentRole);

  const permissionDiffs = useMemo<PermDiff[]>(() => {
    if (!member) return [];
    const currentPerms = member.permissions || DEFAULT_PERMISSIONS[currentRole];
    const newPerms = DEFAULT_PERMISSIONS[newRole];

    return (Object.keys(PERMISSION_LABELS) as Array<keyof TeamPermissions>).map((key) => {
      const oldVal = currentPerms[key] ?? false;
      const newVal = newPerms[key] ?? false;
      let status: PermDiff['status'] = 'unchanged';
      if (!oldVal && newVal) status = 'gained';
      if (oldVal && !newVal) status = 'lost';
      return {
        key,
        label: PERMISSION_LABELS[key],
        oldValue: oldVal,
        newValue: newVal,
        status,
      };
    });
  }, [member, currentRole, newRole]);

  const gained = permissionDiffs.filter((d) => d.status === 'gained');
  const lost = permissionDiffs.filter((d) => d.status === 'lost');
  const unchanged = permissionDiffs.filter((d) => d.status === 'unchanged');

  if (!member) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isPromotion ? (
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <ChevronUp className="w-5 h-5 text-green-600" />
              </div>
            ) : isDemotion ? (
              <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center">
                <ChevronDown className="w-5 h-5 text-orange-600" />
              </div>
            ) : null}
            <span>
              {isPromotion ? 'Promouvoir' : isDemotion ? 'Rétrograder' : 'Modifier le rôle de'}{' '}
              {member.display_name}
            </span>
          </DialogTitle>
          <DialogDescription>
            Vérifiez les changements de permissions avant de confirmer.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          {/* Member info + role transition */}
          <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border">
            <Avatar className="w-14 h-14 ring-2 ring-white shadow-md">
              <AvatarFallback
                className={`font-bold text-lg text-white ${ROLE_BG[currentRole]}`}
              >
                {member.display_name[0]?.toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h4 className="font-semibold text-base">{member.display_name}</h4>
              <p className="text-sm text-gray-500">{member.email}</p>
            </div>
          </div>

          {/* Role transition visual */}
          <div className="flex items-center justify-center gap-4 py-3">
            <div className="flex flex-col items-center gap-1.5">
              <div
                className={`w-14 h-14 rounded-xl flex items-center justify-center text-white shadow-md ${ROLE_BG[currentRole]}`}
              >
                {React.cloneElement(ROLE_ICONS[currentRole] as React.ReactElement, {
                  className: 'w-6 h-6',
                })}
              </div>
              <Badge className={`${ROLE_COLORS[currentRole]} text-xs`}>
                {ROLE_LABELS[currentRole]}
              </Badge>
              <span className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold">
                Actuel
              </span>
            </div>

            <div className="flex flex-col items-center gap-1">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  isPromotion
                    ? 'bg-green-100 text-green-600'
                    : 'bg-orange-100 text-orange-600'
                }`}
              >
                <ArrowRight className="w-5 h-5" />
              </div>
              <span
                className={`text-xs font-semibold ${
                  isPromotion ? 'text-green-600' : 'text-orange-600'
                }`}
              >
                {isPromotion ? 'Promotion' : 'Rétrogradation'}
              </span>
            </div>

            <div className="flex flex-col items-center gap-1.5">
              <div
                className={`w-14 h-14 rounded-xl flex items-center justify-center text-white shadow-md ring-2 ring-offset-2 ${
                  isPromotion ? 'ring-green-400' : 'ring-orange-400'
                } ${ROLE_BG[newRole]}`}
              >
                {React.cloneElement(ROLE_ICONS[newRole] as React.ReactElement, {
                  className: 'w-6 h-6',
                })}
              </div>
              <Badge className={`${ROLE_COLORS[newRole]} text-xs`}>
                {ROLE_LABELS[newRole]}
              </Badge>
              <span className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold">
                Nouveau
              </span>
            </div>
          </div>

          {/* Permission changes */}
          <div className="space-y-3">
            <h5 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Changements de permissions
            </h5>

            {/* Gained permissions */}
            {gained.length > 0 && (
              <div className="rounded-lg border border-green-200 bg-green-50/50 overflow-hidden">
                <div className="px-3 py-2 bg-green-100/60 border-b border-green-200">
                  <span className="text-xs font-semibold text-green-700 uppercase tracking-wide flex items-center gap-1.5">
                    <Plus className="w-3.5 h-3.5" />
                    Permissions accordées ({gained.length})
                  </span>
                </div>
                <div className="divide-y divide-green-100">
                  {gained.map((d) => (
                    <div
                      key={d.key}
                      className="flex items-center gap-3 px-3 py-2.5 text-sm"
                    >
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                        <Plus className="w-3.5 h-3.5 text-green-600" />
                      </div>
                      <span className="text-green-800 font-medium">{d.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Lost permissions */}
            {lost.length > 0 && (
              <div className="rounded-lg border border-red-200 bg-red-50/50 overflow-hidden">
                <div className="px-3 py-2 bg-red-100/60 border-b border-red-200">
                  <span className="text-xs font-semibold text-red-700 uppercase tracking-wide flex items-center gap-1.5">
                    <Minus className="w-3.5 h-3.5" />
                    Permissions retirées ({lost.length})
                  </span>
                </div>
                <div className="divide-y divide-red-100">
                  {lost.map((d) => (
                    <div
                      key={d.key}
                      className="flex items-center gap-3 px-3 py-2.5 text-sm"
                    >
                      <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                        <Minus className="w-3.5 h-3.5 text-red-600" />
                      </div>
                      <span className="text-red-800 font-medium line-through decoration-red-300">
                        {d.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Unchanged permissions */}
            {unchanged.length > 0 && (
              <div className="rounded-lg border border-gray-200 bg-gray-50/50 overflow-hidden">
                <div className="px-3 py-2 bg-gray-100/60 border-b border-gray-200">
                  <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                    Permissions inchangées ({unchanged.length})
                  </span>
                </div>
                <div className="divide-y divide-gray-100">
                  {unchanged.map((d) => (
                    <div
                      key={d.key}
                      className="flex items-center gap-3 px-3 py-2 text-sm"
                    >
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                          d.newValue
                            ? 'bg-green-100 text-green-500'
                            : 'bg-gray-200 text-gray-400'
                        }`}
                      >
                        {d.newValue ? (
                          <svg
                            className="w-3 h-3"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={3}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M5 13l4 4L19 7"
                            />
                          </svg>
                        ) : (
                          <svg
                            className="w-3 h-3"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={3}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M6 18L18 6M6 6l12 12"
                            />
                          </svg>
                        )}
                      </div>
                      <span className={d.newValue ? 'text-gray-700' : 'text-gray-400'}>
                        {d.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Warning for demotion */}
          {isDemotion && (
            <div className="flex items-start gap-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-orange-800">Attention</p>
                <p className="text-sm text-orange-700 mt-0.5">
                  {member.display_name} perdra immédiatement l'accès aux fonctionnalités
                  retirées. Cette action est réversible.
                </p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Annuler
          </Button>
          <Button
            onClick={onConfirm}
            disabled={loading}
            className={
              isPromotion
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-orange-600 hover:bg-orange-700 text-white'
            }
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                    fill="none"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                  />
                </svg>
                Modification...
              </span>
            ) : (
              <>
                {isPromotion ? (
                  <ChevronUp className="w-4 h-4 mr-1.5" />
                ) : (
                  <ChevronDown className="w-4 h-4 mr-1.5" />
                )}
                Confirmer la {isPromotion ? 'promotion' : 'rétrogradation'}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RoleChangeConfirmDialog;
