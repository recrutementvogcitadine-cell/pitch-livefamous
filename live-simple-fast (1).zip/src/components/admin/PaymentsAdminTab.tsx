import React, { useState, useEffect, useMemo } from 'react';
import {
  DollarSign, TrendingUp, Search, Filter, Download, RefreshCw,
  CheckCircle, XCircle, ArrowUpDown, ChevronDown, Phone,
  Calendar, CreditCard, BarChart3, AlertCircle, Loader2,
  ArrowDownCircle, ArrowUpCircle, Clock, Ban
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { TeamMember } from '@/lib/teamService';
import { paymentService, paymentProviders, PaymentProvider } from '@/lib/paymentService';

interface PaymentsAdminTabProps {
  currentMember: TeamMember | null;
}

interface AdminPayment {
  id: string;
  creator_id: string;
  subscription_id: string | null;
  amount: number;
  currency: string;
  payment_method: string;
  provider: string;
  phone_number: string;
  transaction_id: string;
  external_reference: string | null;
  status: string;
  status_message: string;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  creator?: {
    id: string;
    display_name: string;
    username: string;
    avatar_url: string | null;
  };
}

interface MonthlyRevenue {
  month: string;
  label: string;
  total: number;
  completed: number;
  count: number;
}

const PaymentsAdminTab: React.FC<PaymentsAdminTabProps> = ({ currentMember }) => {
  const { toast } = useToast();
  const [payments, setPayments] = useState<AdminPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [providerFilter, setProviderFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [sortField, setSortField] = useState<'created_at' | 'amount'>('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Modal states
  const [updateModal, setUpdateModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<AdminPayment | null>(null);
  const [newStatus, setNewStatus] = useState('');
  const [adminNote, setAdminNote] = useState('');
  const [updating, setUpdating] = useState(false);

  const isAdmin = currentMember?.role === 'owner' || currentMember?.role === 'admin';

  useEffect(() => {
    loadPayments();
  }, []);

  const loadPayments = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('process-payment', {
        body: { action: 'admin_get_all_payments' }
      });

      if (error) throw error;
      if (data?.payments) {
        setPayments(data.payments);
      } else if (data?.error) {
        throw new Error(typeof data.error === 'string' ? data.error : 'Erreur serveur');
      }
    } catch (err: any) {
      const msg = err?.message || '';
      const lower = msg.toLowerCase();
      const isUpstream = lower.includes('upstream') || lower.includes('functionshttp') || lower.includes('functionsrelay') || lower.includes('unexpected token');
      console.warn('Error loading payments:', msg);
      toast({
        title: 'Erreur',
        description: isUpstream ? 'Le service de paiement n\'est pas disponible actuellement.' : (msg || 'Impossible de charger les paiements'),
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };


  // ==================== COMPUTED STATS ====================
  const stats = useMemo(() => {
    const totalRevenue = payments
      .filter(p => p.status === 'completed')
      .reduce((sum, p) => sum + p.amount, 0);

    const totalPending = payments
      .filter(p => p.status === 'pending' || p.status === 'processing')
      .reduce((sum, p) => sum + p.amount, 0);

    const totalRefunded = payments
      .filter(p => p.status === 'refunded')
      .reduce((sum, p) => sum + p.amount, 0);

    const byProvider: Record<string, { count: number; revenue: number }> = {};
    payments.forEach(p => {
      if (!byProvider[p.provider]) {
        byProvider[p.provider] = { count: 0, revenue: 0 };
      }
      byProvider[p.provider].count++;
      if (p.status === 'completed') {
        byProvider[p.provider].revenue += p.amount;
      }
    });

    const totalPayments = payments.length;
    const completedPayments = payments.filter(p => p.status === 'completed').length;
    const failedPayments = payments.filter(p => p.status === 'failed').length;
    const successRate = totalPayments > 0 ? (completedPayments / totalPayments * 100) : 0;
    const failureRate = totalPayments > 0 ? (failedPayments / totalPayments * 100) : 0;

    return {
      totalRevenue,
      totalPending,
      totalRefunded,
      totalPayments,
      completedPayments,
      failedPayments,
      successRate,
      failureRate,
      byProvider
    };
  }, [payments]);

  // ==================== MONTHLY REVENUE CHART DATA ====================
  const monthlyRevenue = useMemo(() => {
    const months: Record<string, MonthlyRevenue> = {};
    const now = new Date();

    // Initialize last 6 months
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = d.toLocaleDateString('fr-FR', { month: 'short', year: '2-digit' });
      months[key] = { month: key, label, total: 0, completed: 0, count: 0 };
    }

    payments.forEach(p => {
      const d = new Date(p.created_at);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      if (months[key]) {
        months[key].total += p.amount;
        months[key].count++;
        if (p.status === 'completed') {
          months[key].completed += p.amount;
        }
      }
    });

    return Object.values(months);
  }, [payments]);

  const maxMonthlyRevenue = useMemo(() => {
    return Math.max(...monthlyRevenue.map(m => m.completed), 1);
  }, [monthlyRevenue]);

  // ==================== FILTERED & SORTED PAYMENTS ====================
  const filteredPayments = useMemo(() => {
    let result = [...payments];

    // Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.transaction_id?.toLowerCase().includes(q) ||
        p.phone_number?.toLowerCase().includes(q) ||
        p.creator?.display_name?.toLowerCase().includes(q) ||
        p.creator?.username?.toLowerCase().includes(q) ||
        p.external_reference?.toLowerCase().includes(q)
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      result = result.filter(p => p.status === statusFilter);
    }

    // Provider filter
    if (providerFilter !== 'all') {
      result = result.filter(p => p.provider === providerFilter);
    }

    // Date filter
    if (dateFilter !== 'all') {
      const now = new Date();
      let cutoff: Date;
      switch (dateFilter) {
        case 'today':
          cutoff = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          break;
        case 'week':
          cutoff = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        case 'month':
          cutoff = new Date(now.getFullYear(), now.getMonth(), 1);
          break;
        case '3months':
          cutoff = new Date(now.getFullYear(), now.getMonth() - 3, 1);
          break;
        default:
          cutoff = new Date(0);
      }
      result = result.filter(p => new Date(p.created_at) >= cutoff);
    }

    // Sort
    result.sort((a, b) => {
      const valA = sortField === 'amount' ? a.amount : new Date(a.created_at).getTime();
      const valB = sortField === 'amount' ? b.amount : new Date(b.created_at).getTime();
      return sortOrder === 'asc' ? valA - valB : valB - valA;
    });

    return result;
  }, [payments, searchQuery, statusFilter, providerFilter, dateFilter, sortField, sortOrder]);

  // ==================== HANDLERS ====================
  const handleUpdatePayment = async () => {
    if (!selectedPayment || !newStatus) return;
    setUpdating(true);
    try {
      const { data, error } = await supabase.functions.invoke('process-payment', {
        body: {
          action: 'admin_update_payment_status',
          payment_id: selectedPayment.id,
          new_status: newStatus,
          admin_note: adminNote || undefined
        }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast({
        title: 'Succès',
        description: `Paiement mis à jour: ${getStatusLabel(newStatus)}`
      });
      setUpdateModal(false);
      setSelectedPayment(null);
      setNewStatus('');
      setAdminNote('');
      loadPayments();
    } catch (err: any) {
      toast({
        title: 'Erreur',
        description: err.message || 'Impossible de mettre à jour le paiement',
        variant: 'destructive'
      });
    } finally {
      setUpdating(false);
    }
  };

  const openUpdateModal = (payment: AdminPayment, status: string) => {
    setSelectedPayment(payment);
    setNewStatus(status);
    setAdminNote('');
    setUpdateModal(true);
  };

  // ==================== CSV EXPORT ====================
  const exportToCSV = () => {
    const headers = [
      'ID Transaction',
      'Date',
      'Créateur',
      'Username',
      'Montant',
      'Devise',
      'Fournisseur',
      'Téléphone',
      'Statut',
      'Référence externe',
      'Date confirmation',
      'Plan',
      'Cycle'
    ];

    const rows = filteredPayments.map(p => [
      p.transaction_id,
      new Date(p.created_at).toLocaleString('fr-FR'),
      p.creator?.display_name || 'Inconnu',
      p.creator?.username || '-',
      p.amount.toString(),
      p.currency,
      getProviderName(p.provider),
      p.phone_number,
      getStatusLabel(p.status),
      p.external_reference || '-',
      p.completed_at ? new Date(p.completed_at).toLocaleString('fr-FR') : '-',
      p.metadata?.plan_name || '-',
      p.metadata?.billing_cycle === 'monthly' ? 'Mensuel' : p.metadata?.billing_cycle === 'yearly' ? 'Annuel' : '-'
    ]);

    const csvContent = [
      headers.join(';'),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(';'))
    ].join('\n');

    // Add BOM for Excel UTF-8 compatibility
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `paiements_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: 'Export réussi',
      description: `${filteredPayments.length} transactions exportées en CSV`
    });
  };

  // ==================== HELPERS ====================
  const formatAmount = (amount: number, currency: string = 'XOF') => {
    return paymentService.formatAmount(amount, currency);
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: 'En attente',
      processing: 'En cours',
      completed: 'Confirmé',
      failed: 'Échoué',
      cancelled: 'Annulé',
      refunded: 'Remboursé'
    };
    return labels[status] || status;
  };

  const getStatusBadgeClass = (status: string) => {
    const classes: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      processing: 'bg-blue-100 text-blue-800 border-blue-200',
      completed: 'bg-green-100 text-green-800 border-green-200',
      failed: 'bg-red-100 text-red-800 border-red-200',
      cancelled: 'bg-gray-100 text-gray-800 border-gray-200',
      refunded: 'bg-purple-100 text-purple-800 border-purple-200'
    };
    return classes[status] || 'bg-gray-100 text-gray-800';
  };

  const getProviderName = (provider: string) => {
    const names: Record<string, string> = {
      orange_money: 'Orange Money',
      mtn_money: 'MTN Money',
      wave: 'Wave'
    };
    return names[provider] || provider;
  };

  const getProviderColor = (provider: string) => {
    const colors: Record<string, string> = {
      orange_money: 'bg-orange-500',
      mtn_money: 'bg-yellow-500',
      wave: 'bg-cyan-500'
    };
    return colors[provider] || 'bg-gray-500';
  };

  const getProviderBgClass = (provider: string) => {
    const classes: Record<string, string> = {
      orange_money: 'bg-orange-50 border-orange-200',
      mtn_money: 'bg-yellow-50 border-yellow-200',
      wave: 'bg-cyan-50 border-cyan-200'
    };
    return classes[provider] || 'bg-gray-50 border-gray-200';
  };

  const toggleSort = (field: 'created_at' | 'amount') => {
    if (sortField === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-purple-600" />
          <p className="mt-3 text-gray-500">Chargement des paiements...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ==================== SUMMARY CARDS ==================== */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-600">Revenus totaux</p>
                <p className="text-2xl font-bold text-green-800 mt-1">
                  {formatAmount(stats.totalRevenue)}
                </p>
                <p className="text-xs text-green-500 mt-1">
                  {stats.completedPayments} paiement{stats.completedPayments !== 1 ? 's' : ''} confirmé{stats.completedPayments !== 1 ? 's' : ''}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-yellow-200 bg-gradient-to-br from-yellow-50 to-amber-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-600">En attente</p>
                <p className="text-2xl font-bold text-yellow-800 mt-1">
                  {formatAmount(stats.totalPending)}
                </p>
                <p className="text-xs text-yellow-500 mt-1">
                  {payments.filter(p => p.status === 'pending' || p.status === 'processing').length} transaction{payments.filter(p => p.status === 'pending' || p.status === 'processing').length !== 1 ? 's' : ''}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">Taux de succès</p>
                <p className="text-2xl font-bold text-blue-800 mt-1">
                  {stats.successRate.toFixed(1)}%
                </p>
                <p className="text-xs text-blue-500 mt-1">
                  {stats.totalPayments} total / {stats.failedPayments} échoué{stats.failedPayments !== 1 ? 's' : ''}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-violet-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-600">Remboursements</p>
                <p className="text-2xl font-bold text-purple-800 mt-1">
                  {formatAmount(stats.totalRefunded)}
                </p>
                <p className="text-xs text-purple-500 mt-1">
                  {payments.filter(p => p.status === 'refunded').length} remboursement{payments.filter(p => p.status === 'refunded').length !== 1 ? 's' : ''}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <ArrowDownCircle className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ==================== REVENUE BY PROVIDER + CHART ==================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue by Provider */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Revenus par fournisseur
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(stats.byProvider).length === 0 ? (
                <p className="text-gray-400 text-center py-4">Aucune donnée disponible</p>
              ) : (
                Object.entries(stats.byProvider)
                  .sort((a, b) => b[1].revenue - a[1].revenue)
                  .map(([provider, data]) => {
                    const percentage = stats.totalRevenue > 0 
                      ? (data.revenue / stats.totalRevenue * 100) 
                      : 0;
                    return (
                      <div key={provider} className={`p-4 rounded-lg border ${getProviderBgClass(provider)}`}>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-3">
                            <div className={`w-3 h-3 rounded-full ${getProviderColor(provider)}`} />
                            <span className="font-medium">{getProviderName(provider)}</span>
                          </div>
                          <div className="text-right">
                            <p className="font-bold">{formatAmount(data.revenue)}</p>
                            <p className="text-xs text-gray-500">{data.count} transaction{data.count !== 1 ? 's' : ''}</p>
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full transition-all duration-500 ${getProviderColor(provider)}`}
                            style={{ width: `${Math.max(percentage, 2)}%` }}
                          />
                        </div>
                        <p className="text-xs text-gray-500 mt-1">{percentage.toFixed(1)}% du total</p>
                      </div>
                    );
                  })
              )}
            </div>
          </CardContent>
        </Card>

        {/* Monthly Revenue Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Revenus mensuels (6 derniers mois)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-3 h-52">
              {monthlyRevenue.map((month) => {
                const heightPercent = maxMonthlyRevenue > 0
                  ? (month.completed / maxMonthlyRevenue * 100)
                  : 0;
                return (
                  <div key={month.month} className="flex-1 flex flex-col items-center gap-2">
                    <div className="w-full flex flex-col items-center justify-end h-40">
                      <span className="text-xs font-medium text-gray-600 mb-1">
                        {month.completed > 0 ? formatAmount(month.completed) : ''}
                      </span>
                      <div
                        className="w-full bg-gradient-to-t from-purple-600 to-purple-400 rounded-t-md transition-all duration-700 min-h-[4px] relative group"
                        style={{ height: `${Math.max(heightPercent, 3)}%` }}
                      >
                        <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                          {month.count} paiement{month.count !== 1 ? 's' : ''}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500 font-medium">{month.label}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ==================== TRANSACTIONS TABLE ==================== */}
      <Card>
        <CardHeader>
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Toutes les transactions
              </CardTitle>
              <CardDescription>
                {filteredPayments.length} transaction{filteredPayments.length !== 1 ? 's' : ''} 
                {filteredPayments.length !== payments.length && ` sur ${payments.length}`}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={loadPayments}>
                <RefreshCw className="w-4 h-4 mr-1" />
                Actualiser
              </Button>
              <Button variant="outline" size="sm" onClick={exportToCSV} disabled={filteredPayments.length === 0}>
                <Download className="w-4 h-4 mr-1" />
                Export CSV
              </Button>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2 mt-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Rechercher par ID, téléphone, créateur..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="pending">En attente</SelectItem>
                <SelectItem value="processing">En cours</SelectItem>
                <SelectItem value="completed">Confirmé</SelectItem>
                <SelectItem value="failed">Échoué</SelectItem>
                <SelectItem value="refunded">Remboursé</SelectItem>
                <SelectItem value="cancelled">Annulé</SelectItem>
              </SelectContent>
            </Select>
            <Select value={providerFilter} onValueChange={setProviderFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Fournisseur" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les fournisseurs</SelectItem>
                <SelectItem value="orange_money">Orange Money</SelectItem>
                <SelectItem value="mtn_money">MTN Money</SelectItem>
                <SelectItem value="wave">Wave</SelectItem>
              </SelectContent>
            </Select>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Période" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toute période</SelectItem>
                <SelectItem value="today">Aujourd'hui</SelectItem>
                <SelectItem value="week">7 derniers jours</SelectItem>
                <SelectItem value="month">Ce mois</SelectItem>
                <SelectItem value="3months">3 derniers mois</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-gray-50/50">
                  <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase">
                    Créateur
                  </th>
                  <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase">
                    Transaction
                  </th>
                  <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase">
                    Fournisseur
                  </th>
                  <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase">
                    Téléphone
                  </th>
                  <th
                    className="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase cursor-pointer hover:text-gray-700 select-none"
                    onClick={() => toggleSort('amount')}
                  >
                    <div className="flex items-center gap-1">
                      Montant
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase">
                    Statut
                  </th>
                  <th
                    className="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase cursor-pointer hover:text-gray-700 select-none"
                    onClick={() => toggleSort('created_at')}
                  >
                    <div className="flex items-center gap-1">
                      Date
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  {isAdmin && (
                    <th className="text-right py-3 px-3 text-xs font-semibold text-gray-500 uppercase">
                      Actions
                    </th>
                  )}
                </tr>
              </thead>
              <tbody>
                {filteredPayments.map((payment) => (
                  <tr key={payment.id} className="border-b hover:bg-gray-50/50 transition-colors">
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={payment.creator?.avatar_url || ''} />
                          <AvatarFallback className="text-xs">
                            {payment.creator?.display_name?.[0] || '?'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-sm">{payment.creator?.display_name || 'Inconnu'}</p>
                          <p className="text-xs text-gray-400">@{payment.creator?.username || '?'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <p className="text-xs font-mono text-gray-600">{payment.transaction_id}</p>
                      {payment.metadata?.plan_name && (
                        <p className="text-xs text-gray-400 mt-0.5">
                          {payment.metadata.plan_name} ({payment.metadata.billing_cycle === 'monthly' ? 'Mensuel' : 'Annuel'})
                        </p>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-2.5 h-2.5 rounded-full ${getProviderColor(payment.provider)}`} />
                        <span className="text-sm">{getProviderName(payment.provider)}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1 text-sm text-gray-600">
                        <Phone className="w-3 h-3" />
                        {payment.phone_number}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-semibold text-sm">
                        {formatAmount(payment.amount, payment.currency)}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <Badge className={`text-xs ${getStatusBadgeClass(payment.status)}`}>
                        {getStatusLabel(payment.status)}
                      </Badge>
                    </td>
                    <td className="py-3 px-3">
                      <div>
                        <p className="text-sm text-gray-600">
                          {new Date(payment.created_at).toLocaleDateString('fr-FR')}
                        </p>
                        <p className="text-xs text-gray-400">
                          {new Date(payment.created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </td>
                    {isAdmin && (
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {(payment.status === 'pending' || payment.status === 'processing') && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-green-600 border-green-200 hover:bg-green-50 h-7 px-2 text-xs"
                              onClick={() => openUpdateModal(payment, 'completed')}
                            >
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Confirmer
                            </Button>
                          )}
                          {payment.status === 'completed' && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-purple-600 border-purple-200 hover:bg-purple-50 h-7 px-2 text-xs"
                              onClick={() => openUpdateModal(payment, 'refunded')}
                            >
                              <ArrowDownCircle className="w-3 h-3 mr-1" />
                              Rembourser
                            </Button>
                          )}
                          {(payment.status === 'pending' || payment.status === 'processing') && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 border-red-200 hover:bg-red-50 h-7 px-2 text-xs"
                              onClick={() => openUpdateModal(payment, 'failed')}
                            >
                              <XCircle className="w-3 h-3 mr-1" />
                              Échouer
                            </Button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredPayments.length === 0 && (
              <div className="text-center py-12">
                <DollarSign className="w-12 h-12 mx-auto text-gray-300 mb-3" />
                <p className="text-gray-500 font-medium">Aucune transaction trouvée</p>
                <p className="text-gray-400 text-sm mt-1">
                  {payments.length > 0
                    ? 'Essayez de modifier vos filtres'
                    : 'Les paiements Mobile Money apparaîtront ici'}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ==================== UPDATE PAYMENT MODAL ==================== */}
      <Dialog open={updateModal} onOpenChange={setUpdateModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {newStatus === 'completed' && <CheckCircle className="w-5 h-5 text-green-600" />}
              {newStatus === 'refunded' && <ArrowDownCircle className="w-5 h-5 text-purple-600" />}
              {newStatus === 'failed' && <XCircle className="w-5 h-5 text-red-600" />}
              {newStatus === 'completed' && 'Confirmer le paiement'}
              {newStatus === 'refunded' && 'Rembourser le paiement'}
              {newStatus === 'failed' && 'Marquer comme échoué'}
            </DialogTitle>
          </DialogHeader>

          {selectedPayment && (
            <div className="space-y-4">
              {/* Payment summary */}
              <div className="p-4 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Transaction</span>
                  <span className="text-sm font-mono">{selectedPayment.transaction_id}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Créateur</span>
                  <span className="text-sm font-medium">{selectedPayment.creator?.display_name || 'Inconnu'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Montant</span>
                  <span className="text-sm font-bold">{formatAmount(selectedPayment.amount, selectedPayment.currency)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Fournisseur</span>
                  <span className="text-sm">{getProviderName(selectedPayment.provider)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Statut actuel</span>
                  <Badge className={`text-xs ${getStatusBadgeClass(selectedPayment.status)}`}>
                    {getStatusLabel(selectedPayment.status)}
                  </Badge>
                </div>
              </div>

              {/* Warning for refund */}
              {newStatus === 'refunded' && (
                <div className="flex items-start gap-2 p-3 bg-purple-50 border border-purple-200 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-purple-700">
                    <p className="font-medium">Attention</p>
                    <p>Le remboursement désactivera automatiquement l'abonnement associé à ce paiement.</p>
                  </div>
                </div>
              )}

              {newStatus === 'completed' && (
                <div className="flex items-start gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-green-700">
                    <p className="font-medium">Confirmation manuelle</p>
                    <p>L'abonnement sera automatiquement activé après confirmation.</p>
                  </div>
                </div>
              )}

              <div>
                <Label>Note administrateur (optionnel)</Label>
                <Textarea
                  value={adminNote}
                  onChange={(e) => setAdminNote(e.target.value)}
                  placeholder="Ajouter une note explicative..."
                  rows={3}
                  className="mt-1"
                />
              </div>

              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setUpdateModal(false)} disabled={updating}>
                  Annuler
                </Button>
                <Button
                  onClick={handleUpdatePayment}
                  disabled={updating}
                  className={
                    newStatus === 'completed' ? 'bg-green-600 hover:bg-green-700' :
                    newStatus === 'refunded' ? 'bg-purple-600 hover:bg-purple-700' :
                    'bg-red-600 hover:bg-red-700'
                  }
                >
                  {updating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Mise à jour...
                    </>
                  ) : (
                    <>
                      {newStatus === 'completed' && <CheckCircle className="w-4 h-4 mr-2" />}
                      {newStatus === 'refunded' && <ArrowDownCircle className="w-4 h-4 mr-2" />}
                      {newStatus === 'failed' && <XCircle className="w-4 h-4 mr-2" />}
                      {newStatus === 'completed' && 'Confirmer le paiement'}
                      {newStatus === 'refunded' && 'Rembourser'}
                      {newStatus === 'failed' && 'Marquer comme échoué'}
                    </>
                  )}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PaymentsAdminTab;
