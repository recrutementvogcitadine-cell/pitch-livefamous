import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import AuthModal from './AuthModal';

import CreatorProfileForm from './CreatorProfileForm';
import StartLiveModal from './StartLiveModal';
import SubscriptionModal from './SubscriptionModal';

interface CreatorData {
  id: string;
  username: string;
  display_name: string;
  bio: string | null;
  avatar_url: string | null;
  is_verified: boolean;
  followers_count: number;
  total_views: number;
}

const HERO_IMAGE = 'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471948412_fdc6f331.jpg';
const STREAMING_IMAGE = 'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471994946_501e455b.png';

const FALLBACK_AVATARS = [
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471962230_9ffb24ac.jpg',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471963594_5644eaf8.jpg',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471964934_c0e82b9f.jpg',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471969898_3fdcbee1.png',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471971304_bb185e18.png',
  'https://d64gsuwffb70l.cloudfront.net/698273729b52c79e1b5870ee_1770471972611_77eb0e03.png',
];

// Demo creators shown as fallback
const DEMO_CREATORS: CreatorData[] = [
  { id: '1', username: 'aminata_ci', display_name: 'Aminata', bio: 'Créatrice de contenu', avatar_url: FALLBACK_AVATARS[0], is_verified: true, followers_count: 12500, total_views: 45000 },
  { id: '2', username: 'kouame_live', display_name: 'Kouamé Live', bio: 'Musique & divertissement', avatar_url: FALLBACK_AVATARS[1], is_verified: true, followers_count: 8700, total_views: 32000 },
  { id: '3', username: 'fatou_style', display_name: 'Fatou Style', bio: 'Mode & beauté', avatar_url: FALLBACK_AVATARS[2], is_verified: false, followers_count: 5200, total_views: 18000 },
  { id: '4', username: 'yao_comedy', display_name: 'Yao Comedy', bio: 'Humour ivoirien', avatar_url: FALLBACK_AVATARS[3], is_verified: true, followers_count: 15800, total_views: 67000 },
  { id: '5', username: 'awa_cuisine', display_name: 'Awa Cuisine', bio: 'Recettes africaines', avatar_url: FALLBACK_AVATARS[4], is_verified: false, followers_count: 3400, total_views: 12000 },
  { id: '6', username: 'dj_abidjan', display_name: 'DJ Abidjan', bio: 'Mix & coupé-décalé', avatar_url: FALLBACK_AVATARS[5], is_verified: true, followers_count: 21000, total_views: 89000 },
];

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, creatorProfile } = useAppContext();
  const [creators, setCreators] = useState<CreatorData[]>([]);
  const [loadingCreators, setLoadingCreators] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [showProfileForm, setShowProfileForm] = useState(false);
  const [showStartLive, setShowStartLive] = useState(false);
  const [showSubscription, setShowSubscription] = useState(false);
  const [replayCount, setReplayCount] = useState(0);

  // Listen for event triggers
  useEffect(() => {
    const handleTriggerAuth = () => setShowAuth(true);
    const handleTriggerProfile = () => setShowProfileForm(true);
    const handleTriggerSubscription = () => setShowSubscription(true);
    const handleTriggerStartLive = () => setShowStartLive(true);

    window.addEventListener('triggerAuthModal', handleTriggerAuth);
    window.addEventListener('openAuthModal', handleTriggerAuth);
    window.addEventListener('triggerProfileForm', handleTriggerProfile);
    window.addEventListener('triggerSubscription', handleTriggerSubscription);
    window.addEventListener('triggerStartLive', handleTriggerStartLive);

    return () => {
      window.removeEventListener('triggerAuthModal', handleTriggerAuth);
      window.removeEventListener('openAuthModal', handleTriggerAuth);
      window.removeEventListener('triggerProfileForm', handleTriggerProfile);
      window.removeEventListener('triggerSubscription', handleTriggerSubscription);
      window.removeEventListener('triggerStartLive', handleTriggerStartLive);
    };
  }, []);

  // Always try to fetch real data, fall back to demo on error
  useEffect(() => {
    const fetchCreators = async () => {
      setLoadingCreators(true);
      try {
        const { data, error } = await supabase
          .from('creator_profiles')
          .select('id, username, display_name, bio, avatar_url, is_verified, followers_count, total_views')
          .order('followers_count', { ascending: false })
          .limit(12);

        if (!error && data && data.length > 0) {
          setCreators(data);
        } else {
          setCreators(DEMO_CREATORS);
        }
      } catch {
        setCreators(DEMO_CREATORS);
      } finally {
        setLoadingCreators(false);
      }
    };

    const fetchReplayCount = async () => {
      try {
        const { count, error } = await supabase
          .from('live_streams')
          .select('id', { count: 'exact', head: true })
          .eq('is_live', false)
          .in('recording_status', ['completed', 'uploading', 'processing']);

        if (!error && count !== null) {
          setReplayCount(count);
        } else {
          setReplayCount(24);
        }
      } catch {
        setReplayCount(24);
      }
    };

    fetchCreators();
    fetchReplayCount();
  }, []);

  const handleStartLive = () => {
    if (!isAuthenticated) {
      setShowAuth(true);
      return;
    }
    if (!creatorProfile) {
      setShowProfileForm(true);
      return;
    }
    setShowStartLive(true);
  };

  const handleSignUp = () => {
    setShowAuth(true);
  };

  const formatCount = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white overflow-y-auto">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-gray-950/80 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <img
                src="https://d64gsuwffb70l.cloudfront.net/697513d586d0577d49bce648_1770472366980_d2796087.png"
                alt="PitchCI"
                className="h-9 w-9 rounded-xl object-contain shadow-lg"
              />
              <span className="text-white font-bold text-xl tracking-tight">PitchCI</span>
            </div>
            {/* Nav */}
            <nav className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-gray-400 hover:text-white text-sm font-medium transition-colors">
                Fonctionnalités
              </a>
              <a href="#how-it-works" className="text-gray-400 hover:text-white text-sm font-medium transition-colors">
                Comment ça marche
              </a>
              <a href="#creators" className="text-gray-400 hover:text-white text-sm font-medium transition-colors">
                Créateurs
              </a>
              <button onClick={() => navigate('/explore')} className="text-gray-400 hover:text-white text-sm font-medium transition-colors flex items-center gap-1.5">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Explorer
              </button>
            </nav>


            {/* Actions */}
            <div className="flex items-center gap-3">
              {isAuthenticated ? (
                <>
                  <button
                    onClick={handleStartLive}
                    className="bg-gradient-to-r from-pink-500 to-red-500 text-white text-sm font-semibold px-5 py-2.5 rounded-full shadow-lg shadow-red-500/25 hover:shadow-red-500/40 transition-all flex items-center gap-2"
                  >
                    <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                    Go Live
                  </button>
                  {creatorProfile && (
                    <button
                      onClick={() => navigate(`/creator/${creatorProfile.username}`)}
                      className="w-9 h-9 rounded-full overflow-hidden border-2 border-white/20 hover:border-purple-500 transition-colors"
                    >
                      {creatorProfile.avatar_url ? (
                        <img src={creatorProfile.avatar_url} alt={creatorProfile.display_name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-gray-700 flex items-center justify-center">
                          <svg className="w-5 h-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                    </button>
                  )}
                </>
              ) : (
                <>
                  <button
                    onClick={() => setShowAuth(true)}
                    className="text-gray-300 hover:text-white text-sm font-medium transition-colors px-4 py-2"
                  >
                    Connexion
                  </button>
                  <button
                    onClick={handleSignUp}
                    className="bg-gradient-to-r from-orange-500 to-pink-500 text-white text-sm font-semibold px-5 py-2.5 rounded-full shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 transition-all"
                  >
                    S'inscrire
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-16 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <img src={HERO_IMAGE} alt="" className="w-full h-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-b from-gray-950/60 via-gray-950/80 to-gray-950" />
          <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 via-transparent to-orange-900/20" />
        </div>

        {/* Animated orbs */}
        <div className="absolute top-32 left-10 w-72 h-72 bg-purple-600/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-48 right-10 w-96 h-96 bg-orange-500/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-20 left-1/3 w-64 h-64 bg-pink-500/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left Content */}
            <div className="text-center lg:text-left">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2 mb-8">
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-sm text-gray-300">Plateforme de live streaming en Côte d'Ivoire</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-extrabold leading-tight mb-6">
                <span className="bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
                  Partagez votre
                </span>
                <br />
                <span className="bg-gradient-to-r from-orange-400 via-pink-500 to-purple-500 bg-clip-text text-transparent">
                  talent en direct
                </span>
              </h1>

              <p className="text-lg sm:text-xl text-gray-400 max-w-xl mx-auto lg:mx-0 mb-10 leading-relaxed">
                PitchCI est la première plateforme ivoirienne de live streaming. 
                Créez du contenu, interagissez avec votre audience en temps réel et monétisez votre passion.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
                <button
                  onClick={handleStartLive}
                  className="w-full sm:w-auto bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-bold px-8 py-4 rounded-full shadow-2xl shadow-purple-500/30 hover:shadow-purple-500/50 transition-all hover:scale-105 flex items-center justify-center gap-3 text-lg"
                >
                  <span className="w-3 h-3 bg-white rounded-full animate-pulse" />
                  Démarrer un Live
                </button>
                <button
                  onClick={() => {
                    const el = document.getElementById('how-it-works');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="w-full sm:w-auto bg-white/5 border border-white/10 text-white font-semibold px-8 py-4 rounded-full hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Découvrir
                </button>
              </div>

              {/* Stats */}
              <div className="flex items-center gap-8 mt-12 justify-center lg:justify-start">
                <div>
                  <div className="text-2xl sm:text-3xl font-bold text-white">{creators.length > 0 ? formatCount(creators.length) : '—'}</div>
                  <div className="text-sm text-gray-500">Créateurs</div>
                </div>
                <div className="w-px h-10 bg-gray-800" />
                <div>
                  <div className="text-2xl sm:text-3xl font-bold text-white">{replayCount > 0 ? formatCount(replayCount) : '—'}</div>
                  <div className="text-sm text-gray-500">Replays</div>
                </div>
                <div className="w-px h-10 bg-gray-800" />
                <div>
                  <div className="text-2xl sm:text-3xl font-bold text-white">24/7</div>
                  <div className="text-sm text-gray-500">Disponible</div>
                </div>
              </div>
            </div>

            {/* Right Visual */}
            <div className="relative hidden lg:block">
              <div className="relative">
                {/* Main card */}
                <div className="relative bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-xl rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
                  <img src={STREAMING_IMAGE} alt="Live Streaming" className="w-full aspect-video object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  
                  {/* Live badge */}
                  <div className="absolute top-4 left-4 flex items-center gap-2">
                    <span className="bg-red-600 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-lg">
                      <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                      LIVE
                    </span>
                    <span className="bg-black/50 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5">
                      <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                      </svg>
                      1.2K
                    </span>
                  </div>

                  {/* Bottom info */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-pink-500 flex items-center justify-center text-white font-bold text-sm">
                        P
                      </div>
                      <div>
                        <p className="text-white font-semibold text-sm">PitchCI Creator</p>
                        <p className="text-gray-300 text-xs">En direct maintenant</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Floating chat messages */}
                <div className="absolute -right-4 top-1/4 bg-gray-800/80 backdrop-blur-xl rounded-2xl border border-white/10 p-3 shadow-xl transform rotate-2 animate-bounce" style={{ animationDuration: '3s' }}>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-green-500" />
                    <span className="text-white text-xs font-medium">Super stream !</span>
                  </div>
                </div>

                <div className="absolute -left-4 bottom-1/4 bg-gray-800/80 backdrop-blur-xl rounded-2xl border border-white/10 p-3 shadow-xl transform -rotate-2 animate-bounce" style={{ animationDuration: '4s', animationDelay: '1s' }}>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-purple-500" />
                    <span className="text-white text-xs font-medium">Bravo !</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Wave divider */}
        <div className="relative -mb-1">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
            <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="#030712"/>
          </svg>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-gray-950 py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-orange-400 font-semibold text-sm uppercase tracking-wider">Fonctionnalités</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-3 mb-5">
              Tout ce qu'il faut pour{' '}
              <span className="bg-gradient-to-r from-orange-400 to-pink-500 bg-clip-text text-transparent">réussir</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Une plateforme complète conçue pour les créateurs de contenu en Côte d'Ivoire et en Afrique francophone.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {[
              {
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                ),
                title: 'Live Streaming HD',
                description: 'Diffusez en direct en haute qualité avec audio et vidéo. Interface intuitive pour démarrer en un clic.',
                color: 'from-red-500 to-pink-500',
              },
              {
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                ),
                title: 'Chat en temps réel',
                description: 'Interagissez avec votre audience grâce au chat en direct. Messages instantanés et réactions.',
                color: 'from-blue-500 to-cyan-500',
              },
              {
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                ),
                title: 'Paiement Mobile Money',
                description: 'Monétisez votre contenu avec Orange Money, MTN Money, Wave et Moov Money.',
                color: 'from-orange-500 to-yellow-500',
              },
              {
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                ),
                title: 'Replays automatiques',
                description: 'Vos lives sont automatiquement enregistrés. Votre audience peut les revoir à tout moment.',
                color: 'from-purple-500 to-indigo-500',
              },
              {
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                ),
                title: 'Communauté engagée',
                description: 'Suivez vos créateurs préférés, recevez des notifications et ne manquez aucun live.',
                color: 'from-green-500 to-emerald-500',
              },
              {
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                ),
                title: 'Tableau de bord',
                description: 'Analysez vos performances avec des statistiques détaillées : vues, followers, revenus.',
                color: 'from-pink-500 to-rose-500',
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="group relative bg-gray-900/50 border border-white/5 rounded-2xl p-6 lg:p-8 hover:border-white/10 hover:bg-gray-900/80 transition-all duration-300"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-white mb-5 group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="bg-gray-950 py-20 sm:py-28 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/5 via-transparent to-orange-900/5" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-purple-400 font-semibold text-sm uppercase tracking-wider">Comment ça marche</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-3 mb-5">
              En{' '}
              <span className="bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">3 étapes</span>
              {' '}simples
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Commencez à diffuser en quelques minutes. Pas besoin d'équipement professionnel.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            {[
              {
                step: '01',
                title: 'Créez votre profil',
                description: 'Inscrivez-vous gratuitement et personnalisez votre profil de créateur. Ajoutez votre photo, bio et lien WhatsApp.',
                icon: (
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                ),
                gradient: 'from-orange-500 to-pink-500',
              },
              {
                step: '02',
                title: 'Lancez votre live',
                description: 'Appuyez sur "Go Live" et commencez à diffuser. Audio, vidéo ou les deux. C\'est aussi simple que ça.',
                icon: (
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                ),
                gradient: 'from-pink-500 to-purple-500',
              },
              {
                step: '03',
                title: 'Gagnez de l\'argent',
                description: 'Recevez des paiements via Mobile Money. Vos fans vous soutiennent directement depuis leur téléphone.',
                icon: (
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                ),
                gradient: 'from-purple-500 to-indigo-500',
              },
            ].map((item, index) => (
              <div key={index} className="relative text-center group">
                {/* Connector line */}
                {index < 2 && (
                  <div className="hidden md:block absolute top-16 left-[60%] w-[80%] h-px bg-gradient-to-r from-white/10 to-white/5" />
                )}

                {/* Step number */}
                <div className="relative inline-flex mb-6">
                  <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center text-white shadow-xl group-hover:scale-110 transition-transform duration-300`}>
                    {item.icon}
                  </div>
                  <span className="absolute -top-2 -right-2 w-8 h-8 bg-gray-800 border-2 border-gray-700 rounded-full flex items-center justify-center text-xs font-bold text-white">
                    {item.step}
                  </span>
                </div>

                <h3 className="text-white font-bold text-xl mb-3">{item.title}</h3>
                <p className="text-gray-400 leading-relaxed max-w-sm mx-auto">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Creators Gallery */}
      <section id="creators" className="bg-gray-950 py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-pink-400 font-semibold text-sm uppercase tracking-wider">Communauté</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-3 mb-5">
              Nos{' '}
              <span className="bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent">créateurs</span>
              {' '}populaires
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Découvrez les talents qui font vivre la plateforme PitchCI.
            </p>
          </div>

          {loadingCreators ? (
            <div className="flex items-center justify-center h-48">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-purple-500" />
            </div>
          ) : creators.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 lg:gap-6">
              {creators.map((creator, index) => (
                <button
                  key={creator.id}
                  onClick={() => {
                    if (creator.username) {
                      navigate(`/creator/${creator.username}`);
                    } else if (!isAuthenticated) {
                      setShowAuth(true);
                    }
                  }}
                  className="group flex flex-col items-center text-center p-4 rounded-2xl bg-gray-900/30 border border-white/5 hover:border-white/10 hover:bg-gray-900/60 transition-all duration-300"
                >
                  <div className="relative mb-3">
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border-2 border-transparent group-hover:border-purple-500 transition-colors">
                      <img
                        src={creator.avatar_url || FALLBACK_AVATARS[index % FALLBACK_AVATARS.length]}
                        alt={creator.display_name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                    {creator.is_verified && (
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center border-2 border-gray-950">
                        <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                    )}
                  </div>
                  <h3 className="text-white font-semibold text-sm truncate w-full">{creator.display_name}</h3>
                  <p className="text-gray-500 text-xs mt-0.5">@{creator.username}</p>
                  {creator.followers_count > 0 && (
                    <p className="text-gray-400 text-xs mt-1.5 flex items-center gap-1">
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                      </svg>
                      {formatCount(creator.followers_count)}
                    </p>
                  )}
                </button>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 lg:gap-6">
                {FALLBACK_AVATARS.map((avatar, index) => (
                  <div
                    key={index}
                    className="flex flex-col items-center text-center p-4 rounded-2xl bg-gray-900/30 border border-white/5"
                  >
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border-2 border-white/10 mb-3">
                      <img src={avatar} alt={`Créateur ${index + 1}`} className="w-full h-full object-cover" />
                    </div>
                    <div className="w-20 h-3 bg-gray-800 rounded-full mb-1" />
                    <div className="w-14 h-2 bg-gray-800/60 rounded-full" />
                  </div>
                ))}
              </div>
              <p className="text-gray-500 mt-8 text-sm">
                Soyez parmi les premiers créateurs sur PitchCI !
              </p>
            </div>
          )}

          {/* Explore all creators button */}
          <div className="text-center mt-10">
            <button
              onClick={() => navigate('/explore')}
              className="inline-flex items-center gap-2 bg-white/5 border border-white/10 text-white font-semibold px-8 py-3 rounded-full hover:bg-white/10 hover:border-white/20 transition-all group"
            >
              <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              Explorer tous les créateurs
              <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </section>


      {/* CTA Section */}
      <section className="bg-gray-950 py-20 sm:py-28 relative overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/40 backdrop-blur-xl border border-white/10 rounded-3xl p-8 sm:p-12 lg:p-16">
            <img
              src="https://d64gsuwffb70l.cloudfront.net/697513d586d0577d49bce648_1770472366980_d2796087.png"
              alt="PitchCI"
              className="w-16 h-16 rounded-2xl object-contain mx-auto mb-8 shadow-xl shadow-red-500/20"
            />

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-5">
              Prêt à{' '}
              <span className="bg-gradient-to-r from-orange-400 via-pink-500 to-purple-500 bg-clip-text text-transparent">
                lancer votre live
              </span>
              {' '}?
            </h2>
            <p className="text-gray-400 text-lg max-w-xl mx-auto mb-10">
              Rejoignez des centaines de créateurs ivoiriens qui partagent leur passion et gagnent de l'argent sur PitchCI.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              {isAuthenticated ? (
                <button
                  onClick={handleStartLive}
                  className="w-full sm:w-auto bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-bold px-10 py-4 rounded-full shadow-2xl shadow-purple-500/30 hover:shadow-purple-500/50 transition-all hover:scale-105 flex items-center justify-center gap-3 text-lg"
                >
                  <span className="w-3 h-3 bg-white rounded-full animate-pulse" />
                  Démarrer un Live
                </button>
              ) : (
                <>
                  <button
                    onClick={handleSignUp}
                    className="w-full sm:w-auto bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-bold px-10 py-4 rounded-full shadow-2xl shadow-purple-500/30 hover:shadow-purple-500/50 transition-all hover:scale-105 flex items-center justify-center gap-3 text-lg"
                  >
                    Créer mon compte gratuit
                  </button>
                  <button
                    onClick={() => setShowAuth(true)}
                    className="w-full sm:w-auto bg-white/5 border border-white/10 text-white font-semibold px-8 py-4 rounded-full hover:bg-white/10 transition-all"
                  >
                    J'ai déjà un compte
                  </button>
                </>
              )}
            </div>

            {/* Trust indicators */}
            <div className="flex items-center justify-center gap-6 mt-10 text-gray-500 text-sm">
              <div className="flex items-center gap-1.5">
                <svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Inscription gratuite
              </div>
              <div className="flex items-center gap-1.5">
                <svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Mobile Money
              </div>
              <div className="flex items-center gap-1.5">
                <svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Sans engagement
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 border-t border-white/5 py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 mb-12">
            {/* Brand */}
            <div className="sm:col-span-2 lg:col-span-1">
              <div className="flex items-center gap-3 mb-4">
                <img
                  src="https://d64gsuwffb70l.cloudfront.net/697513d586d0577d49bce648_1770472366980_d2796087.png"
                  alt="PitchCI"
                  className="h-9 w-9 rounded-xl object-contain"
                />
                <span className="text-white font-bold text-lg">PitchCI</span>
              </div>
              <p className="text-gray-500 text-sm leading-relaxed mb-4">
                La première plateforme de live streaming en Côte d'Ivoire. Créez, partagez et monétisez votre contenu.
              </p>
              <div className="flex items-center gap-3">
                <a href="https://wa.me/2250000000000" target="_blank" rel="noopener noreferrer" className="w-9 h-9 bg-gray-800 hover:bg-green-600 rounded-lg flex items-center justify-center transition-colors">
                  <svg className="w-4 h-4 text-gray-400 hover:text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </a>
              </div>
            </div>

            {/* Links */}
            <div>
              <h4 className="text-white font-semibold text-sm mb-4">Plateforme</h4>
              <ul className="space-y-3">
                <li><button onClick={() => navigate('/explore')} className="text-gray-500 hover:text-white text-sm transition-colors">Explorer les créateurs</button></li>
                <li><button onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })} className="text-gray-500 hover:text-white text-sm transition-colors">Fonctionnalités</button></li>
                <li><button onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })} className="text-gray-500 hover:text-white text-sm transition-colors">Comment ça marche</button></li>
                <li><button onClick={() => navigate('/payment')} className="text-gray-500 hover:text-white text-sm transition-colors">Paiements</button></li>
                <li><button onClick={() => document.getElementById('creators')?.scrollIntoView({ behavior: 'smooth' })} className="text-gray-500 hover:text-white text-sm transition-colors">Créateurs</button></li>
              </ul>
            </div>



            <div>
              <h4 className="text-white font-semibold text-sm mb-4">Créateurs</h4>
              <ul className="space-y-3">
                <li><button onClick={handleStartLive} className="text-gray-500 hover:text-white text-sm transition-colors">Démarrer un live</button></li>
                <li><button onClick={handleSignUp} className="text-gray-500 hover:text-white text-sm transition-colors">Créer un compte</button></li>
                <li><button onClick={() => isAuthenticated ? navigate('/dashboard') : setShowAuth(true)} className="text-gray-500 hover:text-white text-sm transition-colors">Tableau de bord</button></li>
                <li><button onClick={() => isAuthenticated ? navigate('/settings') : setShowAuth(true)} className="text-gray-500 hover:text-white text-sm transition-colors">Paramètres</button></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold text-sm mb-4">Support</h4>
              <ul className="space-y-3">
                <li><a href="mailto:support@pitchci.com" className="text-gray-500 hover:text-white text-sm transition-colors">Contact</a></li>
                <li><a href="https://wa.me/2250000000000" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-white text-sm transition-colors">WhatsApp</a></li>
                <li><button onClick={() => {}} className="text-gray-500 hover:text-white text-sm transition-colors">Conditions d'utilisation</button></li>
                <li><button onClick={() => {}} className="text-gray-500 hover:text-white text-sm transition-colors">Politique de confidentialité</button></li>
              </ul>
            </div>
          </div>

          {/* Bottom */}
          <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-gray-600 text-sm">
              &copy; {new Date().getFullYear()} PitchCI. Tous droits réservés. Fait avec passion en Côte d'Ivoire.
            </p>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full animate-pulse bg-green-500" />
              <span className="text-gray-500 text-sm">
                Tous les systèmes opérationnels
              </span>
            </div>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />
      <CreatorProfileForm
        isOpen={showProfileForm || (isAuthenticated && !creatorProfile && showAuth === false)}
        onClose={() => setShowProfileForm(false)}
      />
      <StartLiveModal
        isOpen={showStartLive}
        onClose={() => setShowStartLive(false)}
        onStarted={() => {}}
      />
      <SubscriptionModal
        isOpen={showSubscription}
        onClose={() => setShowSubscription(false)}
      />
    </div>
  );
};

export default HomePage;
