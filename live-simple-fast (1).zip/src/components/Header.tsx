import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import SubscriptionModal from './SubscriptionModal';

interface HeaderProps {
  onAuthClick: () => void;
  onStartLive: () => void;
}

const Header: React.FC<HeaderProps> = ({ onAuthClick, onStartLive }) => {
  const navigate = useNavigate();
  const { isAuthenticated, creatorProfile, utilisateur, hasActiveSubscription, signOut, isAdmin } = useAppContext();

  const [showMenu, setShowMenu] = useState(false);
  const [showSubscription, setShowSubscription] = useState(false);


  const handleProfileClick = () => {
    if (creatorProfile) {
      navigate(`/creator/${creatorProfile.username}`);
    }
    setShowMenu(false);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-40 bg-gradient-to-b from-black/90 to-transparent">
        <div className="flex items-center justify-between px-4 py-3">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <img
              src="https://d64gsuwffb70l.cloudfront.net/697513d586d0577d49bce648_1770472366980_d2796087.png"
              alt="PitchCI"
              className="h-9 w-9 rounded-lg object-contain"
            />
            <span className="text-white font-bold text-lg">PitchCI</span>
          </div>



          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {isAuthenticated ? (
              <>
                {/* Admin Badge */}
                {isAdmin && (
                  <button
                    onClick={() => navigate('/admin')}
                    className="px-3 py-1.5 rounded-full text-xs font-medium bg-purple-500/20 text-purple-400 border border-purple-500/30 hover:bg-purple-500/30 transition-colors"
                  >
                    Admin
                  </button>
                )}

                {/* Subscription Status Badge */}
                {creatorProfile && (
                  <button
                    onClick={() => setShowSubscription(true)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                      hasActiveSubscription
                        ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                        : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                    }`}
                  >
                    {hasActiveSubscription ? 'Pro' : 'S\'abonner'}
                  </button>
                )}

                {/* Go Live Button */}
                <button
                  onClick={onStartLive}
                  className="bg-gradient-to-r from-pink-500 to-red-500 text-white text-sm font-semibold px-4 py-2 rounded-full shadow-lg flex items-center gap-1.5"
                >
                  <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                  Go Live
                </button>

                {/* Profile Menu */}
                <div className="relative">
                  <button
                    onClick={() => setShowMenu(!showMenu)}
                    className="w-9 h-9 rounded-full overflow-hidden border-2 border-white/20"
                  >
                    {creatorProfile?.avatar_url ? (
                      <img
                        src={creatorProfile.avatar_url}
                        alt={creatorProfile.display_name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-700 flex items-center justify-center">
                        <svg className="w-5 h-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                        </svg>
                      </div>
                    )}
                  </button>

                  {showMenu && (
                    <>
                      <div
                        className="fixed inset-0 z-40"
                        onClick={() => setShowMenu(false)}
                      />
                      <div className="absolute right-0 top-full mt-2 w-56 bg-gray-900 border border-gray-800 rounded-xl shadow-xl z-50 overflow-hidden">
                        {(utilisateur || creatorProfile) && (
                          <div className="p-4 border-b border-gray-800">
                            <p className="text-white font-semibold">{utilisateur?.display_name || creatorProfile?.display_name || 'Utilisateur'}</p>
                            <p className="text-gray-400 text-sm">{creatorProfile ? `@${creatorProfile.username}` : (utilisateur?.email || '')}</p>
                          </div>
                        )}

                        
                        <div className="py-2">
                          {creatorProfile && (
                            <>
                              <button
                                onClick={handleProfileClick}
                                className="w-full px-4 py-2.5 text-left text-gray-300 hover:bg-gray-800 flex items-center gap-3"
                              >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                </svg>
                                Mon profil
                              </button>

                              <button
                                onClick={() => {
                                  navigate('/profile/edit');
                                  setShowMenu(false);
                                }}
                                className="w-full px-4 py-2.5 text-left text-gray-300 hover:bg-gray-800 flex items-center gap-3"
                              >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                </svg>
                                Modifier le profil
                              </button>

                              <button
                                onClick={() => {
                                  navigate('/dashboard');
                                  setShowMenu(false);
                                }}
                                className="w-full px-4 py-2.5 text-left text-gray-300 hover:bg-gray-800 flex items-center gap-3"
                              >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                                </svg>
                                Tableau de bord
                              </button>
                            </>
                          )}


                          
                          <button
                            onClick={() => {
                              navigate('/payment');
                              setShowMenu(false);
                            }}
                            className="w-full px-4 py-2.5 text-left text-gray-300 hover:bg-gray-800 flex items-center gap-3"
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                            </svg>
                            Paiement Mobile Money
                          </button>

                          <button
                            onClick={() => {
                              setShowSubscription(true);
                              setShowMenu(false);
                            }}
                            className="w-full px-4 py-2.5 text-left text-gray-300 hover:bg-gray-800 flex items-center gap-3"
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                            </svg>
                            Mon abonnement
                          </button>

                          {/* Settings Link */}
                          <button
                            onClick={() => {
                              navigate('/settings');
                              setShowMenu(false);
                            }}
                            className="w-full px-4 py-2.5 text-left text-gray-300 hover:bg-gray-800 flex items-center gap-3"
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                            Paramètres
                          </button>

                          {isAdmin && (
                            <>
                              <button
                                onClick={() => {
                                  navigate('/admin');
                                  setShowMenu(false);
                                }}
                                className="w-full px-4 py-2.5 text-left text-purple-400 hover:bg-gray-800 flex items-center gap-3"
                              >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                                </svg>
                                Administration
                              </button>
                              <button
                                onClick={() => {
                                  navigate('/connect-sync');
                                  setShowMenu(false);
                                }}
                                className="w-full px-4 py-2.5 text-left text-cyan-400 hover:bg-gray-800 flex items-center gap-3"
                              >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                                </svg>
                                Connecter & Sync
                              </button>
                            </>
                          )}


                          <div className="my-1 border-t border-gray-800" />
                          
                          <button
                            onClick={() => {
                              signOut();
                              setShowMenu(false);
                            }}
                            className="w-full px-4 py-2.5 text-left text-red-400 hover:bg-gray-800 flex items-center gap-3"
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                            </svg>
                            Déconnexion
                          </button>
                        </div>

                      </div>
                    </>
                  )}
                </div>
              </>
            ) : (
              <button
                onClick={onAuthClick}
                className="bg-white/20 backdrop-blur-sm text-white text-sm font-medium px-4 py-2 rounded-full hover:bg-white/30 transition-colors"
              >
                Connexion
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Subscription Modal */}
      <SubscriptionModal
        isOpen={showSubscription}
        onClose={() => setShowSubscription(false)}
      />
    </>
  );
};

export default Header;
