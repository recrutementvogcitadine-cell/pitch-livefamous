import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { subscriptionService, SubscriptionPlan, CreatorSubscription } from '@/lib/subscriptionService';
import { paymentService } from '@/lib/paymentService';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscribed?: () => void;
}

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, onSubscribed }) => {
  const navigate = useNavigate();
  const { creatorProfile } = useAppContext();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [currentSubscription, setCurrentSubscription] = useState<CreatorSubscription | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && creatorProfile) {
      loadData();
    }
  }, [isOpen, creatorProfile]);

  const loadData = async () => {
    if (!creatorProfile) return;
    
    setIsLoading(true);
    try {
      const [plansData, subscription] = await Promise.all([
        subscriptionService.getPlans(),
        subscriptionService.getCreatorSubscription(creatorProfile.id)
      ]);
      
      setPlans(plansData);
      setCurrentSubscription(subscription);
      
      if (plansData.length > 0 && !selectedPlan) {
        setSelectedPlan(plansData[0]);
      }
    } catch (err) {
      console.error('Error loading subscription data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoToPayment = () => {
    if (!selectedPlan) return;
    onClose();
    navigate(`/payment?plan=${selectedPlan.id}&cycle=${billingCycle}`);
  };

  const getPrice = (plan?: SubscriptionPlan | null) => {
    const p = plan || selectedPlan;
    if (!p) return 0;
    return billingCycle === 'monthly' ? p.price_monthly : p.price_yearly;
  };

  const getSavings = () => {
    if (!selectedPlan) return 0;
    const monthlyTotal = selectedPlan.price_monthly * 12;
    const yearlyTotal = selectedPlan.price_yearly;
    return Math.round(((monthlyTotal - yearlyTotal) / monthlyTotal) * 100);
  };

  if (!isOpen) return null;

  // Show current subscription status
  if (currentSubscription?.status === 'active') {
    const daysRemaining = subscriptionService.getDaysRemaining(currentSubscription.expires_at);
    
    return (
      <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
        <div className="bg-gray-900 rounded-2xl w-full max-w-md overflow-hidden">
          <div className="p-6 border-b border-gray-800">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-white">Mon abonnement</h2>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
              >
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-6 mb-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <p className="text-green-400 font-semibold">Abonnement actif</p>
                  <p className="text-white font-bold text-lg">{currentSubscription.plan?.name || 'Créateur Pro'}</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Cycle de facturation</span>
                  <span className="text-white capitalize">{currentSubscription.billing_cycle === 'monthly' ? 'Mensuel' : 'Annuel'}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Expire le</span>
                  <span className="text-white">
                    {currentSubscription.expires_at 
                      ? new Date(currentSubscription.expires_at).toLocaleDateString('fr-FR')
                      : '-'
                    }
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Jours restants</span>
                  <span className={`font-semibold ${daysRemaining <= 7 ? 'text-yellow-400' : 'text-green-400'}`}>
                    {daysRemaining} jours
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-4 mb-6">
              <p className="text-gray-400 text-sm mb-3">Fonctionnalités incluses:</p>
              <ul className="space-y-2">
                {(currentSubscription.plan?.features || ['Lives illimités', 'Bouton WhatsApp direct', 'Statistiques de base', 'Support prioritaire']).map((feature, index) => (
                  <li key={index} className="flex items-center gap-2 text-white text-sm">
                    <svg className="w-4 h-4 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            <button
              onClick={onClose}
              className="w-full bg-gray-800 hover:bg-gray-700 text-white font-medium py-3 rounded-xl transition-colors"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Plan selection
  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-800">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Abonnement Créateur</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <p className="text-gray-400 text-sm mt-2">
            Un abonnement actif est requis pour démarrer des lives
          </p>
        </div>

        {isLoading ? (
          <div className="p-8 flex justify-center">
            <div className="w-8 h-8 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
          </div>
        ) : (
          <div className="p-6">
            {/* Billing Cycle Toggle */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  billingCycle === 'monthly'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-800 text-gray-400 hover:text-white'
                }`}
              >
                Mensuel
              </button>
              <button
                onClick={() => setBillingCycle('yearly')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors relative ${
                  billingCycle === 'yearly'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-800 text-gray-400 hover:text-white'
                }`}
              >
                Annuel
                {getSavings() > 0 && (
                  <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                    -{getSavings()}%
                  </span>
                )}
              </button>
            </div>

            {/* Plans */}
            {plans.map((plan) => (
              <div
                key={plan.id}
                onClick={() => setSelectedPlan(plan)}
                className={`relative rounded-2xl p-6 mb-4 cursor-pointer transition-all ${
                  selectedPlan?.id === plan.id
                    ? 'bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-2 border-purple-500'
                    : 'bg-gray-800/50 border-2 border-gray-700 hover:border-gray-600'
                }`}
              >
                {selectedPlan?.id === plan.id && (
                  <div className="absolute top-4 right-4 w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                )}

                <h3 className="text-white font-bold text-lg mb-2">{plan.name}</h3>
                <p className="text-gray-400 text-sm mb-4">{plan.description}</p>

                <div className="mb-4">
                  <span className="text-white font-bold text-3xl">
                    {paymentService.formatAmount(getPrice(plan))}
                  </span>
                  <span className="text-gray-400 text-sm">
                    /{billingCycle === 'monthly' ? 'mois' : 'an'}
                  </span>
                  {billingCycle === 'yearly' && (
                    <p className="text-green-400 text-sm mt-1">
                      Soit {paymentService.formatAmount(Math.round(plan.price_yearly / 12))}/mois
                    </p>
                  )}
                </div>

                <ul className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-gray-300 text-sm">
                      <svg className="w-4 h-4 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}

            {/* Pending subscription notice */}
            {currentSubscription?.status === 'pending' && (
              <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-xl p-4 mb-4">
                <div className="flex items-center gap-2 text-yellow-400">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <span className="font-medium">Paiement en attente</span>
                </div>
                <p className="text-yellow-300/80 text-sm mt-1">
                  Finalisez votre paiement pour activer votre abonnement
                </p>
              </div>
            )}

            {/* Expired subscription notice */}
            {currentSubscription?.status === 'expired' && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-xl p-4 mb-4">
                <div className="flex items-center gap-2 text-red-400">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="font-medium">Abonnement expiré</span>
                </div>
                <p className="text-red-300/80 text-sm mt-1">
                  Renouvelez votre abonnement pour continuer à faire des lives
                </p>
              </div>
            )}

            {error && (
              <div className="mb-4 p-3 bg-red-500/20 border border-red-500/30 rounded-xl">
                <p className="text-red-400 text-sm">{error}</p>
              </div>
            )}

            {/* Mobile Money Payment Methods Preview */}
            <div className="mb-4 p-4 bg-gray-800/30 rounded-xl border border-gray-700/50">
              <p className="text-gray-400 text-xs uppercase tracking-wider mb-3">Moyens de paiement acceptés</p>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <circle cx="12" cy="12" r="8" fill="white" fillOpacity="0.3" />
                      <path d="M12 9v6M9 12h6" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
                    </svg>
                  </div>
                  <span className="text-gray-400 text-xs">Orange</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <path d="M12 5L6 9v10h12V9l-6-4z" fill="white" fillOpacity="0.4" stroke="white" strokeWidth="1.5" />
                    </svg>
                  </div>
                  <span className="text-gray-400 text-xs">MTN</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <path d="M4 12c2-3 4-4 6-4s4 3 6 3 4-3 6-3" stroke="white" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                  </div>
                  <span className="text-gray-400 text-xs">Wave</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleGoToPayment}
              disabled={!selectedPlan}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 text-white font-semibold py-4 rounded-xl transition-all flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
              Payer avec Mobile Money - {paymentService.formatAmount(getPrice())}
            </button>

            <p className="text-gray-500 text-xs text-center mt-4">
              Paiement sécurisé via Orange Money, MTN Money ou Wave
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubscriptionModal;
