import React, { useState, useRef } from 'react';
import { Upload, X, FileText, Camera, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { submitVerificationRequest, VerificationSubmission } from '@/lib/verificationService';

interface VerificationRequestFormProps {
  creatorId: string;
  userId: string;
  onSuccess: () => void;
  onCancel: () => void;
}

const COUNTRIES = [
  'France', 'Belgium', 'Switzerland', 'Canada', 'United States', 'United Kingdom',
  'Germany', 'Spain', 'Italy', 'Netherlands', 'Portugal', 'Morocco', 'Algeria',
  'Tunisia', 'Senegal', 'Ivory Coast', 'Cameroon', 'Other'
];

export function VerificationRequestForm({ 
  creatorId, 
  userId, 
  onSuccess, 
  onCancel 
}: VerificationRequestFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    full_legal_name: '',
    date_of_birth: '',
    country: '',
    document_type: '' as 'passport' | 'national_id' | 'drivers_license' | '',
    additional_notes: ''
  });

  const [documentFront, setDocumentFront] = useState<File | null>(null);
  const [documentBack, setDocumentBack] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);

  const documentFrontRef = useRef<HTMLInputElement>(null);
  const documentBackRef = useRef<HTMLInputElement>(null);
  const selfieRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: React.Dispatch<React.SetStateAction<File | null>>
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        setError('Please upload an image file (JPG, PNG, etc.)');
        return;
      }
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        setError('File size must be less than 10MB');
        return;
      }
      setter(file);
      setError(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validate required fields
    if (!formData.full_legal_name || !formData.date_of_birth || !formData.country || !formData.document_type) {
      setError('Please fill in all required fields');
      return;
    }

    if (!documentFront) {
      setError('Please upload the front of your identity document');
      return;
    }

    if (!selfie) {
      setError('Please upload a selfie holding your identity document');
      return;
    }

    // Validate age (must be 18+)
    const birthDate = new Date(formData.date_of_birth);
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();
    if (age < 18) {
      setError('You must be at least 18 years old to become a verified creator');
      return;
    }

    setIsSubmitting(true);

    const submission: VerificationSubmission = {
      full_legal_name: formData.full_legal_name,
      date_of_birth: formData.date_of_birth,
      country: formData.country,
      document_type: formData.document_type as 'passport' | 'national_id' | 'drivers_license',
      document_front: documentFront,
      document_back: documentBack || undefined,
      selfie: selfie,
      additional_notes: formData.additional_notes || undefined
    };

    const result = await submitVerificationRequest(creatorId, userId, submission);

    setIsSubmitting(false);

    if (result.success) {
      onSuccess();
    } else {
      setError(result.error || 'Failed to submit verification request');
    }
  };

  const FileUploadBox = ({ 
    label, 
    description, 
    file, 
    inputRef, 
    onChange, 
    onClear,
    required = true,
    icon: Icon = FileText
  }: {
    label: string;
    description: string;
    file: File | null;
    inputRef: React.RefObject<HTMLInputElement>;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onClear: () => void;
    required?: boolean;
    icon?: React.ElementType;
  }) => (
    <div className="space-y-2">
      <Label className="flex items-center gap-1">
        {label}
        {required && <span className="text-red-500">*</span>}
      </Label>
      <div 
        className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${
          file ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-purple-400 hover:bg-purple-50'
        }`}
        onClick={() => inputRef.current?.click()}
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          onChange={onChange}
          className="hidden"
        />
        {file ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-sm text-green-700 truncate max-w-[200px]">{file.name}</span>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onClear();
              }}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            <Icon className="w-8 h-8 mx-auto text-gray-400" />
            <p className="text-sm text-gray-600">{description}</p>
            <p className="text-xs text-gray-400">Click to upload (max 10MB)</p>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-blue-500" />
          Request Verification
        </CardTitle>
        <CardDescription>
          Verify your identity to get a verified badge on your profile. This helps build trust with your audience.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Personal Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
              Personal Information
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="full_legal_name">
                  Full Legal Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="full_legal_name"
                  value={formData.full_legal_name}
                  onChange={(e) => setFormData({ ...formData, full_legal_name: e.target.value })}
                  placeholder="As shown on your ID"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="date_of_birth">
                  Date of Birth <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="date_of_birth"
                  type="date"
                  value={formData.date_of_birth}
                  onChange={(e) => setFormData({ ...formData, date_of_birth: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="country">
                  Country <span className="text-red-500">*</span>
                </Label>
                <Select
                  value={formData.country}
                  onValueChange={(value) => setFormData({ ...formData, country: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your country" />
                  </SelectTrigger>
                  <SelectContent>
                    {COUNTRIES.map((country) => (
                      <SelectItem key={country} value={country}>
                        {country}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="document_type">
                  Document Type <span className="text-red-500">*</span>
                </Label>
                <Select
                  value={formData.document_type}
                  onValueChange={(value) => setFormData({ ...formData, document_type: value as any })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select document type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="passport">Passport</SelectItem>
                    <SelectItem value="national_id">National ID Card</SelectItem>
                    <SelectItem value="drivers_license">Driver's License</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Document Upload */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
              Identity Documents
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FileUploadBox
                label="Front of Document"
                description="Upload the front of your ID"
                file={documentFront}
                inputRef={documentFrontRef as React.RefObject<HTMLInputElement>}
                onChange={(e) => handleFileChange(e, setDocumentFront)}
                onClear={() => setDocumentFront(null)}
                icon={FileText}
              />

              <FileUploadBox
                label="Back of Document"
                description="Upload the back of your ID (if applicable)"
                file={documentBack}
                inputRef={documentBackRef as React.RefObject<HTMLInputElement>}
                onChange={(e) => handleFileChange(e, setDocumentBack)}
                onClear={() => setDocumentBack(null)}
                required={false}
                icon={FileText}
              />
            </div>

            <FileUploadBox
              label="Selfie with Document"
              description="Take a selfie holding your ID next to your face"
              file={selfie}
              inputRef={selfieRef as React.RefObject<HTMLInputElement>}
              onChange={(e) => handleFileChange(e, setSelfie)}
              onClear={() => setSelfie(null)}
              icon={Camera}
            />
          </div>

          {/* Additional Notes */}
          <div className="space-y-2">
            <Label htmlFor="additional_notes">Additional Notes (Optional)</Label>
            <Textarea
              id="additional_notes"
              value={formData.additional_notes}
              onChange={(e) => setFormData({ ...formData, additional_notes: e.target.value })}
              placeholder="Any additional information you'd like to provide..."
              rows={3}
            />
          </div>

          {/* Privacy Notice */}
          <div className="bg-gray-50 rounded-lg p-4 text-sm text-gray-600">
            <p className="font-medium text-gray-700 mb-2">Privacy Notice</p>
            <p>
              Your identity documents will be securely stored and only used for verification purposes. 
              They will be reviewed by our admin team and deleted after verification is complete.
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-3 justify-end">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Submit Request
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
