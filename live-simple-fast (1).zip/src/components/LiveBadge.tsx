import React from 'react';

interface LiveBadgeProps {
  isLive: boolean;
  viewerCount?: number;
}

const LiveBadge: React.FC<LiveBadgeProps> = ({ isLive, viewerCount }) => {
  if (!isLive) return null;

  return (
    <div className="flex items-center gap-2">
      <span className="bg-red-600 text-white text-xs font-bold px-2 py-1 rounded flex items-center gap-1">
        <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
        LIVE
      </span>
      {viewerCount !== undefined && (
        <span className="bg-black/60 text-white text-xs px-2 py-1 rounded">
          {viewerCount} spectateurs
        </span>
      )}
    </div>
  );
};

export default LiveBadge;
