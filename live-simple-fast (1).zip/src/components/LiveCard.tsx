import React from 'react';
import { useNavigate } from 'react-router-dom';
import FollowButton from './FollowButton';
import { VerificationBadge } from './VerificationBadge';

interface LiveCardProps {
  stream: {
    id: string;
    title: string;
    creatorId: string;
    creatorName: string;
    creatorUsername?: string;
    creatorAvatar: string;
    viewerCount: number;
    thumbnailUrl: string;
    followerCount?: number;
    whatsappNumber?: string;
    isVerified?: boolean;
  };
  onClick: () => void;
  showFollowButton?: boolean;
  onFollowChange?: (isFollowing: boolean) => void;
}

const LiveCard: React.FC<LiveCardProps> = ({ stream, onClick, showFollowButton = true, onFollowChange }) => {
  const navigate = useNavigate();
  
  const formatCount = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const goToProfile = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Only navigate if we have a real creatorUsername from the database
    if (stream.creatorUsername) {
      navigate(`/creator/${stream.creatorUsername}`);
    }
  };


  const openWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!stream.whatsappNumber) return;
    const message = encodeURIComponent(`Salut ${stream.creatorName}! Je regarde ton live sur PitchCI`);

    window.open(`https://wa.me/${stream.whatsappNumber.replace(/[^0-9+]/g, '')}?text=${message}`, '_blank');
  };

  return (
    <div className="w-full bg-gray-900 rounded-xl overflow-hidden hover:ring-2 hover:ring-purple-500 transition-all group">
      <button onClick={onClick} className="w-full relative aspect-video">
        <img src={stream.thumbnailUrl} alt={stream.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        <div className="absolute top-2 left-2">
          <span className="bg-red-600 text-white text-xs font-bold px-2 py-1 rounded flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>LIVE
          </span>
        </div>
        <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">{formatCount(stream.viewerCount)}</div>
      </button>
      <div className="p-3">
        <div className="flex items-start gap-3">
          <button onClick={goToProfile} className="flex-shrink-0 relative">
            <img src={stream.creatorAvatar} alt={stream.creatorName} className="w-10 h-10 rounded-full object-cover hover:ring-2 hover:ring-purple-500" />
            {stream.isVerified && (
              <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center border border-gray-900">
                <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
            )}
          </button>
          <div className="flex-1 min-w-0">
            <button onClick={goToProfile} className="block text-left">
              <div className="flex items-center gap-1">
                <h3 className="text-white font-medium text-sm truncate hover:text-purple-400">{stream.creatorName}</h3>
                <VerificationBadge isVerified={stream.isVerified || false} size="sm" />
              </div>
            </button>
            <p className="text-gray-400 text-xs truncate">{stream.title}</p>
          </div>
          <div className="flex-shrink-0 flex items-center gap-2">
            {stream.whatsappNumber && (
              <button onClick={openWhatsApp} className="w-8 h-8 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center">
                <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              </button>
            )}
            {showFollowButton && stream.creatorId && (
              <FollowButton creatorId={stream.creatorId} creatorName={stream.creatorName} followerCount={stream.followerCount} size="sm" onFollowChange={onFollowChange} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveCard;
