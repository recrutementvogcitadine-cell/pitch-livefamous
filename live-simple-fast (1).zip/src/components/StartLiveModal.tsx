import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { startLiveStream, endLiveStream, agoraClient } from '@/lib/agoraClient';
import { recordingService } from '@/lib/recordingService';
import { useMediaRecorder } from '@/hooks/useMediaRecorder';
import { useStreamPresence } from '@/hooks/useStreamPresence';
import AudioVisualizer from './AudioVisualizer';
import SubscriptionModal from './SubscriptionModal';



interface StartLiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStarted: () => void;
}

const StartLiveModal: React.FC<StartLiveModalProps> = ({ isOpen, onClose, onStarted }) => {
  const { creatorProfile, hasActiveSubscription, refreshSubscription, user } = useAppContext();

  const [title, setTitle] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [isPreviewActive, setIsPreviewActive] = useState(false);
  const [currentStreamId, setCurrentStreamId] = useState<string | null>(null);
  const [isLive, setIsLive] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [agoraError, setAgoraError] = useState<string | null>(null);

  const [audioOnly, setAudioOnly] = useState(false);
  const [cameraUnavailable, setCameraUnavailable] = useState(false);
  const [audioFallbackSuggested, setAudioFallbackSuggested] = useState(false);

  // Mute toggles (Agora tracks)
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [isVideoMuted, setIsVideoMuted] = useState(false);

  const [uploadProgress, setUploadProgress] = useState<{
    status: 'idle' | 'uploading' | 'processing' | 'completed' | 'failed';
    message: string;
  }>({ status: 'idle', message: '' });
  const [showUploadStatus, setShowUploadStatus] = useState(false);
  
  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const agoraVideoContainerRef = useRef<HTMLDivElement>(null);
  const isRequestingMediaRef = useRef(false);

  const {
    isRecording,
    duration: recordingDuration,
    error: recordingError,
    startRecording,
    stopRecording,
    getRecordingBlob,
  } = useMediaRecorder({
    timeslice: 2000,
    videoBitsPerSecond: 2500000,
    audioBitsPerSecond: 128000,
    onError: () => {},
  });

  // Real-time Presence tracking for the creator's own stream
  const {
    viewerCount: presenceViewerCount,
    isConnected: presenceConnected,
    viewers: presenceViewers,
  } = useStreamPresence({
    streamId: currentStreamId || 'none',
    userId: user?.id || null,
    displayName: creatorProfile?.display_name || 'Créateur',
    avatarUrl: creatorProfile?.avatar_url || null,
    isCreator: true,
    enabled: isOpen && isLive && !!currentStreamId,
  });

  // Set up Agora error callback
  useEffect(() => {
    agoraClient.setCallbacks({
      onError: (error) => setAgoraError(error),
    });
    return () => {
      agoraClient.setCallbacks({});
    };
  }, []);

  // Play local Agora video in the container when live
  useEffect(() => {
    if (isLive && agoraVideoContainerRef.current && !audioOnly) {
      const state = agoraClient.getState();
      if (state.localVideoTrack) {
        state.localVideoTrack.play(agoraVideoContainerRef.current);
      }
    }
  }, [isLive, audioOnly]);

  useEffect(() => {
    return () => {
      if (!isLive) {
        stopPreview();
      }
    };
  }, [isLive]);

  useEffect(() => {
    if (videoPreviewRef.current && mediaStream && !audioOnly) {
      videoPreviewRef.current.srcObject = mediaStream;
    }
  }, [mediaStream, audioOnly]);

  const formatRecordingDuration = (seconds: number): string => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const checkMediaDevicesAvailable = useCallback((): { available: boolean; error?: string } => {
    if (typeof window !== 'undefined' && window.isSecureContext === false) {
      return {
        available: false,
        error: 'L\'accès à la caméra nécessite une connexion sécurisée (HTTPS). Veuillez utiliser HTTPS.',
      };
    }

    if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
      return {
        available: false,
        error: 'Votre navigateur ne supporte pas l\'accès à la caméra/micro dans ce contexte. Essayez d\'ouvrir cette page directement dans un nouvel onglet.',
      };
    }

    return { available: true };
  }, []);

  const handleCameraError = useCallback((error: any) => {
    let errorMessage = '';
    let suggestAudioFallback = false;

    if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
      errorMessage = 'Accès à la caméra refusé. Vous pouvez passer en mode audio uniquement pour continuer.';
      suggestAudioFallback = true;
    } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
      errorMessage = 'Aucune caméra détectée sur cet appareil. Vous pouvez utiliser le mode audio uniquement.';
      suggestAudioFallback = true;
    } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
      errorMessage = 'La caméra est déjà utilisée par une autre application. Vous pouvez passer en mode audio uniquement.';
      suggestAudioFallback = true;
    } else if (error.name === 'SecurityError') {
      errorMessage = 'Accès à la caméra bloqué par les paramètres de sécurité (iframe/aperçu). Utilisez le mode audio uniquement ou ouvrez la page dans un nouvel onglet.';
      suggestAudioFallback = true;
    } else if (error.name === 'AbortError') {
      errorMessage = 'La demande d\'accès a été interrompue. Veuillez réessayer.';
    } else {
      errorMessage = `Erreur d'accès à la caméra: ${error.message || error.name || 'Erreur inconnue'}`;
      suggestAudioFallback = true;
    }

    setMediaError(errorMessage);
    if (suggestAudioFallback) {
      setCameraUnavailable(true);
      setAudioFallbackSuggested(true);
    }
  }, []);

  const switchToAudioOnly = useCallback(() => {
    stopPreview();
    setAudioOnly(true);
    setMediaError(null);
    setAudioFallbackSuggested(false);
  }, []);

  const startPreview = async () => {
    if (isRequestingMediaRef.current || isLoading) return;

    setMediaError(null);
    setIsLoading(true);
    isRequestingMediaRef.current = true;

    const mediaCheck = checkMediaDevicesAvailable();
    if (!mediaCheck.available) {
      setMediaError(mediaCheck.error || 'Accès média non disponible');
      setCameraUnavailable(true);
      setAudioFallbackSuggested(true);
      setIsLoading(false);
      isRequestingMediaRef.current = false;
      return;
    }

    try {
      const constraints: MediaStreamConstraints = audioOnly
        ? { audio: true, video: false }
        : { video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } }, audio: true };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      setMediaStream(stream);
      setIsPreviewActive(true);
      
      stream.getTracks().forEach(track => {
        track.onended = () => {
          if (!isLive) {
            stopPreview();
          }
        };
      });
    } catch (error: any) {
      if (audioOnly) {
        setMediaError(
          'Impossible d\'accéder au microphone. Vérifiez les permissions de votre navigateur ou ouvrez la page dans un nouvel onglet.'
        );
      } else {
        handleCameraError(error);
        
        if (error.name === 'OverconstrainedError') {
          try {
            const fallbackStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            setMediaStream(fallbackStream);
            setIsPreviewActive(true);
            setIsLoading(false);
            isRequestingMediaRef.current = false;
            return;
          } catch {
            setCameraUnavailable(true);
            setAudioFallbackSuggested(true);
          }
        }
      }
    } finally {
      setIsLoading(false);
      isRequestingMediaRef.current = false;
    }
  };

  const stopPreview = () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
    }
    setMediaStream(null);
    setIsPreviewActive(false);
    if (videoPreviewRef.current) {
      videoPreviewRef.current.srcObject = null;
    }
  };

  const handleToggleAudioOnly = () => {
    if (isPreviewActive) {
      stopPreview();
    }
    setMediaError(null);
    setAudioFallbackSuggested(false);
    setAudioOnly(prev => !prev);
  };

  // ── Mute/unmute via Agora tracks ──
  const handleToggleAudioMute = async () => {
    try {
      await agoraClient.setAudioMuted(!isAudioMuted);
      setIsAudioMuted(!isAudioMuted);
    } catch (err: any) {
      console.warn('[StartLive] Audio mute toggle failed:', err.message);
    }
  };

  const handleToggleVideoMute = async () => {
    try {
      await agoraClient.setVideoMuted(!isVideoMuted);
      setIsVideoMuted(!isVideoMuted);
    } catch (err: any) {
      console.warn('[StartLive] Video mute toggle failed:', err.message);
    }
  };

  const handleStart = async () => {
    if (!title.trim() || !creatorProfile || isLoading) return;

    if (!hasActiveSubscription) {
      setShowSubscriptionModal(true);
      return;
    }

    setIsLoading(true);
    setAgoraError(null);

    try {
      // ── Edge Function call via startLiveStream() ──
      // 1. Calls manage-live → start (creates live_streams record, generates Agora token)
      // 2. Calls agoraClient.joinAsPublisher() which:
      //    a. If mediaStream exists (from preview): wraps tracks via createCustomAudioTrack/createCustomVideoTrack
      //    b. If no mediaStream: creates fresh tracks via AgoraRTC.createMicrophoneAudioTrack() + createCameraVideoTrack()
      // 3. Publishes tracks to the Agora channel
      // 4. Returns recordingStream from Agora tracks for local recording
      //
      // The Agora App Certificate NEVER touches the frontend.
      const { streamId, channelInfo, recordingStream } = await startLiveStream({
        title: title.trim() || 'Live sans titre',
        isAudioOnly: audioOnly,
        recordingEnabled: true,
        mediaStream: mediaStream, // Pass preview stream if available
      });

      if (!streamId) {
        throw new Error('Aucun identifiant de stream retourné');
      }
      
      // Stop the preview MediaStream — Agora now owns the tracks
      // (or has created its own via createMicrophoneAudioTrack/createCameraVideoTrack)
      if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
        setMediaStream(null);
      }

      setCurrentStreamId(streamId);
      setIsLive(true);

      // Start local recording using the MediaStream from Agora tracks
      const streamForRecording = recordingStream || agoraClient.getLocalMediaStream();
      if (streamForRecording) {
        const started = startRecording(streamForRecording, audioOnly);
        if (started) {
          await recordingService.updateRecordingStatus(streamId, 'recording');
        }
      }

      console.info('[StartLive] Live démarré via Edge Function — stream:', streamId, 'channel:', channelInfo.channelName);
      onStarted();
    } catch (err: any) {
      const msg = err?.message || 'Erreur lors du démarrage du live';
      setMediaError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEndLive = async () => {
    if (!currentStreamId) return;

    setIsLoading(true);

    stopRecording();

    try {
      // ── Edge Function call via endLiveStream() ──
      // 1. Calls agoraClient.leave() — unpublishes tracks, closes mic/camera, leaves channel
      // 2. Calls manage-live → end — updates DB record, calculates duration, updates stats
      const endResult = await endLiveStream(currentStreamId);
      console.info('[EndLive] Live terminé via Edge Function — durée:', endResult.durationSeconds, 's');

      setShowUploadStatus(true);
      setUploadProgress({ status: 'uploading', message: 'Sauvegarde de l\'enregistrement...' });

      await new Promise(resolve => setTimeout(resolve, 500));
      
      const recordingBlob = getRecordingBlob();
      
      if (recordingBlob && recordingBlob.size > 0 && currentStreamId) {
        setUploadProgress({ status: 'uploading', message: `Upload en cours (${(recordingBlob.size / 1024 / 1024).toFixed(1)} MB)...` });

        const result = await recordingService.uploadRecording(currentStreamId, recordingBlob);
        
        if (result) {
          setUploadProgress({ status: 'completed', message: 'Enregistrement sauvegardé avec succès!' });
          await new Promise(resolve => setTimeout(resolve, 2000));
        } else {
          setUploadProgress({ status: 'failed', message: 'Échec de la sauvegarde de l\'enregistrement' });
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      } else {
        setUploadProgress({ status: 'completed', message: 'Live terminé (pas d\'enregistrement)' });
        await new Promise(resolve => setTimeout(resolve, 1500));
      }

      handleClose();
    } catch {
      setUploadProgress({ status: 'failed', message: 'Erreur lors de la fin du live' });
      await new Promise(resolve => setTimeout(resolve, 2000));
      handleClose();
    } finally {
      setIsLoading(false);
    }
  };



  const handleClose = () => {
    stopPreview();
    // Ensure Agora is cleaned up if still connected
    agoraClient.leave().catch(() => {});
    setCurrentStreamId(null);
    setIsLive(false);
    setTitle('');
    setMediaError(null);
    setAgoraError(null);
    setAudioOnly(false);
    setCameraUnavailable(false);
    setAudioFallbackSuggested(false);
    setShowUploadStatus(false);
    setUploadProgress({ status: 'idle', message: '' });
    setIsAudioMuted(false);
    setIsVideoMuted(false);
    onClose();
  };

  const handleSubscriptionComplete = () => {
    setShowSubscriptionModal(false);
    refreshSubscription();
  };

  const avatarUrl = creatorProfile?.avatar_url;
  const displayName = creatorProfile?.display_name || 'Créateur';
  const initials = displayName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

  if (!isOpen) return null;

  if (showSubscriptionModal) {
    return (
      <SubscriptionModal
        isOpen={true}
        onClose={() => setShowSubscriptionModal(false)}
        onSubscribed={handleSubscriptionComplete}
      />
    );
  }

  if (showUploadStatus && uploadProgress.status !== 'idle') {
    return (
      <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
        <div className="bg-gray-900 rounded-2xl p-8 max-w-sm w-full text-center">
          {uploadProgress.status === 'uploading' && (
            <>
              <div className="w-16 h-16 mx-auto mb-4 relative">
                <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
                <svg className="w-6 h-6 text-purple-400 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">Sauvegarde en cours</h3>
              <p className="text-gray-400 text-sm">{uploadProgress.message}</p>
              <div className="mt-4 bg-gray-800 rounded-full h-2 overflow-hidden">
                <div className="bg-purple-500 h-full rounded-full animate-pulse" style={{ width: '60%' }} />
              </div>
            </>
          )}
          {uploadProgress.status === 'processing' && (
            <>
              <div className="w-16 h-16 mx-auto mb-4 bg-yellow-500/20 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-yellow-400 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">Traitement</h3>
              <p className="text-gray-400 text-sm">{uploadProgress.message}</p>
            </>
          )}
          {uploadProgress.status === 'completed' && (
            <>
              <div className="w-16 h-16 mx-auto mb-4 bg-green-500/20 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">Terminé</h3>
              <p className="text-gray-400 text-sm">{uploadProgress.message}</p>
            </>
          )}
          {uploadProgress.status === 'failed' && (
            <>
              <div className="w-16 h-16 mx-auto mb-4 bg-red-500/20 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">Erreur</h3>
              <p className="text-gray-400 text-sm">{uploadProgress.message}</p>
              <button
                onClick={handleClose}
                className="mt-4 bg-gray-800 hover:bg-gray-700 text-white px-6 py-2 rounded-lg transition-colors"
              >
                Fermer
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  // ── LIVE VIEW — Creator is streaming ──
  if (isLive) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col">
        <div className="flex items-center justify-between p-4 bg-gradient-to-b from-black/80 to-transparent absolute top-0 left-0 right-0 z-10">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-red-600 px-3 py-1.5 rounded-full">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
              <span className="text-white text-sm font-bold">LIVE</span>
            </div>
            {audioOnly && (
              <div className="flex items-center gap-1.5 bg-purple-600/80 px-3 py-1.5 rounded-full">
                <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
                <span className="text-white text-xs font-medium">Audio</span>
              </div>
            )}
            <span className="text-white font-medium truncate max-w-[200px]">{title}</span>
          </div>
          <div className="flex items-center gap-2">
            {/* Real-time viewer count from Presence */}
            <div className="bg-black/50 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
              </svg>
              <span className="font-semibold">{presenceViewerCount}</span>
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  presenceConnected ? 'bg-green-400' : 'bg-yellow-400 animate-pulse'
                }`}
              />
            </div>
            <span className="text-gray-500 text-xs font-mono">
              ID: {currentStreamId?.substring(0, 8)}...
            </span>
          </div>

        </div>

        {isRecording && (
          <div className="absolute top-16 left-4 z-10 flex items-center gap-3">
            <div className="bg-red-600/20 backdrop-blur-sm border border-red-500/30 rounded-full px-3 py-1.5 flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
              <span className="text-red-400 text-xs font-medium">REC</span>
              <span className="text-red-300 text-xs font-mono">{formatRecordingDuration(recordingDuration)}</span>
            </div>
          </div>
        )}

        {/* Agora error banner */}
        {agoraError && (
          <div className="absolute top-16 left-16 right-4 z-10">
            <div className="bg-amber-500/20 backdrop-blur-sm border border-amber-500/30 rounded-lg px-3 py-2 flex items-center gap-2">
              <svg className="w-4 h-4 text-amber-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <p className="text-amber-400 text-xs flex-1">{agoraError}</p>
              <button onClick={() => setAgoraError(null)} className="text-amber-400/60 hover:text-amber-400">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        )}

        {/* Main video / audio area */}
        <div className="flex-1 flex items-center justify-center bg-gray-900">
          {audioOnly ? (
            <div className="flex flex-col items-center justify-center gap-6 px-8 w-full max-w-lg">
              <div className="relative">
                <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full overflow-hidden ring-4 ring-purple-500/50 shadow-2xl shadow-purple-500/20">
                  {avatarUrl ? (
                    <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                      <span className="text-white text-4xl sm:text-5xl font-bold">{initials}</span>
                    </div>
                  )}
                </div>
                {!isAudioMuted && (
                  <div className="absolute inset-0 rounded-full ring-4 ring-purple-500/30 animate-ping" style={{ animationDuration: '2s' }} />
                )}
              </div>

              <div className="text-center">
                <h3 className="text-white text-xl font-bold">{displayName}</h3>
                <p className="text-gray-400 text-sm mt-1">{title}</p>
              </div>

              <div className="w-full px-4">
                <AudioVisualizer
                  stream={agoraClient.getLocalMediaStream()}
                  isActive={!isAudioMuted}
                  barColor="#a855f7"
                  barCount={40}
                  className="rounded-xl"
                />
              </div>

              <div className="bg-purple-500/10 border border-purple-500/20 rounded-xl px-4 py-2.5 flex items-center gap-2">
                <svg className="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
                <span className="text-purple-300 text-sm">Mode audio uniquement</span>
              </div>
            </div>
          ) : (
            // Agora renders the local video track into this container
            <div
              ref={agoraVideoContainerRef}
              className="w-full h-full"
              style={{ background: '#111' }}
            />
          )}
        </div>

        {creatorProfile?.whatsapp_number && (
          <div className="absolute top-16 right-4 z-10">
            <div className="bg-green-500/20 backdrop-blur-sm border border-green-500/30 rounded-full px-3 py-1.5 flex items-center gap-2">
              <svg className="w-4 h-4 text-green-400" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              <span className="text-green-400 text-xs font-medium">WhatsApp actif</span>
            </div>
          </div>
        )}

        {recordingError && (
          <div className="absolute top-28 left-4 right-4 z-10">
            <div className="bg-yellow-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-lg px-3 py-2">
              <p className="text-yellow-400 text-xs">Enregistrement: {recordingError}</p>
            </div>
          </div>
        )}

        {/* Bottom controls — End live + mute toggles */}
        <div className="p-4 bg-gradient-to-t from-black/80 to-transparent absolute bottom-0 left-0 right-0">
          <div className="flex items-center justify-center gap-4">
            {/* Mute audio */}
            <button
              onClick={handleToggleAudioMute}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                isAudioMuted ? 'bg-red-600 hover:bg-red-700' : 'bg-white/20 hover:bg-white/30 backdrop-blur-sm'
              }`}
              title={isAudioMuted ? 'Activer le micro' : 'Couper le micro'}
            >
              {isAudioMuted ? (
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
                </svg>
              ) : (
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              )}
            </button>

            {/* End live */}
            <button
              onClick={handleEndLive}
              disabled={isLoading}
              className="px-8 py-3 bg-red-600 hover:bg-red-700 disabled:bg-gray-700 text-white font-semibold rounded-xl transition-colors flex items-center gap-2"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clipRule="evenodd" />
                  </svg>
                  Terminer le live
                </>
              )}
            </button>

            {/* Mute video (only if not audio-only) */}
            {!audioOnly && (
              <button
                onClick={handleToggleVideoMute}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                  isVideoMuted ? 'bg-red-600 hover:bg-red-700' : 'bg-white/20 hover:bg-white/30 backdrop-blur-sm'
                }`}
                title={isVideoMuted ? 'Activer la caméra' : 'Couper la caméra'}
              >
                {isVideoMuted ? (
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    <line x1="3" y1="3" x2="21" y2="21" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                )}
              </button>
            )}
          </div>
          {isRecording && (
            <p className="text-center text-gray-400 text-xs mt-2">
              L'enregistrement sera sauvegardé automatiquement
            </p>
          )}
        </div>
      </div>
    );
  }

  // ── PRE-LIVE SETUP VIEW ──
  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <h2 className="text-xl font-bold text-white">Démarrer un live</h2>
          <button onClick={handleClose} className="w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors">
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6 space-y-5">
          {!hasActiveSubscription && (
            <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <svg className="w-6 h-6 text-yellow-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <div>
                  <p className="text-yellow-400 font-semibold">Abonnement requis</p>
                  <p className="text-yellow-300/80 text-sm mt-1">Un abonnement actif est nécessaire pour démarrer un live.</p>
                  <button onClick={() => setShowSubscriptionModal(true)} className="mt-3 bg-yellow-500 hover:bg-yellow-600 text-black font-medium px-4 py-2 rounded-lg text-sm transition-colors">
                    Voir les forfaits
                  </button>
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm text-gray-400 mb-2">Titre du live</label>
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex: Discussion du soir" className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500" autoFocus />
          </div>

          <div className={`rounded-xl p-4 transition-colors ${audioOnly ? 'bg-purple-500/15 border border-purple-500/40' : 'bg-gray-800/50 border border-gray-700'}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${audioOnly ? 'bg-purple-500/30' : 'bg-gray-700'}`}>
                  <svg className={`w-5 h-5 transition-colors ${audioOnly ? 'text-purple-400' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                </div>
                <div>
                  <p className={`font-medium text-sm ${audioOnly ? 'text-purple-300' : 'text-gray-300'}`}>Mode audio uniquement</p>
                  <p className="text-gray-500 text-xs mt-0.5">{audioOnly ? 'Seul le microphone sera utilisé' : 'Désactivez la caméra et diffusez en audio'}</p>
                </div>
              </div>
              <button onClick={handleToggleAudioOnly} className={`relative w-12 h-7 rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-gray-900 ${audioOnly ? 'bg-purple-600' : 'bg-gray-600'}`} role="switch" aria-checked={audioOnly} aria-label="Mode audio uniquement">
                <span className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full shadow-md transform transition-transform duration-200 ${audioOnly ? 'translate-x-5' : 'translate-x-0'}`} />
              </button>
            </div>
            {cameraUnavailable && !audioOnly && (
              <div className="mt-3 pt-3 border-t border-gray-700/50">
                <p className="text-amber-400/90 text-xs flex items-center gap-1.5">
                  <svg className="w-3.5 h-3.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  Caméra non disponible — activez le mode audio pour continuer
                </p>
              </div>
            )}
          </div>

          {audioFallbackSuggested && !audioOnly && (
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 animate-in fade-in slide-in-from-top-2 duration-300">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    <line x1="3" y1="3" x2="21" y2="21" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
                  </svg>
                </div>
                <div className="flex-1">
                  <p className="text-amber-300 font-semibold text-sm">Caméra non accessible</p>
                  <p className="text-amber-200/70 text-xs mt-1 leading-relaxed">L'accès à la caméra est bloqué. Vous pouvez passer en mode audio uniquement pour démarrer votre live.</p>
                  <div className="flex gap-2 mt-3">
                    <button onClick={switchToAudioOnly} className="bg-purple-600 hover:bg-purple-700 text-white font-medium px-4 py-2 rounded-lg text-xs transition-colors flex items-center gap-2">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                      </svg>
                      Passer en audio uniquement
                    </button>
                    <button onClick={() => { setAudioFallbackSuggested(false); setMediaError(null); }} className="bg-gray-800 hover:bg-gray-700 text-gray-300 font-medium px-4 py-2 rounded-lg text-xs transition-colors">
                      Réessayer
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="relative">
            <div className="aspect-video bg-gray-800 rounded-xl overflow-hidden">
              {audioOnly ? (
                <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-gray-800 via-gray-900 to-gray-800 relative">
                  <div className="absolute inset-0 opacity-5">
                    <div className="w-full h-full" style={{ backgroundImage: 'radial-gradient(circle at 25% 25%, #a855f7 1px, transparent 1px), radial-gradient(circle at 75% 75%, #a855f7 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
                  </div>
                  <div className="relative z-10 mb-3">
                    <div className="w-20 h-20 rounded-full overflow-hidden ring-3 ring-purple-500/40 shadow-lg shadow-purple-500/10">
                      {avatarUrl ? (
                        <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                          <span className="text-white text-2xl font-bold">{initials}</span>
                        </div>
                      )}
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-purple-600 rounded-full flex items-center justify-center ring-2 ring-gray-800">
                      <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                      </svg>
                    </div>
                  </div>
                  {isPreviewActive && mediaStream ? (
                    <div className="w-3/4 z-10">
                      <AudioVisualizer stream={mediaStream} isActive={isPreviewActive} barColor="#a855f7" barCount={24} />
                    </div>
                  ) : (
                    <div className="z-10 text-center">
                      <p className="text-gray-400 text-sm font-medium">Mode audio uniquement</p>
                      <p className="text-gray-500 text-xs mt-1">Votre avatar sera affiché aux spectateurs</p>
                    </div>
                  )}
                </div>
              ) : isPreviewActive && mediaStream ? (
                <video ref={videoPreviewRef} autoPlay muted playsInline className="w-full h-full object-cover mirror" style={{ transform: 'scaleX(-1)' }} />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-gray-500">
                  <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  <p className="text-sm">Aperçu caméra</p>
                </div>
              )}
            </div>
            <div className="absolute bottom-3 right-3 flex gap-2">
              {isPreviewActive ? (
                <button onClick={stopPreview} className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-sm rounded-lg transition-colors">
                  {audioOnly ? 'Arrêter le micro' : 'Arrêter l\'aperçu'}
                </button>
              ) : (
                <button onClick={startPreview} disabled={isLoading} className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 text-white text-sm rounded-lg transition-colors flex items-center gap-2">
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : audioOnly ? (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                      </svg>
                      Tester le micro
                    </>
                  ) : (
                    'Tester la caméra'
                  )}
                </button>
              )}
            </div>
          </div>

          <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center">
                <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </div>
              <div>
                <p className="text-purple-400 font-medium text-sm">Enregistrement automatique</p>
                <p className="text-gray-400 text-xs">{audioOnly ? 'Votre live audio sera enregistré et disponible en replay' : 'Votre live sera enregistré et disponible en replay'}</p>
              </div>
            </div>
          </div>

          {creatorProfile?.whatsapp_number ? (
            <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </div>
                <div>
                  <p className="text-green-400 font-medium text-sm">WhatsApp activé</p>
                  <p className="text-gray-400 text-xs">Les spectateurs pourront vous contacter: {creatorProfile.whatsapp_number}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center">
                  <svg className="w-5 h-5 text-gray-500" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </div>
                <div>
                  <p className="text-gray-400 font-medium text-sm">WhatsApp non configuré</p>
                  <p className="text-gray-500 text-xs">Ajoutez un numéro WhatsApp dans votre profil</p>
                </div>
              </div>
            </div>
          )}

          {mediaError && !audioFallbackSuggested && (
            <div className="p-4 bg-red-500/20 border border-red-500/30 rounded-xl">
              <div className="flex items-start gap-3">
                <svg className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
                <div>
                  <p className="text-red-400 text-sm">{mediaError}</p>
                  <button onClick={() => setMediaError(null)} className="text-red-300 text-xs underline mt-1">Fermer</button>
                </div>
              </div>
            </div>
          )}

          <button
            onClick={handleStart}
            disabled={!title.trim() || isLoading}
            className={`w-full font-semibold py-4 rounded-xl transition-colors flex items-center justify-center gap-2 ${hasActiveSubscription ? 'bg-red-600 hover:bg-red-700 disabled:bg-gray-700 text-white' : 'bg-gray-700 text-gray-400 cursor-not-allowed'}`}
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                {audioOnly ? (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" />
                  </svg>
                )}
                {hasActiveSubscription ? (audioOnly ? 'Démarrer le live audio' : 'Démarrer le live') : 'Abonnement requis'}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default StartLiveModal;
