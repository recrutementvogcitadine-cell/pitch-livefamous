import React, { useState, useCallback, useEffect, useRef } from 'react';
import { supabase, isSupabaseConfigured, getProjectRef } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Database, CheckCircle, XCircle, Loader2, AlertTriangle,
  Copy, ExternalLink, RefreshCw, ChevronDown, ChevronUp,
  Table2, Shield, Zap, HardDrive, FileCode, ClipboardCheck,
  ArrowRight, Download, Eye, EyeOff, Wrench,
  RotateCcw, Sparkles, CircleDot, Clock,
} from 'lucide-react';



// ============================================================================
// TYPES
// ============================================================================

type TableStatus = 'idle' | 'checking' | 'exists' | 'missing' | 'error';

interface TableCheckResult {
  name: string;
  label: string;
  description: string;
  status: TableStatus;
  rowCount?: number;
  errorMessage?: string;
  isCritical: boolean;
  category: 'core' | 'social' | 'admin' | 'moderation' | 'billing';
}

type AutoFixStepStatus = 'pending' | 'running' | 'success' | 'skipped' | 'failed';

interface AutoFixStep {
  id: string;
  label: string;
  description: string;
  status: AutoFixStepStatus;
  errorMessage?: string;
  duration?: number; // ms
}

type AutoFixPhase = 'idle' | 'bootstrap_check' | 'creating_tables' | 'rpc_functions' | 'postamble' | 'verifying' | 'done';

// ============================================================================
// TABLE DEFINITIONS
// ============================================================================

const TABLE_DEFINITIONS: Omit<TableCheckResult, 'status' | 'rowCount' | 'errorMessage'>[] = [
  // Core
  { name: 'utilisateurs', label: 'Utilisateurs', description: 'Profils utilisateurs synchronisés depuis auth.users', isCritical: true, category: 'core' },
  { name: 'creator_profiles', label: 'Profils créateurs', description: 'Profils des créateurs de contenu', isCritical: true, category: 'core' },
  { name: 'live_streams', label: 'Lives', description: 'Sessions de streaming en direct', isCritical: true, category: 'core' },
  { name: 'live_chat_messages', label: 'Messages chat', description: 'Messages du chat en direct', isCritical: true, category: 'core' },
  // Social
  { name: 'follows', label: 'Abonnements', description: 'Relations follower/créateur', isCritical: true, category: 'social' },
  // Billing
  { name: 'payments', label: 'Paiements', description: 'Historique des paiements', isCritical: true, category: 'billing' },
  { name: 'subscription_plans', label: 'Plans d\'abonnement', description: 'Plans tarifaires disponibles', isCritical: false, category: 'billing' },
  { name: 'creator_subscriptions', label: 'Abonnements créateurs', description: 'Abonnements actifs des créateurs', isCritical: false, category: 'billing' },
  // Admin
  { name: 'team_members', label: 'Équipe', description: 'Membres de l\'équipe admin', isCritical: false, category: 'admin' },
  { name: 'admin_users', label: 'Administrateurs', description: 'Table legacy des admins', isCritical: false, category: 'admin' },
  { name: 'support_requests', label: 'Demandes support', description: 'Tickets de support', isCritical: false, category: 'admin' },
  { name: 'verification_requests', label: 'Vérifications', description: 'Demandes de vérification d\'identité', isCritical: false, category: 'admin' },
  // Moderation
  { name: 'chat_bans', label: 'Bannissements', description: 'Utilisateurs bannis du chat', isCritical: false, category: 'moderation' },
  { name: 'moderation_logs', label: 'Logs modération', description: 'Journal des actions de modération', isCritical: false, category: 'moderation' },
];

const TABLE_ORDER = [
  'utilisateurs', 'creator_profiles', 'subscription_plans', 'team_members',
  'admin_users', 'creator_subscriptions', 'live_streams', 'live_chat_messages',
  'follows', 'payments', 'support_requests', 'verification_requests',
  'chat_bans', 'moderation_logs',
];

const CATEGORY_CONFIG: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  core: { label: 'Tables principales', icon: <Database className="w-4 h-4" />, color: 'text-blue-400' },
  social: { label: 'Social', icon: <Zap className="w-4 h-4" />, color: 'text-purple-400' },
  billing: { label: 'Facturation', icon: <HardDrive className="w-4 h-4" />, color: 'text-green-400' },
  admin: { label: 'Administration', icon: <Shield className="w-4 h-4" />, color: 'text-amber-400' },
  moderation: { label: 'Modération', icon: <Table2 className="w-4 h-4" />, color: 'text-red-400' },
};

// ============================================================================
// BOOTSTRAP SQL — Required for auto-fix to work
// ============================================================================

const BOOTSTRAP_SQL = `-- ============================================
-- BOOTSTRAP: exec_migration_sql function
-- Run this ONCE in Supabase SQL Editor to enable auto-fix
-- ============================================
CREATE OR REPLACE FUNCTION public.exec_migration_sql(sql_text TEXT)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  EXECUTE sql_text;
  RETURN jsonb_build_object('success', true);
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('success', false, 'error', SQLERRM, 'detail', SQLSTATE);
END; $$;

GRANT EXECUTE ON FUNCTION public.exec_migration_sql(TEXT) TO service_role;
`;

// ============================================================================
// SQL TEMPLATES FOR EACH TABLE (for manual copy/paste fallback)
// ============================================================================

const TABLE_SQL: Record<string, string> = {
  utilisateurs: `-- utilisateurs (user profile sync from auth.users)
CREATE TABLE IF NOT EXISTS public.utilisateurs (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_user_id  UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email         TEXT,
  display_name  TEXT,
  avatar_url    TEXT,
  phone         TEXT,
  role          TEXT NOT NULL DEFAULT 'user',
  is_active     BOOLEAN NOT NULL DEFAULT true,
  last_seen_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_utilisateurs_auth_user_id ON public.utilisateurs(auth_user_id);
ALTER TABLE public.utilisateurs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "utilisateurs_select" ON public.utilisateurs;
CREATE POLICY "utilisateurs_select" ON public.utilisateurs FOR SELECT USING (true);
DROP POLICY IF EXISTS "utilisateurs_insert" ON public.utilisateurs;
CREATE POLICY "utilisateurs_insert" ON public.utilisateurs FOR INSERT WITH CHECK (auth.uid() = auth_user_id);
DROP POLICY IF EXISTS "utilisateurs_update" ON public.utilisateurs;
CREATE POLICY "utilisateurs_update" ON public.utilisateurs FOR UPDATE USING (auth.uid() = auth_user_id);`,

  creator_profiles: `-- creator_profiles
CREATE TABLE IF NOT EXISTS public.creator_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  bio TEXT,
  avatar_url TEXT,
  whatsapp_number TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  followers_count INTEGER DEFAULT 0,
  total_views INTEGER DEFAULT 0,
  total_live_duration_seconds INTEGER DEFAULT 0,
  live_count INTEGER DEFAULT 0,
  average_viewers INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.creator_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "creator_profiles_select" ON public.creator_profiles FOR SELECT USING (true);
CREATE POLICY "creator_profiles_insert" ON public.creator_profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "creator_profiles_update" ON public.creator_profiles FOR UPDATE USING (auth.uid() = user_id);`,

  live_streams: `CREATE TABLE IF NOT EXISTS public.live_streams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  description TEXT,
  thumbnail_url TEXT,
  is_live BOOLEAN NOT NULL DEFAULT false,
  is_audio_only BOOLEAN NOT NULL DEFAULT false,
  started_at TIMESTAMPTZ DEFAULT now(),
  ended_at TIMESTAMPTZ,
  viewer_count INTEGER NOT NULL DEFAULT 0,
  peak_viewers INTEGER NOT NULL DEFAULT 0,
  recording_enabled BOOLEAN NOT NULL DEFAULT false,
  recording_status TEXT DEFAULT 'none',
  recording_url TEXT,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.live_streams ENABLE ROW LEVEL SECURITY;
CREATE POLICY "live_streams_select" ON public.live_streams FOR SELECT USING (true);`,

  live_chat_messages: `CREATE TABLE IF NOT EXISTS public.live_chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stream_id UUID NOT NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL DEFAULT '',
  avatar_url TEXT,
  message TEXT NOT NULL DEFAULT '',
  is_deleted BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.live_chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "live_chat_messages_select" ON public.live_chat_messages FOR SELECT USING (true);
CREATE POLICY "live_chat_messages_insert" ON public.live_chat_messages FOR INSERT WITH CHECK (auth.uid() = user_id);`,

  follows: `CREATE TABLE IF NOT EXISTS public.follows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(follower_id, creator_id)
);
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "follows_select" ON public.follows FOR SELECT USING (true);
CREATE POLICY "follows_insert" ON public.follows FOR INSERT WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "follows_delete" ON public.follows FOR DELETE USING (auth.uid() = follower_id);`,

  payments: `CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL,
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'XOF',
  status TEXT NOT NULL DEFAULT 'pending',
  payment_method TEXT DEFAULT 'mobile_money',
  provider TEXT DEFAULT '',
  phone_number TEXT DEFAULT '',
  transaction_id TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "payments_select" ON public.payments FOR SELECT USING (true);`,

  subscription_plans: `CREATE TABLE IF NOT EXISTS public.subscription_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL DEFAULT '',
  description TEXT DEFAULT '',
  price_monthly NUMERIC(12,2) NOT NULL DEFAULT 0,
  price_yearly NUMERIC(12,2) NOT NULL DEFAULT 0,
  features JSONB DEFAULT '[]',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "subscription_plans_select" ON public.subscription_plans FOR SELECT USING (true);`,

  creator_subscriptions: `CREATE TABLE IF NOT EXISTS public.creator_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL,
  plan_id UUID,
  billing_cycle TEXT NOT NULL DEFAULT 'monthly',
  status TEXT NOT NULL DEFAULT 'pending',
  started_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.creator_subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "creator_subscriptions_select" ON public.creator_subscriptions FOR SELECT USING (true);`,

  team_members: `CREATE TABLE IF NOT EXISTS public.team_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL DEFAULT '',
  display_name TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'read_only',
  permissions JSONB NOT NULL DEFAULT '{}',
  added_by UUID REFERENCES auth.users(id),
  is_active BOOLEAN NOT NULL DEFAULT true,
  last_active_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "team_members_select" ON public.team_members FOR SELECT USING (true);
CREATE POLICY "team_members_insert" ON public.team_members FOR INSERT WITH CHECK (true);
CREATE POLICY "team_members_update" ON public.team_members FOR UPDATE USING (true);`,

  admin_users: `CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'admin',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin_users_select" ON public.admin_users FOR SELECT USING (true);`,

  support_requests: `CREATE TABLE IF NOT EXISTS public.support_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL,
  subject TEXT NOT NULL DEFAULT '',
  message TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open',
  priority TEXT NOT NULL DEFAULT 'normal',
  admin_notes TEXT,
  resolved_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.support_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "support_requests_select" ON public.support_requests FOR SELECT USING (true);`,

  verification_requests: `CREATE TABLE IF NOT EXISTS public.verification_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  full_legal_name TEXT DEFAULT '',
  date_of_birth DATE,
  country TEXT DEFAULT '',
  document_type TEXT DEFAULT '',
  document_front_url TEXT,
  document_back_url TEXT,
  selfie_url TEXT,
  additional_notes TEXT DEFAULT '',
  rejection_reason TEXT,
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  reviewed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.verification_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "verification_requests_select" ON public.verification_requests FOR SELECT USING (true);`,

  chat_bans: `CREATE TABLE IF NOT EXISTS public.chat_bans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  stream_id UUID,
  banned_by UUID NOT NULL REFERENCES auth.users(id),
  reason TEXT DEFAULT '',
  banned_user_name TEXT DEFAULT '',
  banned_by_name TEXT DEFAULT '',
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_bans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "chat_bans_select" ON public.chat_bans FOR SELECT USING (true);`,

  moderation_logs: `CREATE TABLE IF NOT EXISTS public.moderation_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  moderator_id UUID NOT NULL REFERENCES auth.users(id),
  moderator_name TEXT NOT NULL DEFAULT '',
  action_type TEXT NOT NULL,
  target_type TEXT NOT NULL DEFAULT 'other',
  target_id TEXT,
  details JSONB NOT NULL DEFAULT '{}',
  stream_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.moderation_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "moderation_logs_select" ON public.moderation_logs FOR SELECT USING (true);
CREATE POLICY "moderation_logs_insert" ON public.moderation_logs FOR INSERT WITH CHECK (auth.uid() = moderator_id);`,
};

// Preamble / Postamble for manual SQL
const PREAMBLE_SQL = `-- FAMOUS.AI — Script de création des tables manquantes
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$;

`;

const POSTAMBLE_SQL = `

-- TRIGGERS updated_at
DO $$
DECLARE tbl TEXT;
BEGIN
  FOR tbl IN SELECT unnest(ARRAY[
    'creator_profiles','subscription_plans','creator_subscriptions',
    'team_members','support_requests','live_streams',
    'chat_bans','verification_requests','payments'
  ]) LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trigger_updated_at ON public.%I;
       CREATE TRIGGER trigger_updated_at BEFORE UPDATE ON public.%I
       FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();', tbl, tbl
    );
  END LOOP;
END; $$;

-- Realtime
DO $$ BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.live_chat_messages; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.live_streams; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.follows; EXCEPTION WHEN duplicate_object THEN NULL; END;
END; $$;
`;

// ============================================================================
// HELPER: Step icon component
// ============================================================================

const StepIcon: React.FC<{ status: AutoFixStepStatus }> = ({ status }) => {
  switch (status) {
    case 'pending':
      return <CircleDot className="w-4 h-4 text-gray-500" />;
    case 'running':
      return <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />;
    case 'success':
      return <CheckCircle className="w-4 h-4 text-emerald-400" />;
    case 'skipped':
      return <Clock className="w-4 h-4 text-gray-400" />;
    case 'failed':
      return <XCircle className="w-4 h-4 text-red-400" />;
    default:
      return <CircleDot className="w-4 h-4 text-gray-600" />;
  }
};

// ============================================================================
// COMPONENT
// ============================================================================

interface DatabaseSetupWizardProps {
  className?: string;
  compact?: boolean;
}

const DatabaseSetupWizard: React.FC<DatabaseSetupWizardProps> = ({ className = '', compact = false }) => {
  // Table check state
  const [tables, setTables] = useState<TableCheckResult[]>(
    TABLE_DEFINITIONS.map(t => ({ ...t, status: 'idle' }))
  );
  const [isChecking, setIsChecking] = useState(false);
  const [hasChecked, setHasChecked] = useState(false);

  // SQL panel state
  const [showSQL, setShowSQL] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showFullScript, setShowFullScript] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(
    new Set(['core', 'social', 'billing', 'admin', 'moderation'])
  );
  const sqlRef = useRef<HTMLTextAreaElement>(null);

  // Auto-fix state
  const [isAutoFixing, setIsAutoFixing] = useState(false);
  const [autoFixPhase, setAutoFixPhase] = useState<AutoFixPhase>('idle');
  const [autoFixSteps, setAutoFixSteps] = useState<AutoFixStep[]>([]);
  const [bootstrapAvailable, setBootstrapAvailable] = useState<boolean | null>(null);
  const [showBootstrapHelp, setShowBootstrapHelp] = useState(false);
  const [bootstrapCopied, setBootstrapCopied] = useState(false);
  const [autoFixSummary, setAutoFixSummary] = useState<{
    total: number;
    created: number;
    skipped: number;
    failed: number;
    rpcOk: boolean;
    postambleOk: boolean;
    verifiedCount: number;
  } | null>(null);
  const [showAutoFixPanel, setShowAutoFixPanel] = useState(false);

  // Auto-check on mount
  useEffect(() => {
    if (isSupabaseConfigured && !hasChecked) {
      checkAllTables();
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ============================================================================
  // TABLE CHECKING
  // ============================================================================

  const checkAllTables = useCallback(async () => {
    if (!isSupabaseConfigured) return;
    setIsChecking(true);

    const results: TableCheckResult[] = [];

    for (const tableDef of TABLE_DEFINITIONS) {
      setTables(prev => prev.map(t =>
        t.name === tableDef.name ? { ...t, status: 'checking' } : t
      ));
      try {
        const { error, count } = await supabase
          .from(tableDef.name)
          .select('*', { count: 'exact', head: true });

        if (error) {
          const errMsg = (error.message || '').toLowerCase();
          const errCode = error.code || '';
          if (
            errCode === '42P01' ||
            errCode === 'PGRST205' ||
            errMsg.includes('does not exist') ||
            errMsg.includes('relation') ||
            errMsg.includes('schema cache') ||
            errMsg.includes('404') ||
            errMsg.includes('not found')
          ) {
            results.push({ ...tableDef, status: 'missing' });
          } else if (errCode === '42501' || errCode.startsWith('PGRST')) {
            results.push({ ...tableDef, status: 'exists', rowCount: undefined });
          } else {
            const looksLikeServerResponse = errMsg.includes('erreur serveur') || errMsg.includes('http') || errMsg.includes('server');
            if (!errCode && looksLikeServerResponse) {
              results.push({ ...tableDef, status: 'missing' });
            } else {
              results.push({ ...tableDef, status: 'error', errorMessage: error.message });
            }
          }
        } else {
          results.push({ ...tableDef, status: 'exists', rowCount: count ?? 0 });
        }
      } catch (err: any) {
        results.push({
          ...tableDef,
          status: 'error',
          errorMessage: err?.message || 'Erreur inconnue',
        });
      }

      setTables(prev => {
        const latest = results[results.length - 1];
        return prev.map(t => t.name === latest.name ? latest : t);
      });
    }

    setHasChecked(true);
    setIsChecking(false);
  }, []);

  // ============================================================================
  // AUTO-FIX
  // ============================================================================

  const handleAutoFix = useCallback(async () => {
    if (isAutoFixing) return;
    setIsAutoFixing(true);
    setShowAutoFixPanel(true);
    setAutoFixSummary(null);

    const missingTableNames = tables
      .filter(t => t.status === 'missing' || t.status === 'error')
      .map(t => t.name);

    // Build steps list
    const steps: AutoFixStep[] = [
      {
        id: 'bootstrap_check',
        label: 'Vérification du bootstrap',
        description: 'Vérifier que la fonction exec_migration_sql est disponible',
        status: 'pending',
      },
    ];

    // Add table steps (only missing ones, in dependency order)
    const orderedMissing = TABLE_ORDER.filter(t => missingTableNames.includes(t));
    for (const tableName of orderedMissing) {
      const def = TABLE_DEFINITIONS.find(d => d.name === tableName);
      steps.push({
        id: `table:${tableName}`,
        label: `Table: ${tableName}`,
        description: def?.description || `Créer la table ${tableName}`,
        status: 'pending',
      });
    }

    // Add RPC and postamble steps
    steps.push({
      id: 'rpc_functions',
      label: 'Fonctions RPC',
      description: 'Créer/mettre à jour les fonctions serveur (setup_platform_owner, etc.)',
      status: 'pending',
    });
    steps.push({
      id: 'postamble',
      label: 'Triggers & Realtime',
      description: 'Configurer les triggers updated_at et la publication realtime',
      status: 'pending',
    });
    steps.push({
      id: 'verify',
      label: 'Vérification finale',
      description: 'Vérifier que toutes les tables sont accessibles',
      status: 'pending',
    });

    setAutoFixSteps(steps);

    // Helper to update a step
    const updateStep = (id: string, updates: Partial<AutoFixStep>) => {
      setAutoFixSteps(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
    };

    // Helper to call edge function
    const callEdge = async (funcName: string, body: Record<string, any>) => {
      try {
        const { data, error } = await supabase.functions.invoke(funcName, { body });
        if (error) {
          return { success: false, error: error.message || 'Edge function error', data: null };
        }
        return { success: data?.success !== false, error: data?.error || null, data };
      } catch (e: any) {
        return { success: false, error: e?.message || 'Network error', data: null };
      }
    };

    let createdCount = 0;
    let skippedCount = 0;
    let failedCount = 0;
    let rpcOk = false;
    let postambleOk = false;

    // ---- Step 1: Bootstrap check ----
    setAutoFixPhase('bootstrap_check');
    updateStep('bootstrap_check', { status: 'running' });
    const startBoot = Date.now();

    const bootResult = await callEdge('run-migrations', { action: 'check_bootstrap' });
    const isBootstrapReady = bootResult.data?.bootstrap_ready === true;
    setBootstrapAvailable(isBootstrapReady);

    if (!isBootstrapReady) {
      updateStep('bootstrap_check', {
        status: 'failed',
        errorMessage: 'La fonction exec_migration_sql n\'est pas installée. Veuillez exécuter le SQL de bootstrap.',
        duration: Date.now() - startBoot,
      });
      // Mark all remaining steps as failed
      steps.forEach(s => {
        if (s.id !== 'bootstrap_check') {
          updateStep(s.id, { status: 'failed', errorMessage: 'Bootstrap requis' });
        }
      });
      setAutoFixPhase('done');
      setShowBootstrapHelp(true);
      setIsAutoFixing(false);
      setAutoFixSummary({
        total: orderedMissing.length,
        created: 0,
        skipped: 0,
        failed: orderedMissing.length,
        rpcOk: false,
        postambleOk: false,
        verifiedCount: 0,
      });
      return;
    }

    updateStep('bootstrap_check', { status: 'success', duration: Date.now() - startBoot });

    // ---- Step 2: Create missing tables one by one ----
    setAutoFixPhase('creating_tables');

    for (const tableName of orderedMissing) {
      const stepId = `table:${tableName}`;
      updateStep(stepId, { status: 'running' });
      const startTable = Date.now();

      const result = await callEdge('run-migrations', {
        action: 'create_table',
        table: tableName,
      });

      if (result.data?.already_exists) {
        updateStep(stepId, { status: 'skipped', duration: Date.now() - startTable });
        skippedCount++;
      } else if (result.success && result.data?.verified) {
        updateStep(stepId, { status: 'success', duration: Date.now() - startTable });
        createdCount++;
      } else if (result.success && !result.data?.verified) {
        // Created but not verified — might still be OK
        updateStep(stepId, {
          status: 'success',
          duration: Date.now() - startTable,
          errorMessage: 'Créée mais vérification incertaine',
        });
        createdCount++;
      } else {
        updateStep(stepId, {
          status: 'failed',
          errorMessage: result.error || result.data?.error || 'Erreur inconnue',
          duration: Date.now() - startTable,
        });
        failedCount++;
      }
    }

    // ---- Step 3: RPC Functions ----
    setAutoFixPhase('rpc_functions');
    updateStep('rpc_functions', { status: 'running' });
    const startRpc = Date.now();

    const rpcResult = await callEdge('run-migrations', { action: 'setup_rpc_functions' });
    rpcOk = rpcResult.success;
    updateStep('rpc_functions', {
      status: rpcOk ? 'success' : 'failed',
      errorMessage: rpcOk ? undefined : (rpcResult.error || 'Erreur lors de la création des fonctions RPC'),
      duration: Date.now() - startRpc,
    });

    // ---- Step 4: Postamble (triggers, realtime, views) ----
    setAutoFixPhase('postamble');
    updateStep('postamble', { status: 'running' });
    const startPost = Date.now();

    const postResult = await callEdge('run-migrations', { action: 'setup_postamble' });
    postambleOk = postResult.success;
    updateStep('postamble', {
      status: postambleOk ? 'success' : 'failed',
      errorMessage: postambleOk ? undefined : (postResult.error || 'Erreur lors de la configuration'),
      duration: Date.now() - startPost,
    });

    // ---- Step 5: Verify using edge function (avoids stale React state) ----
    setAutoFixPhase('verifying');
    updateStep('verify', { status: 'running' });
    const startVerify = Date.now();

    // Use the edge function to get accurate table counts
    const verifyResult = await callEdge('run-migrations', { action: 'check_tables' });
    const verifiedCount = verifyResult.data?.existing_count ?? 0;

    updateStep('verify', {
      status: 'success',
      duration: Date.now() - startVerify,
    });

    // ---- Done ----
    setAutoFixPhase('done');
    setIsAutoFixing(false);

    // Re-check tables in the UI to update the table checklist display
    checkAllTables();

    setAutoFixSummary({
      total: orderedMissing.length,
      created: createdCount,
      skipped: skippedCount,
      failed: failedCount,
      rpcOk,
      postambleOk,
      verifiedCount,
    });

  }, [isAutoFixing, tables, checkAllTables]);

  const resetAutoFix = useCallback(() => {
    setAutoFixSteps([]);
    setAutoFixPhase('idle');
    setAutoFixSummary(null);
    setShowAutoFixPanel(false);
    setShowBootstrapHelp(false);
  }, []);

  // ============================================================================
  // STATS
  // ============================================================================

  const existingCount = tables.filter(t => t.status === 'exists').length;
  const missingCount = tables.filter(t => t.status === 'missing').length;
  const errorCount = tables.filter(t => t.status === 'error').length;
  const totalCount = tables.length;
  const allExist = existingCount === totalCount && hasChecked;
  const missingTables = tables.filter(t => t.status === 'missing');
  const criticalMissing = missingTables.filter(t => t.isCritical);
  const hasMissingOrErrors = missingCount > 0 || errorCount > 0;

  // ============================================================================
  // SQL GENERATION (for manual fallback)
  // ============================================================================

  const generateMissingSQL = useCallback((): string => {
    if (showFullScript) {
      const allSQL = TABLE_DEFINITIONS.map(t => TABLE_SQL[t.name]).filter(Boolean).join('\n\n');
      return PREAMBLE_SQL + allSQL + POSTAMBLE_SQL;
    }
    const missing = tables.filter(t => t.status === 'missing');
    if (missing.length === 0) return '-- Toutes les tables existent déjà !';
    const sqlParts = missing.map(t => TABLE_SQL[t.name]).filter(Boolean);
    return PREAMBLE_SQL + sqlParts.join('\n\n') + POSTAMBLE_SQL;
  }, [tables, showFullScript]);

  const handleCopySQL = useCallback(async () => {
    const sql = generateMissingSQL();
    try {
      await navigator.clipboard.writeText(sql);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      if (sqlRef.current) {
        sqlRef.current.select();
        document.execCommand('copy');
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
      }
    }
  }, [generateMissingSQL]);

  const handleCopyBootstrapSQL = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(BOOTSTRAP_SQL);
      setBootstrapCopied(true);
      setTimeout(() => setBootstrapCopied(false), 3000);
    } catch {
      // fallback
    }
  }, []);

  const handleDownloadSQL = useCallback(() => {
    const sql = generateMissingSQL();
    const blob = new Blob([sql], { type: 'text/sql' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'famous-ai-missing-tables.sql';
    a.click();
    URL.revokeObjectURL(url);
  }, [generateMissingSQL]);

  const toggleCategory = (cat: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat);
      else next.add(cat);
      return next;
    });
  };

  const getSQLEditorUrl = () => {
    const ref = getProjectRef();
    if (ref) return `https://supabase.com/dashboard/project/${ref}/sql/new`;
    return 'https://supabase.com/dashboard';
  };

  // Group tables by category
  const groupedTables = Object.entries(CATEGORY_CONFIG).map(([catKey, catConfig]) => ({
    key: catKey,
    ...catConfig,
    tables: tables.filter(t => t.category === catKey),
  }));

  // ============================================================================
  // RENDER
  // ============================================================================

  if (!isSupabaseConfigured) {
    return (
      <Card className={`border-amber-500/30 bg-gray-900/80 backdrop-blur-xl ${className}`}>
        <CardContent className="py-6">
          <div className="flex items-center gap-3 text-amber-400">
            <AlertTriangle className="w-5 h-5" />
            <p className="text-sm">Connectez d'abord Supabase pour vérifier les tables.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {/* ================================================================ */}
      {/* HEADER CARD */}
      {/* ================================================================ */}
      <Card className="border-gray-800 bg-gray-900/80 backdrop-blur-xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 via-purple-500/5 to-cyan-500/5 pointer-events-none" />
        <CardHeader className="relative pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
                <Database className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-lg">Assistant base de données</CardTitle>
                <CardDescription className="text-gray-400 text-sm">
                  Vérifiez et créez les {totalCount} tables requises
                </CardDescription>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={checkAllTables}
                disabled={isChecking || isAutoFixing}
                className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
              >
                {isChecking ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                {isChecking ? 'Vérification...' : hasChecked ? 'Revérifier' : 'Vérifier'}
              </Button>
            </div>
          </div>
        </CardHeader>

        {/* Progress Summary */}
        {hasChecked && (
          <CardContent className="relative pt-0 pb-4">
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge className={`${allExist ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-blue-500/10 text-blue-400 border-blue-500/30'}`}>
                <CheckCircle className="w-3 h-3 mr-1" />
                {existingCount} existante{existingCount > 1 ? 's' : ''}
              </Badge>
              {missingCount > 0 && (
                <Badge className="bg-red-500/10 text-red-400 border-red-500/30">
                  <XCircle className="w-3 h-3 mr-1" />
                  {missingCount} manquante{missingCount > 1 ? 's' : ''}
                </Badge>
              )}
              {errorCount > 0 && (
                <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/30">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  {errorCount} erreur{errorCount > 1 ? 's' : ''}
                </Badge>
              )}
            </div>

            {/* Progress bar */}
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <div className="h-full flex transition-all duration-700">
                <div
                  className="bg-emerald-500 transition-all duration-500"
                  style={{ width: `${(existingCount / totalCount) * 100}%` }}
                />
                <div
                  className="bg-amber-500 transition-all duration-500"
                  style={{ width: `${(errorCount / totalCount) * 100}%` }}
                />
                <div
                  className="bg-red-500 transition-all duration-500"
                  style={{ width: `${(missingCount / totalCount) * 100}%` }}
                />
              </div>
            </div>
            <p className="text-gray-500 text-xs mt-1.5">
              {existingCount}/{totalCount} tables détectées
            </p>

            {allExist && (
              <Alert className="mt-3 border-emerald-500/30 bg-emerald-500/10">
                <CheckCircle className="h-4 w-4 text-emerald-400" />
                <AlertDescription className="text-emerald-300">
                  Toutes les tables sont en place ! Votre base de données est correctement configurée.
                </AlertDescription>
              </Alert>
            )}

            {criticalMissing.length > 0 && (
              <Alert className="mt-3 border-red-500/30 bg-red-500/10">
                <AlertTriangle className="h-4 w-4 text-red-400" />
                <AlertDescription className="text-red-300">
                  <span className="font-semibold">{criticalMissing.length} table{criticalMissing.length > 1 ? 's' : ''} critique{criticalMissing.length > 1 ? 's' : ''} manquante{criticalMissing.length > 1 ? 's' : ''} :</span>{' '}
                  {criticalMissing.map(t => t.name).join(', ')}
                  <br />
                  <span className="text-red-400/80 text-xs">L'application ne fonctionnera pas correctement sans ces tables.</span>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        )}
      </Card>

      {/* ================================================================ */}
      {/* AUTO-FIX BUTTON — Prominent one-click action */}
      {/* ================================================================ */}
      {hasChecked && hasMissingOrErrors && !showAutoFixPanel && (
        <Card className="border-indigo-500/30 bg-gradient-to-br from-indigo-950/60 via-gray-900/80 to-purple-950/60 backdrop-blur-xl overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-500/10 via-transparent to-purple-500/10 pointer-events-none" />
          <CardContent className="relative py-6">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="flex-shrink-0">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-xl shadow-indigo-500/30 ring-2 ring-indigo-400/20">
                  <Wrench className="w-7 h-7 text-white" />
                </div>
              </div>
              <div className="flex-1 text-center sm:text-left">
                <h3 className="text-white font-bold text-lg mb-1">Réparation automatique</h3>
                <p className="text-gray-400 text-sm">
                  {missingCount + errorCount} table{(missingCount + errorCount) > 1 ? 's' : ''} à créer.
                  Cliquez pour tout configurer automatiquement en un clic — tables, fonctions RPC, triggers et realtime.
                </p>
              </div>
              <Button
                onClick={handleAutoFix}
                disabled={isAutoFixing || isChecking}
                size="lg"
                className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:via-purple-500 hover:to-pink-500 text-white font-bold shadow-xl shadow-purple-500/25 border-0 px-8 py-3 text-base transition-all duration-300 hover:scale-[1.02] hover:shadow-purple-500/40 min-w-[220px]"
              >
                {isAutoFixing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Réparation en cours...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    Auto-fix Database
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ================================================================ */}
      {/* AUTO-FIX PROGRESS PANEL */}
      {/* ================================================================ */}
      {showAutoFixPanel && (
        <Card className="border-indigo-500/30 bg-gray-900/90 backdrop-blur-xl overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/5 to-transparent pointer-events-none" />
          <CardHeader className="relative pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg ${
                  autoFixPhase === 'done'
                    ? autoFixSummary && autoFixSummary.failed === 0
                      ? 'bg-gradient-to-br from-emerald-500 to-green-600 shadow-emerald-500/20'
                      : 'bg-gradient-to-br from-amber-500 to-orange-600 shadow-amber-500/20'
                    : 'bg-gradient-to-br from-indigo-500 to-purple-600 shadow-indigo-500/20'
                }`}>
                  {autoFixPhase === 'done' ? (
                    autoFixSummary && autoFixSummary.failed === 0 ? (
                      <CheckCircle className="w-5 h-5 text-white" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-white" />
                    )
                  ) : (
                    <Loader2 className="w-5 h-5 text-white animate-spin" />
                  )}
                </div>
                <div>
                  <CardTitle className="text-white text-base">
                    {autoFixPhase === 'done'
                      ? autoFixSummary && autoFixSummary.failed === 0
                        ? 'Réparation terminée !'
                        : 'Réparation terminée avec des erreurs'
                      : 'Réparation en cours...'
                    }
                  </CardTitle>
                  <CardDescription className="text-gray-400 text-xs">
                    {autoFixPhase === 'bootstrap_check' && 'Vérification du bootstrap...'}
                    {autoFixPhase === 'creating_tables' && 'Création des tables manquantes...'}
                    {autoFixPhase === 'rpc_functions' && 'Configuration des fonctions RPC...'}
                    {autoFixPhase === 'postamble' && 'Application des triggers et realtime...'}
                    {autoFixPhase === 'verifying' && 'Vérification finale...'}
                    {autoFixPhase === 'done' && `${autoFixSteps.filter(s => s.status === 'success').length}/${autoFixSteps.length} étapes réussies`}
                  </CardDescription>
                </div>
              </div>
              {autoFixPhase === 'done' && (
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => { resetAutoFix(); checkAllTables(); }}
                    className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                  >
                    <RotateCcw className="w-3.5 h-3.5 mr-1.5" />
                    Recommencer
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={resetAutoFix}
                    className="text-gray-500 hover:text-gray-300"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>

          <CardContent className="relative pt-0 space-y-3">
            {/* Overall progress bar */}
            {autoFixPhase !== 'idle' && (
              <div className="space-y-1.5">
                <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ease-out ${
                      autoFixPhase === 'done'
                        ? autoFixSummary && autoFixSummary.failed === 0
                          ? 'bg-gradient-to-r from-emerald-500 to-green-400'
                          : 'bg-gradient-to-r from-amber-500 to-orange-400'
                        : 'bg-gradient-to-r from-indigo-500 to-purple-500'
                    }`}
                    style={{
                      width: `${Math.max(5, (autoFixSteps.filter(s => s.status !== 'pending' && s.status !== 'running').length / Math.max(autoFixSteps.length, 1)) * 100)}%`
                    }}
                  />
                </div>
                <div className="flex justify-between text-xs text-gray-500">
                  <span>
                    {autoFixSteps.filter(s => s.status === 'success' || s.status === 'skipped').length} / {autoFixSteps.length} étapes
                  </span>
                  {isAutoFixing && (
                    <span className="text-indigo-400 animate-pulse">En cours...</span>
                  )}
                </div>
              </div>
            )}

            {/* Steps list */}
            <div className="space-y-1 max-h-[400px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
              {autoFixSteps.map((step) => (
                <div
                  key={step.id}
                  className={`flex items-start gap-3 px-3 py-2.5 rounded-lg transition-all duration-300 ${
                    step.status === 'running'
                      ? 'bg-indigo-500/10 border border-indigo-500/20 ring-1 ring-indigo-500/10'
                      : step.status === 'success'
                      ? 'bg-emerald-500/5 border border-transparent'
                      : step.status === 'failed'
                      ? 'bg-red-500/5 border border-red-500/10'
                      : step.status === 'skipped'
                      ? 'bg-gray-800/30 border border-transparent'
                      : 'bg-transparent border border-transparent opacity-60'
                  }`}
                >
                  <div className="flex-shrink-0 mt-0.5">
                    <StepIcon status={step.status} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-medium ${
                        step.status === 'running' ? 'text-indigo-300' :
                        step.status === 'success' ? 'text-emerald-300' :
                        step.status === 'failed' ? 'text-red-300' :
                        step.status === 'skipped' ? 'text-gray-400' :
                        'text-gray-500'
                      }`}>
                        {step.label}
                      </span>
                      {step.duration !== undefined && (
                        <span className="text-[10px] text-gray-600 font-mono">
                          {step.duration < 1000 ? `${step.duration}ms` : `${(step.duration / 1000).toFixed(1)}s`}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">{step.description}</p>
                    {step.errorMessage && step.status === 'failed' && (
                      <p className="text-xs text-red-400/80 mt-1 font-mono bg-red-500/5 rounded px-2 py-1">
                        {step.errorMessage}
                      </p>
                    )}
                    {step.status === 'skipped' && (
                      <p className="text-xs text-gray-500 mt-0.5 italic">Déjà existant — ignoré</p>
                    )}
                  </div>
                  <div className="flex-shrink-0">
                    {step.status === 'success' && (
                      <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-[10px] px-1.5 py-0">
                        OK
                      </Badge>
                    )}
                    {step.status === 'skipped' && (
                      <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20 text-[10px] px-1.5 py-0">
                        Ignoré
                      </Badge>
                    )}
                    {step.status === 'failed' && (
                      <Badge className="bg-red-500/10 text-red-400 border-red-500/20 text-[10px] px-1.5 py-0">
                        Échec
                      </Badge>
                    )}
                    {step.status === 'running' && (
                      <Badge className="bg-indigo-500/10 text-indigo-400 border-indigo-500/20 text-[10px] px-1.5 py-0 animate-pulse">
                        En cours
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* ---- Summary after completion ---- */}
            {autoFixPhase === 'done' && autoFixSummary && (
              <div className={`rounded-xl p-4 border ${
                autoFixSummary.failed === 0
                  ? 'bg-emerald-500/10 border-emerald-500/20'
                  : 'bg-amber-500/10 border-amber-500/20'
              }`}>
                <div className="flex items-start gap-3">
                  {autoFixSummary.failed === 0 ? (
                    <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <h4 className={`font-semibold text-sm mb-2 ${
                      autoFixSummary.failed === 0 ? 'text-emerald-300' : 'text-amber-300'
                    }`}>
                      {autoFixSummary.failed === 0
                        ? 'Base de données configurée avec succès !'
                        : `Réparation terminée avec ${autoFixSummary.failed} erreur${autoFixSummary.failed > 1 ? 's' : ''}`
                      }
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="bg-black/20 rounded-lg p-2.5 text-center">
                        <div className="text-lg font-bold text-emerald-400">{autoFixSummary.created}</div>
                        <div className="text-[10px] text-gray-400 uppercase tracking-wider">Créées</div>
                      </div>
                      <div className="bg-black/20 rounded-lg p-2.5 text-center">
                        <div className="text-lg font-bold text-gray-400">{autoFixSummary.skipped}</div>
                        <div className="text-[10px] text-gray-400 uppercase tracking-wider">Ignorées</div>
                      </div>
                      <div className="bg-black/20 rounded-lg p-2.5 text-center">
                        <div className={`text-lg font-bold ${autoFixSummary.failed > 0 ? 'text-red-400' : 'text-gray-600'}`}>
                          {autoFixSummary.failed}
                        </div>
                        <div className="text-[10px] text-gray-400 uppercase tracking-wider">Échouées</div>
                      </div>
                      <div className="bg-black/20 rounded-lg p-2.5 text-center">
                        <div className="text-lg font-bold text-blue-400">{autoFixSummary.verifiedCount}/{totalCount}</div>
                        <div className="text-[10px] text-gray-400 uppercase tracking-wider">Vérifiées</div>
                      </div>
                    </div>

                    {/* RPC and Postamble status */}
                    <div className="flex flex-wrap gap-2 mt-3">
                      <Badge className={autoFixSummary.rpcOk
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        : 'bg-red-500/10 text-red-400 border-red-500/20'
                      }>
                        {autoFixSummary.rpcOk ? <CheckCircle className="w-3 h-3 mr-1" /> : <XCircle className="w-3 h-3 mr-1" />}
                        Fonctions RPC
                      </Badge>
                      <Badge className={autoFixSummary.postambleOk
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        : 'bg-red-500/10 text-red-400 border-red-500/20'
                      }>
                        {autoFixSummary.postambleOk ? <CheckCircle className="w-3 h-3 mr-1" /> : <XCircle className="w-3 h-3 mr-1" />}
                        Triggers & Realtime
                      </Badge>
                    </div>

                    {autoFixSummary.failed === 0 && (
                      <p className="text-emerald-400/70 text-xs mt-3">
                        Vous pouvez maintenant utiliser l'application normalement. Essayez de vous connecter ou de créer un profil créateur.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ---- Bootstrap Help Panel ---- */}
            {showBootstrapHelp && (
              <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="text-amber-300 font-semibold text-sm mb-1">Bootstrap requis</h4>
                    <p className="text-amber-300/70 text-xs mb-3">
                      La fonction <code className="bg-amber-500/10 px-1.5 py-0.5 rounded text-amber-300">exec_migration_sql</code> n'est pas encore installée dans votre base de données.
                      Cette fonction est nécessaire pour que l'auto-fix puisse créer les tables automatiquement.
                    </p>
                    <div className="space-y-2">
                      <p className="text-amber-300/80 text-xs font-medium">Instructions :</p>
                      <ol className="text-amber-300/60 text-xs space-y-1.5 list-decimal list-inside">
                        <li>Cliquez <span className="font-semibold text-amber-300">"Copier le SQL Bootstrap"</span></li>
                        <li>
                          Ouvrez le{' '}
                          <a
                            href={getSQLEditorUrl()}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-amber-400 hover:text-amber-300 underline inline-flex items-center gap-1"
                          >
                            SQL Editor de Supabase <ExternalLink className="w-3 h-3" />
                          </a>
                        </li>
                        <li>Collez et exécutez le script (Ctrl+Enter)</li>
                        <li>Revenez ici et relancez l'auto-fix</li>
                      </ol>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2 mt-3">
                      <Button
                        size="sm"
                        onClick={handleCopyBootstrapSQL}
                        className={`flex-1 font-semibold ${
                          bootstrapCopied
                            ? 'bg-emerald-600 hover:bg-emerald-700'
                            : 'bg-amber-600 hover:bg-amber-700'
                        } text-white`}
                      >
                        {bootstrapCopied ? (
                          <>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Copié !
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4 mr-2" />
                            Copier le SQL Bootstrap
                          </>
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(getSQLEditorUrl(), '_blank')}
                        className="flex-1 border-amber-500/30 text-amber-400 hover:bg-amber-500/10"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Ouvrir SQL Editor
                      </Button>
                    </div>

                    {/* Show the bootstrap SQL */}
                    <details className="mt-3">
                      <summary className="text-xs text-amber-400/60 cursor-pointer hover:text-amber-400/80 transition-colors">
                        Voir le SQL Bootstrap
                      </summary>
                      <pre className="mt-2 bg-gray-950 border border-gray-800 rounded-lg p-3 text-[11px] font-mono text-gray-300 overflow-x-auto max-h-40 overflow-y-auto">
                        {BOOTSTRAP_SQL}
                      </pre>
                    </details>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ================================================================ */}
      {/* TABLE CHECKLIST */}
      {/* ================================================================ */}
      <div className="space-y-2">
        {groupedTables.map(group => {
          const isExpanded = expandedCategories.has(group.key);
          const groupExisting = group.tables.filter(t => t.status === 'exists').length;
          const groupMissing = group.tables.filter(t => t.status === 'missing').length;
          const groupTotal = group.tables.length;
          const groupAllOk = groupExisting === groupTotal && hasChecked;

          return (
            <Card key={group.key} className={`border-gray-800 bg-gray-900/60 backdrop-blur-sm overflow-hidden transition-all ${
              groupMissing > 0 ? 'border-red-500/20' : groupAllOk ? 'border-emerald-500/20' : ''
            }`}>
              <button
                onClick={() => toggleCategory(group.key)}
                className="w-full flex items-center justify-between p-3.5 text-left hover:bg-white/[0.02] transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <span className={group.color}>{group.icon}</span>
                  <span className="text-white font-medium text-sm">{group.label}</span>
                  {hasChecked && (
                    <span className={`text-xs ${groupAllOk ? 'text-emerald-400' : groupMissing > 0 ? 'text-red-400' : 'text-gray-500'}`}>
                      ({groupExisting}/{groupTotal})
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {hasChecked && groupAllOk && <CheckCircle className="w-4 h-4 text-emerald-400" />}
                  {hasChecked && groupMissing > 0 && <XCircle className="w-4 h-4 text-red-400" />}
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
                </div>
              </button>

              {isExpanded && (
                <div className="border-t border-gray-800/50">
                  {group.tables.map((table) => (
                    <div
                      key={table.name}
                      className={`flex items-center gap-3 px-4 py-2.5 border-b border-gray-800/30 last:border-b-0 transition-colors ${
                        table.status === 'missing' ? 'bg-red-500/5' :
                        table.status === 'exists' ? 'bg-emerald-500/5' :
                        table.status === 'error' ? 'bg-amber-500/5' : ''
                      }`}
                    >
                      <div className="flex-shrink-0">
                        {table.status === 'idle' && <div className="w-5 h-5 rounded-full border-2 border-gray-700" />}
                        {table.status === 'checking' && <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />}
                        {table.status === 'exists' && <CheckCircle className="w-5 h-5 text-emerald-400" />}
                        {table.status === 'missing' && <XCircle className="w-5 h-5 text-red-400" />}
                        {table.status === 'error' && <AlertTriangle className="w-5 h-5 text-amber-400" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-white font-mono text-sm">{table.name}</span>
                          {table.isCritical && (
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-amber-500/30 text-amber-400">
                              critique
                            </Badge>
                          )}
                        </div>
                        <p className="text-gray-500 text-xs">{table.description}</p>
                      </div>
                      <div className="flex-shrink-0 text-right">
                        {table.status === 'exists' && (
                          <span className="text-emerald-400 text-xs">
                            {table.rowCount !== undefined ? `${table.rowCount} ligne${table.rowCount !== 1 ? 's' : ''}` : 'OK'}
                          </span>
                        )}
                        {table.status === 'missing' && <span className="text-red-400 text-xs font-medium">Manquante</span>}
                        {table.status === 'error' && <span className="text-amber-400 text-xs" title={table.errorMessage}>Erreur</span>}
                        {table.status === 'checking' && <span className="text-blue-400 text-xs">Vérification...</span>}
                        {table.status === 'idle' && <span className="text-gray-600 text-xs">En attente</span>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {/* ================================================================ */}
      {/* MANUAL SQL FALLBACK — Show SQL */}
      {/* ================================================================ */}
      {hasChecked && missingCount > 0 && !showAutoFixPanel && (
        <Card className="border-gray-800 bg-gray-900/60 backdrop-blur-xl">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gray-600 to-gray-700 flex items-center justify-center shadow-lg">
                <FileCode className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-base">Méthode manuelle (alternative)</CardTitle>
                <CardDescription className="text-gray-400 text-sm">
                  Si l'auto-fix ne fonctionne pas, copiez le SQL et exécutez-le manuellement
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Toggle: missing only vs full script */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowFullScript(false)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  !showFullScript
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    : 'text-gray-500 hover:text-gray-400'
                }`}
              >
                <ClipboardCheck className="w-3.5 h-3.5" />
                Tables manquantes ({missingCount})
              </button>
              <button
                onClick={() => setShowFullScript(true)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  showFullScript
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    : 'text-gray-500 hover:text-gray-400'
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                Script complet ({totalCount})
              </button>
            </div>

            {/* SQL Preview */}
            <div className="relative">
              <div className="flex items-center justify-between mb-2">
                <button
                  onClick={() => setShowSQL(!showSQL)}
                  className="flex items-center gap-1.5 text-gray-400 hover:text-gray-300 text-xs transition-colors"
                >
                  {showSQL ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  {showSQL ? 'Masquer le SQL' : 'Voir le SQL'}
                </button>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleDownloadSQL}
                    className="border-gray-700 text-gray-400 hover:text-white hover:bg-gray-800 text-xs h-7"
                  >
                    <Download className="w-3.5 h-3.5 mr-1" />
                    .sql
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleCopySQL}
                    className={`text-xs h-7 ${
                      copied
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-purple-600 hover:bg-purple-700 text-white'
                    }`}
                  >
                    {copied ? (
                      <><CheckCircle className="w-3.5 h-3.5 mr-1" /> Copié !</>
                    ) : (
                      <><Copy className="w-3.5 h-3.5 mr-1" /> Copier le SQL</>
                    )}
                  </Button>
                </div>
              </div>

              {showSQL && (
                <textarea
                  ref={sqlRef}
                  readOnly
                  value={generateMissingSQL()}
                  className="w-full h-80 bg-gray-950 border border-gray-800 rounded-xl p-4 text-xs font-mono text-gray-300 resize-y focus:outline-none focus:border-purple-500/50 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent"
                  spellCheck={false}
                />
              )}

              {!showSQL && (
                <div className="bg-gray-950 border border-gray-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-gray-500 text-xs">
                    <FileCode className="w-4 h-4" />
                    <span>
                      {showFullScript
                        ? `Script complet — ${totalCount} tables`
                        : `${missingCount} table${missingCount > 1 ? 's' : ''} à créer`
                      }
                    </span>
                  </div>
                  <div className="mt-2 text-gray-600 text-xs font-mono line-clamp-3">
                    {generateMissingSQL().substring(0, 200)}...
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                onClick={handleCopySQL}
                variant="outline"
                className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
              >
                {copied ? (
                  <><CheckCircle className="w-4 h-4 mr-2" /> SQL copié !</>
                ) : (
                  <><Copy className="w-4 h-4 mr-2" /> Copier le SQL</>
                )}
              </Button>
              <Button
                variant="outline"
                className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                onClick={() => window.open(getSQLEditorUrl(), '_blank')}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Ouvrir le SQL Editor
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ================================================================ */}
      {/* SUCCESS — All tables exist */}
      {/* ================================================================ */}
      {hasChecked && allExist && !showAutoFixPanel && (
        <Card className="border-emerald-500/30 bg-gray-900/80 backdrop-blur-xl">
          <CardContent className="py-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
                <CheckCircle className="w-6 h-6 text-emerald-400" />
              </div>
              <div className="flex-1">
                <p className="text-emerald-300 font-semibold">Base de données prête</p>
                <p className="text-gray-400 text-sm">
                  Les {totalCount} tables sont créées et accessibles. Vous pouvez utiliser l'application normalement.
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                onClick={() => {
                  setShowFullScript(true);
                  setShowSQL(true);
                }}
              >
                <Eye className="w-4 h-4 mr-1" />
                Voir le SQL
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default DatabaseSetupWizard;
