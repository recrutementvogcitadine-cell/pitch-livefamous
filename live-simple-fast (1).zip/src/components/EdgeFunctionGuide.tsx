import React, { useState, useCallback } from 'react';
import { supabase, getEdgeFunctionsUrl, getProjectRef } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Server, CheckCircle, Loader2, AlertTriangle, Copy, ExternalLink,
  Terminal, Shield, Zap, ChevronDown, ChevronUp, ArrowRight,
  Info, Key, Globe, Database, Rocket, Check, X,
  Radio, Bell, CreditCard, Mail, Play,
  RefreshCw, FileCode, DownloadCloud,
} from 'lucide-react';


// ============================================================================
// TYPES
// ============================================================================

type FunctionStatus = 'unknown' | 'checking' | 'deployed' | 'not-deployed' | 'error';

interface HealthCheckResult {
  deployed: boolean;
  checks: Record<string, boolean>;
  all_good: boolean;
  message: string;
  timestamp: string;
}

interface FunctionState {
  status: FunctionStatus;
  healthResult: HealthCheckResult | null;
  error: string | null;
  lastChecked: Date | null;
}

interface EdgeFunctionDef {
  id: string;
  name: string;
  description: string;
  deployCommand: string;
  icon: React.ElementType;
  iconColor: string;
  gradientFrom: string;
  gradientTo: string;
  purpose: string;
  requiredSecrets: string[];
}

interface EdgeFunctionGuideProps {
  onContinue?: () => void;
  showContinue?: boolean;
  continueLabel?: string;
  compact?: boolean;
}

// ============================================================================
// EDGE FUNCTIONS REGISTRY
// ============================================================================

const EDGE_FUNCTIONS: EdgeFunctionDef[] = [
  {
    id: 'generate-agora-token',
    name: 'generate-agora-token',
    description: 'Génération de tokens Agora RTC pour le streaming en direct.',
    deployCommand: 'supabase functions deploy generate-agora-token',
    icon: Zap,
    iconColor: 'text-cyan-400',
    gradientFrom: 'from-cyan-500',
    gradientTo: 'to-blue-500',
    purpose: 'Génère des tokens Agora RTC signés pour les rôles publisher (créateur) et subscriber (spectateur). Valide le JWT utilisateur, vérifie le profil créateur pour les publishers, et applique des limites d\'expiration configurables.',
    requiredSecrets: ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'AGORA_APP_ID', 'AGORA_APP_CERTIFICATE'],
  },
  {
    id: 'manage-live',
    name: 'manage-live',
    description: 'Gestion du cycle de vie des lives : démarrage, arrêt, mise à jour.',
    deployCommand: 'supabase functions deploy manage-live',
    icon: Radio,
    iconColor: 'text-red-400',
    gradientFrom: 'from-red-500',
    gradientTo: 'to-orange-500',
    purpose: 'Gère le cycle de vie complet des sessions de live : création du stream avec token Agora, vérification de l\'abonnement actif, arrêt avec calcul de durée et mise à jour des stats créateur, mise à jour des métadonnées en temps réel, et consultation des infos stream.',
    requiredSecrets: ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'AGORA_APP_ID', 'AGORA_APP_CERTIFICATE'],
  },
  {
    id: 'manage-subscription',
    name: 'manage-subscription',
    description: 'Gestion des abonnements créateurs : création, annulation, vérification.',
    deployCommand: 'supabase functions deploy manage-subscription',
    icon: Key,
    iconColor: 'text-violet-400',
    gradientFrom: 'from-violet-500',
    gradientTo: 'to-purple-500',
    purpose: 'Gère le cycle de vie des abonnements créateurs : création/mise à jour d\'abonnement avec vérification du plan, annulation, vérification du statut avec auto-expiration, et listing des plans disponibles. Toutes les opérations utilisent la clé service_role pour contourner le RLS.',
    requiredSecrets: ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'],
  },
  {
    id: 'process-payment',
    name: 'process-payment',
    description: 'Traitement sécurisé des paiements Mobile Money et gestion admin.',
    deployCommand: 'supabase functions deploy process-payment',
    icon: CreditCard,
    iconColor: 'text-emerald-400',
    gradientFrom: 'from-emerald-500',
    gradientTo: 'to-teal-500',
    purpose: 'Gère le traitement complet des paiements : initiation via Orange Money / MTN / Wave, confirmation, vérification de statut, historique. Inclut des actions admin pour lister tous les paiements et mettre à jour les statuts avec activation/désactivation automatique des abonnements.',
    requiredSecrets: ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'],
  },
  {
    id: 'confirm-user-email',
    name: 'confirm-user-email',
    description: 'Confirmation manuelle des emails utilisateurs lorsque le service SMTP échoue.',
    deployCommand: 'supabase functions deploy confirm-user-email',
    icon: Mail,
    iconColor: 'text-blue-400',
    gradientFrom: 'from-blue-500',
    gradientTo: 'to-cyan-500',
    purpose: 'Permet de confirmer manuellement les adresses email via l\'API Admin quand le service d\'email intégré de Supabase échoue (limite de débit, erreurs SMTP).',
    requiredSecrets: ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY'],
  },
  {
    id: 'stream-manager',
    name: 'stream-manager',
    description: 'Gestionnaire de streams legacy (compatibilité arrière).',
    deployCommand: 'supabase functions deploy stream-manager',
    icon: Play,
    iconColor: 'text-orange-400',
    gradientFrom: 'from-orange-500',
    gradientTo: 'to-red-500',
    purpose: 'Gestionnaire de streams legacy utilisé par certains composants. Gère start_stream, end_stream, join_stream, get_streams, check_subscription et save_recording. Remplacé progressivement par manage-live.',
    requiredSecrets: ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'],
  },
  {
    id: 'push-notifications',
    name: 'push-notifications',
    description: 'Envoi de notifications push aux abonnés et followers.',
    deployCommand: 'supabase functions deploy push-notifications',
    icon: Bell,
    iconColor: 'text-amber-400',
    gradientFrom: 'from-amber-500',
    gradientTo: 'to-yellow-500',
    purpose: 'Envoie des notifications push aux utilisateurs abonnés lorsqu\'un créateur démarre un live, publie du contenu, ou lors d\'événements importants de la plateforme.',
    requiredSecrets: ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'VAPID_PRIVATE_KEY'],
  },
];


// ============================================================================
// COMPONENT
// ============================================================================

const EdgeFunctionGuide: React.FC<EdgeFunctionGuideProps> = ({
  onContinue,
  showContinue = true,
  continueLabel = 'Continuer vers le tableau de bord',
}) => {
  const projectRef = getProjectRef();
  const edgeFunctionsUrl = getEdgeFunctionsUrl();

  // Per-function state
  const [functionStates, setFunctionStates] = useState<Record<string, FunctionState>>(() => {
    const initial: Record<string, FunctionState> = {};
    EDGE_FUNCTIONS.forEach((fn) => {
      initial[fn.id] = { status: 'unknown', healthResult: null, error: null, lastChecked: null };
    });
    return initial;
  });

  // UI state
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showOptionalSteps, setShowOptionalSteps] = useState(false);
  const [showTroubleshooting, setShowTroubleshooting] = useState(false);
  const [expandedFunctions, setExpandedFunctions] = useState<Record<string, boolean>>({});
  const [isCheckingAll, setIsCheckingAll] = useState(false);
  const [showDeployScript, setShowDeployScript] = useState(false);

  // ============================================================================
  // HELPERS
  // ============================================================================

  const handleCopy = useCallback((text: string, id: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    }).catch(() => {
      const input = document.createElement('input');
      input.value = text;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  }, []);

  const toggleExpanded = (fnId: string) => {
    setExpandedFunctions((prev) => ({ ...prev, [fnId]: !prev[fnId] }));
  };

  // ============================================================================
  // HEALTH CHECK — SINGLE FUNCTION
  // ============================================================================

  const checkFunction = useCallback(async (fnDef: EdgeFunctionDef): Promise<FunctionState> => {
    try {
      const { data, error } = await supabase.functions.invoke(fnDef.id, {
        body: { action: 'health-check' },
      });

      if (error) {
        const errObj = error as any;
        const errMsg = (errObj?.message || errObj?.error || '').toLowerCase();

        if (
          errMsg.includes('not found') ||
          errMsg.includes('404') ||
          errMsg.includes('relay error') ||
          errMsg.includes('function not found')
        ) {
          return {
            status: 'not-deployed',
            healthResult: null,
            error: `La fonction '${fnDef.name}' n'est pas déployée.`,
            lastChecked: new Date(),
          };
        }

        if (errMsg.includes('boot') || errMsg.includes('500')) {
          return {
            status: 'error',
            healthResult: null,
            error: `La fonction a été trouvée mais n'a pas pu démarrer (erreur de boot). Vérifiez les logs.`,
            lastChecked: new Date(),
          };
        }

        return {
          status: 'error',
          healthResult: null,
          error: `Erreur : ${errObj?.message || 'Erreur inconnue'}`,
          lastChecked: new Date(),
        };
      }

      if (data?.action === 'health-check' && data?.deployed) {
        return {
          status: 'deployed',
          healthResult: data as HealthCheckResult,
          error: null,
          lastChecked: new Date(),
        };
      }

      // Function responded but no health-check handler — still means it's deployed
      return {
        status: 'deployed',
        healthResult: {
          deployed: true,
          checks: {},
          all_good: true,
          message: 'La fonction est accessible (pas de endpoint health-check dédié).',
          timestamp: new Date().toISOString(),
        },
        error: null,
        lastChecked: new Date(),
      };
    } catch (err: any) {
      const errMsg = (err?.message || '').toLowerCase();
      if (errMsg.includes('not found') || errMsg.includes('404')) {
        return {
          status: 'not-deployed',
          healthResult: null,
          error: `La fonction '${fnDef.name}' n'est pas déployée.`,
          lastChecked: new Date(),
        };
      }
      return {
        status: 'error',
        healthResult: null,
        error: `Erreur réseau : ${err?.message || 'Veuillez réessayer.'}`,
        lastChecked: new Date(),
      };
    }
  }, []);

  const handleCheckSingle = useCallback(async (fnDef: EdgeFunctionDef) => {
    setFunctionStates((prev) => ({
      ...prev,
      [fnDef.id]: { ...prev[fnDef.id], status: 'checking', error: null },
    }));

    const result = await checkFunction(fnDef);

    setFunctionStates((prev) => ({
      ...prev,
      [fnDef.id]: result,
    }));
  }, [checkFunction]);

  // ============================================================================
  // HEALTH CHECK — ALL FUNCTIONS
  // ============================================================================

  const handleCheckAll = useCallback(async () => {
    setIsCheckingAll(true);

    // Set all to checking
    setFunctionStates((prev) => {
      const next = { ...prev };
      EDGE_FUNCTIONS.forEach((fn) => {
        next[fn.id] = { ...next[fn.id], status: 'checking', error: null };
      });
      return next;
    });

    // Check all in parallel
    const results = await Promise.all(
      EDGE_FUNCTIONS.map(async (fn) => {
        const result = await checkFunction(fn);
        // Update immediately as each completes
        setFunctionStates((prev) => ({ ...prev, [fn.id]: result }));
        return { id: fn.id, result };
      })
    );

    setIsCheckingAll(false);
  }, [checkFunction]);

  // ============================================================================
  // DEPLOY ALL SCRIPT GENERATOR
  // ============================================================================

  const generateDeployAllScript = useCallback(() => {
    const lines = [
      '#!/bin/bash',
      '# Deploy all Famous.ai Edge Functions',
      `# Generated on ${new Date().toLocaleString('fr-FR')}`,
      '',
      '# Make sure you are logged in and linked:',
      '# supabase login',
      projectRef
        ? `# supabase link --project-ref ${projectRef}`
        : '# supabase link --project-ref <YOUR_PROJECT_REF>',
      '',
      'echo "Deploying all Edge Functions..."',
      '',
      ...EDGE_FUNCTIONS.map((fn) => [
        `echo "Deploying ${fn.name}..."`,
        fn.deployCommand,
        `echo "${fn.name} deployed successfully!"`,
        '',
      ]).flat(),
      'echo ""',
      'echo "All Edge Functions deployed successfully!"',
    ];
    return lines.join('\n');
  }, [projectRef]);

  const deployAllOneLiner = EDGE_FUNCTIONS.map((fn) => fn.deployCommand).join(' && ');

  // ============================================================================
  // STATUS HELPERS
  // ============================================================================

  const getStatusBadge = (status: FunctionStatus) => {
    switch (status) {
      case 'deployed':
        return (
          <Badge className="bg-green-500/10 text-green-400 border-green-500/30 text-[10px] gap-1">
            <CheckCircle className="w-3 h-3" />
            Déployée
          </Badge>
        );
      case 'not-deployed':
        return (
          <Badge className="bg-red-500/10 text-red-400 border-red-500/30 text-[10px] gap-1">
            <X className="w-3 h-3" />
            Non déployée
          </Badge>
        );
      case 'checking':
        return (
          <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/30 text-[10px] gap-1">
            <Loader2 className="w-3 h-3 animate-spin" />
            Vérification...
          </Badge>
        );
      case 'error':
        return (
          <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/30 text-[10px] gap-1">
            <AlertTriangle className="w-3 h-3" />
            Erreur
          </Badge>
        );
      default:
        return (
          <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/30 text-[10px] gap-1">
            <Server className="w-3 h-3" />
            Non vérifiée
          </Badge>
        );
    }
  };

  const deployedCount = Object.values(functionStates).filter((s) => s.status === 'deployed').length;
  const notDeployedCount = Object.values(functionStates).filter((s) => s.status === 'not-deployed').length;
  const checkedCount = Object.values(functionStates).filter((s) => s.status !== 'unknown' && s.status !== 'checking').length;
  const allChecked = checkedCount === EDGE_FUNCTIONS.length;
  const allDeployed = deployedCount === EDGE_FUNCTIONS.length;

  // ============================================================================
  // RENDER CHECK ITEM
  // ============================================================================

  const renderCheckItem = (label: string, passed: boolean, detail?: string) => (
    <div className="flex items-center gap-3 py-1.5">
      <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
        passed ? 'bg-green-500/20' : 'bg-red-500/20'
      }`}>
        {passed ? (
          <Check className="w-3 h-3 text-green-400" />
        ) : (
          <X className="w-3 h-3 text-red-400" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <span className={`text-xs font-medium ${passed ? 'text-green-300' : 'text-red-300'}`}>
          {label}
        </span>
        {detail && (
          <p className="text-gray-500 text-[10px] mt-0.5">{detail}</p>
        )}
      </div>
      <Badge className={`text-[9px] ${
        passed
          ? 'bg-green-500/10 text-green-400 border-green-500/30'
          : 'bg-red-500/10 text-red-400 border-red-500/30'
      }`}>
        {passed ? 'OK' : 'FAIL'}
      </Badge>
    </div>
  );

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="space-y-4">
      {/* ==================== MAIN CARD ==================== */}
      <Card className="border-purple-500/20 bg-gray-900/80 backdrop-blur-xl shadow-2xl shadow-purple-500/5">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center mb-3 shadow-lg shadow-purple-500/20">
            <Rocket className="w-7 h-7 text-white" />
          </div>
          <CardTitle className="text-white text-xl">Déployer les Edge Functions</CardTitle>
          <CardDescription className="text-gray-400">
            Déployez toutes les fonctions serveur nécessaires au fonctionnement de la plateforme.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-5">
          {/* ==================== OVERVIEW STATS ==================== */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="bg-gray-800/50 rounded-xl p-3 text-center border border-gray-700/30">
              <p className="text-2xl font-bold text-white">{EDGE_FUNCTIONS.length}</p>
              <p className="text-gray-400 text-[10px] mt-0.5">Fonctions totales</p>
            </div>
            <div className="bg-gray-800/50 rounded-xl p-3 text-center border border-gray-700/30">
              <p className={`text-2xl font-bold ${deployedCount > 0 ? 'text-green-400' : 'text-gray-500'}`}>
                {deployedCount}
              </p>
              <p className="text-gray-400 text-[10px] mt-0.5">Déployées</p>
            </div>
            <div className="bg-gray-800/50 rounded-xl p-3 text-center border border-gray-700/30">
              <p className={`text-2xl font-bold ${notDeployedCount > 0 ? 'text-red-400' : 'text-gray-500'}`}>
                {notDeployedCount}
              </p>
              <p className="text-gray-400 text-[10px] mt-0.5">Manquantes</p>
            </div>
            <div className="bg-gray-800/50 rounded-xl p-3 text-center border border-gray-700/30">
              <p className={`text-2xl font-bold ${allChecked ? (allDeployed ? 'text-green-400' : 'text-amber-400') : 'text-gray-500'}`}>
                {allChecked ? (allDeployed ? '100%' : `${Math.round((deployedCount / EDGE_FUNCTIONS.length) * 100)}%`) : '—'}
              </p>
              <p className="text-gray-400 text-[10px] mt-0.5">Couverture</p>
            </div>
          </div>

          {/* ==================== CHECK ALL BUTTON ==================== */}
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              onClick={handleCheckAll}
              disabled={isCheckingAll}
              className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-semibold shadow-lg shadow-emerald-500/20 disabled:from-gray-700 disabled:to-gray-700 disabled:shadow-none"
            >
              {isCheckingAll ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Vérification de toutes les fonctions...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4" />
                  {allChecked ? 'Revérifier toutes les fonctions' : 'Vérifier toutes les fonctions'}
                </div>
              )}
            </Button>
          </div>

          {/* All deployed success banner */}
          {allDeployed && allChecked && (
            <Alert className="border-green-500/20 bg-green-500/5">
              <CheckCircle className="h-4 w-4 text-green-400" />
              <AlertDescription className="text-green-300 text-sm">
                Toutes les Edge Functions sont déployées et opérationnelles !
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* ==================== INDIVIDUAL FUNCTIONS ==================== */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 px-1">
          <Server className="w-4 h-4 text-purple-400" />
          <h3 className="text-white font-semibold text-sm">Fonctions Edge ({EDGE_FUNCTIONS.length})</h3>
        </div>

        {EDGE_FUNCTIONS.map((fn) => {
          const state = functionStates[fn.id];
          const isExpanded = expandedFunctions[fn.id] || false;
          const FnIcon = fn.icon;

          return (
            <Card
              key={fn.id}
              className={`border transition-all ${
                state.status === 'deployed'
                  ? 'border-green-500/20 bg-gray-900/80'
                  : state.status === 'not-deployed'
                    ? 'border-red-500/20 bg-gray-900/80'
                    : state.status === 'error'
                      ? 'border-amber-500/20 bg-gray-900/80'
                      : 'border-gray-700/40 bg-gray-900/80'
              } backdrop-blur-xl`}
            >
              <CardContent className="p-0">
                {/* Function Header — always visible */}
                <button
                  onClick={() => toggleExpanded(fn.id)}
                  className="w-full flex items-center gap-3 p-4 text-left hover:bg-gray-800/30 transition-colors rounded-t-xl"
                >
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${fn.gradientFrom} ${fn.gradientTo} flex items-center justify-center flex-shrink-0 shadow-lg`}>
                    <FnIcon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <code className="text-white font-mono text-sm font-semibold">{fn.name}</code>
                      {getStatusBadge(state.status)}
                    </div>
                    <p className="text-gray-400 text-xs mt-0.5 truncate">{fn.description}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {/* Quick test button (doesn't expand) */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCheckSingle(fn);
                      }}
                      disabled={state.status === 'checking'}
                      className={`p-2 rounded-lg transition-colors ${
                        state.status === 'checking'
                          ? 'bg-gray-700/50 text-gray-500 cursor-not-allowed'
                          : 'bg-gray-700/50 hover:bg-gray-700 text-gray-300 hover:text-white'
                      }`}
                      title="Tester cette fonction"
                    >
                      {state.status === 'checking' ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Play className="w-4 h-4" />
                      )}
                    </button>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-gray-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-500" />
                    )}
                  </div>
                </button>

                {/* Expanded Content */}
                {isExpanded && (
                  <div className="px-4 pb-4 space-y-4 border-t border-gray-800/50">
                    {/* Purpose */}
                    <div className="bg-gray-800/30 rounded-lg p-3 mt-3">
                      <p className="text-gray-300 text-xs leading-relaxed">
                        <Info className="w-3.5 h-3.5 inline mr-1.5 text-blue-400" />
                        {fn.purpose}
                      </p>
                    </div>

                    {/* Deploy Command */}
                    <div className="space-y-2">
                      <p className="text-gray-300 text-xs font-medium flex items-center gap-1.5">
                        <Terminal className="w-3.5 h-3.5 text-purple-400" />
                        Commande de déploiement
                      </p>
                      <div className="relative group">
                        <div className="bg-gray-950/80 rounded-lg px-3 py-2.5 font-mono text-xs text-green-300 flex items-center gap-2 overflow-x-auto">
                          <span className="text-gray-600 select-none flex-shrink-0">$</span>
                          <code className="whitespace-nowrap flex-1">{fn.deployCommand}</code>
                          <button
                            onClick={() => handleCopy(fn.deployCommand, `deploy-${fn.id}`)}
                            className="flex-shrink-0 p-1.5 rounded-md bg-gray-800/80 hover:bg-gray-700 text-gray-400 hover:text-white transition-all opacity-60 group-hover:opacity-100"
                            title="Copier"
                          >
                            {copiedId === `deploy-${fn.id}` ? (
                              <Check className="w-3.5 h-3.5 text-green-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Required Secrets */}
                    <div className="space-y-1.5">
                      <p className="text-gray-300 text-xs font-medium flex items-center gap-1.5">
                        <Key className="w-3.5 h-3.5 text-amber-400" />
                        Variables d'environnement requises
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {fn.requiredSecrets.map((secret) => (
                          <Badge
                            key={secret}
                            className="bg-gray-800/60 text-gray-300 border-gray-600/40 text-[10px] font-mono"
                          >
                            {secret}
                          </Badge>
                        ))}
                      </div>
                      <p className="text-gray-500 text-[10px]">
                        Ces variables sont automatiquement disponibles dans les Edge Functions Supabase.
                      </p>
                    </div>

                    {/* Health Check Results */}
                    {state.error && (
                      <Alert className="border-red-500/30 bg-red-500/10">
                        <AlertTriangle className="h-4 w-4 text-red-400" />
                        <AlertDescription className="text-red-300 text-xs leading-relaxed">
                          {state.error}
                        </AlertDescription>
                      </Alert>
                    )}

                    {state.healthResult && (
                      <div className={`rounded-xl border p-3 space-y-2 ${
                        state.healthResult.all_good
                          ? 'border-green-500/30 bg-green-500/5'
                          : 'border-amber-500/30 bg-amber-500/5'
                      }`}>
                        <div className="flex items-center gap-2">
                          {state.healthResult.all_good ? (
                            <CheckCircle className="w-4 h-4 text-green-400" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-400" />
                          )}
                          <p className={`font-medium text-xs ${
                            state.healthResult.all_good ? 'text-green-300' : 'text-amber-300'
                          }`}>
                            {state.healthResult.all_good
                              ? 'Tous les checks passent !'
                              : 'Vérifications partielles'}
                          </p>
                        </div>

                        {Object.keys(state.healthResult.checks).length > 0 && (
                          <div className="divide-y divide-gray-700/20">
                            {renderCheckItem(
                              'Fonction déployée',
                              state.healthResult.deployed,
                            )}
                            {state.healthResult.checks.supabase_url !== undefined &&
                              renderCheckItem('SUPABASE_URL', state.healthResult.checks.supabase_url)}
                            {state.healthResult.checks.anon_key !== undefined &&
                              renderCheckItem('SUPABASE_ANON_KEY', state.healthResult.checks.anon_key)}
                            {state.healthResult.checks.service_role_key !== undefined &&
                              renderCheckItem('SUPABASE_SERVICE_ROLE_KEY', state.healthResult.checks.service_role_key)}
                            {state.healthResult.checks.admin_api !== undefined &&
                              renderCheckItem('API Admin', state.healthResult.checks.admin_api)}
                          </div>
                        )}

                        {state.lastChecked && (
                          <p className="text-gray-500 text-[10px] text-right">
                            Testé à {state.lastChecked.toLocaleTimeString('fr-FR')}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Test Button */}
                    <Button
                      onClick={() => handleCheckSingle(fn)}
                      disabled={state.status === 'checking'}
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                      size="sm"
                    >
                      {state.status === 'checking' ? (
                        <div className="flex items-center gap-2">
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          Test en cours...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Zap className="w-3.5 h-3.5" />
                          {state.lastChecked ? 'Retester' : 'Tester'} {fn.name}
                        </div>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* ==================== DEPLOY ALL SECTION ==================== */}
      <Card className="border-indigo-500/20 bg-gray-900/80 backdrop-blur-xl">
        <CardContent className="p-4 space-y-4">
          <div className="flex items-center gap-2">
            <DownloadCloud className="w-4 h-4 text-indigo-400" />
            <h4 className="text-white font-semibold text-sm">Déployer toutes les fonctions</h4>
          </div>

          <p className="text-gray-400 text-xs leading-relaxed">
            Utilisez la commande ci-dessous pour déployer toutes les Edge Functions en une seule fois.
          </p>

          {/* Pre-requisites */}
          <div className="space-y-2">
            <button
              onClick={() => setShowOptionalSteps(!showOptionalSteps)}
              className="inline-flex items-center gap-2 text-gray-400 hover:text-gray-300 text-xs font-medium transition-colors"
            >
              {showOptionalSteps ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              Pré-requis (installation CLI, login, link)
            </button>

            {showOptionalSteps && (
              <div className="space-y-2">
                {/* Install CLI */}
                <div className="rounded-lg border border-gray-700/30 bg-gray-800/30 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-5 h-5 rounded-full bg-gray-600/30 flex items-center justify-center">
                      <span className="text-[10px] font-bold text-gray-400">1</span>
                    </div>
                    <span className="text-xs text-gray-300 font-medium">Installer le CLI Supabase</span>
                    <Badge className="bg-gray-700/50 text-gray-500 border-gray-600/30 text-[9px] ml-auto">Optionnel</Badge>
                  </div>
                  <div className="relative group">
                    <div className="bg-gray-950/80 rounded-lg px-3 py-2 font-mono text-xs text-green-300 flex items-center gap-2">
                      <span className="text-gray-600 select-none">$</span>
                      <code className="flex-1">npm install -g supabase</code>
                      <button
                        onClick={() => handleCopy('npm install -g supabase', 'prereq-install')}
                        className="flex-shrink-0 p-1 rounded bg-gray-800/80 hover:bg-gray-700 text-gray-400 hover:text-white transition-all opacity-60 group-hover:opacity-100"
                      >
                        {copiedId === 'prereq-install' ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Login */}
                <div className="rounded-lg border border-gray-700/30 bg-gray-800/30 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-5 h-5 rounded-full bg-gray-600/30 flex items-center justify-center">
                      <span className="text-[10px] font-bold text-gray-400">2</span>
                    </div>
                    <span className="text-xs text-gray-300 font-medium">Se connecter au CLI</span>
                    <Badge className="bg-gray-700/50 text-gray-500 border-gray-600/30 text-[9px] ml-auto">Optionnel</Badge>
                  </div>
                  <div className="relative group">
                    <div className="bg-gray-950/80 rounded-lg px-3 py-2 font-mono text-xs text-green-300 flex items-center gap-2">
                      <span className="text-gray-600 select-none">$</span>
                      <code className="flex-1">supabase login</code>
                      <button
                        onClick={() => handleCopy('supabase login', 'prereq-login')}
                        className="flex-shrink-0 p-1 rounded bg-gray-800/80 hover:bg-gray-700 text-gray-400 hover:text-white transition-all opacity-60 group-hover:opacity-100"
                      >
                        {copiedId === 'prereq-login' ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Link */}
                <div className="rounded-lg border border-indigo-500/20 bg-indigo-500/5 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-5 h-5 rounded-full bg-indigo-500/20 flex items-center justify-center">
                      <span className="text-[10px] font-bold text-indigo-400">3</span>
                    </div>
                    <span className="text-xs text-indigo-300 font-medium">Lier votre projet</span>
                    <Badge className="bg-indigo-500/10 text-indigo-400 border-indigo-500/30 text-[9px] ml-auto gap-1">
                      <Zap className="w-2.5 h-2.5" />
                      Requis
                    </Badge>
                  </div>
                  <div className="relative group">
                    <div className="bg-gray-950/80 rounded-lg px-3 py-2 font-mono text-xs text-green-300 flex items-center gap-2">
                      <span className="text-gray-600 select-none">$</span>
                      <code className="flex-1">
                        {projectRef
                          ? `supabase link --project-ref ${projectRef}`
                          : 'supabase link --project-ref <VOTRE_PROJECT_REF>'}
                      </code>
                      <button
                        onClick={() => handleCopy(
                          projectRef
                            ? `supabase link --project-ref ${projectRef}`
                            : 'supabase link --project-ref <VOTRE_PROJECT_REF>',
                          'prereq-link'
                        )}
                        className="flex-shrink-0 p-1 rounded bg-gray-800/80 hover:bg-gray-700 text-gray-400 hover:text-white transition-all opacity-60 group-hover:opacity-100"
                      >
                        {copiedId === 'prereq-link' ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>
                  {projectRef ? (
                    <p className="text-green-400/80 text-[10px] mt-1.5 flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Project ref détecté : <code className="bg-green-500/10 px-1 py-0.5 rounded text-green-300 font-mono">{projectRef}</code>
                    </p>
                  ) : (
                    <p className="text-amber-400/80 text-[10px] mt-1.5 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      Remplacez <code className="font-mono">&lt;VOTRE_PROJECT_REF&gt;</code> par votre identifiant
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* One-liner deploy all */}
          <div className="space-y-2">
            <p className="text-gray-300 text-xs font-medium flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-indigo-400" />
              Commande unique (déploie tout)
            </p>
            <div className="relative group">
              <div className="bg-gray-950/80 rounded-xl px-3 py-3 font-mono text-[11px] text-green-300 overflow-x-auto border border-indigo-500/20">
                <div className="flex items-start gap-2">
                  <span className="text-gray-600 select-none flex-shrink-0 mt-0.5">$</span>
                  <code className="flex-1 break-all leading-relaxed">{deployAllOneLiner}</code>
                  <button
                    onClick={() => handleCopy(deployAllOneLiner, 'deploy-all-oneliner')}
                    className="flex-shrink-0 p-1.5 rounded-md bg-gray-800/80 hover:bg-gray-700 text-gray-400 hover:text-white transition-all opacity-60 group-hover:opacity-100 mt-0.5"
                    title="Copier"
                  >
                    {copiedId === 'deploy-all-oneliner' ? (
                      <Check className="w-3.5 h-3.5 text-green-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Full bash script */}
          <div className="space-y-2">
            <button
              onClick={() => setShowDeployScript(!showDeployScript)}
              className="inline-flex items-center gap-2 text-gray-400 hover:text-gray-300 text-xs font-medium transition-colors"
            >
              {showDeployScript ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              <FileCode className="w-3.5 h-3.5" />
              Script complet (bash)
            </button>

            {showDeployScript && (
              <div className="relative group">
                <div className="bg-gray-950/80 rounded-xl p-4 font-mono text-[11px] text-green-300/80 overflow-x-auto border border-gray-700/30 max-h-64 overflow-y-auto">
                  <pre className="whitespace-pre leading-relaxed">{generateDeployAllScript()}</pre>
                </div>
                <button
                  onClick={() => handleCopy(generateDeployAllScript(), 'deploy-all-script')}
                  className="absolute top-2 right-2 p-2 rounded-lg bg-gray-800/90 hover:bg-gray-700 text-gray-400 hover:text-white transition-all opacity-60 group-hover:opacity-100"
                  title="Copier le script"
                >
                  {copiedId === 'deploy-all-script' ? (
                    <Check className="w-4 h-4 text-green-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ==================== DASHBOARD LINK ==================== */}
      <Card className="border-gray-700/40 bg-gray-900/80 backdrop-blur-xl">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-indigo-400" />
            <h4 className="text-white font-medium text-sm">Dashboard Supabase</h4>
          </div>
          <p className="text-gray-400 text-xs leading-relaxed">
            Gérez vos Edge Functions, consultez les logs et les métriques directement depuis le Dashboard.
          </p>

          <div className="flex flex-col sm:flex-row gap-2">
            <a
              href={edgeFunctionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 text-sm font-medium transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              Ouvrir Edge Functions
            </a>
            <button
              onClick={() => handleCopy(edgeFunctionsUrl, 'dashboard-url')}
              className="inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 text-gray-300 text-sm transition-colors"
              title="Copier le lien"
            >
              {copiedId === 'dashboard-url' ? (
                <Check className="w-4 h-4 text-green-400" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
              Copier le lien
            </button>
          </div>

          {projectRef && (
            <div className="bg-gray-800/50 rounded-lg p-2.5 flex items-center gap-2 overflow-hidden">
              <Database className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
              <code className="text-gray-400 text-[10px] font-mono truncate">{edgeFunctionsUrl}</code>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ==================== SERVICE ROLE KEY INFO ==================== */}
      <Card className="border-amber-500/15 bg-gray-900/80 backdrop-blur-xl">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center flex-shrink-0">
              <Key className="w-4 h-4 text-amber-400" />
            </div>
            <div className="flex-1 min-w-0">
              <h5 className="text-amber-300 font-medium text-sm mb-1">Variables d'environnement automatiques</h5>
              <p className="text-amber-300/70 text-xs leading-relaxed">
                Les variables <code className="bg-amber-500/10 px-1 py-0.5 rounded text-amber-300">SUPABASE_URL</code>, <code className="bg-amber-500/10 px-1 py-0.5 rounded text-amber-300">SUPABASE_ANON_KEY</code> et <code className="bg-amber-500/10 px-1 py-0.5 rounded text-amber-300">SUPABASE_SERVICE_ROLE_KEY</code> sont <span className="font-semibold text-amber-300">automatiquement disponibles</span> dans toutes les Edge Functions de votre projet. Aucune configuration manuelle n'est nécessaire.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ==================== TROUBLESHOOTING ==================== */}
      <Card className="border-gray-700/40 bg-gray-900/80 backdrop-blur-xl">
        <CardContent className="p-4">
          <button
            onClick={() => setShowTroubleshooting(!showTroubleshooting)}
            className="flex items-center gap-2 text-gray-400 hover:text-gray-300 text-xs w-full transition-colors"
          >
            {showTroubleshooting ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            <Shield className="w-3.5 h-3.5" />
            Dépannage et questions fréquentes
          </button>

          {showTroubleshooting && (
            <div className="mt-3 space-y-3">
              {[
                {
                  q: "La commande 'supabase' n'est pas reconnue",
                  a: "Installez le CLI Supabase avec : npm install -g supabase (ou brew install supabase/tap/supabase sur macOS).",
                },
                {
                  q: "Erreur 'Function not found' lors du test",
                  a: "La fonction n'a pas encore été déployée. Utilisez la commande de déploiement correspondante ci-dessus.",
                },
                {
                  q: "Erreur de boot / 500 sur une fonction",
                  a: "Vérifiez les logs dans le Dashboard Supabase > Edge Functions > [nom de la fonction] > Logs. Assurez-vous que le code est correct.",
                },
                {
                  q: "La clé service_role n'est pas disponible",
                  a: "Les variables SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont automatiquement injectées. Si elles manquent, essayez de redéployer.",
                },
                {
                  q: "Puis-je déployer les fonctions une par une ?",
                  a: "Oui, chaque fonction peut être déployée individuellement avec sa commande spécifique. Vous pouvez aussi utiliser la commande unique pour tout déployer d'un coup.",
                },
                {
                  q: "Puis-je sauter cette étape ?",
                  a: "Certaines fonctions sont optionnelles selon vos besoins. confirm-user-email est utile si le service d'email échoue. Les autres fonctions activent des fonctionnalités spécifiques de la plateforme.",
                },
              ].map((item, i) => (
                <div key={i} className="bg-gray-800/30 rounded-lg p-3 border border-gray-700/30">
                  <p className="text-gray-300 text-xs font-medium mb-1 flex items-start gap-2">
                    <span className="text-purple-400 flex-shrink-0">Q:</span>
                    {item.q}
                  </p>
                  <p className="text-gray-500 text-xs leading-relaxed pl-5">
                    {item.a}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ==================== CONTINUE / SKIP ==================== */}
      {showContinue && (
        <div className="space-y-2">
          {allDeployed && allChecked && (
            <Alert className="border-green-500/20 bg-green-500/5">
              <CheckCircle className="h-4 w-4 text-green-400" />
              <AlertDescription className="text-green-300 text-xs">
                Toutes les fonctions sont prêtes ! Vous pouvez continuer vers le tableau de bord.
              </AlertDescription>
            </Alert>
          )}

          <Button
            onClick={onContinue}
            className={`w-full font-semibold shadow-lg ${
              allDeployed && allChecked
                ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-green-500/20'
                : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 shadow-purple-500/20'
            } text-white`}
          >
            <div className="flex items-center gap-2">
              {allDeployed && allChecked ? (
                <CheckCircle className="w-4 h-4" />
              ) : (
                <ArrowRight className="w-4 h-4" />
              )}
              {continueLabel}
            </div>
          </Button>

          {!(allDeployed && allChecked) && (
            <button
              onClick={onContinue}
              className="text-gray-500 hover:text-gray-400 text-xs text-center py-2 transition-colors w-full"
            >
              Passer cette étape et continuer quand même
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default EdgeFunctionGuide;
