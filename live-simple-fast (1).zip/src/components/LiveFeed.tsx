import React, { useState, useEffect, useMemo } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';


import { useAppContext } from '@/contexts/AppContext';

import { isValidUUID } from '@/lib/utils';
import Header from './Header';
import LiveCard from './LiveCard';
import VideoPlayer from './VideoPlayer';
import AuthModal from './AuthModal';
import CreatorProfileForm from './CreatorProfileForm';
import StartLiveModal from './StartLiveModal';
import SubscriptionModal from './SubscriptionModal';
import { sampleStreams, LiveStream } from '@/data/liveStreams';

type TabType = 'all' | 'following';

const LiveFeed: React.FC = () => {
  const { isAuthenticated, creatorProfile, user } = useAppContext();
  const [streams, setStreams] = useState<LiveStream[]>(sampleStreams);
  const [selectedStream, setSelectedStream] = useState<LiveStream | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [showProfileForm, setShowProfileForm] = useState(false);
  const [showStartLive, setShowStartLive] = useState(false);
  const [showSubscription, setShowSubscription] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [followedCreatorIds, setFollowedCreatorIds] = useState<string[]>([]);
  const [loadingFollows, setLoadingFollows] = useState(false);
  const [demoFollowedIds, setDemoFollowedIds] = useState<string[]>([]);

  useEffect(() => {
    const handleTriggerAuth = () => setShowAuth(true);
    const handleTriggerProfile = () => setShowProfileForm(true);
    const handleTriggerSubscription = () => setShowSubscription(true);
    const handleTriggerStartLive = () => setShowStartLive(true);

    window.addEventListener('triggerAuthModal', handleTriggerAuth);
    window.addEventListener('openAuthModal', handleTriggerAuth);
    window.addEventListener('triggerProfileForm', handleTriggerProfile);
    window.addEventListener('triggerSubscription', handleTriggerSubscription);
    window.addEventListener('triggerStartLive', handleTriggerStartLive);

    return () => {
      window.removeEventListener('triggerAuthModal', handleTriggerAuth);
      window.removeEventListener('openAuthModal', handleTriggerAuth);
      window.removeEventListener('triggerProfileForm', handleTriggerProfile);
      window.removeEventListener('triggerSubscription', handleTriggerSubscription);
      window.removeEventListener('triggerStartLive', handleTriggerStartLive);
    };
  }, []);

  useEffect(() => {
    // Skip all Supabase network requests if not configured (placeholder credentials)
    if (!isSupabaseConfigured) return;

    const fetchStreams = async () => {
      try {
        const { data: streamsData, error: streamsError } = await supabase
          .from('live_streams')
          .select('id, title, viewer_count, thumbnail_url, started_at, creator_id, channel_name, is_audio_only')
          .eq('is_live', true)
          .order('viewer_count', { ascending: false });

        if (streamsError) return;

        if (streamsData && streamsData.length > 0) {
          const creatorIds = [...new Set(streamsData.map(s => s.creator_id).filter(Boolean))];
          
          let creatorsMap: Record<string, any> = {};
          if (creatorIds.length > 0) {
            const { data: creatorsData, error: creatorsError } = await supabase
              .from('creator_profiles')
              .select('id, display_name, username, avatar_url, whatsapp_number')
              .in('id', creatorIds);
            
            if (!creatorsError && creatorsData) {
              creatorsMap = creatorsData.reduce((acc, creator) => {
                acc[creator.id] = creator;
                return acc;
              }, {} as Record<string, any>);
            } else if (creatorsError) {
              const { data: fallbackData, error: fallbackError } = await supabase
                .from('creators')
                .select('id, name, avatar_url, whatsapp_number')
                .in('id', creatorIds);
              
              if (!fallbackError && fallbackData) {
                creatorsMap = fallbackData.reduce((acc, creator) => {
                  acc[creator.id] = { ...creator, display_name: creator.name, username: creator.name?.replace(/\s+/g, '').toLowerCase() };
                  return acc;
                }, {} as Record<string, any>);
              }
            }
          }

          const formattedStreams: LiveStream[] = streamsData.map((stream: any) => {
            const creator = creatorsMap[stream.creator_id] || {};
            return {
              id: stream.id,
              title: stream.title,
              creatorId: stream.creator_id || '',
              creatorName: creator.display_name || creator.name || 'Creator',
              creatorUsername: creator.username || '',
              creatorAvatar: creator.avatar_url || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop',
              viewerCount: stream.viewer_count || 0,
              thumbnailUrl: stream.thumbnail_url || 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=800&h=450&fit=crop',
              isLive: true,
              startedAt: stream.started_at,
              followerCount: 0,
              whatsappNumber: creator.whatsapp_number || '',
              // Agora channel info — needed for VideoPlayer to join as subscriber
              channelName: stream.channel_name || null,
              isAudioOnly: stream.is_audio_only || false,
            };
          });

          setStreams(formattedStreams);
        }
      } catch {
        // Failed to fetch streams, using sample data
      }
    };


    fetchStreams();

    const channel = supabase
      .channel('live_streams_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'live_streams' }, () => {
        fetchStreams();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);



  useEffect(() => {


    const fetchFollowedCreators = async () => {
      if (!user) {
        setFollowedCreatorIds([]);
        return;
      }

      setLoadingFollows(true);
      try {
        const { data, error } = await supabase
          .from('follows')
          .select('creator_id')
          .eq('follower_id', user.id);

        if (!error && data) {
          setFollowedCreatorIds(data.map(f => f.creator_id));
        }
      } catch {
        // Failed to fetch follows
      } finally {
        setLoadingFollows(false);
      }
    };

    fetchFollowedCreators();

    if (user) {
      const channel = supabase
        .channel('follows_changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'follows',
          filter: `follower_id=eq.${user.id}`
        }, () => {
          fetchFollowedCreators();
        })
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user]);


  const handleDemoFollowChange = (creatorId: string, isFollowing: boolean) => {
    if (!isValidUUID(creatorId)) {
      if (isFollowing) {
        setDemoFollowedIds(prev => [...prev, creatorId]);
      } else {
        setDemoFollowedIds(prev => prev.filter(id => id !== creatorId));
      }
    }
  };

  const allFollowedIds = useMemo(() => {
    return [...followedCreatorIds, ...demoFollowedIds];
  }, [followedCreatorIds, demoFollowedIds]);

  const filteredStreams = useMemo(() => {
    if (activeTab === 'following') {
      return streams.filter(stream => allFollowedIds.includes(stream.creatorId));
    }
    return streams;
  }, [streams, activeTab, allFollowedIds]);

  const handleStartLive = () => {
    if (!isAuthenticated) {
      setShowAuth(true);
      return;
    }
    if (!creatorProfile) {
      setShowProfileForm(true);
      return;
    }
    setShowStartLive(true);
  };

  const handleStreamClick = (stream: LiveStream) => {
    setSelectedStream(stream);
  };

  const handleTabChange = (tab: TabType) => {
    if (tab === 'following' && !isAuthenticated) {
      setShowAuth(true);
      return;
    }
    setActiveTab(tab);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col pt-16">
      <Header
        onAuthClick={() => setShowAuth(true)}
        onStartLive={handleStartLive}
      />

      <div className="border-b border-gray-800 px-4">
        <div className="flex gap-1">
          <button
            onClick={() => handleTabChange('all')}
            className={`px-4 py-3 text-sm font-medium transition-colors relative ${
              activeTab === 'all'
                ? 'text-white'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            Tous les lives
            {activeTab === 'all' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-500 rounded-full" />
            )}
          </button>
          <button
            onClick={() => handleTabChange('following')}
            className={`px-4 py-3 text-sm font-medium transition-colors relative flex items-center gap-2 ${
              activeTab === 'following'
                ? 'text-white'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            Abonnements
            {allFollowedIds.length > 0 && (
              <span className="bg-purple-600 text-white text-xs px-1.5 py-0.5 rounded-full">
                {allFollowedIds.length}
              </span>
            )}
            {activeTab === 'following' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-500 rounded-full" />
            )}
          </button>
        </div>
      </div>

      <main className="flex-1 overflow-y-auto">
        {loadingFollows && activeTab === 'following' ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
          </div>
        ) : filteredStreams.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center min-h-[400px]">
            <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mb-4">
              {activeTab === 'following' ? (
                <svg className="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
              ) : (
                <svg className="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              )}
            </div>
            {activeTab === 'following' ? (
              <>
                <h2 className="text-white text-xl font-semibold mb-2">
                  {allFollowedIds.length === 0 
                    ? "Vous ne suivez personne"
                    : "Aucun créateur suivi n'est en live"
                  }
                </h2>
                <p className="text-gray-400 mb-6">
                  {allFollowedIds.length === 0
                    ? "Suivez des créateurs pour voir leurs lives ici"
                    : "Les créateurs que vous suivez ne sont pas en direct"
                  }
                </p>
                <button
                  onClick={() => setActiveTab('all')}
                  className="bg-purple-600 hover:bg-purple-700 text-white font-medium px-6 py-3 rounded-xl transition-colors"
                >
                  Découvrir des créateurs
                </button>
              </>
            ) : (
              <>
                <h2 className="text-white text-xl font-semibold mb-2">Aucun live en cours</h2>
                <p className="text-gray-400 mb-6">Soyez le premier à démarrer un live!</p>
                <button
                  onClick={handleStartLive}
                  className="bg-red-600 hover:bg-red-700 text-white font-medium px-6 py-3 rounded-xl transition-colors flex items-center gap-2"
                >
                  <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                  Démarrer un live
                </button>
              </>
            )}
          </div>
        ) : (
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredStreams.map((stream) => (
              <LiveCard
                key={stream.id}
                stream={stream}
                onClick={() => handleStreamClick(stream)}
                onFollowChange={(isFollowing) => handleDemoFollowChange(stream.creatorId, isFollowing)}
              />
            ))}
          </div>
        )}
      </main>

      {selectedStream && (
        <VideoPlayer
          stream={selectedStream}
          onClose={() => setSelectedStream(null)}
          onFollowChange={(isFollowing) => handleDemoFollowChange(selectedStream.creatorId, isFollowing)}
        />
      )}

      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />
      <CreatorProfileForm
        isOpen={showProfileForm || (isAuthenticated && !creatorProfile && showAuth === false)}
        onClose={() => setShowProfileForm(false)}
      />
      <StartLiveModal
        isOpen={showStartLive}
        onClose={() => setShowStartLive(false)}
        onStarted={() => {}}
      />
      <SubscriptionModal
        isOpen={showSubscription}
        onClose={() => setShowSubscription(false)}
      />
    </div>
  );
};

export default LiveFeed;
