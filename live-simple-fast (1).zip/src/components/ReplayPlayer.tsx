import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ReplayData } from './ReplayCard';
import { recordingService } from '@/lib/recordingService';
import AudioVisualizer from './AudioVisualizer';

interface ReplayPlayerProps {
  replay: ReplayData;
  onClose: () => void;
}

const ReplayPlayer: React.FC<ReplayPlayerProps> = ({ replay, onClose }) => {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [audioStream, setAudioStream] = useState<MediaStream | null>(null);
  const controlsTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const isAudioOnly = replay.is_audio_only === true;

  useEffect(() => {
    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(() => {});
      }
    };
  }, []);

  // Create a MediaStream from the audio element for the visualizer
  useEffect(() => {
    if (!isAudioOnly || !audioRef.current) return;

    const setupAudioStream = () => {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const source = audioCtx.createMediaElementSource(audioRef.current!);
        const destination = audioCtx.createMediaStreamDestination();
        source.connect(destination);
        source.connect(audioCtx.destination); // Also connect to speakers
        audioContextRef.current = audioCtx;
        setAudioStream(destination.stream);
      } catch (err) {
        console.warn('[ReplayPlayer] Could not create audio stream for visualizer:', err);
      }
    };

    // Setup on first play to avoid autoplay restrictions
    const handleFirstPlay = () => {
      if (!audioStream) {
        setupAudioStream();
      }
    };

    audioRef.current.addEventListener('play', handleFirstPlay, { once: true });
    return () => {
      audioRef.current?.removeEventListener('play', handleFirstPlay);
    };
  }, [isAudioOnly, audioStream]);

  const getMediaElement = () => {
    return isAudioOnly ? audioRef.current : videoRef.current;
  };

  const handlePlayPause = () => {
    const media = getMediaElement();
    if (!media) return;

    if (media.paused) {
      media.play();
      setIsPlaying(true);
    } else {
      media.pause();
      setIsPlaying(false);
    }
  };

  const handleTimeUpdate = () => {
    const media = getMediaElement();
    if (media) {
      setCurrentTime(media.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    const media = getMediaElement();
    if (media) {
      setDuration(media.duration);
      setIsLoading(false);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const media = getMediaElement();
    if (media) {
      const time = parseFloat(e.target.value);
      media.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleVideoClick = () => {
    setShowControls(true);
    handlePlayPause();

    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const formatTime = (seconds: number): string => {
    if (isNaN(seconds)) return '0:00';
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const openWhatsApp = () => {
    if (!replay.whatsappNumber) return;
    const message = encodeURIComponent(`Salut ${replay.creatorName}! J'ai regardé ton replay "${replay.title}" sur PitchCI`);
    const cleanNumber = replay.whatsappNumber.replace(/[^0-9+]/g, '');
    window.open(`https://wa.me/${cleanNumber}?text=${message}`, '_blank');
  };

  const handleShare = async () => {
    const shareData = {
      title: replay.title,
      text: `Regardez le replay de ${replay.creatorName} sur PitchCI!`,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      await navigator.clipboard.writeText(window.location.href);
    }
  };

  const goToProfile = () => {
    // Only navigate if we have a real creatorUsername from the database
    if (replay.creatorUsername) {
      onClose();
      navigate(`/creator/${replay.creatorUsername}`);
    }
  };


  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  const creatorInitials = (replay.creatorName || 'C')
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div
      className="fixed inset-0 bg-black z-50 flex flex-col"
      onMouseMove={handleMouseMove}
    >
      {/* Main Content Area */}
      <div className="relative flex-1 bg-gray-900 flex items-center justify-center">
        {isAudioOnly ? (
          /* ===== AUDIO-ONLY REPLAY VIEW ===== */
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-gray-900 via-purple-950/30 to-gray-900 relative" onClick={handleVideoClick}>
            {/* Subtle background pattern */}
            <div className="absolute inset-0 opacity-5">
              <div className="w-full h-full" style={{
                backgroundImage: 'radial-gradient(circle at 25% 25%, #a855f7 1px, transparent 1px), radial-gradient(circle at 75% 75%, #a855f7 1px, transparent 1px)',
                backgroundSize: '50px 50px'
              }} />
            </div>

            {/* Large Avatar */}
            <div className="relative z-10 mb-6">
              <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full overflow-hidden ring-4 ring-purple-500/40 shadow-2xl shadow-purple-500/20">
                {replay.creatorAvatar ? (
                  <img src={replay.creatorAvatar} alt={replay.creatorName || ''} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                    <span className="text-white text-4xl sm:text-5xl font-bold">{creatorInitials}</span>
                  </div>
                )}
              </div>
              {/* Mic badge */}
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center ring-3 ring-gray-900">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              {/* Pulsing ring when playing */}
              {isPlaying && (
                <div className="absolute inset-0 rounded-full ring-4 ring-purple-500/20 animate-ping" style={{ animationDuration: '2s' }} />
              )}
            </div>

            {/* Creator Name */}
            <div className="text-center z-10 mb-6">
              <h3 className="text-white text-xl font-bold">{replay.creatorName}</h3>
              <p className="text-purple-300/70 text-sm mt-1">Replay audio</p>
            </div>

            {/* Audio Visualizer */}
            <div className="w-full max-w-md px-8 z-10">
              <AudioVisualizer
                stream={audioStream}
                isActive={isPlaying}
                barColor="#a855f7"
                barCount={40}
                className="rounded-xl"
              />
            </div>

            {/* Hidden audio element */}
            {replay.recording_url && (
              <audio
                ref={audioRef}
                src={replay.recording_url}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onWaiting={() => setIsLoading(true)}
                onCanPlay={() => setIsLoading(false)}
                onError={() => { setHasError(true); setIsLoading(false); }}
                onEnded={() => { setIsPlaying(false); setShowControls(true); }}
                preload="metadata"
              />
            )}

            {/* Large play button overlay when paused */}
            {!isPlaying && !isLoading && replay.recording_url && (
              <button
                onClick={(e) => { e.stopPropagation(); handlePlayPause(); }}
                className="absolute z-20 w-20 h-20 bg-purple-600/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-purple-600 transition-colors shadow-2xl"
                style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
              >
                <svg className="w-10 h-10 text-white ml-1" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                </svg>
              </button>
            )}
          </div>
        ) : (
          /* ===== VIDEO REPLAY VIEW ===== */
          <>
            {replay.recording_url ? (
              <video
                ref={videoRef}
                src={replay.recording_url}
                className="max-w-full max-h-full object-contain cursor-pointer"
                onClick={handleVideoClick}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onWaiting={() => setIsLoading(true)}
                onCanPlay={() => setIsLoading(false)}
                onError={() => { setHasError(true); setIsLoading(false); }}
                onEnded={() => { setIsPlaying(false); setShowControls(true); }}
                playsInline
                poster={replay.thumbnail_url}
              />
            ) : (
              <div className="relative w-full h-full">
                <img
                  src={replay.thumbnail_url || 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=800&h=450&fit=crop'}
                  alt={replay.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <div className="text-center">
                    <svg className="w-16 h-16 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                    <p className="text-gray-400">Enregistrement en cours de traitement</p>
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* Loading spinner */}
        {isLoading && replay.recording_url && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30 z-30">
            <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin" />
          </div>
        )}

        {/* Error state */}
        {hasError && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-30">
            <div className="text-center">
              <svg className="w-12 h-12 text-red-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="text-red-400 font-medium">Impossible de lire l'enregistrement</p>
              <p className="text-gray-500 text-sm mt-1">Le fichier est peut-être corrompu ou indisponible</p>
            </div>
          </div>
        )}

        {/* Top Bar */}
        <div className={`absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/70 to-transparent transition-opacity duration-300 z-40 ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <div className="flex items-center justify-between">
            <button
              onClick={onClose}
              className="w-10 h-10 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-black/70 transition-colors"
            >
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <div className="flex items-center gap-2">
              <span className="bg-purple-600 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5">
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
                </svg>
                REPLAY
              </span>
              {isAudioOnly && (
                <span className="bg-purple-500/80 backdrop-blur-sm text-white text-xs font-medium px-3 py-1.5 rounded-full flex items-center gap-1.5">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                  Audio
                </span>
              )}
              <span className="bg-black/50 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                </svg>
                {replay.peak_viewers || replay.viewer_count}
              </span>
            </div>
          </div>
        </div>

        {/* Right Side Actions */}
        <div className={`absolute right-4 bottom-32 flex flex-col items-center gap-5 transition-opacity duration-300 z-40 ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          {/* Creator Avatar */}
          <button onClick={goToProfile} className="relative">
            <img
              src={replay.creatorAvatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop'}
              alt={replay.creatorName}
              className="w-12 h-12 rounded-full border-2 border-white object-cover hover:scale-105 transition-transform"
            />
          </button>

          {/* WhatsApp Button */}
          {replay.whatsappNumber && (
            <button onClick={openWhatsApp} className="flex flex-col items-center gap-1 group">
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </div>
              <span className="text-white text-xs font-medium drop-shadow-lg">WhatsApp</span>
            </button>
          )}

          {/* Share */}
          <button onClick={handleShare} className="flex flex-col items-center gap-1 group">
            <div className="w-12 h-12 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg group-hover:bg-black/60 transition-colors">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
            </div>
            <span className="text-white text-xs font-medium drop-shadow-lg">Partager</span>
          </button>
        </div>

        {/* Bottom Info + Controls */}
        <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent transition-opacity duration-300 z-40 ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          {/* Creator info */}
          <div className="px-4 pb-2 pr-20">
            <button onClick={goToProfile} className="flex items-center gap-2 mb-1 hover:opacity-80 transition-opacity">
              <span className="text-white font-bold text-base drop-shadow-lg">
                @{replay.creatorUsername || replay.creatorName?.replace(/\s+/g, '').toLowerCase()}
              </span>
            </button>
            <h2 className="text-white font-semibold text-lg mb-1 drop-shadow-lg line-clamp-2">
              {replay.title}
            </h2>
            <div className="flex items-center gap-3 text-gray-400 text-xs">
              <span>{recordingService.formatDuration(replay.duration_seconds)}</span>
              {replay.recording_size_bytes > 0 && (
                <>
                  <span>·</span>
                  <span>{recordingService.formatFileSize(replay.recording_size_bytes)}</span>
                </>
              )}
              {isAudioOnly && (
                <>
                  <span>·</span>
                  <span className="text-purple-400 flex items-center gap-1">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                    Audio uniquement
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Playback controls */}
          {replay.recording_url && (
            <div className="px-4 py-3">
              {/* Progress bar */}
              <div className="flex items-center gap-3 mb-2">
                <span className="text-white text-xs font-mono w-12 text-right">{formatTime(currentTime)}</span>
                <div className="flex-1 relative">
                  <input
                    type="range"
                    min={0}
                    max={duration || 0}
                    step={0.1}
                    value={currentTime}
                    onChange={handleSeek}
                    className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:cursor-pointer"
                    style={{
                      background: `linear-gradient(to right, #a855f7 ${progress}%, rgba(255,255,255,0.2) ${progress}%)`
                    }}
                  />
                </div>
                <span className="text-white text-xs font-mono w-12">{formatTime(duration)}</span>
              </div>

              {/* Play/Pause button */}
              <div className="flex items-center justify-center">
                <button
                  onClick={handlePlayPause}
                  className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
                >
                  {isPlaying ? (
                    <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg className="w-6 h-6 text-white ml-0.5" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                    </svg>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReplayPlayer;
