import React from 'react';
import { CheckCircle, Shield } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface VerificationBadgeProps {
  isVerified: boolean;
  size?: 'sm' | 'md' | 'lg';
  showTooltip?: boolean;
  className?: string;
}

export function VerificationBadge({ 
  isVerified, 
  size = 'md', 
  showTooltip = true,
  className = '' 
}: VerificationBadgeProps) {
  if (!isVerified) return null;

  const sizeClasses = {
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
    lg: 'w-5 h-5'
  };

  const badge = (
    <div className={`inline-flex items-center justify-center ${className}`}>
      <CheckCircle 
        className={`${sizeClasses[size]} text-blue-500 fill-blue-500`} 
        strokeWidth={2.5}
      />
    </div>
  );

  if (!showTooltip) {
    return badge;
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          {badge}
        </TooltipTrigger>
        <TooltipContent>
          <div className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-blue-500" />
            <span className="text-xs font-medium">Verified Creator</span>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Inline verification badge for use in text
export function VerificationBadgeInline({ isVerified }: { isVerified: boolean }) {
  if (!isVerified) return null;
  
  return (
    <CheckCircle 
      className="inline-block w-4 h-4 ml-1 text-blue-500 fill-blue-500 align-text-bottom" 
      strokeWidth={2.5}
    />
  );
}

// Full verification status display
export function VerificationStatus({ 
  status 
}: { 
  status: 'pending' | 'approved' | 'rejected' | 'none' 
}) {
  const statusConfig = {
    none: {
      label: 'Not Verified',
      color: 'text-gray-500 bg-gray-100',
      icon: Shield
    },
    pending: {
      label: 'Pending Review',
      color: 'text-yellow-700 bg-yellow-100',
      icon: Shield
    },
    approved: {
      label: 'Verified',
      color: 'text-blue-700 bg-blue-100',
      icon: CheckCircle
    },
    rejected: {
      label: 'Rejected',
      color: 'text-red-700 bg-red-100',
      icon: Shield
    }
  };

  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${config.color}`}>
      <Icon className="w-3.5 h-3.5" />
      {config.label}
    </span>
  );
}
