import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import { isValidUUID } from '@/lib/utils';
import { sampleStreams, LiveStream } from '@/data/liveStreams';
import FollowButton from './FollowButton';
import LiveChat from './LiveChat';
import AuthModal from './AuthModal';
import CreatorProfileForm from './CreatorProfileForm';
import StartLiveModal from './StartLiveModal';
import SubscriptionModal from './SubscriptionModal';

const TikTokFeed: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, creatorProfile, user, hasActiveSubscription } = useAppContext();
  const [streams, setStreams] = useState<LiveStream[]>(sampleStreams);
  const [currentIndex, setCurrentIndex] = useState(0);

  const [showAuth, setShowAuth] = useState(false);
  const [showProfileForm, setShowProfileForm] = useState(false);
  const [showStartLive, setShowStartLive] = useState(false);
  const [showSubscription, setShowSubscription] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [followedCreatorIds, setFollowedCreatorIds] = useState<string[]>([]);
  const [demoFollowedIds, setDemoFollowedIds] = useState<string[]>([]);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const minSwipeDistance = 50;

  // Listen for event triggers
  useEffect(() => {
    const handleTriggerAuth = () => setShowAuth(true);
    const handleTriggerProfile = () => setShowProfileForm(true);
    const handleTriggerSubscription = () => setShowSubscription(true);
    const handleTriggerStartLive = () => setShowStartLive(true);

    window.addEventListener('triggerAuthModal', handleTriggerAuth);
    window.addEventListener('openAuthModal', handleTriggerAuth);
    window.addEventListener('triggerProfileForm', handleTriggerProfile);
    window.addEventListener('triggerSubscription', handleTriggerSubscription);
    window.addEventListener('triggerStartLive', handleTriggerStartLive);

    return () => {
      window.removeEventListener('triggerAuthModal', handleTriggerAuth);
      window.removeEventListener('openAuthModal', handleTriggerAuth);
      window.removeEventListener('triggerProfileForm', handleTriggerProfile);
      window.removeEventListener('triggerSubscription', handleTriggerSubscription);
      window.removeEventListener('triggerStartLive', handleTriggerStartLive);
    };
  }, []);


  useEffect(() => {
    const fetchStreams = async () => {
      try {
        const { data: streamsData, error: streamsError } = await supabase
          .from('live_streams')
          .select('id, title, viewer_count, thumbnail_url, started_at, creator_id')
          .eq('is_live', true)
          .order('viewer_count', { ascending: false });

        if (streamsError) {
          return;
        }

        if (streamsData && streamsData.length > 0) {
          const creatorIds = [...new Set(streamsData.map(s => s.creator_id).filter(Boolean))];
          
          let creatorsMap: Record<string, any> = {};
          if (creatorIds.length > 0) {
            const { data: creatorsData, error: creatorsError } = await supabase
              .from('creator_profiles')
              .select('id, display_name, username, avatar_url, whatsapp_number')
              .in('id', creatorIds);
            
            if (!creatorsError && creatorsData) {
              creatorsMap = creatorsData.reduce((acc, creator) => {
                acc[creator.id] = creator;
                return acc;
              }, {} as Record<string, any>);
            }
          }

          const formattedStreams: LiveStream[] = streamsData.map((stream: any) => {
            const creator = creatorsMap[stream.creator_id] || {};
            return {
              id: stream.id,
              title: stream.title,
              creatorId: stream.creator_id || '',
              creatorName: creator.display_name || creator.name || 'Creator',
              creatorUsername: creator.username || '',
              creatorAvatar: creator.avatar_url || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop',
              viewerCount: stream.viewer_count || 0,
              thumbnailUrl: stream.thumbnail_url || 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=800&h=1400&fit=crop',
              isLive: true,
              startedAt: stream.started_at,
              followerCount: 0,
              whatsappNumber: creator.whatsapp_number || '',
            };
          });

          setStreams(formattedStreams);
        }
      } catch (err) {
        console.error('Error fetching streams:', err);
      }
    };

    fetchStreams();

    const channel = supabase
      .channel('live_streams_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'live_streams' }, () => {
        fetchStreams();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);



  useEffect(() => {
    const fetchFollowedCreators = async () => {
      if (!user) {
        setFollowedCreatorIds([]);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('follows')
          .select('creator_id')
          .eq('follower_id', user.id);

        if (!error && data) {
          setFollowedCreatorIds(data.map(f => f.creator_id));
        }
      } catch (err) {
        console.error('[DEBUG TikTokFeed] Error fetching follows:', err);
      }
    };

    fetchFollowedCreators();
  }, [user]);

  const currentStream = streams[currentIndex];

  const handleDemoFollowChange = (creatorId: string, isFollowing: boolean) => {
    if (!isValidUUID(creatorId)) {
      if (isFollowing) {
        setDemoFollowedIds(prev => [...prev, creatorId]);
      } else {
        setDemoFollowedIds(prev => prev.filter(id => id !== creatorId));
      }
    }
  };

  const allFollowedIds = useMemo(() => {
    return [...followedCreatorIds, ...demoFollowedIds];
  }, [followedCreatorIds, demoFollowedIds]);

  const goToNext = useCallback(() => {
    if (isTransitioning || currentIndex >= streams.length - 1) return;
    setIsTransitioning(true);
    setCurrentIndex(prev => prev + 1);
    setTimeout(() => setIsTransitioning(false), 300);
  }, [currentIndex, streams.length, isTransitioning]);

  const goToPrevious = useCallback(() => {
    if (isTransitioning || currentIndex <= 0) return;
    setIsTransitioning(true);
    setCurrentIndex(prev => prev - 1);
    setTimeout(() => setIsTransitioning(false), 300);
  }, [currentIndex, isTransitioning]);

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientY);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientY);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isUpSwipe = distance > minSwipeDistance;
    const isDownSwipe = distance < -minSwipeDistance;

    if (isUpSwipe) {
      goToNext();
    } else if (isDownSwipe) {
      goToPrevious();
    }
  };

  const handleWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    if (e.deltaY > 30) {
      goToNext();
    } else if (e.deltaY < -30) {
      goToPrevious();
    }
  }, [goToNext, goToPrevious]);

  useEffect(() => {
    const container = containerRef.current;
    if (container) {
      container.addEventListener('wheel', handleWheel, { passive: false });
      return () => container.removeEventListener('wheel', handleWheel);
    }
  }, [handleWheel]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' || e.key === 'j') {
        goToNext();
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        goToPrevious();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [goToNext, goToPrevious]);

  const handleStartLive = () => {
    if (!isAuthenticated) {
      setShowAuth(true);
      return;
    }
    if (!creatorProfile) {
      setShowProfileForm(true);
      return;
    }
    setShowStartLive(true);
  };

  const openWhatsApp = (whatsappNumber: string, creatorName: string) => {
    const message = encodeURIComponent(`Salut ${creatorName}! Je regarde ton live sur PitchCI`);

    const cleanNumber = whatsappNumber.replace(/[^0-9+]/g, '');
    window.open(`https://wa.me/${cleanNumber}?text=${message}`, '_blank');
  };




  const formatCount = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  if (streams.length === 0) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center">
        <div className="text-center p-8">
          <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </div>
          <h2 className="text-white text-xl font-semibold mb-2">Aucun live en cours</h2>
          <p className="text-gray-400 mb-6">Soyez le premier à démarrer un live!</p>
          <button
            onClick={handleStartLive}
            className="bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white font-medium px-6 py-3 rounded-full transition-all flex items-center gap-2 mx-auto"
          >
            <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
            Démarrer un Live
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 bg-black overflow-hidden"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* Video Container */}
      <div 
        className="absolute inset-0 transition-transform duration-300 ease-out"
        style={{ transform: `translateY(-${currentIndex * 100}%)` }}
      >
        {streams.map((stream, index) => (
          <div 
            key={stream.id}
            className="absolute inset-0 w-full h-full"
            style={{ top: `${index * 100}%` }}
          >
            <div className="absolute inset-0">
              <img
                src={stream.thumbnailUrl}
                alt={stream.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/60" />
            </div>
          </div>
        ))}
      </div>

      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 z-20 safe-area-top">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-2">
            <span className="bg-red-600 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-lg">
              <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
              LIVE
            </span>
            <span className="bg-black/50 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
              </svg>
              {formatCount(currentStream?.viewerCount || 0)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleStartLive}
              className="bg-gradient-to-r from-pink-500 to-red-500 text-white text-xs font-semibold px-4 py-2 rounded-full shadow-lg"
            >
              Go Live
            </button>

            {!isAuthenticated && (
              <button
                onClick={() => setShowAuth(true)}
                className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-4 py-2 rounded-full"
              >
                Connexion
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Right Side Actions (TikTok style) */}
      <div className="absolute right-3 bottom-32 z-20 flex flex-col items-center gap-5">
        {/* Creator Avatar with Follow Button */}
        <div className="relative">
          <button
            onClick={() => {
              const username = currentStream?.creatorUsername || currentStream?.creatorName?.replace(/\s+/g, '').toLowerCase();
              if (username) {
                navigate(`/creator/${username}`);
              }
            }}
            className="block"
          >
            <img
              src={currentStream?.creatorAvatar}
              alt={currentStream?.creatorName}
              className="w-12 h-12 rounded-full border-2 border-white object-cover shadow-lg hover:scale-105 transition-transform"
            />
          </button>
          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
            <FollowButton
              creatorId={currentStream?.creatorId || ''}
              creatorName={currentStream?.creatorName || ''}
              followerCount={currentStream?.followerCount}
              size="icon"
              onFollowChange={(isFollowing) => handleDemoFollowChange(currentStream?.creatorId || '', isFollowing)}
            />
          </div>
        </div>

        {/* WhatsApp Button - Prominent */}
        {currentStream?.whatsappNumber && (
          <button
            onClick={() => {
              console.log('[DEBUG WhatsApp] Button clicked! Stream:', currentStream.title, 'Number:', currentStream.whatsappNumber);
              openWhatsApp(currentStream.whatsappNumber!, currentStream.creatorName);
            }}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
              <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
            </div>
            <span className="text-white text-xs font-medium drop-shadow-lg">WhatsApp</span>
          </button>
        )}

        {/* Chat Toggle */}
        <button
          onClick={() => setShowChat(!showChat)}
          className="flex flex-col items-center gap-1 group"
        >
          <div className="w-12 h-12 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg group-hover:bg-black/60 transition-colors">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
          </div>
          <span className="text-white text-xs font-medium drop-shadow-lg">Chat</span>
        </button>

        {/* Share */}
        <button
          onClick={() => {
            if (navigator.share) {
              navigator.share({
                title: currentStream?.title,
                text: `Regardez le live de ${currentStream?.creatorName} sur PitchCI!`,

                url: window.location.href,
              });
            } else {
              navigator.clipboard.writeText(window.location.href);
            }
          }}
          className="flex flex-col items-center gap-1 group"
        >
          <div className="w-12 h-12 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg group-hover:bg-black/60 transition-colors">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
            </svg>
          </div>
          <span className="text-white text-xs font-medium drop-shadow-lg">Partager</span>
        </button>
      </div>

      {/* Bottom Info (Creator info + Title) */}
      <div className="absolute bottom-0 left-0 right-20 z-20 p-4 pb-8 safe-area-bottom">
        <button 
          onClick={() => {
            const username = currentStream?.creatorUsername || currentStream?.creatorName?.replace(/\s+/g, '').toLowerCase();
            if (username) {
              navigate(`/creator/${username}`);
            }
          }}
          className="flex items-center gap-3 mb-3 hover:opacity-80 transition-opacity"
        >
          <span className="text-white font-bold text-base drop-shadow-lg">
            @{currentStream?.creatorUsername || currentStream?.creatorName?.replace(/\s+/g, '').toLowerCase()}
          </span>
          {allFollowedIds.includes(currentStream?.creatorId || '') && (
            <span className="bg-purple-500/80 text-white text-xs px-2 py-0.5 rounded-full">
              Suivi
            </span>
          )}
        </button>

        <h2 className="text-white font-semibold text-lg mb-2 drop-shadow-lg line-clamp-2">
          {currentStream?.title}
        </h2>

        {/* WhatsApp indicator in bottom info */}
        {currentStream?.whatsappNumber && (
          <div className="flex items-center gap-2 mt-2">
            <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
              <svg className="w-2.5 h-2.5 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
            </div>
            <span className="text-green-400 text-xs drop-shadow-lg">WhatsApp disponible</span>
          </div>
        )}

        <div className="mt-4 flex items-center gap-2 text-white/60 text-xs">
          <svg className="w-4 h-4 animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
          <span>Swipe pour le prochain live</span>
        </div>
      </div>

      {/* Progress Indicators */}
      <div className="absolute right-1.5 top-1/2 transform -translate-y-1/2 z-20 flex flex-col gap-1">
        {streams.map((_, index) => (
          <div
            key={index}
            className={`w-1 rounded-full transition-all duration-300 ${
              index === currentIndex 
                ? 'h-6 bg-white' 
                : 'h-2 bg-white/40'
            }`}
          />
        ))}
      </div>

      {/* Chat Overlay */}
      {showChat && currentStream && (
        <div className="absolute inset-0 z-30 bg-black/50 backdrop-blur-sm">
          <div className="absolute bottom-0 left-0 right-0 h-[70%] bg-gray-900 rounded-t-3xl overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-800 flex-shrink-0">
              <h3 className="text-white font-semibold">Chat en direct</h3>
              <button
                onClick={() => setShowChat(false)}
                className="w-8 h-8 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center transition-colors"
              >
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <LiveChat
                streamId={currentStream.id}
                creatorId={currentStream.creatorId}
                isExpanded={true}
                onToggleExpand={() => setShowChat(false)}
              />
            </div>
          </div>
        </div>
      )}


      {/* Modals */}
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />
      <CreatorProfileForm
        isOpen={showProfileForm || (isAuthenticated && !creatorProfile && showAuth === false)}
        onClose={() => setShowProfileForm(false)}
      />
      <StartLiveModal
        isOpen={showStartLive}
        onClose={() => setShowStartLive(false)}
        onStarted={() => {
          console.log('[DEBUG TikTokFeed] Live started successfully!');
        }}
      />
      <SubscriptionModal
        isOpen={showSubscription}
        onClose={() => setShowSubscription(false)}
      />
    </div>
  );
};

export default TikTokFeed;
