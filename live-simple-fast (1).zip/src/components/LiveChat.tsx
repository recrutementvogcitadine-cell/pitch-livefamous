import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { isValidUUID } from '@/lib/utils';
import { chatService, ChatMessage } from '@/lib/chatService';
import { teamService } from '@/lib/teamService';
import { getReplicationSettingsUrl } from '@/lib/supabase';

interface LiveChatProps {
  streamId: string;
  creatorId?: string;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

// Mock messages for demo streams (non-UUID IDs)
const mockMessages: ChatMessage[] = [
  {
    id: 'mock-1',
    stream_id: 'demo',
    user_id: 'user-1',
    message: 'Super stream !',
    display_name: 'StreamFan42',
    avatar_url: null,
    is_deleted: false,
    deleted_by: null,
    created_at: new Date(Date.now() - 300000).toISOString(),
  },
  {
    id: 'mock-2',
    stream_id: 'demo',
    user_id: 'user-2',
    message: 'Salut tout le monde !',
    display_name: 'NightOwl',
    avatar_url: null,
    is_deleted: false,
    deleted_by: null,
    created_at: new Date(Date.now() - 240000).toISOString(),
  },
  {
    id: 'mock-3',
    stream_id: 'demo',
    user_id: 'user-3',
    message: 'Contenu incroyable',
    display_name: 'TechLover',
    avatar_url: null,
    is_deleted: false,
    deleted_by: null,
    created_at: new Date(Date.now() - 180000).toISOString(),
  },
  {
    id: 'mock-4',
    stream_id: 'demo',
    user_id: 'user-4',
    message: 'Tu peux expliquer encore ?',
    display_name: 'CuriousCat',
    avatar_url: null,
    is_deleted: false,
    deleted_by: null,
    created_at: new Date(Date.now() - 120000).toISOString(),
  },
  {
    id: 'mock-5',
    stream_id: 'demo',
    user_id: 'user-5',
    message: "Premiere fois ici, j'adore !",
    display_name: 'NewViewer',
    avatar_url: null,
    is_deleted: false,
    deleted_by: null,
    created_at: new Date(Date.now() - 60000).toISOString(),
  },
];

interface BanModalState {
  isOpen: boolean;
  targetUserId: string;
  targetUserName: string;
  reason: string;
  duration: string; // 'permanent' | '1h' | '24h' | '7d' | '30d'
}

const POLLING_INTERVAL_MS = 5000; // 5 seconds fallback polling

const LiveChat: React.FC<LiveChatProps> = ({ streamId, creatorId, isExpanded = true, onToggleExpand }) => {
  const { user, creatorProfile } = useAppContext();
  const isRealStream = isValidUUID(streamId);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rateLimitWait, setRateLimitWait] = useState(0);
  const [isCreatorOfStream, setIsCreatorOfStream] = useState(false);
  const [isTeamModerator, setIsTeamModerator] = useState(false);
  const [deletedMessageId, setDeletedMessageId] = useState<string | null>(null);
  const [showModMenu, setShowModMenu] = useState<string | null>(null);
  const [isBanned, setIsBanned] = useState(false);
  const [realtimeActive, setRealtimeActive] = useState(true);
  const [showRealtimeWarning, setShowRealtimeWarning] = useState(false);
  const [banModal, setBanModal] = useState<BanModalState>({
    isOpen: false,
    targetUserId: '',
    targetUserName: '',
    reason: '',
    duration: '24h',
  });
  const [isBanning, setIsBanning] = useState(false);
  const [banSuccess, setBanSuccess] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const rateLimitTimerRef = useRef<NodeJS.Timeout | null>(null);
  const pollingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const lastMessageCountRef = useRef<number>(0);

  // Determine if current user is the stream creator or team moderator
  useEffect(() => {
    if (!user || !isRealStream) {
      setIsCreatorOfStream(false);
      setIsTeamModerator(false);
      return;
    }

    if (creatorId && creatorProfile) {
      setIsCreatorOfStream(creatorProfile.id === creatorId);
    } else {
      chatService.isStreamCreator(streamId, user.id).then(setIsCreatorOfStream);
    }

    teamService.hasPermission('moderate_chat').then(setIsTeamModerator);
  }, [user, creatorId, creatorProfile, streamId, isRealStream]);

  // Check if current user is banned
  useEffect(() => {
    if (!user || !isRealStream) return;
    chatService.checkBanStatus(streamId, user.id).then(({ isBanned: banned }) => {
      setIsBanned(banned);
    });
  }, [user, streamId, isRealStream]);

  const isModerator = isCreatorOfStream || isTeamModerator;

  // Scroll to bottom when new messages arrive
  const scrollToBottom = useCallback(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  // Rate limit countdown timer
  useEffect(() => {
    if (rateLimitWait > 0) {
      rateLimitTimerRef.current = setInterval(() => {
        setRateLimitWait(prev => {
          if (prev <= 1) {
            if (rateLimitTimerRef.current) clearInterval(rateLimitTimerRef.current);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => {
        if (rateLimitTimerRef.current) clearInterval(rateLimitTimerRef.current);
      };
    }
  }, [rateLimitWait]);

  // Fetch existing messages
  useEffect(() => {
    const fetchMessages = async () => {
      setIsLoading(true);

      if (!isRealStream) {
        setMessages(mockMessages);
        setIsLoading(false);
        return;
      }

      const { data, error: fetchError } = await chatService.fetchMessages(streamId);

      if (fetchError) {
        console.error('[LiveChat] Error fetching messages:', fetchError);
        setError('Impossible de charger les messages');
      } else {
        setMessages(data || []);
        lastMessageCountRef.current = (data || []).length;
      }

      setIsLoading(false);
    };

    fetchMessages();
  }, [streamId, isRealStream]);

  // Subscribe to real-time messages with fallback polling detection
  useEffect(() => {
    if (!isRealStream) return;

    let realtimeReceived = false;
    let subscriptionTimeout: NodeJS.Timeout | null = null;

    const unsubscribe = chatService.subscribeToMessages(
      streamId,
      (newMsg) => {
        realtimeReceived = true;
        setRealtimeActive(true);
        setMessages(prev => {
          if (prev.some(m => m.id === newMsg.id)) return prev;
          return [...prev, newMsg];
        });
      },
      (deletedId) => {
        realtimeReceived = true;
        setRealtimeActive(true);
        setMessages(prev => prev.filter(m => m.id !== deletedId));
        setDeletedMessageId(deletedId);
        setTimeout(() => setDeletedMessageId(null), 2000);
      }
    );

    // After 10 seconds, if no realtime events received and there are messages,
    // check if realtime is actually working by doing a test query
    subscriptionTimeout = setTimeout(async () => {
      if (!realtimeReceived) {
        // Do a fresh fetch to see if there are new messages we missed
        const { data } = await chatService.fetchMessages(streamId);
        if (data && data.length > lastMessageCountRef.current) {
          // There are new messages we didn't get via realtime — realtime is NOT working
          console.warn('[LiveChat] Realtime not delivering messages — falling back to polling. Enable Realtime for live_chat_messages table in Supabase Dashboard > Database > Replication.');
          setRealtimeActive(false);
          setShowRealtimeWarning(true);
          setMessages(data);
          lastMessageCountRef.current = data.length;
        }
      }
    }, 10000);

    return () => {
      unsubscribe();
      if (subscriptionTimeout) clearTimeout(subscriptionTimeout);
    };
  }, [streamId, isRealStream]);

  // Fallback polling when Realtime is not active
  useEffect(() => {
    if (!isRealStream || realtimeActive) {
      if (pollingTimerRef.current) {
        clearInterval(pollingTimerRef.current);
        pollingTimerRef.current = null;
      }
      return;
    }

    console.info('[LiveChat] Starting fallback polling every', POLLING_INTERVAL_MS, 'ms');

    const poll = async () => {
      const { data } = await chatService.fetchMessages(streamId);
      if (data) {
        setMessages(prev => {
          // Merge new messages without duplicates
          const existingIds = new Set(prev.map(m => m.id));
          const newMsgs = data.filter(m => !existingIds.has(m.id));
          if (newMsgs.length === 0) return prev;
          return [...prev, ...newMsgs].sort(
            (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
          );
        });
        lastMessageCountRef.current = data.length;
      }
    };

    pollingTimerRef.current = setInterval(poll, POLLING_INTERVAL_MS);

    return () => {
      if (pollingTimerRef.current) {
        clearInterval(pollingTimerRef.current);
        pollingTimerRef.current = null;
      }
    };
  }, [isRealStream, realtimeActive, streamId]);

  // Close mod menu on click outside
  useEffect(() => {
    const handleClickOutside = () => setShowModMenu(null);
    if (showModMenu) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [showModMenu]);

  // Clear ban success message after 3s
  useEffect(() => {
    if (banSuccess) {
      const timer = setTimeout(() => setBanSuccess(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [banSuccess]);

  // Send a message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      setError('Connectez-vous pour participer au chat');
      return;
    }

    if (isBanned) {
      setError('Vous êtes banni de ce chat.');
      return;
    }

    const trimmed = newMessage.trim();
    if (!trimmed) return;

    if (rateLimitWait > 0) {
      setError(`Attendez ${rateLimitWait}s avant d'envoyer un message`);
      return;
    }

    // For demo streams, add message locally
    if (!isRealStream) {
      const mockMsg: ChatMessage = {
        id: `mock-${Date.now()}`,
        stream_id: streamId,
        user_id: user.id,
        message: trimmed,
        display_name: creatorProfile?.display_name || user.email?.split('@')[0] || 'Vous',
        avatar_url: creatorProfile?.avatar_url || null,
        is_deleted: false,
        deleted_by: null,
        created_at: new Date().toISOString(),
      };
      setMessages(prev => [...prev, mockMsg]);
      setNewMessage('');
      return;
    }

    setIsSending(true);
    setError(null);

    const displayName = creatorProfile?.display_name || user.email?.split('@')[0] || 'Anonymous';
    const avatarUrl = creatorProfile?.avatar_url || null;

    const result = await chatService.sendMessage(
      streamId,
      user.id,
      displayName,
      avatarUrl,
      trimmed
    );

    if (result.success) {
      setNewMessage('');
      inputRef.current?.focus();

      // If realtime is not active, immediately fetch to show the sent message
      if (!realtimeActive) {
        setTimeout(async () => {
          const { data } = await chatService.fetchMessages(streamId);
          if (data) {
            setMessages(data);
            lastMessageCountRef.current = data.length;
          }
        }, 300);
      }
    } else {
      setError(result.error || "Erreur lors de l'envoi");
      if (result.isBanned) {
        setIsBanned(true);
      }
      if (result.waitSeconds) {
        setRateLimitWait(result.waitSeconds);
      }
    }

    setIsSending(false);
  };

  // Delete a message (own or moderation)
  const handleDeleteMessage = async (messageId: string) => {
    setShowModMenu(null);

    if (!isRealStream || messageId.startsWith('mock-')) {
      setMessages(prev => prev.filter(msg => msg.id !== messageId));
      return;
    }

    if (!user) return;

    const result = await chatService.deleteMessage(messageId, user.id);
    if (result.success) {
      setMessages(prev => prev.filter(msg => msg.id !== messageId));
    } else {
      setError(result.error || 'Impossible de supprimer le message');
    }
  };

  // Open ban modal for a user
  const handleOpenBanModal = (msg: ChatMessage) => {
    setShowModMenu(null);
    setBanModal({
      isOpen: true,
      targetUserId: msg.user_id,
      targetUserName: msg.display_name,
      reason: '',
      duration: '24h',
    });
  };

  // Calculate expiry date from duration string
  const getExpiryDate = (duration: string): string | null => {
    if (duration === 'permanent') return null;
    const now = new Date();
    switch (duration) {
      case '1h':
        now.setHours(now.getHours() + 1);
        break;
      case '24h':
        now.setHours(now.getHours() + 24);
        break;
      case '7d':
        now.setDate(now.getDate() + 7);
        break;
      case '30d':
        now.setDate(now.getDate() + 30);
        break;
      default:
        now.setHours(now.getHours() + 24);
    }
    return now.toISOString();
  };

  // Execute ban
  const handleBanUser = async () => {
    if (!user || !banModal.targetUserId) return;

    setIsBanning(true);

    const bannedByName = creatorProfile?.display_name || user.email?.split('@')[0] || 'Moderator';
    const expiresAt = getExpiryDate(banModal.duration);

    const result = await chatService.banUser(
      streamId,
      banModal.targetUserId,
      user.id,
      banModal.reason,
      banModal.targetUserName,
      bannedByName,
      expiresAt
    );

    if (result.success) {
      // Log the moderation action
      await teamService.logAction('ban_user', 'user', banModal.targetUserId, {
        banned_user_name: banModal.targetUserName,
        reason: banModal.reason,
        duration: banModal.duration,
        expires_at: expiresAt,
        stream_id: streamId,
      }, streamId);

      setBanSuccess(`${banModal.targetUserName} a été banni du chat`);
      setBanModal({ isOpen: false, targetUserId: '', targetUserName: '', reason: '', duration: '24h' });
    } else {
      setError(result.error || 'Impossible de bannir cet utilisateur');
    }

    setIsBanning(false);
  };

  // Check if user can delete a specific message
  const canDeleteMessage = (msg: ChatMessage): boolean => {
    if (!user) return false;
    if (msg.user_id === user.id) return true;
    if (isModerator) return true;
    return false;
  };

  // Check if user can ban another user (moderator only, can't ban self)
  const canBanUser = (msg: ChatMessage): boolean => {
    if (!user) return false;
    if (msg.user_id === user.id) return false;
    if (isModerator) return true;
    return false;
  };

  // Format timestamp
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Generate avatar color from user id
  const getAvatarColor = (userId: string) => {
    const colors = [
      'bg-purple-500', 'bg-pink-500', 'bg-blue-500', 'bg-green-500',
      'bg-yellow-500', 'bg-red-500', 'bg-indigo-500', 'bg-teal-500',
      'bg-orange-500', 'bg-cyan-500',
    ];
    let hash = 0;
    for (let i = 0; i < userId.length; i++) {
      hash = userId.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  const charCount = newMessage.length;
  const charLimitWarning = charCount > 450;

  const DURATION_LABELS: Record<string, string> = {
    '1h': '1 heure',
    '24h': '24 heures',
    '7d': '7 jours',
    '30d': '30 jours',
    permanent: 'Permanent',
  };

  if (!isExpanded) {
    return (
      <button
        onClick={onToggleExpand}
        className="fixed right-4 bottom-4 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-full shadow-lg flex items-center gap-2 transition-colors z-50"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
        Chat
        {messages.length > 0 && (
          <span className="bg-white text-purple-600 text-xs font-bold px-2 py-0.5 rounded-full">
            {messages.length}
          </span>
        )}
      </button>
    );
  }

  return (
    <div className="flex flex-col h-full bg-gray-900 border-l border-gray-800">
      {/* Ban Modal */}
      {banModal.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-gray-900 border border-gray-700 rounded-xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
            {/* Modal Header */}
            <div className="px-5 py-4 border-b border-gray-700 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                </svg>
              </div>
              <div>
                <h3 className="text-white font-semibold">Bannir un utilisateur</h3>
                <p className="text-gray-400 text-sm">
                  Bannir <span className="text-red-400 font-medium">{banModal.targetUserName}</span> du chat
                </p>
              </div>
            </div>

            {/* Modal Body */}
            <div className="px-5 py-4 space-y-4">
              {/* Reason */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1.5">
                  Raison du bannissement
                </label>
                <textarea
                  value={banModal.reason}
                  onChange={(e) => setBanModal(prev => ({ ...prev, reason: e.target.value }))}
                  placeholder="Spam, contenu inapproprié, harcèlement..."
                  rows={2}
                  className="w-full bg-gray-800 text-white placeholder-gray-500 px-3 py-2 rounded-lg border border-gray-700 focus:border-red-500 focus:ring-1 focus:ring-red-500 focus:outline-none text-sm resize-none"
                />
              </div>

              {/* Duration */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1.5">
                  Durée du bannissement
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(DURATION_LABELS).map(([key, label]) => (
                    <button
                      key={key}
                      onClick={() => setBanModal(prev => ({ ...prev, duration: key }))}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                        banModal.duration === key
                          ? key === 'permanent'
                            ? 'bg-red-600 text-white ring-2 ring-red-400'
                            : 'bg-purple-600 text-white ring-2 ring-purple-400'
                          : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
                {banModal.duration === 'permanent' && (
                  <p className="mt-2 text-xs text-red-400 flex items-center gap-1">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
                    </svg>
                    Ce bannissement est permanent et ne peut être levé que manuellement.
                  </p>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-4 border-t border-gray-700 flex items-center justify-end gap-3">
              <button
                onClick={() => setBanModal({ isOpen: false, targetUserId: '', targetUserName: '', reason: '', duration: '24h' })}
                className="px-4 py-2 text-sm text-gray-300 hover:text-white transition-colors rounded-lg hover:bg-gray-800"
                disabled={isBanning}
              >
                Annuler
              </button>
              <button
                onClick={handleBanUser}
                disabled={isBanning}
                className="px-4 py-2 text-sm bg-red-600 hover:bg-red-700 disabled:bg-red-800 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
              >
                {isBanning ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Bannissement...
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                    </svg>
                    Bannir
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chat Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 flex-shrink-0">
        <div className="flex items-center gap-2">
          <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
          <h3 className="text-white font-semibold text-sm">Chat en direct</h3>
          <span className="text-gray-500 text-xs">({messages.length})</span>
          {!isRealStream && (
            <span className="text-xs bg-yellow-600/20 text-yellow-500 px-2 py-0.5 rounded-full">Demo</span>
          )}
          {isRealStream && !realtimeActive && (
            <span className="text-xs bg-amber-600/20 text-amber-400 px-2 py-0.5 rounded-full flex items-center gap-1" title="Realtime non actif — mode polling">
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Polling
            </span>
          )}
          {isModerator && (
            <span className="text-xs bg-purple-600/20 text-purple-400 px-2 py-0.5 rounded-full flex items-center gap-1">
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              Modérateur
            </span>
          )}
        </div>
        {onToggleExpand && (
          <button
            onClick={onToggleExpand}
            className="text-gray-400 hover:text-white transition-colors p-1"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      {/* Realtime warning banner */}
      {showRealtimeWarning && (
        <div className="px-4 py-3 bg-amber-500/10 border-b border-amber-500/20 flex-shrink-0">
          <div className="flex items-start gap-2">
            <svg className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <div className="flex-1 min-w-0">
              <p className="text-amber-400 text-xs font-medium">Realtime non activé</p>
              <p className="text-amber-400/70 text-[11px] mt-0.5 leading-relaxed">
                Les messages s'affichent avec un délai de ~5s. Pour un chat instantané, activez Realtime pour la table <code className="bg-amber-500/10 px-1 rounded">live_chat_messages</code>.
              </p>
              <a
                href={getReplicationSettingsUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-[11px] text-amber-300 hover:text-amber-200 mt-1 underline"
              >
                Ouvrir Database &gt; Replication
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
              </a>
            </div>
            <button
              onClick={() => setShowRealtimeWarning(false)}
              className="text-amber-400/50 hover:text-amber-400 transition-colors flex-shrink-0"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Ban success notification */}
      {banSuccess && (
        <div className="px-4 py-2 bg-red-500/10 border-b border-red-500/20 flex-shrink-0">
          <p className="text-red-400 text-xs flex items-center gap-1.5">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
            </svg>
            {banSuccess}
          </p>
        </div>
      )}

      {/* Deleted message notification */}
      {deletedMessageId && (
        <div className="px-4 py-2 bg-red-500/10 border-b border-red-500/20 flex-shrink-0">
          <p className="text-red-400 text-xs flex items-center gap-1.5">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
            Un message a été supprimé par un modérateur
          </p>
        </div>
      )}

      {/* Banned user banner */}
      {isBanned && (
        <div className="px-4 py-3 bg-red-900/30 border-b border-red-500/30 flex-shrink-0">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-red-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
            </svg>
            <div>
              <p className="text-red-400 text-sm font-medium">Vous êtes banni de ce chat</p>
              <p className="text-red-400/70 text-xs">Vous ne pouvez plus envoyer de messages dans ce chat.</p>
            </div>
          </div>
        </div>
      )}

      {/* Messages Area */}
      <div
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto px-3 py-2 space-y-2 scroll-smooth"
        style={{ minHeight: 0 }}
      >
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="flex flex-col items-center gap-2">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
              <p className="text-gray-500 text-xs">Chargement du chat...</p>
            </div>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <svg className="w-12 h-12 mb-2 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <p className="text-sm">Aucun message</p>
            <p className="text-xs">Soyez le premier à dire bonjour !</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isOwnMessage = msg.user_id === user?.id;
            const isStreamOwnerMessage = msg.user_id === creatorId ||
              (creatorProfile && msg.user_id === creatorProfile.user_id);

            return (
              <div
                key={msg.id}
                className={`group relative flex gap-2 py-1 px-2 rounded-lg hover:bg-white/5 transition-colors ${
                  isOwnMessage ? 'flex-row-reverse' : ''
                }`}
              >
                {/* Avatar */}
                {msg.avatar_url ? (
                  <img
                    src={msg.avatar_url}
                    alt={msg.display_name}
                    className="w-7 h-7 rounded-full object-cover flex-shrink-0 mt-0.5"
                  />
                ) : (
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5 ${getAvatarColor(msg.user_id)}`}
                  >
                    {(msg.display_name || 'A').charAt(0).toUpperCase()}
                  </div>
                )}

                {/* Message Content */}
                <div
                  className={`flex flex-col max-w-[80%] ${
                    isOwnMessage ? 'items-end' : 'items-start'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className={`text-xs font-semibold ${
                      isStreamOwnerMessage ? 'text-yellow-400' : 'text-purple-400'
                    }`}>
                      {msg.display_name}
                    </span>
                    {isStreamOwnerMessage && (
                      <span className="text-[10px] bg-yellow-500/20 text-yellow-400 px-1.5 py-0 rounded-full font-medium">
                        Créateur
                      </span>
                    )}
                    <span className="text-[10px] text-gray-600">
                      {formatTime(msg.created_at)}
                    </span>
                  </div>
                  <div
                    className={`px-3 py-1.5 rounded-2xl ${
                      isOwnMessage
                        ? 'bg-purple-600 text-white rounded-br-sm'
                        : isStreamOwnerMessage
                        ? 'bg-yellow-500/10 text-gray-100 rounded-bl-sm border border-yellow-500/20'
                        : 'bg-gray-800 text-gray-100 rounded-bl-sm'
                    }`}
                  >
                    <p className="text-sm break-words leading-relaxed">{msg.message}</p>
                  </div>
                </div>

                {/* Moderation / Delete button */}
                {(canDeleteMessage(msg) || canBanUser(msg)) && (
                  <div className="absolute top-0 right-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowModMenu(showModMenu === msg.id ? null : msg.id);
                      }}
                      className="w-6 h-6 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                    >
                      <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="5" r="2" />
                        <circle cx="12" cy="12" r="2" />
                        <circle cx="12" cy="19" r="2" />
                      </svg>
                    </button>

                    {/* Dropdown menu */}
                    {showModMenu === msg.id && (
                      <div
                        className="absolute right-0 top-7 bg-gray-800 border border-gray-700 rounded-lg shadow-xl z-50 py-1 min-w-[180px]"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {/* Delete option */}
                        {canDeleteMessage(msg) && (
                          <button
                            onClick={() => handleDeleteMessage(msg.id)}
                            className="w-full px-3 py-2 text-left text-sm text-red-400 hover:bg-red-500/10 flex items-center gap-2 transition-colors"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                            {isOwnMessage ? 'Supprimer' : 'Supprimer (mod)'}
                          </button>
                        )}

                        {/* Ban option - only for moderators, not for own messages */}
                        {canBanUser(msg) && (
                          <>
                            <div className="border-t border-gray-700 my-1" />
                            <button
                              onClick={() => handleOpenBanModal(msg)}
                              className="w-full px-3 py-2 text-left text-sm text-red-500 hover:bg-red-500/10 flex items-center gap-2 transition-colors font-medium"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                              </svg>
                              Bannir
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Rate limit warning */}
      {rateLimitWait > 0 && (
        <div className="px-4 py-2 bg-amber-500/10 border-t border-amber-500/20 flex-shrink-0">
          <div className="flex items-center gap-2">
            <svg className="w-4 h-4 text-amber-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-amber-400 text-xs">
              Veuillez patienter {rateLimitWait}s avant d'envoyer un nouveau message
            </p>
          </div>
          <div className="mt-1.5 h-1 bg-gray-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-500 rounded-full transition-all duration-1000 ease-linear"
              style={{ width: `${Math.max(0, (1 - rateLimitWait / 10) * 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && !rateLimitWait && (
        <div className="px-4 py-2 bg-red-500/10 border-t border-red-500/20 flex-shrink-0">
          <div className="flex items-center justify-between">
            <p className="text-red-400 text-xs">{error}</p>
            <button
              onClick={() => setError(null)}
              className="text-red-400 hover:text-red-300 ml-2"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Message Input */}
      <div className="p-3 border-t border-gray-800 flex-shrink-0">
        {user ? (
          isBanned ? (
            <div className="text-center py-2">
              <p className="text-red-400/80 text-sm">Vous ne pouvez pas envoyer de messages (banni)</p>
            </div>
          ) : (
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <div className="flex-1 relative">
                <input
                  ref={inputRef}
                  type="text"
                  value={newMessage}
                  onChange={(e) => {
                    setNewMessage(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder={rateLimitWait > 0 ? `Attendez ${rateLimitWait}s...` : 'Envoyer un message...'}
                  maxLength={500}
                  className={`w-full bg-gray-800 text-white placeholder-gray-500 px-4 py-2.5 pr-12 rounded-full border transition-colors text-sm ${
                    rateLimitWait > 0
                      ? 'border-amber-500/30 opacity-60 cursor-not-allowed'
                      : 'border-gray-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500'
                  } focus:outline-none`}
                  disabled={isSending || rateLimitWait > 0}
                />
                {charCount > 0 && (
                  <span className={`absolute right-14 top-1/2 -translate-y-1/2 text-[10px] ${
                    charLimitWarning ? 'text-amber-400' : 'text-gray-600'
                  }`}>
                    {charCount}/500
                  </span>
                )}
              </div>
              <button
                type="submit"
                disabled={isSending || !newMessage.trim() || rateLimitWait > 0}
                className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white px-3 py-2.5 rounded-full transition-colors flex items-center justify-center min-w-[44px]"
              >
                {isSending ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                )}
              </button>
            </form>
          )
        ) : (
          <div className="text-center py-2">
            <p className="text-gray-400 text-sm mb-2">Connectez-vous pour participer au chat</p>
            <button
              onClick={() => {
                const event = new CustomEvent('openAuthModal');
                window.dispatchEvent(event);
              }}
              className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-full text-sm transition-colors"
            >
              Se connecter
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LiveChat;
