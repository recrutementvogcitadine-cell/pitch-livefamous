import React, { useEffect, useState, useRef, Suspense } from 'react';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';
import HomePage from './HomePage';

// Lazy load non-critical components to avoid blocking initial render
const TikTokFeed = React.lazy(() => import('./TikTokFeed'));
const LiveFeed = React.lazy(() => import('./LiveFeed'));
const ReplaysFeed = React.lazy(() => import('./ReplaysFeed'));

type ViewMode = 'home' | 'tiktok' | 'grid' | 'replays';

const LazyFallback = () => (
  <div className="h-screen w-full bg-black flex items-center justify-center">
    <div className="flex flex-col items-center gap-4">
      <div className="w-10 h-10 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
      <span className="text-gray-400 text-sm">Chargement du contenu...</span>
    </div>
  </div>
);

const AppLayout: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('home');
  const [liveCount, setLiveCount] = useState<number>(0);
  const [hasChecked, setHasChecked] = useState(false);
  const [realtimeStatus, setRealtimeStatus] = useState<'connected' | 'disconnected' | 'checking'>('checking');
  const channelRef = useRef<any>(null);

  // Always try to check for live streams
  useEffect(() => {
    // If Supabase isn't configured, skip the check and show homepage immediately
    if (!isSupabaseConfigured) {
      setHasChecked(true);
      setRealtimeStatus('disconnected');
      return;
    }

    const checkLiveStreams = async () => {
      try {
        const { count, error } = await supabase
          .from('live_streams')
          .select('id', { count: 'exact', head: true })
          .eq('is_live', true);

        if (!error && count !== null) {
          setLiveCount(count);
          if (count > 0 && viewMode === 'home') {
            setViewMode('tiktok');
          }
          if (count === 0 && (viewMode === 'tiktok' || viewMode === 'grid')) {
            setViewMode('home');
          }
        }
      } catch {
        // Failed to check — stay on homepage
      } finally {
        setHasChecked(true);
      }
    };

    checkLiveStreams();

    // Subscribe to realtime changes with status tracking
    let realtimeTimeout: ReturnType<typeof setTimeout> | undefined;
    try {
      const channel = supabase
        .channel('app_layout_live_check')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'live_streams' }, () => {
          checkLiveStreams();
        })
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            setRealtimeStatus('connected');
          } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
            setRealtimeStatus('disconnected');
          }
        });

      channelRef.current = channel;

      realtimeTimeout = setTimeout(() => {
        setRealtimeStatus(prev => prev === 'checking' ? 'disconnected' : prev);
      }, 15000);
    } catch {
      setRealtimeStatus('disconnected');
    }

    // Fallback: poll every 30 seconds if realtime is not working
    const pollingInterval = setInterval(() => {
      checkLiveStreams();
    }, 30000);

    return () => {
      if (realtimeTimeout) clearTimeout(realtimeTimeout);
      clearInterval(pollingInterval);
      if (channelRef.current) {
        try { supabase.removeChannel(channelRef.current); } catch { /* ignore */ }
      }
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Listen for auth modal open events from chat component
  useEffect(() => {
    const handleOpenAuthModal = () => {
      const event = new CustomEvent('triggerAuthModal');
      window.dispatchEvent(event);
    };

    window.addEventListener('openAuthModal', handleOpenAuthModal);
    return () => {
      window.removeEventListener('openAuthModal', handleOpenAuthModal);
    };
  }, []);

  // Guarantee hasChecked becomes true (max 2 seconds)
  useEffect(() => {
    if (!hasChecked) {
      const timeout = setTimeout(() => {
        setHasChecked(true);
      }, 2000);
      return () => clearTimeout(timeout);
    }
  }, [hasChecked]);

  // Show loading briefly while checking
  if (!hasChecked) {
    return (
      <div className="h-screen w-full bg-gray-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-500 via-pink-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20 animate-pulse">
            <svg className="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" />
            </svg>
          </div>
          <span className="text-gray-400 text-sm">Chargement...</span>
        </div>
      </div>
    );
  }

  // Show HomePage when no lives are active
  if (viewMode === 'home') {
    return <HomePage />;
  }

  return (
    <div className="h-screen w-full overflow-hidden bg-black relative">
      {/* View Mode Toggle */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-50">
        <div className="bg-black/60 backdrop-blur-md rounded-full p-1 flex gap-1">
          <button
            onClick={() => setViewMode('home')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              viewMode === 'home'
                ? 'bg-white text-black'
                : 'text-white hover:bg-white/20'
            }`}
          >
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
              <span className="hidden sm:inline">Accueil</span>
            </div>
          </button>
          <button
            onClick={() => setViewMode('tiktok')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              viewMode === 'tiktok'
                ? 'bg-white text-black'
                : 'text-white hover:bg-white/20'
            }`}
          >
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
              </svg>
              <span className="hidden sm:inline">Feed</span>
            </div>
          </button>
          <button
            onClick={() => setViewMode('grid')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              viewMode === 'grid'
                ? 'bg-white text-black'
                : 'text-white hover:bg-white/20'
            }`}
          >
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
              <span className="hidden sm:inline">Grille</span>
            </div>
          </button>
          <button
            onClick={() => setViewMode('replays')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              viewMode === 'replays'
                ? 'bg-white text-black'
                : 'text-white hover:bg-white/20'
            }`}
          >
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
              </svg>
              <span className="hidden sm:inline">Replays</span>
            </div>
          </button>
        </div>
      </div>

      {/* Main Content with Suspense for lazy-loaded components */}
      <Suspense fallback={<LazyFallback />}>
        {viewMode === 'tiktok' && <TikTokFeed />}
        {viewMode === 'grid' && <LiveFeed />}
        {viewMode === 'replays' && <ReplaysFeed />}
      </Suspense>
    </div>
  );
};

export default AppLayout;
