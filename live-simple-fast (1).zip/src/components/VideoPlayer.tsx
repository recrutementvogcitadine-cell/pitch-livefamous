import React, { useState, useEffect, useRef, useCallback } from 'react';
import { LiveStream } from '@/data/liveStreams';
import { useAppContext } from '@/contexts/AppContext';
import { useStreamPresence } from '@/hooks/useStreamPresence';
import {
  joinLiveAsViewer,
  leaveLiveAsViewer,
  agoraClient,
  type IAgoraRTCRemoteUser,
} from '@/lib/agoraClient';
import { isValidUUID } from '@/lib/utils';
import FollowButton from './FollowButton';
import LiveChat from './LiveChat';
import StreamingUnavailable from './StreamingUnavailable';

interface VideoPlayerProps {
  stream: LiveStream;
  onClose: () => void;
  onFollowChange?: (isFollowing: boolean) => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ stream, onClose, onFollowChange }) => {
  const { user, creatorProfile } = useAppContext();
  const [showChat, setShowChat] = useState(false);
  const [showViewerList, setShowViewerList] = useState(false);
  const [agoraConnected, setAgoraConnected] = useState(false);
  const [agoraError, setAgoraError] = useState<string | null>(null);
  const [hasRemoteVideo, setHasRemoteVideo] = useState(false);
  const [hasRemoteAudio, setHasRemoteAudio] = useState(false);
  const remoteVideoRef = useRef<HTMLDivElement>(null);

  const isRealStream = isValidUUID(stream.id);

  // Use Presence-based viewer count for real streams, fallback to stream data for demo
  const {
    viewerCount: presenceViewerCount,
    isConnected,
    viewers,
  } = useStreamPresence({
    streamId: stream.id,
    userId: user?.id || null,
    displayName: creatorProfile?.display_name || user?.email?.split('@')[0] || 'Spectateur',
    avatarUrl: creatorProfile?.avatar_url || null,
    isCreator: false,
    enabled: isRealStream,
  });

  // For real streams, use Presence count; for demo streams, use the static value
  const viewerCount = isRealStream && isConnected ? presenceViewerCount : stream.viewerCount;

  // ── Agora RTC Subscriber — Join as viewer for real streams ──
  // Requests a subscriber token from the Edge Function (server-side generation)
  // The App Certificate is NEVER in the frontend — only the token is returned
  const handleRemoteUserJoined = useCallback((remoteUser: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
    if (mediaType === 'video') {
      setHasRemoteVideo(true);
      // Play remote video into the container
      if (remoteVideoRef.current && remoteUser.videoTrack) {
        remoteUser.videoTrack.play(remoteVideoRef.current);
      }
    }
    if (mediaType === 'audio') {
      setHasRemoteAudio(true);
      // Play remote audio (no container needed — plays through speakers)
      if (remoteUser.audioTrack) {
        remoteUser.audioTrack.play();
      }
    }
  }, []);

  const handleRemoteUserLeft = useCallback((uid: number) => {
    // Check if any remote users still have video/audio
    const state = agoraClient.getState();
    const hasVideo = Array.from(state.remoteUsers.values()).some(u => u.videoTrack);
    const hasAudio = Array.from(state.remoteUsers.values()).some(u => u.audioTrack);
    setHasRemoteVideo(hasVideo);
    setHasRemoteAudio(hasAudio);
  }, []);

  useEffect(() => {
    if (!isRealStream || !stream.channelName) return;

    let mounted = true;

    const joinAgora = async () => {
      try {
        // Set up callbacks BEFORE joining so we catch the first user-published event
        agoraClient.setCallbacks({
          onRemoteUserJoined: handleRemoteUserJoined,
          onRemoteUserLeft: handleRemoteUserLeft,
          onStateChange: (state) => {
            if (!mounted) return;
            // Check for existing remote users that may have already published
            const hasVideo = Array.from(state.remoteUsers.values()).some(u => u.videoTrack);
            const hasAudio = Array.from(state.remoteUsers.values()).some(u => u.audioTrack);
            setHasRemoteVideo(hasVideo);
            setHasRemoteAudio(hasAudio);
          },
          onError: (error) => {
            if (mounted) setAgoraError(error);
          },
        });

        const channelInfo = await joinLiveAsViewer(stream.channelName!);
        if (mounted && channelInfo) {
          setAgoraConnected(true);
          console.info('[VideoPlayer] Joined Agora as subscriber — channel:', channelInfo.channelName);
        }
      } catch (err: any) {
        if (mounted) {
          setAgoraError(err.message);
          console.warn('[VideoPlayer] Agora join failed:', err.message);
        }
      }
    };

    joinAgora();

    return () => {
      mounted = false;
      leaveLiveAsViewer();
      agoraClient.setCallbacks({});
    };
  }, [isRealStream, stream.channelName, handleRemoteUserJoined, handleRemoteUserLeft]);

  // When the remote video container mounts and we already have remote users, play their video
  useEffect(() => {
    if (!remoteVideoRef.current || !agoraConnected) return;

    const state = agoraClient.getState();
    for (const remoteUser of state.remoteUsers.values()) {
      if (remoteUser.videoTrack) {
        remoteUser.videoTrack.play(remoteVideoRef.current);
        setHasRemoteVideo(true);
        break; // Play only the first (publisher) video
      }
    }
  }, [agoraConnected]);

  const formatCount = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const openWhatsApp = () => {
    if (!stream.whatsappNumber) return;
    
    const message = encodeURIComponent(`Salut ${stream.creatorName}! Je regarde ton live sur PitchCI`);

    const cleanNumber = stream.whatsappNumber.replace(/[^0-9+]/g, '');
    window.open(`https://wa.me/${cleanNumber}?text=${message}`, '_blank');
  };

  const handleShare = async () => {
    const shareData = {
      title: stream.title,
      text: `Regardez le live de ${stream.creatorName} sur PitchCI!`,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      await navigator.clipboard.writeText(window.location.href);
      alert('Lien copié!');
    }
  };

  // Generate avatar color from user id
  const getAvatarColor = (uid: string) => {
    const colors = [
      'bg-purple-500', 'bg-pink-500', 'bg-blue-500', 'bg-green-500',
      'bg-yellow-500', 'bg-red-500', 'bg-indigo-500', 'bg-teal-500',
      'bg-orange-500', 'bg-cyan-500',
    ];
    let hash = 0;
    for (let i = 0; i < uid.length; i++) {
      hash = uid.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Video Area */}
      <div className="relative flex-1 bg-gray-900">
        {/* Agora remote video container — renders the publisher's video stream */}
        <div
          ref={remoteVideoRef}
          className="absolute inset-0 w-full h-full"
          style={{ background: '#000' }}
        />

        {/* Fallback: show thumbnail if no Agora video is playing */}
        {!hasRemoteVideo && (
          <img
            src={stream.thumbnailUrl}
            alt={stream.title}
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}

        {/* Audio-only indicator */}
        {stream.isAudioOnly && hasRemoteAudio && !hasRemoteVideo && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-gray-900 via-purple-900/20 to-gray-900">
            <div className="w-32 h-32 rounded-full overflow-hidden ring-4 ring-purple-500/50 shadow-2xl shadow-purple-500/20 mb-4">
              <img src={stream.creatorAvatar} alt={stream.creatorName} className="w-full h-full object-cover" />
            </div>
            <p className="text-white text-lg font-bold">{stream.creatorName}</p>
            <div className="mt-4 flex items-center gap-2 bg-purple-500/20 px-4 py-2 rounded-full">
              <svg className="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
              <span className="text-purple-300 text-sm">Live audio en cours</span>
            </div>
            {/* Audio wave animation */}
            <div className="mt-6 flex items-end gap-1 h-8">
              {[...Array(12)].map((_, i) => (
                <div
                  key={i}
                  className="w-1 bg-purple-500 rounded-full animate-pulse"
                  style={{
                    height: `${Math.random() * 100}%`,
                    animationDelay: `${i * 0.1}s`,
                    animationDuration: `${0.5 + Math.random() * 0.5}s`,
                  }}
                />
              ))}
            </div>
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/70 pointer-events-none" />

        {/* Agora connection status indicator */}
        {isRealStream && stream.channelName && (
          <div className="absolute top-14 left-4 z-10">
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium backdrop-blur-sm ${
              agoraConnected
                ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                : agoraError
                ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${
                agoraConnected ? 'bg-green-400' : agoraError ? 'bg-red-400' : 'bg-yellow-400 animate-pulse'
              }`} />
              {agoraConnected ? 'Connecté' : agoraError ? 'Erreur RTC' : 'Connexion...'}
            </div>
          </div>
        )}

        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between safe-area-top z-10">
          <button
            onClick={onClose}
            className="w-10 h-10 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div className="flex items-center gap-2">
            <span className="bg-red-600 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5">
              <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
              LIVE
            </span>

            {/* Viewer count button — clickable to show viewer list */}
            <button
              onClick={() => setShowViewerList(!showViewerList)}
              className="bg-black/50 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5 hover:bg-black/70 transition-colors"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
              </svg>
              {formatCount(viewerCount)}

              {/* Presence connection indicator */}
              {isRealStream && (
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    isConnected ? 'bg-green-400' : 'bg-yellow-400 animate-pulse'
                  }`}
                  title={isConnected ? 'Temps réel actif' : 'Connexion en cours...'}
                />
              )}
            </button>
          </div>
        </div>

        {/* Viewer List Dropdown */}
        {showViewerList && viewers.length > 0 && (
          <div className="absolute top-16 right-4 z-40 w-72 max-h-80 bg-gray-900/95 backdrop-blur-md border border-gray-700 rounded-xl shadow-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                <h4 className="text-white text-sm font-semibold">
                  Spectateurs ({viewers.length})
                </h4>
              </div>
              <button
                onClick={() => setShowViewerList(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="overflow-y-auto max-h-64 py-2">
              {viewers.map((viewer) => (
                <div
                  key={viewer.userId}
                  className="flex items-center gap-3 px-4 py-2 hover:bg-white/5 transition-colors"
                >
                  {viewer.avatarUrl ? (
                    <img
                      src={viewer.avatarUrl}
                      alt={viewer.displayName}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  ) : (
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${getAvatarColor(viewer.userId)}`}
                    >
                      {(viewer.displayName || 'S').charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium truncate">
                      {viewer.displayName}
                    </p>
                    <p className="text-gray-500 text-xs">
                      {viewer.userId === user?.id ? 'Vous' : 'En ligne'}
                    </p>
                  </div>
                  <span className="w-2 h-2 bg-green-400 rounded-full flex-shrink-0" />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Right Side Actions */}
        <div className="absolute right-4 bottom-32 flex flex-col items-center gap-5 z-10">
          {/* Creator Avatar */}
          <div className="relative">
            <img
              src={stream.creatorAvatar}
              alt={stream.creatorName}
              className="w-12 h-12 rounded-full border-2 border-white object-cover"
            />
            <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
              <FollowButton
                creatorId={stream.creatorId}
                creatorName={stream.creatorName}
                followerCount={stream.followerCount}
                size="icon"
                onFollowChange={onFollowChange}
              />
            </div>
          </div>

          {/* WhatsApp Button - Prominent */}
          {stream.whatsappNumber && (
            <button
              onClick={openWhatsApp}
              className="flex flex-col items-center gap-1 group"
            >
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </div>
              <span className="text-white text-xs font-medium drop-shadow-lg">WhatsApp</span>
            </button>
          )}

          {/* Chat Toggle */}
          <button
            onClick={() => setShowChat(!showChat)}
            className="flex flex-col items-center gap-1 group"
          >
            <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-colors ${
              showChat ? 'bg-purple-500' : 'bg-black/40 backdrop-blur-sm group-hover:bg-black/60'
            }`}>
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </div>
            <span className="text-white text-xs font-medium drop-shadow-lg">Chat</span>
          </button>

          {/* Share */}
          <button
            onClick={handleShare}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="w-12 h-12 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg group-hover:bg-black/60 transition-colors">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
            </div>
            <span className="text-white text-xs font-medium drop-shadow-lg">Partager</span>
          </button>
        </div>

        {/* Bottom Info */}
        <div className="absolute bottom-0 left-0 right-20 p-4 pb-8 safe-area-bottom z-10">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-white font-bold text-base drop-shadow-lg">
              @{stream.creatorName?.replace(/\s+/g, '').toLowerCase()}
            </span>
          </div>
          <h2 className="text-white font-semibold text-lg mb-2 drop-shadow-lg line-clamp-2">
            {stream.title}
          </h2>
        </div>
      </div>

      {/* Chat Overlay */}
      {showChat && (
        <div className="absolute inset-0 z-30 bg-black/50 backdrop-blur-sm">
          <div className="absolute bottom-0 left-0 right-0 h-[70%] bg-gray-900 rounded-t-3xl overflow-hidden flex flex-col">
            {/* Chat header with close button */}
            <div className="flex items-center justify-between p-4 border-b border-gray-800 flex-shrink-0">
              <div className="flex items-center gap-2">
                <h3 className="text-white font-semibold">Chat en direct</h3>
                <div className="flex items-center gap-1.5 bg-green-500/10 px-2 py-0.5 rounded-full">
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    isConnected ? 'bg-green-500' : 'bg-yellow-500'
                  } animate-pulse`}></span>
                  <span className="text-green-400 text-xs font-medium">
                    {formatCount(viewerCount)} en ligne
                  </span>
                </div>
              </div>
              <button
                onClick={() => setShowChat(false)}
                className="w-8 h-8 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center transition-colors"
              >
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            {/* Chat component fills remaining space */}
            <div className="flex-1 overflow-hidden">
              <LiveChat
                streamId={stream.id}
                creatorId={stream.creatorId}
                isExpanded={true}
                onToggleExpand={() => setShowChat(false)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoPlayer;
