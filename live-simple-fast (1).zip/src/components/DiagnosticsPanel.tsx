import React, { useState, useCallback } from 'react';
import { supabase, isSupabaseConfigured, getConfigDiagnostics, getReplicationSettingsUrl } from '@/lib/supabase';


// ============================================================================
// TYPES
// ============================================================================

type TestStatus = 'idle' | 'running' | 'success' | 'warning' | 'error';

interface TestResult {
  id: string;
  category: string;
  name: string;
  description: string;
  status: TestStatus;
  message: string;
  duration?: number;
  details?: string;
}

interface CategoryResult {
  id: string;
  label: string;
  icon: React.ReactNode;
  description: string;
  tests: TestResult[];
  overallStatus: TestStatus;
}

// ============================================================================
// TABLES TO CHECK
// ============================================================================

const EXPECTED_TABLES = [
  'creator_profiles',
  'live_streams',
  'stream_recordings',
  'chat_messages',
  'follows',
  'subscriptions',
  'payments',
  'admin_users',
  'team_members',
  'verification_requests',
  'moderation_logs',
  'notification_preferences',
  'support_requests',
];

const EXPECTED_BUCKETS = ['avatars', 'streams', 'recordings'];

// ============================================================================
// ICONS
// ============================================================================

const DatabaseIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
  </svg>
);

const TableIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);

const ShieldIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
);

const StorageIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
  </svg>
);

const RealtimeIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
);

const CloudIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
  </svg>
);

const VideoIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);

const RefreshIcon = ({ spinning }: { spinning?: boolean }) => (
  <svg className={`w-5 h-5 ${spinning ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
  </svg>
);

const CheckCircleIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const XCircleIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const WarningIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
  </svg>
);

const ClockIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const ChevronIcon = ({ open }: { open: boolean }) => (
  <svg className={`w-4 h-4 transition-transform duration-200 ${open ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
  </svg>
);

// ============================================================================
// STATUS HELPERS
// ============================================================================

const statusConfig: Record<TestStatus, { color: string; bg: string; border: string; label: string; dotColor: string }> = {
  idle: { color: 'text-gray-400', bg: 'bg-gray-800/50', border: 'border-gray-700/50', label: 'En attente', dotColor: 'bg-gray-500' },
  running: { color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20', label: 'En cours...', dotColor: 'bg-blue-500 animate-pulse' },
  success: { color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', label: 'OK', dotColor: 'bg-emerald-500' },
  warning: { color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', label: 'Attention', dotColor: 'bg-amber-500' },
  error: { color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20', label: 'Erreur', dotColor: 'bg-red-500' },
};

function getOverallStatus(tests: TestResult[]): TestStatus {
  if (tests.some(t => t.status === 'running')) return 'running';
  if (tests.every(t => t.status === 'idle')) return 'idle';
  if (tests.some(t => t.status === 'error')) return 'error';
  if (tests.some(t => t.status === 'warning')) return 'warning';
  if (tests.every(t => t.status === 'success')) return 'success';
  return 'idle';
}

// ============================================================================
// COMPONENT
// ============================================================================

const DiagnosticsPanel: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [lastRun, setLastRun] = useState<Date | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [categories, setCategories] = useState<CategoryResult[]>(getInitialCategories());

  function getInitialCategories(): CategoryResult[] {
    return [
      {
        id: 'connection',
        label: 'Connexion Supabase',
        icon: <DatabaseIcon />,
        description: 'Vérification de la connexion au serveur de base de données',
        tests: [
          { id: 'config', category: 'connection', name: 'Configuration', description: 'Variables d\'environnement VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY', status: 'idle', message: '' },
          { id: 'ping', category: 'connection', name: 'Ping serveur', description: 'Connexion HTTP au serveur Supabase', status: 'idle', message: '' },
          { id: 'auth', category: 'connection', name: 'Service Auth', description: 'Vérification du service d\'authentification', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
      },
      {
        id: 'tables',
        label: 'Accès aux tables',
        icon: <TableIcon />,
        description: 'Vérification de l\'existence et de l\'accès aux 13 tables requises',
        tests: EXPECTED_TABLES.map(table => ({
          id: `table_${table}`,
          category: 'tables',
          name: table,
          description: `SELECT sur la table ${table}`,
          status: 'idle' as TestStatus,
          message: '',
        })),
        overallStatus: 'idle',
      },
      {
        id: 'rls',
        label: 'Row Level Security (RLS)',
        icon: <ShieldIcon />,
        description: 'Vérification que les politiques de sécurité sont actives',
        tests: [
          { id: 'rls_enabled', category: 'rls', name: 'RLS activé', description: 'Vérification que RLS est activé sur les tables', status: 'idle', message: '' },
          { id: 'rls_policies', category: 'rls', name: 'Politiques RLS', description: 'Vérification que les policies sont en place', status: 'idle', message: '' },
          { id: 'rls_anon_block', category: 'rls', name: 'Protection anonyme', description: 'Les utilisateurs non connectés ne peuvent pas écrire', status: 'idle', message: '' },
          { id: 'rls_read_access', category: 'rls', name: 'Lecture publique', description: 'Les profils créateurs sont lisibles publiquement', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
      },
      {
        id: 'storage',
        label: 'Storage Buckets',
        icon: <StorageIcon />,
        description: 'Vérification des buckets de stockage (avatars, streams, recordings)',
        tests: EXPECTED_BUCKETS.map(bucket => ({
          id: `bucket_${bucket}`,
          category: 'storage',
          name: bucket,
          description: `Bucket "${bucket}" existe et est accessible`,
          status: 'idle' as TestStatus,
          message: '',
        })),
        overallStatus: 'idle',
      },
      {
        id: 'realtime',
        label: 'Realtime',
        icon: <RealtimeIcon />,
        description: 'Vérification de la connexion WebSocket et de la réplication temps réel',
        tests: [
          { id: 'rt_connect', category: 'realtime', name: 'Connexion WebSocket', description: 'Établissement de la connexion Realtime', status: 'idle', message: '' },
          { id: 'rt_subscribe', category: 'realtime', name: 'Souscription canal', description: 'Capacité à souscrire à un canal de test', status: 'idle', message: '' },
          { id: 'rt_tables', category: 'realtime', name: 'Tables Realtime', description: 'Vérification que live_chat_messages, live_streams et follows sont dans la publication Realtime', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
      },
      {
        id: 'edge_functions',
        label: 'Edge Functions',
        icon: <CloudIcon />,
        description: 'Vérification des Edge Functions Supabase (manage-live, generate-agora-token)',
        tests: [
          { id: 'ef_manage_live', category: 'edge_functions', name: 'manage-live', description: 'Health check de la fonction manage-live', status: 'idle', message: '' },
          { id: 'ef_generate_token', category: 'edge_functions', name: 'generate-agora-token', description: 'Health check de la fonction generate-agora-token', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
      },
      {
        id: 'agora',
        label: 'Agora Live Streaming',
        icon: <VideoIcon />,
        description: 'Vérification de la configuration Agora (App ID, Certificate, tokens)',
        tests: [
          { id: 'agora_app_id', category: 'agora', name: 'AGORA_APP_ID', description: 'Secret AGORA_APP_ID configuré dans les Edge Functions', status: 'idle', message: '' },
          { id: 'agora_certificate', category: 'agora', name: 'AGORA_APP_CERTIFICATE', description: 'Secret AGORA_APP_CERTIFICATE configuré dans les Edge Functions', status: 'idle', message: '' },
          { id: 'agora_env_vars', category: 'agora', name: 'Variables d\'environnement', description: 'Liste complète des variables disponibles dans les Edge Functions', status: 'idle', message: '' },
          { id: 'agora_db_column', category: 'agora', name: 'Colonne channel_name', description: 'Colonne channel_name dans la table live_streams', status: 'idle', message: '' },
        ],
        overallStatus: 'idle',
      },
    ];
  }


  const updateTest = useCallback((categoryId: string, testId: string, update: Partial<TestResult>) => {
    setCategories(prev => prev.map(cat => {
      if (cat.id !== categoryId) return cat;
      const updatedTests = cat.tests.map(t => t.id === testId ? { ...t, ...update } : t);
      return { ...cat, tests: updatedTests, overallStatus: getOverallStatus(updatedTests) };
    }));
  }, []);

  const setAllRunning = useCallback((categoryId: string) => {
    setCategories(prev => prev.map(cat => {
      if (cat.id !== categoryId) return cat;
      const updatedTests = cat.tests.map(t => ({ ...t, status: 'running' as TestStatus, message: 'Test en cours...' }));
      return { ...cat, tests: updatedTests, overallStatus: 'running' };
    }));
  }, []);

  // ---- TEST RUNNERS ----

  const runConnectionTests = async () => {
    setAllRunning('connection');
    const diag = getConfigDiagnostics();

    // Test 1: Configuration
    const configStart = performance.now();
    if (diag.isConfigured) {
      updateTest('connection', 'config', {
        status: 'success',
        message: `URL: ${diag.url} | Clé: ${diag.keyLength} caractères`,
        duration: Math.round(performance.now() - configStart),
      });
    } else {
      updateTest('connection', 'config', {
        status: 'error',
        message: 'Variables d\'environnement manquantes ou invalides',
        duration: Math.round(performance.now() - configStart),
        details: `URL vide: ${diag.urlEmpty} | Clé vide: ${diag.keyEmpty} | URL valide: ${diag.hasRealUrl} | Clé valide: ${diag.hasRealKey}\n\nSolution: Copiez .env.example en .env et ajoutez vos clés Supabase.`,
      });
      updateTest('connection', 'ping', { status: 'error', message: 'Test ignoré — configuration manquante' });
      updateTest('connection', 'auth', { status: 'error', message: 'Test ignoré — configuration manquante' });
      return;
    }

    // Test 2: Ping
    const pingStart = performance.now();
    try {
      const { error } = await supabase.from('creator_profiles').select('id', { count: 'exact', head: true });
      const pingDuration = Math.round(performance.now() - pingStart);
      if (error && error.code !== '42P01' && error.code !== '42501') {
        updateTest('connection', 'ping', {
          status: 'error',
          message: `Erreur: ${error.message}`,
          duration: pingDuration,
          details: `Code: ${error.code}\nHint: ${error.hint || 'N/A'}\nDetails: ${error.details || 'N/A'}`,
        });
      } else {
        updateTest('connection', 'ping', {
          status: 'success',
          message: `Serveur accessible (${pingDuration}ms)`,
          duration: pingDuration,
        });
      }
    } catch (err: any) {
      updateTest('connection', 'ping', {
        status: 'error',
        message: `Impossible de joindre le serveur: ${err?.message || 'Erreur réseau'}`,
        duration: Math.round(performance.now() - pingStart),
        details: 'Vérifiez que votre URL Supabase est correcte et que le projet est actif.',
      });
    }

    // Test 3: Auth service
    const authStart = performance.now();
    try {
      const { data, error } = await supabase.auth.getSession();
      const authDuration = Math.round(performance.now() - authStart);
      if (error) {
        updateTest('connection', 'auth', {
          status: 'warning',
          message: `Service auth accessible mais erreur: ${error.message}`,
          duration: authDuration,
        });
      } else {
        const sessionInfo = data.session ? `Session active (${data.session.user.email})` : 'Aucune session active';
        updateTest('connection', 'auth', {
          status: 'success',
          message: `Service d'authentification opérationnel — ${sessionInfo}`,
          duration: authDuration,
        });
      }
    } catch (err: any) {
      updateTest('connection', 'auth', {
        status: 'error',
        message: `Service d'authentification inaccessible: ${err?.message}`,
        duration: Math.round(performance.now() - authStart),
      });
    }
  };

  const runTableTests = async () => {
    setAllRunning('tables');

    for (const table of EXPECTED_TABLES) {
      const testId = `table_${table}`;
      const start = performance.now();
      try {
        const { data, error, count } = await supabase.from(table).select('*', { count: 'exact', head: true });
        const duration = Math.round(performance.now() - start);

        if (error) {
          if (error.code === '42P01') {
            updateTest('tables', testId, {
              status: 'error',
              message: `Table "${table}" n'existe pas`,
              duration,
              details: `La table n'a pas été créée. Exécutez le script database-setup.sql dans le SQL Editor de Supabase.\n\nErreur: ${error.message}`,
            });
          } else if (error.code === '42501') {
            updateTest('tables', testId, {
              status: 'warning',
              message: `Table existe mais accès refusé par RLS (normal si non connecté)`,
              duration,
            });
          } else {
            updateTest('tables', testId, {
              status: 'error',
              message: `Erreur: ${error.message}`,
              duration,
              details: `Code: ${error.code}\nHint: ${error.hint || 'N/A'}`,
            });
          }
        } else {
          updateTest('tables', testId, {
            status: 'success',
            message: `Table accessible — ${count ?? 0} enregistrement(s)`,
            duration,
          });
        }
      } catch (err: any) {
        updateTest('tables', testId, {
          status: 'error',
          message: `Exception: ${err?.message || 'Erreur inconnue'}`,
          duration: Math.round(performance.now() - start),
        });
      }
    }
  };

  const runRLSTests = async () => {
    setAllRunning('rls');

    // Test 1: RLS enabled
    const rlsStart = performance.now();
    try {
      // Use wildcard select to avoid column-not-found errors on incomplete schemas
      const { data, error } = await supabase.from('team_members').select('*').limit(1);
      const duration = Math.round(performance.now() - rlsStart);

      if (error) {
        if (error.code === '42P01') {
          updateTest('rls', 'rls_enabled', { status: 'error', message: 'Table team_members n\'existe pas — exécutez database-setup.sql', duration });
        } else if (error.code === '42501') {
          updateTest('rls', 'rls_enabled', { status: 'success', message: 'RLS est activé — accès correctement restreint', duration });
        } else if (error.code === '42703') {
          updateTest('rls', 'rls_enabled', { status: 'warning', message: `Table team_members existe mais colonnes manquantes — lancez la migration`, duration, details: `Erreur: ${error.message}\n\nSolution: Allez sur /setup > Base de données pour lancer la migration.` });
        } else {
          updateTest('rls', 'rls_enabled', { status: 'warning', message: `Réponse inattendue: ${error.message}`, duration, details: `Code: ${error.code}` });
        }
      } else {
        const { data: session } = await supabase.auth.getSession();
        if (!session.session && data && data.length > 0) {
          updateTest('rls', 'rls_enabled', { status: 'error', message: 'ATTENTION: Données accessibles sans authentification — RLS peut être désactivé!', duration, details: 'Les données de team_members sont accessibles sans connexion.' });
        } else {
          updateTest('rls', 'rls_enabled', { status: 'success', message: data?.length ? `RLS actif — ${data.length} enregistrement(s) visibles` : 'RLS actif — aucune donnée visible (filtrage correct)', duration });
        }
      }

    } catch (err: any) {
      updateTest('rls', 'rls_enabled', { status: 'error', message: `Erreur: ${err?.message}`, duration: Math.round(performance.now() - rlsStart) });
    }

    // Test 2: Policies count
    const policiesStart = performance.now();
    try {
      const tables = ['creator_profiles', 'payments', 'verification_requests', 'moderation_logs'];
      const results: string[] = [];
      for (const table of tables) {
        const { error } = await supabase.from(table).select('id', { count: 'exact', head: true });
        if (error && error.code === '42P01') results.push(`${table}: MANQUANTE`);
        else if (error && error.code === '42501') results.push(`${table}: protégée (RLS)`);
        else results.push(`${table}: accessible`);
      }
      const hasErrors = results.some(r => r.includes('MANQUANTE'));
      updateTest('rls', 'rls_policies', { status: hasErrors ? 'error' : 'success', message: hasErrors ? 'Certaines tables sont manquantes' : 'Politiques RLS détectées sur les tables critiques', duration: Math.round(performance.now() - policiesStart), details: results.join('\n') });
    } catch (err: any) {
      updateTest('rls', 'rls_policies', { status: 'error', message: `Erreur: ${err?.message}`, duration: Math.round(performance.now() - policiesStart) });
    }

    // Test 3: Anonymous write protection
    const anonStart = performance.now();
    try {
      const { error } = await supabase.from('creator_profiles').insert({ user_id: '00000000-0000-0000-0000-000000000000', username: '__diagnostic_test__', display_name: 'Test' });
      const duration = Math.round(performance.now() - anonStart);
      if (error) {
        updateTest('rls', 'rls_anon_block', { status: 'success', message: 'Écriture anonyme correctement bloquée par RLS', duration, details: `Erreur retournée (attendue): ${error.message}` });
      } else {
        await supabase.from('creator_profiles').delete().eq('username', '__diagnostic_test__');
        updateTest('rls', 'rls_anon_block', { status: 'error', message: 'CRITIQUE: Écriture anonyme NON bloquée — RLS mal configuré!', duration });
      }
    } catch (err: any) {
      updateTest('rls', 'rls_anon_block', { status: 'warning', message: `Test non concluant: ${err?.message}`, duration: Math.round(performance.now() - anonStart) });
    }

    // Test 4: Public read access
    const readStart = performance.now();
    try {
      const { data, error } = await supabase.from('creator_profiles').select('id, username, display_name').limit(5);
      const duration = Math.round(performance.now() - readStart);
      if (error) {
        if (error.code === '42P01') updateTest('rls', 'rls_read_access', { status: 'error', message: 'Table creator_profiles n\'existe pas', duration });
        else updateTest('rls', 'rls_read_access', { status: 'warning', message: `Lecture publique restreinte: ${error.message}`, duration });
      } else {
        updateTest('rls', 'rls_read_access', { status: 'success', message: `Lecture publique OK — ${data?.length ?? 0} profil(s) lisibles`, duration });
      }
    } catch (err: any) {
      updateTest('rls', 'rls_read_access', { status: 'error', message: `Erreur: ${err?.message}`, duration: Math.round(performance.now() - readStart) });
    }
  };

  const runStorageTests = async () => {
    setAllRunning('storage');

    for (const bucket of EXPECTED_BUCKETS) {
      const testId = `bucket_${bucket}`;
      const start = performance.now();
      try {
        const { data, error } = await supabase.storage.from(bucket).list('', { limit: 1 });
        const duration = Math.round(performance.now() - start);
        if (error) {
          const errMsg = typeof error === 'object' && 'message' in error ? (error as any).message : String(error);
          if (errMsg.includes('not found') || errMsg.includes('Bucket not found')) {
            updateTest('storage', testId, { status: 'error', message: `Bucket "${bucket}" n'existe pas`, duration, details: `Créez le bucket dans Dashboard > Storage > New bucket > "${bucket}"` });
          } else {
            updateTest('storage', testId, { status: 'warning', message: `Bucket existe mais erreur d'accès: ${errMsg}`, duration });
          }
        } else {
          updateTest('storage', testId, { status: 'success', message: `Bucket "${bucket}" accessible — ${data?.length ?? 0} fichier(s)`, duration });
        }
      } catch (err: any) {
        updateTest('storage', testId, { status: 'error', message: `Exception: ${err?.message || 'Erreur inconnue'}`, duration: Math.round(performance.now() - start) });
      }
    }
  };

  const runRealtimeTests = async () => {
    setAllRunning('realtime');

    // Test 1: WebSocket connection
    const wsStart = performance.now();
    try {
      const channel = supabase.channel('diagnostics-test-' + Date.now());
      const connectionPromise = new Promise<{ status: TestStatus; message: string }>((resolve) => {
        const timeout = setTimeout(() => resolve({ status: 'warning', message: 'Connexion WebSocket lente (timeout 5s)' }), 5000);
        channel.subscribe((status) => {
          clearTimeout(timeout);
          if (status === 'SUBSCRIBED') resolve({ status: 'success', message: 'Connexion WebSocket établie' });
          else if (status === 'CHANNEL_ERROR') resolve({ status: 'error', message: 'Erreur connexion canal WebSocket' });
          else if (status === 'TIMED_OUT') resolve({ status: 'error', message: 'Timeout connexion WebSocket' });
          else if (status === 'CLOSED') resolve({ status: 'warning', message: 'Canal WebSocket fermé prématurément' });
        });
      });

      const result = await connectionPromise;
      updateTest('realtime', 'rt_connect', { ...result, duration: Math.round(performance.now() - wsStart) });

      const subStart = performance.now();
      updateTest('realtime', 'rt_subscribe', {
        status: result.status === 'success' ? 'success' : result.status,
        message: result.status === 'success' ? 'Souscription au canal réussie' : `Souscription non testée — connexion ${result.status}`,
        duration: Math.round(performance.now() - subStart),
      });

      await supabase.removeChannel(channel);
    } catch (err: any) {
      updateTest('realtime', 'rt_connect', { status: 'error', message: `Erreur WebSocket: ${err?.message}`, duration: Math.round(performance.now() - wsStart) });
      updateTest('realtime', 'rt_subscribe', { status: 'error', message: 'Test ignoré — connexion échouée', duration: 0 });
    }

    // Test 3: Table-level Realtime
    const rtTablesStart = performance.now();
    const REALTIME_TABLES = ['live_chat_messages', 'live_streams', 'follows'];
    try {
      const results: string[] = [];
      let allOk = true;
      for (const table of REALTIME_TABLES) {
        const testChannel = supabase.channel(`rt-test-${table}-${Date.now()}`);
        const subResult = await new Promise<{ ok: boolean; msg: string }>((resolve) => {
          const timeout = setTimeout(() => resolve({ ok: false, msg: `${table}: timeout` }), 4000);
          testChannel.on('postgres_changes', { event: '*', schema: 'public', table }, () => {}).subscribe((status) => {
            clearTimeout(timeout);
            if (status === 'SUBSCRIBED') resolve({ ok: true, msg: `${table}: OK` });
            else if (status === 'CHANNEL_ERROR') resolve({ ok: false, msg: `${table}: erreur canal` });
            else if (status === 'TIMED_OUT') resolve({ ok: false, msg: `${table}: timeout` });
          });
        });
        results.push(subResult.msg);
        if (!subResult.ok) allOk = false;
        try { await supabase.removeChannel(testChannel); } catch { /* ignore */ }
      }

      const replicationUrl = getReplicationSettingsUrl();
      updateTest('realtime', 'rt_tables', {
        status: allOk ? 'success' : 'warning',
        message: allOk ? `Les 3 tables sont dans la publication Realtime` : 'Certaines tables ne sont pas dans la publication Realtime',
        duration: Math.round(performance.now() - rtTablesStart),
        details: results.join('\n') + (allOk ? '' : `\n\nSolution: Dashboard > Database > Replication\n${replicationUrl}`),
      });
    } catch (err: any) {
      updateTest('realtime', 'rt_tables', { status: 'error', message: `Erreur: ${err?.message}`, duration: Math.round(performance.now() - rtTablesStart) });
    }
  };

  // ---- EDGE FUNCTIONS & AGORA TESTS ----

  const runEdgeFunctionTests = async () => {
    setAllRunning('edge_functions');

    // Test manage-live health check
    const mlStart = performance.now();
    try {
      const { data, error } = await supabase.functions.invoke('manage-live', {
        body: { action: 'health_check' },
      });
      const duration = Math.round(performance.now() - mlStart);

      if (error) {
        updateTest('edge_functions', 'ef_manage_live', {
          status: 'error',
          message: `Erreur: ${error.message}`,
          duration,
          details: `La fonction manage-live n'est pas accessible.\nVérifiez qu'elle est déployée dans Dashboard > Edge Functions.`,
        });
      } else if (data) {
        const version = data.version || 'inconnue';
        const supabaseOk = data.supabase_url_configured && data.service_role_key_configured;
        updateTest('edge_functions', 'ef_manage_live', {
          status: supabaseOk ? 'success' : 'warning',
          message: `Fonction opérationnelle — v${version}${supabaseOk ? '' : ' (config Supabase incomplète)'}`,
          duration,
          details: `Version: ${version}\nSUPABASE_URL: ${data.supabase_url_configured ? 'OK' : 'MANQUANT'}\nSERVICE_ROLE_KEY: ${data.service_role_key_configured ? 'OK' : 'MANQUANT'}\nAGORA_APP_ID: ${data.agora_app_id_configured ? 'OK' : 'MANQUANT'}\nAGORA_CERTIFICATE: ${data.agora_certificate_configured ? 'OK' : 'MANQUANT'}\nEnv vars: ${(data.all_env_keys || []).join(', ')}`,
        });
      } else {
        updateTest('edge_functions', 'ef_manage_live', {
          status: 'warning',
          message: 'Réponse vide de la fonction',
          duration,
        });
      }
    } catch (err: any) {
      updateTest('edge_functions', 'ef_manage_live', {
        status: 'error',
        message: `Exception: ${err?.message || 'Erreur inconnue'}`,
        duration: Math.round(performance.now() - mlStart),
      });
    }

    // Test generate-agora-token health check
    const gatStart = performance.now();
    try {
      const { data, error } = await supabase.functions.invoke('generate-agora-token', {
        body: { action: 'health_check' },
      });
      const duration = Math.round(performance.now() - gatStart);

      if (error) {
        updateTest('edge_functions', 'ef_generate_token', {
          status: 'error',
          message: `Erreur: ${error.message}`,
          duration,
          details: `La fonction generate-agora-token n'est pas accessible.`,
        });
      } else if (data) {
        const version = data.version || 'inconnue';
        updateTest('edge_functions', 'ef_generate_token', {
          status: 'success',
          message: `Fonction opérationnelle — v${version}`,
          duration,
          details: `Version: ${version}\nAGORA_APP_ID: ${data.agora_app_id_configured ? `OK (${data.agora_app_id_length} chars)` : 'MANQUANT'}\nAGORA_CERTIFICATE: ${data.agora_certificate_configured ? `OK (${data.agora_certificate_length} chars)` : 'MANQUANT'}`,
        });
      } else {
        updateTest('edge_functions', 'ef_generate_token', { status: 'warning', message: 'Réponse vide', duration });
      }
    } catch (err: any) {
      updateTest('edge_functions', 'ef_generate_token', {
        status: 'error',
        message: `Exception: ${err?.message || 'Erreur inconnue'}`,
        duration: Math.round(performance.now() - gatStart),
      });
    }
  };

  const runAgoraTests = async () => {
    setAllRunning('agora');

    // Get health check data from manage-live (which has the most complete info)
    let healthData: any = null;
    const hcStart = performance.now();
    try {
      const { data, error } = await supabase.functions.invoke('manage-live', {
        body: { action: 'health_check' },
      });
      if (!error && data) healthData = data;
    } catch { /* ignore */ }
    const hcDuration = Math.round(performance.now() - hcStart);

    // Test 1: AGORA_APP_ID
    if (healthData) {
      const appIdConfigured = healthData.agora_app_id_configured;
      const appIdLength = healthData.agora_app_id_length || 0;
      updateTest('agora', 'agora_app_id', {
        status: appIdConfigured ? 'success' : 'error',
        message: appIdConfigured
          ? `AGORA_APP_ID configuré (${appIdLength} caractères)`
          : 'AGORA_APP_ID NON CONFIGURÉ — Le live streaming ne fonctionnera pas',
        duration: hcDuration,
        details: appIdConfigured
          ? `Longueur: ${appIdLength} caractères\nPrévisualisation: ${healthData.agora_app_id_preview || 'N/A'}`
          : `Le secret AGORA_APP_ID n'est PAS dans les variables d'environnement des Edge Functions.\n\nVariables disponibles: ${(healthData.all_env_keys || []).join(', ')}\n\n--- SOLUTION ---\n1. Allez sur console.agora.io\n2. Sélectionnez votre projet\n3. Copiez l'App ID\n4. Dans le Dashboard Supabase:\n   - Allez dans Edge Functions > Secrets\n   - Si AGORA_APP_ID existe, SUPPRIMEZ-LE\n   - Recréez-le avec la valeur copiée\n   - Cliquez "Save"\n5. Redéployez les Edge Functions`,
      });

      // Test 2: AGORA_APP_CERTIFICATE
      const certConfigured = healthData.agora_certificate_configured;
      const certLength = healthData.agora_certificate_length || 0;
      updateTest('agora', 'agora_certificate', {
        status: certConfigured ? 'success' : 'error',
        message: certConfigured
          ? `AGORA_APP_CERTIFICATE configuré (${certLength} caractères)`
          : 'AGORA_APP_CERTIFICATE NON CONFIGURÉ — Le live streaming ne fonctionnera pas',
        duration: hcDuration,
        details: certConfigured
          ? `Longueur: ${certLength} caractères`
          : `Le secret AGORA_APP_CERTIFICATE n'est PAS dans les variables d'environnement des Edge Functions.\n\n--- SOLUTION ---\n1. Allez sur console.agora.io\n2. Sélectionnez votre projet\n3. Copiez le Primary Certificate (App Certificate)\n4. Dans le Dashboard Supabase:\n   - Allez dans Edge Functions > Secrets\n   - Si AGORA_APP_CERTIFICATE existe, SUPPRIMEZ-LE\n   - Recréez-le avec la valeur copiée\n   - Cliquez "Save"\n5. Redéployez les Edge Functions`,
      });

      // Test 3: Environment variables list
      const envKeys = healthData.all_env_keys || [];
      const hasAgora = envKeys.includes('AGORA_APP_ID') && envKeys.includes('AGORA_APP_CERTIFICATE');
      updateTest('agora', 'agora_env_vars', {
        status: hasAgora ? 'success' : 'error',
        message: hasAgora
          ? `${envKeys.length} variables d'environnement disponibles (Agora inclus)`
          : `${envKeys.length} variables disponibles — AGORA_APP_ID et AGORA_APP_CERTIFICATE ABSENTS`,
        duration: hcDuration,
        details: `Variables d'environnement dans les Edge Functions:\n${envKeys.map((k: string) => `  - ${k}`).join('\n')}\n\n${hasAgora ? 'Les secrets Agora sont correctement injectés.' : 'PROBLÈME: Les secrets Agora ne sont PAS injectés dans le runtime des Edge Functions.\n\nCela signifie que les secrets existent peut-être dans les métadonnées mais ne sont pas réellement accessibles.\n\nSolution: Supprimez et recréez les secrets dans Dashboard > Edge Functions > Secrets.'}`,
      });
    } else {
      updateTest('agora', 'agora_app_id', { status: 'error', message: 'Impossible de vérifier — Edge Function inaccessible', duration: hcDuration });
      updateTest('agora', 'agora_certificate', { status: 'error', message: 'Impossible de vérifier — Edge Function inaccessible', duration: hcDuration });
      updateTest('agora', 'agora_env_vars', { status: 'error', message: 'Impossible de vérifier — Edge Function inaccessible', duration: hcDuration });
    }

    // Test 4: channel_name column in live_streams
    const colStart = performance.now();
    try {
      // Try to select channel_name specifically
      const { error } = await supabase.from('live_streams').select('channel_name').limit(1);
      const duration = Math.round(performance.now() - colStart);

      if (error) {
        if (error.message?.includes('channel_name') || error.code === '42703') {
          updateTest('agora', 'agora_db_column', {
            status: 'error',
            message: 'Colonne channel_name MANQUANTE dans live_streams',
            duration,
            details: `La colonne channel_name n'existe pas dans la table live_streams.\n\nSolution: Exécutez cette requête SQL dans le Dashboard Supabase > SQL Editor:\n\nALTER TABLE public.live_streams ADD COLUMN IF NOT EXISTS channel_name TEXT;\n\nNote: Le système fonctionne sans cette colonne (fallback automatique), mais elle est recommandée pour une meilleure fiabilité.`,
          });
        } else {
          updateTest('agora', 'agora_db_column', {
            status: 'warning',
            message: `Erreur lors du test: ${error.message}`,
            duration,
            details: `Code: ${error.code}\nMessage: ${error.message}`,
          });
        }
      } else {
        updateTest('agora', 'agora_db_column', {
          status: 'success',
          message: 'Colonne channel_name présente dans live_streams',
          duration,
        });
      }
    } catch (err: any) {
      updateTest('agora', 'agora_db_column', {
        status: 'error',
        message: `Exception: ${err?.message}`,
        duration: Math.round(performance.now() - colStart),
      });
    }
  };


  // ---- RUN ALL ----

  const runAllTests = async () => {
    if (isRunning) return;
    setIsRunning(true);
    setCategories(getInitialCategories());
    setExpandedCategories(new Set());

    await runConnectionTests();
    await runTableTests();
    await runRLSTests();
    await runStorageTests();
    await runRealtimeTests();
    await runEdgeFunctionTests();
    await runAgoraTests();

    setLastRun(new Date());
    setIsRunning(false);
  };

  const toggleCategory = (id: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // ---- STATS ----

  const allTests = categories.flatMap(c => c.tests);
  const totalTests = allTests.length;
  const passedTests = allTests.filter(t => t.status === 'success').length;
  const failedTests = allTests.filter(t => t.status === 'error').length;
  const warningTests = allTests.filter(t => t.status === 'warning').length;
  const overallStatus: TestStatus = allTests.every(t => t.status === 'idle')
    ? 'idle'
    : failedTests > 0
    ? 'error'
    : warningTests > 0
    ? 'warning'
    : allTests.some(t => t.status === 'running')
    ? 'running'
    : 'success';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
              <DatabaseIcon />
            </div>
            Diagnostic complet
          </h2>
          <p className="text-gray-400 text-sm mt-1">
            Connexion, tables, RLS, stockage, temps réel, Edge Functions et Agora
          </p>
        </div>
        <button
          onClick={runAllTests}
          disabled={isRunning}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium text-sm transition-all ${
            isRunning
              ? 'bg-blue-500/20 text-blue-300 cursor-not-allowed'
              : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-blue-500/25'
          }`}
        >
          <RefreshIcon spinning={isRunning} />
          {isRunning ? 'Tests en cours...' : 'Lancer les diagnostics'}
        </button>
      </div>

      {/* Summary Bar */}
      {overallStatus !== 'idle' && (
        <div className={`rounded-xl border p-4 ${statusConfig[overallStatus].bg} ${statusConfig[overallStatus].border}`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className={statusConfig[overallStatus].color}>
                {overallStatus === 'success' && <CheckCircleIcon />}
                {overallStatus === 'error' && <XCircleIcon />}
                {overallStatus === 'warning' && <WarningIcon />}
                {overallStatus === 'running' && <RefreshIcon spinning />}
              </div>
              <div>
                <p className={`font-semibold text-sm ${statusConfig[overallStatus].color}`}>
                  {overallStatus === 'success' && 'Tous les tests ont réussi'}
                  {overallStatus === 'error' && `${failedTests} test(s) échoué(s)`}
                  {overallStatus === 'warning' && `${warningTests} avertissement(s)`}
                  {overallStatus === 'running' && 'Tests en cours d\'exécution...'}
                </p>
                {lastRun && (
                  <p className="text-gray-500 text-xs flex items-center gap-1 mt-0.5">
                    <ClockIcon />
                    Dernier test: {lastRun.toLocaleTimeString('fr-FR')}
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-gray-400">{passedTests} réussi(s)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-gray-400">{warningTests} avertissement(s)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-red-500" />
                <span className="text-gray-400">{failedTests} erreur(s)</span>
              </span>
            </div>
          </div>

          {totalTests > 0 && (
            <div className="mt-3 h-1.5 bg-gray-800 rounded-full overflow-hidden">
              <div className="h-full flex">
                <div className="bg-emerald-500 transition-all duration-500" style={{ width: `${(passedTests / totalTests) * 100}%` }} />
                <div className="bg-amber-500 transition-all duration-500" style={{ width: `${(warningTests / totalTests) * 100}%` }} />
                <div className="bg-red-500 transition-all duration-500" style={{ width: `${(failedTests / totalTests) * 100}%` }} />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Agora Alert Banner - shown when Agora is not configured */}
      {categories.find(c => c.id === 'agora')?.tests.some(t => t.status === 'error') && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-5">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center flex-shrink-0">
              <VideoIcon />
            </div>
            <div className="space-y-2">
              <h3 className="text-red-400 font-semibold text-sm">Configuration Agora requise pour le Live Streaming</h3>
              <p className="text-gray-400 text-xs leading-relaxed">
                Les secrets <code className="text-red-300 bg-red-500/20 px-1.5 py-0.5 rounded">AGORA_APP_ID</code> et{' '}
                <code className="text-red-300 bg-red-500/20 px-1.5 py-0.5 rounded">AGORA_APP_CERTIFICATE</code> ne sont pas accessibles
                par les Edge Functions, bien qu'ils puissent apparaître dans la liste des secrets.
              </p>
              <div className="bg-gray-900/80 rounded-lg p-4 text-xs font-mono text-gray-300 space-y-1 border border-gray-800/50">
                <p className="text-amber-400 font-semibold mb-2">Étapes de résolution :</p>
                <p>1. Allez sur <span className="text-blue-400">console.agora.io</span> &gt; Votre projet</p>
                <p>2. Copiez l'<span className="text-emerald-400">App ID</span> et le <span className="text-emerald-400">Primary Certificate</span></p>
                <p>3. Dans le <span className="text-blue-400">Dashboard Supabase</span> &gt; Edge Functions &gt; Secrets :</p>
                <p className="pl-4">a. Supprimez AGORA_APP_ID (s'il existe)</p>
                <p className="pl-4">b. Recréez AGORA_APP_ID avec la valeur copiée</p>
                <p className="pl-4">c. Supprimez AGORA_APP_CERTIFICATE (s'il existe)</p>
                <p className="pl-4">d. Recréez AGORA_APP_CERTIFICATE avec la valeur copiée</p>
                <p>4. Relancez les diagnostics pour vérifier</p>
              </div>
              <p className="text-gray-500 text-xs">
                SQL pour la colonne manquante (à exécuter dans SQL Editor) :{' '}
                <code className="text-gray-300 bg-gray-800 px-1.5 py-0.5 rounded">
                  ALTER TABLE public.live_streams ADD COLUMN IF NOT EXISTS channel_name TEXT;
                </code>
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Categories */}
      <div className="space-y-3">
        {categories.map((category) => {
          const isExpanded = expandedCategories.has(category.id);
          const cfg = statusConfig[category.overallStatus];

          return (
            <div
              key={category.id}
              className={`rounded-xl border transition-all ${cfg.border} ${
                category.overallStatus === 'idle' ? 'bg-gray-900/30' : cfg.bg
              }`}
            >
              <button
                onClick={() => toggleCategory(category.id)}
                className="w-full flex items-center justify-between p-4 text-left hover:bg-white/[0.02] transition-colors rounded-xl"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                    category.overallStatus === 'idle' ? 'bg-gray-800 text-gray-400' :
                    category.overallStatus === 'success' ? 'bg-emerald-500/20 text-emerald-400' :
                    category.overallStatus === 'error' ? 'bg-red-500/20 text-red-400' :
                    category.overallStatus === 'warning' ? 'bg-amber-500/20 text-amber-400' :
                    'bg-blue-500/20 text-blue-400'
                  }`}>
                    {category.icon}
                  </div>
                  <div>
                    <p className="text-white font-medium text-sm">{category.label}</p>
                    <p className="text-gray-500 text-xs">{category.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {category.overallStatus !== 'idle' && (
                    <div className="flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${cfg.dotColor}`} />
                      <span className={`text-xs font-medium ${cfg.color}`}>
                        {category.tests.filter(t => t.status === 'success').length}/{category.tests.length}
                      </span>
                    </div>
                  )}
                  <ChevronIcon open={isExpanded} />
                </div>
              </button>

              {isExpanded && (
                <div className="border-t border-gray-800/50 px-4 pb-4">
                  <div className="mt-3 overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-gray-500 text-xs uppercase tracking-wider">
                          <th className="text-left py-2 px-3 font-medium">Statut</th>
                          <th className="text-left py-2 px-3 font-medium">Test</th>
                          <th className="text-left py-2 px-3 font-medium hidden sm:table-cell">Description</th>
                          <th className="text-left py-2 px-3 font-medium">Résultat</th>
                          <th className="text-right py-2 px-3 font-medium hidden md:table-cell">Durée</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800/30">
                        {category.tests.map((test) => {
                          const tcfg = statusConfig[test.status];
                          return (
                            <React.Fragment key={test.id}>
                              <tr className="group hover:bg-white/[0.02]">
                                <td className="py-2.5 px-3">
                                  <div className="flex items-center gap-2">
                                    <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${tcfg.dotColor}`} />
                                    <span className={`text-xs font-medium ${tcfg.color} hidden sm:inline`}>
                                      {tcfg.label}
                                    </span>
                                  </div>
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-white font-mono text-xs">{test.name}</span>
                                </td>
                                <td className="py-2.5 px-3 hidden sm:table-cell">
                                  <span className="text-gray-500 text-xs">{test.description}</span>
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className={`text-xs ${tcfg.color}`}>{test.message || '—'}</span>
                                </td>
                                <td className="py-2.5 px-3 text-right hidden md:table-cell">
                                  {test.duration !== undefined ? (
                                    <span className="text-gray-500 text-xs font-mono">{test.duration}ms</span>
                                  ) : (
                                    <span className="text-gray-600 text-xs">—</span>
                                  )}
                                </td>
                              </tr>
                              {test.details && (
                                <tr>
                                  <td colSpan={5} className="px-3 pb-2">
                                    <div className="bg-gray-900/80 rounded-lg p-3 text-xs font-mono text-gray-400 whitespace-pre-wrap border border-gray-800/50">
                                      {test.details}
                                    </div>
                                  </td>
                                </tr>
                              )}
                            </React.Fragment>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Config Info Footer */}
      <div className="rounded-xl border border-gray-800/50 bg-gray-900/20 p-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center flex-shrink-0 mt-0.5">
            <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div className="text-xs text-gray-500 space-y-1">
            <p className="text-gray-400 font-medium">Informations de configuration</p>
            <p>Supabase configuré: <span className={isSupabaseConfigured ? 'text-emerald-400' : 'text-red-400'}>{isSupabaseConfigured ? 'Oui' : 'Non'}</span></p>
            <p>Source: <span className="text-gray-400 font-mono">{getConfigDiagnostics().source}</span></p>
            <p>URL: <span className="text-gray-400 font-mono">{getConfigDiagnostics().url}</span></p>
            <p>Longueur clé: <span className="text-gray-400 font-mono">{getConfigDiagnostics().keyLength} caractères</span></p>
            <p className="pt-1 text-gray-600">
              En cas de problème, consultez <code className="text-gray-400">DATABASE-SETUP.md</code> ou allez sur <a href="/setup" className="text-blue-400 hover:underline">/setup</a>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiagnosticsPanel;
