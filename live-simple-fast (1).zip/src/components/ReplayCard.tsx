import React from 'react';
import { useNavigate } from 'react-router-dom';
import { recordingService } from '@/lib/recordingService';

export interface ReplayData {
  id: string;
  title: string;
  thumbnail_url: string;
  recording_url: string;
  duration_seconds: number;
  recording_size_bytes: number;
  viewer_count: number;
  peak_viewers: number;
  started_at: string;
  ended_at: string;
  recording_status: string;
  creator_id: string;
  is_audio_only?: boolean;
  // Creator info (joined)
  creatorName?: string;
  creatorUsername?: string;
  creatorAvatar?: string;
  whatsappNumber?: string;
}

interface ReplayCardProps {
  replay: ReplayData;
  onClick: () => void;
}

const ReplayCard: React.FC<ReplayCardProps> = ({ replay, onClick }) => {
  const navigate = useNavigate();

  const formatCount = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const formatTimeAgo = (dateStr: string): string => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `il y a ${diffMins}min`;
    if (diffHours < 24) return `il y a ${diffHours}h`;
    if (diffDays < 7) return `il y a ${diffDays}j`;
    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  };

  const goToProfile = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Only navigate if we have a real creatorUsername from the database
    if (replay.creatorUsername) {
      navigate(`/creator/${replay.creatorUsername}`);
    }
  };


  const openWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!replay.whatsappNumber) return;
    const message = encodeURIComponent(`Salut ${replay.creatorName}! J'ai regardé ton replay "${replay.title}" sur PitchCI`);

    const cleanNumber = replay.whatsappNumber.replace(/[^0-9+]/g, '');
    window.open(`https://wa.me/${cleanNumber}?text=${message}`, '_blank');
  };

  const creatorInitials = (replay.creatorName || 'C')
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="w-full bg-gray-900 rounded-xl overflow-hidden hover:ring-2 hover:ring-purple-500 transition-all group">
      <button onClick={onClick} className="w-full relative aspect-video">
        {replay.is_audio_only ? (
          /* Audio-only thumbnail: avatar + gradient background */
          <div className="w-full h-full bg-gradient-to-br from-purple-900/80 via-gray-900 to-purple-800/60 flex flex-col items-center justify-center relative">
            {/* Subtle background pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="w-full h-full" style={{
                backgroundImage: 'radial-gradient(circle at 30% 40%, #a855f7 1px, transparent 1px), radial-gradient(circle at 70% 60%, #a855f7 1px, transparent 1px)',
                backgroundSize: '30px 30px'
              }} />
            </div>
            {/* Avatar */}
            <div className="w-16 h-16 rounded-full overflow-hidden ring-3 ring-purple-500/40 mb-2 relative z-10">
              {replay.creatorAvatar ? (
                <img src={replay.creatorAvatar} alt={replay.creatorName || ''} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                  <span className="text-white text-xl font-bold">{creatorInitials}</span>
                </div>
              )}
            </div>
            {/* Audio waveform icon */}
            <div className="flex items-center gap-0.5 relative z-10">
              {[3, 5, 8, 6, 9, 5, 7, 4, 6, 3].map((h, i) => (
                <div
                  key={i}
                  className="w-1 bg-purple-400/60 rounded-full"
                  style={{ height: `${h * 2}px` }}
                />
              ))}
            </div>
          </div>
        ) : (
          <img
            src={replay.thumbnail_url || 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=800&h=450&fit=crop'}
            alt={replay.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        )}

        {/* Replay badge */}
        <div className="absolute top-2 left-2 flex items-center gap-1.5">
          <span className="bg-purple-600 text-white text-xs font-bold px-2 py-1 rounded flex items-center gap-1">
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
            </svg>
            REPLAY
          </span>
          {replay.is_audio_only && (
            <span className="bg-purple-500/80 text-white text-xs font-medium px-2 py-1 rounded flex items-center gap-1">
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
              Audio
            </span>
          )}
        </div>

        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded font-mono">
          {recordingService.formatDurationLong(replay.duration_seconds)}
        </div>

        {/* Viewers */}
        <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
          </svg>
          {formatCount(replay.peak_viewers || replay.viewer_count)}
        </div>

        {/* Play overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
          <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <svg className="w-7 h-7 text-white ml-1" fill="currentColor" viewBox="0 0 20 20">
              <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
            </svg>
          </div>
        </div>
      </button>

      <div className="p-3">
        <div className="flex items-start gap-3">
          <button onClick={goToProfile} className="flex-shrink-0">
            <img
              src={replay.creatorAvatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop'}
              alt={replay.creatorName || 'Creator'}
              className="w-10 h-10 rounded-full object-cover hover:ring-2 hover:ring-purple-500 transition-all"
            />
          </button>
          <div className="flex-1 min-w-0">
            <h3 className="text-white font-medium text-sm truncate">{replay.title}</h3>
            <button onClick={goToProfile} className="block">
              <p className="text-gray-400 text-xs hover:text-purple-400 transition-colors">
                @{replay.creatorUsername || replay.creatorName?.replace(/\s+/g, '').toLowerCase()}
              </p>
            </button>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-gray-500 text-xs">{formatTimeAgo(replay.ended_at || replay.started_at)}</span>
              {replay.recording_size_bytes > 0 && (
                <>
                  <span className="text-gray-600 text-xs">·</span>
                  <span className="text-gray-500 text-xs">{recordingService.formatFileSize(replay.recording_size_bytes)}</span>
                </>
              )}
              {replay.is_audio_only && (
                <>
                  <span className="text-gray-600 text-xs">·</span>
                  <span className="text-purple-400/70 text-xs flex items-center gap-0.5">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                    Audio
                  </span>
                </>
              )}
            </div>
          </div>
          {replay.whatsappNumber && (
            <button
              onClick={openWhatsApp}
              className="flex-shrink-0 w-8 h-8 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center transition-colors"
              title="Contacter sur WhatsApp"
            >
              <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReplayCard;
