export interface LiveStream {
  id: string;
  title: string;
  creatorId: string;
  creatorName: string;
  creatorUsername?: string;
  creatorAvatar: string;
  viewerCount: number;
  thumbnailUrl: string;
  isLive?: boolean;
  startedAt?: string;
  followerCount?: number;
  whatsappNumber?: string;
  description?: string;
  category?: string;
  /** Agora channel name — required for real-time video/audio via Agora RTC */
  channelName?: string;
  /** Whether this is an audio-only stream */
  isAudioOnly?: boolean;
}



export const sampleStreams: LiveStream[] = [
  {
    id: '1',
    title: 'Session créative en direct',
    creatorId: 'creator-1',
    creatorName: 'Marie L.',
    creatorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    viewerCount: 234,
    thumbnailUrl: 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=800&h=1400&fit=crop',
    isLive: true,
    followerCount: 1250,
    whatsappNumber: '+33612345678',
    description: 'Rejoignez-moi pour une session créative! Art, design et bonne humeur.',
    category: 'Art & Design',
  },
  {
    id: '2',
    title: 'Discussion tech du soir',
    creatorId: 'creator-2',
    creatorName: 'Thomas D.',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
    viewerCount: 156,
    thumbnailUrl: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?w=800&h=1400&fit=crop',
    isLive: true,
    followerCount: 890,
    whatsappNumber: '+33698765432',
    description: 'On parle de développement web, IA et nouvelles technologies.',
    category: 'Tech',
  },
  {
    id: '3',
    title: 'Cours de cuisine live',
    creatorId: 'creator-3',
    creatorName: 'Sophie M.',
    creatorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
    viewerCount: 89,
    thumbnailUrl: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=1400&fit=crop',
    isLive: true,
    followerCount: 2340,
    whatsappNumber: '+33611223344',
    description: 'Apprenez à cuisiner des plats délicieux en direct avec moi!',
    category: 'Cuisine',
  },
  {
    id: '4',
    title: 'Gaming session - Fortnite',
    creatorId: 'creator-4',
    creatorName: 'Lucas P.',
    creatorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop',
    viewerCount: 412,
    thumbnailUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&h=1400&fit=crop',
    isLive: true,
    followerCount: 5670,
    whatsappNumber: '+33655667788',
    description: 'Gaming en live! Venez jouer avec moi.',
    category: 'Gaming',
  },
  {
    id: '5',
    title: 'Yoga matinal relaxant',
    creatorId: 'creator-5',
    creatorName: 'Emma R.',
    creatorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop',
    viewerCount: 178,
    thumbnailUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&h=1400&fit=crop',
    isLive: true,
    followerCount: 3450,
    whatsappNumber: '+33699887766',
    description: 'Commencez votre journée avec une séance de yoga relaxante.',
    category: 'Bien-être',
  },
  {
    id: '6',
    title: 'Live shopping mode',
    creatorId: 'creator-6',
    creatorName: 'Léa B.',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop',
    viewerCount: 567,
    thumbnailUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=1400&fit=crop',
    isLive: true,
    followerCount: 8920,
    whatsappNumber: '+33644556677',
    description: 'Découvrez les dernières tendances mode avec moi!',
    category: 'Mode',
  },
  {
    id: '7',
    title: 'Musique acoustique live',
    creatorId: 'creator-7',
    creatorName: 'Antoine M.',
    creatorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop',
    viewerCount: 289,
    thumbnailUrl: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=800&h=1400&fit=crop',
    isLive: true,
    followerCount: 4560,
    whatsappNumber: '+33677889900',
    description: 'Concert acoustique en direct depuis mon salon.',
    category: 'Musique',
  },
  {
    id: '8',
    title: 'Conseils business & entrepreneuriat',
    creatorId: 'creator-8',
    creatorName: 'Nicolas F.',
    creatorAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop',
    viewerCount: 345,
    thumbnailUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=1400&fit=crop',
    isLive: true,
    followerCount: 12300,
    whatsappNumber: '+33688990011',
    description: 'Partageons nos expériences entrepreneuriales.',
    category: 'Business',
  },
];
