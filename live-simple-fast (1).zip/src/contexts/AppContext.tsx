import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { subscriptionService, CreatorSubscription } from '@/lib/subscriptionService';


export interface User {
  id: string;
  email: string;
}

export interface Utilisateur {
  id: string;
  auth_user_id: string;
  email: string | null;
  display_name: string | null;
  avatar_url: string | null;
  phone: string | null;
  role: string;
  is_active: boolean;
  last_seen_at: string | null;
  created_at: string;
  updated_at: string;
}


export interface CreatorProfile {
  id: string;
  user_id: string;
  username: string;
  display_name: string;
  bio: string | null;
  avatar_url: string | null;
  whatsapp_number: string | null;
  is_verified: boolean;
  followers_count: number;
  total_views: number;
  created_at: string;
  updated_at: string;
}

interface AuthResult {
  success: boolean;
  error?: string;
  errorCode?: string; // e.g. 'email_not_confirmed'
}

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  user: User | null;
  utilisateur: Utilisateur | null;
  creatorProfile: CreatorProfile | null;
  subscription: CreatorSubscription | null;
  hasActiveSubscription: boolean;
  isAuthenticated: boolean;
  isLoading: boolean;
  isSupabaseReady: boolean;
  isAdmin: boolean;
  signUp: (email: string, password: string) => Promise<AuthResult>;
  signIn: (email: string, password: string) => Promise<AuthResult>;
  signOut: () => Promise<void>;
  createProfile: (data: Partial<CreatorProfile>) => Promise<{ success: boolean; error?: string }>;
  updateProfile: (data: Partial<CreatorProfile>) => Promise<{ success: boolean; error?: string }>;
  updateUtilisateur: (data: Partial<Utilisateur>) => Promise<{ success: boolean; error?: string }>;
  refreshUtilisateur: () => Promise<void>;
  uploadAvatar: (file: File) => Promise<{ success: boolean; url?: string; error?: string }>;
  refreshProfile: () => Promise<void>;
  refreshSubscription: () => Promise<void>;
}


const AppContext = createContext<AppContextType>({
  sidebarOpen: false,
  toggleSidebar: () => {},
  user: null,
  utilisateur: null,
  creatorProfile: null,
  subscription: null,
  hasActiveSubscription: false,
  isAuthenticated: false,
  isLoading: true,
  isSupabaseReady: false,
  isAdmin: false,
  signUp: async () => ({ success: false }),
  signIn: async () => ({ success: false }),
  signOut: async () => {},
  createProfile: async () => ({ success: false }),
  updateProfile: async () => ({ success: false }),
  updateUtilisateur: async () => ({ success: false }),
  refreshUtilisateur: async () => {},
  uploadAvatar: async () => ({ success: false }),
  refreshProfile: async () => {},
  refreshSubscription: async () => {},
});


export const useAppContext = () => useContext(AppContext);

// ============================================================================
// Extract a human-readable message from any error shape
// ============================================================================
function extractErrorMessage(err: unknown): string {
  if (!err) return '';

  if (typeof err === 'string') {
    const trimmed = err.trim();
    if (!trimmed || trimmed === '{}' || trimmed === '""') return '';
    return trimmed;
  }

  if (typeof err === 'object') {
    const obj = err as Record<string, any>;

    if (typeof obj.message === 'string' && obj.message.trim() && obj.message.trim() !== '{}') {
      return obj.message.trim();
    }
    if (typeof obj.error_description === 'string' && obj.error_description.trim()) {
      return obj.error_description.trim();
    }
    if (typeof obj.error === 'string' && obj.error.trim() && obj.error.trim() !== '{}') {
      return obj.error.trim();
    }
    if (typeof obj.msg === 'string' && obj.msg.trim()) {
      return obj.msg.trim();
    }
    if (typeof obj.statusText === 'string' && obj.statusText.trim()) {
      return obj.statusText.trim();
    }

    try {
      const json = JSON.stringify(obj);
      if (json && json !== '{}' && json !== '""' && json.length > 2) {
        return json;
      }
    } catch {
      // ignore
    }
  }

  return '';
}

/**
 * Detect if an error is an "email not confirmed" error.
 * Checks multiple patterns from Supabase auth error responses.
 */
function isEmailNotConfirmedError(err: unknown): boolean {
  if (!err) return false;
  const msg = extractErrorMessage(err).toLowerCase();
  if (msg.includes('email not confirmed') || msg.includes('email_not_confirmed')) return true;
  if (typeof err === 'object') {
    const obj = err as Record<string, any>;
    if (obj.code === 'email_not_confirmed') return true;
    if (obj.error_code === 'email_not_confirmed') return true;
  }
  return false;
}

/**
 * Detect if an error is an "error sending confirmation/email" error.
 * This happens when Supabase's built-in email service fails (rate limits, SMTP not configured, etc.)
 */
function isEmailSendingError(err: unknown): boolean {
  if (!err) return false;
  const msg = extractErrorMessage(err).toLowerCase();
  if (msg.includes('error sending confirmation')) return true;
  if (msg.includes('error sending email')) return true;
  if (msg.includes('sending confirmation email')) return true;
  if (msg.includes('email sending')) return true;
  if (msg.includes('unable to send')) return true;
  if (msg.includes('failed to send')) return true;
  if (msg.includes('smtp')) return true;
  if (typeof err === 'object') {
    const obj = err as Record<string, any>;
    if (obj.code === 'email_send_failed') return true;
    if (obj.error_code === 'email_send_failed') return true;
    if (obj.code === 'unexpected_failure' && msg.includes('email')) return true;
  }
  return false;
}

/**
 * Determine the email-related error code from an error object.
 * Returns 'email_sending_failed', 'email_not_confirmed', or undefined.
 */
function getEmailErrorCode(err: unknown): string | undefined {
  if (isEmailSendingError(err)) return 'email_sending_failed';
  if (isEmailNotConfirmedError(err)) return 'email_not_confirmed';
  return undefined;
}





// ============================================================================
// Detect AbortError from Supabase GoTrue navigator lock
// ============================================================================
function isAbortError(err: unknown): boolean {
  if (!err) return false;
  if (typeof err === 'object') {
    const obj = err as Record<string, any>;
    if (obj.name === 'AbortError') return true;
    if (obj.code === 'ABORT_ERR' || obj.code === 20) return true;
  }
  const msg = extractErrorMessage(err).toLowerCase();
  return msg.includes('signal is aborted') || msg.includes('aborterror') || msg.includes('aborted without reason');
}

// ============================================================================
// Translate common Supabase auth error messages to French
// ============================================================================
function translateAuthError(rawError: unknown): string {
  // Handle AbortError specifically — this is a transient lock contention issue
  if (isAbortError(rawError)) {
    return 'La connexion a été interrompue. Veuillez réessayer.';
  }

  const message = extractErrorMessage(rawError);

  if (!message) return 'Une erreur inconnue est survenue. Veuillez réessayer.';

  const translations: Record<string, string> = {
    'Invalid login credentials': 'Email ou mot de passe incorrect.',
    'invalid_credentials': 'Email ou mot de passe incorrect.',
    'invalid credentials': 'Email ou mot de passe incorrect.',
    'Email not confirmed': 'Veuillez confirmer votre email avant de vous connecter. Vérifiez votre boîte de réception (et les spams).',
    'Error sending confirmation email': "Erreur lors de l'envoi de l'email de confirmation. Le service d'email de Supabase a échoué.",
    'Error sending email': "Erreur lors de l'envoi de l'email. Le service d'email n'est pas disponible.",
    'sending confirmation email': "Erreur lors de l'envoi de l'email de confirmation. Vérifiez la configuration SMTP.",
    'User already registered': 'Un compte existe déjà avec cet email.',
    'Password should be at least 6 characters': 'Le mot de passe doit contenir au moins 6 caractères.',
    'Signup requires a valid password': 'Veuillez entrer un mot de passe valide.',
    'Unable to validate email address: invalid format': "Format d'email invalide.",
    'Email rate limit exceeded': 'Trop de tentatives. Veuillez réessayer dans quelques minutes.',
    'For security purposes, you can only request this after': 'Pour des raisons de sécurité, veuillez patienter avant de réessayer.',
    'Network request failed': 'Erreur réseau. Vérifiez votre connexion internet.',
    'Invalid API key': "Clé API invalide. Contactez l'administrateur.",
    'Relay error': "Erreur du serveur d'authentification. Réessayez dans un instant.",
    'invalid_grant': 'Email ou mot de passe incorrect.',
    'user_not_found': 'Aucun compte trouvé avec cet email.',
    'email_not_confirmed': 'Veuillez confirmer votre email avant de vous connecter.',
  };


  const lowerMessage = message.toLowerCase();

  // Check for AbortError patterns in the message text
  if (lowerMessage.includes('signal is aborted') || lowerMessage.includes('aborterror') || lowerMessage.includes('aborted without reason')) {
    return 'La connexion a été interrompue. Veuillez réessayer.';
  }

  for (const [eng, fr] of Object.entries(translations)) {
    if (lowerMessage.includes(eng.toLowerCase())) {
      return fr;
    }
  }

  if (lowerMessage.includes('fetch') || lowerMessage.includes('network') || lowerMessage.includes('503') || lowerMessage.includes('load failed') || lowerMessage.includes('failed to fetch')) {
    return 'Impossible de se connecter au serveur. Vérifiez votre connexion internet et réessayez.';
  }

  if (lowerMessage.includes('upstream') || lowerMessage.includes('proxy') || lowerMessage.includes('bad gateway') || lowerMessage.includes('502') || lowerMessage.includes('504')) {
    return 'Le serveur est temporairement indisponible. Veuillez réessayer dans quelques instants.';
  }

  if (lowerMessage.includes('unexpected token') || lowerMessage.includes('json') || lowerMessage.includes('is not valid')) {
    return 'Erreur de communication avec le serveur. Veuillez réessayer.';
  }

  if (lowerMessage.includes('apikey') || lowerMessage.includes('api key') || lowerMessage.includes('not found')) {
    return "Erreur de configuration du serveur. Contactez l'administrateur.";
  }

  if (message.startsWith('{') || message.startsWith('[') || message.startsWith('<')) {
    return 'Une erreur serveur est survenue. Veuillez réessayer.';
  }

  return message;
}




export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [utilisateur, setUtilisateur] = useState<Utilisateur | null>(null);
  const [creatorProfile, setCreatorProfile] = useState<CreatorProfile | null>(null);
  const [subscription, setSubscription] = useState<CreatorSubscription | null>(null);
  const [hasActiveSubscription, setHasActiveSubscription] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);


  // ============================================================================
  // CONCURRENCY GUARDS — prevent duplicate setupUserData calls
  // ============================================================================
  const setupInProgressRef = useRef(false);
  const setupCompletedForRef = useRef<string | null>(null);
  const initCompletedRef = useRef(false);
  // Track if a signIn/signUp operation is in progress to prevent double-clicks
  const authOperationInProgressRef = useRef(false);

  const toggleSidebar = () => setSidebarOpen(prev => !prev);

  // ---- Data fetching helpers ----

  const fetchCreatorProfile = async (userId: string) => {
    if (!userId || userId === 'undefined' || userId === 'null' || userId.length < 5) {
      console.warn('[AppContext] fetchCreatorProfile called with invalid userId:', userId);
      return null;
    }
    try {
      const { data, error } = await supabase
        .from('creator_profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        console.warn('[AppContext] Error fetching profile:', error.message);
        return null;
      }
      return data as CreatorProfile | null;
    } catch (err: any) {
      console.warn('[AppContext] Exception fetching profile:', err?.message);
      return null;
    }
  };
  const fetchSubscription = async (creatorId: string) => {
    try {
      const sub = await subscriptionService.getCreatorSubscription(creatorId);
      setSubscription(sub);
      const isActive = await subscriptionService.hasActiveSubscription(creatorId);
      setHasActiveSubscription(isActive);
      return sub;
    } catch (err: any) {
      console.warn('[AppContext] Error fetching subscription:', err?.message);
      setSubscription(null);
      setHasActiveSubscription(false);
      return null;
    }
  };
  // ============================================================================
  // Helper: detect if an error means the table/relation doesn't exist
  // ============================================================================
  const isTableMissingError = (err: any): boolean => {
    if (!err) return false;
    const code = err.code || '';
    const msg = (err.message || '').toLowerCase();
    return (
      code === '42P01' ||
      code === 'PGRST205' ||
      msg.includes('does not exist') ||
      msg.includes('relation') && msg.includes('not') ||
      msg.includes('404') ||
      msg.includes('not found') ||
      msg.includes('schema cache')
    );
  };

  // ============================================================================
  // Helper: detect if an error means the RPC function doesn't exist
  // ============================================================================
  const isRpcMissingError = (err: any): boolean => {
    if (!err) return false;
    const code = err.code || '';
    const msg = (err.message || '').toLowerCase();
    return (
      code === '42883' ||
      msg.includes('function') && msg.includes('does not exist') ||
      msg.includes('could not find') ||
      msg.includes('no function matches')
    );
  };

  // ============================================================================
  // UTILISATEURS TABLE — sync auth.users to utilisateurs
  // Gracefully handles missing table (returns null, doesn't block login)
  // ============================================================================
  const ensureUtilisateur = async (userId: string, email: string): Promise<Utilisateur | null> => {
    if (!userId || userId.length < 5) return null;
    const now = new Date().toISOString();

    try {
      // Try to fetch existing row
      const { data: existing, error: fetchErr } = await supabase
        .from('utilisateurs')
        .select('*')
        .eq('auth_user_id', userId)
        .maybeSingle();

      if (fetchErr) {
        // If table doesn't exist, return null gracefully — don't block login
        if (isTableMissingError(fetchErr)) {
          console.warn('[AppContext] utilisateurs table not found — skipping. Run migration SQL to create it.');
          return null;
        }
        console.warn('[AppContext] Error fetching utilisateur:', fetchErr.message);
        return null;
      }

      if (existing) {
        // Update last_seen_at and sync email if changed
        const updates: Record<string, any> = {
          last_seen_at: now,
          updated_at: now,
        };
        if (email && existing.email !== email) {
          updates.email = email;
        }
        const { data: updated, error: updateErr } = await supabase
          .from('utilisateurs')
          .update(updates)
          .eq('auth_user_id', userId)
          .select()
          .single();

        if (updateErr) {
          console.warn('[AppContext] Error updating utilisateur last_seen_at:', updateErr.message);
          return existing as Utilisateur;
        }
        console.log('[AppContext] Utilisateur last_seen_at updated:', updated?.display_name || email);
        return updated as Utilisateur;
      }

      // Create new utilisateur row
      const displayName = email.split('@')[0];
      console.log('[AppContext] Creating utilisateur for:', email);

      const { data: created, error: insertErr } = await supabase
        .from('utilisateurs')
        .insert({
          auth_user_id: userId,
          email: email,
          display_name: displayName,
          role: 'user',
          is_active: true,
          last_seen_at: now,
        })
        .select()
        .single();

      if (insertErr) {
        // Handle race condition — row was created between our SELECT and INSERT
        if (insertErr.code === '23505') {
          console.log('[AppContext] Utilisateur already exists (race condition), fetching...');
          const { data: retry } = await supabase
            .from('utilisateurs')
            .select('*')
            .eq('auth_user_id', userId)
            .maybeSingle();
          return (retry as Utilisateur) || null;
        }
        // If table doesn't exist, return null gracefully
        if (isTableMissingError(insertErr)) {
          console.warn('[AppContext] utilisateurs table not found on insert — skipping.');
          return null;
        }
        console.warn('[AppContext] Error creating utilisateur:', insertErr.message, insertErr.code);
        return null;
      }

      console.log('[AppContext] Utilisateur created:', created?.display_name);
      return created as Utilisateur;
    } catch (err: any) {
      console.warn('[AppContext] ensureUtilisateur exception:', err?.message);
      return null;
    }
  };


  const updateUtilisateur = async (data: Partial<Utilisateur>): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'Vous devez être connecté.' };
    try {
      // Only allow safe fields to be updated
      const { id, auth_user_id, created_at, ...editableFields } = data as any;
      const { data: updated, error } = await supabase
        .from('utilisateurs')
        .update({ ...editableFields, updated_at: new Date().toISOString() })
        .eq('auth_user_id', user.id)
        .select()
        .single();

      if (error) {
        console.warn('[AppContext] updateUtilisateur error:', error.message);
        return { success: false, error: error.message };
      }
      setUtilisateur(updated as Utilisateur);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Erreur lors de la mise à jour.' };
    }
  };

  const refreshUtilisateur = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('utilisateurs')
        .select('*')
        .eq('auth_user_id', user.id)
        .maybeSingle();
      if (!error && data) {
        setUtilisateur(data as Utilisateur);
      }
    } catch (err: any) {
      console.warn('[AppContext] refreshUtilisateur error:', err?.message);
    }
  };



  // ============================================================================
  // AUTO-CREATE CREATOR PROFILE if none exists
  // ============================================================================
  const ensureCreatorProfile = async (userId: string, email: string): Promise<CreatorProfile | null> => {
    // First try to fetch existing
    const existing = await fetchCreatorProfile(userId);
    if (existing) return existing;

    // Generate a unique username from email
    const baseUsername = email
      .split('@')[0]
      .replace(/[^a-zA-Z0-9_]/g, '_')
      .substring(0, 20)
      .toLowerCase();
    const uniqueUsername = `${baseUsername}_${Date.now().toString(36)}`;
    const displayName = email.split('@')[0];

    console.log('[AppContext] Auto-creating creator profile for:', email);

    try {
      const { data, error } = await supabase
        .from('creator_profiles')
        .insert({
          user_id: userId,
          username: uniqueUsername,
          display_name: displayName,
          bio: null,
          avatar_url: null,
          whatsapp_number: null,
        })
        .select()
        .single();

      if (error) {
        console.warn('[AppContext] Auto-create profile error:', error.message, error.code);

        if (error.code === '23505' && (error.message.includes('user_id') || error.message.includes('creator_profiles_user_id'))) {
          console.log('[AppContext] Profile already exists (race condition), fetching...');
          const existingRetry = await fetchCreatorProfile(userId);
          if (existingRetry) return existingRetry;
        }

        if (error.code === '23505' && error.message.includes('username')) {
          const retryUsername = `${baseUsername}_${Math.random().toString(36).substring(2, 8)}`;
          const { data: retryData, error: retryError } = await supabase
            .from('creator_profiles')
            .insert({
              user_id: userId,
              username: retryUsername,
              display_name: displayName,
              bio: null,
              avatar_url: null,
              whatsapp_number: null,
            })
            .select()
            .single();

          if (!retryError && retryData) {
            console.log('[AppContext] Profile auto-created (retry):', retryData.username);
            return retryData as CreatorProfile;
          }

          if (retryError?.code === '23505') {
            const existingRetry2 = await fetchCreatorProfile(userId);
            if (existingRetry2) return existingRetry2;
          }
        }
        return null;
      }

      console.log('[AppContext] Profile auto-created:', data.username);
      return data as CreatorProfile;
    } catch (err: any) {
      console.warn('[AppContext] Auto-create profile exception:', err?.message);
      return null;
    }
  };

  // ============================================================================
  // ADMIN ROLE CONSTANTS
  // ============================================================================
  const ADMIN_TEAM_ROLES = ['owner', 'admin'];
  const ADMIN_USER_ROLES = ['super_admin', 'admin'];

  // ============================================================================
  // AUTO-SETUP FIRST USER AS ADMIN
  // Tries multiple RPC functions in order, then falls back to direct DB check.
  // Gracefully handles missing functions/tables — never blocks login.
  // ============================================================================
  const ensureFirstUserAdmin = async (userId: string, email: string): Promise<boolean> => {
    const displayName = email.split('@')[0];

    // Strategy 1: Try ensure_user_admin_setup RPC (the expected function)
    try {
      const { data: setupResult, error: setupError } = await supabase.rpc('ensure_user_admin_setup', {
        p_user_id: userId,
        p_email: email,
        p_display_name: displayName,
      });

      if (!setupError && setupResult && typeof setupResult === 'object') {
        const result = setupResult as Record<string, any>;
        console.log('[AppContext] Admin setup result (ensure_user_admin_setup):', result);
        if (result.success === true || result.is_admin === true) return true;
        const msg = (result.message || '').toLowerCase();
        if (msg.includes('already_admin') || msg.includes('already_owner') || msg.includes('owner_created') || msg.includes('admin_created') || msg.includes('first_user_setup') || msg.includes('setup_complete')) return true;
        const role = (result.role || '').toLowerCase();
        if (ADMIN_TEAM_ROLES.includes(role) || ADMIN_USER_ROLES.includes(role)) return true;
      }

      if (setupError) {
        // If the RPC function doesn't exist, try the next strategy
        if (isRpcMissingError(setupError)) {
          console.warn('[AppContext] ensure_user_admin_setup RPC not found — trying setup_platform_owner...');
        } else {
          console.warn('[AppContext] ensure_user_admin_setup RPC error:', setupError.message);
        }
      }
    } catch (err: any) {
      console.warn('[AppContext] ensure_user_admin_setup exception:', err?.message);
    }

    // Strategy 2: Try setup_platform_owner RPC (defined in migration SQL)
    try {
      const { data: ownerResult, error: ownerError } = await supabase.rpc('setup_platform_owner', {
        p_user_id: userId,
        p_email: email,
        p_display_name: displayName,
      });

      if (!ownerError && ownerResult && typeof ownerResult === 'object') {
        const result = ownerResult as Record<string, any>;
        console.log('[AppContext] Admin setup result (setup_platform_owner):', result);
        if (result.success === true) return true;
        const msg = (result.message || '').toLowerCase();
        if (msg.includes('already_owner') || msg.includes('owner_created') || msg.includes('owner_exists')) {
          // If another user is already owner, we're not admin
          if (result.owner_exists === true && result.success === false) {
            console.log('[AppContext] Another user is already owner — current user is not admin');
            return await fallbackAdminCheck(userId);
          }
          return true;
        }
      }

      if (ownerError) {
        if (isRpcMissingError(ownerError)) {
          console.warn('[AppContext] setup_platform_owner RPC not found — falling back to direct DB check');
        } else {
          console.warn('[AppContext] setup_platform_owner RPC error:', ownerError.message);
        }
      }
    } catch (err: any) {
      console.warn('[AppContext] setup_platform_owner exception:', err?.message);
    }

    // Strategy 3: Direct DB check
    return await fallbackAdminCheck(userId);
  };

  // ============================================================================
  // FALLBACK: Direct DB admin check
  // Handles missing tables gracefully (returns false, doesn't throw)
  // ============================================================================
  const fallbackAdminCheck = async (userId: string): Promise<boolean> => {
    // Try team_members
    try {
      const { data: myTeam, error: teamErr } = await supabase
        .from('team_members')
        .select('id, role')
        .eq('user_id', userId)
        .maybeSingle();

      if (!teamErr && myTeam) {
        const teamRole = (myTeam.role || '').toLowerCase();
        if (ADMIN_TEAM_ROLES.includes(teamRole)) {
          console.log('[AppContext] Fallback: User is admin via team_members, role:', myTeam.role);
          return true;
        }
      }
      if (teamErr) {
        // Table doesn't exist — not an error, just means no admin setup yet
        if (isTableMissingError(teamErr)) {
          console.warn('[AppContext] team_members table not found — skipping admin check');
          return false;
        }
        // Handle infinite recursion in RLS policy (42P17) — treat as admin
        if (teamErr.code === '42P17' || (teamErr.message || '').toLowerCase().includes('infinite recursion')) {
          console.warn('[AppContext] Infinite recursion in team_members policy (42P17) — treating user as admin. Run migration SQL to fix.');
          return true;
        }
        // Column missing — try wildcard
        if (teamErr.code === '42703' || teamErr.message?.includes('does not exist')) {
          const { data: myTeam2, error: teamErr2 } = await supabase
            .from('team_members')
            .select('*')
            .eq('user_id', userId)
            .maybeSingle();

          if (!teamErr2 && myTeam2) {
            const teamRole = ((myTeam2 as any).role || '').toLowerCase();
            if (ADMIN_TEAM_ROLES.includes(teamRole)) return true;
          }
          if (teamErr2 && (teamErr2.code === '42P17' || (teamErr2.message || '').toLowerCase().includes('infinite recursion'))) {
            return true;
          }
        } else {
          console.warn('[AppContext] Fallback team_members check error:', teamErr.code, teamErr.message);
        }
      }
    } catch (e: any) {
      console.warn('[AppContext] Fallback team_members check failed:', e?.message);
    }

    // Try admin_users
    try {
      const { data: myAdmin, error: adminErr } = await supabase
        .from('admin_users')
        .select('id, role')
        .eq('user_id', userId)
        .maybeSingle();

      if (adminErr) {
        const code = adminErr.code;
        if (isTableMissingError(adminErr)) {
          console.warn('[AppContext] admin_users table not found — skipping');
          return false;
        }
        if (code === '42703' || code === '42P17' || code === '42501' || code === 'PGRST204') {
          console.warn('[AppContext] admin_users query not available (code:', code, ') — skipping');
        } else {
          console.warn('[AppContext] admin_users check error:', code, adminErr.message);
        }
        return false;
      }

      if (myAdmin) {
        const adminRole = (myAdmin.role || '').toLowerCase();
        if (ADMIN_USER_ROLES.includes(adminRole)) {
          console.log('[AppContext] Fallback: User is admin via admin_users, role:', myAdmin.role);
          return true;
        }
        console.log('[AppContext] Fallback: User has admin_users entry with role:', myAdmin.role);
        return true;
      }
    } catch (e: any) {
      console.warn('[AppContext] Fallback admin_users check failed:', e?.message);
    }

    return false;
  };



  // ============================================================================
  // FULL USER SETUP — with concurrency guard
  // Each step runs independently so one failure doesn't block others.
  // CRITICAL: This must never throw — login must succeed even if all steps fail.
  // ============================================================================
  const setupUserData = async (userId: string, email: string) => {
    // Prevent concurrent calls for the same user
    if (setupInProgressRef.current) {
      console.log('[AppContext] setupUserData already in progress, skipping duplicate call');
      return;
    }
    // Skip if we already completed setup for this user
    if (setupCompletedForRef.current === userId) {
      console.log('[AppContext] setupUserData already completed for this user, skipping');
      return;
    }

    setupInProgressRef.current = true;
    try {
      // 1. Ensure utilisateur row exists and sync data (non-blocking)
      try {
        const util = await ensureUtilisateur(userId, email);
        setUtilisateur(util);
      } catch (err: any) {
        console.warn('[AppContext] ensureUtilisateur failed (non-blocking):', err?.message);
        setUtilisateur(null);
      }

      // 2. Ensure creator profile exists (critical for dashboard access)
      let profile: CreatorProfile | null = null;
      try {
        profile = await ensureCreatorProfile(userId, email);
        setCreatorProfile(profile);
      } catch (err: any) {
        console.warn('[AppContext] ensureCreatorProfile failed (non-blocking):', err?.message);
        setCreatorProfile(null);
      }

      // 3. Fetch subscription if profile exists (non-blocking)
      if (profile) {
        try {
          await fetchSubscription(profile.id);
        } catch (err: any) {
          console.warn('[AppContext] fetchSubscription failed (non-blocking):', err?.message);
        }
      }

      // 4. Check/setup admin status (non-blocking)
      try {
        const adminStatus = await ensureFirstUserAdmin(userId, email);
        setIsAdmin(adminStatus);
      } catch (err: any) {
        console.warn('[AppContext] ensureFirstUserAdmin failed (non-blocking):', err?.message);
        setIsAdmin(false);
      }

      // Mark as completed for this user
      setupCompletedForRef.current = userId;
    } catch (err: any) {
      console.warn('[AppContext] setupUserData unexpected error:', err?.message);
    } finally {
      setupInProgressRef.current = false;
    }
  };


  useEffect(() => {
    // CRITICAL: Guarantee loading state resolves within 8 seconds max
    // This prevents the app from being stuck on a loading screen forever
    const maxLoadingTimeout = setTimeout(() => {
      setIsLoading(prev => {
        if (prev) {
          console.warn('[AppContext] Auth init forced timeout after 8s — showing app in demo mode');
          return false;
        }
        return prev;
      });
    }, 8000);

    const initAuth = async () => {
      if (!isSupabaseConfigured) {
        console.info('[AppContext] Supabase not configured — skipping auth init, running in demo mode.');
        setIsLoading(false);
        return;
      }

      try {
        const timeoutPromise = new Promise<null>((resolve) => {
          setTimeout(() => {
            console.warn('[AppContext] Auth init timeout after 10s');
            resolve(null);
          }, 10000);
        });

        const sessionPromise = supabase.auth.getSession().then(({ data: { session }, error }) => {
          if (error) {
            // Gracefully handle AbortError during session retrieval
            if (isAbortError(error)) {
              console.warn('[AppContext] Auth session AbortError (lock contention) — will retry via onAuthStateChange');
              return null;
            }
            console.warn('[AppContext] Auth session error:', error.message);
            return null;
          }
          return session;
        }).catch((err) => {
          // Gracefully handle AbortError
          if (isAbortError(err)) {
            console.warn('[AppContext] Auth session AbortError caught — will retry via onAuthStateChange');
            return null;
          }
          console.warn('[AppContext] Auth session exception:', err?.message);
          return null;
        });

        const session = await Promise.race([sessionPromise, timeoutPromise]);

        if (session?.user) {
          const userEmail = session.user.email || '';
          setUser({ id: session.user.id, email: userEmail });
          await setupUserData(session.user.id, userEmail);
        }
      } catch (err: any) {
        // Gracefully handle AbortError at the top level
        if (isAbortError(err)) {
          console.warn('[AppContext] Auth init AbortError — will retry via onAuthStateChange');
        } else {
          console.warn('[AppContext] Auth init exception:', err?.message);
        }
      } finally {
        initCompletedRef.current = true;
        setIsLoading(false);
      }
    };

    initAuth();

    // Listen for auth state changes
    let authSubscription: { unsubscribe: () => void } | null = null;
    let sessionCheckInterval: ReturnType<typeof setInterval> | null = null;

    if (isSupabaseConfigured) {
      try {
        const { data } = supabase.auth.onAuthStateChange(async (event, session) => {
          console.log('[AppContext] Auth event:', event);
          
          if (event === 'SIGNED_IN' && session?.user) {
            const userEmail = session.user.email || '';
            setUser({ id: session.user.id, email: userEmail });
            // setupUserData has its own concurrency guard — safe to call
            await setupUserData(session.user.id, userEmail);
          } else if (event === 'TOKEN_REFRESHED' && session?.user) {
            console.log('[AppContext] Token refreshed for:', session.user.email);
            const userEmail = session.user.email || '';
            setUser(prev => {
              if (!prev || prev.id !== session.user.id) {
                return { id: session.user.id, email: userEmail };
              }
              return prev;
            });
          } else if (event === 'SIGNED_OUT') {
            setUser(null);
            setUtilisateur(null);
            setCreatorProfile(null);
            setSubscription(null);
            setHasActiveSubscription(false);
            setIsAdmin(false);
            // Reset setup tracking so next sign-in works
            setupCompletedForRef.current = null;
          }

        });
        authSubscription = data.subscription;
      } catch (err: any) {
        console.warn('[AppContext] Auth listener setup failed:', err?.message);
      }

      // Periodic session check — prevent silent disconnections (every 2 minutes)
      sessionCheckInterval = setInterval(async () => {
        try {
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user) {
            setUser(prev => {
              if (!prev && session.user) {
                console.log('[AppContext] Session recovery — re-setting user:', session.user.email);
                setupUserData(session.user.id, session.user.email || '');
                return { id: session.user.id, email: session.user.email || '' };
              }
              return prev;
            });
          }
        } catch {
          // Silent — don't disrupt the app
        }
      }, 120000); // Increased to 2 minutes to reduce lock contention
    }

    return () => {
      clearTimeout(maxLoadingTimeout);
      authSubscription?.unsubscribe();
      if (sessionCheckInterval) clearInterval(sessionCheckInterval);
    };
  }, []);



  // ---- Auth actions ----

  const signUp = async (email: string, password: string) => {
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Veuillez entrer une adresse email valide.' };
    }
    if (!password || password.length < 6) {
      return { success: false, error: 'Le mot de passe doit contenir au moins 6 caractères.' };
    }

    // Prevent concurrent auth operations (rapid double-clicks)
    if (authOperationInProgressRef.current) {
      return { success: false, error: 'Opération en cours, veuillez patienter...' };
    }
    authOperationInProgressRef.current = true;

    try {
      // Reset setup tracking for new sign-up
      setupCompletedForRef.current = null;

      const { data, error } = await supabase.auth.signUp({ email, password });

      if (error) {
        console.warn('[SignUp] Supabase error object:', error);
        const errorCode = getEmailErrorCode(error);
        return { success: false, error: translateAuthError(error), errorCode };
      }

      if (data.user) {
        if (data.user.identities && data.user.identities.length === 0) {
          return {
            success: false,
            error: 'Un compte existe déjà avec cet email. Essayez de vous connecter.',
          };
        }

        if (data.session === null && data.user.email_confirmed_at === null) {
          return { success: true };
        }

        const userEmail = data.user.email || '';
        setUser({ id: data.user.id, email: userEmail });
        await setupUserData(data.user.id, userEmail);
        
        return { success: true };
      }

      return { success: false, error: 'Une erreur inattendue est survenue. Veuillez réessayer.' };
    } catch (err: any) {
      console.error('[SignUp Error]', err);
      // Handle AbortError gracefully
      if (isAbortError(err)) {
        return { success: false, error: 'La connexion a été interrompue. Veuillez réessayer.' };
      }
      const errorCode = getEmailErrorCode(err);
      return { success: false, error: translateAuthError(err), errorCode };
    } finally {
      authOperationInProgressRef.current = false;
    }
  };

  const signIn = async (email: string, password: string): Promise<AuthResult> => {
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Veuillez entrer une adresse email valide.' };
    }
    if (!password) {
      return { success: false, error: 'Veuillez entrer votre mot de passe.' };
    }

    // Prevent concurrent auth operations (rapid double-clicks)
    if (authOperationInProgressRef.current) {
      return { success: false, error: 'Connexion en cours, veuillez patienter...' };
    }
    authOperationInProgressRef.current = true;

    try {
      // Reset setup tracking for new sign-in
      setupCompletedForRef.current = null;

      const { data, error } = await supabase.auth.signInWithPassword({ email, password });

      if (error) {
        console.warn('[SignIn] Supabase error object:', error);
        // Handle AbortError from navigator lock contention
        if (isAbortError(error)) {
          return { success: false, error: 'La connexion a été interrompue. Veuillez réessayer.' };
        }
        const errorCode = getEmailErrorCode(error);
        return { success: false, error: translateAuthError(error), errorCode };
      }

      if (data.user) {
        const userEmail = data.user.email || '';
        setUser({ id: data.user.id, email: userEmail });
        await setupUserData(data.user.id, userEmail);
        
        return { success: true };
      }

      return { success: false, error: 'Une erreur inattendue est survenue. Veuillez réessayer.' };
    } catch (err: any) {
      console.error('[SignIn Error]', err);
      // Handle AbortError gracefully
      if (isAbortError(err)) {
        return { success: false, error: 'La connexion a été interrompue. Veuillez réessayer.' };
      }
      const errorCode = getEmailErrorCode(err);
      return { success: false, error: translateAuthError(err), errorCode };
    } finally {
      authOperationInProgressRef.current = false;
    }
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
    } catch (err: any) {
      console.warn('[SignOut] Error:', err?.message);
    }
    setUser(null);
    setUtilisateur(null);
    setCreatorProfile(null);
    setSubscription(null);
    setHasActiveSubscription(false);
    setIsAdmin(false);
    // Reset setup tracking
    setupCompletedForRef.current = null;
    setupInProgressRef.current = false;
    authOperationInProgressRef.current = false;
  };


  // ---- Profile actions ----

  const createProfile = async (data: Partial<CreatorProfile>) => {
    if (!user) return { success: false, error: 'Vous devez être connecté.' };

    try {
      const editableFields = {
        username: data.username,
        display_name: data.display_name,
        bio: data.bio || null,
        avatar_url: data.avatar_url || null,
        whatsapp_number: data.whatsapp_number || null,
      };

      console.log('[createProfile] Creating/updating profile for user:', user.id, 'username:', data.username);

      const { data: existingProfile } = await supabase
        .from('creator_profiles')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      let resultProfile: any = null;
      let resultError: any = null;

      if (existingProfile) {
        console.log('[createProfile] Profile exists, updating...');
        const { data: updated, error: updateErr } = await supabase
          .from('creator_profiles')
          .update({ ...editableFields, updated_at: new Date().toISOString() })
          .eq('user_id', user.id)
          .select()
          .single();
        resultProfile = updated;
        resultError = updateErr;
      } else {
        console.log('[createProfile] No profile found, inserting...');
        const { data: inserted, error: insertErr } = await supabase
          .from('creator_profiles')
          .insert({ user_id: user.id, ...editableFields })
          .select()
          .single();
        resultProfile = inserted;
        resultError = insertErr;

        if (insertErr?.code === '23505') {
          console.log('[createProfile] Insert conflict (race condition), trying update...');
          const { data: updated2, error: updateErr2 } = await supabase
            .from('creator_profiles')
            .update({ ...editableFields, updated_at: new Date().toISOString() })
            .eq('user_id', user.id)
            .select()
            .single();
          resultProfile = updated2;
          resultError = updateErr2;
        }
      }

      if (resultError) {
        console.error('[createProfile] Error:', resultError.code, resultError.message);
        if (resultError.code === '23505' && resultError.message?.includes('username')) {
          return { success: false, error: 'Ce nom d\'utilisateur est déjà pris. Veuillez en choisir un autre.' };
        }
        return { success: false, error: 'Erreur lors de l\'enregistrement du profil. Veuillez réessayer.' };
      }

      if (resultProfile) {
        console.log('[createProfile] Profile saved successfully:', resultProfile.username);
        setCreatorProfile(resultProfile as CreatorProfile);
        return { success: true };
      }

      return { success: false, error: 'Erreur inattendue lors de l\'enregistrement.' };
    } catch (err: any) {
      console.error('[createProfile] Exception:', err);
      return { success: false, error: translateAuthError(err?.message || 'Erreur lors de la création du profil.') };
    }
  };

  const updateProfile = async (data: Partial<CreatorProfile>) => {
    if (!user || !creatorProfile) return { success: false, error: 'Vous devez être connecté.' };

    try {
      const { followers_count, total_views, id, user_id, created_at, updated_at, ...editableFields } = data as any;
      
      const { data: updatedProfile, error } = await supabase
        .from('creator_profiles')
        .update({ ...editableFields, updated_at: new Date().toISOString() })
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) return { success: false, error: translateAuthError(error.message) };

      setCreatorProfile(updatedProfile as CreatorProfile);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: translateAuthError(err?.message || 'Erreur lors de la mise à jour.') };
    }
  };

  const uploadAvatar = async (file: File) => {
    if (!user) return { success: false, error: 'Vous devez être connecté.' };

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, { upsert: true });

      if (uploadError) return { success: false, error: uploadError.message };

      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(fileName);
      return { success: true, url: publicUrl };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const refreshProfile = async () => {
    if (user) {
      const profile = await fetchCreatorProfile(user.id);
      setCreatorProfile(profile);
      if (profile) {
        await fetchSubscription(profile.id);
      }
    }
  };

  const refreshSubscription = async () => {
    if (creatorProfile) {
      await fetchSubscription(creatorProfile.id);
    }
  };

  return (
    <AppContext.Provider
      value={{
        sidebarOpen,
        toggleSidebar,
        user,
        utilisateur,
        creatorProfile,
        subscription,
        hasActiveSubscription,
        isAuthenticated: !!user,
        isLoading,
        isSupabaseReady: isSupabaseConfigured,
        isAdmin,
        signUp,
        signIn,
        signOut,
        createProfile,
        updateProfile,
        updateUtilisateur,
        refreshUtilisateur,
        uploadAvatar,
        refreshProfile,
        refreshSubscription,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};


