# Famous.ai — Guide complet de configuration de la base de données

## Vue d'ensemble

Le fichier `supabase-setup.sql` contient **tout** ce dont vous avez besoin pour configurer votre base de données Supabase. Ce script est **idempotent** — vous pouvez l'exécuter plusieurs fois sans erreur.

### Ce que le script crée :

| # | Élément | Description |
|---|---------|-------------|
| 1 | **13 Tables** | creator_profiles, subscription_plans, creator_subscriptions, admin_users, team_members, support_requests, live_streams, live_chat_messages, chat_bans, moderation_logs, follows, verification_requests, payments |
| 2 | **Index** | Index optimisés sur toutes les colonnes fréquemment requêtées |
| 3 | **Fonctions RPC** | count_recent_messages (anti-spam), get_stream_creator_id, handle_updated_at, update_creator_stats |
| 4 | **Triggers** | updated_at automatique sur 9 tables, recalcul stats créateur à la fin d'un live |
| 5 | **RLS activé** | Row Level Security activé sur les 13 tables |
| 6 | **38+ Policies RLS** | Règles de sécurité complètes pour chaque table (SELECT, INSERT, UPDATE, DELETE) |
| 7 | **Realtime** | Publication temps réel pour live_chat_messages, live_streams, follows |
| 8 | **3 Plans d'abonnement** | Starter (2 990 FCFA), Pro (5 990 FCFA), Business (14 990 FCFA) |
| 9 | **3 Storage Buckets** | avatars (5 Mo, public), verification-documents (10 Mo, privé), recordings (500 Mo, public) |
| 10 | **Storage Policies** | Politiques de lecture/écriture/suppression pour chaque bucket |

---

## Étapes d'exécution

### Étape 1 : Accéder au SQL Editor

1. Connectez-vous à [app.supabase.com](https://app.supabase.com)
2. Sélectionnez votre projet Famous.ai
3. Dans le menu latéral gauche, cliquez sur **SQL Editor** (icône de terminal)

### Étape 2 : Créer une nouvelle requête

1. Cliquez sur **"New query"** (bouton vert en haut à droite)
2. Donnez un nom à la requête : `Famous.ai - Setup complet`

### Étape 3 : Copier le script SQL

1. Ouvrez le fichier `supabase-setup.sql` dans votre éditeur de code
2. Sélectionnez **tout le contenu** (Ctrl+A / Cmd+A)
3. Copiez-le (Ctrl+C / Cmd+C)
4. Collez-le dans l'éditeur SQL de Supabase (Ctrl+V / Cmd+V)

### Étape 4 : Exécuter le script

1. Cliquez sur le bouton **"Run"** (ou appuyez sur Ctrl+Enter / Cmd+Enter)
2. Attendez que l'exécution se termine (environ 5-15 secondes)
3. Vous devriez voir : `Success. No rows returned` (c'est normal !)

### Étape 5 : Vérifier l'installation

Exécutez ces requêtes de vérification une par une :

```sql
-- Vérifier les tables (doit retourner 13 lignes)
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_type = 'BASE TABLE'
ORDER BY table_name;

-- Vérifier les politiques RLS (doit retourner 38+ lignes)
SELECT schemaname, tablename, policyname, cmd 
FROM pg_policies 
WHERE schemaname = 'public'
ORDER BY tablename, cmd;

-- Vérifier les plans d'abonnement (doit retourner 3 lignes)
SELECT name, price_monthly, price_yearly, is_active 
FROM public.subscription_plans;

-- Vérifier les storage buckets (doit retourner 3 lignes)
SELECT id, name, public, file_size_limit 
FROM storage.buckets 
WHERE id IN ('avatars', 'verification-documents', 'recordings');

-- Vérifier les politiques de storage
SELECT policyname, cmd 
FROM pg_policies 
WHERE schemaname = 'storage'
ORDER BY policyname;
```

---

## ⚡ Étape 6 : Activer Realtime (OBLIGATOIRE)

> **IMPORTANT** : Cette étape **ne peut PAS** être faite via le SQL Editor. La commande `ALTER PUBLICATION supabase_realtime ADD TABLE` incluse dans le script SQL peut échouer silencieusement selon la version de Supabase. Vous **devez** activer Realtime manuellement via le Dashboard UI.

### Pourquoi c'est nécessaire ?

Sans Realtime activé sur ces tables :
- Les **messages du chat** n'apparaissent pas instantanément (délai de ~5 secondes en mode polling)
- Les **mises à jour de statut des lives** (début/fin) ne se propagent pas en temps réel
- Les **follows** ne se mettent pas à jour immédiatement pour les autres utilisateurs

### Comment activer Realtime :

#### Méthode 1 : Via le Dashboard UI (recommandée)

1. Connectez-vous à [app.supabase.com](https://app.supabase.com)
2. Sélectionnez votre projet
3. Dans le menu latéral gauche, cliquez sur **Database** (icône de base de données)
4. Cliquez sur **Replication** dans le sous-menu
5. Vous verrez la section **"supabase_realtime"** avec la liste de vos tables
6. **Activez le toggle** (ON) pour ces 3 tables :

| Table | Raison |
|-------|--------|
| `live_chat_messages` | Chat en direct instantané — les messages apparaissent immédiatement pour tous les spectateurs |
| `live_streams` | Détection automatique des lives en cours — les spectateurs voient quand un live commence/se termine |
| `follows` | Mise à jour instantanée du compteur de followers |

7. Chaque toggle doit passer au **vert** (ON)

#### Méthode 2 : Via le SQL Editor (alternative)

Si vous préférez utiliser SQL, exécutez cette commande :

```sql
-- Ajouter les tables à la publication Realtime
-- NOTE: Cette commande peut échouer si les tables sont déjà dans la publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.live_chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.live_streams;
ALTER PUBLICATION supabase_realtime ADD TABLE public.follows;
```

Si vous obtenez l'erreur `relation "public.xxx" is already member of publication "supabase_realtime"`, c'est que la table est déjà activée — tout va bien !

### Vérifier que Realtime est activé :

```sql
-- Lister les tables dans la publication Realtime
SELECT schemaname, tablename 
FROM pg_publication_tables 
WHERE pubname = 'supabase_realtime'
ORDER BY tablename;
```

Vous devriez voir au minimum :
```
 schemaname |      tablename       
------------+----------------------
 public     | follows
 public     | live_chat_messages
 public     | live_streams
```

### Diagnostic dans l'application :

L'application détecte automatiquement si Realtime fonctionne :
- **Chat** : Si Realtime n'est pas activé, le chat passe en mode **polling** (rafraîchissement toutes les 5 secondes) et affiche un badge **"Polling"** dans l'en-tête du chat
- **Page d'accueil** : Un bandeau bleu s'affiche en bas de page avec un lien direct vers les paramètres de Replication
- **Page Diagnostics** (`/diagnostics`) : Le test "Realtime" vérifie la connexion WebSocket

---

## Détail des politiques RLS par table

### creator_profiles (4 policies)
| Action | Règle |
|--------|-------|
| SELECT | Tout le monde (public) |
| INSERT | Utilisateur authentifié = propriétaire (user_id) |
| UPDATE | Utilisateur authentifié = propriétaire (user_id) |
| DELETE | Utilisateur authentifié = propriétaire (user_id) |

### subscription_plans (2 policies)
| Action | Règle |
|--------|-------|
| SELECT | Tout le monde (public) |
| ALL | Admins/Owners de l'équipe uniquement |

### creator_subscriptions (4 policies)
| Action | Règle |
|--------|-------|
| SELECT | Créateur propriétaire OU membre de l'équipe |
| INSERT | Créateur propriétaire uniquement |
| UPDATE | Créateur propriétaire OU admin/owner de l'équipe |
| DELETE | Créateur propriétaire OU admin/owner de l'équipe |

### admin_users (1 policy)
| Action | Règle |
|--------|-------|
| SELECT | L'utilisateur lui-même OU admin/owner de l'équipe |

### team_members (3 policies)
| Action | Règle |
|--------|-------|
| SELECT | Tout membre actif de l'équipe OU l'utilisateur lui-même |
| INSERT | Si aucun owner n'existe (premier utilisateur) OU admin/owner existant |
| UPDATE | Admin/owner de l'équipe OU l'utilisateur lui-même |

### support_requests (3 policies)
| Action | Règle |
|--------|-------|
| SELECT | Créateur propriétaire OU membre de l'équipe |
| INSERT | Créateur propriétaire uniquement |
| UPDATE | Admin/owner/modérateur de l'équipe |

### live_streams (3 policies)
| Action | Règle |
|--------|-------|
| SELECT | Tout le monde (public) |
| INSERT | Créateur propriétaire uniquement |
| UPDATE | Créateur propriétaire OU équipe avec permission manage_streams |

### live_chat_messages (3 policies)
| Action | Règle |
|--------|-------|
| SELECT | Tout le monde (public) |
| INSERT | Utilisateur authentifié = auteur (user_id) |
| UPDATE | Auteur du message OU équipe avec permission moderate_chat |

### chat_bans (3 policies)
| Action | Règle |
|--------|-------|
| SELECT | Utilisateur banni lui-même OU équipe avec permission moderate_chat |
| INSERT | Équipe avec permission moderate_chat OU créateur |
| UPDATE | Équipe avec permission moderate_chat |

### moderation_logs (2 policies)
| Action | Règle |
|--------|-------|
| SELECT | Tout membre actif de l'équipe |
| INSERT | Utilisateur authentifié = modérateur (moderator_id) |

### follows (3 policies)
| Action | Règle |
|--------|-------|
| SELECT | Tout le monde (public) |
| INSERT | Utilisateur authentifié = follower (follower_id) |
| DELETE | Utilisateur authentifié = follower (follower_id) |

### verification_requests (3 policies)
| Action | Règle |
|--------|-------|
| SELECT | Créateur propriétaire OU équipe avec permission manage_verification |
| INSERT | Créateur propriétaire uniquement |
| UPDATE | Équipe avec permission manage_verification |

### payments (3 policies)
| Action | Règle |
|--------|-------|
| SELECT | Créateur propriétaire OU équipe avec permission view_payments |
| INSERT | Créateur propriétaire uniquement |
| UPDATE | Admin/owner de l'équipe uniquement |

---

## Résolution de problèmes

### Erreur : "Could not find the 'email' column of 'team_members' in the schema cache"

**Cause** : La colonne `email` n'existe pas dans votre table `team_members`. Cela arrive si la table a été créée avec une ancienne version du script SQL qui ne contenait pas cette colonne.

**Solution rapide** : Exécutez cette commande dans le **SQL Editor** de Supabase :

```sql
ALTER TABLE public.team_members ADD COLUMN IF NOT EXISTS email TEXT NOT NULL DEFAULT '';
```

Puis **rechargez la page** de l'application. L'erreur disparaîtra immédiatement.

**Solution définitive** : Ré-exécutez le script complet `supabase-setup.sql` (il est idempotent et contient désormais une migration automatique pour cette colonne).

### Erreur : "relation already exists"
**Solution** : C'est normal et géré par `CREATE TABLE IF NOT EXISTS`. Le script est idempotent.

### Erreur : "policy already exists"
**Solution** : Le script utilise `DROP POLICY IF EXISTS` avant chaque `CREATE POLICY`. Si vous voyez cette erreur, vérifiez que vous exécutez le script complet (pas un extrait partiel).

### Erreur : "permission denied for schema"
**Solution** : Assurez-vous d'exécuter le script depuis le SQL Editor de Supabase (qui utilise le rôle `postgres` avec tous les privilèges).

### Les tables sont créées mais les policies ne fonctionnent pas
**Solution** : Vérifiez que RLS est bien activé :
```sql
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public';
```
Toutes les tables doivent avoir `rowsecurity = true`.

### Le chat ne fonctionne pas en temps réel (messages avec délai)

**Cause** : Realtime n'est pas activé pour la table `live_chat_messages`.

**Solution** :
1. Allez dans **Dashboard Supabase** > **Database** > **Replication**
2. Activez le toggle pour `live_chat_messages`
3. Vérifiez aussi `live_streams` et `follows`

Voir la section [Étape 6 : Activer Realtime](#-étape-6--activer-realtime-obligatoire) ci-dessus.

### Les lives ne se mettent pas à jour automatiquement

**Cause** : Realtime n'est pas activé pour la table `live_streams`.

**Solution** : Même procédure que ci-dessus — activez Realtime pour `live_streams` dans Database > Replication.

### L'authentification ne fonctionne pas
**Solution** : Vérifiez vos variables d'environnement dans `.env` :
```env
VITE_SUPABASE_URL=https://encxfaensoedguznstwa.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVuY3hmYWVuc29lZGd1em5zdHdhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA0MjIyMjMsImV4cCI6MjA4NTk5ODIyM30.EPNVabonZ66YGjQBgjrzsCcYW7k7hTKKnNr0mSs2qCQ
```


---

## Configurer le premier administrateur

Après avoir exécuté le script SQL et créé un compte utilisateur via l'application :

```sql
-- Remplacez 'VOTRE_USER_ID' par l'UUID de votre utilisateur
-- (visible dans Authentication > Users dans le dashboard Supabase)

INSERT INTO public.team_members (user_id, email, display_name, role, permissions, is_active)
VALUES (
  'VOTRE_USER_ID',
  'votre@email.com',
  'Votre Nom',
  'owner',
  '{
    "view_dashboard": true,
    "manage_streams": true,
    "moderate_chat": true,
    "manage_creators": true,
    "manage_subscriptions": true,
    "manage_team": true,
    "view_payments": true,
    "manage_verification": true
  }'::jsonb,
  true
);

-- Optionnel : ajouter aussi dans admin_users (legacy)
INSERT INTO public.admin_users (user_id, email, role)
VALUES ('VOTRE_USER_ID', 'votre@email.com', 'super_admin');
```

### Comment trouver votre User ID :
1. Allez dans le dashboard Supabase
2. Cliquez sur **Authentication** dans le menu latéral
3. Onglet **Users**
4. Copiez l'**UUID** de votre utilisateur

---

## Architecture de sécurité

```
┌─────────────────────────────────────────────────┐
│                   Client (React)                 │
│  Utilise la clé anon (publique) uniquement       │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│              Supabase API Gateway                │
│  Vérifie le JWT token de l'utilisateur           │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│           Row Level Security (RLS)               │
│  38+ policies vérifient les permissions          │
│  auth.uid() = identité de l'utilisateur          │
│  team_members = rôles et permissions             │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│              PostgreSQL Database                  │
│  13 tables avec index optimisés                  │
│  Triggers automatiques (updated_at, stats)       │
│  Realtime activé sur 3 tables clés               │
└─────────────────────────────────────────────────┘
```

---

## Checklist de mise en production

Avant de lancer votre application en production, vérifiez :

- [ ] Script SQL exécuté avec succès
- [ ] 13 tables créées
- [ ] 38+ policies RLS actives
- [ ] 3 storage buckets créés
- [ ] **Realtime activé** pour `live_chat_messages`, `live_streams`, `follows`
- [ ] Premier administrateur configuré (team_members + admin_users)
- [ ] Variables d'environnement configurées (VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY)
- [ ] Edge Functions déployées (process-payment, stream-manager, confirm-user-email, push-notifications)
- [ ] Page Diagnostics (`/diagnostics`) : tous les tests au vert

---

*Script SQL : `supabase-setup.sql` | Dernière mise à jour : Février 2026*
